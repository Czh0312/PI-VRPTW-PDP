* Signature: 0x57816b609b0000de
NAME M5_complete_enumerated_E2_route_cover
ROWS
 N  OBJ
 E  cover_0 
 E  cover_1 
 E  cover_2 
 E  cover_3 
 L  aggregate_trip_limit
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    route_0   OBJ       7.6550636836018555e+01
    route_0   cover_1   1
    route_0   aggregate_trip_limit  1
    route_1   OBJ       7.7566443393746567e+01
    route_1   cover_1   1
    route_1   cover_3   1
    route_1   aggregate_trip_limit  1
    route_2   OBJ       1.6970562748477139e+01
    route_2   cover_3   1
    route_2   aggregate_trip_limit  1
    route_3   OBJ       7.6550636836018555e+01
    route_3   cover_0   1
    route_3   aggregate_trip_limit  1
    route_4   OBJ       7.6550636836018555e+01
    route_4   cover_0   1
    route_4   cover_1   1
    route_4   aggregate_trip_limit  1
    route_5   OBJ       7.7566443393746567e+01
    route_5   cover_0   1
    route_5   cover_1   1
    route_5   cover_3   1
    route_5   aggregate_trip_limit  1
    route_6   OBJ       7.7566443393746567e+01
    route_6   cover_0   1
    route_6   cover_3   1
    route_6   aggregate_trip_limit  1
    route_7   OBJ       1.6970562748477139e+01
    route_7   cover_2   1
    route_7   aggregate_trip_limit  1
    route_8   OBJ       1.6970562748477139e+01
    route_8   cover_2   1
    route_8   cover_3   1
    route_8   aggregate_trip_limit  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      cover_0   1
    RHS1      cover_1   1
    RHS1      cover_2   1
    RHS1      cover_3   1
    RHS1      aggregate_trip_limit  4
BOUNDS
 BV BND1      route_0 
 BV BND1      route_1 
 BV BND1      route_2 
 BV BND1      route_3 
 BV BND1      route_4 
 BV BND1      route_5 
 BV BND1      route_6 
 BV BND1      route_7 
 BV BND1      route_8 
ENDATA
