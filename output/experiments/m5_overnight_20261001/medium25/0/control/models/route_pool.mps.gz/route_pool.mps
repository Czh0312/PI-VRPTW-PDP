* Signature: 0xdb3915ebbc3c90b1
NAME M5_complete_E1_route_inventory_relaxation
ROWS
 N  OBJ
 L  R0      
 L  R1      
 G  R2      
 L  R3      
 L  R4      
 L  R5      
 G  R6      
 L  R7      
 L  R8      
 L  R9      
 L  R10     
 L  R11     
 G  R12     
 L  R13     
 L  R14     
 L  R15     
 G  R16     
 L  R17     
 L  R18     
 L  R19     
 G  R20     
 L  R21     
 L  R22     
 L  R23     
 G  R24     
 L  R25     
 G  R26     
 L  R27     
 L  R28     
 L  R29     
 G  R30     
 L  R31     
 G  R32     
 L  R33     
 L  R34     
 L  R35     
 L  R36     
 L  R37     
 G  R38     
 L  R39     
 L  R40     
 L  R41     
 G  R42     
 L  R43     
 L  R44     
 L  R45     
 G  R46     
 L  R47     
 G  R48     
 L  R49     
 L  R50     
 L  R51     
 L  R52     
 L  R53     
 G  R54     
 L  R55     
 L  R56     
 L  R57     
 G  R58     
 L  R59     
 L  R60     
 L  R61     
 G  R62     
 L  R63     
 L  R64     
 L  R65     
 G  R66     
 L  R67     
 G  R68     
 L  R69     
 L  R70     
 L  R71     
 G  R72     
 L  R73     
 G  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 G  R80     
 L  R81     
 L  R82     
 L  R83     
 G  R84     
 L  R85     
 L  R86     
 L  R87     
 G  R88     
 L  R89     
 G  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 G  R96     
 L  R97     
 L  R98     
 L  R99     
 G  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 G  R106    
 L  R107    
 L  R108    
 L  R109    
 G  R110    
 L  R111    
 L  R112    
 L  R113    
 G  R114    
 L  R115    
 G  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 G  R122    
 L  R123    
 L  R124    
 L  R125    
 G  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 G  R132    
 L  R133    
 L  R134    
 L  R135    
 G  R136    
 L  R137    
 L  R138    
 L  R139    
 G  R140    
 L  R141    
 L  R142    
 L  R143    
 G  R144    
 L  R145    
 G  R146    
 L  R147    
 L  R148    
 L  R149    
 G  R150    
 L  R151    
 G  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 G  R158    
 L  R159    
 L  R160    
 L  R161    
 G  R162    
 L  R163    
 L  R164    
 L  R165    
 G  R166    
 L  R167    
 G  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 G  R174    
 L  R175    
 L  R176    
 L  R177    
 G  R178    
 L  R179    
 L  R180    
 L  R181    
 G  R182    
 L  R183    
 L  R184    
 L  R185    
 G  R186    
 L  R187    
 G  R188    
 L  R189    
 L  R190    
 L  R191    
 G  R192    
 L  R193    
 G  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 G  R200    
 L  R201    
 L  R202    
 L  R203    
 G  R204    
 L  R205    
 L  R206    
 L  R207    
 G  R208    
 L  R209    
 G  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 G  R216    
 L  R217    
 L  R218    
 L  R219    
 G  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 G  R226    
 L  R227    
 L  R228    
 L  R229    
 G  R230    
 L  R231    
 L  R232    
 L  R233    
 G  R234    
 L  R235    
 L  R236    
 L  R237    
 G  R238    
 L  R239    
 G  R240    
 L  R241    
 L  R242    
 L  R243    
 G  R244    
 L  R245    
 G  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 G  R252    
 L  R253    
 L  R254    
 L  R255    
 G  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 G  R262    
 L  R263    
 L  R264    
 L  R265    
 G  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 G  R272    
 L  R273    
 L  R274    
 L  R275    
 G  R276    
 L  R277    
 L  R278    
 L  R279    
 G  R280    
 L  R281    
 L  R282    
 L  R283    
 G  R284    
 L  R285    
 G  R286    
 L  R287    
 L  R288    
 L  R289    
 G  R290    
 L  R291    
 G  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 G  R298    
 L  R299    
 L  R300    
 L  R301    
 G  R302    
 L  R303    
 L  R304    
 L  R305    
 G  R306    
 L  R307    
 G  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 G  R314    
 L  R315    
 L  R316    
 L  R317    
 G  R318    
 L  R319    
 L  R320    
 L  R321    
 G  R322    
 L  R323    
 L  R324    
 L  R325    
 G  R326    
 L  R327    
 G  R328    
 L  R329    
 L  R330    
 L  R331    
 G  R332    
 L  R333    
 G  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 G  R340    
 L  R341    
 L  R342    
 L  R343    
 G  R344    
 L  R345    
 L  R346    
 L  R347    
 G  R348    
 L  R349    
 G  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 G  R356    
 L  R357    
 L  R358    
 L  R359    
 G  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 G  R366    
 L  R367    
 L  R368    
 L  R369    
 G  R370    
 L  R371    
 L  R372    
 L  R373    
 G  R374    
 L  R375    
 G  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 G  R382    
 L  R383    
 L  R384    
 L  R385    
 G  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 G  R392    
 L  R393    
 L  R394    
 L  R395    
 G  R396    
 L  R397    
 L  R398    
 L  R399    
 G  R400    
 L  R401    
 L  R402    
 L  R403    
 G  R404    
 L  R405    
 G  R406    
 L  R407    
 L  R408    
 L  R409    
 G  R410    
 L  R411    
 G  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 G  R418    
 L  R419    
 L  R420    
 L  R421    
 G  R422    
 L  R423    
 L  R424    
 L  R425    
 G  R426    
 L  R427    
 G  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 G  R434    
 L  R435    
 L  R436    
 L  R437    
 G  R438    
 L  R439    
 L  R440    
 L  R441    
 G  R442    
 L  R443    
 L  R444    
 L  R445    
 G  R446    
 L  R447    
 G  R448    
 L  R449    
 L  R450    
 L  R451    
 G  R452    
 L  R453    
 G  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 G  R460    
 L  R461    
 L  R462    
 L  R463    
 G  R464    
 L  R465    
 L  R466    
 L  R467    
 G  R468    
 L  R469    
 G  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 G  R476    
 L  R477    
 L  R478    
 L  R479    
 G  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 G  R486    
 L  R487    
 L  R488    
 L  R489    
 G  R490    
 L  R491    
 L  R492    
 L  R493    
 G  R494    
 L  R495    
 L  R496    
 L  R497    
 G  R498    
 L  R499    
 G  R500    
 L  R501    
 L  R502    
 L  R503    
 G  R504    
 L  R505    
 G  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 G  R512    
 L  R513    
 L  R514    
 L  R515    
 G  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 G  R522    
 L  R523    
 L  R524    
 L  R525    
 G  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 G  R532    
 L  R533    
 L  R534    
 L  R535    
 G  R536    
 L  R537    
 L  R538    
 L  R539    
 G  R540    
 L  R541    
 L  R542    
 L  R543    
 G  R544    
 L  R545    
 G  R546    
 L  R547    
 L  R548    
 L  R549    
 G  R550    
 L  R551    
 G  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 G  R558    
 L  R559    
 L  R560    
 L  R561    
 G  R562    
 L  R563    
 L  R564    
 L  R565    
 G  R566    
 L  R567    
 L  R568    
 L  R569    
 G  R570    
 L  R571    
 G  R572    
 L  R573    
 L  R574    
 L  R575    
 G  R576    
 L  R577    
 G  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 G  R584    
 L  R585    
 L  R586    
 L  R587    
 G  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 E  R593    
 E  R594    
 L  R595    
 E  R596    
 E  R597    
 L  R598    
 E  R599    
 E  R600    
 L  R601    
 L  R602    
 E  R603    
 E  R604    
 L  R605    
 E  R606    
 E  R607    
 L  R608    
 E  R609    
 E  R610    
 L  R611    
 L  R612    
 E  R613    
 E  R614    
 L  R615    
 E  R616    
 E  R617    
 L  R618    
 L  R619    
 L  R620    
 G  R621    
 G  R622    
 G  R623    
 E  R624    
 L  R625    
 G  R626    
 G  R627    
 G  R628    
 E  R629    
 L  R630    
 G  R631    
 G  R632    
 G  R633    
 E  R634    
 L  R635    
 G  R636    
 G  R637    
 G  R638    
 E  R639    
 L  R640    
 G  R641    
 G  R642    
 G  R643    
 E  R644    
 L  R645    
 G  R646    
 G  R647    
 G  R648    
 E  R649    
 L  R650    
 G  R651    
 G  R652    
 G  R653    
 E  R654    
 L  R655    
 G  R656    
 G  R657    
 G  R658    
 E  R659    
 L  R660    
 G  R661    
 G  R662    
 G  R663    
 E  R664    
 L  R665    
 G  R666    
 G  R667    
 G  R668    
 E  R669    
 L  R670    
 G  R671    
 G  R672    
 G  R673    
 E  R674    
 L  R675    
 G  R676    
 G  R677    
 G  R678    
 E  R679    
 L  R680    
 G  R681    
 G  R682    
 G  R683    
 E  R684    
 L  R685    
 G  R686    
 G  R687    
 G  R688    
 E  R689    
 L  R690    
 G  R691    
 G  R692    
 G  R693    
 E  R694    
 L  R695    
 G  R696    
 G  R697    
 G  R698    
 E  R699    
 L  R700    
 G  R701    
 G  R702    
 G  R703    
 E  R704    
 L  R705    
 G  R706    
 G  R707    
 G  R708    
 E  R709    
 L  R710    
 G  R711    
 G  R712    
 G  R713    
 E  R714    
 L  R715    
 G  R716    
 G  R717    
 G  R718    
 E  R719    
 E  R720    
 E  R721    
 E  R722    
 E  R723    
 E  R724    
 E  R725    
 E  R726    
 E  R727    
 E  R728    
 G  clean_stock_b1
 G  clean_stock_b2
 G  clean_stock_b3
 G  R732    
 G  R733    
 G  R734    
 G  R735    
 G  R736    
 G  R737    
 G  R738    
 G  R739    
 G  R740    
 G  R741    
 G  R742    
 G  R743    
 G  R744    
 G  R745    
 G  R746    
 G  R747    
 G  R748    
 G  R749    
 G  R750    
 G  R751    
 E  R752    
 G  R753    
 L  R754    
 L  R755    
 G  R756    
 L  R757    
 L  R758    
 E  R759    
 E  R760    
 E  R761    
 E  R762    
 E  R763    
 E  R764    
 E  R765    
 E  R766    
 E  R767    
 E  R768    
 E  R769    
 E  R770    
 E  R771    
 E  R772    
 E  R773    
 E  R774    
 E  R775    
 E  R776    
 E  R777    
 E  R778    
 E  R779    
 E  R780    
 E  R781    
 E  R782    
 E  R783    
 E  R784    
 E  R785    
 E  R786    
 E  R787    
 E  R788    
 E  R789    
 E  R790    
 E  R791    
 E  R792    
 E  R793    
 E  R794    
 E  R795    
 E  R796    
 E  R797    
 E  R798    
 E  R799    
 E  R800    
 E  R801    
 E  R802    
 E  R803    
 E  R804    
 E  R805    
 E  R806    
 E  R807    
 E  R808    
 E  R809    
 E  R810    
 E  R811    
 E  R812    
 G  R813    
 L  R814    
 L  R815    
 G  R816    
 L  R817    
 L  R818    
 E  R819    
 E  R820    
 E  R821    
 E  R822    
 E  R823    
 E  R824    
 E  R825    
 E  R826    
 E  R827    
 E  R828    
 E  R829    
 E  R830    
 E  R831    
 E  R832    
 E  R833    
 E  R834    
 E  R835    
 E  R836    
 E  R837    
 E  R838    
 E  R839    
 E  R840    
 E  R841    
 E  R842    
 E  R843    
 E  R844    
 E  R845    
 E  R846    
 E  R847    
 E  R848    
 E  R849    
 E  R850    
 E  R851    
 E  R852    
 E  R853    
 E  R854    
 E  R855    
 G  R856    
 L  R857    
 L  R858    
 G  R859    
 L  R860    
 L  R861    
 E  R862    
 E  R863    
 E  R864    
 E  R865    
 E  R866    
 E  R867    
 E  R868    
 E  R869    
 E  R870    
 E  R871    
 E  R872    
 E  R873    
 E  R874    
 E  R875    
 E  R876    
 E  R877    
 E  R878    
 E  R879    
 E  R880    
 E  R881    
 E  R882    
 E  R883    
 E  R884    
 E  R885    
 E  R886    
 E  R887    
 E  R888    
 E  R889    
 E  R890    
 E  R891    
 E  R892    
 E  R893    
 E  R894    
 E  R895    
 E  R896    
 E  R897    
 E  R898    
 E  R899    
 E  R900    
 E  R901    
 G  R902    
 L  R903    
 L  R904    
 G  R905    
 L  R906    
 L  R907    
 E  R908    
 E  R909    
 E  R910    
 E  R911    
 E  R912    
 E  R913    
 E  R914    
 E  R915    
 E  R916    
 E  R917    
 E  R918    
 E  R919    
 E  R920    
 E  R921    
 E  R922    
 E  R923    
 E  R924    
 E  R925    
 E  R926    
 E  R927    
 E  R928    
 E  R929    
 E  R930    
 E  R931    
 E  R932    
 E  R933    
 E  R934    
 E  R935    
 E  R936    
 E  R937    
 E  R938    
 E  R939    
 E  R940    
 E  R941    
 G  R942    
 L  R943    
 L  R944    
 G  R945    
 L  R946    
 L  R947    
 E  R948    
 E  R949    
 E  R950    
 E  R951    
 E  R952    
 E  R953    
 E  R954    
 E  R955    
 E  R956    
 E  R957    
 E  R958    
 E  R959    
 E  R960    
 E  R961    
 E  R962    
 E  R963    
 E  R964    
 E  R965    
 E  R966    
 E  R967    
 E  R968    
 E  R969    
 E  R970    
 E  R971    
 E  R972    
 E  R973    
 E  R974    
 E  R975    
 E  R976    
 E  R977    
 E  R978    
 E  R979    
 E  R980    
 E  R981    
 E  R982    
 E  R983    
 E  R984    
 E  R985    
 E  R986    
 E  R987    
 E  R988    
 E  R989    
 E  R990    
 E  R991    
 E  R992    
 E  R993    
 E  R994    
 E  R995    
 E  R996    
 E  R997    
 E  R998    
 E  R999    
 E  R1000   
 E  R1001   
 G  R1002   
 L  R1003   
 L  R1004   
 G  R1005   
 L  R1006   
 L  R1007   
 E  R1008   
 E  R1009   
 E  R1010   
 E  R1011   
 E  R1012   
 E  R1013   
 E  R1014   
 E  R1015   
 E  R1016   
 E  R1017   
 E  R1018   
 E  R1019   
 E  R1020   
 E  R1021   
 E  R1022   
 E  R1023   
 E  R1024   
 E  R1025   
 E  R1026   
 E  R1027   
 E  R1028   
 E  R1029   
 E  R1030   
 E  R1031   
 E  R1032   
 E  R1033   
 E  R1034   
 E  R1035   
 E  R1036   
 E  R1037   
 E  R1038   
 E  R1039   
 E  R1040   
 E  R1041   
 E  R1042   
 E  R1043   
 E  R1044   
 E  R1045   
 E  R1046   
 E  R1047   
 E  R1048   
 E  R1049   
 E  R1050   
 E  R1051   
 E  R1052   
 E  R1053   
 G  R1054   
 L  R1055   
 L  R1056   
 G  R1057   
 L  R1058   
 L  R1059   
 E  R1060   
 E  R1061   
 E  R1062   
 E  R1063   
 E  R1064   
 E  R1065   
 E  R1066   
 E  R1067   
 E  R1068   
 E  R1069   
 E  R1070   
 E  R1071   
 E  R1072   
 E  R1073   
 E  R1074   
 E  R1075   
 E  R1076   
 E  R1077   
 E  R1078   
 E  R1079   
 E  R1080   
 E  R1081   
 E  R1082   
 E  R1083   
 E  R1084   
 E  R1085   
 E  R1086   
 E  R1087   
 E  R1088   
 E  R1089   
 E  R1090   
 E  R1091   
 E  R1092   
 E  R1093   
 E  R1094   
 E  R1095   
 E  R1096   
 G  R1097   
 L  R1098   
 L  R1099   
 G  R1100   
 L  R1101   
 L  R1102   
 E  R1103   
 E  R1104   
 E  R1105   
 E  R1106   
 E  R1107   
 E  R1108   
 E  R1109   
 E  R1110   
 E  R1111   
 E  R1112   
 E  R1113   
 E  R1114   
 E  R1115   
 E  R1116   
 E  R1117   
 E  R1118   
 E  R1119   
 E  R1120   
 E  R1121   
 E  R1122   
 E  R1123   
 E  R1124   
 E  R1125   
 E  R1126   
 E  R1127   
 E  R1128   
 E  R1129   
 E  R1130   
 E  R1131   
 E  R1132   
 E  R1133   
 E  R1134   
 E  R1135   
 E  R1136   
 E  R1137   
 E  R1138   
 E  R1139   
 G  R1140   
 L  R1141   
 L  R1142   
 G  R1143   
 L  R1144   
 L  R1145   
 E  R1146   
 E  R1147   
 E  R1148   
 E  R1149   
 E  R1150   
 E  R1151   
 E  R1152   
 E  R1153   
 E  R1154   
 E  R1155   
 E  R1156   
 E  R1157   
 E  R1158   
 E  R1159   
 E  R1160   
 E  R1161   
 E  R1162   
 E  R1163   
 E  R1164   
 E  R1165   
 E  R1166   
 E  R1167   
 E  R1168   
 E  R1169   
 E  R1170   
 E  R1171   
 E  R1172   
 E  R1173   
 E  R1174   
 E  R1175   
 E  R1176   
 E  R1177   
 E  R1178   
 E  R1179   
 E  R1180   
 E  R1181   
 E  R1182   
 E  R1183   
 E  R1184   
 E  R1185   
 E  R1186   
 E  R1187   
 E  R1188   
 E  R1189   
 G  R1190   
 L  R1191   
 L  R1192   
 G  R1193   
 L  R1194   
 L  R1195   
 E  R1196   
 E  R1197   
 E  R1198   
 E  R1199   
 E  R1200   
 E  R1201   
 E  R1202   
 E  R1203   
 E  R1204   
 E  R1205   
 E  R1206   
 E  R1207   
 E  R1208   
 E  R1209   
 E  R1210   
 E  R1211   
 E  R1212   
 E  R1213   
 E  R1214   
 E  R1215   
 E  R1216   
 E  R1217   
 E  R1218   
 E  R1219   
 E  R1220   
 E  R1221   
 E  R1222   
 E  R1223   
 E  R1224   
 E  R1225   
 E  R1226   
 E  R1227   
 E  R1228   
 E  R1229   
 E  R1230   
 E  R1231   
 E  R1232   
 E  R1233   
 E  R1234   
 G  R1235   
 L  R1236   
 L  R1237   
 G  R1238   
 L  R1239   
 L  R1240   
 E  R1241   
 E  R1242   
 E  R1243   
 E  R1244   
 E  R1245   
 E  R1246   
 E  R1247   
 E  R1248   
 E  R1249   
 E  R1250   
 E  R1251   
 E  R1252   
 E  R1253   
 E  R1254   
 E  R1255   
 E  R1256   
 E  R1257   
 E  R1258   
 E  R1259   
 E  R1260   
 E  R1261   
 E  R1262   
 E  R1263   
 E  R1264   
 E  R1265   
 E  R1266   
 E  R1267   
 E  R1268   
 E  R1269   
 E  R1270   
 E  R1271   
 E  R1272   
 E  R1273   
 E  R1274   
 E  R1275   
 E  R1276   
 E  R1277   
 G  R1278   
 L  R1279   
 L  R1280   
 G  R1281   
 L  R1282   
 L  R1283   
 E  R1284   
 E  R1285   
 E  R1286   
 E  R1287   
 E  R1288   
 E  R1289   
 E  R1290   
 E  R1291   
 E  R1292   
 E  R1293   
 E  R1294   
 E  R1295   
 E  R1296   
 E  R1297   
 E  R1298   
 E  R1299   
 E  R1300   
 E  R1301   
 E  R1302   
 E  R1303   
 E  R1304   
 E  R1305   
 E  R1306   
 E  R1307   
 E  R1308   
 E  R1309   
 E  R1310   
 E  R1311   
 E  R1312   
 E  R1313   
 E  R1314   
 E  R1315   
 E  R1316   
 E  R1317   
 E  R1318   
 E  R1319   
 E  R1320   
 G  R1321   
 L  R1322   
 L  R1323   
 G  R1324   
 L  R1325   
 L  R1326   
 E  R1327   
 E  R1328   
 E  R1329   
 E  R1330   
 E  R1331   
 E  R1332   
 E  R1333   
 E  R1334   
 E  R1335   
 E  R1336   
 E  R1337   
 E  R1338   
 E  R1339   
 E  R1340   
 E  R1341   
 E  R1342   
 E  R1343   
 E  R1344   
 E  R1345   
 E  R1346   
 E  R1347   
 E  R1348   
 E  R1349   
 E  R1350   
 E  R1351   
 E  R1352   
 E  R1353   
 E  R1354   
 E  R1355   
 E  R1356   
 E  R1357   
 E  R1358   
 E  R1359   
 E  R1360   
 E  R1361   
 E  R1362   
 E  R1363   
 E  R1364   
 E  R1365   
 E  R1366   
 E  R1367   
 E  R1368   
 E  R1369   
 E  R1370   
 G  R1371   
 L  R1372   
 L  R1373   
 G  R1374   
 L  R1375   
 L  R1376   
 E  R1377   
 E  R1378   
 E  R1379   
 E  R1380   
 E  R1381   
 E  R1382   
 E  R1383   
 E  R1384   
 E  R1385   
 E  R1386   
 E  R1387   
 E  R1388   
 E  R1389   
 E  R1390   
 E  R1391   
 E  R1392   
 E  R1393   
 E  R1394   
 E  R1395   
 E  R1396   
 E  R1397   
 E  R1398   
 E  R1399   
 E  R1400   
 E  R1401   
 E  R1402   
 E  R1403   
 E  R1404   
 E  R1405   
 E  R1406   
 E  R1407   
 E  R1408   
 E  R1409   
 E  R1410   
 E  R1411   
 E  R1412   
 E  R1413   
 E  R1414   
 G  R1415   
 L  R1416   
 L  R1417   
 G  R1418   
 L  R1419   
 L  R1420   
 E  R1421   
 E  R1422   
 E  R1423   
 E  R1424   
 E  R1425   
 E  R1426   
 E  R1427   
 E  R1428   
 E  R1429   
 E  R1430   
 E  R1431   
 E  R1432   
 E  R1433   
 E  R1434   
 E  R1435   
 E  R1436   
 E  R1437   
 E  R1438   
 E  R1439   
 E  R1440   
 E  R1441   
 E  R1442   
 E  R1443   
 E  R1444   
 E  R1445   
 E  R1446   
 E  R1447   
 E  R1448   
 E  R1449   
 E  R1450   
 E  R1451   
 E  R1452   
 E  R1453   
 E  R1454   
 E  R1455   
 E  R1456   
 E  R1457   
 E  R1458   
 G  R1459   
 L  R1460   
 L  R1461   
 G  R1462   
 L  R1463   
 L  R1464   
 E  R1465   
 E  R1466   
 E  R1467   
 E  R1468   
 E  R1469   
 E  R1470   
 E  R1471   
 E  R1472   
 E  R1473   
 E  R1474   
 E  R1475   
 E  R1476   
 E  R1477   
 E  R1478   
 E  R1479   
 E  R1480   
 E  R1481   
 E  R1482   
 E  R1483   
 E  R1484   
 E  R1485   
 E  R1486   
 E  R1487   
 E  R1488   
 E  R1489   
 E  R1490   
 E  R1491   
 E  R1492   
 E  R1493   
 E  R1494   
 E  R1495   
 E  R1496   
 E  R1497   
 E  R1498   
 E  R1499   
 E  R1500   
 E  R1501   
 E  R1502   
 G  R1503   
 L  R1504   
 L  R1505   
 G  R1506   
 L  R1507   
 L  R1508   
 E  R1509   
 E  R1510   
 E  R1511   
 E  R1512   
 E  R1513   
 E  R1514   
 E  R1515   
 E  R1516   
 E  R1517   
 E  R1518   
 E  R1519   
 E  R1520   
 E  R1521   
 G  R1522   
 L  R1523   
 L  R1524   
 G  R1525   
 L  R1526   
 L  R1527   
 E  R1528   
 E  R1529   
 E  R1530   
 E  R1531   
 E  R1532   
 E  R1533   
 E  R1534   
 E  R1535   
 E  R1536   
 E  R1537   
 E  R1538   
 E  R1539   
 E  R1540   
 G  R1541   
 L  R1542   
 L  R1543   
 G  R1544   
 L  R1545   
 L  R1546   
 E  R1547   
 E  R1548   
 E  R1549   
 E  R1550   
 E  R1551   
 E  R1552   
 E  R1553   
 E  R1554   
 E  R1555   
 E  R1556   
 E  R1557   
 E  R1558   
 E  R1559   
 G  R1560   
 L  R1561   
 L  R1562   
 G  R1563   
 L  R1564   
 L  R1565   
 E  R1566   
 E  R1567   
 E  R1568   
 E  R1569   
 E  R1570   
 E  R1571   
 E  R1572   
 E  R1573   
 E  R1574   
 E  R1575   
 E  R1576   
 E  R1577   
 E  pool_cover_C81_order_d
 E  pool_cover_C81_order_p
 E  pool_cover_C90_order_d
 E  pool_cover_C90_order_p
 E  pool_cover_C97_order_d
 E  pool_cover_C97_order_p
 E  pool_cover_C51_order_d
 E  pool_cover_C51_order_p
 E  pool_cover_C0_order_d
 E  pool_cover_C0_order_p
 E  pool_cover_C39_order_d
 E  pool_cover_C39_order_p
 E  pool_cover_C52_order_d
 E  pool_cover_C52_order_p
 E  pool_cover_C85_order_d
 E  pool_cover_C85_order_p
 E  pool_cover_C75_order_d
 E  pool_cover_C75_order_p
 E  pool_cover_C21_order_d
 E  pool_cover_C21_order_p
 E  pool_cover_C88_order_d
 E  pool_cover_C88_order_p
 E  pool_cover_C76_order_d
 E  pool_cover_C76_order_p
 E  pool_cover_C27_order_d
 E  pool_cover_C27_order_p
 E  pool_cover_C47_order_d
 E  pool_cover_C47_order_p
 E  pool_cover_C25_order_d
 E  pool_cover_C25_order_p
 E  pool_cover_C46_order_d
 E  pool_cover_C46_order_p
 E  pool_cover_C29_order_d
 E  pool_cover_C29_order_p
 E  pool_cover_C6_order_d
 E  pool_cover_C6_order_p
 E  pool_cover_C34_order_d
 E  pool_cover_C34_order_p
 E  pool_cover_C95_order_d
 E  pool_cover_C95_order_p
 E  R1618   
 E  R1619   
 E  R1620   
 E  R1621   
 E  R1622   
 E  R1623   
 E  R1624   
 E  R1625   
 E  R1626   
 E  R1627   
 E  R1628   
 E  R1629   
 E  R1630   
 E  R1631   
 E  R1632   
 E  R1633   
 E  R1634   
 E  R1635   
 E  R1636   
 E  R1637   
 E  R1638   
 E  R1639   
 E  R1640   
 E  R1641   
 E  R1642   
 E  R1643   
 E  R1644   
 E  R1645   
 E  R1646   
 E  R1647   
 E  R1648   
 E  R1649   
 E  R1650   
 E  R1651   
 E  R1652   
 E  R1653   
 E  R1654   
 E  R1655   
 E  R1656   
 E  R1657   
 E  R1658   
 E  R1659   
 E  R1660   
 E  R1661   
 E  R1662   
 E  R1663   
 E  R1664   
 E  R1665   
 E  R1666   
 E  R1667   
 E  R1668   
 E  R1669   
 E  R1670   
 E  R1671   
 E  R1672   
 E  R1673   
 E  R1674   
 E  R1675   
 E  R1676   
 E  R1677   
 E  R1678   
 E  R1679   
 E  R1680   
 E  R1681   
 E  R1682   
 E  R1683   
 E  R1684   
 E  R1685   
 E  R1686   
 E  R1687   
 E  R1688   
 E  R1689   
 E  R1690   
 E  R1691   
 E  R1692   
 E  R1693   
 E  R1694   
 E  R1695   
 E  R1696   
 E  R1697   
 E  R1698   
 E  R1699   
 E  R1700   
 E  R1701   
 E  R1702   
 E  R1703   
 E  R1704   
 E  R1705   
 E  R1706   
 E  R1707   
 E  R1708   
 E  R1709   
 E  R1710   
 E  R1711   
 E  R1712   
 E  R1713   
 E  R1714   
 E  R1715   
 E  R1716   
 E  R1717   
 E  R1718   
 E  R1719   
 E  R1720   
 E  R1721   
 E  R1722   
 E  R1723   
 E  R1724   
 E  R1725   
 E  R1726   
 E  R1727   
 E  R1728   
 E  R1729   
 E  R1730   
 E  R1731   
 E  R1732   
 E  R1733   
 E  R1734   
 E  R1735   
 E  R1736   
 E  R1737   
 E  R1738   
 E  R1739   
 E  R1740   
 E  R1741   
 E  R1742   
 E  R1743   
 E  R1744   
 E  R1745   
 E  R1746   
 E  R1747   
 E  R1748   
 E  R1749   
 E  R1750   
 E  R1751   
 E  R1752   
 E  R1753   
 E  R1754   
 E  R1755   
 E  R1756   
 E  R1757   
 E  R1758   
 E  R1759   
 E  R1760   
 E  R1761   
 E  R1762   
 E  R1763   
 E  R1764   
 E  R1765   
 E  R1766   
 G  R1767   
 G  R1768   
 G  R1769   
 G  R1770   
 G  R1771   
 G  R1772   
 G  R1773   
 G  R1774   
 G  R1775   
 G  R1776   
 G  R1777   
 G  R1778   
 G  R1779   
 G  R1780   
 G  R1781   
 G  R1782   
 G  R1783   
 G  R1784   
 G  R1785   
 G  R1786   
 G  R1787   
 G  R1788   
 G  R1789   
 G  R1790   
 G  R1791   
 G  R1792   
 G  R1793   
 G  R1794   
 G  R1795   
 G  R1796   
 G  R1797   
 G  R1798   
 G  R1799   
 G  R1800   
 G  R1801   
 G  R1802   
 G  R1803   
 G  R1804   
 G  R1805   
 G  R1806   
 G  R1807   
 G  R1808   
 G  R1809   
 G  R1810   
 G  R1811   
 G  R1812   
 G  R1813   
 G  R1814   
 G  R1815   
 G  R1816   
 G  R1817   
 G  R1818   
 G  GC0     
 L  GC1     
 G  GC2     
 L  GC3     
 G  GC4     
 L  GC5     
 G  GC6     
 L  GC7     
 G  GC8     
 L  GC9     
 G  GC10    
 L  GC11    
 G  GC12    
 L  GC13    
 G  GC14    
 L  GC15    
 G  GC16    
 L  GC17    
 G  GC18    
 L  GC19    
 G  GC20    
 L  GC21    
 G  GC22    
 L  GC23    
 G  GC24    
 L  GC25    
 G  GC26    
 L  GC27    
 G  GC28    
 L  GC29    
 G  GC30    
 L  GC31    
 G  GC32    
 L  GC33    
 G  GC34    
 L  GC35    
 G  GC36    
 L  GC37    
 G  GC38    
 L  GC39    
 G  GC40    
 L  GC41    
 G  GC42    
 L  GC43    
 G  GC44    
 L  GC45    
 G  GC46    
 L  GC47    
 G  GC48    
 L  GC49    
 G  GC50    
 L  GC51    
 G  GC52    
 L  GC53    
 G  GC54    
 L  GC55    
 G  GC56    
 L  GC57    
 G  GC58    
 L  GC59    
 G  GC60    
 L  GC61    
 G  GC62    
 L  GC63    
 G  GC64    
 L  GC65    
 G  GC66    
 L  GC67    
 G  GC68    
 L  GC69    
 G  GC70    
 L  GC71    
 G  GC72    
 L  GC73    
 G  GC74    
 L  GC75    
 G  GC76    
 L  GC77    
 G  GC78    
 L  GC79    
 G  GC80    
 L  GC81    
 G  GC82    
 L  GC83    
 G  GC84    
 L  GC85    
 G  GC86    
 L  GC87    
 G  GC88    
 L  GC89    
 G  GC90    
 L  GC91    
 G  GC92    
 L  GC93    
 G  GC94    
 L  GC95    
 G  GC96    
 L  GC97    
 G  GC98    
 L  GC99    
 G  GC100   
 L  GC101   
 G  GC102   
 L  GC103   
 G  GC104   
 L  GC105   
 G  GC106   
 L  GC107   
 G  GC108   
 L  GC109   
 G  GC110   
 L  GC111   
 G  GC112   
 L  GC113   
 G  GC114   
 L  GC115   
 G  GC116   
 L  GC117   
 G  GC118   
 L  GC119   
 G  GC120   
 G  GC121   
 G  GC122   
 G  GC123   
 G  GC124   
 G  GC125   
 G  GC126   
 G  GC127   
 G  GC128   
 G  GC129   
 G  GC130   
 G  GC131   
 G  GC132   
 G  GC133   
 G  GC134   
 G  GC135   
 G  GC136   
 G  GC137   
 G  GC138   
 G  GC139   
 G  GC140   
 G  GC141   
 G  GC142   
 G  GC143   
 G  GC144   
 G  GC145   
 G  GC146   
 G  GC147   
 G  GC148   
 G  GC149   
 G  GC150   
 G  GC151   
 G  GC152   
 G  GC153   
 G  GC154   
 G  GC155   
 G  GC156   
 G  GC157   
 G  GC158   
 G  GC159   
 G  GC160   
 G  GC161   
 G  GC162   
 G  GC163   
 G  GC164   
 G  GC165   
 G  GC166   
 G  GC167   
 G  GC168   
 G  GC169   
 G  GC170   
 G  GC171   
 G  GC172   
 G  GC173   
 G  GC174   
 G  GC175   
 G  GC176   
 G  GC177   
 G  GC178   
 G  GC179   
 G  GC180   
 G  GC181   
 G  GC182   
 G  GC183   
 G  GC184   
 G  GC185   
 G  GC186   
 G  GC187   
 G  GC188   
 G  GC189   
 G  GC190   
 G  GC191   
 G  GC192   
 G  GC193   
 G  GC194   
 G  GC195   
 G  GC196   
 G  GC197   
 G  GC198   
 G  GC199   
 E  GC200   
 E  GC201   
 E  GC202   
 E  GC203   
 E  GC204   
 E  GC205   
 E  GC206   
 E  GC207   
 E  GC208   
 E  GC209   
 G  GC210   
 G  GC211   
 G  GC212   
 G  GC213   
 G  GC214   
 G  GC215   
 G  GC216   
 G  GC217   
 G  GC218   
 G  GC219   
 G  GC220   
 G  GC221   
 G  GC222   
 G  GC223   
 G  GC224   
 G  GC225   
 G  GC226   
 G  GC227   
 G  GC228   
 G  GC229   
 G  GC230   
 G  GC231   
 G  GC232   
 G  GC233   
 G  GC234   
 G  GC235   
 G  GC236   
 G  GC237   
 G  GC238   
 G  GC239   
 G  GC240   
 G  GC241   
 G  GC242   
 G  GC243   
 G  GC244   
 G  GC245   
 G  GC246   
 G  GC247   
 G  GC248   
 G  GC249   
 G  GC250   
 G  GC251   
 G  GC252   
 G  GC253   
 G  GC254   
 G  GC255   
 G  GC256   
 G  GC257   
 G  GC258   
 G  GC259   
 G  GC260   
 G  GC261   
 G  GC262   
 E  GC263   
 E  GC264   
 E  GC265   
 E  GC266   
 E  GC267   
 E  GC268   
 E  GC269   
 E  GC270   
 G  GC271   
 G  GC272   
 G  GC273   
 G  GC274   
 G  GC275   
 G  GC276   
 G  GC277   
 G  GC278   
 G  GC279   
 G  GC280   
 G  GC281   
 G  GC282   
 G  GC283   
 G  GC284   
 G  GC285   
 G  GC286   
 G  GC287   
 G  GC288   
 G  GC289   
 G  GC290   
 G  GC291   
 G  GC292   
 G  GC293   
 G  GC294   
 G  GC295   
 G  GC296   
 G  GC297   
 G  GC298   
 G  GC299   
 G  GC300   
 G  GC301   
 G  GC302   
 G  GC303   
 G  GC304   
 G  GC305   
 G  GC306   
 G  GC307   
 G  GC308   
 G  GC309   
 G  GC310   
 G  GC311   
 G  GC312   
 G  GC313   
 G  GC314   
 G  GC315   
 G  GC316   
 G  GC317   
 G  GC318   
 G  GC319   
 G  GC320   
 G  GC321   
 G  GC322   
 G  GC323   
 G  GC324   
 G  GC325   
 G  GC326   
 G  GC327   
 G  GC328   
 G  GC329   
 E  GC330   
 E  GC331   
 E  GC332   
 E  GC333   
 E  GC334   
 E  GC335   
 E  GC336   
 E  GC337   
 G  GC338   
 G  GC339   
 G  GC340   
 G  GC341   
 G  GC342   
 G  GC343   
 G  GC344   
 G  GC345   
 G  GC346   
 G  GC347   
 G  GC348   
 G  GC349   
 G  GC350   
 G  GC351   
 G  GC352   
 G  GC353   
 G  GC354   
 G  GC355   
 G  GC356   
 G  GC357   
 G  GC358   
 G  GC359   
 G  GC360   
 G  GC361   
 G  GC362   
 G  GC363   
 G  GC364   
 G  GC365   
 G  GC366   
 G  GC367   
 G  GC368   
 G  GC369   
 G  GC370   
 G  GC371   
 G  GC372   
 G  GC373   
 G  GC374   
 G  GC375   
 G  GC376   
 G  GC377   
 G  GC378   
 G  GC379   
 G  GC380   
 G  GC381   
 G  GC382   
 G  GC383   
 G  GC384   
 G  GC385   
 G  GC386   
 E  GC387   
 E  GC388   
 E  GC389   
 E  GC390   
 E  GC391   
 E  GC392   
 E  GC393   
 G  GC394   
 G  GC395   
 G  GC396   
 G  GC397   
 G  GC398   
 G  GC399   
 G  GC400   
 G  GC401   
 G  GC402   
 G  GC403   
 G  GC404   
 G  GC405   
 G  GC406   
 G  GC407   
 G  GC408   
 G  GC409   
 G  GC410   
 G  GC411   
 G  GC412   
 G  GC413   
 G  GC414   
 G  GC415   
 G  GC416   
 G  GC417   
 G  GC418   
 G  GC419   
 G  GC420   
 G  GC421   
 G  GC422   
 G  GC423   
 G  GC424   
 G  GC425   
 G  GC426   
 G  GC427   
 G  GC428   
 G  GC429   
 G  GC430   
 G  GC431   
 G  GC432   
 G  GC433   
 G  GC434   
 G  GC435   
 G  GC436   
 G  GC437   
 G  GC438   
 G  GC439   
 G  GC440   
 G  GC441   
 G  GC442   
 G  GC443   
 G  GC444   
 G  GC445   
 G  GC446   
 G  GC447   
 G  GC448   
 G  GC449   
 G  GC450   
 G  GC451   
 G  GC452   
 G  GC453   
 G  GC454   
 G  GC455   
 G  GC456   
 G  GC457   
 G  GC458   
 G  GC459   
 G  GC460   
 G  GC461   
 G  GC462   
 G  GC463   
 G  GC464   
 G  GC465   
 G  GC466   
 G  GC467   
 G  GC468   
 G  GC469   
 G  GC470   
 G  GC471   
 G  GC472   
 G  GC473   
 G  GC474   
 G  GC475   
 G  GC476   
 E  GC477   
 E  GC478   
 E  GC479   
 E  GC480   
 E  GC481   
 E  GC482   
 E  GC483   
 E  GC484   
 E  GC485   
 E  GC486   
 G  GC487   
 G  GC488   
 G  GC489   
 G  GC490   
 G  GC491   
 G  GC492   
 G  GC493   
 G  GC494   
 G  GC495   
 G  GC496   
 G  GC497   
 G  GC498   
 G  GC499   
 G  GC500   
 G  GC501   
 G  GC502   
 G  GC503   
 G  GC504   
 G  GC505   
 G  GC506   
 G  GC507   
 G  GC508   
 G  GC509   
 G  GC510   
 G  GC511   
 G  GC512   
 G  GC513   
 G  GC514   
 G  GC515   
 G  GC516   
 G  GC517   
 G  GC518   
 G  GC519   
 G  GC520   
 G  GC521   
 G  GC522   
 G  GC523   
 G  GC524   
 G  GC525   
 G  GC526   
 G  GC527   
 G  GC528   
 G  GC529   
 G  GC530   
 G  GC531   
 G  GC532   
 G  GC533   
 G  GC534   
 G  GC535   
 G  GC536   
 G  GC537   
 G  GC538   
 G  GC539   
 G  GC540   
 G  GC541   
 G  GC542   
 G  GC543   
 G  GC544   
 G  GC545   
 G  GC546   
 G  GC547   
 G  GC548   
 G  GC549   
 G  GC550   
 G  GC551   
 G  GC552   
 G  GC553   
 E  GC554   
 E  GC555   
 E  GC556   
 E  GC557   
 E  GC558   
 E  GC559   
 E  GC560   
 E  GC561   
 E  GC562   
 E  GC563   
 G  GC564   
 G  GC565   
 G  GC566   
 G  GC567   
 G  GC568   
 G  GC569   
 G  GC570   
 G  GC571   
 G  GC572   
 G  GC573   
 G  GC574   
 G  GC575   
 G  GC576   
 G  GC577   
 G  GC578   
 G  GC579   
 G  GC580   
 G  GC581   
 G  GC582   
 G  GC583   
 G  GC584   
 G  GC585   
 G  GC586   
 G  GC587   
 G  GC588   
 G  GC589   
 G  GC590   
 G  GC591   
 G  GC592   
 G  GC593   
 G  GC594   
 G  GC595   
 G  GC596   
 G  GC597   
 G  GC598   
 G  GC599   
 G  GC600   
 G  GC601   
 G  GC602   
 G  GC603   
 G  GC604   
 G  GC605   
 G  GC606   
 G  GC607   
 G  GC608   
 G  GC609   
 G  GC610   
 G  GC611   
 G  GC612   
 G  GC613   
 G  GC614   
 G  GC615   
 G  GC616   
 E  GC617   
 E  GC618   
 E  GC619   
 E  GC620   
 E  GC621   
 E  GC622   
 E  GC623   
 E  GC624   
 G  GC625   
 G  GC626   
 G  GC627   
 G  GC628   
 G  GC629   
 G  GC630   
 G  GC631   
 G  GC632   
 G  GC633   
 G  GC634   
 G  GC635   
 G  GC636   
 G  GC637   
 G  GC638   
 G  GC639   
 G  GC640   
 G  GC641   
 G  GC642   
 G  GC643   
 G  GC644   
 G  GC645   
 G  GC646   
 G  GC647   
 G  GC648   
 G  GC649   
 G  GC650   
 G  GC651   
 G  GC652   
 G  GC653   
 G  GC654   
 G  GC655   
 G  GC656   
 G  GC657   
 G  GC658   
 G  GC659   
 G  GC660   
 G  GC661   
 G  GC662   
 G  GC663   
 G  GC664   
 G  GC665   
 G  GC666   
 G  GC667   
 G  GC668   
 G  GC669   
 G  GC670   
 G  GC671   
 G  GC672   
 G  GC673   
 G  GC674   
 G  GC675   
 G  GC676   
 G  GC677   
 G  GC678   
 G  GC679   
 E  GC680   
 E  GC681   
 E  GC682   
 E  GC683   
 E  GC684   
 E  GC685   
 E  GC686   
 G  GC687   
 G  GC688   
 G  GC689   
 G  GC690   
 G  GC691   
 G  GC692   
 G  GC693   
 G  GC694   
 G  GC695   
 G  GC696   
 G  GC697   
 G  GC698   
 G  GC699   
 G  GC700   
 G  GC701   
 G  GC702   
 G  GC703   
 G  GC704   
 G  GC705   
 G  GC706   
 G  GC707   
 G  GC708   
 G  GC709   
 G  GC710   
 G  GC711   
 G  GC712   
 G  GC713   
 G  GC714   
 G  GC715   
 G  GC716   
 G  GC717   
 G  GC718   
 G  GC719   
 G  GC720   
 G  GC721   
 G  GC722   
 G  GC723   
 G  GC724   
 G  GC725   
 G  GC726   
 G  GC727   
 G  GC728   
 G  GC729   
 G  GC730   
 G  GC731   
 G  GC732   
 G  GC733   
 G  GC734   
 G  GC735   
 G  GC736   
 G  GC737   
 G  GC738   
 G  GC739   
 G  GC740   
 G  GC741   
 G  GC742   
 G  GC743   
 G  GC744   
 G  GC745   
 G  GC746   
 G  GC747   
 G  GC748   
 G  GC749   
 G  GC750   
 G  GC751   
 G  GC752   
 G  GC753   
 E  GC754   
 E  GC755   
 E  GC756   
 E  GC757   
 E  GC758   
 E  GC759   
 E  GC760   
 E  GC761   
 G  GC762   
 G  GC763   
 G  GC764   
 G  GC765   
 G  GC766   
 G  GC767   
 G  GC768   
 G  GC769   
 G  GC770   
 G  GC771   
 G  GC772   
 G  GC773   
 G  GC774   
 G  GC775   
 G  GC776   
 G  GC777   
 G  GC778   
 G  GC779   
 G  GC780   
 G  GC781   
 G  GC782   
 G  GC783   
 G  GC784   
 G  GC785   
 G  GC786   
 G  GC787   
 G  GC788   
 G  GC789   
 G  GC790   
 G  GC791   
 G  GC792   
 G  GC793   
 G  GC794   
 G  GC795   
 G  GC796   
 G  GC797   
 G  GC798   
 G  GC799   
 G  GC800   
 G  GC801   
 G  GC802   
 G  GC803   
 G  GC804   
 G  GC805   
 G  GC806   
 G  GC807   
 G  GC808   
 G  GC809   
 G  GC810   
 G  GC811   
 G  GC812   
 G  GC813   
 G  GC814   
 G  GC815   
 G  GC816   
 G  GC817   
 G  GC818   
 E  GC819   
 E  GC820   
 E  GC821   
 E  GC822   
 E  GC823   
 E  GC824   
 E  GC825   
 E  GC826   
 G  GC827   
 G  GC828   
 G  GC829   
 G  GC830   
 G  GC831   
 G  GC832   
 G  GC833   
 G  GC834   
 G  GC835   
 G  GC836   
 G  GC837   
 G  GC838   
 G  GC839   
 G  GC840   
 G  GC841   
 G  GC842   
 G  GC843   
 G  GC844   
 G  GC845   
 G  GC846   
 G  GC847   
 G  GC848   
 G  GC849   
 G  GC850   
 G  GC851   
 G  GC852   
 G  GC853   
 G  GC854   
 G  GC855   
 G  GC856   
 G  GC857   
 G  GC858   
 G  GC859   
 G  GC860   
 G  GC861   
 G  GC862   
 G  GC863   
 G  GC864   
 G  GC865   
 G  GC866   
 G  GC867   
 G  GC868   
 G  GC869   
 G  GC870   
 G  GC871   
 G  GC872   
 G  GC873   
 G  GC874   
 G  GC875   
 G  GC876   
 G  GC877   
 G  GC878   
 G  GC879   
 E  GC880   
 E  GC881   
 E  GC882   
 E  GC883   
 E  GC884   
 E  GC885   
 E  GC886   
 E  GC887   
 G  GC888   
 G  GC889   
 G  GC890   
 G  GC891   
 G  GC892   
 G  GC893   
 G  GC894   
 G  GC895   
 G  GC896   
 G  GC897   
 G  GC898   
 G  GC899   
 G  GC900   
 G  GC901   
 G  GC902   
 G  GC903   
 G  GC904   
 G  GC905   
 G  GC906   
 G  GC907   
 G  GC908   
 G  GC909   
 G  GC910   
 G  GC911   
 G  GC912   
 G  GC913   
 G  GC914   
 G  GC915   
 G  GC916   
 G  GC917   
 G  GC918   
 G  GC919   
 G  GC920   
 G  GC921   
 G  GC922   
 G  GC923   
 G  GC924   
 G  GC925   
 G  GC926   
 G  GC927   
 G  GC928   
 G  GC929   
 G  GC930   
 G  GC931   
 G  GC932   
 G  GC933   
 G  GC934   
 G  GC935   
 G  GC936   
 G  GC937   
 G  GC938   
 G  GC939   
 G  GC940   
 E  GC941   
 E  GC942   
 E  GC943   
 E  GC944   
 E  GC945   
 E  GC946   
 E  GC947   
 E  GC948   
 G  GC949   
 G  GC950   
 G  GC951   
 G  GC952   
 G  GC953   
 G  GC954   
 G  GC955   
 G  GC956   
 G  GC957   
 G  GC958   
 G  GC959   
 G  GC960   
 G  GC961   
 G  GC962   
 G  GC963   
 G  GC964   
 G  GC965   
 G  GC966   
 G  GC967   
 G  GC968   
 G  GC969   
 G  GC970   
 G  GC971   
 G  GC972   
 G  GC973   
 G  GC974   
 G  GC975   
 G  GC976   
 G  GC977   
 G  GC978   
 G  GC979   
 G  GC980   
 G  GC981   
 G  GC982   
 G  GC983   
 G  GC984   
 G  GC985   
 G  GC986   
 G  GC987   
 G  GC988   
 G  GC989   
 G  GC990   
 G  GC991   
 G  GC992   
 G  GC993   
 G  GC994   
 G  GC995   
 G  GC996   
 G  GC997   
 G  GC998   
 G  GC999   
 G  GC1000  
 G  GC1001  
 G  GC1002  
 G  GC1003  
 G  GC1004  
 G  GC1005  
 G  GC1006  
 G  GC1007  
 G  GC1008  
 G  GC1009  
 G  GC1010  
 G  GC1011  
 G  GC1012  
 G  GC1013  
 G  GC1014  
 G  GC1015  
 E  GC1016  
 E  GC1017  
 E  GC1018  
 E  GC1019  
 E  GC1020  
 E  GC1021  
 E  GC1022  
 E  GC1023  
 G  GC1024  
 G  GC1025  
 G  GC1026  
 G  GC1027  
 G  GC1028  
 G  GC1029  
 G  GC1030  
 G  GC1031  
 G  GC1032  
 G  GC1033  
 G  GC1034  
 G  GC1035  
 G  GC1036  
 G  GC1037  
 G  GC1038  
 G  GC1039  
 G  GC1040  
 G  GC1041  
 G  GC1042  
 G  GC1043  
 G  GC1044  
 G  GC1045  
 G  GC1046  
 G  GC1047  
 G  GC1048  
 G  GC1049  
 G  GC1050  
 G  GC1051  
 G  GC1052  
 G  GC1053  
 G  GC1054  
 G  GC1055  
 G  GC1056  
 G  GC1057  
 G  GC1058  
 G  GC1059  
 G  GC1060  
 G  GC1061  
 G  GC1062  
 G  GC1063  
 G  GC1064  
 G  GC1065  
 G  GC1066  
 G  GC1067  
 G  GC1068  
 G  GC1069  
 G  GC1070  
 G  GC1071  
 G  GC1072  
 G  GC1073  
 G  GC1074  
 G  GC1075  
 G  GC1076  
 G  GC1077  
 G  GC1078  
 E  GC1079  
 E  GC1080  
 E  GC1081  
 E  GC1082  
 E  GC1083  
 E  GC1084  
 E  GC1085  
 E  GC1086  
 G  GC1087  
 G  GC1088  
 G  GC1089  
 G  GC1090  
 G  GC1091  
 G  GC1092  
 G  GC1093  
 G  GC1094  
 G  GC1095  
 G  GC1096  
 G  GC1097  
 G  GC1098  
 G  GC1099  
 G  GC1100  
 G  GC1101  
 G  GC1102  
 G  GC1103  
 G  GC1104  
 G  GC1105  
 G  GC1106  
 G  GC1107  
 G  GC1108  
 G  GC1109  
 G  GC1110  
 G  GC1111  
 G  GC1112  
 G  GC1113  
 G  GC1114  
 G  GC1115  
 G  GC1116  
 G  GC1117  
 G  GC1118  
 G  GC1119  
 G  GC1120  
 G  GC1121  
 G  GC1122  
 G  GC1123  
 G  GC1124  
 G  GC1125  
 G  GC1126  
 G  GC1127  
 G  GC1128  
 G  GC1129  
 G  GC1130  
 G  GC1131  
 G  GC1132  
 G  GC1133  
 G  GC1134  
 G  GC1135  
 G  GC1136  
 G  GC1137  
 G  GC1138  
 G  GC1139  
 G  GC1140  
 G  GC1141  
 E  GC1142  
 E  GC1143  
 E  GC1144  
 E  GC1145  
 E  GC1146  
 E  GC1147  
 E  GC1148  
 E  GC1149  
 G  GC1150  
 G  GC1151  
 G  GC1152  
 G  GC1153  
 G  GC1154  
 G  GC1155  
 G  GC1156  
 G  GC1157  
 G  GC1158  
 G  GC1159  
 G  GC1160  
 G  GC1161  
 G  GC1162  
 G  GC1163  
 G  GC1164  
 G  GC1165  
 G  GC1166  
 G  GC1167  
 G  GC1168  
 G  GC1169  
 G  GC1170  
 G  GC1171  
 G  GC1172  
 G  GC1173  
 G  GC1174  
 G  GC1175  
 G  GC1176  
 G  GC1177  
 G  GC1178  
 G  GC1179  
 G  GC1180  
 G  GC1181  
 G  GC1182  
 G  GC1183  
 G  GC1184  
 G  GC1185  
 G  GC1186  
 G  GC1187  
 G  GC1188  
 G  GC1189  
 G  GC1190  
 G  GC1191  
 G  GC1192  
 G  GC1193  
 G  GC1194  
 G  GC1195  
 G  GC1196  
 G  GC1197  
 G  GC1198  
 G  GC1199  
 G  GC1200  
 G  GC1201  
 G  GC1202  
 G  GC1203  
 G  GC1204  
 E  GC1205  
 E  GC1206  
 E  GC1207  
 E  GC1208  
 E  GC1209  
 E  GC1210  
 E  GC1211  
 E  GC1212  
 G  GC1213  
 G  GC1214  
 G  GC1215  
 G  GC1216  
 G  GC1217  
 G  GC1218  
 G  GC1219  
 G  GC1220  
 G  GC1221  
 G  GC1222  
 G  GC1223  
 G  GC1224  
 G  GC1225  
 G  GC1226  
 G  GC1227  
 G  GC1228  
 G  GC1229  
 G  GC1230  
 G  GC1231  
 E  GC1232  
 E  GC1233  
 G  GC1234  
 G  GC1235  
 G  GC1236  
 G  GC1237  
 G  GC1238  
 G  GC1239  
 G  GC1240  
 G  GC1241  
 G  GC1242  
 G  GC1243  
 G  GC1244  
 G  GC1245  
 G  GC1246  
 G  GC1247  
 G  GC1248  
 G  GC1249  
 G  GC1250  
 G  GC1251  
 E  GC1252  
 E  GC1253  
 G  GC1254  
 G  GC1255  
 G  GC1256  
 G  GC1257  
 G  GC1258  
 G  GC1259  
 G  GC1260  
 G  GC1261  
 G  GC1262  
 G  GC1263  
 G  GC1264  
 G  GC1265  
 G  GC1266  
 G  GC1267  
 G  GC1268  
 G  GC1269  
 G  GC1270  
 G  GC1271  
 E  GC1272  
 E  GC1273  
 G  GC1274  
 G  GC1275  
 G  GC1276  
 G  GC1277  
 G  GC1278  
 G  GC1279  
 G  GC1280  
 G  GC1281  
 G  GC1282  
 G  GC1283  
 G  GC1284  
 G  GC1285  
 G  GC1286  
 G  GC1287  
 G  GC1288  
 G  GC1289  
 G  GC1290  
 G  GC1291  
 E  GC1292  
 E  GC1293  
 G  GC1294  
 G  GC1295  
 G  GC1296  
 G  GC1297  
 G  GC1298  
 G  GC1299  
 G  GC1300  
 G  GC1301  
 G  GC1302  
 G  GC1303  
 G  GC1304  
 G  GC1305  
 G  GC1306  
 G  GC1307  
 G  GC1308  
 G  GC1309  
 G  GC1310  
 G  GC1311  
 G  GC1312  
 G  GC1313  
 G  GC1314  
 G  GC1315  
 G  GC1316  
 G  GC1317  
 G  GC1318  
 G  GC1319  
 G  GC1320  
 G  GC1321  
 G  GC1322  
 G  GC1323  
 G  GC1324  
 G  GC1325  
 G  GC1326  
 G  GC1327  
 G  GC1328  
 G  GC1329  
 G  GC1330  
 G  GC1331  
 G  GC1332  
 G  GC1333  
 G  GC1334  
 G  GC1335  
 G  GC1336  
 G  GC1337  
 G  GC1338  
 G  GC1339  
 G  GC1340  
 G  GC1341  
 G  GC1342  
 G  GC1343  
 G  GC1344  
 G  GC1345  
 G  GC1346  
 G  GC1347  
 G  GC1348  
 G  GC1349  
 G  GC1350  
 G  GC1351  
 G  GC1352  
 G  GC1353  
 G  GC1354  
 G  GC1355  
 G  GC1356  
 G  GC1357  
 G  GC1358  
 G  GC1359  
 G  GC1360  
 G  GC1361  
 G  GC1362  
 G  GC1363  
 G  GC1364  
 G  GC1365  
 G  GC1366  
 G  GC1367  
 G  GC1368  
 G  GC1369  
 G  GC1370  
 G  GC1371  
 G  GC1372  
 G  GC1373  
 G  GC1374  
 G  GC1375  
 G  GC1376  
 G  GC1377  
 G  GC1378  
 G  GC1379  
 G  GC1380  
 G  GC1381  
 G  GC1382  
 G  GC1383  
 G  GC1384  
 G  GC1385  
 G  GC1386  
 G  GC1387  
 G  GC1388  
 G  GC1389  
 G  GC1390  
 G  GC1391  
 G  GC1392  
 G  GC1393  
 G  GC1394  
 G  GC1395  
 G  GC1396  
 G  GC1397  
 G  GC1398  
 G  GC1399  
 G  GC1400  
 G  GC1401  
 G  GC1402  
 G  GC1403  
 G  GC1404  
 G  GC1405  
 G  GC1406  
 G  GC1407  
 G  GC1408  
 G  GC1409  
 G  GC1410  
 G  GC1411  
 G  GC1412  
 G  GC1413  
 G  GC1414  
 G  GC1415  
 G  GC1416  
 G  GC1417  
 G  GC1418  
 G  GC1419  
 G  GC1420  
 G  GC1421  
 G  GC1422  
 G  GC1423  
 G  GC1424  
 G  GC1425  
 G  GC1426  
 G  GC1427  
 G  GC1428  
 G  GC1429  
 G  GC1430  
 G  GC1431  
 G  GC1432  
 G  GC1433  
 G  GC1434  
 G  GC1435  
 G  GC1436  
 G  GC1437  
 G  GC1438  
 G  GC1439  
 G  GC1440  
 G  GC1441  
 G  GC1442  
 G  GC1443  
 G  GC1444  
 G  GC1445  
 G  GC1446  
 G  GC1447  
 G  GC1448  
 G  GC1449  
 G  GC1450  
 G  GC1451  
 G  GC1452  
 G  GC1453  
 G  GC1454  
 G  GC1455  
 G  GC1456  
 G  GC1457  
 G  GC1458  
 G  GC1459  
 G  GC1460  
 G  GC1461  
 G  GC1462  
 G  GC1463  
 G  GC1464  
 G  GC1465  
 G  GC1466  
 G  GC1467  
 G  GC1468  
 G  GC1469  
 G  GC1470  
 G  GC1471  
 G  GC1472  
 G  GC1473  
 G  GC1474  
 G  GC1475  
 G  GC1476  
 G  GC1477  
 G  GC1478  
 G  GC1479  
 G  GC1480  
 G  GC1481  
 G  GC1482  
 G  GC1483  
 G  GC1484  
 G  GC1485  
 G  GC1486  
 G  GC1487  
 G  GC1488  
 G  GC1489  
 G  GC1490  
 G  GC1491  
 G  GC1492  
 G  GC1493  
 G  GC1494  
 G  GC1495  
 G  GC1496  
 G  GC1497  
 G  GC1498  
 G  GC1499  
 G  GC1500  
 G  GC1501  
 G  GC1502  
 G  GC1503  
 G  GC1504  
 G  GC1505  
 G  GC1506  
 G  GC1507  
 G  GC1508  
 G  GC1509  
 G  GC1510  
 G  GC1511  
 G  GC1512  
 G  GC1513  
 G  GC1514  
 G  GC1515  
 G  GC1516  
 G  GC1517  
 G  GC1518  
 G  GC1519  
 G  GC1520  
 G  GC1521  
 G  GC1522  
 G  GC1523  
 G  GC1524  
 G  GC1525  
 G  GC1526  
 G  GC1527  
 G  GC1528  
 G  GC1529  
 G  GC1530  
 G  GC1531  
 G  GC1532  
 G  GC1533  
 G  GC1534  
 G  GC1535  
 G  GC1536  
 G  GC1537  
 G  GC1538  
 G  GC1539  
 G  GC1540  
 G  GC1541  
 G  GC1542  
 G  GC1543  
 G  GC1544  
 G  GC1545  
 G  GC1546  
 G  GC1547  
 G  GC1548  
 G  GC1549  
 G  GC1550  
 G  GC1551  
 G  GC1552  
 G  GC1553  
 G  GC1554  
 G  GC1555  
 G  GC1556  
 G  GC1557  
 G  GC1558  
 G  GC1559  
 G  GC1560  
 G  GC1561  
 G  GC1562  
 G  GC1563  
 G  GC1564  
 G  GC1565  
 G  GC1566  
 G  GC1567  
 G  GC1568  
 G  GC1569  
 G  GC1570  
 G  GC1571  
 G  GC1572  
 G  GC1573  
 G  GC1574  
 G  GC1575  
 G  GC1576  
 G  GC1577  
 G  GC1578  
 G  GC1579  
 G  GC1580  
 G  GC1581  
 G  GC1582  
 G  GC1583  
 G  GC1584  
 G  GC1585  
 G  GC1586  
 G  GC1587  
 G  GC1588  
 G  GC1589  
 G  GC1590  
 G  GC1591  
 G  GC1592  
 G  GC1593  
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    route[0]  OBJ       1.3281566172707193e+02
    route[0]  R0        -600.000001
    route[0]  R1        -40.000001
    route[0]  R592      1
    route[0]  R593      1
    route[0]  R594      -31093
    route[1]  OBJ       1.3281566172707193e+02
    route[1]  R2        -1
    route[1]  R3        -18
    route[1]  R4        -600.000001
    route[1]  R5        -40.000001
    route[1]  R592      1
    route[1]  R593      1
    route[1]  R594      -31093
    route[1]  R595      1
    route[2]  OBJ       1.7490653625707344e+02
    route[2]  R6        -1
    route[2]  R7        -11
    route[2]  R8        -600.000001
    route[2]  R9        -40.000001
    route[2]  R592      1
    route[2]  R593      1
    route[2]  R594      -31093
    route[2]  R598      1
    route[3]  OBJ       1.4449913494550754e+02
    route[3]  R10       -600.000001
    route[3]  R11       -40.000001
    route[3]  R592      1
    route[3]  R596      1
    route[3]  R597      -31268
    route[4]  OBJ       1.7490653625707344e+02
    route[4]  R12       -1
    route[4]  R13       -18
    route[4]  R14       -600.000001
    route[4]  R15       -40.000001
    route[4]  R592      1
    route[4]  R595      1
    route[4]  R596      1
    route[4]  R597      -31268
    route[5]  OBJ       1.4449913494550754e+02
    route[5]  R16       -1
    route[5]  R17       -11
    route[5]  R18       -600.000001
    route[5]  R19       -40.000001
    route[5]  R592      1
    route[5]  R596      1
    route[5]  R597      -31268
    route[5]  R598      1
    route[6]  OBJ       1.6352321594301694e+02
    route[6]  R20       -1
    route[6]  R21       -4
    route[6]  R22       -600.000001
    route[6]  R23       -40.000001
    route[6]  R592      1
    route[6]  R596      1
    route[6]  R597      -31268
    route[6]  R601      1
    route[7]  OBJ       1.7490653625707344e+02
    route[7]  R24       -1
    route[7]  R25       -11
    route[7]  R26       -1
    route[7]  R27       -18
    route[7]  R28       -600.000001
    route[7]  R29       -40.000001
    route[7]  R592      1
    route[7]  R595      1
    route[7]  R596      1
    route[7]  R597      -31268
    route[7]  R598      1
    route[8]  OBJ       1.6352321594301694e+02
    route[8]  R30       -1
    route[8]  R31       -11
    route[8]  R32       -1
    route[8]  R33       -4
    route[8]  R34       -600.000001
    route[8]  R35       -40.000001
    route[8]  R592      1
    route[8]  R596      1
    route[8]  R597      -31268
    route[8]  R598      1
    route[8]  R601      1
    route[9]  OBJ       1.4136477637657833e+02
    route[9]  R36       -600.000001
    route[9]  R37       -40.000001
    route[9]  R592      1
    route[9]  R599      1
    route[9]  R600      -31221
    route[10]  OBJ       1.6352321594301694e+02
    route[10]  R38       -1
    route[10]  R39       -11
    route[10]  R40       -600.000001
    route[10]  R41       -40.000001
    route[10]  R592      1
    route[10]  R598      1
    route[10]  R599      1
    route[10]  R600      -31221
    route[11]  OBJ       1.4136477637657833e+02
    route[11]  R42       -1
    route[11]  R43       -4
    route[11]  R44       -600.000001
    route[11]  R45       -40.000001
    route[11]  R592      1
    route[11]  R599      1
    route[11]  R600      -31221
    route[11]  R601      1
    route[12]  OBJ       1.6352321594301694e+02
    route[12]  R46       -1
    route[12]  R47       -4
    route[12]  R48       -1
    route[12]  R49       -11
    route[12]  R50       -600.000001
    route[12]  R51       -40.000001
    route[12]  R592      1
    route[12]  R598      1
    route[12]  R599      1
    route[12]  R600      -31221
    route[12]  R601      1
    route[13]  OBJ       1.7490653625707344e+02
    route[13]  R52       -600.000001
    route[13]  R53       -40.000001
    route[13]  R592      1
    route[13]  R593      1
    route[13]  R594      -31093
    route[13]  R596      1
    route[13]  R597      -32361
    route[14]  OBJ       2.0531393756863935e+02
    route[14]  R54       -1
    route[14]  R55       -18
    route[14]  R56       -600.000001
    route[14]  R57       -40.000001
    route[14]  R592      1
    route[14]  R593      1
    route[14]  R594      -31093
    route[14]  R595      1
    route[14]  R596      1
    route[14]  R597      -32361
    route[15]  OBJ       1.7490653625707344e+02
    route[15]  R58       -1
    route[15]  R59       -11
    route[15]  R60       -600.000001
    route[15]  R61       -40.000001
    route[15]  R592      1
    route[15]  R593      1
    route[15]  R594      -31093
    route[15]  R596      1
    route[15]  R597      -32361
    route[15]  R598      1
    route[16]  OBJ       1.9393061725458284e+02
    route[16]  R62       -1
    route[16]  R63       -4
    route[16]  R64       -600.000001
    route[16]  R65       -40.000001
    route[16]  R592      1
    route[16]  R593      1
    route[16]  R594      -31093
    route[16]  R596      1
    route[16]  R597      -32361
    route[16]  R601      1
    route[17]  OBJ       2.0531393756863935e+02
    route[17]  R66       -1
    route[17]  R67       -11
    route[17]  R68       -1
    route[17]  R69       -18
    route[17]  R70       -600.000001
    route[17]  R71       -40.000001
    route[17]  R592      1
    route[17]  R593      1
    route[17]  R594      -31093
    route[17]  R595      1
    route[17]  R596      1
    route[17]  R597      -32361
    route[17]  R598      1
    route[18]  OBJ       1.9393061725458284e+02
    route[18]  R72       -1
    route[18]  R73       -11
    route[18]  R74       -1
    route[18]  R75       -4
    route[18]  R76       -600.000001
    route[18]  R77       -40.000001
    route[18]  R592      1
    route[18]  R593      1
    route[18]  R594      -31093
    route[18]  R596      1
    route[18]  R597      -32361
    route[18]  R598      1
    route[18]  R601      1
    route[19]  OBJ       1.9129353998329574e+02
    route[19]  R78       -600.000001
    route[19]  R79       -40.000001
    route[19]  R592      1
    route[19]  R593      1
    route[19]  R594      -31093
    route[19]  R599      1
    route[19]  R600      -32900
    route[20]  OBJ       2.1345197954973435e+02
    route[20]  R80       -1
    route[20]  R81       -11
    route[20]  R82       -600.000001
    route[20]  R83       -40.000001
    route[20]  R592      1
    route[20]  R593      1
    route[20]  R594      -31093
    route[20]  R598      1
    route[20]  R599      1
    route[20]  R600      -32900
    route[21]  OBJ       1.9129353998329574e+02
    route[21]  R84       -1
    route[21]  R85       -4
    route[21]  R86       -600.000001
    route[21]  R87       -40.000001
    route[21]  R592      1
    route[21]  R593      1
    route[21]  R594      -31093
    route[21]  R599      1
    route[21]  R600      -32900
    route[21]  R601      1
    route[22]  OBJ       2.1345197954973435e+02
    route[22]  R88       -1
    route[22]  R89       -4
    route[22]  R90       -1
    route[22]  R91       -11
    route[22]  R92       -600.000001
    route[22]  R93       -40.000001
    route[22]  R592      1
    route[22]  R593      1
    route[22]  R594      -31093
    route[22]  R598      1
    route[22]  R599      1
    route[22]  R600      -32900
    route[22]  R601      1
    route[23]  OBJ       1.7490653625707344e+02
    route[23]  R94       -600.000001
    route[23]  R95       -40.000001
    route[23]  R592      1
    route[23]  R593      1
    route[23]  R594      -32536
    route[23]  R596      1
    route[23]  R597      -31268
    route[24]  OBJ       1.7490653625707344e+02
    route[24]  R96       -1
    route[24]  R97       -18
    route[24]  R98       -600.000001
    route[24]  R99       -40.000001
    route[24]  R592      1
    route[24]  R593      1
    route[24]  R594      -32536
    route[24]  R595      1
    route[24]  R596      1
    route[24]  R597      -31268
    route[25]  OBJ       2.1699741078707495e+02
    route[25]  R100      -1
    route[25]  R101      -11
    route[25]  R102      -600.000001
    route[25]  R103      -40.000001
    route[25]  R592      1
    route[25]  R593      1
    route[25]  R594      -32536
    route[25]  R596      1
    route[25]  R597      -31268
    route[25]  R598      1
    route[26]  OBJ       1.6352321594301694e+02
    route[26]  R104      -600.000001
    route[26]  R105      -40.000001
    route[26]  R592      1
    route[26]  R596      1
    route[26]  R597      -31268
    route[26]  R599      1
    route[26]  R600      -32066
    route[27]  OBJ       1.8568165550945554e+02
    route[27]  R106      -1
    route[27]  R107      -11
    route[27]  R108      -600.000001
    route[27]  R109      -40.000001
    route[27]  R592      1
    route[27]  R596      1
    route[27]  R597      -31268
    route[27]  R598      1
    route[27]  R599      1
    route[27]  R600      -32066
    route[28]  OBJ       1.6352321594301694e+02
    route[28]  R110      -1
    route[28]  R111      -4
    route[28]  R112      -600.000001
    route[28]  R113      -40.000001
    route[28]  R592      1
    route[28]  R596      1
    route[28]  R597      -31268
    route[28]  R599      1
    route[28]  R600      -32066
    route[28]  R601      1
    route[29]  OBJ       1.8568165550945554e+02
    route[29]  R114      -1
    route[29]  R115      -4
    route[29]  R116      -1
    route[29]  R117      -11
    route[29]  R118      -600.000001
    route[29]  R119      -40.000001
    route[29]  R592      1
    route[29]  R596      1
    route[29]  R597      -31268
    route[29]  R598      1
    route[29]  R599      1
    route[29]  R600      -32066
    route[29]  R601      1
    route[30]  OBJ       1.9129353998329574e+02
    route[30]  R120      -600.000001
    route[30]  R121      -40.000001
    route[30]  R592      1
    route[30]  R593      1
    route[30]  R594      -33028
    route[30]  R599      1
    route[30]  R600      -31221
    route[31]  OBJ       1.9129353998329574e+02
    route[31]  R122      -1
    route[31]  R123      -18
    route[31]  R124      -600.000001
    route[31]  R125      -40.000001
    route[31]  R592      1
    route[31]  R593      1
    route[31]  R594      -33028
    route[31]  R595      1
    route[31]  R599      1
    route[31]  R600      -31221
    route[32]  OBJ       2.3338441451329726e+02
    route[32]  R126      -1
    route[32]  R127      -11
    route[32]  R128      -600.000001
    route[32]  R129      -40.000001
    route[32]  R592      1
    route[32]  R593      1
    route[32]  R594      -33028
    route[32]  R598      1
    route[32]  R599      1
    route[32]  R600      -31221
    route[33]  OBJ       1.6352321594301694e+02
    route[33]  R130      -600.000001
    route[33]  R131      -40.000001
    route[33]  R592      1
    route[33]  R596      1
    route[33]  R597      -32019
    route[33]  R599      1
    route[33]  R600      -31221
    route[34]  OBJ       1.9393061725458284e+02
    route[34]  R132      -1
    route[34]  R133      -18
    route[34]  R134      -600.000001
    route[34]  R135      -40.000001
    route[34]  R592      1
    route[34]  R595      1
    route[34]  R596      1
    route[34]  R597      -32019
    route[34]  R599      1
    route[34]  R600      -31221
    route[35]  OBJ       1.6352321594301694e+02
    route[35]  R136      -1
    route[35]  R137      -11
    route[35]  R138      -600.000001
    route[35]  R139      -40.000001
    route[35]  R592      1
    route[35]  R596      1
    route[35]  R597      -32019
    route[35]  R598      1
    route[35]  R599      1
    route[35]  R600      -31221
    route[36]  OBJ       1.8254729694052634e+02
    route[36]  R140      -1
    route[36]  R141      -4
    route[36]  R142      -600.000001
    route[36]  R143      -40.000001
    route[36]  R592      1
    route[36]  R596      1
    route[36]  R597      -32019
    route[36]  R599      1
    route[36]  R600      -31221
    route[36]  R601      1
    route[37]  OBJ       1.9393061725458284e+02
    route[37]  R144      -1
    route[37]  R145      -11
    route[37]  R146      -1
    route[37]  R147      -18
    route[37]  R148      -600.000001
    route[37]  R149      -40.000001
    route[37]  R592      1
    route[37]  R595      1
    route[37]  R596      1
    route[37]  R597      -32019
    route[37]  R598      1
    route[37]  R599      1
    route[37]  R600      -31221
    route[38]  OBJ       1.8254729694052634e+02
    route[38]  R150      -1
    route[38]  R151      -11
    route[38]  R152      -1
    route[38]  R153      -4
    route[38]  R154      -600.000001
    route[38]  R155      -40.000001
    route[38]  R592      1
    route[38]  R596      1
    route[38]  R597      -32019
    route[38]  R598      1
    route[38]  R599      1
    route[38]  R600      -31221
    route[38]  R601      1
    route[39]  OBJ       1.9393061725458284e+02
    route[39]  R156      -600.000001
    route[39]  R157      -40.000001
    route[39]  R592      1
    route[39]  R593      1
    route[39]  R594      -31093
    route[39]  R596      1
    route[39]  R597      -32361
    route[39]  R599      1
    route[39]  R600      -33159
    route[40]  OBJ       2.1608905682102144e+02
    route[40]  R158      -1
    route[40]  R159      -11
    route[40]  R160      -600.000001
    route[40]  R161      -40.000001
    route[40]  R592      1
    route[40]  R593      1
    route[40]  R594      -31093
    route[40]  R596      1
    route[40]  R597      -32361
    route[40]  R598      1
    route[40]  R599      1
    route[40]  R600      -33159
    route[41]  OBJ       1.9393061725458284e+02
    route[41]  R162      -1
    route[41]  R163      -4
    route[41]  R164      -600.000001
    route[41]  R165      -40.000001
    route[41]  R592      1
    route[41]  R593      1
    route[41]  R594      -31093
    route[41]  R596      1
    route[41]  R597      -32361
    route[41]  R599      1
    route[41]  R600      -33159
    route[41]  R601      1
    route[42]  OBJ       2.1608905682102144e+02
    route[42]  R166      -1
    route[42]  R167      -4
    route[42]  R168      -1
    route[42]  R169      -11
    route[42]  R170      -600.000001
    route[42]  R171      -40.000001
    route[42]  R592      1
    route[42]  R593      1
    route[42]  R594      -31093
    route[42]  R596      1
    route[42]  R597      -32361
    route[42]  R598      1
    route[42]  R599      1
    route[42]  R600      -33159
    route[42]  R601      1
    route[43]  OBJ       2.1345197954973435e+02
    route[43]  R172      -600.000001
    route[43]  R173      -40.000001
    route[43]  R592      1
    route[43]  R593      1
    route[43]  R594      -31093
    route[43]  R596      1
    route[43]  R597      -33698
    route[43]  R599      1
    route[43]  R600      -32900
    route[44]  OBJ       2.4385938086130025e+02
    route[44]  R174      -1
    route[44]  R175      -18
    route[44]  R176      -600.000001
    route[44]  R177      -40.000001
    route[44]  R592      1
    route[44]  R593      1
    route[44]  R594      -31093
    route[44]  R595      1
    route[44]  R596      1
    route[44]  R597      -33698
    route[44]  R599      1
    route[44]  R600      -32900
    route[45]  OBJ       2.1345197954973435e+02
    route[45]  R178      -1
    route[45]  R179      -11
    route[45]  R180      -600.000001
    route[45]  R181      -40.000001
    route[45]  R592      1
    route[45]  R593      1
    route[45]  R594      -31093
    route[45]  R596      1
    route[45]  R597      -33698
    route[45]  R598      1
    route[45]  R599      1
    route[45]  R600      -32900
    route[46]  OBJ       2.3247606054724375e+02
    route[46]  R182      -1
    route[46]  R183      -4
    route[46]  R184      -600.000001
    route[46]  R185      -40.000001
    route[46]  R592      1
    route[46]  R593      1
    route[46]  R594      -31093
    route[46]  R596      1
    route[46]  R597      -33698
    route[46]  R599      1
    route[46]  R600      -32900
    route[46]  R601      1
    route[47]  OBJ       2.4385938086130025e+02
    route[47]  R186      -1
    route[47]  R187      -11
    route[47]  R188      -1
    route[47]  R189      -18
    route[47]  R190      -600.000001
    route[47]  R191      -40.000001
    route[47]  R592      1
    route[47]  R593      1
    route[47]  R594      -31093
    route[47]  R595      1
    route[47]  R596      1
    route[47]  R597      -33698
    route[47]  R598      1
    route[47]  R599      1
    route[47]  R600      -32900
    route[48]  OBJ       2.3247606054724375e+02
    route[48]  R192      -1
    route[48]  R193      -11
    route[48]  R194      -1
    route[48]  R195      -4
    route[48]  R196      -600.000001
    route[48]  R197      -40.000001
    route[48]  R592      1
    route[48]  R593      1
    route[48]  R594      -31093
    route[48]  R596      1
    route[48]  R597      -33698
    route[48]  R598      1
    route[48]  R599      1
    route[48]  R600      -32900
    route[48]  R601      1
    route[49]  OBJ       2.3338441451329726e+02
    route[49]  R198      -600.000001
    route[49]  R199      -40.000001
    route[49]  R592      1
    route[49]  R593      1
    route[49]  R594      -32536
    route[49]  R596      1
    route[49]  R597      -31268
    route[49]  R599      1
    route[49]  R600      -34343
    route[50]  OBJ       2.5554285407973586e+02
    route[50]  R200      -1
    route[50]  R201      -11
    route[50]  R202      -600.000001
    route[50]  R203      -40.000001
    route[50]  R592      1
    route[50]  R593      1
    route[50]  R594      -32536
    route[50]  R596      1
    route[50]  R597      -31268
    route[50]  R598      1
    route[50]  R599      1
    route[50]  R600      -34343
    route[51]  OBJ       2.3338441451329726e+02
    route[51]  R204      -1
    route[51]  R205      -4
    route[51]  R206      -600.000001
    route[51]  R207      -40.000001
    route[51]  R592      1
    route[51]  R593      1
    route[51]  R594      -32536
    route[51]  R596      1
    route[51]  R597      -31268
    route[51]  R599      1
    route[51]  R600      -34343
    route[51]  R601      1
    route[52]  OBJ       2.5554285407973586e+02
    route[52]  R208      -1
    route[52]  R209      -4
    route[52]  R210      -1
    route[52]  R211      -11
    route[52]  R212      -600.000001
    route[52]  R213      -40.000001
    route[52]  R592      1
    route[52]  R593      1
    route[52]  R594      -32536
    route[52]  R596      1
    route[52]  R597      -31268
    route[52]  R598      1
    route[52]  R599      1
    route[52]  R600      -34343
    route[52]  R601      1
    route[53]  OBJ       2.1345197954973435e+02
    route[53]  R214      -600.000001
    route[53]  R215      -40.000001
    route[53]  R592      1
    route[53]  R593      1
    route[53]  R594      -33873
    route[53]  R596      1
    route[53]  R597      -31268
    route[53]  R599      1
    route[53]  R600      -32066
    route[54]  OBJ       2.1345197954973435e+02
    route[54]  R216      -1
    route[54]  R217      -18
    route[54]  R218      -600.000001
    route[54]  R219      -40.000001
    route[54]  R592      1
    route[54]  R593      1
    route[54]  R594      -33873
    route[54]  R595      1
    route[54]  R596      1
    route[54]  R597      -31268
    route[54]  R599      1
    route[54]  R600      -32066
    route[55]  OBJ       2.5554285407973586e+02
    route[55]  R220      -1
    route[55]  R221      -11
    route[55]  R222      -600.000001
    route[55]  R223      -40.000001
    route[55]  R592      1
    route[55]  R593      1
    route[55]  R594      -33873
    route[55]  R596      1
    route[55]  R597      -31268
    route[55]  R598      1
    route[55]  R599      1
    route[55]  R600      -32066
    route[56]  OBJ       2.3338441451329726e+02
    route[56]  R224      -600.000001
    route[56]  R225      -40.000001
    route[56]  R592      1
    route[56]  R593      1
    route[56]  R594      -33028
    route[56]  R596      1
    route[56]  R597      -34296
    route[56]  R599      1
    route[56]  R600      -31221
    route[57]  OBJ       2.6379181582486319e+02
    route[57]  R226      -1
    route[57]  R227      -18
    route[57]  R228      -600.000001
    route[57]  R229      -40.000001
    route[57]  R592      1
    route[57]  R593      1
    route[57]  R594      -33028
    route[57]  R595      1
    route[57]  R596      1
    route[57]  R597      -34296
    route[57]  R599      1
    route[57]  R600      -31221
    route[58]  OBJ       2.3338441451329726e+02
    route[58]  R230      -1
    route[58]  R231      -11
    route[58]  R232      -600.000001
    route[58]  R233      -40.000001
    route[58]  R592      1
    route[58]  R593      1
    route[58]  R594      -33028
    route[58]  R596      1
    route[58]  R597      -34296
    route[58]  R598      1
    route[58]  R599      1
    route[58]  R600      -31221
    route[59]  OBJ       2.5240849551080666e+02
    route[59]  R234      -1
    route[59]  R235      -4
    route[59]  R236      -600.000001
    route[59]  R237      -40.000001
    route[59]  R592      1
    route[59]  R593      1
    route[59]  R594      -33028
    route[59]  R596      1
    route[59]  R597      -34296
    route[59]  R599      1
    route[59]  R600      -31221
    route[59]  R601      1
    route[60]  OBJ       2.6379181582486319e+02
    route[60]  R238      -1
    route[60]  R239      -11
    route[60]  R240      -1
    route[60]  R241      -18
    route[60]  R242      -600.000001
    route[60]  R243      -40.000001
    route[60]  R592      1
    route[60]  R593      1
    route[60]  R594      -33028
    route[60]  R595      1
    route[60]  R596      1
    route[60]  R597      -34296
    route[60]  R598      1
    route[60]  R599      1
    route[60]  R600      -31221
    route[61]  OBJ       2.5240849551080666e+02
    route[61]  R244      -1
    route[61]  R245      -11
    route[61]  R246      -1
    route[61]  R247      -4
    route[61]  R248      -600.000001
    route[61]  R249      -40.000001
    route[61]  R592      1
    route[61]  R593      1
    route[61]  R594      -33028
    route[61]  R596      1
    route[61]  R597      -34296
    route[61]  R598      1
    route[61]  R599      1
    route[61]  R600      -31221
    route[61]  R601      1
    route[62]  OBJ       1.9393061725458284e+02
    route[62]  R250      -600.000001
    route[62]  R251      -40.000001
    route[62]  R592      1
    route[62]  R593      1
    route[62]  R594      -33287
    route[62]  R596      1
    route[62]  R597      -32019
    route[62]  R599      1
    route[62]  R600      -31221
    route[63]  OBJ       1.9393061725458284e+02
    route[63]  R252      -1
    route[63]  R253      -18
    route[63]  R254      -600.000001
    route[63]  R255      -40.000001
    route[63]  R592      1
    route[63]  R593      1
    route[63]  R594      -33287
    route[63]  R595      1
    route[63]  R596      1
    route[63]  R597      -32019
    route[63]  R599      1
    route[63]  R600      -31221
    route[64]  OBJ       2.3602149178458436e+02
    route[64]  R256      -1
    route[64]  R257      -11
    route[64]  R258      -600.000001
    route[64]  R259      -40.000001
    route[64]  R592      1
    route[64]  R593      1
    route[64]  R594      -33287
    route[64]  R596      1
    route[64]  R597      -32019
    route[64]  R598      1
    route[64]  R599      1
    route[64]  R600      -31221
    route[65]  OBJ       1.3281566172707193e+02
    route[65]  R260      -600.000001
    route[65]  R261      -40.000001
    route[65]  R602      1
    route[65]  R603      1
    route[65]  R604      -45493
    route[66]  OBJ       1.3281566172707193e+02
    route[66]  R262      -1
    route[66]  R263      -18
    route[66]  R264      -600.000001
    route[66]  R265      -40.000001
    route[66]  R602      1
    route[66]  R603      1
    route[66]  R604      -45493
    route[66]  R605      1
    route[67]  OBJ       1.7490653625707344e+02
    route[67]  R266      -1
    route[67]  R267      -11
    route[67]  R268      -600.000001
    route[67]  R269      -40.000001
    route[67]  R602      1
    route[67]  R603      1
    route[67]  R604      -45493
    route[67]  R608      1
    route[68]  OBJ       1.4449913494550754e+02
    route[68]  R270      -600.000001
    route[68]  R271      -40.000001
    route[68]  R602      1
    route[68]  R606      1
    route[68]  R607      -45668
    route[69]  OBJ       1.7490653625707344e+02
    route[69]  R272      -1
    route[69]  R273      -18
    route[69]  R274      -600.000001
    route[69]  R275      -40.000001
    route[69]  R602      1
    route[69]  R605      1
    route[69]  R606      1
    route[69]  R607      -45668
    route[70]  OBJ       1.4449913494550754e+02
    route[70]  R276      -1
    route[70]  R277      -11
    route[70]  R278      -600.000001
    route[70]  R279      -40.000001
    route[70]  R602      1
    route[70]  R606      1
    route[70]  R607      -45668
    route[70]  R608      1
    route[71]  OBJ       1.6352321594301694e+02
    route[71]  R280      -1
    route[71]  R281      -4
    route[71]  R282      -600.000001
    route[71]  R283      -40.000001
    route[71]  R602      1
    route[71]  R606      1
    route[71]  R607      -45668
    route[71]  R611      1
    route[72]  OBJ       1.7490653625707344e+02
    route[72]  R284      -1
    route[72]  R285      -11
    route[72]  R286      -1
    route[72]  R287      -18
    route[72]  R288      -600.000001
    route[72]  R289      -40.000001
    route[72]  R602      1
    route[72]  R605      1
    route[72]  R606      1
    route[72]  R607      -45668
    route[72]  R608      1
    route[73]  OBJ       1.6352321594301694e+02
    route[73]  R290      -1
    route[73]  R291      -11
    route[73]  R292      -1
    route[73]  R293      -4
    route[73]  R294      -600.000001
    route[73]  R295      -40.000001
    route[73]  R602      1
    route[73]  R606      1
    route[73]  R607      -45668
    route[73]  R608      1
    route[73]  R611      1
    route[74]  OBJ       1.4136477637657833e+02
    route[74]  R296      -600.000001
    route[74]  R297      -40.000001
    route[74]  R602      1
    route[74]  R609      1
    route[74]  R610      -45621
    route[75]  OBJ       1.6352321594301694e+02
    route[75]  R298      -1
    route[75]  R299      -11
    route[75]  R300      -600.000001
    route[75]  R301      -40.000001
    route[75]  R602      1
    route[75]  R608      1
    route[75]  R609      1
    route[75]  R610      -45621
    route[76]  OBJ       1.4136477637657833e+02
    route[76]  R302      -1
    route[76]  R303      -4
    route[76]  R304      -600.000001
    route[76]  R305      -40.000001
    route[76]  R602      1
    route[76]  R609      1
    route[76]  R610      -45621
    route[76]  R611      1
    route[77]  OBJ       1.6352321594301694e+02
    route[77]  R306      -1
    route[77]  R307      -4
    route[77]  R308      -1
    route[77]  R309      -11
    route[77]  R310      -600.000001
    route[77]  R311      -40.000001
    route[77]  R602      1
    route[77]  R608      1
    route[77]  R609      1
    route[77]  R610      -45621
    route[77]  R611      1
    route[78]  OBJ       1.7490653625707344e+02
    route[78]  R312      -600.000001
    route[78]  R313      -40.000001
    route[78]  R602      1
    route[78]  R603      1
    route[78]  R604      -45493
    route[78]  R606      1
    route[78]  R607      -46761
    route[79]  OBJ       2.0531393756863935e+02
    route[79]  R314      -1
    route[79]  R315      -18
    route[79]  R316      -600.000001
    route[79]  R317      -40.000001
    route[79]  R602      1
    route[79]  R603      1
    route[79]  R604      -45493
    route[79]  R605      1
    route[79]  R606      1
    route[79]  R607      -46761
    route[80]  OBJ       1.7490653625707344e+02
    route[80]  R318      -1
    route[80]  R319      -11
    route[80]  R320      -600.000001
    route[80]  R321      -40.000001
    route[80]  R602      1
    route[80]  R603      1
    route[80]  R604      -45493
    route[80]  R606      1
    route[80]  R607      -46761
    route[80]  R608      1
    route[81]  OBJ       1.9393061725458284e+02
    route[81]  R322      -1
    route[81]  R323      -4
    route[81]  R324      -600.000001
    route[81]  R325      -40.000001
    route[81]  R602      1
    route[81]  R603      1
    route[81]  R604      -45493
    route[81]  R606      1
    route[81]  R607      -46761
    route[81]  R611      1
    route[82]  OBJ       2.0531393756863935e+02
    route[82]  R326      -1
    route[82]  R327      -11
    route[82]  R328      -1
    route[82]  R329      -18
    route[82]  R330      -600.000001
    route[82]  R331      -40.000001
    route[82]  R602      1
    route[82]  R603      1
    route[82]  R604      -45493
    route[82]  R605      1
    route[82]  R606      1
    route[82]  R607      -46761
    route[82]  R608      1
    route[83]  OBJ       1.9393061725458284e+02
    route[83]  R332      -1
    route[83]  R333      -11
    route[83]  R334      -1
    route[83]  R335      -4
    route[83]  R336      -600.000001
    route[83]  R337      -40.000001
    route[83]  R602      1
    route[83]  R603      1
    route[83]  R604      -45493
    route[83]  R606      1
    route[83]  R607      -46761
    route[83]  R608      1
    route[83]  R611      1
    route[84]  OBJ       1.9129353998329574e+02
    route[84]  R338      -600.000001
    route[84]  R339      -40.000001
    route[84]  R602      1
    route[84]  R603      1
    route[84]  R604      -45493
    route[84]  R609      1
    route[84]  R610      -47300
    route[85]  OBJ       2.1345197954973435e+02
    route[85]  R340      -1
    route[85]  R341      -11
    route[85]  R342      -600.000001
    route[85]  R343      -40.000001
    route[85]  R602      1
    route[85]  R603      1
    route[85]  R604      -45493
    route[85]  R608      1
    route[85]  R609      1
    route[85]  R610      -47300
    route[86]  OBJ       1.9129353998329574e+02
    route[86]  R344      -1
    route[86]  R345      -4
    route[86]  R346      -600.000001
    route[86]  R347      -40.000001
    route[86]  R602      1
    route[86]  R603      1
    route[86]  R604      -45493
    route[86]  R609      1
    route[86]  R610      -47300
    route[86]  R611      1
    route[87]  OBJ       2.1345197954973435e+02
    route[87]  R348      -1
    route[87]  R349      -4
    route[87]  R350      -1
    route[87]  R351      -11
    route[87]  R352      -600.000001
    route[87]  R353      -40.000001
    route[87]  R602      1
    route[87]  R603      1
    route[87]  R604      -45493
    route[87]  R608      1
    route[87]  R609      1
    route[87]  R610      -47300
    route[87]  R611      1
    route[88]  OBJ       1.7490653625707344e+02
    route[88]  R354      -600.000001
    route[88]  R355      -40.000001
    route[88]  R602      1
    route[88]  R603      1
    route[88]  R604      -46936
    route[88]  R606      1
    route[88]  R607      -45668
    route[89]  OBJ       1.7490653625707344e+02
    route[89]  R356      -1
    route[89]  R357      -18
    route[89]  R358      -600.000001
    route[89]  R359      -40.000001
    route[89]  R602      1
    route[89]  R603      1
    route[89]  R604      -46936
    route[89]  R605      1
    route[89]  R606      1
    route[89]  R607      -45668
    route[90]  OBJ       2.1699741078707495e+02
    route[90]  R360      -1
    route[90]  R361      -11
    route[90]  R362      -600.000001
    route[90]  R363      -40.000001
    route[90]  R602      1
    route[90]  R603      1
    route[90]  R604      -46936
    route[90]  R606      1
    route[90]  R607      -45668
    route[90]  R608      1
    route[91]  OBJ       1.6352321594301694e+02
    route[91]  R364      -600.000001
    route[91]  R365      -40.000001
    route[91]  R602      1
    route[91]  R606      1
    route[91]  R607      -45668
    route[91]  R609      1
    route[91]  R610      -46466
    route[92]  OBJ       1.8568165550945554e+02
    route[92]  R366      -1
    route[92]  R367      -11
    route[92]  R368      -600.000001
    route[92]  R369      -40.000001
    route[92]  R602      1
    route[92]  R606      1
    route[92]  R607      -45668
    route[92]  R608      1
    route[92]  R609      1
    route[92]  R610      -46466
    route[93]  OBJ       1.6352321594301694e+02
    route[93]  R370      -1
    route[93]  R371      -4
    route[93]  R372      -600.000001
    route[93]  R373      -40.000001
    route[93]  R602      1
    route[93]  R606      1
    route[93]  R607      -45668
    route[93]  R609      1
    route[93]  R610      -46466
    route[93]  R611      1
    route[94]  OBJ       1.8568165550945554e+02
    route[94]  R374      -1
    route[94]  R375      -4
    route[94]  R376      -1
    route[94]  R377      -11
    route[94]  R378      -600.000001
    route[94]  R379      -40.000001
    route[94]  R602      1
    route[94]  R606      1
    route[94]  R607      -45668
    route[94]  R608      1
    route[94]  R609      1
    route[94]  R610      -46466
    route[94]  R611      1
    route[95]  OBJ       1.9129353998329574e+02
    route[95]  R380      -600.000001
    route[95]  R381      -40.000001
    route[95]  R602      1
    route[95]  R603      1
    route[95]  R604      -47428
    route[95]  R609      1
    route[95]  R610      -45621
    route[96]  OBJ       1.9129353998329574e+02
    route[96]  R382      -1
    route[96]  R383      -18
    route[96]  R384      -600.000001
    route[96]  R385      -40.000001
    route[96]  R602      1
    route[96]  R603      1
    route[96]  R604      -47428
    route[96]  R605      1
    route[96]  R609      1
    route[96]  R610      -45621
    route[97]  OBJ       2.3338441451329726e+02
    route[97]  R386      -1
    route[97]  R387      -11
    route[97]  R388      -600.000001
    route[97]  R389      -40.000001
    route[97]  R602      1
    route[97]  R603      1
    route[97]  R604      -47428
    route[97]  R608      1
    route[97]  R609      1
    route[97]  R610      -45621
    route[98]  OBJ       1.6352321594301694e+02
    route[98]  R390      -600.000001
    route[98]  R391      -40.000001
    route[98]  R602      1
    route[98]  R606      1
    route[98]  R607      -46419
    route[98]  R609      1
    route[98]  R610      -45621
    route[99]  OBJ       1.9393061725458284e+02
    route[99]  R392      -1
    route[99]  R393      -18
    route[99]  R394      -600.000001
    route[99]  R395      -40.000001
    route[99]  R602      1
    route[99]  R605      1
    route[99]  R606      1
    route[99]  R607      -46419
    route[99]  R609      1
    route[99]  R610      -45621
    route[100]  OBJ       1.6352321594301694e+02
    route[100]  R396      -1
    route[100]  R397      -11
    route[100]  R398      -600.000001
    route[100]  R399      -40.000001
    route[100]  R602      1
    route[100]  R606      1
    route[100]  R607      -46419
    route[100]  R608      1
    route[100]  R609      1
    route[100]  R610      -45621
    route[101]  OBJ       1.8254729694052634e+02
    route[101]  R400      -1
    route[101]  R401      -4
    route[101]  R402      -600.000001
    route[101]  R403      -40.000001
    route[101]  R602      1
    route[101]  R606      1
    route[101]  R607      -46419
    route[101]  R609      1
    route[101]  R610      -45621
    route[101]  R611      1
    route[102]  OBJ       1.9393061725458284e+02
    route[102]  R404      -1
    route[102]  R405      -11
    route[102]  R406      -1
    route[102]  R407      -18
    route[102]  R408      -600.000001
    route[102]  R409      -40.000001
    route[102]  R602      1
    route[102]  R605      1
    route[102]  R606      1
    route[102]  R607      -46419
    route[102]  R608      1
    route[102]  R609      1
    route[102]  R610      -45621
    route[103]  OBJ       1.8254729694052634e+02
    route[103]  R410      -1
    route[103]  R411      -11
    route[103]  R412      -1
    route[103]  R413      -4
    route[103]  R414      -600.000001
    route[103]  R415      -40.000001
    route[103]  R602      1
    route[103]  R606      1
    route[103]  R607      -46419
    route[103]  R608      1
    route[103]  R609      1
    route[103]  R610      -45621
    route[103]  R611      1
    route[104]  OBJ       1.9393061725458284e+02
    route[104]  R416      -600.000001
    route[104]  R417      -40.000001
    route[104]  R602      1
    route[104]  R603      1
    route[104]  R604      -45493
    route[104]  R606      1
    route[104]  R607      -46761
    route[104]  R609      1
    route[104]  R610      -47559
    route[105]  OBJ       2.1608905682102144e+02
    route[105]  R418      -1
    route[105]  R419      -11
    route[105]  R420      -600.000001
    route[105]  R421      -40.000001
    route[105]  R602      1
    route[105]  R603      1
    route[105]  R604      -45493
    route[105]  R606      1
    route[105]  R607      -46761
    route[105]  R608      1
    route[105]  R609      1
    route[105]  R610      -47559
    route[106]  OBJ       1.9393061725458284e+02
    route[106]  R422      -1
    route[106]  R423      -4
    route[106]  R424      -600.000001
    route[106]  R425      -40.000001
    route[106]  R602      1
    route[106]  R603      1
    route[106]  R604      -45493
    route[106]  R606      1
    route[106]  R607      -46761
    route[106]  R609      1
    route[106]  R610      -47559
    route[106]  R611      1
    route[107]  OBJ       2.1608905682102144e+02
    route[107]  R426      -1
    route[107]  R427      -4
    route[107]  R428      -1
    route[107]  R429      -11
    route[107]  R430      -600.000001
    route[107]  R431      -40.000001
    route[107]  R602      1
    route[107]  R603      1
    route[107]  R604      -45493
    route[107]  R606      1
    route[107]  R607      -46761
    route[107]  R608      1
    route[107]  R609      1
    route[107]  R610      -47559
    route[107]  R611      1
    route[108]  OBJ       2.1345197954973435e+02
    route[108]  R432      -600.000001
    route[108]  R433      -40.000001
    route[108]  R602      1
    route[108]  R603      1
    route[108]  R604      -45493
    route[108]  R606      1
    route[108]  R607      -48098
    route[108]  R609      1
    route[108]  R610      -47300
    route[109]  OBJ       2.4385938086130025e+02
    route[109]  R434      -1
    route[109]  R435      -18
    route[109]  R436      -600.000001
    route[109]  R437      -40.000001
    route[109]  R602      1
    route[109]  R603      1
    route[109]  R604      -45493
    route[109]  R605      1
    route[109]  R606      1
    route[109]  R607      -48098
    route[109]  R609      1
    route[109]  R610      -47300
    route[110]  OBJ       2.1345197954973435e+02
    route[110]  R438      -1
    route[110]  R439      -11
    route[110]  R440      -600.000001
    route[110]  R441      -40.000001
    route[110]  R602      1
    route[110]  R603      1
    route[110]  R604      -45493
    route[110]  R606      1
    route[110]  R607      -48098
    route[110]  R608      1
    route[110]  R609      1
    route[110]  R610      -47300
    route[111]  OBJ       2.3247606054724375e+02
    route[111]  R442      -1
    route[111]  R443      -4
    route[111]  R444      -600.000001
    route[111]  R445      -40.000001
    route[111]  R602      1
    route[111]  R603      1
    route[111]  R604      -45493
    route[111]  R606      1
    route[111]  R607      -48098
    route[111]  R609      1
    route[111]  R610      -47300
    route[111]  R611      1
    route[112]  OBJ       2.4385938086130025e+02
    route[112]  R446      -1
    route[112]  R447      -11
    route[112]  R448      -1
    route[112]  R449      -18
    route[112]  R450      -600.000001
    route[112]  R451      -40.000001
    route[112]  R602      1
    route[112]  R603      1
    route[112]  R604      -45493
    route[112]  R605      1
    route[112]  R606      1
    route[112]  R607      -48098
    route[112]  R608      1
    route[112]  R609      1
    route[112]  R610      -47300
    route[113]  OBJ       2.3247606054724375e+02
    route[113]  R452      -1
    route[113]  R453      -11
    route[113]  R454      -1
    route[113]  R455      -4
    route[113]  R456      -600.000001
    route[113]  R457      -40.000001
    route[113]  R602      1
    route[113]  R603      1
    route[113]  R604      -45493
    route[113]  R606      1
    route[113]  R607      -48098
    route[113]  R608      1
    route[113]  R609      1
    route[113]  R610      -47300
    route[113]  R611      1
    route[114]  OBJ       2.3338441451329726e+02
    route[114]  R458      -600.000001
    route[114]  R459      -40.000001
    route[114]  R602      1
    route[114]  R603      1
    route[114]  R604      -46936
    route[114]  R606      1
    route[114]  R607      -45668
    route[114]  R609      1
    route[114]  R610      -48743
    route[115]  OBJ       2.5554285407973586e+02
    route[115]  R460      -1
    route[115]  R461      -11
    route[115]  R462      -600.000001
    route[115]  R463      -40.000001
    route[115]  R602      1
    route[115]  R603      1
    route[115]  R604      -46936
    route[115]  R606      1
    route[115]  R607      -45668
    route[115]  R608      1
    route[115]  R609      1
    route[115]  R610      -48743
    route[116]  OBJ       2.3338441451329726e+02
    route[116]  R464      -1
    route[116]  R465      -4
    route[116]  R466      -600.000001
    route[116]  R467      -40.000001
    route[116]  R602      1
    route[116]  R603      1
    route[116]  R604      -46936
    route[116]  R606      1
    route[116]  R607      -45668
    route[116]  R609      1
    route[116]  R610      -48743
    route[116]  R611      1
    route[117]  OBJ       2.5554285407973586e+02
    route[117]  R468      -1
    route[117]  R469      -4
    route[117]  R470      -1
    route[117]  R471      -11
    route[117]  R472      -600.000001
    route[117]  R473      -40.000001
    route[117]  R602      1
    route[117]  R603      1
    route[117]  R604      -46936
    route[117]  R606      1
    route[117]  R607      -45668
    route[117]  R608      1
    route[117]  R609      1
    route[117]  R610      -48743
    route[117]  R611      1
    route[118]  OBJ       2.1345197954973435e+02
    route[118]  R474      -600.000001
    route[118]  R475      -40.000001
    route[118]  R602      1
    route[118]  R603      1
    route[118]  R604      -48273
    route[118]  R606      1
    route[118]  R607      -45668
    route[118]  R609      1
    route[118]  R610      -46466
    route[119]  OBJ       2.1345197954973435e+02
    route[119]  R476      -1
    route[119]  R477      -18
    route[119]  R478      -600.000001
    route[119]  R479      -40.000001
    route[119]  R602      1
    route[119]  R603      1
    route[119]  R604      -48273
    route[119]  R605      1
    route[119]  R606      1
    route[119]  R607      -45668
    route[119]  R609      1
    route[119]  R610      -46466
    route[120]  OBJ       2.5554285407973586e+02
    route[120]  R480      -1
    route[120]  R481      -11
    route[120]  R482      -600.000001
    route[120]  R483      -40.000001
    route[120]  R602      1
    route[120]  R603      1
    route[120]  R604      -48273
    route[120]  R606      1
    route[120]  R607      -45668
    route[120]  R608      1
    route[120]  R609      1
    route[120]  R610      -46466
    route[121]  OBJ       2.3338441451329726e+02
    route[121]  R484      -600.000001
    route[121]  R485      -40.000001
    route[121]  R602      1
    route[121]  R603      1
    route[121]  R604      -47428
    route[121]  R606      1
    route[121]  R607      -48696
    route[121]  R609      1
    route[121]  R610      -45621
    route[122]  OBJ       2.6379181582486319e+02
    route[122]  R486      -1
    route[122]  R487      -18
    route[122]  R488      -600.000001
    route[122]  R489      -40.000001
    route[122]  R602      1
    route[122]  R603      1
    route[122]  R604      -47428
    route[122]  R605      1
    route[122]  R606      1
    route[122]  R607      -48696
    route[122]  R609      1
    route[122]  R610      -45621
    route[123]  OBJ       2.3338441451329726e+02
    route[123]  R490      -1
    route[123]  R491      -11
    route[123]  R492      -600.000001
    route[123]  R493      -40.000001
    route[123]  R602      1
    route[123]  R603      1
    route[123]  R604      -47428
    route[123]  R606      1
    route[123]  R607      -48696
    route[123]  R608      1
    route[123]  R609      1
    route[123]  R610      -45621
    route[124]  OBJ       2.5240849551080666e+02
    route[124]  R494      -1
    route[124]  R495      -4
    route[124]  R496      -600.000001
    route[124]  R497      -40.000001
    route[124]  R602      1
    route[124]  R603      1
    route[124]  R604      -47428
    route[124]  R606      1
    route[124]  R607      -48696
    route[124]  R609      1
    route[124]  R610      -45621
    route[124]  R611      1
    route[125]  OBJ       2.6379181582486319e+02
    route[125]  R498      -1
    route[125]  R499      -11
    route[125]  R500      -1
    route[125]  R501      -18
    route[125]  R502      -600.000001
    route[125]  R503      -40.000001
    route[125]  R602      1
    route[125]  R603      1
    route[125]  R604      -47428
    route[125]  R605      1
    route[125]  R606      1
    route[125]  R607      -48696
    route[125]  R608      1
    route[125]  R609      1
    route[125]  R610      -45621
    route[126]  OBJ       2.5240849551080666e+02
    route[126]  R504      -1
    route[126]  R505      -11
    route[126]  R506      -1
    route[126]  R507      -4
    route[126]  R508      -600.000001
    route[126]  R509      -40.000001
    route[126]  R602      1
    route[126]  R603      1
    route[126]  R604      -47428
    route[126]  R606      1
    route[126]  R607      -48696
    route[126]  R608      1
    route[126]  R609      1
    route[126]  R610      -45621
    route[126]  R611      1
    route[127]  OBJ       1.9393061725458284e+02
    route[127]  R510      -600.000001
    route[127]  R511      -40.000001
    route[127]  R602      1
    route[127]  R603      1
    route[127]  R604      -47687
    route[127]  R606      1
    route[127]  R607      -46419
    route[127]  R609      1
    route[127]  R610      -45621
    route[128]  OBJ       1.9393061725458284e+02
    route[128]  R512      -1
    route[128]  R513      -18
    route[128]  R514      -600.000001
    route[128]  R515      -40.000001
    route[128]  R602      1
    route[128]  R603      1
    route[128]  R604      -47687
    route[128]  R605      1
    route[128]  R606      1
    route[128]  R607      -46419
    route[128]  R609      1
    route[128]  R610      -45621
    route[129]  OBJ       2.3602149178458436e+02
    route[129]  R516      -1
    route[129]  R517      -11
    route[129]  R518      -600.000001
    route[129]  R519      -40.000001
    route[129]  R602      1
    route[129]  R603      1
    route[129]  R604      -47687
    route[129]  R606      1
    route[129]  R607      -46419
    route[129]  R608      1
    route[129]  R609      1
    route[129]  R610      -45621
    route[130]  OBJ       1.3281566172707193e+02
    route[130]  R520      -600.000001
    route[130]  R521      -40.000001
    route[130]  R612      1
    route[130]  R613      1
    route[130]  R614      -59893
    route[131]  OBJ       1.3281566172707193e+02
    route[131]  R522      -1
    route[131]  R523      -18
    route[131]  R524      -600.000001
    route[131]  R525      -40.000001
    route[131]  R612      1
    route[131]  R613      1
    route[131]  R614      -59893
    route[131]  R615      1
    route[132]  OBJ       1.7490653625707344e+02
    route[132]  R526      -1
    route[132]  R527      -11
    route[132]  R528      -600.000001
    route[132]  R529      -40.000001
    route[132]  R612      1
    route[132]  R613      1
    route[132]  R614      -59893
    route[132]  R618      1
    route[133]  OBJ       1.4449913494550754e+02
    route[133]  R530      -600.000001
    route[133]  R531      -40.000001
    route[133]  R612      1
    route[133]  R616      1
    route[133]  R617      -60068
    route[134]  OBJ       1.7490653625707344e+02
    route[134]  R532      -1
    route[134]  R533      -18
    route[134]  R534      -600.000001
    route[134]  R535      -40.000001
    route[134]  R612      1
    route[134]  R615      1
    route[134]  R616      1
    route[134]  R617      -60068
    route[135]  OBJ       1.4449913494550754e+02
    route[135]  R536      -1
    route[135]  R537      -11
    route[135]  R538      -600.000001
    route[135]  R539      -40.000001
    route[135]  R612      1
    route[135]  R616      1
    route[135]  R617      -60068
    route[135]  R618      1
    route[136]  OBJ       1.6352321594301694e+02
    route[136]  R540      -1
    route[136]  R541      -4
    route[136]  R542      -600.000001
    route[136]  R543      -40.000001
    route[136]  R612      1
    route[136]  R616      1
    route[136]  R617      -60068
    route[136]  R619      1
    route[137]  OBJ       1.7490653625707344e+02
    route[137]  R544      -1
    route[137]  R545      -11
    route[137]  R546      -1
    route[137]  R547      -18
    route[137]  R548      -600.000001
    route[137]  R549      -40.000001
    route[137]  R612      1
    route[137]  R615      1
    route[137]  R616      1
    route[137]  R617      -60068
    route[137]  R618      1
    route[138]  OBJ       1.6352321594301694e+02
    route[138]  R550      -1
    route[138]  R551      -11
    route[138]  R552      -1
    route[138]  R553      -4
    route[138]  R554      -600.000001
    route[138]  R555      -40.000001
    route[138]  R612      1
    route[138]  R616      1
    route[138]  R617      -60068
    route[138]  R618      1
    route[138]  R619      1
    route[139]  OBJ       1.7490653625707344e+02
    route[139]  R556      -600.000001
    route[139]  R557      -40.000001
    route[139]  R612      1
    route[139]  R613      1
    route[139]  R614      -59893
    route[139]  R616      1
    route[139]  R617      -61161
    route[140]  OBJ       2.0531393756863935e+02
    route[140]  R558      -1
    route[140]  R559      -18
    route[140]  R560      -600.000001
    route[140]  R561      -40.000001
    route[140]  R612      1
    route[140]  R613      1
    route[140]  R614      -59893
    route[140]  R615      1
    route[140]  R616      1
    route[140]  R617      -61161
    route[141]  OBJ       1.7490653625707344e+02
    route[141]  R562      -1
    route[141]  R563      -11
    route[141]  R564      -600.000001
    route[141]  R565      -40.000001
    route[141]  R612      1
    route[141]  R613      1
    route[141]  R614      -59893
    route[141]  R616      1
    route[141]  R617      -61161
    route[141]  R618      1
    route[142]  OBJ       1.9393061725458284e+02
    route[142]  R566      -1
    route[142]  R567      -4
    route[142]  R568      -600.000001
    route[142]  R569      -40.000001
    route[142]  R612      1
    route[142]  R613      1
    route[142]  R614      -59893
    route[142]  R616      1
    route[142]  R617      -61161
    route[142]  R619      1
    route[143]  OBJ       2.0531393756863935e+02
    route[143]  R570      -1
    route[143]  R571      -11
    route[143]  R572      -1
    route[143]  R573      -18
    route[143]  R574      -600.000001
    route[143]  R575      -40.000001
    route[143]  R612      1
    route[143]  R613      1
    route[143]  R614      -59893
    route[143]  R615      1
    route[143]  R616      1
    route[143]  R617      -61161
    route[143]  R618      1
    route[144]  OBJ       1.9393061725458284e+02
    route[144]  R576      -1
    route[144]  R577      -11
    route[144]  R578      -1
    route[144]  R579      -4
    route[144]  R580      -600.000001
    route[144]  R581      -40.000001
    route[144]  R612      1
    route[144]  R613      1
    route[144]  R614      -59893
    route[144]  R616      1
    route[144]  R617      -61161
    route[144]  R618      1
    route[144]  R619      1
    route[145]  OBJ       1.7490653625707344e+02
    route[145]  R582      -600.000001
    route[145]  R583      -40.000001
    route[145]  R612      1
    route[145]  R613      1
    route[145]  R614      -61336
    route[145]  R616      1
    route[145]  R617      -60068
    route[146]  OBJ       1.7490653625707344e+02
    route[146]  R584      -1
    route[146]  R585      -18
    route[146]  R586      -600.000001
    route[146]  R587      -40.000001
    route[146]  R612      1
    route[146]  R613      1
    route[146]  R614      -61336
    route[146]  R615      1
    route[146]  R616      1
    route[146]  R617      -60068
    route[147]  OBJ       2.1699741078707495e+02
    route[147]  R588      -1
    route[147]  R589      -11
    route[147]  R590      -600.000001
    route[147]  R591      -40.000001
    route[147]  R612      1
    route[147]  R613      1
    route[147]  R614      -61336
    route[147]  R616      1
    route[147]  R617      -60068
    route[147]  R618      1
    quantity_1_S1  R2        1
    quantity_1_S1  R3        1
    quantity_1_S1  R4        2
    quantity_1_S1  R5        1
    quantity_1_S1  R720      1
    quantity_1_S1  clean_stock_b2  1
    quantity_1_S1  clean_stock_b3  1
    quantity_2_S3  R6        1
    quantity_2_S3  R7        1
    quantity_2_S3  R8        2
    quantity_2_S3  R9        1
    quantity_2_S3  R721      1
    quantity_2_S3  clean_stock_b3  1
    quantity_4_S1  R12       1
    quantity_4_S1  R13       1
    quantity_4_S1  R14       2
    quantity_4_S1  R15       1
    quantity_4_S1  R720      1
    quantity_4_S1  clean_stock_b3  1
    quantity_5_S3  R16       1
    quantity_5_S3  R17       1
    quantity_5_S3  R18       2
    quantity_5_S3  R19       1
    quantity_5_S3  R721      1
    quantity_5_S3  clean_stock_b2  1
    quantity_5_S3  clean_stock_b3  1
    quantity_6_S4  R20       1
    quantity_6_S4  R21       1
    quantity_6_S4  R22       2
    quantity_6_S4  R23       1
    quantity_6_S4  R722      1
    quantity_6_S4  clean_stock_b3  1
    quantity_7_S3  R24       1
    quantity_7_S3  R25       1
    quantity_7_S3  R28       2
    quantity_7_S3  R29       1
    quantity_7_S3  R721      1
    quantity_7_S3  clean_stock_b3  1
    quantity_7_S1  R26       1
    quantity_7_S1  R27       1
    quantity_7_S1  R28       2
    quantity_7_S1  R29       1
    quantity_7_S1  R720      1
    quantity_7_S1  clean_stock_b3  1
    quantity_8_S3  R30       1
    quantity_8_S3  R31       1
    quantity_8_S3  R34       2
    quantity_8_S3  R35       1
    quantity_8_S3  R721      1
    quantity_8_S3  clean_stock_b3  1
    quantity_8_S4  R32       1
    quantity_8_S4  R33       1
    quantity_8_S4  R34       2
    quantity_8_S4  R35       1
    quantity_8_S4  R722      1
    quantity_8_S4  clean_stock_b3  1
    quantity_10_S3  R38       1
    quantity_10_S3  R39       1
    quantity_10_S3  R40       2
    quantity_10_S3  R41       1
    quantity_10_S3  R721      1
    quantity_10_S3  clean_stock_b3  1
    quantity_11_S4  R42       1
    quantity_11_S4  R43       1
    quantity_11_S4  R44       2
    quantity_11_S4  R45       1
    quantity_11_S4  R722      1
    quantity_11_S4  clean_stock_b2  1
    quantity_11_S4  clean_stock_b3  1
    quantity_12_S4  R46       1
    quantity_12_S4  R47       1
    quantity_12_S4  R50       2
    quantity_12_S4  R51       1
    quantity_12_S4  R722      1
    quantity_12_S4  clean_stock_b3  1
    quantity_12_S3  R48       1
    quantity_12_S3  R49       1
    quantity_12_S3  R50       2
    quantity_12_S3  R51       1
    quantity_12_S3  R721      1
    quantity_12_S3  clean_stock_b3  1
    quantity_14_S1  R54       1
    quantity_14_S1  R55       1
    quantity_14_S1  R56       2
    quantity_14_S1  R57       1
    quantity_14_S1  R720      1
    quantity_14_S1  clean_stock_b3  1
    quantity_15_S3  R58       1
    quantity_15_S3  R59       1
    quantity_15_S3  R60       2
    quantity_15_S3  R61       1
    quantity_15_S3  R721      1
    quantity_15_S3  clean_stock_b2  1
    quantity_15_S3  clean_stock_b3  1
    quantity_16_S4  R62       1
    quantity_16_S4  R63       1
    quantity_16_S4  R64       2
    quantity_16_S4  R65       1
    quantity_16_S4  R722      1
    quantity_16_S4  clean_stock_b3  1
    quantity_17_S3  R66       1
    quantity_17_S3  R67       1
    quantity_17_S3  R70       2
    quantity_17_S3  R71       1
    quantity_17_S3  R721      1
    quantity_17_S3  clean_stock_b3  1
    quantity_17_S1  R68       1
    quantity_17_S1  R69       1
    quantity_17_S1  R70       2
    quantity_17_S1  R71       1
    quantity_17_S1  R720      1
    quantity_17_S1  clean_stock_b3  1
    quantity_18_S3  R72       1
    quantity_18_S3  R73       1
    quantity_18_S3  R76       2
    quantity_18_S3  R77       1
    quantity_18_S3  R721      1
    quantity_18_S3  clean_stock_b3  1
    quantity_18_S4  R74       1
    quantity_18_S4  R75       1
    quantity_18_S4  R76       2
    quantity_18_S4  R77       1
    quantity_18_S4  R722      1
    quantity_18_S4  clean_stock_b3  1
    quantity_20_S3  R80       1
    quantity_20_S3  R81       1
    quantity_20_S3  R82       2
    quantity_20_S3  R83       1
    quantity_20_S3  R721      1
    quantity_20_S3  clean_stock_b3  1
    quantity_21_S4  R84       1
    quantity_21_S4  R85       1
    quantity_21_S4  R86       2
    quantity_21_S4  R87       1
    quantity_21_S4  R722      1
    quantity_21_S4  clean_stock_b2  1
    quantity_21_S4  clean_stock_b3  1
    quantity_22_S4  R88       1
    quantity_22_S4  R89       1
    quantity_22_S4  R92       2
    quantity_22_S4  R93       1
    quantity_22_S4  R722      1
    quantity_22_S4  clean_stock_b3  1
    quantity_22_S3  R90       1
    quantity_22_S3  R91       1
    quantity_22_S3  R92       2
    quantity_22_S3  R93       1
    quantity_22_S3  R721      1
    quantity_22_S3  clean_stock_b3  1
    quantity_24_S1  R96       1
    quantity_24_S1  R97       1
    quantity_24_S1  R98       2
    quantity_24_S1  R99       1
    quantity_24_S1  R720      1
    quantity_24_S1  clean_stock_b2  1
    quantity_24_S1  clean_stock_b3  1
    quantity_25_S3  R100      1
    quantity_25_S3  R101      1
    quantity_25_S3  R102      2
    quantity_25_S3  R103      1
    quantity_25_S3  R721      1
    quantity_25_S3  clean_stock_b3  1
    quantity_27_S3  R106      1
    quantity_27_S3  R107      1
    quantity_27_S3  R108      2
    quantity_27_S3  R109      1
    quantity_27_S3  R721      1
    quantity_27_S3  clean_stock_b3  1
    quantity_28_S4  R110      1
    quantity_28_S4  R111      1
    quantity_28_S4  R112      2
    quantity_28_S4  R113      1
    quantity_28_S4  R722      1
    quantity_28_S4  clean_stock_b2  1
    quantity_28_S4  clean_stock_b3  1
    quantity_29_S4  R114      1
    quantity_29_S4  R115      1
    quantity_29_S4  R118      2
    quantity_29_S4  R119      1
    quantity_29_S4  R722      1
    quantity_29_S4  clean_stock_b3  1
    quantity_29_S3  R116      1
    quantity_29_S3  R117      1
    quantity_29_S3  R118      2
    quantity_29_S3  R119      1
    quantity_29_S3  R721      1
    quantity_29_S3  clean_stock_b3  1
    quantity_31_S1  R122      1
    quantity_31_S1  R123      1
    quantity_31_S1  R124      2
    quantity_31_S1  R125      1
    quantity_31_S1  R720      1
    quantity_31_S1  clean_stock_b2  1
    quantity_31_S1  clean_stock_b3  1
    quantity_32_S3  R126      1
    quantity_32_S3  R127      1
    quantity_32_S3  R128      2
    quantity_32_S3  R129      1
    quantity_32_S3  R721      1
    quantity_32_S3  clean_stock_b3  1
    quantity_34_S1  R132      1
    quantity_34_S1  R133      1
    quantity_34_S1  R134      2
    quantity_34_S1  R135      1
    quantity_34_S1  R720      1
    quantity_34_S1  clean_stock_b3  1
    quantity_35_S3  R136      1
    quantity_35_S3  R137      1
    quantity_35_S3  R138      2
    quantity_35_S3  R139      1
    quantity_35_S3  R721      1
    quantity_35_S3  clean_stock_b2  1
    quantity_35_S3  clean_stock_b3  1
    quantity_36_S4  R140      1
    quantity_36_S4  R141      1
    quantity_36_S4  R142      2
    quantity_36_S4  R143      1
    quantity_36_S4  R722      1
    quantity_36_S4  clean_stock_b3  1
    quantity_37_S3  R144      1
    quantity_37_S3  R145      1
    quantity_37_S3  R148      2
    quantity_37_S3  R149      1
    quantity_37_S3  R721      1
    quantity_37_S3  clean_stock_b3  1
    quantity_37_S1  R146      1
    quantity_37_S1  R147      1
    quantity_37_S1  R148      2
    quantity_37_S1  R149      1
    quantity_37_S1  R720      1
    quantity_37_S1  clean_stock_b3  1
    quantity_38_S3  R150      1
    quantity_38_S3  R151      1
    quantity_38_S3  R154      2
    quantity_38_S3  R155      1
    quantity_38_S3  R721      1
    quantity_38_S3  clean_stock_b3  1
    quantity_38_S4  R152      1
    quantity_38_S4  R153      1
    quantity_38_S4  R154      2
    quantity_38_S4  R155      1
    quantity_38_S4  R722      1
    quantity_38_S4  clean_stock_b3  1
    quantity_40_S3  R158      1
    quantity_40_S3  R159      1
    quantity_40_S3  R160      2
    quantity_40_S3  R161      1
    quantity_40_S3  R721      1
    quantity_40_S3  clean_stock_b3  1
    quantity_41_S4  R162      1
    quantity_41_S4  R163      1
    quantity_41_S4  R164      2
    quantity_41_S4  R165      1
    quantity_41_S4  R722      1
    quantity_41_S4  clean_stock_b2  1
    quantity_41_S4  clean_stock_b3  1
    quantity_42_S4  R166      1
    quantity_42_S4  R167      1
    quantity_42_S4  R170      2
    quantity_42_S4  R171      1
    quantity_42_S4  R722      1
    quantity_42_S4  clean_stock_b3  1
    quantity_42_S3  R168      1
    quantity_42_S3  R169      1
    quantity_42_S3  R170      2
    quantity_42_S3  R171      1
    quantity_42_S3  R721      1
    quantity_42_S3  clean_stock_b3  1
    quantity_44_S1  R174      1
    quantity_44_S1  R175      1
    quantity_44_S1  R176      2
    quantity_44_S1  R177      1
    quantity_44_S1  R720      1
    quantity_44_S1  clean_stock_b3  1
    quantity_45_S3  R178      1
    quantity_45_S3  R179      1
    quantity_45_S3  R180      2
    quantity_45_S3  R181      1
    quantity_45_S3  R721      1
    quantity_45_S3  clean_stock_b2  1
    quantity_45_S3  clean_stock_b3  1
    quantity_46_S4  R182      1
    quantity_46_S4  R183      1
    quantity_46_S4  R184      2
    quantity_46_S4  R185      1
    quantity_46_S4  R722      1
    quantity_46_S4  clean_stock_b3  1
    quantity_47_S3  R186      1
    quantity_47_S3  R187      1
    quantity_47_S3  R190      2
    quantity_47_S3  R191      1
    quantity_47_S3  R721      1
    quantity_47_S3  clean_stock_b3  1
    quantity_47_S1  R188      1
    quantity_47_S1  R189      1
    quantity_47_S1  R190      2
    quantity_47_S1  R191      1
    quantity_47_S1  R720      1
    quantity_47_S1  clean_stock_b3  1
    quantity_48_S3  R192      1
    quantity_48_S3  R193      1
    quantity_48_S3  R196      2
    quantity_48_S3  R197      1
    quantity_48_S3  R721      1
    quantity_48_S3  clean_stock_b3  1
    quantity_48_S4  R194      1
    quantity_48_S4  R195      1
    quantity_48_S4  R196      2
    quantity_48_S4  R197      1
    quantity_48_S4  R722      1
    quantity_48_S4  clean_stock_b3  1
    quantity_50_S3  R200      1
    quantity_50_S3  R201      1
    quantity_50_S3  R202      2
    quantity_50_S3  R203      1
    quantity_50_S3  R721      1
    quantity_50_S3  clean_stock_b3  1
    quantity_51_S4  R204      1
    quantity_51_S4  R205      1
    quantity_51_S4  R206      2
    quantity_51_S4  R207      1
    quantity_51_S4  R722      1
    quantity_51_S4  clean_stock_b2  1
    quantity_51_S4  clean_stock_b3  1
    quantity_52_S4  R208      1
    quantity_52_S4  R209      1
    quantity_52_S4  R212      2
    quantity_52_S4  R213      1
    quantity_52_S4  R722      1
    quantity_52_S4  clean_stock_b3  1
    quantity_52_S3  R210      1
    quantity_52_S3  R211      1
    quantity_52_S3  R212      2
    quantity_52_S3  R213      1
    quantity_52_S3  R721      1
    quantity_52_S3  clean_stock_b3  1
    quantity_54_S1  R216      1
    quantity_54_S1  R217      1
    quantity_54_S1  R218      2
    quantity_54_S1  R219      1
    quantity_54_S1  R720      1
    quantity_54_S1  clean_stock_b2  1
    quantity_54_S1  clean_stock_b3  1
    quantity_55_S3  R220      1
    quantity_55_S3  R221      1
    quantity_55_S3  R222      2
    quantity_55_S3  R223      1
    quantity_55_S3  R721      1
    quantity_55_S3  clean_stock_b3  1
    quantity_57_S1  R226      1
    quantity_57_S1  R227      1
    quantity_57_S1  R228      2
    quantity_57_S1  R229      1
    quantity_57_S1  R720      1
    quantity_57_S1  clean_stock_b3  1
    quantity_58_S3  R230      1
    quantity_58_S3  R231      1
    quantity_58_S3  R232      2
    quantity_58_S3  R233      1
    quantity_58_S3  R721      1
    quantity_58_S3  clean_stock_b2  1
    quantity_58_S3  clean_stock_b3  1
    quantity_59_S4  R234      1
    quantity_59_S4  R235      1
    quantity_59_S4  R236      2
    quantity_59_S4  R237      1
    quantity_59_S4  R722      1
    quantity_59_S4  clean_stock_b3  1
    quantity_60_S3  R238      1
    quantity_60_S3  R239      1
    quantity_60_S3  R242      2
    quantity_60_S3  R243      1
    quantity_60_S3  R721      1
    quantity_60_S3  clean_stock_b3  1
    quantity_60_S1  R240      1
    quantity_60_S1  R241      1
    quantity_60_S1  R242      2
    quantity_60_S1  R243      1
    quantity_60_S1  R720      1
    quantity_60_S1  clean_stock_b3  1
    quantity_61_S3  R244      1
    quantity_61_S3  R245      1
    quantity_61_S3  R248      2
    quantity_61_S3  R249      1
    quantity_61_S3  R721      1
    quantity_61_S3  clean_stock_b3  1
    quantity_61_S4  R246      1
    quantity_61_S4  R247      1
    quantity_61_S4  R248      2
    quantity_61_S4  R249      1
    quantity_61_S4  R722      1
    quantity_61_S4  clean_stock_b3  1
    quantity_63_S1  R252      1
    quantity_63_S1  R253      1
    quantity_63_S1  R254      2
    quantity_63_S1  R255      1
    quantity_63_S1  R720      1
    quantity_63_S1  clean_stock_b2  1
    quantity_63_S1  clean_stock_b3  1
    quantity_64_S3  R256      1
    quantity_64_S3  R257      1
    quantity_64_S3  R258      2
    quantity_64_S3  R259      1
    quantity_64_S3  R721      1
    quantity_64_S3  clean_stock_b3  1
    quantity_66_S1  R262      1
    quantity_66_S1  R263      1
    quantity_66_S1  R264      2
    quantity_66_S1  R265      1
    quantity_66_S1  R723      1
    quantity_66_S1  clean_stock_b3  1
    quantity_67_S3  R266      1
    quantity_67_S3  R267      1
    quantity_67_S3  R268      2
    quantity_67_S3  R269      1
    quantity_67_S3  R724      1
    quantity_69_S1  R272      1
    quantity_69_S1  R273      1
    quantity_69_S1  R274      2
    quantity_69_S1  R275      1
    quantity_69_S1  R723      1
    quantity_70_S3  R276      1
    quantity_70_S3  R277      1
    quantity_70_S3  R278      2
    quantity_70_S3  R279      1
    quantity_70_S3  R724      1
    quantity_70_S3  clean_stock_b3  1
    quantity_71_S4  R280      1
    quantity_71_S4  R281      1
    quantity_71_S4  R282      2
    quantity_71_S4  R283      1
    quantity_71_S4  R725      1
    quantity_72_S3  R284      1
    quantity_72_S3  R285      1
    quantity_72_S3  R288      2
    quantity_72_S3  R289      1
    quantity_72_S3  R724      1
    quantity_72_S1  R286      1
    quantity_72_S1  R287      1
    quantity_72_S1  R288      2
    quantity_72_S1  R289      1
    quantity_72_S1  R723      1
    quantity_73_S3  R290      1
    quantity_73_S3  R291      1
    quantity_73_S3  R294      2
    quantity_73_S3  R295      1
    quantity_73_S3  R724      1
    quantity_73_S4  R292      1
    quantity_73_S4  R293      1
    quantity_73_S4  R294      2
    quantity_73_S4  R295      1
    quantity_73_S4  R725      1
    quantity_75_S3  R298      1
    quantity_75_S3  R299      1
    quantity_75_S3  R300      2
    quantity_75_S3  R301      1
    quantity_75_S3  R724      1
    quantity_76_S4  R302      1
    quantity_76_S4  R303      1
    quantity_76_S4  R304      2
    quantity_76_S4  R305      1
    quantity_76_S4  R725      1
    quantity_76_S4  clean_stock_b3  1
    quantity_77_S4  R306      1
    quantity_77_S4  R307      1
    quantity_77_S4  R310      2
    quantity_77_S4  R311      1
    quantity_77_S4  R725      1
    quantity_77_S3  R308      1
    quantity_77_S3  R309      1
    quantity_77_S3  R310      2
    quantity_77_S3  R311      1
    quantity_77_S3  R724      1
    quantity_79_S1  R314      1
    quantity_79_S1  R315      1
    quantity_79_S1  R316      2
    quantity_79_S1  R317      1
    quantity_79_S1  R723      1
    quantity_80_S3  R318      1
    quantity_80_S3  R319      1
    quantity_80_S3  R320      2
    quantity_80_S3  R321      1
    quantity_80_S3  R724      1
    quantity_80_S3  clean_stock_b3  1
    quantity_81_S4  R322      1
    quantity_81_S4  R323      1
    quantity_81_S4  R324      2
    quantity_81_S4  R325      1
    quantity_81_S4  R725      1
    quantity_82_S3  R326      1
    quantity_82_S3  R327      1
    quantity_82_S3  R330      2
    quantity_82_S3  R331      1
    quantity_82_S3  R724      1
    quantity_82_S1  R328      1
    quantity_82_S1  R329      1
    quantity_82_S1  R330      2
    quantity_82_S1  R331      1
    quantity_82_S1  R723      1
    quantity_83_S3  R332      1
    quantity_83_S3  R333      1
    quantity_83_S3  R336      2
    quantity_83_S3  R337      1
    quantity_83_S3  R724      1
    quantity_83_S4  R334      1
    quantity_83_S4  R335      1
    quantity_83_S4  R336      2
    quantity_83_S4  R337      1
    quantity_83_S4  R725      1
    quantity_85_S3  R340      1
    quantity_85_S3  R341      1
    quantity_85_S3  R342      2
    quantity_85_S3  R343      1
    quantity_85_S3  R724      1
    quantity_86_S4  R344      1
    quantity_86_S4  R345      1
    quantity_86_S4  R346      2
    quantity_86_S4  R347      1
    quantity_86_S4  R725      1
    quantity_86_S4  clean_stock_b3  1
    quantity_87_S4  R348      1
    quantity_87_S4  R349      1
    quantity_87_S4  R352      2
    quantity_87_S4  R353      1
    quantity_87_S4  R725      1
    quantity_87_S3  R350      1
    quantity_87_S3  R351      1
    quantity_87_S3  R352      2
    quantity_87_S3  R353      1
    quantity_87_S3  R724      1
    quantity_89_S1  R356      1
    quantity_89_S1  R357      1
    quantity_89_S1  R358      2
    quantity_89_S1  R359      1
    quantity_89_S1  R723      1
    quantity_89_S1  clean_stock_b3  1
    quantity_90_S3  R360      1
    quantity_90_S3  R361      1
    quantity_90_S3  R362      2
    quantity_90_S3  R363      1
    quantity_90_S3  R724      1
    quantity_92_S3  R366      1
    quantity_92_S3  R367      1
    quantity_92_S3  R368      2
    quantity_92_S3  R369      1
    quantity_92_S3  R724      1
    quantity_93_S4  R370      1
    quantity_93_S4  R371      1
    quantity_93_S4  R372      2
    quantity_93_S4  R373      1
    quantity_93_S4  R725      1
    quantity_93_S4  clean_stock_b3  1
    quantity_94_S4  R374      1
    quantity_94_S4  R375      1
    quantity_94_S4  R378      2
    quantity_94_S4  R379      1
    quantity_94_S4  R725      1
    quantity_94_S3  R376      1
    quantity_94_S3  R377      1
    quantity_94_S3  R378      2
    quantity_94_S3  R379      1
    quantity_94_S3  R724      1
    quantity_96_S1  R382      1
    quantity_96_S1  R383      1
    quantity_96_S1  R384      2
    quantity_96_S1  R385      1
    quantity_96_S1  R723      1
    quantity_96_S1  clean_stock_b3  1
    quantity_97_S3  R386      1
    quantity_97_S3  R387      1
    quantity_97_S3  R388      2
    quantity_97_S3  R389      1
    quantity_97_S3  R724      1
    quantity_99_S1  R392      1
    quantity_99_S1  R393      1
    quantity_99_S1  R394      2
    quantity_99_S1  R395      1
    quantity_99_S1  R723      1
    quantity_100_S3  R396      1
    quantity_100_S3  R397      1
    quantity_100_S3  R398      2
    quantity_100_S3  R399      1
    quantity_100_S3  R724      1
    quantity_100_S3  clean_stock_b3  1
    quantity_101_S4  R400      1
    quantity_101_S4  R401      1
    quantity_101_S4  R402      2
    quantity_101_S4  R403      1
    quantity_101_S4  R725      1
    quantity_102_S3  R404      1
    quantity_102_S3  R405      1
    quantity_102_S3  R408      2
    quantity_102_S3  R409      1
    quantity_102_S3  R724      1
    quantity_102_S1  R406      1
    quantity_102_S1  R407      1
    quantity_102_S1  R408      2
    quantity_102_S1  R409      1
    quantity_102_S1  R723      1
    quantity_103_S3  R410      1
    quantity_103_S3  R411      1
    quantity_103_S3  R414      2
    quantity_103_S3  R415      1
    quantity_103_S3  R724      1
    quantity_103_S4  R412      1
    quantity_103_S4  R413      1
    quantity_103_S4  R414      2
    quantity_103_S4  R415      1
    quantity_103_S4  R725      1
    quantity_105_S3  R418      1
    quantity_105_S3  R419      1
    quantity_105_S3  R420      2
    quantity_105_S3  R421      1
    quantity_105_S3  R724      1
    quantity_106_S4  R422      1
    quantity_106_S4  R423      1
    quantity_106_S4  R424      2
    quantity_106_S4  R425      1
    quantity_106_S4  R725      1
    quantity_106_S4  clean_stock_b3  1
    quantity_107_S4  R426      1
    quantity_107_S4  R427      1
    quantity_107_S4  R430      2
    quantity_107_S4  R431      1
    quantity_107_S4  R725      1
    quantity_107_S3  R428      1
    quantity_107_S3  R429      1
    quantity_107_S3  R430      2
    quantity_107_S3  R431      1
    quantity_107_S3  R724      1
    quantity_109_S1  R434      1
    quantity_109_S1  R435      1
    quantity_109_S1  R436      2
    quantity_109_S1  R437      1
    quantity_109_S1  R723      1
    quantity_110_S3  R438      1
    quantity_110_S3  R439      1
    quantity_110_S3  R440      2
    quantity_110_S3  R441      1
    quantity_110_S3  R724      1
    quantity_110_S3  clean_stock_b3  1
    quantity_111_S4  R442      1
    quantity_111_S4  R443      1
    quantity_111_S4  R444      2
    quantity_111_S4  R445      1
    quantity_111_S4  R725      1
    quantity_112_S3  R446      1
    quantity_112_S3  R447      1
    quantity_112_S3  R450      2
    quantity_112_S3  R451      1
    quantity_112_S3  R724      1
    quantity_112_S1  R448      1
    quantity_112_S1  R449      1
    quantity_112_S1  R450      2
    quantity_112_S1  R451      1
    quantity_112_S1  R723      1
    quantity_113_S3  R452      1
    quantity_113_S3  R453      1
    quantity_113_S3  R456      2
    quantity_113_S3  R457      1
    quantity_113_S3  R724      1
    quantity_113_S4  R454      1
    quantity_113_S4  R455      1
    quantity_113_S4  R456      2
    quantity_113_S4  R457      1
    quantity_113_S4  R725      1
    quantity_115_S3  R460      1
    quantity_115_S3  R461      1
    quantity_115_S3  R462      2
    quantity_115_S3  R463      1
    quantity_115_S3  R724      1
    quantity_116_S4  R464      1
    quantity_116_S4  R465      1
    quantity_116_S4  R466      2
    quantity_116_S4  R467      1
    quantity_116_S4  R725      1
    quantity_116_S4  clean_stock_b3  1
    quantity_117_S4  R468      1
    quantity_117_S4  R469      1
    quantity_117_S4  R472      2
    quantity_117_S4  R473      1
    quantity_117_S4  R725      1
    quantity_117_S3  R470      1
    quantity_117_S3  R471      1
    quantity_117_S3  R472      2
    quantity_117_S3  R473      1
    quantity_117_S3  R724      1
    quantity_119_S1  R476      1
    quantity_119_S1  R477      1
    quantity_119_S1  R478      2
    quantity_119_S1  R479      1
    quantity_119_S1  R723      1
    quantity_119_S1  clean_stock_b3  1
    quantity_120_S3  R480      1
    quantity_120_S3  R481      1
    quantity_120_S3  R482      2
    quantity_120_S3  R483      1
    quantity_120_S3  R724      1
    quantity_122_S1  R486      1
    quantity_122_S1  R487      1
    quantity_122_S1  R488      2
    quantity_122_S1  R489      1
    quantity_122_S1  R723      1
    quantity_123_S3  R490      1
    quantity_123_S3  R491      1
    quantity_123_S3  R492      2
    quantity_123_S3  R493      1
    quantity_123_S3  R724      1
    quantity_123_S3  clean_stock_b3  1
    quantity_124_S4  R494      1
    quantity_124_S4  R495      1
    quantity_124_S4  R496      2
    quantity_124_S4  R497      1
    quantity_124_S4  R725      1
    quantity_125_S3  R498      1
    quantity_125_S3  R499      1
    quantity_125_S3  R502      2
    quantity_125_S3  R503      1
    quantity_125_S3  R724      1
    quantity_125_S1  R500      1
    quantity_125_S1  R501      1
    quantity_125_S1  R502      2
    quantity_125_S1  R503      1
    quantity_125_S1  R723      1
    quantity_126_S3  R504      1
    quantity_126_S3  R505      1
    quantity_126_S3  R508      2
    quantity_126_S3  R509      1
    quantity_126_S3  R724      1
    quantity_126_S4  R506      1
    quantity_126_S4  R507      1
    quantity_126_S4  R508      2
    quantity_126_S4  R509      1
    quantity_126_S4  R725      1
    quantity_128_S1  R512      1
    quantity_128_S1  R513      1
    quantity_128_S1  R514      2
    quantity_128_S1  R515      1
    quantity_128_S1  R723      1
    quantity_128_S1  clean_stock_b3  1
    quantity_129_S3  R516      1
    quantity_129_S3  R517      1
    quantity_129_S3  R518      2
    quantity_129_S3  R519      1
    quantity_129_S3  R724      1
    quantity_131_S1  R522      1
    quantity_131_S1  R523      1
    quantity_131_S1  R524      2
    quantity_131_S1  R525      1
    quantity_131_S1  R726      1
    quantity_132_S3  R526      1
    quantity_132_S3  R527      1
    quantity_132_S3  R528      2
    quantity_132_S3  R529      1
    quantity_132_S3  R727      1
    quantity_134_S1  R532      1
    quantity_134_S1  R533      1
    quantity_134_S1  R534      2
    quantity_134_S1  R535      1
    quantity_134_S1  R726      1
    quantity_135_S3  R536      1
    quantity_135_S3  R537      1
    quantity_135_S3  R538      2
    quantity_135_S3  R539      1
    quantity_135_S3  R727      1
    quantity_136_S4  R540      1
    quantity_136_S4  R541      1
    quantity_136_S4  R542      2
    quantity_136_S4  R543      1
    quantity_136_S4  R728      1
    quantity_137_S3  R544      1
    quantity_137_S3  R545      1
    quantity_137_S3  R548      2
    quantity_137_S3  R549      1
    quantity_137_S3  R727      1
    quantity_137_S1  R546      1
    quantity_137_S1  R547      1
    quantity_137_S1  R548      2
    quantity_137_S1  R549      1
    quantity_137_S1  R726      1
    quantity_138_S3  R550      1
    quantity_138_S3  R551      1
    quantity_138_S3  R554      2
    quantity_138_S3  R555      1
    quantity_138_S3  R727      1
    quantity_138_S4  R552      1
    quantity_138_S4  R553      1
    quantity_138_S4  R554      2
    quantity_138_S4  R555      1
    quantity_138_S4  R728      1
    quantity_140_S1  R558      1
    quantity_140_S1  R559      1
    quantity_140_S1  R560      2
    quantity_140_S1  R561      1
    quantity_140_S1  R726      1
    quantity_141_S3  R562      1
    quantity_141_S3  R563      1
    quantity_141_S3  R564      2
    quantity_141_S3  R565      1
    quantity_141_S3  R727      1
    quantity_142_S4  R566      1
    quantity_142_S4  R567      1
    quantity_142_S4  R568      2
    quantity_142_S4  R569      1
    quantity_142_S4  R728      1
    quantity_143_S3  R570      1
    quantity_143_S3  R571      1
    quantity_143_S3  R574      2
    quantity_143_S3  R575      1
    quantity_143_S3  R727      1
    quantity_143_S1  R572      1
    quantity_143_S1  R573      1
    quantity_143_S1  R574      2
    quantity_143_S1  R575      1
    quantity_143_S1  R726      1
    quantity_144_S3  R576      1
    quantity_144_S3  R577      1
    quantity_144_S3  R580      2
    quantity_144_S3  R581      1
    quantity_144_S3  R727      1
    quantity_144_S4  R578      1
    quantity_144_S4  R579      1
    quantity_144_S4  R580      2
    quantity_144_S4  R581      1
    quantity_144_S4  R728      1
    quantity_146_S1  R584      1
    quantity_146_S1  R585      1
    quantity_146_S1  R586      2
    quantity_146_S1  R587      1
    quantity_146_S1  R726      1
    quantity_147_S3  R588      1
    quantity_147_S3  R589      1
    quantity_147_S3  R590      2
    quantity_147_S3  R591      1
    quantity_147_S3  R727      1
    supply_S1_b1  R594      1
    supply_S1_b1  R620      1
    supply_S1_b1  R621      -1
    supply_S1_b1  R625      1
    supply_S1_b1  R626      -1
    supply_S1_b1  R630      1
    supply_S1_b1  R631      -1
    supply_S1_b1  R635      1
    supply_S1_b1  R636      -1
    supply_S1_b1  GC211     -1
    supply_S1_b1  GC271     -1
    supply_S1_b1  GC339     -1
    supply_S1_b1  GC395     -1
    supply_S1_b1  GC488     -1
    supply_S1_b1  GC564     -1
    supply_S1_b1  GC626     -1
    supply_S1_b1  GC688     -1
    supply_S3_b1  R597      1
    supply_S3_b1  R670      1
    supply_S3_b1  R671      -1
    supply_S3_b1  R675      1
    supply_S3_b1  R676      -1
    supply_S3_b1  R680      1
    supply_S3_b1  R681      -1
    supply_S3_b1  GC763     -1
    supply_S3_b1  GC827     -1
    supply_S3_b1  GC889     -1
    supply_S3_b1  GC950     -1
    supply_S3_b1  GC1025    -1
    supply_S3_b1  GC1087    -1
    supply_S3_b1  GC1151    -1
    supply_S3_b1  GC1214    -1
    supply_S4_b1  R600      1
    supply_S4_b1  R710      1
    supply_S4_b1  R711      -1
    supply_S4_b1  GC1235    -1
    supply_S4_b1  GC1255    -1
    supply_S4_b1  GC1275    -1
    supply_S4_b1  GC1294    -1
    supply_S1_b2  R604      1
    supply_S1_b2  R640      1
    supply_S1_b2  R641      -1
    supply_S1_b2  R645      1
    supply_S1_b2  R646      -1
    supply_S1_b2  R650      1
    supply_S1_b2  R651      -1
    supply_S1_b2  GC212     -1
    supply_S1_b2  GC272     -1
    supply_S1_b2  GC338     -1
    supply_S1_b2  GC396     -1
    supply_S1_b2  GC489     -1
    supply_S1_b2  GC565     -1
    supply_S1_b2  GC625     -1
    supply_S1_b2  GC689     -1
    supply_S3_b2  R607      1
    supply_S3_b2  R685      1
    supply_S3_b2  R686      -1
    supply_S3_b2  R690      1
    supply_S3_b2  R691      -1
    supply_S3_b2  R695      1
    supply_S3_b2  R696      -1
    supply_S3_b2  GC762     -1
    supply_S3_b2  GC829     -1
    supply_S3_b2  GC888     -1
    supply_S3_b2  GC951     -1
    supply_S3_b2  GC1024    -1
    supply_S3_b2  GC1088    -1
    supply_S3_b2  GC1150    -1
    supply_S3_b2  GC1215    -1
    supply_S4_b2  R610      1
    supply_S4_b2  R715      1
    supply_S4_b2  R716      -1
    supply_S4_b2  GC1234    -1
    supply_S4_b2  GC1254    -1
    supply_S4_b2  GC1274    -1
    supply_S4_b2  GC1295    -1
    supply_S1_b3  R614      1
    supply_S1_b3  R655      1
    supply_S1_b3  R656      -1
    supply_S1_b3  R660      1
    supply_S1_b3  R661      -1
    supply_S1_b3  R665      1
    supply_S1_b3  R666      -1
    supply_S1_b3  GC210     -1
    supply_S1_b3  GC273     -1
    supply_S1_b3  GC340     -1
    supply_S1_b3  GC394     -1
    supply_S1_b3  GC487     -1
    supply_S1_b3  GC566     -1
    supply_S1_b3  GC627     -1
    supply_S1_b3  GC687     -1
    supply_S3_b3  R617      1
    supply_S3_b3  R700      1
    supply_S3_b3  R701      -1
    supply_S3_b3  R705      1
    supply_S3_b3  R706      -1
    supply_S3_b3  GC764     -1
    supply_S3_b3  GC828     -1
    supply_S3_b3  GC890     -1
    supply_S3_b3  GC949     -1
    supply_S3_b3  GC1026    -1
    supply_S3_b3  GC1089    -1
    supply_S3_b3  GC1152    -1
    supply_S3_b3  GC1213    -1
    delivery_C81_order  R621      1
    delivery_C81_order  R622      -1
    delivery_C81_order  GC124     1
    delivery_C81_order  GC172     -1
    delivery_C81_order  GC213     1
    delivery_C81_order  GC249     -1
    delivery_C81_order  GC288     1
    delivery_C81_order  GC324     -1
    delivery_C81_order  GC353     1
    delivery_C81_order  GC375     -1
    delivery_C81_order  GC401     1
    delivery_C81_order  GC449     -1
    delivery_C81_order  GC492     1
    delivery_C81_order  GC546     -1
    delivery_C81_order  GC577     1
    delivery_C81_order  GC605     -1
    delivery_C81_order  GC642     1
    delivery_C81_order  GC672     -1
    delivery_C81_order  GC1298    -1
    delivery_C81_order  GC1316    -1
    delivery_C81_order  GC1336    -1
    delivery_C81_order  GC1348    1
    delivery_C81_order  GC1380    -1
    delivery_C81_order  GC1440    -1
    pickup_time_C81_order  R622      1
    pickup_time_C81_order  R623      -1
    pickup_time_C81_order  GC132     1
    pickup_time_C81_order  GC164     -1
    pickup_time_C81_order  GC225     1
    pickup_time_C81_order  GC233     -1
    pickup_time_C81_order  GC290     1
    pickup_time_C81_order  GC355     1
    pickup_time_C81_order  GC409     1
    pickup_time_C81_order  GC441     -1
    pickup_time_C81_order  GC510     1
    pickup_time_C81_order  GC520     -1
    pickup_time_C81_order  GC581     1
    pickup_time_C81_order  GC644     1
    pickup_time_C81_order  GC1298    1
    pickup_time_C81_order  GC1318    -1
    pickup_time_C81_order  GC1344    1
    pickup_time_C81_order  GC1370    1
    pickup_time_C81_order  GC1378    1
    pickup_time_C81_order  GC1388    -1
    pickup_time_C81_order  GC1436    1
    pickup_time_C81_order  GC1438    -1
    e2_return_C81_order  R623      1
    e2_return_C81_order  GC0       1
    e2_return_C81_order  GC1       1
    e2_return_C81_order  GC2       1
    e2_return_C81_order  GC3       1
    e2_return_C81_order  GC4       1
    e2_return_C81_order  GC5       1
    e2_return_C81_order  GC201     1
    e2_return_C81_order  GC265     1
    e2_return_C81_order  GC337     1
    e2_return_C81_order  GC392     1
    e2_return_C81_order  GC478     1
    e2_return_C81_order  GC556     1
    e2_return_C81_order  GC624     1
    e2_return_C81_order  GC685     1
    cutoff_C81_order_b1  R624      1
    cutoff_C81_order_b1  R720      -2
    cutoff_C81_order_b2  R624      1
    cutoff_C81_order_b2  R723      -2
    cutoff_C81_order_b3  R624      1
    cutoff_C81_order_b3  R726      -2
    delivery_C90_order  R626      1
    delivery_C90_order  R627      -1
    delivery_C90_order  GC126     1
    delivery_C90_order  GC174     -1
    delivery_C90_order  GC215     1
    delivery_C90_order  GC243     -1
    delivery_C90_order  GC276     1
    delivery_C90_order  GC318     -1
    delivery_C90_order  GC343     1
    delivery_C90_order  GC369     -1
    delivery_C90_order  GC403     1
    delivery_C90_order  GC451     -1
    delivery_C90_order  GC490     1
    delivery_C90_order  GC532     -1
    delivery_C90_order  GC569     1
    delivery_C90_order  GC599     -1
    delivery_C90_order  GC632     1
    delivery_C90_order  GC666     -1
    delivery_C90_order  GC1300    -1
    delivery_C90_order  GC1316    1
    delivery_C90_order  GC1338    1
    delivery_C90_order  GC1348    -1
    delivery_C90_order  GC1362    -1
    delivery_C90_order  GC1384    -1
    delivery_C90_order  GC1392    -1
    delivery_C90_order  GC1436    -1
    delivery_C90_order  GC1444    -1
    delivery_C90_order  GC1448    1
    pickup_time_C90_order  R627      1
    pickup_time_C90_order  R628      -1
    pickup_time_C90_order  GC134     1
    pickup_time_C90_order  GC166     -1
    pickup_time_C90_order  GC227     1
    pickup_time_C90_order  GC235     -1
    pickup_time_C90_order  GC292     1
    pickup_time_C90_order  GC302     -1
    pickup_time_C90_order  GC357     1
    pickup_time_C90_order  GC411     1
    pickup_time_C90_order  GC443     -1
    pickup_time_C90_order  GC500     1
    pickup_time_C90_order  GC516     -1
    pickup_time_C90_order  GC583     1
    pickup_time_C90_order  GC646     1
    pickup_time_C90_order  GC656     -1
    pickup_time_C90_order  GC1300    1
    pickup_time_C90_order  GC1328    -1
    pickup_time_C90_order  GC1334    -1
    pickup_time_C90_order  GC1344    -1
    pickup_time_C90_order  GC1372    1
    pickup_time_C90_order  GC1386    1
    pickup_time_C90_order  GC1390    -1
    pickup_time_C90_order  GC1394    1
    pickup_time_C90_order  GC1414    -1
    pickup_time_C90_order  GC1434    -1
    pickup_time_C90_order  GC1438    1
    pickup_time_C90_order  GC1440    1
    pickup_time_C90_order  GC1442    -1
    pickup_time_C90_order  GC1446    -1
    pickup_time_C90_order  GC1450    -1
    pickup_time_C90_order  GC1452    1
    e2_return_C90_order  R628      1
    e2_return_C90_order  GC6       1
    e2_return_C90_order  GC7       1
    e2_return_C90_order  GC8       1
    e2_return_C90_order  GC9       1
    e2_return_C90_order  GC10      1
    e2_return_C90_order  GC11      1
    e2_return_C90_order  GC202     1
    e2_return_C90_order  GC266     1
    e2_return_C90_order  GC332     1
    e2_return_C90_order  GC390     1
    e2_return_C90_order  GC479     1
    e2_return_C90_order  GC554     1
    e2_return_C90_order  GC623     1
    e2_return_C90_order  GC682     1
    cutoff_C90_order_b1  R629      1
    cutoff_C90_order_b1  R720      -2
    cutoff_C90_order_b2  R629      1
    cutoff_C90_order_b2  R723      -2
    cutoff_C90_order_b3  R629      1
    cutoff_C90_order_b3  R726      -2
    delivery_C97_order  R631      1
    delivery_C97_order  R632      -1
    delivery_C97_order  GC136     1
    delivery_C97_order  GC190     -1
    delivery_C97_order  GC217     1
    delivery_C97_order  GC413     1
    delivery_C97_order  GC467     -1
    delivery_C97_order  GC498     1
    delivery_C97_order  GC1306    -1
    delivery_C97_order  GC1336    1
    delivery_C97_order  GC1338    -1
    delivery_C97_order  GC1346    -1
    delivery_C97_order  GC1362    1
    delivery_C97_order  GC1382    -1
    delivery_C97_order  GC1452    -1
    pickup_time_C97_order  R632      1
    pickup_time_C97_order  R633      -1
    pickup_time_C97_order  GC150     1
    pickup_time_C97_order  GC176     -1
    pickup_time_C97_order  GC237     -1
    pickup_time_C97_order  GC427     1
    pickup_time_C97_order  GC453     -1
    pickup_time_C97_order  GC526     -1
    pickup_time_C97_order  GC1306    1
    pickup_time_C97_order  GC1368    1
    pickup_time_C97_order  GC1370    -1
    pickup_time_C97_order  GC1372    -1
    pickup_time_C97_order  GC1374    1
    pickup_time_C97_order  GC1376    -1
    pickup_time_C97_order  GC1390    1
    pickup_time_C97_order  GC1444    1
    e2_return_C97_order  R633      1
    e2_return_C97_order  GC12      1
    e2_return_C97_order  GC13      1
    e2_return_C97_order  GC14      1
    e2_return_C97_order  GC15      1
    e2_return_C97_order  GC16      1
    e2_return_C97_order  GC17      1
    e2_return_C97_order  GC205     1
    e2_return_C97_order  GC264     1
    e2_return_C97_order  GC482     1
    e2_return_C97_order  GC559     1
    cutoff_C97_order_b1  R634      1
    cutoff_C97_order_b1  R720      -2
    cutoff_C97_order_b2  R634      1
    cutoff_C97_order_b2  R723      -2
    cutoff_C97_order_b3  R634      1
    cutoff_C97_order_b3  R726      -2
    delivery_C51_order  R636      1
    delivery_C51_order  R637      -1
    delivery_C51_order  GC146     1
    delivery_C51_order  GC198     -1
    delivery_C51_order  GC261     -1
    delivery_C51_order  GC328     -1
    delivery_C51_order  GC385     -1
    delivery_C51_order  GC423     1
    delivery_C51_order  GC475     -1
    delivery_C51_order  GC502     1
    delivery_C51_order  GC552     -1
    delivery_C51_order  GC615     -1
    delivery_C51_order  GC678     -1
    delivery_C51_order  GC1314    -1
    delivery_C51_order  GC1346    1
    delivery_C51_order  GC1374    -1
    delivery_C51_order  GC1380    1
    delivery_C51_order  GC1384    1
    delivery_C51_order  GC1394    -1
    delivery_C51_order  GC1448    -1
    pickup_time_C51_order  R637      1
    pickup_time_C51_order  R638      -1
    pickup_time_C51_order  GC158     1
    pickup_time_C51_order  GC186     -1
    pickup_time_C51_order  GC435     1
    pickup_time_C51_order  GC463     -1
    pickup_time_C51_order  GC536     -1
    pickup_time_C51_order  GC1314    1
    pickup_time_C51_order  GC1368    -1
    pickup_time_C51_order  GC1376    1
    pickup_time_C51_order  GC1378    -1
    pickup_time_C51_order  GC1382    1
    pickup_time_C51_order  GC1386    -1
    pickup_time_C51_order  GC1392    1
    pickup_time_C51_order  GC1450    1
    e2_return_C51_order  R638      1
    e2_return_C51_order  GC18      1
    e2_return_C51_order  GC19      1
    e2_return_C51_order  GC20      1
    e2_return_C51_order  GC21      1
    e2_return_C51_order  GC22      1
    e2_return_C51_order  GC23      1
    e2_return_C51_order  GC209     1
    e2_return_C51_order  GC263     1
    e2_return_C51_order  GC486     1
    e2_return_C51_order  GC560     1
    cutoff_C51_order_b1  R639      1
    cutoff_C51_order_b1  R720      -1
    cutoff_C51_order_b2  R639      1
    cutoff_C51_order_b2  R723      -1
    cutoff_C51_order_b3  R639      1
    cutoff_C51_order_b3  R726      -1
    delivery_C0_order  R641      1
    delivery_C0_order  R642      -1
    delivery_C0_order  GC128     1
    delivery_C0_order  GC182     -1
    delivery_C0_order  GC221     1
    delivery_C0_order  GC251     -1
    delivery_C0_order  GC274     1
    delivery_C0_order  GC314     -1
    delivery_C0_order  GC345     1
    delivery_C0_order  GC377     -1
    delivery_C0_order  GC405     1
    delivery_C0_order  GC459     -1
    delivery_C0_order  GC494     1
    delivery_C0_order  GC548     -1
    delivery_C0_order  GC573     1
    delivery_C0_order  GC607     -1
    delivery_C0_order  GC634     1
    delivery_C0_order  GC674     -1
    delivery_C0_order  GC1302    -1
    delivery_C0_order  GC1320    -1
    delivery_C0_order  GC1350    -1
    delivery_C0_order  GC1352    -1
    delivery_C0_order  GC1410    -1
    delivery_C0_order  GC1412    -1
    pickup_time_C0_order  R642      1
    pickup_time_C0_order  R643      -1
    pickup_time_C0_order  GC142     1
    pickup_time_C0_order  GC168     -1
    pickup_time_C0_order  GC284     1
    pickup_time_C0_order  GC298     -1
    pickup_time_C0_order  GC419     1
    pickup_time_C0_order  GC445     -1
    pickup_time_C0_order  GC522     -1
    pickup_time_C0_order  GC593     -1
    pickup_time_C0_order  GC658     -1
    pickup_time_C0_order  GC1302    1
    pickup_time_C0_order  GC1324    -1
    pickup_time_C0_order  GC1330    -1
    pickup_time_C0_order  GC1334    1
    pickup_time_C0_order  GC1396    1
    pickup_time_C0_order  GC1398    -1
    pickup_time_C0_order  GC1400    -1
    pickup_time_C0_order  GC1402    1
    pickup_time_C0_order  GC1404    -1
    pickup_time_C0_order  GC1406    1
    pickup_time_C0_order  GC1408    1
    e2_return_C0_order  R643      1
    e2_return_C0_order  GC24      1
    e2_return_C0_order  GC25      1
    e2_return_C0_order  GC26      1
    e2_return_C0_order  GC27      1
    e2_return_C0_order  GC28      1
    e2_return_C0_order  GC29      1
    e2_return_C0_order  GC203     1
    e2_return_C0_order  GC269     1
    e2_return_C0_order  GC330     1
    e2_return_C0_order  GC391     1
    e2_return_C0_order  GC480     1
    e2_return_C0_order  GC557     1
    e2_return_C0_order  GC621     1
    e2_return_C0_order  GC683     1
    cutoff_C0_order_b1  R644      1
    cutoff_C0_order_b1  R720      -2
    cutoff_C0_order_b2  R644      1
    cutoff_C0_order_b2  R723      -2
    cutoff_C0_order_b3  R644      1
    cutoff_C0_order_b3  R726      -2
    delivery_C39_order  R646      1
    delivery_C39_order  R647      -1
    delivery_C39_order  GC138     1
    delivery_C39_order  GC192     -1
    delivery_C39_order  GC229     1
    delivery_C39_order  GC245     -1
    delivery_C39_order  GC280     1
    delivery_C39_order  GC320     -1
    delivery_C39_order  GC359     1
    delivery_C39_order  GC371     -1
    delivery_C39_order  GC415     1
    delivery_C39_order  GC469     -1
    delivery_C39_order  GC506     1
    delivery_C39_order  GC542     -1
    delivery_C39_order  GC567     1
    delivery_C39_order  GC601     -1
    delivery_C39_order  GC648     1
    delivery_C39_order  GC668     -1
    delivery_C39_order  GC1308    -1
    delivery_C39_order  GC1322    1
    delivery_C39_order  GC1340    -1
    delivery_C39_order  GC1350    1
    delivery_C39_order  GC1406    -1
    delivery_C39_order  GC1456    -1
    pickup_time_C39_order  R647      1
    pickup_time_C39_order  R648      -1
    pickup_time_C39_order  GC152     1
    pickup_time_C39_order  GC178     -1
    pickup_time_C39_order  GC308     -1
    pickup_time_C39_order  GC429     1
    pickup_time_C39_order  GC455     -1
    pickup_time_C39_order  GC530     -1
    pickup_time_C39_order  GC587     -1
    pickup_time_C39_order  GC1308    1
    pickup_time_C39_order  GC1354    -1
    pickup_time_C39_order  GC1364    1
    pickup_time_C39_order  GC1366    -1
    pickup_time_C39_order  GC1396    -1
    pickup_time_C39_order  GC1400    1
    pickup_time_C39_order  GC1410    1
    pickup_time_C39_order  GC1442    1
    pickup_time_C39_order  GC1454    -1
    pickup_time_C39_order  GC1458    1
    e2_return_C39_order  R648      1
    e2_return_C39_order  GC30      1
    e2_return_C39_order  GC31      1
    e2_return_C39_order  GC32      1
    e2_return_C39_order  GC33      1
    e2_return_C39_order  GC34      1
    e2_return_C39_order  GC35      1
    e2_return_C39_order  GC206     1
    e2_return_C39_order  GC334     1
    e2_return_C39_order  GC393     1
    e2_return_C39_order  GC483     1
    e2_return_C39_order  GC562     1
    e2_return_C39_order  GC618     1
    e2_return_C39_order  GC686     1
    cutoff_C39_order_b1  R649      1
    cutoff_C39_order_b1  R720      -2
    cutoff_C39_order_b2  R649      1
    cutoff_C39_order_b2  R723      -2
    cutoff_C39_order_b3  R649      1
    cutoff_C39_order_b3  R726      -2
    delivery_C52_order  R651      1
    delivery_C52_order  R652      -1
    delivery_C52_order  GC144     1
    delivery_C52_order  GC196     -1
    delivery_C52_order  GC255     -1
    delivery_C52_order  GC294     1
    delivery_C52_order  GC316     -1
    delivery_C52_order  GC361     1
    delivery_C52_order  GC381     -1
    delivery_C52_order  GC421     1
    delivery_C52_order  GC473     -1
    delivery_C52_order  GC512     1
    delivery_C52_order  GC540     -1
    delivery_C52_order  GC571     1
    delivery_C52_order  GC611     -1
    delivery_C52_order  GC650     1
    delivery_C52_order  GC676     -1
    delivery_C52_order  GC1312    -1
    delivery_C52_order  GC1320    1
    delivery_C52_order  GC1322    -1
    delivery_C52_order  GC1340    1
    delivery_C52_order  GC1408    -1
    delivery_C52_order  GC1458    -1
    pickup_time_C52_order  R652      1
    pickup_time_C52_order  R653      -1
    pickup_time_C52_order  GC156     1
    pickup_time_C52_order  GC184     -1
    pickup_time_C52_order  GC310     -1
    pickup_time_C52_order  GC433     1
    pickup_time_C52_order  GC461     -1
    pickup_time_C52_order  GC534     -1
    pickup_time_C52_order  GC597     -1
    pickup_time_C52_order  GC1312    1
    pickup_time_C52_order  GC1364    -1
    pickup_time_C52_order  GC1402    -1
    pickup_time_C52_order  GC1404    1
    pickup_time_C52_order  GC1412    1
    pickup_time_C52_order  GC1446    1
    pickup_time_C52_order  GC1456    1
    e2_return_C52_order  R653      1
    e2_return_C52_order  GC36      1
    e2_return_C52_order  GC37      1
    e2_return_C52_order  GC38      1
    e2_return_C52_order  GC39      1
    e2_return_C52_order  GC40      1
    e2_return_C52_order  GC41      1
    e2_return_C52_order  GC208     1
    e2_return_C52_order  GC336     1
    e2_return_C52_order  GC485     1
    e2_return_C52_order  GC563     1
    e2_return_C52_order  GC617     1
    cutoff_C52_order_b1  R654      1
    cutoff_C52_order_b1  R720      -2
    cutoff_C52_order_b2  R654      1
    cutoff_C52_order_b2  R723      -2
    cutoff_C52_order_b3  R654      1
    cutoff_C52_order_b3  R726      -2
    delivery_C85_order  R656      1
    delivery_C85_order  R657      -1
    delivery_C85_order  GC120     1
    delivery_C85_order  GC162     -1
    delivery_C85_order  GC223     1
    delivery_C85_order  GC247     -1
    delivery_C85_order  GC282     1
    delivery_C85_order  GC322     -1
    delivery_C85_order  GC341     1
    delivery_C85_order  GC373     -1
    delivery_C85_order  GC397     1
    delivery_C85_order  GC439     -1
    delivery_C85_order  GC504     1
    delivery_C85_order  GC544     -1
    delivery_C85_order  GC579     1
    delivery_C85_order  GC603     -1
    delivery_C85_order  GC630     1
    delivery_C85_order  GC670     -1
    delivery_C85_order  GC1296    -1
    delivery_C85_order  GC1332    -1
    delivery_C85_order  GC1342    -1
    delivery_C85_order  GC1418    -1
    delivery_C85_order  GC1430    -1
    pickup_time_C85_order  R657      1
    pickup_time_C85_order  R658      -1
    pickup_time_C85_order  GC122     1
    pickup_time_C85_order  GC160     -1
    pickup_time_C85_order  GC219     1
    pickup_time_C85_order  GC241     -1
    pickup_time_C85_order  GC286     1
    pickup_time_C85_order  GC300     -1
    pickup_time_C85_order  GC351     1
    pickup_time_C85_order  GC363     -1
    pickup_time_C85_order  GC399     1
    pickup_time_C85_order  GC437     -1
    pickup_time_C85_order  GC508     1
    pickup_time_C85_order  GC518     -1
    pickup_time_C85_order  GC575     1
    pickup_time_C85_order  GC589     -1
    pickup_time_C85_order  GC640     1
    pickup_time_C85_order  GC654     -1
    pickup_time_C85_order  GC1296    1
    pickup_time_C85_order  GC1318    1
    pickup_time_C85_order  GC1326    1
    pickup_time_C85_order  GC1328    1
    pickup_time_C85_order  GC1330    1
    pickup_time_C85_order  GC1356    1
    pickup_time_C85_order  GC1360    -1
    pickup_time_C85_order  GC1366    1
    pickup_time_C85_order  GC1416    1
    pickup_time_C85_order  GC1432    -1
    pickup_time_C85_order  GC1460    1
    e2_return_C85_order  R658      1
    e2_return_C85_order  GC42      1
    e2_return_C85_order  GC43      1
    e2_return_C85_order  GC44      1
    e2_return_C85_order  GC45      1
    e2_return_C85_order  GC46      1
    e2_return_C85_order  GC47      1
    e2_return_C85_order  GC200     1
    e2_return_C85_order  GC268     1
    e2_return_C85_order  GC331     1
    e2_return_C85_order  GC388     1
    e2_return_C85_order  GC477     1
    e2_return_C85_order  GC555     1
    e2_return_C85_order  GC619     1
    e2_return_C85_order  GC681     1
    cutoff_C85_order_b1  R659      1
    cutoff_C85_order_b1  R720      -2
    cutoff_C85_order_b2  R659      1
    cutoff_C85_order_b2  R723      -2
    cutoff_C85_order_b3  R659      1
    cutoff_C85_order_b3  R726      -2
    delivery_C75_order  R661      1
    delivery_C75_order  R662      -1
    delivery_C75_order  GC130     1
    delivery_C75_order  GC188     -1
    delivery_C75_order  GC231     1
    delivery_C75_order  GC253     -1
    delivery_C75_order  GC278     1
    delivery_C75_order  GC326     -1
    delivery_C75_order  GC349     1
    delivery_C75_order  GC379     -1
    delivery_C75_order  GC407     1
    delivery_C75_order  GC465     -1
    delivery_C75_order  GC496     1
    delivery_C75_order  GC550     -1
    delivery_C75_order  GC585     1
    delivery_C75_order  GC609     -1
    delivery_C75_order  GC628     1
    delivery_C75_order  GC664     -1
    delivery_C75_order  GC1304    -1
    delivery_C75_order  GC1332    1
    delivery_C75_order  GC1358    1
    delivery_C75_order  GC1420    -1
    delivery_C75_order  GC1428    -1
    delivery_C75_order  GC1460    -1
    pickup_time_C75_order  R662      1
    pickup_time_C75_order  R663      -1
    pickup_time_C75_order  GC148     1
    pickup_time_C75_order  GC170     -1
    pickup_time_C75_order  GC257     -1
    pickup_time_C75_order  GC304     -1
    pickup_time_C75_order  GC365     -1
    pickup_time_C75_order  GC425     1
    pickup_time_C75_order  GC447     -1
    pickup_time_C75_order  GC524     -1
    pickup_time_C75_order  GC595     -1
    pickup_time_C75_order  GC638     1
    pickup_time_C75_order  GC652     -1
    pickup_time_C75_order  GC1304    1
    pickup_time_C75_order  GC1324    1
    pickup_time_C75_order  GC1326    -1
    pickup_time_C75_order  GC1352    1
    pickup_time_C75_order  GC1360    1
    pickup_time_C75_order  GC1422    -1
    pickup_time_C75_order  GC1424    1
    pickup_time_C75_order  GC1426    1
    pickup_time_C75_order  GC1430    1
    pickup_time_C75_order  GC1434    1
    pickup_time_C75_order  GC1454    1
    e2_return_C75_order  R663      1
    e2_return_C75_order  GC48      1
    e2_return_C75_order  GC49      1
    e2_return_C75_order  GC50      1
    e2_return_C75_order  GC51      1
    e2_return_C75_order  GC52      1
    e2_return_C75_order  GC53      1
    e2_return_C75_order  GC204     1
    e2_return_C75_order  GC270     1
    e2_return_C75_order  GC333     1
    e2_return_C75_order  GC389     1
    e2_return_C75_order  GC481     1
    e2_return_C75_order  GC558     1
    e2_return_C75_order  GC622     1
    e2_return_C75_order  GC680     1
    cutoff_C75_order_b1  R664      1
    cutoff_C75_order_b1  R720      -2
    cutoff_C75_order_b2  R664      1
    cutoff_C75_order_b2  R723      -2
    cutoff_C75_order_b3  R664      1
    cutoff_C75_order_b3  R726      -2
    delivery_C21_order  R666      1
    delivery_C21_order  R667      -1
    delivery_C21_order  GC140     1
    delivery_C21_order  GC194     -1
    delivery_C21_order  GC259     -1
    delivery_C21_order  GC296     1
    delivery_C21_order  GC312     -1
    delivery_C21_order  GC347     1
    delivery_C21_order  GC383     -1
    delivery_C21_order  GC417     1
    delivery_C21_order  GC471     -1
    delivery_C21_order  GC514     1
    delivery_C21_order  GC538     -1
    delivery_C21_order  GC613     -1
    delivery_C21_order  GC636     1
    delivery_C21_order  GC662     -1
    delivery_C21_order  GC1310    -1
    delivery_C21_order  GC1342    1
    delivery_C21_order  GC1358    -1
    delivery_C21_order  GC1416    -1
    delivery_C21_order  GC1420    1
    delivery_C21_order  GC1426    -1
    pickup_time_C21_order  R667      1
    pickup_time_C21_order  R668      -1
    pickup_time_C21_order  GC154     1
    pickup_time_C21_order  GC180     -1
    pickup_time_C21_order  GC239     -1
    pickup_time_C21_order  GC306     -1
    pickup_time_C21_order  GC367     -1
    pickup_time_C21_order  GC431     1
    pickup_time_C21_order  GC457     -1
    pickup_time_C21_order  GC528     -1
    pickup_time_C21_order  GC591     -1
    pickup_time_C21_order  GC660     -1
    pickup_time_C21_order  GC1310    1
    pickup_time_C21_order  GC1354    1
    pickup_time_C21_order  GC1356    -1
    pickup_time_C21_order  GC1388    1
    pickup_time_C21_order  GC1398    1
    pickup_time_C21_order  GC1414    1
    pickup_time_C21_order  GC1418    1
    pickup_time_C21_order  GC1422    1
    pickup_time_C21_order  GC1424    -1
    pickup_time_C21_order  GC1428    1
    pickup_time_C21_order  GC1432    1
    e2_return_C21_order  R668      1
    e2_return_C21_order  GC54      1
    e2_return_C21_order  GC55      1
    e2_return_C21_order  GC56      1
    e2_return_C21_order  GC57      1
    e2_return_C21_order  GC58      1
    e2_return_C21_order  GC59      1
    e2_return_C21_order  GC207     1
    e2_return_C21_order  GC267     1
    e2_return_C21_order  GC335     1
    e2_return_C21_order  GC387     1
    e2_return_C21_order  GC484     1
    e2_return_C21_order  GC561     1
    e2_return_C21_order  GC620     1
    e2_return_C21_order  GC684     1
    cutoff_C21_order_b1  R669      1
    cutoff_C21_order_b1  R720      -1
    cutoff_C21_order_b2  R669      1
    cutoff_C21_order_b2  R723      -1
    cutoff_C21_order_b3  R669      1
    cutoff_C21_order_b3  R726      -1
    delivery_C88_order  R671      1
    delivery_C88_order  R672      -1
    delivery_C88_order  GC692     1
    delivery_C88_order  GC732     -1
    delivery_C88_order  GC765     1
    delivery_C88_order  GC795     -1
    delivery_C88_order  GC834     1
    delivery_C88_order  GC862     -1
    delivery_C88_order  GC893     1
    delivery_C88_order  GC927     -1
    delivery_C88_order  GC954     1
    delivery_C88_order  GC994     -1
    delivery_C88_order  GC1029    1
    delivery_C88_order  GC1063    -1
    delivery_C88_order  GC1094    1
    delivery_C88_order  GC1130    -1
    delivery_C88_order  GC1155    1
    delivery_C88_order  GC1189    -1
    delivery_C88_order  GC1464    -1
    delivery_C88_order  GC1480    -1
    delivery_C88_order  GC1492    -1
    delivery_C88_order  GC1518    -1
    delivery_C88_order  GC1532    -1
    delivery_C88_order  GC1544    -1
    pickup_time_C88_order  R672      1
    pickup_time_C88_order  R673      -1
    pickup_time_C88_order  GC700     1
    pickup_time_C88_order  GC724     -1
    pickup_time_C88_order  GC771     1
    pickup_time_C88_order  GC787     -1
    pickup_time_C88_order  GC838     1
    pickup_time_C88_order  GC870     -1
    pickup_time_C88_order  GC901     1
    pickup_time_C88_order  GC917     -1
    pickup_time_C88_order  GC962     1
    pickup_time_C88_order  GC986     -1
    pickup_time_C88_order  GC1033    1
    pickup_time_C88_order  GC1055    -1
    pickup_time_C88_order  GC1104    1
    pickup_time_C88_order  GC1118    -1
    pickup_time_C88_order  GC1165    1
    pickup_time_C88_order  GC1181    -1
    pickup_time_C88_order  GC1464    1
    pickup_time_C88_order  GC1478    -1
    pickup_time_C88_order  GC1504    -1
    pickup_time_C88_order  GC1510    -1
    pickup_time_C88_order  GC1524    1
    pickup_time_C88_order  GC1528    1
    pickup_time_C88_order  GC1530    1
    pickup_time_C88_order  GC1534    -1
    pickup_time_C88_order  GC1536    -1
    pickup_time_C88_order  GC1538    -1
    pickup_time_C88_order  GC1540    -1
    pickup_time_C88_order  GC1542    1
    e2_return_C88_order  R673      1
    e2_return_C88_order  GC60      1
    e2_return_C88_order  GC61      1
    e2_return_C88_order  GC62      1
    e2_return_C88_order  GC63      1
    e2_return_C88_order  GC64      1
    e2_return_C88_order  GC65      1
    e2_return_C88_order  GC755     1
    e2_return_C88_order  GC819     1
    e2_return_C88_order  GC883     1
    e2_return_C88_order  GC942     1
    e2_return_C88_order  GC1017    1
    e2_return_C88_order  GC1084    1
    e2_return_C88_order  GC1144    1
    e2_return_C88_order  GC1206    1
    cutoff_C88_order_b1  R674      1
    cutoff_C88_order_b1  R721      -2
    cutoff_C88_order_b2  R674      1
    cutoff_C88_order_b2  R724      -2
    cutoff_C88_order_b3  R674      1
    cutoff_C88_order_b3  R727      -2
    delivery_C76_order  R676      1
    delivery_C76_order  R677      -1
    delivery_C76_order  GC698     1
    delivery_C76_order  GC740     -1
    delivery_C76_order  GC769     1
    delivery_C76_order  GC813     -1
    delivery_C76_order  GC846     1
    delivery_C76_order  GC868     -1
    delivery_C76_order  GC909     1
    delivery_C76_order  GC933     -1
    delivery_C76_order  GC960     1
    delivery_C76_order  GC1002    -1
    delivery_C76_order  GC1027    1
    delivery_C76_order  GC1069    -1
    delivery_C76_order  GC1110    1
    delivery_C76_order  GC1136    -1
    delivery_C76_order  GC1173    1
    delivery_C76_order  GC1197    -1
    delivery_C76_order  GC1468    -1
    delivery_C76_order  GC1480    1
    delivery_C76_order  GC1494    1
    delivery_C76_order  GC1512    -1
    delivery_C76_order  GC1528    -1
    delivery_C76_order  GC1576    -1
    pickup_time_C76_order  R677      1
    pickup_time_C76_order  R678      -1
    pickup_time_C76_order  GC708     1
    pickup_time_C76_order  GC730     -1
    pickup_time_C76_order  GC781     1
    pickup_time_C76_order  GC793     -1
    pickup_time_C76_order  GC844     1
    pickup_time_C76_order  GC907     1
    pickup_time_C76_order  GC970     1
    pickup_time_C76_order  GC992     -1
    pickup_time_C76_order  GC1041    1
    pickup_time_C76_order  GC1047    -1
    pickup_time_C76_order  GC1108    1
    pickup_time_C76_order  GC1171    1
    pickup_time_C76_order  GC1468    1
    pickup_time_C76_order  GC1490    -1
    pickup_time_C76_order  GC1500    -1
    pickup_time_C76_order  GC1510    1
    pickup_time_C76_order  GC1514    1
    pickup_time_C76_order  GC1524    -1
    pickup_time_C76_order  GC1532    1
    pickup_time_C76_order  GC1570    -1
    pickup_time_C76_order  GC1572    -1
    pickup_time_C76_order  GC1574    1
    pickup_time_C76_order  GC1578    -1
    pickup_time_C76_order  GC1580    -1
    e2_return_C76_order  R678      1
    e2_return_C76_order  GC66      1
    e2_return_C76_order  GC67      1
    e2_return_C76_order  GC68      1
    e2_return_C76_order  GC69      1
    e2_return_C76_order  GC70      1
    e2_return_C76_order  GC71      1
    e2_return_C76_order  GC757     1
    e2_return_C76_order  GC822     1
    e2_return_C76_order  GC886     1
    e2_return_C76_order  GC946     1
    e2_return_C76_order  GC1019    1
    e2_return_C76_order  GC1080    1
    e2_return_C76_order  GC1148    1
    e2_return_C76_order  GC1210    1
    cutoff_C76_order_b1  R679      1
    cutoff_C76_order_b1  R721      -1
    cutoff_C76_order_b2  R679      1
    cutoff_C76_order_b2  R724      -1
    cutoff_C76_order_b3  R679      1
    cutoff_C76_order_b3  R727      -1
    delivery_C27_order  R681      1
    delivery_C27_order  R682      -1
    delivery_C27_order  GC704     1
    delivery_C27_order  GC746     -1
    delivery_C27_order  GC783     1
    delivery_C27_order  GC803     -1
    delivery_C27_order  GC850     1
    delivery_C27_order  GC878     -1
    delivery_C27_order  GC911     1
    delivery_C27_order  GC939     -1
    delivery_C27_order  GC966     1
    delivery_C27_order  GC1008    -1
    delivery_C27_order  GC1031    1
    delivery_C27_order  GC1077    -1
    delivery_C27_order  GC1112    1
    delivery_C27_order  GC1140    -1
    delivery_C27_order  GC1175    1
    delivery_C27_order  GC1203    -1
    delivery_C27_order  GC1470    -1
    delivery_C27_order  GC1492    1
    delivery_C27_order  GC1494    -1
    delivery_C27_order  GC1512    1
    delivery_C27_order  GC1542    -1
    delivery_C27_order  GC1574    -1
    pickup_time_C27_order  R682      1
    pickup_time_C27_order  R683      -1
    pickup_time_C27_order  GC714     1
    pickup_time_C27_order  GC736     -1
    pickup_time_C27_order  GC797     -1
    pickup_time_C27_order  GC976     1
    pickup_time_C27_order  GC998     -1
    pickup_time_C27_order  GC1057    -1
    pickup_time_C27_order  GC1470    1
    pickup_time_C27_order  GC1500    1
    pickup_time_C27_order  GC1502    -1
    pickup_time_C27_order  GC1514    -1
    pickup_time_C27_order  GC1530    -1
    pickup_time_C27_order  GC1534    1
    pickup_time_C27_order  GC1544    1
    pickup_time_C27_order  GC1576    1
    e2_return_C27_order  R683      1
    e2_return_C27_order  GC72      1
    e2_return_C27_order  GC73      1
    e2_return_C27_order  GC74      1
    e2_return_C27_order  GC75      1
    e2_return_C27_order  GC76      1
    e2_return_C27_order  GC77      1
    e2_return_C27_order  GC758     1
    e2_return_C27_order  GC823     1
    e2_return_C27_order  GC887     1
    e2_return_C27_order  GC948     1
    e2_return_C27_order  GC1020    1
    e2_return_C27_order  GC1079    1
    e2_return_C27_order  GC1149    1
    e2_return_C27_order  GC1212    1
    cutoff_C27_order_b1  R684      1
    cutoff_C27_order_b1  R721      -1
    cutoff_C27_order_b2  R684      1
    cutoff_C27_order_b2  R724      -1
    cutoff_C27_order_b3  R684      1
    cutoff_C27_order_b3  R727      -1
    delivery_C47_order  R686      1
    delivery_C47_order  R687      -1
    delivery_C47_order  GC690     1
    delivery_C47_order  GC728     -1
    delivery_C47_order  GC773     1
    delivery_C47_order  GC809     -1
    delivery_C47_order  GC830     1
    delivery_C47_order  GC864     -1
    delivery_C47_order  GC903     1
    delivery_C47_order  GC929     -1
    delivery_C47_order  GC952     1
    delivery_C47_order  GC990     -1
    delivery_C47_order  GC1035    1
    delivery_C47_order  GC1065    -1
    delivery_C47_order  GC1092    1
    delivery_C47_order  GC1132    -1
    delivery_C47_order  GC1167    1
    delivery_C47_order  GC1191    -1
    delivery_C47_order  GC1462    -1
    delivery_C47_order  GC1482    -1
    delivery_C47_order  GC1496    -1
    delivery_C47_order  GC1516    -1
    delivery_C47_order  GC1548    -1
    delivery_C47_order  GC1562    -1
    pickup_time_C47_order  R687      1
    pickup_time_C47_order  R688      -1
    pickup_time_C47_order  GC696     1
    pickup_time_C47_order  GC722     -1
    pickup_time_C47_order  GC779     1
    pickup_time_C47_order  GC791     -1
    pickup_time_C47_order  GC842     1
    pickup_time_C47_order  GC852     -1
    pickup_time_C47_order  GC905     1
    pickup_time_C47_order  GC931     -1
    pickup_time_C47_order  GC958     1
    pickup_time_C47_order  GC984     -1
    pickup_time_C47_order  GC1039    1
    pickup_time_C47_order  GC1049    -1
    pickup_time_C47_order  GC1106    1
    pickup_time_C47_order  GC1116    -1
    pickup_time_C47_order  GC1169    1
    pickup_time_C47_order  GC1193    -1
    pickup_time_C47_order  GC1462    1
    pickup_time_C47_order  GC1484    -1
    pickup_time_C47_order  GC1490    1
    pickup_time_C47_order  GC1498    1
    pickup_time_C47_order  GC1504    1
    pickup_time_C47_order  GC1526    -1
    pickup_time_C47_order  GC1546    1
    pickup_time_C47_order  GC1550    1
    pickup_time_C47_order  GC1564    -1
    pickup_time_C47_order  GC1566    -1
    pickup_time_C47_order  GC1584    1
    e2_return_C47_order  R688      1
    e2_return_C47_order  GC78      1
    e2_return_C47_order  GC79      1
    e2_return_C47_order  GC80      1
    e2_return_C47_order  GC81      1
    e2_return_C47_order  GC82      1
    e2_return_C47_order  GC83      1
    e2_return_C47_order  GC754     1
    e2_return_C47_order  GC821     1
    e2_return_C47_order  GC881     1
    e2_return_C47_order  GC945     1
    e2_return_C47_order  GC1016    1
    e2_return_C47_order  GC1081    1
    e2_return_C47_order  GC1143    1
    e2_return_C47_order  GC1209    1
    cutoff_C47_order_b1  R689      1
    cutoff_C47_order_b1  R721      -2
    cutoff_C47_order_b2  R689      1
    cutoff_C47_order_b2  R724      -2
    cutoff_C47_order_b3  R689      1
    cutoff_C47_order_b3  R727      -2
    delivery_C25_order  R691      1
    delivery_C25_order  R692      -1
    delivery_C25_order  GC706     1
    delivery_C25_order  GC748     -1
    delivery_C25_order  GC785     1
    delivery_C25_order  GC807     -1
    delivery_C25_order  GC832     1
    delivery_C25_order  GC872     -1
    delivery_C25_order  GC913     1
    delivery_C25_order  GC935     -1
    delivery_C25_order  GC968     1
    delivery_C25_order  GC1010    -1
    delivery_C25_order  GC1045    1
    delivery_C25_order  GC1071    -1
    delivery_C25_order  GC1098    1
    delivery_C25_order  GC1126    -1
    delivery_C25_order  GC1177    1
    delivery_C25_order  GC1199    -1
    delivery_C25_order  GC1472    -1
    delivery_C25_order  GC1482    1
    delivery_C25_order  GC1506    -1
    delivery_C25_order  GC1546    -1
    delivery_C25_order  GC1552    -1
    delivery_C25_order  GC1556    1
    pickup_time_C25_order  R692      1
    pickup_time_C25_order  R693      -1
    pickup_time_C25_order  GC716     1
    pickup_time_C25_order  GC738     -1
    pickup_time_C25_order  GC799     -1
    pickup_time_C25_order  GC856     -1
    pickup_time_C25_order  GC978     1
    pickup_time_C25_order  GC1000    -1
    pickup_time_C25_order  GC1053    -1
    pickup_time_C25_order  GC1124    -1
    pickup_time_C25_order  GC1472    1
    pickup_time_C25_order  GC1498    -1
    pickup_time_C25_order  GC1502    1
    pickup_time_C25_order  GC1536    1
    pickup_time_C25_order  GC1548    1
    pickup_time_C25_order  GC1554    1
    pickup_time_C25_order  GC1558    -1
    pickup_time_C25_order  GC1560    1
    pickup_time_C25_order  GC1566    1
    pickup_time_C25_order  GC1572    1
    e2_return_C25_order  R693      1
    e2_return_C25_order  GC84      1
    e2_return_C25_order  GC85      1
    e2_return_C25_order  GC86      1
    e2_return_C25_order  GC87      1
    e2_return_C25_order  GC88      1
    e2_return_C25_order  GC89      1
    e2_return_C25_order  GC759     1
    e2_return_C25_order  GC824     1
    e2_return_C25_order  GC880     1
    e2_return_C25_order  GC947     1
    e2_return_C25_order  GC1021    1
    e2_return_C25_order  GC1083    1
    e2_return_C25_order  GC1147    1
    e2_return_C25_order  GC1211    1
    cutoff_C25_order_b1  R694      1
    cutoff_C25_order_b1  R721      -2
    cutoff_C25_order_b2  R694      1
    cutoff_C25_order_b2  R724      -2
    cutoff_C25_order_b3  R694      1
    cutoff_C25_order_b3  R727      -2
    delivery_C46_order  R696      1
    delivery_C46_order  R697      -1
    delivery_C46_order  GC710     1
    delivery_C46_order  GC750     -1
    delivery_C46_order  GC775     1
    delivery_C46_order  GC817     -1
    delivery_C46_order  GC836     1
    delivery_C46_order  GC876     -1
    delivery_C46_order  GC897     1
    delivery_C46_order  GC937     -1
    delivery_C46_order  GC972     1
    delivery_C46_order  GC1012    -1
    delivery_C46_order  GC1075    -1
    delivery_C46_order  GC1090    1
    delivery_C46_order  GC1128    -1
    delivery_C46_order  GC1159    1
    delivery_C46_order  GC1201    -1
    delivery_C46_order  GC1474    -1
    delivery_C46_order  GC1496    1
    delivery_C46_order  GC1506    1
    delivery_C46_order  GC1556    -1
    delivery_C46_order  GC1560    -1
    delivery_C46_order  GC1584    -1
    pickup_time_C46_order  R697      1
    pickup_time_C46_order  R698      -1
    pickup_time_C46_order  GC718     1
    pickup_time_C46_order  GC742     -1
    pickup_time_C46_order  GC801     -1
    pickup_time_C46_order  GC858     -1
    pickup_time_C46_order  GC923     -1
    pickup_time_C46_order  GC980     1
    pickup_time_C46_order  GC1004    -1
    pickup_time_C46_order  GC1059    -1
    pickup_time_C46_order  GC1102    1
    pickup_time_C46_order  GC1114    -1
    pickup_time_C46_order  GC1185    -1
    pickup_time_C46_order  GC1474    1
    pickup_time_C46_order  GC1520    -1
    pickup_time_C46_order  GC1526    1
    pickup_time_C46_order  GC1538    1
    pickup_time_C46_order  GC1550    -1
    pickup_time_C46_order  GC1552    1
    pickup_time_C46_order  GC1554    -1
    pickup_time_C46_order  GC1558    1
    pickup_time_C46_order  GC1562    1
    pickup_time_C46_order  GC1578    1
    pickup_time_C46_order  GC1582    -1
    e2_return_C46_order  R698      1
    e2_return_C46_order  GC90      1
    e2_return_C46_order  GC91      1
    e2_return_C46_order  GC92      1
    e2_return_C46_order  GC93      1
    e2_return_C46_order  GC94      1
    e2_return_C46_order  GC95      1
    e2_return_C46_order  GC760     1
    e2_return_C46_order  GC825     1
    e2_return_C46_order  GC884     1
    e2_return_C46_order  GC944     1
    e2_return_C46_order  GC1022    1
    e2_return_C46_order  GC1085    1
    e2_return_C46_order  GC1142    1
    e2_return_C46_order  GC1208    1
    cutoff_C46_order_b1  R699      1
    cutoff_C46_order_b1  R721      -1
    cutoff_C46_order_b2  R699      1
    cutoff_C46_order_b2  R724      -1
    cutoff_C46_order_b3  R699      1
    cutoff_C46_order_b3  R727      -1
    delivery_C29_order  R701      1
    delivery_C29_order  R702      -1
    delivery_C29_order  GC694     1
    delivery_C29_order  GC734     -1
    delivery_C29_order  GC767     1
    delivery_C29_order  GC811     -1
    delivery_C29_order  GC840     1
    delivery_C29_order  GC866     -1
    delivery_C29_order  GC891     1
    delivery_C29_order  GC919     -1
    delivery_C29_order  GC956     1
    delivery_C29_order  GC996     -1
    delivery_C29_order  GC1037    1
    delivery_C29_order  GC1067    -1
    delivery_C29_order  GC1096    1
    delivery_C29_order  GC1134    -1
    delivery_C29_order  GC1157    1
    delivery_C29_order  GC1195    -1
    delivery_C29_order  GC1466    -1
    delivery_C29_order  GC1486    -1
    delivery_C29_order  GC1568    -1
    pickup_time_C29_order  R702      1
    pickup_time_C29_order  R703      -1
    pickup_time_C29_order  GC702     1
    pickup_time_C29_order  GC726     -1
    pickup_time_C29_order  GC789     -1
    pickup_time_C29_order  GC854     -1
    pickup_time_C29_order  GC895     1
    pickup_time_C29_order  GC915     -1
    pickup_time_C29_order  GC964     1
    pickup_time_C29_order  GC988     -1
    pickup_time_C29_order  GC1051    -1
    pickup_time_C29_order  GC1120    -1
    pickup_time_C29_order  GC1161    1
    pickup_time_C29_order  GC1183    -1
    pickup_time_C29_order  GC1466    1
    pickup_time_C29_order  GC1478    1
    pickup_time_C29_order  GC1484    1
    pickup_time_C29_order  GC1488    1
    pickup_time_C29_order  GC1508    -1
    pickup_time_C29_order  GC1516    1
    pickup_time_C29_order  GC1518    1
    pickup_time_C29_order  GC1522    1
    pickup_time_C29_order  GC1570    1
    pickup_time_C29_order  GC1582    1
    e2_return_C29_order  R703      1
    e2_return_C29_order  GC96      1
    e2_return_C29_order  GC97      1
    e2_return_C29_order  GC98      1
    e2_return_C29_order  GC99      1
    e2_return_C29_order  GC100     1
    e2_return_C29_order  GC101     1
    e2_return_C29_order  GC756     1
    e2_return_C29_order  GC820     1
    e2_return_C29_order  GC882     1
    e2_return_C29_order  GC941     1
    e2_return_C29_order  GC1018    1
    e2_return_C29_order  GC1082    1
    e2_return_C29_order  GC1145    1
    e2_return_C29_order  GC1207    1
    cutoff_C29_order_b1  R704      1
    cutoff_C29_order_b1  R721      -1
    cutoff_C29_order_b2  R704      1
    cutoff_C29_order_b2  R724      -1
    cutoff_C29_order_b3  R704      1
    cutoff_C29_order_b3  R727      -1
    delivery_C6_order  R706      1
    delivery_C6_order  R707      -1
    delivery_C6_order  GC712     1
    delivery_C6_order  GC752     -1
    delivery_C6_order  GC777     1
    delivery_C6_order  GC815     -1
    delivery_C6_order  GC848     1
    delivery_C6_order  GC874     -1
    delivery_C6_order  GC899     1
    delivery_C6_order  GC925     -1
    delivery_C6_order  GC974     1
    delivery_C6_order  GC1014    -1
    delivery_C6_order  GC1043    1
    delivery_C6_order  GC1073    -1
    delivery_C6_order  GC1100    1
    delivery_C6_order  GC1138    -1
    delivery_C6_order  GC1153    1
    delivery_C6_order  GC1187    -1
    delivery_C6_order  GC1476    -1
    delivery_C6_order  GC1486    1
    delivery_C6_order  GC1522    -1
    pickup_time_C6_order  R707      1
    pickup_time_C6_order  R708      -1
    pickup_time_C6_order  GC720     1
    pickup_time_C6_order  GC744     -1
    pickup_time_C6_order  GC805     -1
    pickup_time_C6_order  GC860     -1
    pickup_time_C6_order  GC921     -1
    pickup_time_C6_order  GC982     1
    pickup_time_C6_order  GC1006    -1
    pickup_time_C6_order  GC1061    -1
    pickup_time_C6_order  GC1122    -1
    pickup_time_C6_order  GC1163    1
    pickup_time_C6_order  GC1179    -1
    pickup_time_C6_order  GC1476    1
    pickup_time_C6_order  GC1488    -1
    pickup_time_C6_order  GC1508    1
    pickup_time_C6_order  GC1520    1
    pickup_time_C6_order  GC1540    1
    pickup_time_C6_order  GC1564    1
    pickup_time_C6_order  GC1568    1
    pickup_time_C6_order  GC1580    1
    e2_return_C6_order  R708      1
    e2_return_C6_order  GC102     1
    e2_return_C6_order  GC103     1
    e2_return_C6_order  GC104     1
    e2_return_C6_order  GC105     1
    e2_return_C6_order  GC106     1
    e2_return_C6_order  GC107     1
    e2_return_C6_order  GC761     1
    e2_return_C6_order  GC826     1
    e2_return_C6_order  GC885     1
    e2_return_C6_order  GC943     1
    e2_return_C6_order  GC1023    1
    e2_return_C6_order  GC1086    1
    e2_return_C6_order  GC1146    1
    e2_return_C6_order  GC1205    1
    cutoff_C6_order_b1  R709      1
    cutoff_C6_order_b1  R721      -1
    cutoff_C6_order_b2  R709      1
    cutoff_C6_order_b2  R724      -1
    cutoff_C6_order_b3  R709      1
    cutoff_C6_order_b3  R727      -1
    delivery_C34_order  R711      1
    delivery_C34_order  R712      -1
    delivery_C34_order  GC1220    1
    delivery_C34_order  GC1230    -1
    delivery_C34_order  GC1240    1
    delivery_C34_order  GC1250    -1
    delivery_C34_order  GC1260    1
    delivery_C34_order  GC1270    -1
    delivery_C34_order  GC1276    1
    delivery_C34_order  GC1288    -1
    delivery_C34_order  GC1588    -1
    delivery_C34_order  GC1592    -1
    pickup_time_C34_order  R712      1
    pickup_time_C34_order  R713      -1
    pickup_time_C34_order  GC1222    1
    pickup_time_C34_order  GC1228    -1
    pickup_time_C34_order  GC1242    1
    pickup_time_C34_order  GC1248    -1
    pickup_time_C34_order  GC1262    1
    pickup_time_C34_order  GC1268    -1
    pickup_time_C34_order  GC1280    1
    pickup_time_C34_order  GC1284    -1
    pickup_time_C34_order  GC1588    1
    pickup_time_C34_order  GC1590    -1
    e2_return_C34_order  R713      1
    e2_return_C34_order  GC108     1
    e2_return_C34_order  GC109     1
    e2_return_C34_order  GC110     1
    e2_return_C34_order  GC111     1
    e2_return_C34_order  GC112     1
    e2_return_C34_order  GC113     1
    e2_return_C34_order  GC1233    1
    e2_return_C34_order  GC1253    1
    e2_return_C34_order  GC1273    1
    e2_return_C34_order  GC1292    1
    cutoff_C34_order_b1  R714      1
    cutoff_C34_order_b1  R722      -2
    cutoff_C34_order_b2  R714      1
    cutoff_C34_order_b2  R725      -2
    cutoff_C34_order_b3  R714      1
    cutoff_C34_order_b3  R728      -2
    delivery_C95_order  R716      1
    delivery_C95_order  R717      -1
    delivery_C95_order  GC1216    1
    delivery_C95_order  GC1226    -1
    delivery_C95_order  GC1236    1
    delivery_C95_order  GC1246    -1
    delivery_C95_order  GC1256    1
    delivery_C95_order  GC1266    -1
    delivery_C95_order  GC1278    1
    delivery_C95_order  GC1290    -1
    delivery_C95_order  GC1586    -1
    pickup_time_C95_order  R717      1
    pickup_time_C95_order  R718      -1
    pickup_time_C95_order  GC1218    1
    pickup_time_C95_order  GC1224    -1
    pickup_time_C95_order  GC1238    1
    pickup_time_C95_order  GC1244    -1
    pickup_time_C95_order  GC1258    1
    pickup_time_C95_order  GC1264    -1
    pickup_time_C95_order  GC1282    1
    pickup_time_C95_order  GC1286    -1
    pickup_time_C95_order  GC1586    1
    pickup_time_C95_order  GC1590    1
    pickup_time_C95_order  GC1592    1
    e2_return_C95_order  R718      1
    e2_return_C95_order  GC114     1
    e2_return_C95_order  GC115     1
    e2_return_C95_order  GC116     1
    e2_return_C95_order  GC117     1
    e2_return_C95_order  GC118     1
    e2_return_C95_order  GC119     1
    e2_return_C95_order  GC1232    1
    e2_return_C95_order  GC1252    1
    e2_return_C95_order  GC1272    1
    e2_return_C95_order  GC1293    1
    cutoff_C95_order_b1  R719      1
    cutoff_C95_order_b1  R722      -2
    cutoff_C95_order_b2  R719      1
    cutoff_C95_order_b2  R725      -2
    cutoff_C95_order_b3  R719      1
    cutoff_C95_order_b3  R728      -2
    MARKER    'MARKER'                 'INTEND'
    pool_task_rank_C81_order_d  R732      -1
    pool_task_rank_C81_order_d  GC125     1
    pool_task_rank_C81_order_d  GC173     -1
    pool_task_rank_C81_order_d  GC214     1
    pool_task_rank_C81_order_d  GC250     -1
    pool_task_rank_C81_order_d  GC289     1
    pool_task_rank_C81_order_d  GC325     -1
    pool_task_rank_C81_order_d  GC354     1
    pool_task_rank_C81_order_d  GC376     -1
    pool_task_rank_C81_order_d  GC402     1
    pool_task_rank_C81_order_d  GC450     -1
    pool_task_rank_C81_order_d  GC493     1
    pool_task_rank_C81_order_d  GC547     -1
    pool_task_rank_C81_order_d  GC578     1
    pool_task_rank_C81_order_d  GC606     -1
    pool_task_rank_C81_order_d  GC643     1
    pool_task_rank_C81_order_d  GC673     -1
    pool_task_rank_C81_order_d  GC1299    -1
    pool_task_rank_C81_order_d  GC1317    -1
    pool_task_rank_C81_order_d  GC1337    -1
    pool_task_rank_C81_order_d  GC1349    1
    pool_task_rank_C81_order_d  GC1381    -1
    pool_task_rank_C81_order_d  GC1441    -1
    pool_task_rank_C81_order_p  R732      1
    pool_task_rank_C81_order_p  GC133     1
    pool_task_rank_C81_order_p  GC165     -1
    pool_task_rank_C81_order_p  GC226     1
    pool_task_rank_C81_order_p  GC234     -1
    pool_task_rank_C81_order_p  GC291     1
    pool_task_rank_C81_order_p  GC356     1
    pool_task_rank_C81_order_p  GC410     1
    pool_task_rank_C81_order_p  GC442     -1
    pool_task_rank_C81_order_p  GC511     1
    pool_task_rank_C81_order_p  GC521     -1
    pool_task_rank_C81_order_p  GC582     1
    pool_task_rank_C81_order_p  GC645     1
    pool_task_rank_C81_order_p  GC1299    1
    pool_task_rank_C81_order_p  GC1319    -1
    pool_task_rank_C81_order_p  GC1345    1
    pool_task_rank_C81_order_p  GC1371    1
    pool_task_rank_C81_order_p  GC1379    1
    pool_task_rank_C81_order_p  GC1389    -1
    pool_task_rank_C81_order_p  GC1437    1
    pool_task_rank_C81_order_p  GC1439    -1
    pool_task_rank_C90_order_d  R733      -1
    pool_task_rank_C90_order_d  GC127     1
    pool_task_rank_C90_order_d  GC175     -1
    pool_task_rank_C90_order_d  GC216     1
    pool_task_rank_C90_order_d  GC244     -1
    pool_task_rank_C90_order_d  GC277     1
    pool_task_rank_C90_order_d  GC319     -1
    pool_task_rank_C90_order_d  GC344     1
    pool_task_rank_C90_order_d  GC370     -1
    pool_task_rank_C90_order_d  GC404     1
    pool_task_rank_C90_order_d  GC452     -1
    pool_task_rank_C90_order_d  GC491     1
    pool_task_rank_C90_order_d  GC533     -1
    pool_task_rank_C90_order_d  GC570     1
    pool_task_rank_C90_order_d  GC600     -1
    pool_task_rank_C90_order_d  GC633     1
    pool_task_rank_C90_order_d  GC667     -1
    pool_task_rank_C90_order_d  GC1301    -1
    pool_task_rank_C90_order_d  GC1317    1
    pool_task_rank_C90_order_d  GC1339    1
    pool_task_rank_C90_order_d  GC1349    -1
    pool_task_rank_C90_order_d  GC1363    -1
    pool_task_rank_C90_order_d  GC1385    -1
    pool_task_rank_C90_order_d  GC1393    -1
    pool_task_rank_C90_order_d  GC1437    -1
    pool_task_rank_C90_order_d  GC1445    -1
    pool_task_rank_C90_order_d  GC1449    1
    pool_task_rank_C90_order_p  R733      1
    pool_task_rank_C90_order_p  GC135     1
    pool_task_rank_C90_order_p  GC167     -1
    pool_task_rank_C90_order_p  GC228     1
    pool_task_rank_C90_order_p  GC236     -1
    pool_task_rank_C90_order_p  GC293     1
    pool_task_rank_C90_order_p  GC303     -1
    pool_task_rank_C90_order_p  GC358     1
    pool_task_rank_C90_order_p  GC412     1
    pool_task_rank_C90_order_p  GC444     -1
    pool_task_rank_C90_order_p  GC501     1
    pool_task_rank_C90_order_p  GC517     -1
    pool_task_rank_C90_order_p  GC584     1
    pool_task_rank_C90_order_p  GC647     1
    pool_task_rank_C90_order_p  GC657     -1
    pool_task_rank_C90_order_p  GC1301    1
    pool_task_rank_C90_order_p  GC1329    -1
    pool_task_rank_C90_order_p  GC1335    -1
    pool_task_rank_C90_order_p  GC1345    -1
    pool_task_rank_C90_order_p  GC1373    1
    pool_task_rank_C90_order_p  GC1387    1
    pool_task_rank_C90_order_p  GC1391    -1
    pool_task_rank_C90_order_p  GC1395    1
    pool_task_rank_C90_order_p  GC1415    -1
    pool_task_rank_C90_order_p  GC1435    -1
    pool_task_rank_C90_order_p  GC1439    1
    pool_task_rank_C90_order_p  GC1441    1
    pool_task_rank_C90_order_p  GC1443    -1
    pool_task_rank_C90_order_p  GC1447    -1
    pool_task_rank_C90_order_p  GC1451    -1
    pool_task_rank_C90_order_p  GC1453    1
    pool_task_rank_C97_order_d  R734      -1
    pool_task_rank_C97_order_d  GC137     1
    pool_task_rank_C97_order_d  GC191     -1
    pool_task_rank_C97_order_d  GC218     1
    pool_task_rank_C97_order_d  GC414     1
    pool_task_rank_C97_order_d  GC468     -1
    pool_task_rank_C97_order_d  GC499     1
    pool_task_rank_C97_order_d  GC1307    -1
    pool_task_rank_C97_order_d  GC1337    1
    pool_task_rank_C97_order_d  GC1339    -1
    pool_task_rank_C97_order_d  GC1347    -1
    pool_task_rank_C97_order_d  GC1363    1
    pool_task_rank_C97_order_d  GC1383    -1
    pool_task_rank_C97_order_d  GC1453    -1
    pool_task_rank_C97_order_p  R734      1
    pool_task_rank_C97_order_p  GC151     1
    pool_task_rank_C97_order_p  GC177     -1
    pool_task_rank_C97_order_p  GC238     -1
    pool_task_rank_C97_order_p  GC428     1
    pool_task_rank_C97_order_p  GC454     -1
    pool_task_rank_C97_order_p  GC527     -1
    pool_task_rank_C97_order_p  GC1307    1
    pool_task_rank_C97_order_p  GC1369    1
    pool_task_rank_C97_order_p  GC1371    -1
    pool_task_rank_C97_order_p  GC1373    -1
    pool_task_rank_C97_order_p  GC1375    1
    pool_task_rank_C97_order_p  GC1377    -1
    pool_task_rank_C97_order_p  GC1391    1
    pool_task_rank_C97_order_p  GC1445    1
    pool_task_rank_C51_order_d  R735      -1
    pool_task_rank_C51_order_d  GC147     1
    pool_task_rank_C51_order_d  GC199     -1
    pool_task_rank_C51_order_d  GC262     -1
    pool_task_rank_C51_order_d  GC329     -1
    pool_task_rank_C51_order_d  GC386     -1
    pool_task_rank_C51_order_d  GC424     1
    pool_task_rank_C51_order_d  GC476     -1
    pool_task_rank_C51_order_d  GC503     1
    pool_task_rank_C51_order_d  GC553     -1
    pool_task_rank_C51_order_d  GC616     -1
    pool_task_rank_C51_order_d  GC679     -1
    pool_task_rank_C51_order_d  GC1315    -1
    pool_task_rank_C51_order_d  GC1347    1
    pool_task_rank_C51_order_d  GC1375    -1
    pool_task_rank_C51_order_d  GC1381    1
    pool_task_rank_C51_order_d  GC1385    1
    pool_task_rank_C51_order_d  GC1395    -1
    pool_task_rank_C51_order_d  GC1449    -1
    pool_task_rank_C51_order_p  R735      1
    pool_task_rank_C51_order_p  GC159     1
    pool_task_rank_C51_order_p  GC187     -1
    pool_task_rank_C51_order_p  GC436     1
    pool_task_rank_C51_order_p  GC464     -1
    pool_task_rank_C51_order_p  GC537     -1
    pool_task_rank_C51_order_p  GC1315    1
    pool_task_rank_C51_order_p  GC1369    -1
    pool_task_rank_C51_order_p  GC1377    1
    pool_task_rank_C51_order_p  GC1379    -1
    pool_task_rank_C51_order_p  GC1383    1
    pool_task_rank_C51_order_p  GC1387    -1
    pool_task_rank_C51_order_p  GC1393    1
    pool_task_rank_C51_order_p  GC1451    1
    pool_task_rank_C0_order_d  R736      -1
    pool_task_rank_C0_order_d  GC129     1
    pool_task_rank_C0_order_d  GC183     -1
    pool_task_rank_C0_order_d  GC222     1
    pool_task_rank_C0_order_d  GC252     -1
    pool_task_rank_C0_order_d  GC275     1
    pool_task_rank_C0_order_d  GC315     -1
    pool_task_rank_C0_order_d  GC346     1
    pool_task_rank_C0_order_d  GC378     -1
    pool_task_rank_C0_order_d  GC406     1
    pool_task_rank_C0_order_d  GC460     -1
    pool_task_rank_C0_order_d  GC495     1
    pool_task_rank_C0_order_d  GC549     -1
    pool_task_rank_C0_order_d  GC574     1
    pool_task_rank_C0_order_d  GC608     -1
    pool_task_rank_C0_order_d  GC635     1
    pool_task_rank_C0_order_d  GC675     -1
    pool_task_rank_C0_order_d  GC1303    -1
    pool_task_rank_C0_order_d  GC1321    -1
    pool_task_rank_C0_order_d  GC1351    -1
    pool_task_rank_C0_order_d  GC1353    -1
    pool_task_rank_C0_order_d  GC1411    -1
    pool_task_rank_C0_order_d  GC1413    -1
    pool_task_rank_C0_order_p  R736      1
    pool_task_rank_C0_order_p  GC143     1
    pool_task_rank_C0_order_p  GC169     -1
    pool_task_rank_C0_order_p  GC285     1
    pool_task_rank_C0_order_p  GC299     -1
    pool_task_rank_C0_order_p  GC420     1
    pool_task_rank_C0_order_p  GC446     -1
    pool_task_rank_C0_order_p  GC523     -1
    pool_task_rank_C0_order_p  GC594     -1
    pool_task_rank_C0_order_p  GC659     -1
    pool_task_rank_C0_order_p  GC1303    1
    pool_task_rank_C0_order_p  GC1325    -1
    pool_task_rank_C0_order_p  GC1331    -1
    pool_task_rank_C0_order_p  GC1335    1
    pool_task_rank_C0_order_p  GC1397    1
    pool_task_rank_C0_order_p  GC1399    -1
    pool_task_rank_C0_order_p  GC1401    -1
    pool_task_rank_C0_order_p  GC1403    1
    pool_task_rank_C0_order_p  GC1405    -1
    pool_task_rank_C0_order_p  GC1407    1
    pool_task_rank_C0_order_p  GC1409    1
    pool_task_rank_C39_order_d  R737      -1
    pool_task_rank_C39_order_d  GC139     1
    pool_task_rank_C39_order_d  GC193     -1
    pool_task_rank_C39_order_d  GC230     1
    pool_task_rank_C39_order_d  GC246     -1
    pool_task_rank_C39_order_d  GC281     1
    pool_task_rank_C39_order_d  GC321     -1
    pool_task_rank_C39_order_d  GC360     1
    pool_task_rank_C39_order_d  GC372     -1
    pool_task_rank_C39_order_d  GC416     1
    pool_task_rank_C39_order_d  GC470     -1
    pool_task_rank_C39_order_d  GC507     1
    pool_task_rank_C39_order_d  GC543     -1
    pool_task_rank_C39_order_d  GC568     1
    pool_task_rank_C39_order_d  GC602     -1
    pool_task_rank_C39_order_d  GC649     1
    pool_task_rank_C39_order_d  GC669     -1
    pool_task_rank_C39_order_d  GC1309    -1
    pool_task_rank_C39_order_d  GC1323    1
    pool_task_rank_C39_order_d  GC1341    -1
    pool_task_rank_C39_order_d  GC1351    1
    pool_task_rank_C39_order_d  GC1407    -1
    pool_task_rank_C39_order_d  GC1457    -1
    pool_task_rank_C39_order_p  R737      1
    pool_task_rank_C39_order_p  GC153     1
    pool_task_rank_C39_order_p  GC179     -1
    pool_task_rank_C39_order_p  GC309     -1
    pool_task_rank_C39_order_p  GC430     1
    pool_task_rank_C39_order_p  GC456     -1
    pool_task_rank_C39_order_p  GC531     -1
    pool_task_rank_C39_order_p  GC588     -1
    pool_task_rank_C39_order_p  GC1309    1
    pool_task_rank_C39_order_p  GC1355    -1
    pool_task_rank_C39_order_p  GC1365    1
    pool_task_rank_C39_order_p  GC1367    -1
    pool_task_rank_C39_order_p  GC1397    -1
    pool_task_rank_C39_order_p  GC1401    1
    pool_task_rank_C39_order_p  GC1411    1
    pool_task_rank_C39_order_p  GC1443    1
    pool_task_rank_C39_order_p  GC1455    -1
    pool_task_rank_C39_order_p  GC1459    1
    pool_task_rank_C52_order_d  R738      -1
    pool_task_rank_C52_order_d  GC145     1
    pool_task_rank_C52_order_d  GC197     -1
    pool_task_rank_C52_order_d  GC256     -1
    pool_task_rank_C52_order_d  GC295     1
    pool_task_rank_C52_order_d  GC317     -1
    pool_task_rank_C52_order_d  GC362     1
    pool_task_rank_C52_order_d  GC382     -1
    pool_task_rank_C52_order_d  GC422     1
    pool_task_rank_C52_order_d  GC474     -1
    pool_task_rank_C52_order_d  GC513     1
    pool_task_rank_C52_order_d  GC541     -1
    pool_task_rank_C52_order_d  GC572     1
    pool_task_rank_C52_order_d  GC612     -1
    pool_task_rank_C52_order_d  GC651     1
    pool_task_rank_C52_order_d  GC677     -1
    pool_task_rank_C52_order_d  GC1313    -1
    pool_task_rank_C52_order_d  GC1321    1
    pool_task_rank_C52_order_d  GC1323    -1
    pool_task_rank_C52_order_d  GC1341    1
    pool_task_rank_C52_order_d  GC1409    -1
    pool_task_rank_C52_order_d  GC1459    -1
    pool_task_rank_C52_order_p  R738      1
    pool_task_rank_C52_order_p  GC157     1
    pool_task_rank_C52_order_p  GC185     -1
    pool_task_rank_C52_order_p  GC311     -1
    pool_task_rank_C52_order_p  GC434     1
    pool_task_rank_C52_order_p  GC462     -1
    pool_task_rank_C52_order_p  GC535     -1
    pool_task_rank_C52_order_p  GC598     -1
    pool_task_rank_C52_order_p  GC1313    1
    pool_task_rank_C52_order_p  GC1365    -1
    pool_task_rank_C52_order_p  GC1403    -1
    pool_task_rank_C52_order_p  GC1405    1
    pool_task_rank_C52_order_p  GC1413    1
    pool_task_rank_C52_order_p  GC1447    1
    pool_task_rank_C52_order_p  GC1457    1
    pool_task_rank_C85_order_d  R739      -1
    pool_task_rank_C85_order_d  GC121     1
    pool_task_rank_C85_order_d  GC163     -1
    pool_task_rank_C85_order_d  GC224     1
    pool_task_rank_C85_order_d  GC248     -1
    pool_task_rank_C85_order_d  GC283     1
    pool_task_rank_C85_order_d  GC323     -1
    pool_task_rank_C85_order_d  GC342     1
    pool_task_rank_C85_order_d  GC374     -1
    pool_task_rank_C85_order_d  GC398     1
    pool_task_rank_C85_order_d  GC440     -1
    pool_task_rank_C85_order_d  GC505     1
    pool_task_rank_C85_order_d  GC545     -1
    pool_task_rank_C85_order_d  GC580     1
    pool_task_rank_C85_order_d  GC604     -1
    pool_task_rank_C85_order_d  GC631     1
    pool_task_rank_C85_order_d  GC671     -1
    pool_task_rank_C85_order_d  GC1297    -1
    pool_task_rank_C85_order_d  GC1333    -1
    pool_task_rank_C85_order_d  GC1343    -1
    pool_task_rank_C85_order_d  GC1419    -1
    pool_task_rank_C85_order_d  GC1431    -1
    pool_task_rank_C85_order_p  R739      1
    pool_task_rank_C85_order_p  GC123     1
    pool_task_rank_C85_order_p  GC161     -1
    pool_task_rank_C85_order_p  GC220     1
    pool_task_rank_C85_order_p  GC242     -1
    pool_task_rank_C85_order_p  GC287     1
    pool_task_rank_C85_order_p  GC301     -1
    pool_task_rank_C85_order_p  GC352     1
    pool_task_rank_C85_order_p  GC364     -1
    pool_task_rank_C85_order_p  GC400     1
    pool_task_rank_C85_order_p  GC438     -1
    pool_task_rank_C85_order_p  GC509     1
    pool_task_rank_C85_order_p  GC519     -1
    pool_task_rank_C85_order_p  GC576     1
    pool_task_rank_C85_order_p  GC590     -1
    pool_task_rank_C85_order_p  GC641     1
    pool_task_rank_C85_order_p  GC655     -1
    pool_task_rank_C85_order_p  GC1297    1
    pool_task_rank_C85_order_p  GC1319    1
    pool_task_rank_C85_order_p  GC1327    1
    pool_task_rank_C85_order_p  GC1329    1
    pool_task_rank_C85_order_p  GC1331    1
    pool_task_rank_C85_order_p  GC1357    1
    pool_task_rank_C85_order_p  GC1361    -1
    pool_task_rank_C85_order_p  GC1367    1
    pool_task_rank_C85_order_p  GC1417    1
    pool_task_rank_C85_order_p  GC1433    -1
    pool_task_rank_C85_order_p  GC1461    1
    pool_task_rank_C75_order_d  R740      -1
    pool_task_rank_C75_order_d  GC131     1
    pool_task_rank_C75_order_d  GC189     -1
    pool_task_rank_C75_order_d  GC232     1
    pool_task_rank_C75_order_d  GC254     -1
    pool_task_rank_C75_order_d  GC279     1
    pool_task_rank_C75_order_d  GC327     -1
    pool_task_rank_C75_order_d  GC350     1
    pool_task_rank_C75_order_d  GC380     -1
    pool_task_rank_C75_order_d  GC408     1
    pool_task_rank_C75_order_d  GC466     -1
    pool_task_rank_C75_order_d  GC497     1
    pool_task_rank_C75_order_d  GC551     -1
    pool_task_rank_C75_order_d  GC586     1
    pool_task_rank_C75_order_d  GC610     -1
    pool_task_rank_C75_order_d  GC629     1
    pool_task_rank_C75_order_d  GC665     -1
    pool_task_rank_C75_order_d  GC1305    -1
    pool_task_rank_C75_order_d  GC1333    1
    pool_task_rank_C75_order_d  GC1359    1
    pool_task_rank_C75_order_d  GC1421    -1
    pool_task_rank_C75_order_d  GC1429    -1
    pool_task_rank_C75_order_d  GC1461    -1
    pool_task_rank_C75_order_p  R740      1
    pool_task_rank_C75_order_p  GC149     1
    pool_task_rank_C75_order_p  GC171     -1
    pool_task_rank_C75_order_p  GC258     -1
    pool_task_rank_C75_order_p  GC305     -1
    pool_task_rank_C75_order_p  GC366     -1
    pool_task_rank_C75_order_p  GC426     1
    pool_task_rank_C75_order_p  GC448     -1
    pool_task_rank_C75_order_p  GC525     -1
    pool_task_rank_C75_order_p  GC596     -1
    pool_task_rank_C75_order_p  GC639     1
    pool_task_rank_C75_order_p  GC653     -1
    pool_task_rank_C75_order_p  GC1305    1
    pool_task_rank_C75_order_p  GC1325    1
    pool_task_rank_C75_order_p  GC1327    -1
    pool_task_rank_C75_order_p  GC1353    1
    pool_task_rank_C75_order_p  GC1361    1
    pool_task_rank_C75_order_p  GC1423    -1
    pool_task_rank_C75_order_p  GC1425    1
    pool_task_rank_C75_order_p  GC1427    1
    pool_task_rank_C75_order_p  GC1431    1
    pool_task_rank_C75_order_p  GC1435    1
    pool_task_rank_C75_order_p  GC1455    1
    pool_task_rank_C21_order_d  R741      -1
    pool_task_rank_C21_order_d  GC141     1
    pool_task_rank_C21_order_d  GC195     -1
    pool_task_rank_C21_order_d  GC260     -1
    pool_task_rank_C21_order_d  GC297     1
    pool_task_rank_C21_order_d  GC313     -1
    pool_task_rank_C21_order_d  GC348     1
    pool_task_rank_C21_order_d  GC384     -1
    pool_task_rank_C21_order_d  GC418     1
    pool_task_rank_C21_order_d  GC472     -1
    pool_task_rank_C21_order_d  GC515     1
    pool_task_rank_C21_order_d  GC539     -1
    pool_task_rank_C21_order_d  GC614     -1
    pool_task_rank_C21_order_d  GC637     1
    pool_task_rank_C21_order_d  GC663     -1
    pool_task_rank_C21_order_d  GC1311    -1
    pool_task_rank_C21_order_d  GC1343    1
    pool_task_rank_C21_order_d  GC1359    -1
    pool_task_rank_C21_order_d  GC1417    -1
    pool_task_rank_C21_order_d  GC1421    1
    pool_task_rank_C21_order_d  GC1427    -1
    pool_task_rank_C21_order_p  R741      1
    pool_task_rank_C21_order_p  GC155     1
    pool_task_rank_C21_order_p  GC181     -1
    pool_task_rank_C21_order_p  GC240     -1
    pool_task_rank_C21_order_p  GC307     -1
    pool_task_rank_C21_order_p  GC368     -1
    pool_task_rank_C21_order_p  GC432     1
    pool_task_rank_C21_order_p  GC458     -1
    pool_task_rank_C21_order_p  GC529     -1
    pool_task_rank_C21_order_p  GC592     -1
    pool_task_rank_C21_order_p  GC661     -1
    pool_task_rank_C21_order_p  GC1311    1
    pool_task_rank_C21_order_p  GC1355    1
    pool_task_rank_C21_order_p  GC1357    -1
    pool_task_rank_C21_order_p  GC1389    1
    pool_task_rank_C21_order_p  GC1399    1
    pool_task_rank_C21_order_p  GC1415    1
    pool_task_rank_C21_order_p  GC1419    1
    pool_task_rank_C21_order_p  GC1423    1
    pool_task_rank_C21_order_p  GC1425    -1
    pool_task_rank_C21_order_p  GC1429    1
    pool_task_rank_C21_order_p  GC1433    1
    pool_task_rank_C88_order_d  R742      -1
    pool_task_rank_C88_order_d  GC693     1
    pool_task_rank_C88_order_d  GC733     -1
    pool_task_rank_C88_order_d  GC766     1
    pool_task_rank_C88_order_d  GC796     -1
    pool_task_rank_C88_order_d  GC835     1
    pool_task_rank_C88_order_d  GC863     -1
    pool_task_rank_C88_order_d  GC894     1
    pool_task_rank_C88_order_d  GC928     -1
    pool_task_rank_C88_order_d  GC955     1
    pool_task_rank_C88_order_d  GC995     -1
    pool_task_rank_C88_order_d  GC1030    1
    pool_task_rank_C88_order_d  GC1064    -1
    pool_task_rank_C88_order_d  GC1095    1
    pool_task_rank_C88_order_d  GC1131    -1
    pool_task_rank_C88_order_d  GC1156    1
    pool_task_rank_C88_order_d  GC1190    -1
    pool_task_rank_C88_order_d  GC1465    -1
    pool_task_rank_C88_order_d  GC1481    -1
    pool_task_rank_C88_order_d  GC1493    -1
    pool_task_rank_C88_order_d  GC1519    -1
    pool_task_rank_C88_order_d  GC1533    -1
    pool_task_rank_C88_order_d  GC1545    -1
    pool_task_rank_C88_order_p  R742      1
    pool_task_rank_C88_order_p  GC701     1
    pool_task_rank_C88_order_p  GC725     -1
    pool_task_rank_C88_order_p  GC772     1
    pool_task_rank_C88_order_p  GC788     -1
    pool_task_rank_C88_order_p  GC839     1
    pool_task_rank_C88_order_p  GC871     -1
    pool_task_rank_C88_order_p  GC902     1
    pool_task_rank_C88_order_p  GC918     -1
    pool_task_rank_C88_order_p  GC963     1
    pool_task_rank_C88_order_p  GC987     -1
    pool_task_rank_C88_order_p  GC1034    1
    pool_task_rank_C88_order_p  GC1056    -1
    pool_task_rank_C88_order_p  GC1105    1
    pool_task_rank_C88_order_p  GC1119    -1
    pool_task_rank_C88_order_p  GC1166    1
    pool_task_rank_C88_order_p  GC1182    -1
    pool_task_rank_C88_order_p  GC1465    1
    pool_task_rank_C88_order_p  GC1479    -1
    pool_task_rank_C88_order_p  GC1505    -1
    pool_task_rank_C88_order_p  GC1511    -1
    pool_task_rank_C88_order_p  GC1525    1
    pool_task_rank_C88_order_p  GC1529    1
    pool_task_rank_C88_order_p  GC1531    1
    pool_task_rank_C88_order_p  GC1535    -1
    pool_task_rank_C88_order_p  GC1537    -1
    pool_task_rank_C88_order_p  GC1539    -1
    pool_task_rank_C88_order_p  GC1541    -1
    pool_task_rank_C88_order_p  GC1543    1
    pool_task_rank_C76_order_d  R743      -1
    pool_task_rank_C76_order_d  GC699     1
    pool_task_rank_C76_order_d  GC741     -1
    pool_task_rank_C76_order_d  GC770     1
    pool_task_rank_C76_order_d  GC814     -1
    pool_task_rank_C76_order_d  GC847     1
    pool_task_rank_C76_order_d  GC869     -1
    pool_task_rank_C76_order_d  GC910     1
    pool_task_rank_C76_order_d  GC934     -1
    pool_task_rank_C76_order_d  GC961     1
    pool_task_rank_C76_order_d  GC1003    -1
    pool_task_rank_C76_order_d  GC1028    1
    pool_task_rank_C76_order_d  GC1070    -1
    pool_task_rank_C76_order_d  GC1111    1
    pool_task_rank_C76_order_d  GC1137    -1
    pool_task_rank_C76_order_d  GC1174    1
    pool_task_rank_C76_order_d  GC1198    -1
    pool_task_rank_C76_order_d  GC1469    -1
    pool_task_rank_C76_order_d  GC1481    1
    pool_task_rank_C76_order_d  GC1495    1
    pool_task_rank_C76_order_d  GC1513    -1
    pool_task_rank_C76_order_d  GC1529    -1
    pool_task_rank_C76_order_d  GC1577    -1
    pool_task_rank_C76_order_p  R743      1
    pool_task_rank_C76_order_p  GC709     1
    pool_task_rank_C76_order_p  GC731     -1
    pool_task_rank_C76_order_p  GC782     1
    pool_task_rank_C76_order_p  GC794     -1
    pool_task_rank_C76_order_p  GC845     1
    pool_task_rank_C76_order_p  GC908     1
    pool_task_rank_C76_order_p  GC971     1
    pool_task_rank_C76_order_p  GC993     -1
    pool_task_rank_C76_order_p  GC1042    1
    pool_task_rank_C76_order_p  GC1048    -1
    pool_task_rank_C76_order_p  GC1109    1
    pool_task_rank_C76_order_p  GC1172    1
    pool_task_rank_C76_order_p  GC1469    1
    pool_task_rank_C76_order_p  GC1491    -1
    pool_task_rank_C76_order_p  GC1501    -1
    pool_task_rank_C76_order_p  GC1511    1
    pool_task_rank_C76_order_p  GC1515    1
    pool_task_rank_C76_order_p  GC1525    -1
    pool_task_rank_C76_order_p  GC1533    1
    pool_task_rank_C76_order_p  GC1571    -1
    pool_task_rank_C76_order_p  GC1573    -1
    pool_task_rank_C76_order_p  GC1575    1
    pool_task_rank_C76_order_p  GC1579    -1
    pool_task_rank_C76_order_p  GC1581    -1
    pool_task_rank_C27_order_d  R744      -1
    pool_task_rank_C27_order_d  GC705     1
    pool_task_rank_C27_order_d  GC747     -1
    pool_task_rank_C27_order_d  GC784     1
    pool_task_rank_C27_order_d  GC804     -1
    pool_task_rank_C27_order_d  GC851     1
    pool_task_rank_C27_order_d  GC879     -1
    pool_task_rank_C27_order_d  GC912     1
    pool_task_rank_C27_order_d  GC940     -1
    pool_task_rank_C27_order_d  GC967     1
    pool_task_rank_C27_order_d  GC1009    -1
    pool_task_rank_C27_order_d  GC1032    1
    pool_task_rank_C27_order_d  GC1078    -1
    pool_task_rank_C27_order_d  GC1113    1
    pool_task_rank_C27_order_d  GC1141    -1
    pool_task_rank_C27_order_d  GC1176    1
    pool_task_rank_C27_order_d  GC1204    -1
    pool_task_rank_C27_order_d  GC1471    -1
    pool_task_rank_C27_order_d  GC1493    1
    pool_task_rank_C27_order_d  GC1495    -1
    pool_task_rank_C27_order_d  GC1513    1
    pool_task_rank_C27_order_d  GC1543    -1
    pool_task_rank_C27_order_d  GC1575    -1
    pool_task_rank_C27_order_p  R744      1
    pool_task_rank_C27_order_p  GC715     1
    pool_task_rank_C27_order_p  GC737     -1
    pool_task_rank_C27_order_p  GC798     -1
    pool_task_rank_C27_order_p  GC977     1
    pool_task_rank_C27_order_p  GC999     -1
    pool_task_rank_C27_order_p  GC1058    -1
    pool_task_rank_C27_order_p  GC1471    1
    pool_task_rank_C27_order_p  GC1501    1
    pool_task_rank_C27_order_p  GC1503    -1
    pool_task_rank_C27_order_p  GC1515    -1
    pool_task_rank_C27_order_p  GC1531    -1
    pool_task_rank_C27_order_p  GC1535    1
    pool_task_rank_C27_order_p  GC1545    1
    pool_task_rank_C27_order_p  GC1577    1
    pool_task_rank_C47_order_d  R745      -1
    pool_task_rank_C47_order_d  GC691     1
    pool_task_rank_C47_order_d  GC729     -1
    pool_task_rank_C47_order_d  GC774     1
    pool_task_rank_C47_order_d  GC810     -1
    pool_task_rank_C47_order_d  GC831     1
    pool_task_rank_C47_order_d  GC865     -1
    pool_task_rank_C47_order_d  GC904     1
    pool_task_rank_C47_order_d  GC930     -1
    pool_task_rank_C47_order_d  GC953     1
    pool_task_rank_C47_order_d  GC991     -1
    pool_task_rank_C47_order_d  GC1036    1
    pool_task_rank_C47_order_d  GC1066    -1
    pool_task_rank_C47_order_d  GC1093    1
    pool_task_rank_C47_order_d  GC1133    -1
    pool_task_rank_C47_order_d  GC1168    1
    pool_task_rank_C47_order_d  GC1192    -1
    pool_task_rank_C47_order_d  GC1463    -1
    pool_task_rank_C47_order_d  GC1483    -1
    pool_task_rank_C47_order_d  GC1497    -1
    pool_task_rank_C47_order_d  GC1517    -1
    pool_task_rank_C47_order_d  GC1549    -1
    pool_task_rank_C47_order_d  GC1563    -1
    pool_task_rank_C47_order_p  R745      1
    pool_task_rank_C47_order_p  GC697     1
    pool_task_rank_C47_order_p  GC723     -1
    pool_task_rank_C47_order_p  GC780     1
    pool_task_rank_C47_order_p  GC792     -1
    pool_task_rank_C47_order_p  GC843     1
    pool_task_rank_C47_order_p  GC853     -1
    pool_task_rank_C47_order_p  GC906     1
    pool_task_rank_C47_order_p  GC932     -1
    pool_task_rank_C47_order_p  GC959     1
    pool_task_rank_C47_order_p  GC985     -1
    pool_task_rank_C47_order_p  GC1040    1
    pool_task_rank_C47_order_p  GC1050    -1
    pool_task_rank_C47_order_p  GC1107    1
    pool_task_rank_C47_order_p  GC1117    -1
    pool_task_rank_C47_order_p  GC1170    1
    pool_task_rank_C47_order_p  GC1194    -1
    pool_task_rank_C47_order_p  GC1463    1
    pool_task_rank_C47_order_p  GC1485    -1
    pool_task_rank_C47_order_p  GC1491    1
    pool_task_rank_C47_order_p  GC1499    1
    pool_task_rank_C47_order_p  GC1505    1
    pool_task_rank_C47_order_p  GC1527    -1
    pool_task_rank_C47_order_p  GC1547    1
    pool_task_rank_C47_order_p  GC1551    1
    pool_task_rank_C47_order_p  GC1565    -1
    pool_task_rank_C47_order_p  GC1567    -1
    pool_task_rank_C47_order_p  GC1585    1
    pool_task_rank_C25_order_d  R746      -1
    pool_task_rank_C25_order_d  GC707     1
    pool_task_rank_C25_order_d  GC749     -1
    pool_task_rank_C25_order_d  GC786     1
    pool_task_rank_C25_order_d  GC808     -1
    pool_task_rank_C25_order_d  GC833     1
    pool_task_rank_C25_order_d  GC873     -1
    pool_task_rank_C25_order_d  GC914     1
    pool_task_rank_C25_order_d  GC936     -1
    pool_task_rank_C25_order_d  GC969     1
    pool_task_rank_C25_order_d  GC1011    -1
    pool_task_rank_C25_order_d  GC1046    1
    pool_task_rank_C25_order_d  GC1072    -1
    pool_task_rank_C25_order_d  GC1099    1
    pool_task_rank_C25_order_d  GC1127    -1
    pool_task_rank_C25_order_d  GC1178    1
    pool_task_rank_C25_order_d  GC1200    -1
    pool_task_rank_C25_order_d  GC1473    -1
    pool_task_rank_C25_order_d  GC1483    1
    pool_task_rank_C25_order_d  GC1507    -1
    pool_task_rank_C25_order_d  GC1547    -1
    pool_task_rank_C25_order_d  GC1553    -1
    pool_task_rank_C25_order_d  GC1557    1
    pool_task_rank_C25_order_p  R746      1
    pool_task_rank_C25_order_p  GC717     1
    pool_task_rank_C25_order_p  GC739     -1
    pool_task_rank_C25_order_p  GC800     -1
    pool_task_rank_C25_order_p  GC857     -1
    pool_task_rank_C25_order_p  GC979     1
    pool_task_rank_C25_order_p  GC1001    -1
    pool_task_rank_C25_order_p  GC1054    -1
    pool_task_rank_C25_order_p  GC1125    -1
    pool_task_rank_C25_order_p  GC1473    1
    pool_task_rank_C25_order_p  GC1499    -1
    pool_task_rank_C25_order_p  GC1503    1
    pool_task_rank_C25_order_p  GC1537    1
    pool_task_rank_C25_order_p  GC1549    1
    pool_task_rank_C25_order_p  GC1555    1
    pool_task_rank_C25_order_p  GC1559    -1
    pool_task_rank_C25_order_p  GC1561    1
    pool_task_rank_C25_order_p  GC1567    1
    pool_task_rank_C25_order_p  GC1573    1
    pool_task_rank_C46_order_d  R747      -1
    pool_task_rank_C46_order_d  GC711     1
    pool_task_rank_C46_order_d  GC751     -1
    pool_task_rank_C46_order_d  GC776     1
    pool_task_rank_C46_order_d  GC818     -1
    pool_task_rank_C46_order_d  GC837     1
    pool_task_rank_C46_order_d  GC877     -1
    pool_task_rank_C46_order_d  GC898     1
    pool_task_rank_C46_order_d  GC938     -1
    pool_task_rank_C46_order_d  GC973     1
    pool_task_rank_C46_order_d  GC1013    -1
    pool_task_rank_C46_order_d  GC1076    -1
    pool_task_rank_C46_order_d  GC1091    1
    pool_task_rank_C46_order_d  GC1129    -1
    pool_task_rank_C46_order_d  GC1160    1
    pool_task_rank_C46_order_d  GC1202    -1
    pool_task_rank_C46_order_d  GC1475    -1
    pool_task_rank_C46_order_d  GC1497    1
    pool_task_rank_C46_order_d  GC1507    1
    pool_task_rank_C46_order_d  GC1557    -1
    pool_task_rank_C46_order_d  GC1561    -1
    pool_task_rank_C46_order_d  GC1585    -1
    pool_task_rank_C46_order_p  R747      1
    pool_task_rank_C46_order_p  GC719     1
    pool_task_rank_C46_order_p  GC743     -1
    pool_task_rank_C46_order_p  GC802     -1
    pool_task_rank_C46_order_p  GC859     -1
    pool_task_rank_C46_order_p  GC924     -1
    pool_task_rank_C46_order_p  GC981     1
    pool_task_rank_C46_order_p  GC1005    -1
    pool_task_rank_C46_order_p  GC1060    -1
    pool_task_rank_C46_order_p  GC1103    1
    pool_task_rank_C46_order_p  GC1115    -1
    pool_task_rank_C46_order_p  GC1186    -1
    pool_task_rank_C46_order_p  GC1475    1
    pool_task_rank_C46_order_p  GC1521    -1
    pool_task_rank_C46_order_p  GC1527    1
    pool_task_rank_C46_order_p  GC1539    1
    pool_task_rank_C46_order_p  GC1551    -1
    pool_task_rank_C46_order_p  GC1553    1
    pool_task_rank_C46_order_p  GC1555    -1
    pool_task_rank_C46_order_p  GC1559    1
    pool_task_rank_C46_order_p  GC1563    1
    pool_task_rank_C46_order_p  GC1579    1
    pool_task_rank_C46_order_p  GC1583    -1
    pool_task_rank_C29_order_d  R748      -1
    pool_task_rank_C29_order_d  GC695     1
    pool_task_rank_C29_order_d  GC735     -1
    pool_task_rank_C29_order_d  GC768     1
    pool_task_rank_C29_order_d  GC812     -1
    pool_task_rank_C29_order_d  GC841     1
    pool_task_rank_C29_order_d  GC867     -1
    pool_task_rank_C29_order_d  GC892     1
    pool_task_rank_C29_order_d  GC920     -1
    pool_task_rank_C29_order_d  GC957     1
    pool_task_rank_C29_order_d  GC997     -1
    pool_task_rank_C29_order_d  GC1038    1
    pool_task_rank_C29_order_d  GC1068    -1
    pool_task_rank_C29_order_d  GC1097    1
    pool_task_rank_C29_order_d  GC1135    -1
    pool_task_rank_C29_order_d  GC1158    1
    pool_task_rank_C29_order_d  GC1196    -1
    pool_task_rank_C29_order_d  GC1467    -1
    pool_task_rank_C29_order_d  GC1487    -1
    pool_task_rank_C29_order_d  GC1569    -1
    pool_task_rank_C29_order_p  R748      1
    pool_task_rank_C29_order_p  GC703     1
    pool_task_rank_C29_order_p  GC727     -1
    pool_task_rank_C29_order_p  GC790     -1
    pool_task_rank_C29_order_p  GC855     -1
    pool_task_rank_C29_order_p  GC896     1
    pool_task_rank_C29_order_p  GC916     -1
    pool_task_rank_C29_order_p  GC965     1
    pool_task_rank_C29_order_p  GC989     -1
    pool_task_rank_C29_order_p  GC1052    -1
    pool_task_rank_C29_order_p  GC1121    -1
    pool_task_rank_C29_order_p  GC1162    1
    pool_task_rank_C29_order_p  GC1184    -1
    pool_task_rank_C29_order_p  GC1467    1
    pool_task_rank_C29_order_p  GC1479    1
    pool_task_rank_C29_order_p  GC1485    1
    pool_task_rank_C29_order_p  GC1489    1
    pool_task_rank_C29_order_p  GC1509    -1
    pool_task_rank_C29_order_p  GC1517    1
    pool_task_rank_C29_order_p  GC1519    1
    pool_task_rank_C29_order_p  GC1523    1
    pool_task_rank_C29_order_p  GC1571    1
    pool_task_rank_C29_order_p  GC1583    1
    pool_task_rank_C6_order_d  R749      -1
    pool_task_rank_C6_order_d  GC713     1
    pool_task_rank_C6_order_d  GC753     -1
    pool_task_rank_C6_order_d  GC778     1
    pool_task_rank_C6_order_d  GC816     -1
    pool_task_rank_C6_order_d  GC849     1
    pool_task_rank_C6_order_d  GC875     -1
    pool_task_rank_C6_order_d  GC900     1
    pool_task_rank_C6_order_d  GC926     -1
    pool_task_rank_C6_order_d  GC975     1
    pool_task_rank_C6_order_d  GC1015    -1
    pool_task_rank_C6_order_d  GC1044    1
    pool_task_rank_C6_order_d  GC1074    -1
    pool_task_rank_C6_order_d  GC1101    1
    pool_task_rank_C6_order_d  GC1139    -1
    pool_task_rank_C6_order_d  GC1154    1
    pool_task_rank_C6_order_d  GC1188    -1
    pool_task_rank_C6_order_d  GC1477    -1
    pool_task_rank_C6_order_d  GC1487    1
    pool_task_rank_C6_order_d  GC1523    -1
    pool_task_rank_C6_order_p  R749      1
    pool_task_rank_C6_order_p  GC721     1
    pool_task_rank_C6_order_p  GC745     -1
    pool_task_rank_C6_order_p  GC806     -1
    pool_task_rank_C6_order_p  GC861     -1
    pool_task_rank_C6_order_p  GC922     -1
    pool_task_rank_C6_order_p  GC983     1
    pool_task_rank_C6_order_p  GC1007    -1
    pool_task_rank_C6_order_p  GC1062    -1
    pool_task_rank_C6_order_p  GC1123    -1
    pool_task_rank_C6_order_p  GC1164    1
    pool_task_rank_C6_order_p  GC1180    -1
    pool_task_rank_C6_order_p  GC1477    1
    pool_task_rank_C6_order_p  GC1489    -1
    pool_task_rank_C6_order_p  GC1509    1
    pool_task_rank_C6_order_p  GC1521    1
    pool_task_rank_C6_order_p  GC1541    1
    pool_task_rank_C6_order_p  GC1565    1
    pool_task_rank_C6_order_p  GC1569    1
    pool_task_rank_C6_order_p  GC1581    1
    pool_task_rank_C34_order_d  R750      -1
    pool_task_rank_C34_order_d  GC1221    1
    pool_task_rank_C34_order_d  GC1231    -1
    pool_task_rank_C34_order_d  GC1241    1
    pool_task_rank_C34_order_d  GC1251    -1
    pool_task_rank_C34_order_d  GC1261    1
    pool_task_rank_C34_order_d  GC1271    -1
    pool_task_rank_C34_order_d  GC1277    1
    pool_task_rank_C34_order_d  GC1289    -1
    pool_task_rank_C34_order_d  GC1589    -1
    pool_task_rank_C34_order_d  GC1593    -1
    pool_task_rank_C34_order_p  R750      1
    pool_task_rank_C34_order_p  GC1223    1
    pool_task_rank_C34_order_p  GC1229    -1
    pool_task_rank_C34_order_p  GC1243    1
    pool_task_rank_C34_order_p  GC1249    -1
    pool_task_rank_C34_order_p  GC1263    1
    pool_task_rank_C34_order_p  GC1269    -1
    pool_task_rank_C34_order_p  GC1281    1
    pool_task_rank_C34_order_p  GC1285    -1
    pool_task_rank_C34_order_p  GC1589    1
    pool_task_rank_C34_order_p  GC1591    -1
    pool_task_rank_C95_order_d  R751      -1
    pool_task_rank_C95_order_d  GC1217    1
    pool_task_rank_C95_order_d  GC1227    -1
    pool_task_rank_C95_order_d  GC1237    1
    pool_task_rank_C95_order_d  GC1247    -1
    pool_task_rank_C95_order_d  GC1257    1
    pool_task_rank_C95_order_d  GC1267    -1
    pool_task_rank_C95_order_d  GC1279    1
    pool_task_rank_C95_order_d  GC1291    -1
    pool_task_rank_C95_order_d  GC1587    -1
    pool_task_rank_C95_order_p  R751      1
    pool_task_rank_C95_order_p  GC1219    1
    pool_task_rank_C95_order_p  GC1225    -1
    pool_task_rank_C95_order_p  GC1239    1
    pool_task_rank_C95_order_p  GC1245    -1
    pool_task_rank_C95_order_p  GC1259    1
    pool_task_rank_C95_order_p  GC1265    -1
    pool_task_rank_C95_order_p  GC1283    1
    pool_task_rank_C95_order_p  GC1287    -1
    pool_task_rank_C95_order_p  GC1587    1
    pool_task_rank_C95_order_p  GC1591    1
    pool_task_rank_C95_order_p  GC1593    1
    MARKER    'MARKER'                 'INTORG'
    pool_choice_0[0]  OBJ       6
    pool_choice_0[0]  R752      1
    pool_choice_0[0]  R753      -60
    pool_choice_0[0]  R759      -1
    pool_choice_0[0]  R779      -1
    pool_choice_0[0]  R799      -1
    pool_choice_0[0]  R809      -1
    pool_choice_0[0]  pool_cover_C85_order_d  1
    pool_choice_0[0]  pool_cover_C85_order_p  1
    pool_choice_0[0]  R1618     -1
    pool_choice_0[1]  OBJ       6
    pool_choice_0[1]  R752      1
    pool_choice_0[1]  R753      -60
    pool_choice_0[1]  R759      -1
    pool_choice_0[1]  R780      -1
    pool_choice_0[1]  R809      -1
    pool_choice_0[1]  pool_cover_C85_order_d  1
    pool_choice_0[2]  OBJ       6
    pool_choice_0[2]  R752      1
    pool_choice_0[2]  R760      -1
    pool_choice_0[2]  R779      -1
    pool_choice_0[2]  R799      -1
    pool_choice_0[2]  pool_cover_C85_order_p  1
    pool_choice_0[3]  OBJ       2.0396078054371138e+01
    pool_choice_0[3]  R752      1
    pool_choice_0[3]  R753      -60
    pool_choice_0[3]  R761      -1
    pool_choice_0[3]  R781      -1
    pool_choice_0[3]  R800      -1
    pool_choice_0[3]  R810      -1
    pool_choice_0[3]  pool_cover_C81_order_d  1
    pool_choice_0[3]  pool_cover_C81_order_p  1
    pool_choice_0[3]  R1619     -1
    pool_choice_0[4]  OBJ       2.4166091947189145e+01
    pool_choice_0[4]  R752      1
    pool_choice_0[4]  R753      -60
    pool_choice_0[4]  R762      -1
    pool_choice_0[4]  R782      -1
    pool_choice_0[4]  R801      -1
    pool_choice_0[4]  R810      -1
    pool_choice_0[4]  pool_cover_C90_order_d  1
    pool_choice_0[4]  pool_cover_C90_order_p  1
    pool_choice_0[4]  R1620     -1
    pool_choice_0[5]  OBJ       3.0265491900843113e+01
    pool_choice_0[5]  R752      1
    pool_choice_0[5]  R753      -60
    pool_choice_0[5]  R763      -1
    pool_choice_0[5]  R783      -1
    pool_choice_0[5]  R802      -1
    pool_choice_0[5]  R811      -1
    pool_choice_0[5]  pool_cover_C0_order_d  1
    pool_choice_0[5]  pool_cover_C0_order_p  1
    pool_choice_0[5]  R1621     -1
    pool_choice_0[6]  OBJ       3.4234485537247380e+01
    pool_choice_0[6]  R752      1
    pool_choice_0[6]  R753      -60
    pool_choice_0[6]  R764      -1
    pool_choice_0[6]  R784      -1
    pool_choice_0[6]  R803      -1
    pool_choice_0[6]  R809      -1
    pool_choice_0[6]  pool_cover_C75_order_d  1
    pool_choice_0[6]  pool_cover_C75_order_p  1
    pool_choice_0[6]  R1622     -1
    pool_choice_0[7]  OBJ       2.0396078054371138e+01
    pool_choice_0[7]  R752      1
    pool_choice_0[7]  R753      -60
    pool_choice_0[7]  R761      -1
    pool_choice_0[7]  R785      -1
    pool_choice_0[7]  R810      -1
    pool_choice_0[7]  pool_cover_C81_order_d  1
    pool_choice_0[8]  OBJ       2.0396078054371138e+01
    pool_choice_0[8]  R752      1
    pool_choice_0[8]  R765      -1
    pool_choice_0[8]  R781      -1
    pool_choice_0[8]  R800      -1
    pool_choice_0[8]  pool_cover_C81_order_p  1
    pool_choice_0[9]  OBJ       2.4166091947189145e+01
    pool_choice_0[9]  R752      1
    pool_choice_0[9]  R753      -60
    pool_choice_0[9]  R762      -1
    pool_choice_0[9]  R786      -1
    pool_choice_0[9]  R810      -1
    pool_choice_0[9]  pool_cover_C90_order_d  1
    pool_choice_0[10]  OBJ       2.4166091947189145e+01
    pool_choice_0[10]  R752      1
    pool_choice_0[10]  R766      -1
    pool_choice_0[10]  R782      -1
    pool_choice_0[10]  R801      -1
    pool_choice_0[10]  pool_cover_C90_order_p  1
    pool_choice_0[11]  OBJ       5.4037024344425184e+01
    pool_choice_0[11]  R752      1
    pool_choice_0[11]  R753      -60
    pool_choice_0[11]  R767      -1
    pool_choice_0[11]  R787      -1
    pool_choice_0[11]  R804      -1
    pool_choice_0[11]  R810      -1
    pool_choice_0[11]  pool_cover_C97_order_d  1
    pool_choice_0[11]  pool_cover_C97_order_p  1
    pool_choice_0[11]  R1623     -1
    pool_choice_0[12]  OBJ       5.6320511361314892e+01
    pool_choice_0[12]  R752      1
    pool_choice_0[12]  R753      -60
    pool_choice_0[12]  R768      -1
    pool_choice_0[12]  R788      -1
    pool_choice_0[12]  R805      -1
    pool_choice_0[12]  R811      -1
    pool_choice_0[12]  pool_cover_C39_order_d  1
    pool_choice_0[12]  pool_cover_C39_order_p  1
    pool_choice_0[12]  R1624     -1
    pool_choice_0[13]  OBJ       5.6885850613311568e+01
    pool_choice_0[13]  R752      1
    pool_choice_0[13]  R753      -60
    pool_choice_0[13]  R769      -1
    pool_choice_0[13]  R789      -1
    pool_choice_0[13]  R806      -1
    pool_choice_0[13]  R809      -1
    pool_choice_0[13]  pool_cover_C21_order_d  1
    pool_choice_0[13]  pool_cover_C21_order_p  1
    pool_choice_0[13]  R1625     -1
    pool_choice_0[14]  OBJ       3.0265491900843113e+01
    pool_choice_0[14]  R752      1
    pool_choice_0[14]  R753      -60
    pool_choice_0[14]  R763      -1
    pool_choice_0[14]  R790      -1
    pool_choice_0[14]  R811      -1
    pool_choice_0[14]  pool_cover_C0_order_d  1
    pool_choice_0[15]  OBJ       3.0265491900843113e+01
    pool_choice_0[15]  R752      1
    pool_choice_0[15]  R770      -1
    pool_choice_0[15]  R783      -1
    pool_choice_0[15]  R802      -1
    pool_choice_0[15]  pool_cover_C0_order_p  1
    pool_choice_0[16]  OBJ       6.2289646009589745e+01
    pool_choice_0[16]  R752      1
    pool_choice_0[16]  R753      -60
    pool_choice_0[16]  R771      -1
    pool_choice_0[16]  R791      -1
    pool_choice_0[16]  R807      -1
    pool_choice_0[16]  R811      -1
    pool_choice_0[16]  pool_cover_C52_order_d  1
    pool_choice_0[16]  pool_cover_C52_order_p  1
    pool_choice_0[16]  R1626     -1
    pool_choice_0[17]  OBJ       6.4280634719952786e+01
    pool_choice_0[17]  R752      1
    pool_choice_0[17]  R753      -60
    pool_choice_0[17]  R772      -1
    pool_choice_0[17]  R792      -1
    pool_choice_0[17]  R808      -1
    pool_choice_0[17]  R810      -1
    pool_choice_0[17]  pool_cover_C51_order_d  1
    pool_choice_0[17]  pool_cover_C51_order_p  1
    pool_choice_0[17]  R1627     -1
    pool_choice_0[18]  OBJ       3.4234485537247380e+01
    pool_choice_0[18]  R752      1
    pool_choice_0[18]  R753      -60
    pool_choice_0[18]  R764      -1
    pool_choice_0[18]  R793      -1
    pool_choice_0[18]  R809      -1
    pool_choice_0[18]  pool_cover_C75_order_d  1
    pool_choice_0[19]  OBJ       3.4234485537247380e+01
    pool_choice_0[19]  R752      1
    pool_choice_0[19]  R773      -1
    pool_choice_0[19]  R784      -1
    pool_choice_0[19]  R803      -1
    pool_choice_0[19]  pool_cover_C75_order_p  1
    pool_choice_0[20]  OBJ       5.4037024344425184e+01
    pool_choice_0[20]  R752      1
    pool_choice_0[20]  R753      -60
    pool_choice_0[20]  R767      -1
    pool_choice_0[20]  R794      -1
    pool_choice_0[20]  R810      -1
    pool_choice_0[20]  pool_cover_C97_order_d  1
    pool_choice_0[21]  OBJ       5.4037024344425184e+01
    pool_choice_0[21]  R752      1
    pool_choice_0[21]  R774      -1
    pool_choice_0[21]  R787      -1
    pool_choice_0[21]  R804      -1
    pool_choice_0[21]  pool_cover_C97_order_p  1
    pool_choice_0[22]  OBJ       5.6320511361314892e+01
    pool_choice_0[22]  R752      1
    pool_choice_0[22]  R753      -60
    pool_choice_0[22]  R768      -1
    pool_choice_0[22]  R795      -1
    pool_choice_0[22]  R811      -1
    pool_choice_0[22]  pool_cover_C39_order_d  1
    pool_choice_0[23]  OBJ       5.6320511361314892e+01
    pool_choice_0[23]  R752      1
    pool_choice_0[23]  R775      -1
    pool_choice_0[23]  R788      -1
    pool_choice_0[23]  R805      -1
    pool_choice_0[23]  pool_cover_C39_order_p  1
    pool_choice_0[24]  OBJ       5.6885850613311568e+01
    pool_choice_0[24]  R752      1
    pool_choice_0[24]  R753      -60
    pool_choice_0[24]  R769      -1
    pool_choice_0[24]  R796      -1
    pool_choice_0[24]  R809      -1
    pool_choice_0[24]  pool_cover_C21_order_d  1
    pool_choice_0[25]  OBJ       5.6885850613311568e+01
    pool_choice_0[25]  R752      1
    pool_choice_0[25]  R776      -1
    pool_choice_0[25]  R789      -1
    pool_choice_0[25]  R806      -1
    pool_choice_0[25]  pool_cover_C21_order_p  1
    pool_choice_0[26]  OBJ       6.2289646009589745e+01
    pool_choice_0[26]  R752      1
    pool_choice_0[26]  R753      -60
    pool_choice_0[26]  R771      -1
    pool_choice_0[26]  R797      -1
    pool_choice_0[26]  R811      -1
    pool_choice_0[26]  pool_cover_C52_order_d  1
    pool_choice_0[27]  OBJ       6.2289646009589745e+01
    pool_choice_0[27]  R752      1
    pool_choice_0[27]  R777      -1
    pool_choice_0[27]  R791      -1
    pool_choice_0[27]  R807      -1
    pool_choice_0[27]  pool_cover_C52_order_p  1
    pool_choice_0[28]  OBJ       6.4280634719952786e+01
    pool_choice_0[28]  R752      1
    pool_choice_0[28]  R753      -60
    pool_choice_0[28]  R772      -1
    pool_choice_0[28]  R798      -1
    pool_choice_0[28]  R810      -1
    pool_choice_0[28]  pool_cover_C51_order_d  1
    pool_choice_0[29]  OBJ       6.4280634719952786e+01
    pool_choice_0[29]  R752      1
    pool_choice_0[29]  R778      -1
    pool_choice_0[29]  R792      -1
    pool_choice_0[29]  R808      -1
    pool_choice_0[29]  pool_cover_C51_order_p  1
    pool_choice_0[30]  OBJ       3.6209473277964264e+01
    pool_choice_0[30]  R752      1
    pool_choice_0[30]  R753      -60
    pool_choice_0[30]  R761      -1
    pool_choice_0[30]  R786      -1
    pool_choice_0[30]  R810      -1
    pool_choice_0[30]  pool_cover_C81_order_d  1
    pool_choice_0[30]  pool_cover_C90_order_d  1
    pool_choice_0[30]  R1628     -1
    pool_choice_0[31]  OBJ       2.0478148916466086e+01
    pool_choice_0[31]  R752      1
    pool_choice_0[31]  R753      -60
    pool_choice_0[31]  R761      -1
    pool_choice_0[31]  R779      -1
    pool_choice_0[31]  R799      -1
    pool_choice_0[31]  R800      -1
    pool_choice_0[31]  R810      -1
    pool_choice_0[31]  pool_cover_C81_order_d  1
    pool_choice_0[31]  pool_cover_C81_order_p  1
    pool_choice_0[31]  pool_cover_C85_order_p  1
    pool_choice_0[31]  R1619     -1
    pool_choice_0[31]  R1629     -1
    pool_choice_0[32]  OBJ       8.4133301895330391e+01
    pool_choice_0[32]  R752      1
    pool_choice_0[32]  R753      -60
    pool_choice_0[32]  R763      -1
    pool_choice_0[32]  R795      -1
    pool_choice_0[32]  R811      -1
    pool_choice_0[32]  pool_cover_C0_order_d  1
    pool_choice_0[32]  pool_cover_C39_order_d  1
    pool_choice_0[32]  pool_cover_C52_order_d  1
    pool_choice_0[32]  R1630     -1
    pool_choice_0[32]  R1631     -1
    pool_choice_0[33]  OBJ       4.0324927052090487e+01
    pool_choice_0[33]  R752      1
    pool_choice_0[33]  R753      -60
    pool_choice_0[33]  R763      -1
    pool_choice_0[33]  R779      -1
    pool_choice_0[33]  R799      -1
    pool_choice_0[33]  R802      -1
    pool_choice_0[33]  R803      -1
    pool_choice_0[33]  R811      -1
    pool_choice_0[33]  pool_cover_C0_order_d  1
    pool_choice_0[33]  pool_cover_C0_order_p  1
    pool_choice_0[33]  pool_cover_C85_order_p  1
    pool_choice_0[33]  pool_cover_C75_order_p  1
    pool_choice_0[33]  R1621     -1
    pool_choice_0[33]  R1632     -1
    pool_choice_0[33]  R1633     -1
    pool_choice_0[34]  OBJ       2.0478148916466086e+01
    pool_choice_0[34]  R752      1
    pool_choice_0[34]  R765      -1
    pool_choice_0[34]  R779      -1
    pool_choice_0[34]  R799      -1
    pool_choice_0[34]  R800      -1
    pool_choice_0[34]  pool_cover_C81_order_p  1
    pool_choice_0[34]  pool_cover_C85_order_p  1
    pool_choice_0[34]  R1629     -1
    pool_choice_0[35]  OBJ       2.6263385861093521e+01
    pool_choice_0[35]  R752      1
    pool_choice_0[35]  R753      -60
    pool_choice_0[35]  R762      -1
    pool_choice_0[35]  R779      -1
    pool_choice_0[35]  R799      -1
    pool_choice_0[35]  R801      -1
    pool_choice_0[35]  R810      -1
    pool_choice_0[35]  pool_cover_C90_order_d  1
    pool_choice_0[35]  pool_cover_C90_order_p  1
    pool_choice_0[35]  pool_cover_C85_order_p  1
    pool_choice_0[35]  R1620     -1
    pool_choice_0[35]  R1634     -1
    pool_choice_0[36]  OBJ       3.3166042328794461e+01
    pool_choice_0[36]  R752      1
    pool_choice_0[36]  R753      -60
    pool_choice_0[36]  R763      -1
    pool_choice_0[36]  R779      -1
    pool_choice_0[36]  R799      -1
    pool_choice_0[36]  R802      -1
    pool_choice_0[36]  R811      -1
    pool_choice_0[36]  pool_cover_C0_order_d  1
    pool_choice_0[36]  pool_cover_C0_order_p  1
    pool_choice_0[36]  pool_cover_C85_order_p  1
    pool_choice_0[36]  R1621     -1
    pool_choice_0[36]  R1635     -1
    pool_choice_0[37]  OBJ       3.7837287915293039e+01
    pool_choice_0[37]  R752      1
    pool_choice_0[37]  R753      -60
    pool_choice_0[37]  R759      -1
    pool_choice_0[37]  R793      -1
    pool_choice_0[37]  R809      -1
    pool_choice_0[37]  pool_cover_C85_order_d  1
    pool_choice_0[37]  pool_cover_C75_order_d  1
    pool_choice_0[37]  R1636     -1
    pool_choice_0[38]  OBJ       41.4400902933387
    pool_choice_0[38]  R752      1
    pool_choice_0[38]  R753      -60
    pool_choice_0[38]  R759      -1
    pool_choice_0[38]  R779      -1
    pool_choice_0[38]  R799      -1
    pool_choice_0[38]  R803      -1
    pool_choice_0[38]  R809      -1
    pool_choice_0[38]  pool_cover_C85_order_d  1
    pool_choice_0[38]  pool_cover_C85_order_p  1
    pool_choice_0[38]  pool_cover_C75_order_d  1
    pool_choice_0[38]  pool_cover_C75_order_p  1
    pool_choice_0[38]  R1622     -1
    pool_choice_0[38]  R1633     -1
    pool_choice_0[38]  R1636     -1
    pool_choice_0[39]  OBJ       3.5116342351967482e+01
    pool_choice_0[39]  R752      1
    pool_choice_0[39]  R766      -1
    pool_choice_0[39]  R779      -1
    pool_choice_0[39]  R799      -1
    pool_choice_0[39]  R801      -1
    pool_choice_0[39]  R802      -1
    pool_choice_0[39]  pool_cover_C90_order_p  1
    pool_choice_0[39]  pool_cover_C0_order_p  1
    pool_choice_0[39]  pool_cover_C85_order_p  1
    pool_choice_0[39]  R1635     -1
    pool_choice_0[39]  R1637     -1
    pool_choice_0[40]  OBJ       6.3709853449601354e+01
    pool_choice_0[40]  R752      1
    pool_choice_0[40]  R753      -60
    pool_choice_0[40]  R761      -1
    pool_choice_0[40]  R786      -1
    pool_choice_0[40]  R810      -1
    pool_choice_0[40]  pool_cover_C81_order_d  1
    pool_choice_0[40]  pool_cover_C90_order_d  1
    pool_choice_0[40]  pool_cover_C97_order_d  1
    pool_choice_0[40]  R1638     -1
    pool_choice_0[40]  R1639     -1
    pool_choice_0[41]  OBJ       3.5116342351967482e+01
    pool_choice_0[41]  R752      1
    pool_choice_0[41]  R753      -60
    pool_choice_0[41]  R762      -1
    pool_choice_0[41]  R779      -1
    pool_choice_0[41]  R799      -1
    pool_choice_0[41]  R801      -1
    pool_choice_0[41]  R802      -1
    pool_choice_0[41]  R810      -1
    pool_choice_0[41]  pool_cover_C90_order_d  1
    pool_choice_0[41]  pool_cover_C90_order_p  1
    pool_choice_0[41]  pool_cover_C0_order_p  1
    pool_choice_0[41]  pool_cover_C85_order_p  1
    pool_choice_0[41]  R1620     -1
    pool_choice_0[41]  R1635     -1
    pool_choice_0[41]  R1637     -1
    pool_choice_0[42]  OBJ       6.6013282617951688e+01
    pool_choice_0[42]  R752      1
    pool_choice_0[42]  R753      -60
    pool_choice_0[42]  R768      -1
    pool_choice_0[42]  R797      -1
    pool_choice_0[42]  R811      -1
    pool_choice_0[42]  pool_cover_C39_order_d  1
    pool_choice_0[42]  pool_cover_C52_order_d  1
    pool_choice_0[42]  R1640     -1
    pool_choice_0[43]  OBJ       3.6722124674044828e+01
    pool_choice_0[43]  R752      1
    pool_choice_0[43]  R753      -60
    pool_choice_0[43]  R763      -1
    pool_choice_0[43]  R784      -1
    pool_choice_0[43]  R802      -1
    pool_choice_0[43]  R803      -1
    pool_choice_0[43]  R811      -1
    pool_choice_0[43]  pool_cover_C0_order_d  1
    pool_choice_0[43]  pool_cover_C0_order_p  1
    pool_choice_0[43]  pool_cover_C75_order_p  1
    pool_choice_0[43]  R1621     -1
    pool_choice_0[43]  R1632     -1
    pool_choice_0[44]  OBJ       5.6938022874619705e+01
    pool_choice_0[44]  R752      1
    pool_choice_0[44]  R753      -60
    pool_choice_0[44]  R759      -1
    pool_choice_0[44]  R796      -1
    pool_choice_0[44]  R809      -1
    pool_choice_0[44]  pool_cover_C85_order_d  1
    pool_choice_0[44]  pool_cover_C21_order_d  1
    pool_choice_0[44]  R1641     -1
    pool_choice_0[45]  OBJ       3.7837287915293039e+01
    pool_choice_0[45]  R752      1
    pool_choice_0[45]  R753      -60
    pool_choice_0[45]  R764      -1
    pool_choice_0[45]  R779      -1
    pool_choice_0[45]  R799      -1
    pool_choice_0[45]  R803      -1
    pool_choice_0[45]  R809      -1
    pool_choice_0[45]  pool_cover_C85_order_p  1
    pool_choice_0[45]  pool_cover_C75_order_d  1
    pool_choice_0[45]  pool_cover_C75_order_p  1
    pool_choice_0[45]  R1622     -1
    pool_choice_0[45]  R1633     -1
    pool_choice_0[46]  OBJ       3.6291544140059209e+01
    pool_choice_0[46]  R752      1
    pool_choice_0[46]  R766      -1
    pool_choice_0[46]  R779      -1
    pool_choice_0[46]  R799      -1
    pool_choice_0[46]  R800      -1
    pool_choice_0[46]  R801      -1
    pool_choice_0[46]  pool_cover_C81_order_p  1
    pool_choice_0[46]  pool_cover_C90_order_p  1
    pool_choice_0[46]  pool_cover_C85_order_p  1
    pool_choice_0[46]  R1629     -1
    pool_choice_0[46]  R1642     -1
    pool_choice_0[47]  OBJ       6.6004157126226886e+01
    pool_choice_0[47]  R752      1
    pool_choice_0[47]  R753      -60
    pool_choice_0[47]  R761      -1
    pool_choice_0[47]  R798      -1
    pool_choice_0[47]  R810      -1
    pool_choice_0[47]  pool_cover_C81_order_d  1
    pool_choice_0[47]  pool_cover_C97_order_d  1
    pool_choice_0[47]  pool_cover_C51_order_d  1
    pool_choice_0[47]  R1638     -1
    pool_choice_0[47]  R1643     -1
    pool_choice_0[48]  OBJ       3.6291544140059209e+01
    pool_choice_0[48]  R752      1
    pool_choice_0[48]  R753      -60
    pool_choice_0[48]  R762      -1
    pool_choice_0[48]  R779      -1
    pool_choice_0[48]  R799      -1
    pool_choice_0[48]  R800      -1
    pool_choice_0[48]  R810      -1
    pool_choice_0[48]  pool_cover_C81_order_d  1
    pool_choice_0[48]  pool_cover_C81_order_p  1
    pool_choice_0[48]  pool_cover_C90_order_d  1
    pool_choice_0[48]  pool_cover_C85_order_p  1
    pool_choice_0[48]  R1619     -1
    pool_choice_0[48]  R1629     -1
    pool_choice_0[48]  R1644     -1
    pool_choice_0[49]  OBJ       71.9286437576317
    pool_choice_0[49]  R752      1
    pool_choice_0[49]  R753      -60
    pool_choice_0[49]  R763      -1
    pool_choice_0[49]  R795      -1
    pool_choice_0[49]  R811      -1
    pool_choice_0[49]  pool_cover_C0_order_d  1
    pool_choice_0[49]  pool_cover_C39_order_d  1
    pool_choice_0[49]  R1645     -1
    pool_choice_0[50]  OBJ       4.0324927052090487e+01
    pool_choice_0[50]  R752      1
    pool_choice_0[50]  R753      -60
    pool_choice_0[50]  R763      -1
    pool_choice_0[50]  R779      -1
    pool_choice_0[50]  R799      -1
    pool_choice_0[50]  R803      -1
    pool_choice_0[50]  R811      -1
    pool_choice_0[50]  pool_cover_C0_order_d  1
    pool_choice_0[50]  pool_cover_C85_order_p  1
    pool_choice_0[50]  pool_cover_C75_order_p  1
    pool_choice_0[50]  R1633     -1
    pool_choice_0[50]  R1646     -1
    pool_choice_0[51]  OBJ       3.7837287915293039e+01
    pool_choice_0[51]  R752      1
    pool_choice_0[51]  R753      -60
    pool_choice_0[51]  R759      -1
    pool_choice_0[51]  R784      -1
    pool_choice_0[51]  R803      -1
    pool_choice_0[51]  R809      -1
    pool_choice_0[51]  pool_cover_C85_order_d  1
    pool_choice_0[51]  pool_cover_C75_order_d  1
    pool_choice_0[51]  pool_cover_C75_order_p  1
    pool_choice_0[51]  R1622     -1
    pool_choice_0[51]  R1636     -1
    pool_choice_0[52]  OBJ       3.8672424697217842e+01
    pool_choice_0[52]  R752      1
    pool_choice_0[52]  R766      -1
    pool_choice_0[52]  R784      -1
    pool_choice_0[52]  R801      -1
    pool_choice_0[52]  R802      -1
    pool_choice_0[52]  R803      -1
    pool_choice_0[52]  pool_cover_C90_order_p  1
    pool_choice_0[52]  pool_cover_C0_order_p  1
    pool_choice_0[52]  pool_cover_C75_order_p  1
    pool_choice_0[52]  R1632     -1
    pool_choice_0[52]  R1637     -1
    pool_choice_0[53]  OBJ       3.6291544140059209e+01
    pool_choice_0[53]  R752      1
    pool_choice_0[53]  R753      -60
    pool_choice_0[53]  R762      -1
    pool_choice_0[53]  R779      -1
    pool_choice_0[53]  R799      -1
    pool_choice_0[53]  R800      -1
    pool_choice_0[53]  R801      -1
    pool_choice_0[53]  R810      -1
    pool_choice_0[53]  pool_cover_C81_order_p  1
    pool_choice_0[53]  pool_cover_C90_order_d  1
    pool_choice_0[53]  pool_cover_C90_order_p  1
    pool_choice_0[53]  pool_cover_C85_order_p  1
    pool_choice_0[53]  R1620     -1
    pool_choice_0[53]  R1629     -1
    pool_choice_0[53]  R1642     -1
    pool_choice_0[54]  OBJ       8.0409665286968448e+01
    pool_choice_0[54]  R752      1
    pool_choice_0[54]  R753      -60
    pool_choice_0[54]  R763      -1
    pool_choice_0[54]  R797      -1
    pool_choice_0[54]  R811      -1
    pool_choice_0[54]  pool_cover_C0_order_d  1
    pool_choice_0[54]  pool_cover_C52_order_d  1
    pool_choice_0[54]  R1630     -1
    pool_choice_0[55]  OBJ       6.8348124505258170e+01
    pool_choice_0[55]  R752      1
    pool_choice_0[55]  R753      -60
    pool_choice_0[55]  R771      -1
    pool_choice_0[55]  R779      -1
    pool_choice_0[55]  R799      -1
    pool_choice_0[55]  R805      -1
    pool_choice_0[55]  R806      -1
    pool_choice_0[55]  R811      -1
    pool_choice_0[55]  pool_cover_C39_order_d  1
    pool_choice_0[55]  pool_cover_C39_order_p  1
    pool_choice_0[55]  pool_cover_C52_order_d  1
    pool_choice_0[55]  pool_cover_C85_order_p  1
    pool_choice_0[55]  pool_cover_C21_order_p  1
    pool_choice_0[55]  R1624     -1
    pool_choice_0[55]  R1631     -1
    pool_choice_0[55]  R1647     -1
    pool_choice_0[55]  R1648     -1
    pool_choice_0[56]  OBJ       7.7871156918086484e+01
    pool_choice_0[56]  R752      1
    pool_choice_0[56]  R753      -60
    pool_choice_0[56]  R769      -1
    pool_choice_0[56]  R793      -1
    pool_choice_0[56]  R809      -1
    pool_choice_0[56]  pool_cover_C75_order_d  1
    pool_choice_0[56]  pool_cover_C21_order_d  1
    pool_choice_0[56]  R1649     -1
    pool_choice_0[57]  OBJ       3.7837287915293039e+01
    pool_choice_0[57]  R752      1
    pool_choice_0[57]  R753      -60
    pool_choice_0[57]  R759      -1
    pool_choice_0[57]  R784      -1
    pool_choice_0[57]  R799      -1
    pool_choice_0[57]  R803      -1
    pool_choice_0[57]  R809      -1
    pool_choice_0[57]  pool_cover_C85_order_d  1
    pool_choice_0[57]  pool_cover_C85_order_p  1
    pool_choice_0[57]  pool_cover_C75_order_p  1
    pool_choice_0[57]  R1618     -1
    pool_choice_0[57]  R1650     -1
    pool_choice_0[58]  OBJ       2.6263385861093521e+01
    pool_choice_0[58]  R752      1
    pool_choice_0[58]  R766      -1
    pool_choice_0[58]  R779      -1
    pool_choice_0[58]  R799      -1
    pool_choice_0[58]  R801      -1
    pool_choice_0[58]  pool_cover_C90_order_p  1
    pool_choice_0[58]  pool_cover_C85_order_p  1
    pool_choice_0[58]  R1634     -1
    pool_choice_0[59]  OBJ       7.4792579518192952e+01
    pool_choice_0[59]  R752      1
    pool_choice_0[59]  R753      -60
    pool_choice_0[59]  R762      -1
    pool_choice_0[59]  R798      -1
    pool_choice_0[59]  R810      -1
    pool_choice_0[59]  pool_cover_C90_order_d  1
    pool_choice_0[59]  pool_cover_C97_order_d  1
    pool_choice_0[59]  pool_cover_C51_order_d  1
    pool_choice_0[59]  R1643     -1
    pool_choice_0[59]  R1651     -1
    pool_choice_0[60]  OBJ       4.7159723682742595e+01
    pool_choice_0[60]  R752      1
    pool_choice_0[60]  R753      -60
    pool_choice_0[60]  R761      -1
    pool_choice_0[60]  R779      -1
    pool_choice_0[60]  R799      -1
    pool_choice_0[60]  R801      -1
    pool_choice_0[60]  R802      -1
    pool_choice_0[60]  R810      -1
    pool_choice_0[60]  pool_cover_C81_order_d  1
    pool_choice_0[60]  pool_cover_C90_order_d  1
    pool_choice_0[60]  pool_cover_C90_order_p  1
    pool_choice_0[60]  pool_cover_C0_order_p  1
    pool_choice_0[60]  pool_cover_C85_order_p  1
    pool_choice_0[60]  R1620     -1
    pool_choice_0[60]  R1628     -1
    pool_choice_0[60]  R1635     -1
    pool_choice_0[60]  R1637     -1
    pool_choice_0[61]  OBJ       6.9756020169684533e+01
    pool_choice_0[61]  R752      1
    pool_choice_0[61]  R753      -60
    pool_choice_0[61]  R768      -1
    pool_choice_0[61]  R779      -1
    pool_choice_0[61]  R799      -1
    pool_choice_0[61]  R805      -1
    pool_choice_0[61]  R807      -1
    pool_choice_0[61]  R811      -1
    pool_choice_0[61]  pool_cover_C39_order_d  1
    pool_choice_0[61]  pool_cover_C39_order_p  1
    pool_choice_0[61]  pool_cover_C52_order_d  1
    pool_choice_0[61]  pool_cover_C52_order_p  1
    pool_choice_0[61]  pool_cover_C85_order_p  1
    pool_choice_0[61]  R1626     -1
    pool_choice_0[61]  R1640     -1
    pool_choice_0[61]  R1652     -1
    pool_choice_0[61]  R1653     -1
    pool_used_0  R752      -1
    pool_used_0  R753      -28800
    pool_used_0  R754      -75600
    pool_used_0  R755      -75540
    pool_used_0  R756      -1
    pool_used_0  R757      -80
    pool_used_0  R758      -80
    pool_used_0  R1767     -75660
    pool_used_0  R1768     -81
    pool_used_0  R1769     -75660
    pool_used_0  R1770     -81
    pool_used_0  R1771     -75660
    pool_used_0  R1772     -81
    pool_start_0  R753      1
    pool_start_0  R754      1
    pool_start_0  GC120     -1
    pool_start_0  GC122     -1
    pool_start_0  GC124     -1
    pool_start_0  GC126     -1
    pool_start_0  GC128     -1
    pool_start_0  GC130     -1
    pool_start_0  GC132     -1
    pool_start_0  GC134     -1
    pool_start_0  GC136     -1
    pool_start_0  GC138     -1
    pool_start_0  GC140     -1
    pool_start_0  GC142     -1
    pool_start_0  GC144     -1
    pool_start_0  GC146     -1
    pool_start_0  GC148     -1
    pool_start_0  GC150     -1
    pool_start_0  GC152     -1
    pool_start_0  GC154     -1
    pool_start_0  GC156     -1
    pool_start_0  GC158     -1
    pool_start_0  GC210     1
    pool_start_0  GC211     1
    pool_start_0  GC212     1
    pool_end_0  R755      1
    pool_end_0  R1767     -1
    pool_end_0  R1769     -1
    pool_end_0  R1771     -1
    pool_end_0  GC160     1
    pool_end_0  GC162     1
    pool_end_0  GC164     1
    pool_end_0  GC166     1
    pool_end_0  GC168     1
    pool_end_0  GC170     1
    pool_end_0  GC172     1
    pool_end_0  GC174     1
    pool_end_0  GC176     1
    pool_end_0  GC178     1
    pool_end_0  GC180     1
    pool_end_0  GC182     1
    pool_end_0  GC184     1
    pool_end_0  GC186     1
    pool_end_0  GC188     1
    pool_end_0  GC190     1
    pool_end_0  GC192     1
    pool_end_0  GC194     1
    pool_end_0  GC196     1
    pool_end_0  GC198     1
    pool_end_0  GC200     -1
    pool_end_0  GC201     -1
    pool_end_0  GC202     -1
    pool_end_0  GC203     -1
    pool_end_0  GC204     -1
    pool_end_0  GC205     -1
    pool_end_0  GC206     -1
    pool_end_0  GC207     -1
    pool_end_0  GC208     -1
    pool_end_0  GC209     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_0  R756      1
    pool_start_rank_0  R757      1
    pool_start_rank_0  GC121     -1
    pool_start_rank_0  GC123     -1
    pool_start_rank_0  GC125     -1
    pool_start_rank_0  GC127     -1
    pool_start_rank_0  GC129     -1
    pool_start_rank_0  GC131     -1
    pool_start_rank_0  GC133     -1
    pool_start_rank_0  GC135     -1
    pool_start_rank_0  GC137     -1
    pool_start_rank_0  GC139     -1
    pool_start_rank_0  GC141     -1
    pool_start_rank_0  GC143     -1
    pool_start_rank_0  GC145     -1
    pool_start_rank_0  GC147     -1
    pool_start_rank_0  GC149     -1
    pool_start_rank_0  GC151     -1
    pool_start_rank_0  GC153     -1
    pool_start_rank_0  GC155     -1
    pool_start_rank_0  GC157     -1
    pool_start_rank_0  GC159     -1
    pool_end_rank_0  R758      1
    pool_end_rank_0  R1768     -1
    pool_end_rank_0  R1770     -1
    pool_end_rank_0  R1772     -1
    pool_end_rank_0  GC161     1
    pool_end_rank_0  GC163     1
    pool_end_rank_0  GC165     1
    pool_end_rank_0  GC167     1
    pool_end_rank_0  GC169     1
    pool_end_rank_0  GC171     1
    pool_end_rank_0  GC173     1
    pool_end_rank_0  GC175     1
    pool_end_rank_0  GC177     1
    pool_end_rank_0  GC179     1
    pool_end_rank_0  GC181     1
    pool_end_rank_0  GC183     1
    pool_end_rank_0  GC185     1
    pool_end_rank_0  GC187     1
    pool_end_rank_0  GC189     1
    pool_end_rank_0  GC191     1
    pool_end_rank_0  GC193     1
    pool_end_rank_0  GC195     1
    pool_end_rank_0  GC197     1
    pool_end_rank_0  GC199     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_0_C85_order_d  R759      1
    pool_first_0_C85_order_p  R760      1
    pool_first_0_C81_order_d  R761      1
    pool_first_0_C90_order_d  R762      1
    pool_first_0_C0_order_d  R763      1
    pool_first_0_C75_order_d  R764      1
    pool_first_0_C81_order_p  R765      1
    pool_first_0_C90_order_p  R766      1
    pool_first_0_C97_order_d  R767      1
    pool_first_0_C39_order_d  R768      1
    pool_first_0_C21_order_d  R769      1
    pool_first_0_C0_order_p  R770      1
    pool_first_0_C52_order_d  R771      1
    pool_first_0_C51_order_d  R772      1
    pool_first_0_C75_order_p  R773      1
    pool_first_0_C97_order_p  R774      1
    pool_first_0_C39_order_p  R775      1
    pool_first_0_C21_order_p  R776      1
    pool_first_0_C52_order_p  R777      1
    pool_first_0_C51_order_p  R778      1
    pool_last_0_C85_order_p  R779      1
    pool_last_0_C85_order_d  R780      1
    pool_last_0_C81_order_p  R781      1
    pool_last_0_C90_order_p  R782      1
    pool_last_0_C0_order_p  R783      1
    pool_last_0_C75_order_p  R784      1
    pool_last_0_C81_order_d  R785      1
    pool_last_0_C90_order_d  R786      1
    pool_last_0_C97_order_p  R787      1
    pool_last_0_C39_order_p  R788      1
    pool_last_0_C21_order_p  R789      1
    pool_last_0_C0_order_d  R790      1
    pool_last_0_C52_order_p  R791      1
    pool_last_0_C51_order_p  R792      1
    pool_last_0_C75_order_d  R793      1
    pool_last_0_C97_order_d  R794      1
    pool_last_0_C39_order_d  R795      1
    pool_last_0_C21_order_d  R796      1
    pool_last_0_C52_order_d  R797      1
    pool_last_0_C51_order_d  R798      1
    pool_pickup_0_C85_order  R799      1
    pool_pickup_0_C81_order  R800      1
    pool_pickup_0_C90_order  R801      1
    pool_pickup_0_C0_order  R802      1
    pool_pickup_0_C75_order  R803      1
    pool_pickup_0_C97_order  R804      1
    pool_pickup_0_C39_order  R805      1
    pool_pickup_0_C21_order  R806      1
    pool_pickup_0_C52_order  R807      1
    pool_pickup_0_C51_order  R808      1
    pool_batch_0_b3  R809      1
    pool_batch_0_b1  R810      1
    pool_batch_0_b2  R811      1
    pool_choice_1[0]  OBJ       6.7727679532500972e+01
    pool_choice_1[0]  R812      1
    pool_choice_1[0]  R813      -60
    pool_choice_1[0]  R819      -1
    pool_choice_1[0]  R829      -1
    pool_choice_1[0]  R844      -1
    pool_choice_1[0]  R845      -1
    pool_choice_1[0]  R846      -1
    pool_choice_1[0]  R852      -1
    pool_choice_1[0]  pool_cover_C81_order_d  1
    pool_choice_1[0]  pool_cover_C81_order_p  1
    pool_choice_1[0]  pool_cover_C97_order_d  1
    pool_choice_1[0]  pool_cover_C97_order_p  1
    pool_choice_1[0]  pool_cover_C51_order_d  1
    pool_choice_1[0]  pool_cover_C51_order_p  1
    pool_choice_1[0]  R1627     -1
    pool_choice_1[0]  R1638     -1
    pool_choice_1[0]  R1643     -1
    pool_choice_1[0]  R1654     -1
    pool_choice_1[0]  R1655     -1
    pool_choice_1[0]  R1767     -60
    pool_choice_1[1]  OBJ       7.6516101924467051e+01
    pool_choice_1[1]  R812      1
    pool_choice_1[1]  R813      -60
    pool_choice_1[1]  R819      -1
    pool_choice_1[1]  R830      -1
    pool_choice_1[1]  R844      -1
    pool_choice_1[1]  R845      -1
    pool_choice_1[1]  R847      -1
    pool_choice_1[1]  R852      -1
    pool_choice_1[1]  pool_cover_C81_order_d  1
    pool_choice_1[1]  pool_cover_C90_order_p  1
    pool_choice_1[1]  pool_cover_C97_order_d  1
    pool_choice_1[1]  pool_cover_C97_order_p  1
    pool_choice_1[1]  pool_cover_C51_order_d  1
    pool_choice_1[1]  pool_cover_C51_order_p  1
    pool_choice_1[1]  R1627     -1
    pool_choice_1[1]  R1638     -1
    pool_choice_1[1]  R1643     -1
    pool_choice_1[1]  R1654     -1
    pool_choice_1[1]  R1656     -1
    pool_choice_1[1]  R1767     -60
    pool_choice_1[2]  OBJ       7.6516101924467051e+01
    pool_choice_1[2]  R812      1
    pool_choice_1[2]  R813      -60
    pool_choice_1[2]  R820      -1
    pool_choice_1[2]  R829      -1
    pool_choice_1[2]  R844      -1
    pool_choice_1[2]  R845      -1
    pool_choice_1[2]  R846      -1
    pool_choice_1[2]  R852      -1
    pool_choice_1[2]  pool_cover_C81_order_p  1
    pool_choice_1[2]  pool_cover_C90_order_d  1
    pool_choice_1[2]  pool_cover_C97_order_d  1
    pool_choice_1[2]  pool_cover_C97_order_p  1
    pool_choice_1[2]  pool_cover_C51_order_d  1
    pool_choice_1[2]  pool_cover_C51_order_p  1
    pool_choice_1[2]  R1627     -1
    pool_choice_1[2]  R1643     -1
    pool_choice_1[2]  R1651     -1
    pool_choice_1[2]  R1654     -1
    pool_choice_1[2]  R1655     -1
    pool_choice_1[2]  R1767     -60
    pool_choice_1[3]  OBJ       7.8890842813846987e+01
    pool_choice_1[3]  R812      1
    pool_choice_1[3]  R813      -60
    pool_choice_1[3]  R819      -1
    pool_choice_1[3]  R829      -1
    pool_choice_1[3]  R844      -1
    pool_choice_1[3]  R845      -1
    pool_choice_1[3]  R846      -1
    pool_choice_1[3]  R852      -1
    pool_choice_1[3]  pool_cover_C81_order_d  1
    pool_choice_1[3]  pool_cover_C81_order_p  1
    pool_choice_1[3]  pool_cover_C97_order_d  1
    pool_choice_1[3]  pool_cover_C97_order_p  1
    pool_choice_1[3]  pool_cover_C51_order_d  1
    pool_choice_1[3]  pool_cover_C51_order_p  1
    pool_choice_1[3]  R1638     -1
    pool_choice_1[3]  R1643     -1
    pool_choice_1[3]  R1657     -1
    pool_choice_1[3]  R1658     -1
    pool_choice_1[3]  R1659     -1
    pool_choice_1[3]  R1767     -60
    pool_choice_1[4]  OBJ       6.6084594338981290e+01
    pool_choice_1[4]  R812      1
    pool_choice_1[4]  R813      -60
    pool_choice_1[4]  R819      -1
    pool_choice_1[4]  R829      -1
    pool_choice_1[4]  R844      -1
    pool_choice_1[4]  R846      -1
    pool_choice_1[4]  R852      -1
    pool_choice_1[4]  pool_cover_C81_order_d  1
    pool_choice_1[4]  pool_cover_C81_order_p  1
    pool_choice_1[4]  pool_cover_C97_order_d  1
    pool_choice_1[4]  pool_cover_C51_order_d  1
    pool_choice_1[4]  pool_cover_C51_order_p  1
    pool_choice_1[4]  R1627     -1
    pool_choice_1[4]  R1638     -1
    pool_choice_1[4]  R1643     -1
    pool_choice_1[4]  R1659     -1
    pool_choice_1[4]  R1767     -60
    pool_choice_1[5]  OBJ       66.0845943389813
    pool_choice_1[5]  R812      1
    pool_choice_1[5]  R813      -60
    pool_choice_1[5]  R819      -1
    pool_choice_1[5]  R829      -1
    pool_choice_1[5]  R844      -1
    pool_choice_1[5]  R845      -1
    pool_choice_1[5]  R846      -1
    pool_choice_1[5]  R852      -1
    pool_choice_1[5]  pool_cover_C81_order_d  1
    pool_choice_1[5]  pool_cover_C81_order_p  1
    pool_choice_1[5]  pool_cover_C97_order_p  1
    pool_choice_1[5]  pool_cover_C51_order_d  1
    pool_choice_1[5]  pool_cover_C51_order_p  1
    pool_choice_1[5]  R1627     -1
    pool_choice_1[5]  R1654     -1
    pool_choice_1[5]  R1655     -1
    pool_choice_1[5]  R1660     -1
    pool_choice_1[5]  R1767     -60
    pool_choice_1[6]  OBJ       6.7285476175895923e+01
    pool_choice_1[6]  R812      1
    pool_choice_1[6]  R813      -60
    pool_choice_1[6]  R819      -1
    pool_choice_1[6]  R831      -1
    pool_choice_1[6]  R844      -1
    pool_choice_1[6]  R845      -1
    pool_choice_1[6]  R852      -1
    pool_choice_1[6]  pool_cover_C81_order_d  1
    pool_choice_1[6]  pool_cover_C97_order_d  1
    pool_choice_1[6]  pool_cover_C97_order_p  1
    pool_choice_1[6]  pool_cover_C51_order_d  1
    pool_choice_1[6]  pool_cover_C51_order_p  1
    pool_choice_1[6]  R1627     -1
    pool_choice_1[6]  R1638     -1
    pool_choice_1[6]  R1643     -1
    pool_choice_1[6]  R1654     -1
    pool_choice_1[6]  R1767     -60
    pool_choice_1[7]  OBJ       6.7285476175895937e+01
    pool_choice_1[7]  R812      1
    pool_choice_1[7]  R813      -60
    pool_choice_1[7]  R821      -1
    pool_choice_1[7]  R829      -1
    pool_choice_1[7]  R844      -1
    pool_choice_1[7]  R845      -1
    pool_choice_1[7]  R846      -1
    pool_choice_1[7]  R852      -1
    pool_choice_1[7]  pool_cover_C81_order_p  1
    pool_choice_1[7]  pool_cover_C97_order_d  1
    pool_choice_1[7]  pool_cover_C97_order_p  1
    pool_choice_1[7]  pool_cover_C51_order_d  1
    pool_choice_1[7]  pool_cover_C51_order_p  1
    pool_choice_1[7]  R1627     -1
    pool_choice_1[7]  R1643     -1
    pool_choice_1[7]  R1654     -1
    pool_choice_1[7]  R1655     -1
    pool_choice_1[7]  R1767     -60
    pool_choice_1[8]  OBJ       6.7727679532500972e+01
    pool_choice_1[8]  R812      1
    pool_choice_1[8]  R813      -60
    pool_choice_1[8]  R819      -1
    pool_choice_1[8]  R829      -1
    pool_choice_1[8]  R845      -1
    pool_choice_1[8]  R846      -1
    pool_choice_1[8]  R852      -1
    pool_choice_1[8]  pool_cover_C81_order_d  1
    pool_choice_1[8]  pool_cover_C81_order_p  1
    pool_choice_1[8]  pool_cover_C97_order_d  1
    pool_choice_1[8]  pool_cover_C97_order_p  1
    pool_choice_1[8]  pool_cover_C51_order_d  1
    pool_choice_1[8]  R1638     -1
    pool_choice_1[8]  R1643     -1
    pool_choice_1[8]  R1655     -1
    pool_choice_1[8]  R1657     -1
    pool_choice_1[8]  R1767     -60
    pool_choice_1[9]  OBJ       6.7727679532500972e+01
    pool_choice_1[9]  R812      1
    pool_choice_1[9]  R813      -60
    pool_choice_1[9]  R819      -1
    pool_choice_1[9]  R829      -1
    pool_choice_1[9]  R844      -1
    pool_choice_1[9]  R845      -1
    pool_choice_1[9]  R846      -1
    pool_choice_1[9]  R852      -1
    pool_choice_1[9]  pool_cover_C81_order_d  1
    pool_choice_1[9]  pool_cover_C81_order_p  1
    pool_choice_1[9]  pool_cover_C97_order_d  1
    pool_choice_1[9]  pool_cover_C97_order_p  1
    pool_choice_1[9]  pool_cover_C51_order_p  1
    pool_choice_1[9]  R1638     -1
    pool_choice_1[9]  R1654     -1
    pool_choice_1[9]  R1655     -1
    pool_choice_1[9]  R1661     -1
    pool_choice_1[9]  R1767     -60
    pool_choice_1[10]  OBJ       5.4921431057635274e+01
    pool_choice_1[10]  R812      1
    pool_choice_1[10]  R813      -60
    pool_choice_1[10]  R819      -1
    pool_choice_1[10]  R829      -1
    pool_choice_1[10]  R845      -1
    pool_choice_1[10]  R846      -1
    pool_choice_1[10]  R852      -1
    pool_choice_1[10]  pool_cover_C81_order_d  1
    pool_choice_1[10]  pool_cover_C81_order_p  1
    pool_choice_1[10]  pool_cover_C97_order_d  1
    pool_choice_1[10]  pool_cover_C97_order_p  1
    pool_choice_1[10]  R1623     -1
    pool_choice_1[10]  R1638     -1
    pool_choice_1[10]  R1655     -1
    pool_choice_1[10]  R1767     -60
    pool_choice_1[11]  OBJ       8.5304524316433145e+01
    pool_choice_1[11]  R812      1
    pool_choice_1[11]  R813      -60
    pool_choice_1[11]  R820      -1
    pool_choice_1[11]  R830      -1
    pool_choice_1[11]  R844      -1
    pool_choice_1[11]  R845      -1
    pool_choice_1[11]  R847      -1
    pool_choice_1[11]  R852      -1
    pool_choice_1[11]  pool_cover_C90_order_d  1
    pool_choice_1[11]  pool_cover_C90_order_p  1
    pool_choice_1[11]  pool_cover_C97_order_d  1
    pool_choice_1[11]  pool_cover_C97_order_p  1
    pool_choice_1[11]  pool_cover_C51_order_d  1
    pool_choice_1[11]  pool_cover_C51_order_p  1
    pool_choice_1[11]  R1627     -1
    pool_choice_1[11]  R1643     -1
    pool_choice_1[11]  R1651     -1
    pool_choice_1[11]  R1654     -1
    pool_choice_1[11]  R1656     -1
    pool_choice_1[11]  R1767     -60
    pool_choice_1[12]  OBJ       8.8404079722111277e+01
    pool_choice_1[12]  R812      1
    pool_choice_1[12]  R813      -60
    pool_choice_1[12]  R819      -1
    pool_choice_1[12]  R829      -1
    pool_choice_1[12]  R844      -1
    pool_choice_1[12]  R845      -1
    pool_choice_1[12]  R846      -1
    pool_choice_1[12]  R852      -1
    pool_choice_1[12]  pool_cover_C81_order_d  1
    pool_choice_1[12]  pool_cover_C81_order_p  1
    pool_choice_1[12]  pool_cover_C90_order_d  1
    pool_choice_1[12]  pool_cover_C97_order_p  1
    pool_choice_1[12]  pool_cover_C51_order_d  1
    pool_choice_1[12]  pool_cover_C51_order_p  1
    pool_choice_1[12]  R1627     -1
    pool_choice_1[12]  R1628     -1
    pool_choice_1[12]  R1654     -1
    pool_choice_1[12]  R1655     -1
    pool_choice_1[12]  R1662     -1
    pool_choice_1[12]  R1767     -60
    pool_choice_1[13]  OBJ       8.8404079722111291e+01
    pool_choice_1[13]  R812      1
    pool_choice_1[13]  R813      -60
    pool_choice_1[13]  R819      -1
    pool_choice_1[13]  R829      -1
    pool_choice_1[13]  R844      -1
    pool_choice_1[13]  R846      -1
    pool_choice_1[13]  R847      -1
    pool_choice_1[13]  R852      -1
    pool_choice_1[13]  pool_cover_C81_order_d  1
    pool_choice_1[13]  pool_cover_C81_order_p  1
    pool_choice_1[13]  pool_cover_C90_order_p  1
    pool_choice_1[13]  pool_cover_C97_order_d  1
    pool_choice_1[13]  pool_cover_C51_order_d  1
    pool_choice_1[13]  pool_cover_C51_order_p  1
    pool_choice_1[13]  R1627     -1
    pool_choice_1[13]  R1638     -1
    pool_choice_1[13]  R1642     -1
    pool_choice_1[13]  R1643     -1
    pool_choice_1[13]  R1663     -1
    pool_choice_1[13]  R1767     -60
    pool_choice_1[14]  OBJ       1.0528577372779915e+02
    pool_choice_1[14]  R812      1
    pool_choice_1[14]  R813      -60
    pool_choice_1[14]  R819      -1
    pool_choice_1[14]  R832      -1
    pool_choice_1[14]  R844      -1
    pool_choice_1[14]  R845      -1
    pool_choice_1[14]  R846      -1
    pool_choice_1[14]  R848      -1
    pool_choice_1[14]  R852      -1
    pool_choice_1[14]  pool_cover_C81_order_d  1
    pool_choice_1[14]  pool_cover_C81_order_p  1
    pool_choice_1[14]  pool_cover_C97_order_d  1
    pool_choice_1[14]  pool_cover_C97_order_p  1
    pool_choice_1[14]  pool_cover_C51_order_d  1
    pool_choice_1[14]  pool_cover_C51_order_p  1
    pool_choice_1[14]  pool_cover_C21_order_p  1
    pool_choice_1[14]  R1627     -1
    pool_choice_1[14]  R1638     -1
    pool_choice_1[14]  R1643     -1
    pool_choice_1[14]  R1654     -1
    pool_choice_1[14]  R1655     -1
    pool_choice_1[14]  R1664     -1
    pool_choice_1[14]  R1767     -60
    pool_choice_1[15]  OBJ       6.4441509145461623e+01
    pool_choice_1[15]  R812      1
    pool_choice_1[15]  R813      -60
    pool_choice_1[15]  R819      -1
    pool_choice_1[15]  R829      -1
    pool_choice_1[15]  R844      -1
    pool_choice_1[15]  R846      -1
    pool_choice_1[15]  R852      -1
    pool_choice_1[15]  pool_cover_C81_order_d  1
    pool_choice_1[15]  pool_cover_C81_order_p  1
    pool_choice_1[15]  pool_cover_C51_order_d  1
    pool_choice_1[15]  pool_cover_C51_order_p  1
    pool_choice_1[15]  R1627     -1
    pool_choice_1[15]  R1659     -1
    pool_choice_1[15]  R1660     -1
    pool_choice_1[15]  R1767     -60
    pool_choice_1[16]  OBJ       6.6843272819290888e+01
    pool_choice_1[16]  R812      1
    pool_choice_1[16]  R813      -60
    pool_choice_1[16]  R821      -1
    pool_choice_1[16]  R831      -1
    pool_choice_1[16]  R844      -1
    pool_choice_1[16]  R845      -1
    pool_choice_1[16]  R852      -1
    pool_choice_1[16]  pool_cover_C97_order_d  1
    pool_choice_1[16]  pool_cover_C97_order_p  1
    pool_choice_1[16]  pool_cover_C51_order_d  1
    pool_choice_1[16]  pool_cover_C51_order_p  1
    pool_choice_1[16]  R1627     -1
    pool_choice_1[16]  R1643     -1
    pool_choice_1[16]  R1654     -1
    pool_choice_1[16]  R1767     -60
    pool_choice_1[17]  OBJ       1.0325361495201358e+02
    pool_choice_1[17]  R812      1
    pool_choice_1[17]  R813      -60
    pool_choice_1[17]  R819      -1
    pool_choice_1[17]  R829      -1
    pool_choice_1[17]  R845      -1
    pool_choice_1[17]  R846      -1
    pool_choice_1[17]  R847      -1
    pool_choice_1[17]  R852      -1
    pool_choice_1[17]  pool_cover_C81_order_d  1
    pool_choice_1[17]  pool_cover_C81_order_p  1
    pool_choice_1[17]  pool_cover_C90_order_d  1
    pool_choice_1[17]  pool_cover_C90_order_p  1
    pool_choice_1[17]  pool_cover_C97_order_d  1
    pool_choice_1[17]  pool_cover_C97_order_p  1
    pool_choice_1[17]  R1620     -1
    pool_choice_1[17]  R1638     -1
    pool_choice_1[17]  R1639     -1
    pool_choice_1[17]  R1655     -1
    pool_choice_1[17]  R1665     -1
    pool_choice_1[17]  R1767     -60
    pool_choice_1[18]  OBJ       1.0908047991172158e+02
    pool_choice_1[18]  R812      1
    pool_choice_1[18]  R813      -60
    pool_choice_1[18]  R819      -1
    pool_choice_1[18]  R829      -1
    pool_choice_1[18]  R844      -1
    pool_choice_1[18]  R846      -1
    pool_choice_1[18]  R847      -1
    pool_choice_1[18]  R852      -1
    pool_choice_1[18]  pool_cover_C81_order_d  1
    pool_choice_1[18]  pool_cover_C81_order_p  1
    pool_choice_1[18]  pool_cover_C90_order_d  1
    pool_choice_1[18]  pool_cover_C90_order_p  1
    pool_choice_1[18]  pool_cover_C51_order_d  1
    pool_choice_1[18]  pool_cover_C51_order_p  1
    pool_choice_1[18]  R1627     -1
    pool_choice_1[18]  R1628     -1
    pool_choice_1[18]  R1642     -1
    pool_choice_1[18]  R1662     -1
    pool_choice_1[18]  R1663     -1
    pool_choice_1[18]  R1767     -60
    pool_choice_1[19]  OBJ       1.1590445989374837e+02
    pool_choice_1[19]  R812      1
    pool_choice_1[19]  R813      -60
    pool_choice_1[19]  R819      -1
    pool_choice_1[19]  R829      -1
    pool_choice_1[19]  R844      -1
    pool_choice_1[19]  R845      -1
    pool_choice_1[19]  R846      -1
    pool_choice_1[19]  R852      -1
    pool_choice_1[19]  pool_cover_C81_order_d  1
    pool_choice_1[19]  pool_cover_C81_order_p  1
    pool_choice_1[19]  pool_cover_C90_order_d  1
    pool_choice_1[19]  pool_cover_C97_order_d  1
    pool_choice_1[19]  pool_cover_C97_order_p  1
    pool_choice_1[19]  pool_cover_C51_order_p  1
    pool_choice_1[19]  R1638     -1
    pool_choice_1[19]  R1639     -1
    pool_choice_1[19]  R1654     -1
    pool_choice_1[19]  R1655     -1
    pool_choice_1[19]  R1666     -1
    pool_choice_1[19]  R1767     -60
    pool_choice_1[20]  OBJ       1.1590445989374838e+02
    pool_choice_1[20]  R812      1
    pool_choice_1[20]  R813      -60
    pool_choice_1[20]  R819      -1
    pool_choice_1[20]  R829      -1
    pool_choice_1[20]  R845      -1
    pool_choice_1[20]  R846      -1
    pool_choice_1[20]  R847      -1
    pool_choice_1[20]  R852      -1
    pool_choice_1[20]  pool_cover_C81_order_d  1
    pool_choice_1[20]  pool_cover_C81_order_p  1
    pool_choice_1[20]  pool_cover_C90_order_p  1
    pool_choice_1[20]  pool_cover_C97_order_d  1
    pool_choice_1[20]  pool_cover_C97_order_p  1
    pool_choice_1[20]  pool_cover_C51_order_d  1
    pool_choice_1[20]  R1638     -1
    pool_choice_1[20]  R1643     -1
    pool_choice_1[20]  R1655     -1
    pool_choice_1[20]  R1665     -1
    pool_choice_1[20]  R1667     -1
    pool_choice_1[20]  R1767     -60
    pool_choice_1[21]  OBJ       6
    pool_choice_1[21]  R812      1
    pool_choice_1[21]  R822      -1
    pool_choice_1[21]  R833      -1
    pool_choice_1[21]  R849      -1
    pool_choice_1[21]  pool_cover_C85_order_p  1
    pool_choice_1[22]  OBJ       3.6209473277964264e+01
    pool_choice_1[22]  R812      1
    pool_choice_1[22]  R813      -60
    pool_choice_1[22]  R819      -1
    pool_choice_1[22]  R834      -1
    pool_choice_1[22]  R852      -1
    pool_choice_1[22]  pool_cover_C81_order_d  1
    pool_choice_1[22]  pool_cover_C90_order_d  1
    pool_choice_1[22]  R1628     -1
    pool_choice_1[22]  R1767     -60
    pool_choice_1[23]  OBJ       2.0478148916466086e+01
    pool_choice_1[23]  R812      1
    pool_choice_1[23]  R813      -60
    pool_choice_1[23]  R819      -1
    pool_choice_1[23]  R833      -1
    pool_choice_1[23]  R846      -1
    pool_choice_1[23]  R849      -1
    pool_choice_1[23]  R852      -1
    pool_choice_1[23]  pool_cover_C81_order_d  1
    pool_choice_1[23]  pool_cover_C81_order_p  1
    pool_choice_1[23]  pool_cover_C85_order_p  1
    pool_choice_1[23]  R1619     -1
    pool_choice_1[23]  R1629     -1
    pool_choice_1[23]  R1767     -60
    pool_choice_1[24]  OBJ       8.4133301895330391e+01
    pool_choice_1[24]  R812      1
    pool_choice_1[24]  R813      -60
    pool_choice_1[24]  R823      -1
    pool_choice_1[24]  R835      -1
    pool_choice_1[24]  R853      -1
    pool_choice_1[24]  pool_cover_C0_order_d  1
    pool_choice_1[24]  pool_cover_C39_order_d  1
    pool_choice_1[24]  pool_cover_C52_order_d  1
    pool_choice_1[24]  R1630     -1
    pool_choice_1[24]  R1631     -1
    pool_choice_1[24]  R1767     -60
    pool_choice_1[25]  OBJ       4.0324927052090487e+01
    pool_choice_1[25]  R812      1
    pool_choice_1[25]  R813      -60
    pool_choice_1[25]  R823      -1
    pool_choice_1[25]  R833      -1
    pool_choice_1[25]  R849      -1
    pool_choice_1[25]  R850      -1
    pool_choice_1[25]  R851      -1
    pool_choice_1[25]  R853      -1
    pool_choice_1[25]  pool_cover_C0_order_d  1
    pool_choice_1[25]  pool_cover_C0_order_p  1
    pool_choice_1[25]  pool_cover_C85_order_p  1
    pool_choice_1[25]  pool_cover_C75_order_p  1
    pool_choice_1[25]  R1621     -1
    pool_choice_1[25]  R1632     -1
    pool_choice_1[25]  R1633     -1
    pool_choice_1[25]  R1767     -60
    pool_choice_1[26]  OBJ       6
    pool_choice_1[26]  R812      1
    pool_choice_1[26]  R813      -60
    pool_choice_1[26]  R824      -1
    pool_choice_1[26]  R836      -1
    pool_choice_1[26]  R854      -1
    pool_choice_1[26]  pool_cover_C85_order_d  1
    pool_choice_1[26]  R1767     -60
    pool_choice_1[27]  OBJ       6
    pool_choice_1[27]  R812      1
    pool_choice_1[27]  R813      -60
    pool_choice_1[27]  R824      -1
    pool_choice_1[27]  R833      -1
    pool_choice_1[27]  R849      -1
    pool_choice_1[27]  R854      -1
    pool_choice_1[27]  pool_cover_C85_order_d  1
    pool_choice_1[27]  pool_cover_C85_order_p  1
    pool_choice_1[27]  R1618     -1
    pool_choice_1[27]  R1767     -60
    pool_choice_1[28]  OBJ       2.0478148916466086e+01
    pool_choice_1[28]  R812      1
    pool_choice_1[28]  R825      -1
    pool_choice_1[28]  R833      -1
    pool_choice_1[28]  R846      -1
    pool_choice_1[28]  R849      -1
    pool_choice_1[28]  pool_cover_C81_order_p  1
    pool_choice_1[28]  pool_cover_C85_order_p  1
    pool_choice_1[28]  R1629     -1
    pool_choice_1[29]  OBJ       2.0396078054371138e+01
    pool_choice_1[29]  R812      1
    pool_choice_1[29]  R813      -60
    pool_choice_1[29]  R819      -1
    pool_choice_1[29]  R837      -1
    pool_choice_1[29]  R852      -1
    pool_choice_1[29]  pool_cover_C81_order_d  1
    pool_choice_1[29]  R1767     -60
    pool_choice_1[30]  OBJ       2.6263385861093521e+01
    pool_choice_1[30]  R812      1
    pool_choice_1[30]  R813      -60
    pool_choice_1[30]  R820      -1
    pool_choice_1[30]  R833      -1
    pool_choice_1[30]  R847      -1
    pool_choice_1[30]  R849      -1
    pool_choice_1[30]  R852      -1
    pool_choice_1[30]  pool_cover_C90_order_d  1
    pool_choice_1[30]  pool_cover_C90_order_p  1
    pool_choice_1[30]  pool_cover_C85_order_p  1
    pool_choice_1[30]  R1620     -1
    pool_choice_1[30]  R1634     -1
    pool_choice_1[30]  R1767     -60
    pool_choice_1[31]  OBJ       3.0265491900843113e+01
    pool_choice_1[31]  R812      1
    pool_choice_1[31]  R813      -60
    pool_choice_1[31]  R823      -1
    pool_choice_1[31]  R838      -1
    pool_choice_1[31]  R853      -1
    pool_choice_1[31]  pool_cover_C0_order_d  1
    pool_choice_1[31]  R1767     -60
    pool_choice_1[32]  OBJ       3.3166042328794461e+01
    pool_choice_1[32]  R812      1
    pool_choice_1[32]  R813      -60
    pool_choice_1[32]  R823      -1
    pool_choice_1[32]  R833      -1
    pool_choice_1[32]  R849      -1
    pool_choice_1[32]  R850      -1
    pool_choice_1[32]  R853      -1
    pool_choice_1[32]  pool_cover_C0_order_d  1
    pool_choice_1[32]  pool_cover_C0_order_p  1
    pool_choice_1[32]  pool_cover_C85_order_p  1
    pool_choice_1[32]  R1621     -1
    pool_choice_1[32]  R1635     -1
    pool_choice_1[32]  R1767     -60
    pool_choice_1[33]  OBJ       3.7837287915293039e+01
    pool_choice_1[33]  R812      1
    pool_choice_1[33]  R813      -60
    pool_choice_1[33]  R824      -1
    pool_choice_1[33]  R839      -1
    pool_choice_1[33]  R854      -1
    pool_choice_1[33]  pool_cover_C85_order_d  1
    pool_choice_1[33]  pool_cover_C75_order_d  1
    pool_choice_1[33]  R1636     -1
    pool_choice_1[33]  R1767     -60
    pool_choice_1[34]  OBJ       41.4400902933387
    pool_choice_1[34]  R812      1
    pool_choice_1[34]  R813      -60
    pool_choice_1[34]  R824      -1
    pool_choice_1[34]  R833      -1
    pool_choice_1[34]  R849      -1
    pool_choice_1[34]  R851      -1
    pool_choice_1[34]  R854      -1
    pool_choice_1[34]  pool_cover_C85_order_d  1
    pool_choice_1[34]  pool_cover_C85_order_p  1
    pool_choice_1[34]  pool_cover_C75_order_d  1
    pool_choice_1[34]  pool_cover_C75_order_p  1
    pool_choice_1[34]  R1622     -1
    pool_choice_1[34]  R1633     -1
    pool_choice_1[34]  R1636     -1
    pool_choice_1[34]  R1767     -60
    pool_choice_1[35]  OBJ       3.5116342351967482e+01
    pool_choice_1[35]  R812      1
    pool_choice_1[35]  R826      -1
    pool_choice_1[35]  R833      -1
    pool_choice_1[35]  R847      -1
    pool_choice_1[35]  R849      -1
    pool_choice_1[35]  R850      -1
    pool_choice_1[35]  pool_cover_C90_order_p  1
    pool_choice_1[35]  pool_cover_C0_order_p  1
    pool_choice_1[35]  pool_cover_C85_order_p  1
    pool_choice_1[35]  R1635     -1
    pool_choice_1[35]  R1637     -1
    pool_choice_1[36]  OBJ       6.3709853449601354e+01
    pool_choice_1[36]  R812      1
    pool_choice_1[36]  R813      -60
    pool_choice_1[36]  R819      -1
    pool_choice_1[36]  R834      -1
    pool_choice_1[36]  R852      -1
    pool_choice_1[36]  pool_cover_C81_order_d  1
    pool_choice_1[36]  pool_cover_C90_order_d  1
    pool_choice_1[36]  pool_cover_C97_order_d  1
    pool_choice_1[36]  R1638     -1
    pool_choice_1[36]  R1639     -1
    pool_choice_1[36]  R1767     -60
    pool_choice_1[37]  OBJ       3.5116342351967482e+01
    pool_choice_1[37]  R812      1
    pool_choice_1[37]  R813      -60
    pool_choice_1[37]  R820      -1
    pool_choice_1[37]  R833      -1
    pool_choice_1[37]  R847      -1
    pool_choice_1[37]  R849      -1
    pool_choice_1[37]  R850      -1
    pool_choice_1[37]  R852      -1
    pool_choice_1[37]  pool_cover_C90_order_d  1
    pool_choice_1[37]  pool_cover_C90_order_p  1
    pool_choice_1[37]  pool_cover_C0_order_p  1
    pool_choice_1[37]  pool_cover_C85_order_p  1
    pool_choice_1[37]  R1620     -1
    pool_choice_1[37]  R1635     -1
    pool_choice_1[37]  R1637     -1
    pool_choice_1[37]  R1767     -60
    pool_choice_1[38]  OBJ       6.6013282617951688e+01
    pool_choice_1[38]  R812      1
    pool_choice_1[38]  R813      -60
    pool_choice_1[38]  R827      -1
    pool_choice_1[38]  R840      -1
    pool_choice_1[38]  R853      -1
    pool_choice_1[38]  pool_cover_C39_order_d  1
    pool_choice_1[38]  pool_cover_C52_order_d  1
    pool_choice_1[38]  R1640     -1
    pool_choice_1[38]  R1767     -60
    pool_choice_1[39]  OBJ       3.6722124674044828e+01
    pool_choice_1[39]  R812      1
    pool_choice_1[39]  R813      -60
    pool_choice_1[39]  R823      -1
    pool_choice_1[39]  R841      -1
    pool_choice_1[39]  R850      -1
    pool_choice_1[39]  R851      -1
    pool_choice_1[39]  R853      -1
    pool_choice_1[39]  pool_cover_C0_order_d  1
    pool_choice_1[39]  pool_cover_C0_order_p  1
    pool_choice_1[39]  pool_cover_C75_order_p  1
    pool_choice_1[39]  R1621     -1
    pool_choice_1[39]  R1632     -1
    pool_choice_1[39]  R1767     -60
    pool_choice_1[40]  OBJ       5.6938022874619705e+01
    pool_choice_1[40]  R812      1
    pool_choice_1[40]  R813      -60
    pool_choice_1[40]  R824      -1
    pool_choice_1[40]  R842      -1
    pool_choice_1[40]  R854      -1
    pool_choice_1[40]  pool_cover_C85_order_d  1
    pool_choice_1[40]  pool_cover_C21_order_d  1
    pool_choice_1[40]  R1641     -1
    pool_choice_1[40]  R1767     -60
    pool_choice_1[41]  OBJ       3.7837287915293039e+01
    pool_choice_1[41]  R812      1
    pool_choice_1[41]  R813      -60
    pool_choice_1[41]  R828      -1
    pool_choice_1[41]  R833      -1
    pool_choice_1[41]  R849      -1
    pool_choice_1[41]  R851      -1
    pool_choice_1[41]  R854      -1
    pool_choice_1[41]  pool_cover_C85_order_p  1
    pool_choice_1[41]  pool_cover_C75_order_d  1
    pool_choice_1[41]  pool_cover_C75_order_p  1
    pool_choice_1[41]  R1622     -1
    pool_choice_1[41]  R1633     -1
    pool_choice_1[41]  R1767     -60
    pool_choice_1[42]  OBJ       3.6291544140059209e+01
    pool_choice_1[42]  R812      1
    pool_choice_1[42]  R826      -1
    pool_choice_1[42]  R833      -1
    pool_choice_1[42]  R846      -1
    pool_choice_1[42]  R847      -1
    pool_choice_1[42]  R849      -1
    pool_choice_1[42]  pool_cover_C81_order_p  1
    pool_choice_1[42]  pool_cover_C90_order_p  1
    pool_choice_1[42]  pool_cover_C85_order_p  1
    pool_choice_1[42]  R1629     -1
    pool_choice_1[42]  R1642     -1
    pool_choice_1[43]  OBJ       6.6004157126226886e+01
    pool_choice_1[43]  R812      1
    pool_choice_1[43]  R813      -60
    pool_choice_1[43]  R819      -1
    pool_choice_1[43]  R843      -1
    pool_choice_1[43]  R852      -1
    pool_choice_1[43]  pool_cover_C81_order_d  1
    pool_choice_1[43]  pool_cover_C97_order_d  1
    pool_choice_1[43]  pool_cover_C51_order_d  1
    pool_choice_1[43]  R1638     -1
    pool_choice_1[43]  R1643     -1
    pool_choice_1[43]  R1767     -60
    pool_choice_1[44]  OBJ       3.6291544140059209e+01
    pool_choice_1[44]  R812      1
    pool_choice_1[44]  R813      -60
    pool_choice_1[44]  R820      -1
    pool_choice_1[44]  R833      -1
    pool_choice_1[44]  R846      -1
    pool_choice_1[44]  R849      -1
    pool_choice_1[44]  R852      -1
    pool_choice_1[44]  pool_cover_C81_order_d  1
    pool_choice_1[44]  pool_cover_C81_order_p  1
    pool_choice_1[44]  pool_cover_C90_order_d  1
    pool_choice_1[44]  pool_cover_C85_order_p  1
    pool_choice_1[44]  R1619     -1
    pool_choice_1[44]  R1629     -1
    pool_choice_1[44]  R1644     -1
    pool_choice_1[44]  R1767     -60
    pool_choice_1[45]  OBJ       71.9286437576317
    pool_choice_1[45]  R812      1
    pool_choice_1[45]  R813      -60
    pool_choice_1[45]  R823      -1
    pool_choice_1[45]  R835      -1
    pool_choice_1[45]  R853      -1
    pool_choice_1[45]  pool_cover_C0_order_d  1
    pool_choice_1[45]  pool_cover_C39_order_d  1
    pool_choice_1[45]  R1645     -1
    pool_choice_1[45]  R1767     -60
    pool_choice_1[46]  OBJ       4.0324927052090487e+01
    pool_choice_1[46]  R812      1
    pool_choice_1[46]  R813      -60
    pool_choice_1[46]  R823      -1
    pool_choice_1[46]  R833      -1
    pool_choice_1[46]  R849      -1
    pool_choice_1[46]  R851      -1
    pool_choice_1[46]  R853      -1
    pool_choice_1[46]  pool_cover_C0_order_d  1
    pool_choice_1[46]  pool_cover_C85_order_p  1
    pool_choice_1[46]  pool_cover_C75_order_p  1
    pool_choice_1[46]  R1633     -1
    pool_choice_1[46]  R1646     -1
    pool_choice_1[46]  R1767     -60
    pool_choice_1[47]  OBJ       3.4234485537247380e+01
    pool_choice_1[47]  R812      1
    pool_choice_1[47]  R813      -60
    pool_choice_1[47]  R828      -1
    pool_choice_1[47]  R839      -1
    pool_choice_1[47]  R854      -1
    pool_choice_1[47]  pool_cover_C75_order_d  1
    pool_choice_1[47]  R1767     -60
    pool_choice_1[48]  OBJ       3.7837287915293039e+01
    pool_choice_1[48]  R812      1
    pool_choice_1[48]  R813      -60
    pool_choice_1[48]  R824      -1
    pool_choice_1[48]  R841      -1
    pool_choice_1[48]  R851      -1
    pool_choice_1[48]  R854      -1
    pool_choice_1[48]  pool_cover_C85_order_d  1
    pool_choice_1[48]  pool_cover_C75_order_d  1
    pool_choice_1[48]  pool_cover_C75_order_p  1
    pool_choice_1[48]  R1622     -1
    pool_choice_1[48]  R1636     -1
    pool_choice_1[48]  R1767     -60
    pool_choice_1[49]  OBJ       3.8672424697217842e+01
    pool_choice_1[49]  R812      1
    pool_choice_1[49]  R826      -1
    pool_choice_1[49]  R841      -1
    pool_choice_1[49]  R847      -1
    pool_choice_1[49]  R850      -1
    pool_choice_1[49]  R851      -1
    pool_choice_1[49]  pool_cover_C90_order_p  1
    pool_choice_1[49]  pool_cover_C0_order_p  1
    pool_choice_1[49]  pool_cover_C75_order_p  1
    pool_choice_1[49]  R1632     -1
    pool_choice_1[49]  R1637     -1
    pool_choice_1[50]  OBJ       2.4166091947189145e+01
    pool_choice_1[50]  R812      1
    pool_choice_1[50]  R813      -60
    pool_choice_1[50]  R820      -1
    pool_choice_1[50]  R834      -1
    pool_choice_1[50]  R852      -1
    pool_choice_1[50]  pool_cover_C90_order_d  1
    pool_choice_1[50]  R1767     -60
    pool_choice_1[51]  OBJ       3.6291544140059209e+01
    pool_choice_1[51]  R812      1
    pool_choice_1[51]  R813      -60
    pool_choice_1[51]  R820      -1
    pool_choice_1[51]  R833      -1
    pool_choice_1[51]  R846      -1
    pool_choice_1[51]  R847      -1
    pool_choice_1[51]  R849      -1
    pool_choice_1[51]  R852      -1
    pool_choice_1[51]  pool_cover_C81_order_p  1
    pool_choice_1[51]  pool_cover_C90_order_d  1
    pool_choice_1[51]  pool_cover_C90_order_p  1
    pool_choice_1[51]  pool_cover_C85_order_p  1
    pool_choice_1[51]  R1620     -1
    pool_choice_1[51]  R1629     -1
    pool_choice_1[51]  R1642     -1
    pool_choice_1[51]  R1767     -60
    pool_choice_1[52]  OBJ       8.0409665286968448e+01
    pool_choice_1[52]  R812      1
    pool_choice_1[52]  R813      -60
    pool_choice_1[52]  R823      -1
    pool_choice_1[52]  R840      -1
    pool_choice_1[52]  R853      -1
    pool_choice_1[52]  pool_cover_C0_order_d  1
    pool_choice_1[52]  pool_cover_C52_order_d  1
    pool_choice_1[52]  R1630     -1
    pool_choice_1[52]  R1767     -60
    pool_used_1  R812      -1
    pool_used_1  R813      -28800
    pool_used_1  R814      -75600
    pool_used_1  R815      -75540
    pool_used_1  R816      -1
    pool_used_1  R817      -80
    pool_used_1  R818      -80
    pool_used_1  R1767     -75660
    pool_used_1  R1768     -81
    pool_used_1  R1773     -75660
    pool_used_1  R1774     -81
    pool_used_1  R1775     -75660
    pool_used_1  R1776     -81
    pool_start_1  R813      1
    pool_start_1  R814      1
    pool_start_1  R1767     1
    pool_start_1  GC213     -1
    pool_start_1  GC215     -1
    pool_start_1  GC217     -1
    pool_start_1  GC219     -1
    pool_start_1  GC221     -1
    pool_start_1  GC223     -1
    pool_start_1  GC225     -1
    pool_start_1  GC227     -1
    pool_start_1  GC229     -1
    pool_start_1  GC231     -1
    pool_start_1  GC271     1
    pool_start_1  GC272     1
    pool_start_1  GC273     1
    pool_end_1  R815      1
    pool_end_1  R1773     -1
    pool_end_1  R1775     -1
    pool_end_1  GC233     1
    pool_end_1  GC235     1
    pool_end_1  GC237     1
    pool_end_1  GC239     1
    pool_end_1  GC241     1
    pool_end_1  GC243     1
    pool_end_1  GC245     1
    pool_end_1  GC247     1
    pool_end_1  GC249     1
    pool_end_1  GC251     1
    pool_end_1  GC253     1
    pool_end_1  GC255     1
    pool_end_1  GC257     1
    pool_end_1  GC259     1
    pool_end_1  GC261     1
    pool_end_1  GC263     -1
    pool_end_1  GC264     -1
    pool_end_1  GC265     -1
    pool_end_1  GC266     -1
    pool_end_1  GC267     -1
    pool_end_1  GC268     -1
    pool_end_1  GC269     -1
    pool_end_1  GC270     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_1  R816      1
    pool_start_rank_1  R817      1
    pool_start_rank_1  R1768     1
    pool_start_rank_1  GC214     -1
    pool_start_rank_1  GC216     -1
    pool_start_rank_1  GC218     -1
    pool_start_rank_1  GC220     -1
    pool_start_rank_1  GC222     -1
    pool_start_rank_1  GC224     -1
    pool_start_rank_1  GC226     -1
    pool_start_rank_1  GC228     -1
    pool_start_rank_1  GC230     -1
    pool_start_rank_1  GC232     -1
    pool_end_rank_1  R818      1
    pool_end_rank_1  R1774     -1
    pool_end_rank_1  R1776     -1
    pool_end_rank_1  GC234     1
    pool_end_rank_1  GC236     1
    pool_end_rank_1  GC238     1
    pool_end_rank_1  GC240     1
    pool_end_rank_1  GC242     1
    pool_end_rank_1  GC244     1
    pool_end_rank_1  GC246     1
    pool_end_rank_1  GC248     1
    pool_end_rank_1  GC250     1
    pool_end_rank_1  GC252     1
    pool_end_rank_1  GC254     1
    pool_end_rank_1  GC256     1
    pool_end_rank_1  GC258     1
    pool_end_rank_1  GC260     1
    pool_end_rank_1  GC262     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_1_C81_order_d  R819      1
    pool_first_1_C90_order_d  R820      1
    pool_first_1_C97_order_d  R821      1
    pool_first_1_C85_order_p  R822      1
    pool_first_1_C0_order_d  R823      1
    pool_first_1_C85_order_d  R824      1
    pool_first_1_C81_order_p  R825      1
    pool_first_1_C90_order_p  R826      1
    pool_first_1_C39_order_d  R827      1
    pool_first_1_C75_order_d  R828      1
    pool_last_1_C81_order_p  R829      1
    pool_last_1_C90_order_p  R830      1
    pool_last_1_C97_order_p  R831      1
    pool_last_1_C21_order_p  R832      1
    pool_last_1_C85_order_p  R833      1
    pool_last_1_C90_order_d  R834      1
    pool_last_1_C39_order_d  R835      1
    pool_last_1_C85_order_d  R836      1
    pool_last_1_C81_order_d  R837      1
    pool_last_1_C0_order_d  R838      1
    pool_last_1_C75_order_d  R839      1
    pool_last_1_C52_order_d  R840      1
    pool_last_1_C75_order_p  R841      1
    pool_last_1_C21_order_d  R842      1
    pool_last_1_C51_order_d  R843      1
    pool_pickup_1_C51_order  R844      1
    pool_pickup_1_C97_order  R845      1
    pool_pickup_1_C81_order  R846      1
    pool_pickup_1_C90_order  R847      1
    pool_pickup_1_C21_order  R848      1
    pool_pickup_1_C85_order  R849      1
    pool_pickup_1_C0_order  R850      1
    pool_pickup_1_C75_order  R851      1
    pool_batch_1_b1  R852      1
    pool_batch_1_b2  R853      1
    pool_batch_1_b3  R854      1
    pool_choice_2[0]  OBJ       3.0265491900843113e+01
    pool_choice_2[0]  R855      1
    pool_choice_2[0]  R856      -60
    pool_choice_2[0]  R862      -1
    pool_choice_2[0]  R874      -1
    pool_choice_2[0]  R890      -1
    pool_choice_2[0]  R898      -1
    pool_choice_2[0]  pool_cover_C0_order_d  1
    pool_choice_2[0]  pool_cover_C0_order_p  1
    pool_choice_2[0]  R1621     -1
    pool_choice_2[0]  R1769     -60
    pool_choice_2[0]  R1773     -60
    pool_choice_2[1]  OBJ       3.3166042328794461e+01
    pool_choice_2[1]  R855      1
    pool_choice_2[1]  R856      -60
    pool_choice_2[1]  R862      -1
    pool_choice_2[1]  R875      -1
    pool_choice_2[1]  R890      -1
    pool_choice_2[1]  R891      -1
    pool_choice_2[1]  R898      -1
    pool_choice_2[1]  pool_cover_C0_order_d  1
    pool_choice_2[1]  pool_cover_C0_order_p  1
    pool_choice_2[1]  pool_cover_C85_order_p  1
    pool_choice_2[1]  R1621     -1
    pool_choice_2[1]  R1635     -1
    pool_choice_2[1]  R1769     -60
    pool_choice_2[1]  R1773     -60
    pool_choice_2[2]  OBJ       2.4166091947189145e+01
    pool_choice_2[2]  R855      1
    pool_choice_2[2]  R856      -60
    pool_choice_2[2]  R863      -1
    pool_choice_2[2]  R876      -1
    pool_choice_2[2]  R892      -1
    pool_choice_2[2]  R899      -1
    pool_choice_2[2]  pool_cover_C90_order_d  1
    pool_choice_2[2]  pool_cover_C90_order_p  1
    pool_choice_2[2]  R1620     -1
    pool_choice_2[2]  R1769     -60
    pool_choice_2[2]  R1773     -60
    pool_choice_2[3]  OBJ       3.6722124674044828e+01
    pool_choice_2[3]  R855      1
    pool_choice_2[3]  R856      -60
    pool_choice_2[3]  R862      -1
    pool_choice_2[3]  R877      -1
    pool_choice_2[3]  R890      -1
    pool_choice_2[3]  R893      -1
    pool_choice_2[3]  R898      -1
    pool_choice_2[3]  pool_cover_C0_order_d  1
    pool_choice_2[3]  pool_cover_C0_order_p  1
    pool_choice_2[3]  pool_cover_C75_order_p  1
    pool_choice_2[3]  R1621     -1
    pool_choice_2[3]  R1632     -1
    pool_choice_2[3]  R1769     -60
    pool_choice_2[3]  R1773     -60
    pool_choice_2[4]  OBJ       3.4234485537247380e+01
    pool_choice_2[4]  R855      1
    pool_choice_2[4]  R856      -60
    pool_choice_2[4]  R864      -1
    pool_choice_2[4]  R877      -1
    pool_choice_2[4]  R893      -1
    pool_choice_2[4]  R900      -1
    pool_choice_2[4]  pool_cover_C75_order_d  1
    pool_choice_2[4]  pool_cover_C75_order_p  1
    pool_choice_2[4]  R1622     -1
    pool_choice_2[4]  R1769     -60
    pool_choice_2[4]  R1773     -60
    pool_choice_2[5]  OBJ       8.7536776153948523e+01
    pool_choice_2[5]  R855      1
    pool_choice_2[5]  R856      -60
    pool_choice_2[5]  R862      -1
    pool_choice_2[5]  R874      -1
    pool_choice_2[5]  R890      -1
    pool_choice_2[5]  R894      -1
    pool_choice_2[5]  R898      -1
    pool_choice_2[5]  pool_cover_C0_order_d  1
    pool_choice_2[5]  pool_cover_C0_order_p  1
    pool_choice_2[5]  pool_cover_C39_order_d  1
    pool_choice_2[5]  pool_cover_C39_order_p  1
    pool_choice_2[5]  R1624     -1
    pool_choice_2[5]  R1645     -1
    pool_choice_2[5]  R1668     -1
    pool_choice_2[5]  R1769     -60
    pool_choice_2[5]  R1773     -60
    pool_choice_2[6]  OBJ       7.1432447811445584e+01
    pool_choice_2[6]  R855      1
    pool_choice_2[6]  R856      -60
    pool_choice_2[6]  R862      -1
    pool_choice_2[6]  R878      -1
    pool_choice_2[6]  R890      -1
    pool_choice_2[6]  R895      -1
    pool_choice_2[6]  R898      -1
    pool_choice_2[6]  pool_cover_C0_order_d  1
    pool_choice_2[6]  pool_cover_C0_order_p  1
    pool_choice_2[6]  pool_cover_C21_order_p  1
    pool_choice_2[6]  R1621     -1
    pool_choice_2[6]  R1669     -1
    pool_choice_2[6]  R1769     -60
    pool_choice_2[6]  R1773     -60
    pool_choice_2[7]  OBJ       71.9286437576317
    pool_choice_2[7]  R855      1
    pool_choice_2[7]  R856      -60
    pool_choice_2[7]  R862      -1
    pool_choice_2[7]  R879      -1
    pool_choice_2[7]  R890      -1
    pool_choice_2[7]  R894      -1
    pool_choice_2[7]  R898      -1
    pool_choice_2[7]  pool_cover_C0_order_d  1
    pool_choice_2[7]  pool_cover_C0_order_p  1
    pool_choice_2[7]  pool_cover_C39_order_p  1
    pool_choice_2[7]  R1621     -1
    pool_choice_2[7]  R1670     -1
    pool_choice_2[7]  R1769     -60
    pool_choice_2[7]  R1773     -60
    pool_choice_2[8]  OBJ       9.8529684564347164e+01
    pool_choice_2[8]  R855      1
    pool_choice_2[8]  R856      -60
    pool_choice_2[8]  R862      -1
    pool_choice_2[8]  R874      -1
    pool_choice_2[8]  R890      -1
    pool_choice_2[8]  R896      -1
    pool_choice_2[8]  R898      -1
    pool_choice_2[8]  pool_cover_C0_order_d  1
    pool_choice_2[8]  pool_cover_C0_order_p  1
    pool_choice_2[8]  pool_cover_C52_order_d  1
    pool_choice_2[8]  pool_cover_C52_order_p  1
    pool_choice_2[8]  R1626     -1
    pool_choice_2[8]  R1630     -1
    pool_choice_2[8]  R1671     -1
    pool_choice_2[8]  R1769     -60
    pool_choice_2[8]  R1773     -60
    pool_choice_2[9]  OBJ       8.0409665286968448e+01
    pool_choice_2[9]  R855      1
    pool_choice_2[9]  R856      -60
    pool_choice_2[9]  R862      -1
    pool_choice_2[9]  R880      -1
    pool_choice_2[9]  R890      -1
    pool_choice_2[9]  R896      -1
    pool_choice_2[9]  R898      -1
    pool_choice_2[9]  pool_cover_C0_order_d  1
    pool_choice_2[9]  pool_cover_C0_order_p  1
    pool_choice_2[9]  pool_cover_C52_order_p  1
    pool_choice_2[9]  R1621     -1
    pool_choice_2[9]  R1672     -1
    pool_choice_2[9]  R1769     -60
    pool_choice_2[9]  R1773     -60
    pool_choice_2[10]  OBJ       5.6320511361314892e+01
    pool_choice_2[10]  R855      1
    pool_choice_2[10]  R856      -60
    pool_choice_2[10]  R865      -1
    pool_choice_2[10]  R879      -1
    pool_choice_2[10]  R894      -1
    pool_choice_2[10]  R898      -1
    pool_choice_2[10]  pool_cover_C39_order_d  1
    pool_choice_2[10]  pool_cover_C39_order_p  1
    pool_choice_2[10]  R1624     -1
    pool_choice_2[10]  R1769     -60
    pool_choice_2[10]  R1773     -60
    pool_choice_2[11]  OBJ       5.6938022874619705e+01
    pool_choice_2[11]  R855      1
    pool_choice_2[11]  R856      -60
    pool_choice_2[11]  R866      -1
    pool_choice_2[11]  R881      -1
    pool_choice_2[11]  R900      -1
    pool_choice_2[11]  pool_cover_C85_order_d  1
    pool_choice_2[11]  pool_cover_C21_order_d  1
    pool_choice_2[11]  R1641     -1
    pool_choice_2[11]  R1769     -60
    pool_choice_2[11]  R1773     -60
    pool_choice_2[12]  OBJ       8.7536776153948523e+01
    pool_choice_2[12]  R855      1
    pool_choice_2[12]  R856      -60
    pool_choice_2[12]  R862      -1
    pool_choice_2[12]  R874      -1
    pool_choice_2[12]  R890      -1
    pool_choice_2[12]  R898      -1
    pool_choice_2[12]  pool_cover_C0_order_d  1
    pool_choice_2[12]  pool_cover_C0_order_p  1
    pool_choice_2[12]  pool_cover_C39_order_d  1
    pool_choice_2[12]  R1645     -1
    pool_choice_2[12]  R1673     -1
    pool_choice_2[12]  R1769     -60
    pool_choice_2[12]  R1773     -60
    pool_choice_2[13]  OBJ       3.0265491900843113e+01
    pool_choice_2[13]  R855      1
    pool_choice_2[13]  R856      -60
    pool_choice_2[13]  R862      -1
    pool_choice_2[13]  R882      -1
    pool_choice_2[13]  R898      -1
    pool_choice_2[13]  pool_cover_C0_order_d  1
    pool_choice_2[13]  R1769     -60
    pool_choice_2[13]  R1773     -60
    pool_choice_2[14]  OBJ       3.0265491900843113e+01
    pool_choice_2[14]  R855      1
    pool_choice_2[14]  R867      -1
    pool_choice_2[14]  R874      -1
    pool_choice_2[14]  R890      -1
    pool_choice_2[14]  pool_cover_C0_order_p  1
    pool_choice_2[15]  OBJ       1.2919992801073712e+02
    pool_choice_2[15]  R855      1
    pool_choice_2[15]  R856      -60
    pool_choice_2[15]  R862      -1
    pool_choice_2[15]  R879      -1
    pool_choice_2[15]  R890      -1
    pool_choice_2[15]  R894      -1
    pool_choice_2[15]  R898      -1
    pool_choice_2[15]  pool_cover_C0_order_d  1
    pool_choice_2[15]  pool_cover_C0_order_p  1
    pool_choice_2[15]  pool_cover_C39_order_d  1
    pool_choice_2[15]  pool_cover_C39_order_p  1
    pool_choice_2[15]  R1645     -1
    pool_choice_2[15]  R1670     -1
    pool_choice_2[15]  R1673     -1
    pool_choice_2[15]  R1769     -60
    pool_choice_2[15]  R1773     -60
    pool_choice_2[16]  OBJ       9.8529684564347164e+01
    pool_choice_2[16]  R855      1
    pool_choice_2[16]  R856      -60
    pool_choice_2[16]  R862      -1
    pool_choice_2[16]  R874      -1
    pool_choice_2[16]  R890      -1
    pool_choice_2[16]  R898      -1
    pool_choice_2[16]  pool_cover_C0_order_d  1
    pool_choice_2[16]  pool_cover_C0_order_p  1
    pool_choice_2[16]  pool_cover_C52_order_d  1
    pool_choice_2[16]  R1630     -1
    pool_choice_2[16]  R1674     -1
    pool_choice_2[16]  R1769     -60
    pool_choice_2[16]  R1773     -60
    pool_choice_2[17]  OBJ       6.6013282617951688e+01
    pool_choice_2[17]  R855      1
    pool_choice_2[17]  R856      -60
    pool_choice_2[17]  R865      -1
    pool_choice_2[17]  R883      -1
    pool_choice_2[17]  R898      -1
    pool_choice_2[17]  pool_cover_C39_order_d  1
    pool_choice_2[17]  pool_cover_C52_order_d  1
    pool_choice_2[17]  R1640     -1
    pool_choice_2[17]  R1769     -60
    pool_choice_2[17]  R1773     -60
    pool_choice_2[18]  OBJ       71.9286437576317
    pool_choice_2[18]  R855      1
    pool_choice_2[18]  R856      -60
    pool_choice_2[18]  R862      -1
    pool_choice_2[18]  R879      -1
    pool_choice_2[18]  R894      -1
    pool_choice_2[18]  R898      -1
    pool_choice_2[18]  pool_cover_C0_order_d  1
    pool_choice_2[18]  pool_cover_C39_order_p  1
    pool_choice_2[18]  R1675     -1
    pool_choice_2[18]  R1769     -60
    pool_choice_2[18]  R1773     -60
    pool_choice_2[19]  OBJ       71.9286437576317
    pool_choice_2[19]  R855      1
    pool_choice_2[19]  R856      -60
    pool_choice_2[19]  R865      -1
    pool_choice_2[19]  R874      -1
    pool_choice_2[19]  R890      -1
    pool_choice_2[19]  R898      -1
    pool_choice_2[19]  pool_cover_C0_order_p  1
    pool_choice_2[19]  pool_cover_C39_order_d  1
    pool_choice_2[19]  R1673     -1
    pool_choice_2[19]  R1769     -60
    pool_choice_2[19]  R1773     -60
    pool_choice_2[20]  OBJ       1.4867385795047250e+02
    pool_choice_2[20]  R855      1
    pool_choice_2[20]  R856      -60
    pool_choice_2[20]  R862      -1
    pool_choice_2[20]  R880      -1
    pool_choice_2[20]  R890      -1
    pool_choice_2[20]  R896      -1
    pool_choice_2[20]  R898      -1
    pool_choice_2[20]  pool_cover_C0_order_d  1
    pool_choice_2[20]  pool_cover_C0_order_p  1
    pool_choice_2[20]  pool_cover_C52_order_d  1
    pool_choice_2[20]  pool_cover_C52_order_p  1
    pool_choice_2[20]  R1630     -1
    pool_choice_2[20]  R1672     -1
    pool_choice_2[20]  R1674     -1
    pool_choice_2[20]  R1769     -60
    pool_choice_2[20]  R1773     -60
    pool_choice_2[21]  OBJ       8.0409665286968448e+01
    pool_choice_2[21]  R855      1
    pool_choice_2[21]  R856      -60
    pool_choice_2[21]  R862      -1
    pool_choice_2[21]  R883      -1
    pool_choice_2[21]  R898      -1
    pool_choice_2[21]  pool_cover_C0_order_d  1
    pool_choice_2[21]  pool_cover_C52_order_d  1
    pool_choice_2[21]  R1630     -1
    pool_choice_2[21]  R1769     -60
    pool_choice_2[21]  R1773     -60
    pool_choice_2[22]  OBJ       8.0409665286968448e+01
    pool_choice_2[22]  R855      1
    pool_choice_2[22]  R856      -60
    pool_choice_2[22]  R862      -1
    pool_choice_2[22]  R880      -1
    pool_choice_2[22]  R896      -1
    pool_choice_2[22]  R898      -1
    pool_choice_2[22]  pool_cover_C0_order_d  1
    pool_choice_2[22]  pool_cover_C52_order_p  1
    pool_choice_2[22]  R1676     -1
    pool_choice_2[22]  R1769     -60
    pool_choice_2[22]  R1773     -60
    pool_choice_2[23]  OBJ       6
    pool_choice_2[23]  R855      1
    pool_choice_2[23]  R868      -1
    pool_choice_2[23]  R875      -1
    pool_choice_2[23]  R891      -1
    pool_choice_2[23]  pool_cover_C85_order_p  1
    pool_choice_2[24]  OBJ       3.6209473277964264e+01
    pool_choice_2[24]  R855      1
    pool_choice_2[24]  R856      -60
    pool_choice_2[24]  R869      -1
    pool_choice_2[24]  R884      -1
    pool_choice_2[24]  R899      -1
    pool_choice_2[24]  pool_cover_C81_order_d  1
    pool_choice_2[24]  pool_cover_C90_order_d  1
    pool_choice_2[24]  R1628     -1
    pool_choice_2[24]  R1769     -60
    pool_choice_2[24]  R1773     -60
    pool_choice_2[25]  OBJ       2.0478148916466086e+01
    pool_choice_2[25]  R855      1
    pool_choice_2[25]  R856      -60
    pool_choice_2[25]  R869      -1
    pool_choice_2[25]  R875      -1
    pool_choice_2[25]  R891      -1
    pool_choice_2[25]  R897      -1
    pool_choice_2[25]  R899      -1
    pool_choice_2[25]  pool_cover_C81_order_d  1
    pool_choice_2[25]  pool_cover_C81_order_p  1
    pool_choice_2[25]  pool_cover_C85_order_p  1
    pool_choice_2[25]  R1619     -1
    pool_choice_2[25]  R1629     -1
    pool_choice_2[25]  R1769     -60
    pool_choice_2[25]  R1773     -60
    pool_choice_2[26]  OBJ       8.4133301895330391e+01
    pool_choice_2[26]  R855      1
    pool_choice_2[26]  R856      -60
    pool_choice_2[26]  R862      -1
    pool_choice_2[26]  R885      -1
    pool_choice_2[26]  R898      -1
    pool_choice_2[26]  pool_cover_C0_order_d  1
    pool_choice_2[26]  pool_cover_C39_order_d  1
    pool_choice_2[26]  pool_cover_C52_order_d  1
    pool_choice_2[26]  R1630     -1
    pool_choice_2[26]  R1631     -1
    pool_choice_2[26]  R1769     -60
    pool_choice_2[26]  R1773     -60
    pool_choice_2[27]  OBJ       4.0324927052090487e+01
    pool_choice_2[27]  R855      1
    pool_choice_2[27]  R856      -60
    pool_choice_2[27]  R862      -1
    pool_choice_2[27]  R875      -1
    pool_choice_2[27]  R890      -1
    pool_choice_2[27]  R891      -1
    pool_choice_2[27]  R893      -1
    pool_choice_2[27]  R898      -1
    pool_choice_2[27]  pool_cover_C0_order_d  1
    pool_choice_2[27]  pool_cover_C0_order_p  1
    pool_choice_2[27]  pool_cover_C85_order_p  1
    pool_choice_2[27]  pool_cover_C75_order_p  1
    pool_choice_2[27]  R1621     -1
    pool_choice_2[27]  R1632     -1
    pool_choice_2[27]  R1633     -1
    pool_choice_2[27]  R1769     -60
    pool_choice_2[27]  R1773     -60
    pool_choice_2[28]  OBJ       6
    pool_choice_2[28]  R855      1
    pool_choice_2[28]  R856      -60
    pool_choice_2[28]  R866      -1
    pool_choice_2[28]  R886      -1
    pool_choice_2[28]  R900      -1
    pool_choice_2[28]  pool_cover_C85_order_d  1
    pool_choice_2[28]  R1769     -60
    pool_choice_2[28]  R1773     -60
    pool_choice_2[29]  OBJ       6
    pool_choice_2[29]  R855      1
    pool_choice_2[29]  R856      -60
    pool_choice_2[29]  R866      -1
    pool_choice_2[29]  R875      -1
    pool_choice_2[29]  R891      -1
    pool_choice_2[29]  R900      -1
    pool_choice_2[29]  pool_cover_C85_order_d  1
    pool_choice_2[29]  pool_cover_C85_order_p  1
    pool_choice_2[29]  R1618     -1
    pool_choice_2[29]  R1769     -60
    pool_choice_2[29]  R1773     -60
    pool_choice_2[30]  OBJ       2.0478148916466086e+01
    pool_choice_2[30]  R855      1
    pool_choice_2[30]  R870      -1
    pool_choice_2[30]  R875      -1
    pool_choice_2[30]  R891      -1
    pool_choice_2[30]  R897      -1
    pool_choice_2[30]  pool_cover_C81_order_p  1
    pool_choice_2[30]  pool_cover_C85_order_p  1
    pool_choice_2[30]  R1629     -1
    pool_choice_2[31]  OBJ       2.0396078054371138e+01
    pool_choice_2[31]  R855      1
    pool_choice_2[31]  R856      -60
    pool_choice_2[31]  R869      -1
    pool_choice_2[31]  R887      -1
    pool_choice_2[31]  R899      -1
    pool_choice_2[31]  pool_cover_C81_order_d  1
    pool_choice_2[31]  R1769     -60
    pool_choice_2[31]  R1773     -60
    pool_choice_2[32]  OBJ       2.6263385861093521e+01
    pool_choice_2[32]  R855      1
    pool_choice_2[32]  R856      -60
    pool_choice_2[32]  R863      -1
    pool_choice_2[32]  R875      -1
    pool_choice_2[32]  R891      -1
    pool_choice_2[32]  R892      -1
    pool_choice_2[32]  R899      -1
    pool_choice_2[32]  pool_cover_C90_order_d  1
    pool_choice_2[32]  pool_cover_C90_order_p  1
    pool_choice_2[32]  pool_cover_C85_order_p  1
    pool_choice_2[32]  R1620     -1
    pool_choice_2[32]  R1634     -1
    pool_choice_2[32]  R1769     -60
    pool_choice_2[32]  R1773     -60
    pool_choice_2[33]  OBJ       3.7837287915293039e+01
    pool_choice_2[33]  R855      1
    pool_choice_2[33]  R856      -60
    pool_choice_2[33]  R866      -1
    pool_choice_2[33]  R888      -1
    pool_choice_2[33]  R900      -1
    pool_choice_2[33]  pool_cover_C85_order_d  1
    pool_choice_2[33]  pool_cover_C75_order_d  1
    pool_choice_2[33]  R1636     -1
    pool_choice_2[33]  R1769     -60
    pool_choice_2[33]  R1773     -60
    pool_choice_2[34]  OBJ       41.4400902933387
    pool_choice_2[34]  R855      1
    pool_choice_2[34]  R856      -60
    pool_choice_2[34]  R866      -1
    pool_choice_2[34]  R875      -1
    pool_choice_2[34]  R891      -1
    pool_choice_2[34]  R893      -1
    pool_choice_2[34]  R900      -1
    pool_choice_2[34]  pool_cover_C85_order_d  1
    pool_choice_2[34]  pool_cover_C85_order_p  1
    pool_choice_2[34]  pool_cover_C75_order_d  1
    pool_choice_2[34]  pool_cover_C75_order_p  1
    pool_choice_2[34]  R1622     -1
    pool_choice_2[34]  R1633     -1
    pool_choice_2[34]  R1636     -1
    pool_choice_2[34]  R1769     -60
    pool_choice_2[34]  R1773     -60
    pool_choice_2[35]  OBJ       3.5116342351967482e+01
    pool_choice_2[35]  R855      1
    pool_choice_2[35]  R871      -1
    pool_choice_2[35]  R875      -1
    pool_choice_2[35]  R890      -1
    pool_choice_2[35]  R891      -1
    pool_choice_2[35]  R892      -1
    pool_choice_2[35]  pool_cover_C90_order_p  1
    pool_choice_2[35]  pool_cover_C0_order_p  1
    pool_choice_2[35]  pool_cover_C85_order_p  1
    pool_choice_2[35]  R1635     -1
    pool_choice_2[35]  R1637     -1
    pool_choice_2[36]  OBJ       6.3709853449601354e+01
    pool_choice_2[36]  R855      1
    pool_choice_2[36]  R856      -60
    pool_choice_2[36]  R869      -1
    pool_choice_2[36]  R884      -1
    pool_choice_2[36]  R899      -1
    pool_choice_2[36]  pool_cover_C81_order_d  1
    pool_choice_2[36]  pool_cover_C90_order_d  1
    pool_choice_2[36]  pool_cover_C97_order_d  1
    pool_choice_2[36]  R1638     -1
    pool_choice_2[36]  R1639     -1
    pool_choice_2[36]  R1769     -60
    pool_choice_2[36]  R1773     -60
    pool_choice_2[37]  OBJ       3.5116342351967482e+01
    pool_choice_2[37]  R855      1
    pool_choice_2[37]  R856      -60
    pool_choice_2[37]  R863      -1
    pool_choice_2[37]  R875      -1
    pool_choice_2[37]  R890      -1
    pool_choice_2[37]  R891      -1
    pool_choice_2[37]  R892      -1
    pool_choice_2[37]  R899      -1
    pool_choice_2[37]  pool_cover_C90_order_d  1
    pool_choice_2[37]  pool_cover_C90_order_p  1
    pool_choice_2[37]  pool_cover_C0_order_p  1
    pool_choice_2[37]  pool_cover_C85_order_p  1
    pool_choice_2[37]  R1620     -1
    pool_choice_2[37]  R1635     -1
    pool_choice_2[37]  R1637     -1
    pool_choice_2[37]  R1769     -60
    pool_choice_2[37]  R1773     -60
    pool_choice_2[38]  OBJ       3.7837287915293039e+01
    pool_choice_2[38]  R855      1
    pool_choice_2[38]  R856      -60
    pool_choice_2[38]  R864      -1
    pool_choice_2[38]  R875      -1
    pool_choice_2[38]  R891      -1
    pool_choice_2[38]  R893      -1
    pool_choice_2[38]  R900      -1
    pool_choice_2[38]  pool_cover_C85_order_p  1
    pool_choice_2[38]  pool_cover_C75_order_d  1
    pool_choice_2[38]  pool_cover_C75_order_p  1
    pool_choice_2[38]  R1622     -1
    pool_choice_2[38]  R1633     -1
    pool_choice_2[38]  R1769     -60
    pool_choice_2[38]  R1773     -60
    pool_choice_2[39]  OBJ       3.6291544140059209e+01
    pool_choice_2[39]  R855      1
    pool_choice_2[39]  R871      -1
    pool_choice_2[39]  R875      -1
    pool_choice_2[39]  R891      -1
    pool_choice_2[39]  R892      -1
    pool_choice_2[39]  R897      -1
    pool_choice_2[39]  pool_cover_C81_order_p  1
    pool_choice_2[39]  pool_cover_C90_order_p  1
    pool_choice_2[39]  pool_cover_C85_order_p  1
    pool_choice_2[39]  R1629     -1
    pool_choice_2[39]  R1642     -1
    pool_choice_2[40]  OBJ       6.6004157126226886e+01
    pool_choice_2[40]  R855      1
    pool_choice_2[40]  R856      -60
    pool_choice_2[40]  R869      -1
    pool_choice_2[40]  R889      -1
    pool_choice_2[40]  R899      -1
    pool_choice_2[40]  pool_cover_C81_order_d  1
    pool_choice_2[40]  pool_cover_C97_order_d  1
    pool_choice_2[40]  pool_cover_C51_order_d  1
    pool_choice_2[40]  R1638     -1
    pool_choice_2[40]  R1643     -1
    pool_choice_2[40]  R1769     -60
    pool_choice_2[40]  R1773     -60
    pool_choice_2[41]  OBJ       3.6291544140059209e+01
    pool_choice_2[41]  R855      1
    pool_choice_2[41]  R856      -60
    pool_choice_2[41]  R863      -1
    pool_choice_2[41]  R875      -1
    pool_choice_2[41]  R891      -1
    pool_choice_2[41]  R897      -1
    pool_choice_2[41]  R899      -1
    pool_choice_2[41]  pool_cover_C81_order_d  1
    pool_choice_2[41]  pool_cover_C81_order_p  1
    pool_choice_2[41]  pool_cover_C90_order_d  1
    pool_choice_2[41]  pool_cover_C85_order_p  1
    pool_choice_2[41]  R1619     -1
    pool_choice_2[41]  R1629     -1
    pool_choice_2[41]  R1644     -1
    pool_choice_2[41]  R1769     -60
    pool_choice_2[41]  R1773     -60
    pool_choice_2[42]  OBJ       71.9286437576317
    pool_choice_2[42]  R855      1
    pool_choice_2[42]  R856      -60
    pool_choice_2[42]  R862      -1
    pool_choice_2[42]  R885      -1
    pool_choice_2[42]  R898      -1
    pool_choice_2[42]  pool_cover_C0_order_d  1
    pool_choice_2[42]  pool_cover_C39_order_d  1
    pool_choice_2[42]  R1645     -1
    pool_choice_2[42]  R1769     -60
    pool_choice_2[42]  R1773     -60
    pool_choice_2[43]  OBJ       4.0324927052090487e+01
    pool_choice_2[43]  R855      1
    pool_choice_2[43]  R856      -60
    pool_choice_2[43]  R862      -1
    pool_choice_2[43]  R875      -1
    pool_choice_2[43]  R891      -1
    pool_choice_2[43]  R893      -1
    pool_choice_2[43]  R898      -1
    pool_choice_2[43]  pool_cover_C0_order_d  1
    pool_choice_2[43]  pool_cover_C85_order_p  1
    pool_choice_2[43]  pool_cover_C75_order_p  1
    pool_choice_2[43]  R1633     -1
    pool_choice_2[43]  R1646     -1
    pool_choice_2[43]  R1769     -60
    pool_choice_2[43]  R1773     -60
    pool_choice_2[44]  OBJ       3.4234485537247380e+01
    pool_choice_2[44]  R855      1
    pool_choice_2[44]  R856      -60
    pool_choice_2[44]  R864      -1
    pool_choice_2[44]  R888      -1
    pool_choice_2[44]  R900      -1
    pool_choice_2[44]  pool_cover_C75_order_d  1
    pool_choice_2[44]  R1769     -60
    pool_choice_2[44]  R1773     -60
    pool_choice_2[45]  OBJ       3.7837287915293039e+01
    pool_choice_2[45]  R855      1
    pool_choice_2[45]  R856      -60
    pool_choice_2[45]  R866      -1
    pool_choice_2[45]  R877      -1
    pool_choice_2[45]  R893      -1
    pool_choice_2[45]  R900      -1
    pool_choice_2[45]  pool_cover_C85_order_d  1
    pool_choice_2[45]  pool_cover_C75_order_d  1
    pool_choice_2[45]  pool_cover_C75_order_p  1
    pool_choice_2[45]  R1622     -1
    pool_choice_2[45]  R1636     -1
    pool_choice_2[45]  R1769     -60
    pool_choice_2[45]  R1773     -60
    pool_choice_2[46]  OBJ       3.8672424697217842e+01
    pool_choice_2[46]  R855      1
    pool_choice_2[46]  R871      -1
    pool_choice_2[46]  R877      -1
    pool_choice_2[46]  R890      -1
    pool_choice_2[46]  R892      -1
    pool_choice_2[46]  R893      -1
    pool_choice_2[46]  pool_cover_C90_order_p  1
    pool_choice_2[46]  pool_cover_C0_order_p  1
    pool_choice_2[46]  pool_cover_C75_order_p  1
    pool_choice_2[46]  R1632     -1
    pool_choice_2[46]  R1637     -1
    pool_choice_2[47]  OBJ       2.4166091947189145e+01
    pool_choice_2[47]  R855      1
    pool_choice_2[47]  R856      -60
    pool_choice_2[47]  R863      -1
    pool_choice_2[47]  R884      -1
    pool_choice_2[47]  R899      -1
    pool_choice_2[47]  pool_cover_C90_order_d  1
    pool_choice_2[47]  R1769     -60
    pool_choice_2[47]  R1773     -60
    pool_choice_2[48]  OBJ       3.6291544140059209e+01
    pool_choice_2[48]  R855      1
    pool_choice_2[48]  R856      -60
    pool_choice_2[48]  R863      -1
    pool_choice_2[48]  R875      -1
    pool_choice_2[48]  R891      -1
    pool_choice_2[48]  R892      -1
    pool_choice_2[48]  R897      -1
    pool_choice_2[48]  R899      -1
    pool_choice_2[48]  pool_cover_C81_order_p  1
    pool_choice_2[48]  pool_cover_C90_order_d  1
    pool_choice_2[48]  pool_cover_C90_order_p  1
    pool_choice_2[48]  pool_cover_C85_order_p  1
    pool_choice_2[48]  R1620     -1
    pool_choice_2[48]  R1629     -1
    pool_choice_2[48]  R1642     -1
    pool_choice_2[48]  R1769     -60
    pool_choice_2[48]  R1773     -60
    pool_choice_2[49]  OBJ       6.8348124505258170e+01
    pool_choice_2[49]  R855      1
    pool_choice_2[49]  R856      -60
    pool_choice_2[49]  R872      -1
    pool_choice_2[49]  R875      -1
    pool_choice_2[49]  R891      -1
    pool_choice_2[49]  R894      -1
    pool_choice_2[49]  R895      -1
    pool_choice_2[49]  R898      -1
    pool_choice_2[49]  pool_cover_C39_order_d  1
    pool_choice_2[49]  pool_cover_C39_order_p  1
    pool_choice_2[49]  pool_cover_C52_order_d  1
    pool_choice_2[49]  pool_cover_C85_order_p  1
    pool_choice_2[49]  pool_cover_C21_order_p  1
    pool_choice_2[49]  R1624     -1
    pool_choice_2[49]  R1631     -1
    pool_choice_2[49]  R1647     -1
    pool_choice_2[49]  R1648     -1
    pool_choice_2[49]  R1769     -60
    pool_choice_2[49]  R1773     -60
    pool_choice_2[50]  OBJ       7.7871156918086484e+01
    pool_choice_2[50]  R855      1
    pool_choice_2[50]  R856      -60
    pool_choice_2[50]  R873      -1
    pool_choice_2[50]  R888      -1
    pool_choice_2[50]  R900      -1
    pool_choice_2[50]  pool_cover_C75_order_d  1
    pool_choice_2[50]  pool_cover_C21_order_d  1
    pool_choice_2[50]  R1649     -1
    pool_choice_2[50]  R1769     -60
    pool_choice_2[50]  R1773     -60
    pool_choice_2[51]  OBJ       3.7837287915293039e+01
    pool_choice_2[51]  R855      1
    pool_choice_2[51]  R856      -60
    pool_choice_2[51]  R866      -1
    pool_choice_2[51]  R877      -1
    pool_choice_2[51]  R891      -1
    pool_choice_2[51]  R893      -1
    pool_choice_2[51]  R900      -1
    pool_choice_2[51]  pool_cover_C85_order_d  1
    pool_choice_2[51]  pool_cover_C85_order_p  1
    pool_choice_2[51]  pool_cover_C75_order_p  1
    pool_choice_2[51]  R1618     -1
    pool_choice_2[51]  R1650     -1
    pool_choice_2[51]  R1769     -60
    pool_choice_2[51]  R1773     -60
    pool_choice_2[52]  OBJ       2.6263385861093521e+01
    pool_choice_2[52]  R855      1
    pool_choice_2[52]  R871      -1
    pool_choice_2[52]  R875      -1
    pool_choice_2[52]  R891      -1
    pool_choice_2[52]  R892      -1
    pool_choice_2[52]  pool_cover_C90_order_p  1
    pool_choice_2[52]  pool_cover_C85_order_p  1
    pool_choice_2[52]  R1634     -1
    pool_choice_2[53]  OBJ       7.4792579518192952e+01
    pool_choice_2[53]  R855      1
    pool_choice_2[53]  R856      -60
    pool_choice_2[53]  R863      -1
    pool_choice_2[53]  R889      -1
    pool_choice_2[53]  R899      -1
    pool_choice_2[53]  pool_cover_C90_order_d  1
    pool_choice_2[53]  pool_cover_C97_order_d  1
    pool_choice_2[53]  pool_cover_C51_order_d  1
    pool_choice_2[53]  R1643     -1
    pool_choice_2[53]  R1651     -1
    pool_choice_2[53]  R1769     -60
    pool_choice_2[53]  R1773     -60
    pool_choice_2[54]  OBJ       4.7159723682742595e+01
    pool_choice_2[54]  R855      1
    pool_choice_2[54]  R856      -60
    pool_choice_2[54]  R869      -1
    pool_choice_2[54]  R875      -1
    pool_choice_2[54]  R890      -1
    pool_choice_2[54]  R891      -1
    pool_choice_2[54]  R892      -1
    pool_choice_2[54]  R899      -1
    pool_choice_2[54]  pool_cover_C81_order_d  1
    pool_choice_2[54]  pool_cover_C90_order_d  1
    pool_choice_2[54]  pool_cover_C90_order_p  1
    pool_choice_2[54]  pool_cover_C0_order_p  1
    pool_choice_2[54]  pool_cover_C85_order_p  1
    pool_choice_2[54]  R1620     -1
    pool_choice_2[54]  R1628     -1
    pool_choice_2[54]  R1635     -1
    pool_choice_2[54]  R1637     -1
    pool_choice_2[54]  R1769     -60
    pool_choice_2[54]  R1773     -60
    pool_used_2  R855      -1
    pool_used_2  R856      -28800
    pool_used_2  R857      -75600
    pool_used_2  R858      -75540
    pool_used_2  R859      -1
    pool_used_2  R860      -80
    pool_used_2  R861      -80
    pool_used_2  R1769     -75660
    pool_used_2  R1770     -81
    pool_used_2  R1773     -75660
    pool_used_2  R1774     -81
    pool_used_2  R1777     -75660
    pool_used_2  R1778     -81
    pool_start_2  R856      1
    pool_start_2  R857      1
    pool_start_2  R1769     1
    pool_start_2  R1773     1
    pool_start_2  GC274     -1
    pool_start_2  GC276     -1
    pool_start_2  GC278     -1
    pool_start_2  GC280     -1
    pool_start_2  GC282     -1
    pool_start_2  GC284     -1
    pool_start_2  GC286     -1
    pool_start_2  GC288     -1
    pool_start_2  GC290     -1
    pool_start_2  GC292     -1
    pool_start_2  GC294     -1
    pool_start_2  GC296     -1
    pool_start_2  GC338     1
    pool_start_2  GC339     1
    pool_start_2  GC340     1
    pool_end_2  R858      1
    pool_end_2  R1777     -1
    pool_end_2  GC298     1
    pool_end_2  GC300     1
    pool_end_2  GC302     1
    pool_end_2  GC304     1
    pool_end_2  GC306     1
    pool_end_2  GC308     1
    pool_end_2  GC310     1
    pool_end_2  GC312     1
    pool_end_2  GC314     1
    pool_end_2  GC316     1
    pool_end_2  GC318     1
    pool_end_2  GC320     1
    pool_end_2  GC322     1
    pool_end_2  GC324     1
    pool_end_2  GC326     1
    pool_end_2  GC328     1
    pool_end_2  GC330     -1
    pool_end_2  GC331     -1
    pool_end_2  GC332     -1
    pool_end_2  GC333     -1
    pool_end_2  GC334     -1
    pool_end_2  GC335     -1
    pool_end_2  GC336     -1
    pool_end_2  GC337     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_2  R859      1
    pool_start_rank_2  R860      1
    pool_start_rank_2  R1770     1
    pool_start_rank_2  R1774     1
    pool_start_rank_2  GC275     -1
    pool_start_rank_2  GC277     -1
    pool_start_rank_2  GC279     -1
    pool_start_rank_2  GC281     -1
    pool_start_rank_2  GC283     -1
    pool_start_rank_2  GC285     -1
    pool_start_rank_2  GC287     -1
    pool_start_rank_2  GC289     -1
    pool_start_rank_2  GC291     -1
    pool_start_rank_2  GC293     -1
    pool_start_rank_2  GC295     -1
    pool_start_rank_2  GC297     -1
    pool_end_rank_2  R861      1
    pool_end_rank_2  R1778     -1
    pool_end_rank_2  GC299     1
    pool_end_rank_2  GC301     1
    pool_end_rank_2  GC303     1
    pool_end_rank_2  GC305     1
    pool_end_rank_2  GC307     1
    pool_end_rank_2  GC309     1
    pool_end_rank_2  GC311     1
    pool_end_rank_2  GC313     1
    pool_end_rank_2  GC315     1
    pool_end_rank_2  GC317     1
    pool_end_rank_2  GC319     1
    pool_end_rank_2  GC321     1
    pool_end_rank_2  GC323     1
    pool_end_rank_2  GC325     1
    pool_end_rank_2  GC327     1
    pool_end_rank_2  GC329     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_2_C0_order_d  R862      1
    pool_first_2_C90_order_d  R863      1
    pool_first_2_C75_order_d  R864      1
    pool_first_2_C39_order_d  R865      1
    pool_first_2_C85_order_d  R866      1
    pool_first_2_C0_order_p  R867      1
    pool_first_2_C85_order_p  R868      1
    pool_first_2_C81_order_d  R869      1
    pool_first_2_C81_order_p  R870      1
    pool_first_2_C90_order_p  R871      1
    pool_first_2_C52_order_d  R872      1
    pool_first_2_C21_order_d  R873      1
    pool_last_2_C0_order_p  R874      1
    pool_last_2_C85_order_p  R875      1
    pool_last_2_C90_order_p  R876      1
    pool_last_2_C75_order_p  R877      1
    pool_last_2_C21_order_p  R878      1
    pool_last_2_C39_order_p  R879      1
    pool_last_2_C52_order_p  R880      1
    pool_last_2_C21_order_d  R881      1
    pool_last_2_C0_order_d  R882      1
    pool_last_2_C52_order_d  R883      1
    pool_last_2_C90_order_d  R884      1
    pool_last_2_C39_order_d  R885      1
    pool_last_2_C85_order_d  R886      1
    pool_last_2_C81_order_d  R887      1
    pool_last_2_C75_order_d  R888      1
    pool_last_2_C51_order_d  R889      1
    pool_pickup_2_C0_order  R890      1
    pool_pickup_2_C85_order  R891      1
    pool_pickup_2_C90_order  R892      1
    pool_pickup_2_C75_order  R893      1
    pool_pickup_2_C39_order  R894      1
    pool_pickup_2_C21_order  R895      1
    pool_pickup_2_C52_order  R896      1
    pool_pickup_2_C81_order  R897      1
    pool_batch_2_b2  R898      1
    pool_batch_2_b1  R899      1
    pool_batch_2_b3  R900      1
    pool_choice_3[0]  OBJ       5.6990195135927848e+01
    pool_choice_3[0]  R901      1
    pool_choice_3[0]  R902      -60
    pool_choice_3[0]  R908      -1
    pool_choice_3[0]  R919      -1
    pool_choice_3[0]  R931      -1
    pool_choice_3[0]  R932      -1
    pool_choice_3[0]  R938      -1
    pool_choice_3[0]  pool_cover_C85_order_d  1
    pool_choice_3[0]  pool_cover_C85_order_p  1
    pool_choice_3[0]  pool_cover_C21_order_d  1
    pool_choice_3[0]  pool_cover_C21_order_p  1
    pool_choice_3[0]  R1625     -1
    pool_choice_3[0]  R1641     -1
    pool_choice_3[0]  R1648     -1
    pool_choice_3[0]  R1771     -60
    pool_choice_3[0]  R1775     -60
    pool_choice_3[0]  R1777     -60
    pool_choice_3[1]  OBJ       6
    pool_choice_3[1]  R901      1
    pool_choice_3[1]  R902      -60
    pool_choice_3[1]  R908      -1
    pool_choice_3[1]  R919      -1
    pool_choice_3[1]  R932      -1
    pool_choice_3[1]  R938      -1
    pool_choice_3[1]  pool_cover_C85_order_d  1
    pool_choice_3[1]  pool_cover_C85_order_p  1
    pool_choice_3[1]  R1618     -1
    pool_choice_3[1]  R1771     -60
    pool_choice_3[1]  R1775     -60
    pool_choice_3[1]  R1777     -60
    pool_choice_3[2]  OBJ       41.4400902933387
    pool_choice_3[2]  R901      1
    pool_choice_3[2]  R902      -60
    pool_choice_3[2]  R908      -1
    pool_choice_3[2]  R919      -1
    pool_choice_3[2]  R932      -1
    pool_choice_3[2]  R933      -1
    pool_choice_3[2]  R938      -1
    pool_choice_3[2]  pool_cover_C85_order_d  1
    pool_choice_3[2]  pool_cover_C85_order_p  1
    pool_choice_3[2]  pool_cover_C75_order_d  1
    pool_choice_3[2]  pool_cover_C75_order_p  1
    pool_choice_3[2]  R1622     -1
    pool_choice_3[2]  R1633     -1
    pool_choice_3[2]  R1636     -1
    pool_choice_3[2]  R1771     -60
    pool_choice_3[2]  R1775     -60
    pool_choice_3[2]  R1777     -60
    pool_choice_3[3]  OBJ       6.4347872189567923e+01
    pool_choice_3[3]  R901      1
    pool_choice_3[3]  R902      -60
    pool_choice_3[3]  R909      -1
    pool_choice_3[3]  R919      -1
    pool_choice_3[3]  R931      -1
    pool_choice_3[3]  R932      -1
    pool_choice_3[3]  R934      -1
    pool_choice_3[3]  R939      -1
    pool_choice_3[3]  pool_cover_C90_order_d  1
    pool_choice_3[3]  pool_cover_C90_order_p  1
    pool_choice_3[3]  pool_cover_C85_order_p  1
    pool_choice_3[3]  pool_cover_C21_order_p  1
    pool_choice_3[3]  R1620     -1
    pool_choice_3[3]  R1648     -1
    pool_choice_3[3]  R1677     -1
    pool_choice_3[3]  R1771     -60
    pool_choice_3[3]  R1775     -60
    pool_choice_3[3]  R1777     -60
    pool_choice_3[4]  OBJ       88.8274830512209
    pool_choice_3[4]  R901      1
    pool_choice_3[4]  R902      -60
    pool_choice_3[4]  R908      -1
    pool_choice_3[4]  R920      -1
    pool_choice_3[4]  R931      -1
    pool_choice_3[4]  R932      -1
    pool_choice_3[4]  R933      -1
    pool_choice_3[4]  R938      -1
    pool_choice_3[4]  pool_cover_C85_order_d  1
    pool_choice_3[4]  pool_cover_C85_order_p  1
    pool_choice_3[4]  pool_cover_C75_order_p  1
    pool_choice_3[4]  pool_cover_C21_order_d  1
    pool_choice_3[4]  pool_cover_C21_order_p  1
    pool_choice_3[4]  R1625     -1
    pool_choice_3[4]  R1641     -1
    pool_choice_3[4]  R1648     -1
    pool_choice_3[4]  R1650     -1
    pool_choice_3[4]  R1771     -60
    pool_choice_3[4]  R1775     -60
    pool_choice_3[4]  R1777     -60
    pool_choice_3[5]  OBJ       7.1484620072753728e+01
    pool_choice_3[5]  R901      1
    pool_choice_3[5]  R902      -60
    pool_choice_3[5]  R910      -1
    pool_choice_3[5]  R919      -1
    pool_choice_3[5]  R931      -1
    pool_choice_3[5]  R932      -1
    pool_choice_3[5]  R935      -1
    pool_choice_3[5]  R940      -1
    pool_choice_3[5]  pool_cover_C0_order_d  1
    pool_choice_3[5]  pool_cover_C0_order_p  1
    pool_choice_3[5]  pool_cover_C85_order_p  1
    pool_choice_3[5]  pool_cover_C21_order_p  1
    pool_choice_3[5]  R1621     -1
    pool_choice_3[5]  R1648     -1
    pool_choice_3[5]  R1669     -1
    pool_choice_3[5]  R1771     -60
    pool_choice_3[5]  R1775     -60
    pool_choice_3[5]  R1777     -60
    pool_choice_3[6]  OBJ       5.6938022874619705e+01
    pool_choice_3[6]  R901      1
    pool_choice_3[6]  R902      -60
    pool_choice_3[6]  R911      -1
    pool_choice_3[6]  R919      -1
    pool_choice_3[6]  R931      -1
    pool_choice_3[6]  R932      -1
    pool_choice_3[6]  R938      -1
    pool_choice_3[6]  pool_cover_C85_order_p  1
    pool_choice_3[6]  pool_cover_C21_order_d  1
    pool_choice_3[6]  pool_cover_C21_order_p  1
    pool_choice_3[6]  R1625     -1
    pool_choice_3[6]  R1648     -1
    pool_choice_3[6]  R1771     -60
    pool_choice_3[6]  R1775     -60
    pool_choice_3[6]  R1777     -60
    pool_choice_3[7]  OBJ       5.6938022874619705e+01
    pool_choice_3[7]  R901      1
    pool_choice_3[7]  R902      -60
    pool_choice_3[7]  R908      -1
    pool_choice_3[7]  R921      -1
    pool_choice_3[7]  R931      -1
    pool_choice_3[7]  R938      -1
    pool_choice_3[7]  pool_cover_C85_order_d  1
    pool_choice_3[7]  pool_cover_C21_order_d  1
    pool_choice_3[7]  pool_cover_C21_order_p  1
    pool_choice_3[7]  R1625     -1
    pool_choice_3[7]  R1641     -1
    pool_choice_3[7]  R1771     -60
    pool_choice_3[7]  R1775     -60
    pool_choice_3[7]  R1777     -60
    pool_choice_3[8]  OBJ       5.6990195135927848e+01
    pool_choice_3[8]  R901      1
    pool_choice_3[8]  R902      -60
    pool_choice_3[8]  R908      -1
    pool_choice_3[8]  R919      -1
    pool_choice_3[8]  R932      -1
    pool_choice_3[8]  R938      -1
    pool_choice_3[8]  pool_cover_C85_order_d  1
    pool_choice_3[8]  pool_cover_C85_order_p  1
    pool_choice_3[8]  pool_cover_C21_order_d  1
    pool_choice_3[8]  R1641     -1
    pool_choice_3[8]  R1678     -1
    pool_choice_3[8]  R1771     -60
    pool_choice_3[8]  R1775     -60
    pool_choice_3[8]  R1777     -60
    pool_choice_3[9]  OBJ       5.6990195135927848e+01
    pool_choice_3[9]  R901      1
    pool_choice_3[9]  R902      -60
    pool_choice_3[9]  R908      -1
    pool_choice_3[9]  R919      -1
    pool_choice_3[9]  R931      -1
    pool_choice_3[9]  R932      -1
    pool_choice_3[9]  R938      -1
    pool_choice_3[9]  pool_cover_C85_order_d  1
    pool_choice_3[9]  pool_cover_C85_order_p  1
    pool_choice_3[9]  pool_cover_C21_order_p  1
    pool_choice_3[9]  R1648     -1
    pool_choice_3[9]  R1679     -1
    pool_choice_3[9]  R1771     -60
    pool_choice_3[9]  R1775     -60
    pool_choice_3[9]  R1777     -60
    pool_choice_3[10]  OBJ       7.7923329179394642e+01
    pool_choice_3[10]  R901      1
    pool_choice_3[10]  R902      -60
    pool_choice_3[10]  R912      -1
    pool_choice_3[10]  R919      -1
    pool_choice_3[10]  R931      -1
    pool_choice_3[10]  R932      -1
    pool_choice_3[10]  R938      -1
    pool_choice_3[10]  pool_cover_C85_order_p  1
    pool_choice_3[10]  pool_cover_C75_order_d  1
    pool_choice_3[10]  pool_cover_C21_order_d  1
    pool_choice_3[10]  pool_cover_C21_order_p  1
    pool_choice_3[10]  R1625     -1
    pool_choice_3[10]  R1648     -1
    pool_choice_3[10]  R1680     -1
    pool_choice_3[10]  R1771     -60
    pool_choice_3[10]  R1775     -60
    pool_choice_3[10]  R1777     -60
    pool_choice_3[11]  OBJ       7.7923329179394642e+01
    pool_choice_3[11]  R901      1
    pool_choice_3[11]  R902      -60
    pool_choice_3[11]  R912      -1
    pool_choice_3[11]  R919      -1
    pool_choice_3[11]  R931      -1
    pool_choice_3[11]  R932      -1
    pool_choice_3[11]  R933      -1
    pool_choice_3[11]  R938      -1
    pool_choice_3[11]  pool_cover_C85_order_p  1
    pool_choice_3[11]  pool_cover_C75_order_d  1
    pool_choice_3[11]  pool_cover_C75_order_p  1
    pool_choice_3[11]  pool_cover_C21_order_p  1
    pool_choice_3[11]  R1622     -1
    pool_choice_3[11]  R1648     -1
    pool_choice_3[11]  R1681     -1
    pool_choice_3[11]  R1771     -60
    pool_choice_3[11]  R1775     -60
    pool_choice_3[11]  R1777     -60
    pool_choice_3[12]  OBJ       7.7923329179394642e+01
    pool_choice_3[12]  R901      1
    pool_choice_3[12]  R902      -60
    pool_choice_3[12]  R908      -1
    pool_choice_3[12]  R920      -1
    pool_choice_3[12]  R931      -1
    pool_choice_3[12]  R933      -1
    pool_choice_3[12]  R938      -1
    pool_choice_3[12]  pool_cover_C85_order_d  1
    pool_choice_3[12]  pool_cover_C75_order_p  1
    pool_choice_3[12]  pool_cover_C21_order_d  1
    pool_choice_3[12]  pool_cover_C21_order_p  1
    pool_choice_3[12]  R1625     -1
    pool_choice_3[12]  R1641     -1
    pool_choice_3[12]  R1682     -1
    pool_choice_3[12]  R1771     -60
    pool_choice_3[12]  R1775     -60
    pool_choice_3[12]  R1777     -60
    pool_choice_3[13]  OBJ       81.5261315574403
    pool_choice_3[13]  R901      1
    pool_choice_3[13]  R902      -60
    pool_choice_3[13]  R908      -1
    pool_choice_3[13]  R919      -1
    pool_choice_3[13]  R932      -1
    pool_choice_3[13]  R933      -1
    pool_choice_3[13]  R938      -1
    pool_choice_3[13]  pool_cover_C85_order_d  1
    pool_choice_3[13]  pool_cover_C85_order_p  1
    pool_choice_3[13]  pool_cover_C75_order_p  1
    pool_choice_3[13]  pool_cover_C21_order_d  1
    pool_choice_3[13]  R1633     -1
    pool_choice_3[13]  R1641     -1
    pool_choice_3[13]  R1683     -1
    pool_choice_3[13]  R1771     -60
    pool_choice_3[13]  R1775     -60
    pool_choice_3[13]  R1777     -60
    pool_choice_3[14]  OBJ       81.5261315574403
    pool_choice_3[14]  R901      1
    pool_choice_3[14]  R902      -60
    pool_choice_3[14]  R908      -1
    pool_choice_3[14]  R919      -1
    pool_choice_3[14]  R931      -1
    pool_choice_3[14]  R932      -1
    pool_choice_3[14]  R938      -1
    pool_choice_3[14]  pool_cover_C85_order_d  1
    pool_choice_3[14]  pool_cover_C85_order_p  1
    pool_choice_3[14]  pool_cover_C75_order_d  1
    pool_choice_3[14]  pool_cover_C21_order_p  1
    pool_choice_3[14]  R1636     -1
    pool_choice_3[14]  R1648     -1
    pool_choice_3[14]  R1684     -1
    pool_choice_3[14]  R1771     -60
    pool_choice_3[14]  R1775     -60
    pool_choice_3[14]  R1777     -60
    pool_choice_3[15]  OBJ       81.5261315574403
    pool_choice_3[15]  R901      1
    pool_choice_3[15]  R902      -60
    pool_choice_3[15]  R908      -1
    pool_choice_3[15]  R919      -1
    pool_choice_3[15]  R931      -1
    pool_choice_3[15]  R932      -1
    pool_choice_3[15]  R933      -1
    pool_choice_3[15]  R938      -1
    pool_choice_3[15]  pool_cover_C85_order_d  1
    pool_choice_3[15]  pool_cover_C85_order_p  1
    pool_choice_3[15]  pool_cover_C75_order_p  1
    pool_choice_3[15]  pool_cover_C21_order_p  1
    pool_choice_3[15]  R1648     -1
    pool_choice_3[15]  R1681     -1
    pool_choice_3[15]  R1685     -1
    pool_choice_3[15]  R1771     -60
    pool_choice_3[15]  R1775     -60
    pool_choice_3[15]  R1777     -60
    pool_choice_3[16]  OBJ       1.2161217282154189e+02
    pool_choice_3[16]  R901      1
    pool_choice_3[16]  R902      -60
    pool_choice_3[16]  R908      -1
    pool_choice_3[16]  R919      -1
    pool_choice_3[16]  R931      -1
    pool_choice_3[16]  R932      -1
    pool_choice_3[16]  R933      -1
    pool_choice_3[16]  R938      -1
    pool_choice_3[16]  pool_cover_C85_order_d  1
    pool_choice_3[16]  pool_cover_C85_order_p  1
    pool_choice_3[16]  pool_cover_C75_order_p  1
    pool_choice_3[16]  pool_cover_C21_order_d  1
    pool_choice_3[16]  pool_cover_C21_order_p  1
    pool_choice_3[16]  R1641     -1
    pool_choice_3[16]  R1648     -1
    pool_choice_3[16]  R1681     -1
    pool_choice_3[16]  R1683     -1
    pool_choice_3[16]  R1771     -60
    pool_choice_3[16]  R1775     -60
    pool_choice_3[16]  R1777     -60
    pool_choice_3[17]  OBJ       9.8856463222861436e+01
    pool_choice_3[17]  R901      1
    pool_choice_3[17]  R902      -60
    pool_choice_3[17]  R912      -1
    pool_choice_3[17]  R920      -1
    pool_choice_3[17]  R931      -1
    pool_choice_3[17]  R933      -1
    pool_choice_3[17]  R938      -1
    pool_choice_3[17]  pool_cover_C75_order_d  1
    pool_choice_3[17]  pool_cover_C75_order_p  1
    pool_choice_3[17]  pool_cover_C21_order_d  1
    pool_choice_3[17]  pool_cover_C21_order_p  1
    pool_choice_3[17]  R1625     -1
    pool_choice_3[17]  R1680     -1
    pool_choice_3[17]  R1682     -1
    pool_choice_3[17]  R1771     -60
    pool_choice_3[17]  R1775     -60
    pool_choice_3[17]  R1777     -60
    pool_choice_3[18]  OBJ       1.0792821801054755e+02
    pool_choice_3[18]  R901      1
    pool_choice_3[18]  R902      -60
    pool_choice_3[18]  R908      -1
    pool_choice_3[18]  R921      -1
    pool_choice_3[18]  R931      -1
    pool_choice_3[18]  R932      -1
    pool_choice_3[18]  R938      -1
    pool_choice_3[18]  pool_cover_C85_order_d  1
    pool_choice_3[18]  pool_cover_C85_order_p  1
    pool_choice_3[18]  pool_cover_C21_order_d  1
    pool_choice_3[18]  pool_cover_C21_order_p  1
    pool_choice_3[18]  R1641     -1
    pool_choice_3[18]  R1678     -1
    pool_choice_3[18]  R1686     -1
    pool_choice_3[18]  R1771     -60
    pool_choice_3[18]  R1775     -60
    pool_choice_3[18]  R1777     -60
    pool_choice_3[19]  OBJ       5.6885850613311568e+01
    pool_choice_3[19]  R901      1
    pool_choice_3[19]  R902      -60
    pool_choice_3[19]  R911      -1
    pool_choice_3[19]  R921      -1
    pool_choice_3[19]  R931      -1
    pool_choice_3[19]  R938      -1
    pool_choice_3[19]  pool_cover_C21_order_d  1
    pool_choice_3[19]  pool_cover_C21_order_p  1
    pool_choice_3[19]  R1625     -1
    pool_choice_3[19]  R1771     -60
    pool_choice_3[19]  R1775     -60
    pool_choice_3[19]  R1777     -60
    pool_choice_3[20]  OBJ       6
    pool_choice_3[20]  R901      1
    pool_choice_3[20]  R913      -1
    pool_choice_3[20]  R919      -1
    pool_choice_3[20]  R932      -1
    pool_choice_3[20]  pool_cover_C85_order_p  1
    pool_choice_3[21]  OBJ       3.6209473277964264e+01
    pool_choice_3[21]  R901      1
    pool_choice_3[21]  R902      -60
    pool_choice_3[21]  R914      -1
    pool_choice_3[21]  R922      -1
    pool_choice_3[21]  R939      -1
    pool_choice_3[21]  pool_cover_C81_order_d  1
    pool_choice_3[21]  pool_cover_C90_order_d  1
    pool_choice_3[21]  R1628     -1
    pool_choice_3[21]  R1771     -60
    pool_choice_3[21]  R1775     -60
    pool_choice_3[21]  R1777     -60
    pool_choice_3[22]  OBJ       2.0478148916466086e+01
    pool_choice_3[22]  R901      1
    pool_choice_3[22]  R902      -60
    pool_choice_3[22]  R914      -1
    pool_choice_3[22]  R919      -1
    pool_choice_3[22]  R932      -1
    pool_choice_3[22]  R936      -1
    pool_choice_3[22]  R939      -1
    pool_choice_3[22]  pool_cover_C81_order_d  1
    pool_choice_3[22]  pool_cover_C81_order_p  1
    pool_choice_3[22]  pool_cover_C85_order_p  1
    pool_choice_3[22]  R1619     -1
    pool_choice_3[22]  R1629     -1
    pool_choice_3[22]  R1771     -60
    pool_choice_3[22]  R1775     -60
    pool_choice_3[22]  R1777     -60
    pool_choice_3[23]  OBJ       8.4133301895330391e+01
    pool_choice_3[23]  R901      1
    pool_choice_3[23]  R902      -60
    pool_choice_3[23]  R910      -1
    pool_choice_3[23]  R923      -1
    pool_choice_3[23]  R940      -1
    pool_choice_3[23]  pool_cover_C0_order_d  1
    pool_choice_3[23]  pool_cover_C39_order_d  1
    pool_choice_3[23]  pool_cover_C52_order_d  1
    pool_choice_3[23]  R1630     -1
    pool_choice_3[23]  R1631     -1
    pool_choice_3[23]  R1771     -60
    pool_choice_3[23]  R1775     -60
    pool_choice_3[23]  R1777     -60
    pool_choice_3[24]  OBJ       4.0324927052090487e+01
    pool_choice_3[24]  R901      1
    pool_choice_3[24]  R902      -60
    pool_choice_3[24]  R910      -1
    pool_choice_3[24]  R919      -1
    pool_choice_3[24]  R932      -1
    pool_choice_3[24]  R933      -1
    pool_choice_3[24]  R935      -1
    pool_choice_3[24]  R940      -1
    pool_choice_3[24]  pool_cover_C0_order_d  1
    pool_choice_3[24]  pool_cover_C0_order_p  1
    pool_choice_3[24]  pool_cover_C85_order_p  1
    pool_choice_3[24]  pool_cover_C75_order_p  1
    pool_choice_3[24]  R1621     -1
    pool_choice_3[24]  R1632     -1
    pool_choice_3[24]  R1633     -1
    pool_choice_3[24]  R1771     -60
    pool_choice_3[24]  R1775     -60
    pool_choice_3[24]  R1777     -60
    pool_choice_3[25]  OBJ       6
    pool_choice_3[25]  R901      1
    pool_choice_3[25]  R902      -60
    pool_choice_3[25]  R908      -1
    pool_choice_3[25]  R924      -1
    pool_choice_3[25]  R938      -1
    pool_choice_3[25]  pool_cover_C85_order_d  1
    pool_choice_3[25]  R1771     -60
    pool_choice_3[25]  R1775     -60
    pool_choice_3[25]  R1777     -60
    pool_choice_3[26]  OBJ       2.0478148916466086e+01
    pool_choice_3[26]  R901      1
    pool_choice_3[26]  R915      -1
    pool_choice_3[26]  R919      -1
    pool_choice_3[26]  R932      -1
    pool_choice_3[26]  R936      -1
    pool_choice_3[26]  pool_cover_C81_order_p  1
    pool_choice_3[26]  pool_cover_C85_order_p  1
    pool_choice_3[26]  R1629     -1
    pool_choice_3[27]  OBJ       2.0396078054371138e+01
    pool_choice_3[27]  R901      1
    pool_choice_3[27]  R902      -60
    pool_choice_3[27]  R914      -1
    pool_choice_3[27]  R925      -1
    pool_choice_3[27]  R939      -1
    pool_choice_3[27]  pool_cover_C81_order_d  1
    pool_choice_3[27]  R1771     -60
    pool_choice_3[27]  R1775     -60
    pool_choice_3[27]  R1777     -60
    pool_choice_3[28]  OBJ       2.6263385861093521e+01
    pool_choice_3[28]  R901      1
    pool_choice_3[28]  R902      -60
    pool_choice_3[28]  R909      -1
    pool_choice_3[28]  R919      -1
    pool_choice_3[28]  R932      -1
    pool_choice_3[28]  R934      -1
    pool_choice_3[28]  R939      -1
    pool_choice_3[28]  pool_cover_C90_order_d  1
    pool_choice_3[28]  pool_cover_C90_order_p  1
    pool_choice_3[28]  pool_cover_C85_order_p  1
    pool_choice_3[28]  R1620     -1
    pool_choice_3[28]  R1634     -1
    pool_choice_3[28]  R1771     -60
    pool_choice_3[28]  R1775     -60
    pool_choice_3[28]  R1777     -60
    pool_choice_3[29]  OBJ       3.0265491900843113e+01
    pool_choice_3[29]  R901      1
    pool_choice_3[29]  R902      -60
    pool_choice_3[29]  R910      -1
    pool_choice_3[29]  R926      -1
    pool_choice_3[29]  R940      -1
    pool_choice_3[29]  pool_cover_C0_order_d  1
    pool_choice_3[29]  R1771     -60
    pool_choice_3[29]  R1775     -60
    pool_choice_3[29]  R1777     -60
    pool_choice_3[30]  OBJ       3.3166042328794461e+01
    pool_choice_3[30]  R901      1
    pool_choice_3[30]  R902      -60
    pool_choice_3[30]  R910      -1
    pool_choice_3[30]  R919      -1
    pool_choice_3[30]  R932      -1
    pool_choice_3[30]  R935      -1
    pool_choice_3[30]  R940      -1
    pool_choice_3[30]  pool_cover_C0_order_d  1
    pool_choice_3[30]  pool_cover_C0_order_p  1
    pool_choice_3[30]  pool_cover_C85_order_p  1
    pool_choice_3[30]  R1621     -1
    pool_choice_3[30]  R1635     -1
    pool_choice_3[30]  R1771     -60
    pool_choice_3[30]  R1775     -60
    pool_choice_3[30]  R1777     -60
    pool_choice_3[31]  OBJ       3.7837287915293039e+01
    pool_choice_3[31]  R901      1
    pool_choice_3[31]  R902      -60
    pool_choice_3[31]  R908      -1
    pool_choice_3[31]  R927      -1
    pool_choice_3[31]  R938      -1
    pool_choice_3[31]  pool_cover_C85_order_d  1
    pool_choice_3[31]  pool_cover_C75_order_d  1
    pool_choice_3[31]  R1636     -1
    pool_choice_3[31]  R1771     -60
    pool_choice_3[31]  R1775     -60
    pool_choice_3[31]  R1777     -60
    pool_choice_3[32]  OBJ       3.5116342351967482e+01
    pool_choice_3[32]  R901      1
    pool_choice_3[32]  R916      -1
    pool_choice_3[32]  R919      -1
    pool_choice_3[32]  R932      -1
    pool_choice_3[32]  R934      -1
    pool_choice_3[32]  R935      -1
    pool_choice_3[32]  pool_cover_C90_order_p  1
    pool_choice_3[32]  pool_cover_C0_order_p  1
    pool_choice_3[32]  pool_cover_C85_order_p  1
    pool_choice_3[32]  R1635     -1
    pool_choice_3[32]  R1637     -1
    pool_choice_3[33]  OBJ       6.3709853449601354e+01
    pool_choice_3[33]  R901      1
    pool_choice_3[33]  R902      -60
    pool_choice_3[33]  R914      -1
    pool_choice_3[33]  R922      -1
    pool_choice_3[33]  R939      -1
    pool_choice_3[33]  pool_cover_C81_order_d  1
    pool_choice_3[33]  pool_cover_C90_order_d  1
    pool_choice_3[33]  pool_cover_C97_order_d  1
    pool_choice_3[33]  R1638     -1
    pool_choice_3[33]  R1639     -1
    pool_choice_3[33]  R1771     -60
    pool_choice_3[33]  R1775     -60
    pool_choice_3[33]  R1777     -60
    pool_choice_3[34]  OBJ       3.5116342351967482e+01
    pool_choice_3[34]  R901      1
    pool_choice_3[34]  R902      -60
    pool_choice_3[34]  R909      -1
    pool_choice_3[34]  R919      -1
    pool_choice_3[34]  R932      -1
    pool_choice_3[34]  R934      -1
    pool_choice_3[34]  R935      -1
    pool_choice_3[34]  R939      -1
    pool_choice_3[34]  pool_cover_C90_order_d  1
    pool_choice_3[34]  pool_cover_C90_order_p  1
    pool_choice_3[34]  pool_cover_C0_order_p  1
    pool_choice_3[34]  pool_cover_C85_order_p  1
    pool_choice_3[34]  R1620     -1
    pool_choice_3[34]  R1635     -1
    pool_choice_3[34]  R1637     -1
    pool_choice_3[34]  R1771     -60
    pool_choice_3[34]  R1775     -60
    pool_choice_3[34]  R1777     -60
    pool_choice_3[35]  OBJ       6.6013282617951688e+01
    pool_choice_3[35]  R901      1
    pool_choice_3[35]  R902      -60
    pool_choice_3[35]  R917      -1
    pool_choice_3[35]  R928      -1
    pool_choice_3[35]  R940      -1
    pool_choice_3[35]  pool_cover_C39_order_d  1
    pool_choice_3[35]  pool_cover_C52_order_d  1
    pool_choice_3[35]  R1640     -1
    pool_choice_3[35]  R1771     -60
    pool_choice_3[35]  R1775     -60
    pool_choice_3[35]  R1777     -60
    pool_choice_3[36]  OBJ       3.6722124674044828e+01
    pool_choice_3[36]  R901      1
    pool_choice_3[36]  R902      -60
    pool_choice_3[36]  R910      -1
    pool_choice_3[36]  R920      -1
    pool_choice_3[36]  R933      -1
    pool_choice_3[36]  R935      -1
    pool_choice_3[36]  R940      -1
    pool_choice_3[36]  pool_cover_C0_order_d  1
    pool_choice_3[36]  pool_cover_C0_order_p  1
    pool_choice_3[36]  pool_cover_C75_order_p  1
    pool_choice_3[36]  R1621     -1
    pool_choice_3[36]  R1632     -1
    pool_choice_3[36]  R1771     -60
    pool_choice_3[36]  R1775     -60
    pool_choice_3[36]  R1777     -60
    pool_choice_3[37]  OBJ       5.6938022874619705e+01
    pool_choice_3[37]  R901      1
    pool_choice_3[37]  R902      -60
    pool_choice_3[37]  R908      -1
    pool_choice_3[37]  R929      -1
    pool_choice_3[37]  R938      -1
    pool_choice_3[37]  pool_cover_C85_order_d  1
    pool_choice_3[37]  pool_cover_C21_order_d  1
    pool_choice_3[37]  R1641     -1
    pool_choice_3[37]  R1771     -60
    pool_choice_3[37]  R1775     -60
    pool_choice_3[37]  R1777     -60
    pool_choice_3[38]  OBJ       3.7837287915293039e+01
    pool_choice_3[38]  R901      1
    pool_choice_3[38]  R902      -60
    pool_choice_3[38]  R912      -1
    pool_choice_3[38]  R919      -1
    pool_choice_3[38]  R932      -1
    pool_choice_3[38]  R933      -1
    pool_choice_3[38]  R938      -1
    pool_choice_3[38]  pool_cover_C85_order_p  1
    pool_choice_3[38]  pool_cover_C75_order_d  1
    pool_choice_3[38]  pool_cover_C75_order_p  1
    pool_choice_3[38]  R1622     -1
    pool_choice_3[38]  R1633     -1
    pool_choice_3[38]  R1771     -60
    pool_choice_3[38]  R1775     -60
    pool_choice_3[38]  R1777     -60
    pool_choice_3[39]  OBJ       3.6291544140059209e+01
    pool_choice_3[39]  R901      1
    pool_choice_3[39]  R916      -1
    pool_choice_3[39]  R919      -1
    pool_choice_3[39]  R932      -1
    pool_choice_3[39]  R934      -1
    pool_choice_3[39]  R936      -1
    pool_choice_3[39]  pool_cover_C81_order_p  1
    pool_choice_3[39]  pool_cover_C90_order_p  1
    pool_choice_3[39]  pool_cover_C85_order_p  1
    pool_choice_3[39]  R1629     -1
    pool_choice_3[39]  R1642     -1
    pool_choice_3[40]  OBJ       6.6004157126226886e+01
    pool_choice_3[40]  R901      1
    pool_choice_3[40]  R902      -60
    pool_choice_3[40]  R914      -1
    pool_choice_3[40]  R930      -1
    pool_choice_3[40]  R939      -1
    pool_choice_3[40]  pool_cover_C81_order_d  1
    pool_choice_3[40]  pool_cover_C97_order_d  1
    pool_choice_3[40]  pool_cover_C51_order_d  1
    pool_choice_3[40]  R1638     -1
    pool_choice_3[40]  R1643     -1
    pool_choice_3[40]  R1771     -60
    pool_choice_3[40]  R1775     -60
    pool_choice_3[40]  R1777     -60
    pool_choice_3[41]  OBJ       3.6291544140059209e+01
    pool_choice_3[41]  R901      1
    pool_choice_3[41]  R902      -60
    pool_choice_3[41]  R909      -1
    pool_choice_3[41]  R919      -1
    pool_choice_3[41]  R932      -1
    pool_choice_3[41]  R936      -1
    pool_choice_3[41]  R939      -1
    pool_choice_3[41]  pool_cover_C81_order_d  1
    pool_choice_3[41]  pool_cover_C81_order_p  1
    pool_choice_3[41]  pool_cover_C90_order_d  1
    pool_choice_3[41]  pool_cover_C85_order_p  1
    pool_choice_3[41]  R1619     -1
    pool_choice_3[41]  R1629     -1
    pool_choice_3[41]  R1644     -1
    pool_choice_3[41]  R1771     -60
    pool_choice_3[41]  R1775     -60
    pool_choice_3[41]  R1777     -60
    pool_choice_3[42]  OBJ       71.9286437576317
    pool_choice_3[42]  R901      1
    pool_choice_3[42]  R902      -60
    pool_choice_3[42]  R910      -1
    pool_choice_3[42]  R923      -1
    pool_choice_3[42]  R940      -1
    pool_choice_3[42]  pool_cover_C0_order_d  1
    pool_choice_3[42]  pool_cover_C39_order_d  1
    pool_choice_3[42]  R1645     -1
    pool_choice_3[42]  R1771     -60
    pool_choice_3[42]  R1775     -60
    pool_choice_3[42]  R1777     -60
    pool_choice_3[43]  OBJ       4.0324927052090487e+01
    pool_choice_3[43]  R901      1
    pool_choice_3[43]  R902      -60
    pool_choice_3[43]  R910      -1
    pool_choice_3[43]  R919      -1
    pool_choice_3[43]  R932      -1
    pool_choice_3[43]  R933      -1
    pool_choice_3[43]  R940      -1
    pool_choice_3[43]  pool_cover_C0_order_d  1
    pool_choice_3[43]  pool_cover_C85_order_p  1
    pool_choice_3[43]  pool_cover_C75_order_p  1
    pool_choice_3[43]  R1633     -1
    pool_choice_3[43]  R1646     -1
    pool_choice_3[43]  R1771     -60
    pool_choice_3[43]  R1775     -60
    pool_choice_3[43]  R1777     -60
    pool_choice_3[44]  OBJ       3.4234485537247380e+01
    pool_choice_3[44]  R901      1
    pool_choice_3[44]  R902      -60
    pool_choice_3[44]  R912      -1
    pool_choice_3[44]  R927      -1
    pool_choice_3[44]  R938      -1
    pool_choice_3[44]  pool_cover_C75_order_d  1
    pool_choice_3[44]  R1771     -60
    pool_choice_3[44]  R1775     -60
    pool_choice_3[44]  R1777     -60
    pool_choice_3[45]  OBJ       3.7837287915293039e+01
    pool_choice_3[45]  R901      1
    pool_choice_3[45]  R902      -60
    pool_choice_3[45]  R908      -1
    pool_choice_3[45]  R920      -1
    pool_choice_3[45]  R933      -1
    pool_choice_3[45]  R938      -1
    pool_choice_3[45]  pool_cover_C85_order_d  1
    pool_choice_3[45]  pool_cover_C75_order_d  1
    pool_choice_3[45]  pool_cover_C75_order_p  1
    pool_choice_3[45]  R1622     -1
    pool_choice_3[45]  R1636     -1
    pool_choice_3[45]  R1771     -60
    pool_choice_3[45]  R1775     -60
    pool_choice_3[45]  R1777     -60
    pool_choice_3[46]  OBJ       3.8672424697217842e+01
    pool_choice_3[46]  R901      1
    pool_choice_3[46]  R916      -1
    pool_choice_3[46]  R920      -1
    pool_choice_3[46]  R933      -1
    pool_choice_3[46]  R934      -1
    pool_choice_3[46]  R935      -1
    pool_choice_3[46]  pool_cover_C90_order_p  1
    pool_choice_3[46]  pool_cover_C0_order_p  1
    pool_choice_3[46]  pool_cover_C75_order_p  1
    pool_choice_3[46]  R1632     -1
    pool_choice_3[46]  R1637     -1
    pool_choice_3[47]  OBJ       2.4166091947189145e+01
    pool_choice_3[47]  R901      1
    pool_choice_3[47]  R902      -60
    pool_choice_3[47]  R909      -1
    pool_choice_3[47]  R922      -1
    pool_choice_3[47]  R939      -1
    pool_choice_3[47]  pool_cover_C90_order_d  1
    pool_choice_3[47]  R1771     -60
    pool_choice_3[47]  R1775     -60
    pool_choice_3[47]  R1777     -60
    pool_choice_3[48]  OBJ       3.6291544140059209e+01
    pool_choice_3[48]  R901      1
    pool_choice_3[48]  R902      -60
    pool_choice_3[48]  R909      -1
    pool_choice_3[48]  R919      -1
    pool_choice_3[48]  R932      -1
    pool_choice_3[48]  R934      -1
    pool_choice_3[48]  R936      -1
    pool_choice_3[48]  R939      -1
    pool_choice_3[48]  pool_cover_C81_order_p  1
    pool_choice_3[48]  pool_cover_C90_order_d  1
    pool_choice_3[48]  pool_cover_C90_order_p  1
    pool_choice_3[48]  pool_cover_C85_order_p  1
    pool_choice_3[48]  R1620     -1
    pool_choice_3[48]  R1629     -1
    pool_choice_3[48]  R1642     -1
    pool_choice_3[48]  R1771     -60
    pool_choice_3[48]  R1775     -60
    pool_choice_3[48]  R1777     -60
    pool_choice_3[49]  OBJ       8.0409665286968448e+01
    pool_choice_3[49]  R901      1
    pool_choice_3[49]  R902      -60
    pool_choice_3[49]  R910      -1
    pool_choice_3[49]  R928      -1
    pool_choice_3[49]  R940      -1
    pool_choice_3[49]  pool_cover_C0_order_d  1
    pool_choice_3[49]  pool_cover_C52_order_d  1
    pool_choice_3[49]  R1630     -1
    pool_choice_3[49]  R1771     -60
    pool_choice_3[49]  R1775     -60
    pool_choice_3[49]  R1777     -60
    pool_choice_3[50]  OBJ       6.8348124505258170e+01
    pool_choice_3[50]  R901      1
    pool_choice_3[50]  R902      -60
    pool_choice_3[50]  R918      -1
    pool_choice_3[50]  R919      -1
    pool_choice_3[50]  R931      -1
    pool_choice_3[50]  R932      -1
    pool_choice_3[50]  R937      -1
    pool_choice_3[50]  R940      -1
    pool_choice_3[50]  pool_cover_C39_order_d  1
    pool_choice_3[50]  pool_cover_C39_order_p  1
    pool_choice_3[50]  pool_cover_C52_order_d  1
    pool_choice_3[50]  pool_cover_C85_order_p  1
    pool_choice_3[50]  pool_cover_C21_order_p  1
    pool_choice_3[50]  R1624     -1
    pool_choice_3[50]  R1631     -1
    pool_choice_3[50]  R1647     -1
    pool_choice_3[50]  R1648     -1
    pool_choice_3[50]  R1771     -60
    pool_choice_3[50]  R1775     -60
    pool_choice_3[50]  R1777     -60
    pool_choice_3[51]  OBJ       7.7871156918086484e+01
    pool_choice_3[51]  R901      1
    pool_choice_3[51]  R902      -60
    pool_choice_3[51]  R911      -1
    pool_choice_3[51]  R927      -1
    pool_choice_3[51]  R938      -1
    pool_choice_3[51]  pool_cover_C75_order_d  1
    pool_choice_3[51]  pool_cover_C21_order_d  1
    pool_choice_3[51]  R1649     -1
    pool_choice_3[51]  R1771     -60
    pool_choice_3[51]  R1775     -60
    pool_choice_3[51]  R1777     -60
    pool_used_3  R901      -1
    pool_used_3  R902      -28800
    pool_used_3  R903      -75600
    pool_used_3  R904      -75540
    pool_used_3  R905      -1
    pool_used_3  R906      -80
    pool_used_3  R907      -80
    pool_used_3  R1771     -75660
    pool_used_3  R1772     -81
    pool_used_3  R1775     -75660
    pool_used_3  R1776     -81
    pool_used_3  R1777     -75660
    pool_used_3  R1778     -81
    pool_start_3  R902      1
    pool_start_3  R903      1
    pool_start_3  R1771     1
    pool_start_3  R1775     1
    pool_start_3  R1777     1
    pool_start_3  GC341     -1
    pool_start_3  GC343     -1
    pool_start_3  GC345     -1
    pool_start_3  GC347     -1
    pool_start_3  GC349     -1
    pool_start_3  GC351     -1
    pool_start_3  GC353     -1
    pool_start_3  GC355     -1
    pool_start_3  GC357     -1
    pool_start_3  GC359     -1
    pool_start_3  GC361     -1
    pool_start_3  GC394     1
    pool_start_3  GC395     1
    pool_start_3  GC396     1
    pool_end_3  R904      1
    pool_end_3  GC363     1
    pool_end_3  GC365     1
    pool_end_3  GC367     1
    pool_end_3  GC369     1
    pool_end_3  GC371     1
    pool_end_3  GC373     1
    pool_end_3  GC375     1
    pool_end_3  GC377     1
    pool_end_3  GC379     1
    pool_end_3  GC381     1
    pool_end_3  GC383     1
    pool_end_3  GC385     1
    pool_end_3  GC387     -1
    pool_end_3  GC388     -1
    pool_end_3  GC389     -1
    pool_end_3  GC390     -1
    pool_end_3  GC391     -1
    pool_end_3  GC392     -1
    pool_end_3  GC393     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_3  R905      1
    pool_start_rank_3  R906      1
    pool_start_rank_3  R1772     1
    pool_start_rank_3  R1776     1
    pool_start_rank_3  R1778     1
    pool_start_rank_3  GC342     -1
    pool_start_rank_3  GC344     -1
    pool_start_rank_3  GC346     -1
    pool_start_rank_3  GC348     -1
    pool_start_rank_3  GC350     -1
    pool_start_rank_3  GC352     -1
    pool_start_rank_3  GC354     -1
    pool_start_rank_3  GC356     -1
    pool_start_rank_3  GC358     -1
    pool_start_rank_3  GC360     -1
    pool_start_rank_3  GC362     -1
    pool_end_rank_3  R907      1
    pool_end_rank_3  GC364     1
    pool_end_rank_3  GC366     1
    pool_end_rank_3  GC368     1
    pool_end_rank_3  GC370     1
    pool_end_rank_3  GC372     1
    pool_end_rank_3  GC374     1
    pool_end_rank_3  GC376     1
    pool_end_rank_3  GC378     1
    pool_end_rank_3  GC380     1
    pool_end_rank_3  GC382     1
    pool_end_rank_3  GC384     1
    pool_end_rank_3  GC386     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_3_C85_order_d  R908      1
    pool_first_3_C90_order_d  R909      1
    pool_first_3_C0_order_d  R910      1
    pool_first_3_C21_order_d  R911      1
    pool_first_3_C75_order_d  R912      1
    pool_first_3_C85_order_p  R913      1
    pool_first_3_C81_order_d  R914      1
    pool_first_3_C81_order_p  R915      1
    pool_first_3_C90_order_p  R916      1
    pool_first_3_C39_order_d  R917      1
    pool_first_3_C52_order_d  R918      1
    pool_last_3_C85_order_p  R919      1
    pool_last_3_C75_order_p  R920      1
    pool_last_3_C21_order_p  R921      1
    pool_last_3_C90_order_d  R922      1
    pool_last_3_C39_order_d  R923      1
    pool_last_3_C85_order_d  R924      1
    pool_last_3_C81_order_d  R925      1
    pool_last_3_C0_order_d  R926      1
    pool_last_3_C75_order_d  R927      1
    pool_last_3_C52_order_d  R928      1
    pool_last_3_C21_order_d  R929      1
    pool_last_3_C51_order_d  R930      1
    pool_pickup_3_C21_order  R931      1
    pool_pickup_3_C85_order  R932      1
    pool_pickup_3_C75_order  R933      1
    pool_pickup_3_C90_order  R934      1
    pool_pickup_3_C0_order  R935      1
    pool_pickup_3_C81_order  R936      1
    pool_pickup_3_C39_order  R937      1
    pool_batch_3_b3  R938      1
    pool_batch_3_b1  R939      1
    pool_batch_3_b2  R940      1
    pool_choice_4[0]  OBJ       6
    pool_choice_4[0]  R941      1
    pool_choice_4[0]  R942      -60
    pool_choice_4[0]  R948      -1
    pool_choice_4[0]  R968      -1
    pool_choice_4[0]  R988      -1
    pool_choice_4[0]  R998      -1
    pool_choice_4[0]  pool_cover_C85_order_d  1
    pool_choice_4[0]  pool_cover_C85_order_p  1
    pool_choice_4[0]  R1618     -1
    pool_choice_4[1]  OBJ       6
    pool_choice_4[1]  R941      1
    pool_choice_4[1]  R942      -60
    pool_choice_4[1]  R948      -1
    pool_choice_4[1]  R969      -1
    pool_choice_4[1]  R998      -1
    pool_choice_4[1]  pool_cover_C85_order_d  1
    pool_choice_4[2]  OBJ       6
    pool_choice_4[2]  R941      1
    pool_choice_4[2]  R949      -1
    pool_choice_4[2]  R968      -1
    pool_choice_4[2]  R988      -1
    pool_choice_4[2]  pool_cover_C85_order_p  1
    pool_choice_4[3]  OBJ       2.0396078054371138e+01
    pool_choice_4[3]  R941      1
    pool_choice_4[3]  R942      -60
    pool_choice_4[3]  R950      -1
    pool_choice_4[3]  R970      -1
    pool_choice_4[3]  R989      -1
    pool_choice_4[3]  R999      -1
    pool_choice_4[3]  pool_cover_C81_order_d  1
    pool_choice_4[3]  pool_cover_C81_order_p  1
    pool_choice_4[3]  R1619     -1
    pool_choice_4[4]  OBJ       2.4166091947189145e+01
    pool_choice_4[4]  R941      1
    pool_choice_4[4]  R942      -60
    pool_choice_4[4]  R951      -1
    pool_choice_4[4]  R971      -1
    pool_choice_4[4]  R990      -1
    pool_choice_4[4]  R999      -1
    pool_choice_4[4]  pool_cover_C90_order_d  1
    pool_choice_4[4]  pool_cover_C90_order_p  1
    pool_choice_4[4]  R1620     -1
    pool_choice_4[5]  OBJ       3.0265491900843113e+01
    pool_choice_4[5]  R941      1
    pool_choice_4[5]  R942      -60
    pool_choice_4[5]  R952      -1
    pool_choice_4[5]  R972      -1
    pool_choice_4[5]  R991      -1
    pool_choice_4[5]  R1000     -1
    pool_choice_4[5]  pool_cover_C0_order_d  1
    pool_choice_4[5]  pool_cover_C0_order_p  1
    pool_choice_4[5]  R1621     -1
    pool_choice_4[6]  OBJ       3.4234485537247380e+01
    pool_choice_4[6]  R941      1
    pool_choice_4[6]  R942      -60
    pool_choice_4[6]  R953      -1
    pool_choice_4[6]  R973      -1
    pool_choice_4[6]  R992      -1
    pool_choice_4[6]  R998      -1
    pool_choice_4[6]  pool_cover_C75_order_d  1
    pool_choice_4[6]  pool_cover_C75_order_p  1
    pool_choice_4[6]  R1622     -1
    pool_choice_4[7]  OBJ       2.0396078054371138e+01
    pool_choice_4[7]  R941      1
    pool_choice_4[7]  R942      -60
    pool_choice_4[7]  R950      -1
    pool_choice_4[7]  R974      -1
    pool_choice_4[7]  R999      -1
    pool_choice_4[7]  pool_cover_C81_order_d  1
    pool_choice_4[8]  OBJ       2.0396078054371138e+01
    pool_choice_4[8]  R941      1
    pool_choice_4[8]  R954      -1
    pool_choice_4[8]  R970      -1
    pool_choice_4[8]  R989      -1
    pool_choice_4[8]  pool_cover_C81_order_p  1
    pool_choice_4[9]  OBJ       2.4166091947189145e+01
    pool_choice_4[9]  R941      1
    pool_choice_4[9]  R942      -60
    pool_choice_4[9]  R951      -1
    pool_choice_4[9]  R975      -1
    pool_choice_4[9]  R999      -1
    pool_choice_4[9]  pool_cover_C90_order_d  1
    pool_choice_4[10]  OBJ       2.4166091947189145e+01
    pool_choice_4[10]  R941      1
    pool_choice_4[10]  R955      -1
    pool_choice_4[10]  R971      -1
    pool_choice_4[10]  R990      -1
    pool_choice_4[10]  pool_cover_C90_order_p  1
    pool_choice_4[11]  OBJ       5.4037024344425184e+01
    pool_choice_4[11]  R941      1
    pool_choice_4[11]  R942      -60
    pool_choice_4[11]  R956      -1
    pool_choice_4[11]  R976      -1
    pool_choice_4[11]  R993      -1
    pool_choice_4[11]  R999      -1
    pool_choice_4[11]  pool_cover_C97_order_d  1
    pool_choice_4[11]  pool_cover_C97_order_p  1
    pool_choice_4[11]  R1623     -1
    pool_choice_4[12]  OBJ       5.6320511361314892e+01
    pool_choice_4[12]  R941      1
    pool_choice_4[12]  R942      -60
    pool_choice_4[12]  R957      -1
    pool_choice_4[12]  R977      -1
    pool_choice_4[12]  R994      -1
    pool_choice_4[12]  R1000     -1
    pool_choice_4[12]  pool_cover_C39_order_d  1
    pool_choice_4[12]  pool_cover_C39_order_p  1
    pool_choice_4[12]  R1624     -1
    pool_choice_4[13]  OBJ       5.6885850613311568e+01
    pool_choice_4[13]  R941      1
    pool_choice_4[13]  R942      -60
    pool_choice_4[13]  R958      -1
    pool_choice_4[13]  R978      -1
    pool_choice_4[13]  R995      -1
    pool_choice_4[13]  R998      -1
    pool_choice_4[13]  pool_cover_C21_order_d  1
    pool_choice_4[13]  pool_cover_C21_order_p  1
    pool_choice_4[13]  R1625     -1
    pool_choice_4[14]  OBJ       3.0265491900843113e+01
    pool_choice_4[14]  R941      1
    pool_choice_4[14]  R942      -60
    pool_choice_4[14]  R952      -1
    pool_choice_4[14]  R979      -1
    pool_choice_4[14]  R1000     -1
    pool_choice_4[14]  pool_cover_C0_order_d  1
    pool_choice_4[15]  OBJ       3.0265491900843113e+01
    pool_choice_4[15]  R941      1
    pool_choice_4[15]  R959      -1
    pool_choice_4[15]  R972      -1
    pool_choice_4[15]  R991      -1
    pool_choice_4[15]  pool_cover_C0_order_p  1
    pool_choice_4[16]  OBJ       6.2289646009589745e+01
    pool_choice_4[16]  R941      1
    pool_choice_4[16]  R942      -60
    pool_choice_4[16]  R960      -1
    pool_choice_4[16]  R980      -1
    pool_choice_4[16]  R996      -1
    pool_choice_4[16]  R1000     -1
    pool_choice_4[16]  pool_cover_C52_order_d  1
    pool_choice_4[16]  pool_cover_C52_order_p  1
    pool_choice_4[16]  R1626     -1
    pool_choice_4[17]  OBJ       6.4280634719952786e+01
    pool_choice_4[17]  R941      1
    pool_choice_4[17]  R942      -60
    pool_choice_4[17]  R961      -1
    pool_choice_4[17]  R981      -1
    pool_choice_4[17]  R997      -1
    pool_choice_4[17]  R999      -1
    pool_choice_4[17]  pool_cover_C51_order_d  1
    pool_choice_4[17]  pool_cover_C51_order_p  1
    pool_choice_4[17]  R1627     -1
    pool_choice_4[18]  OBJ       3.4234485537247380e+01
    pool_choice_4[18]  R941      1
    pool_choice_4[18]  R942      -60
    pool_choice_4[18]  R953      -1
    pool_choice_4[18]  R982      -1
    pool_choice_4[18]  R998      -1
    pool_choice_4[18]  pool_cover_C75_order_d  1
    pool_choice_4[19]  OBJ       3.4234485537247380e+01
    pool_choice_4[19]  R941      1
    pool_choice_4[19]  R962      -1
    pool_choice_4[19]  R973      -1
    pool_choice_4[19]  R992      -1
    pool_choice_4[19]  pool_cover_C75_order_p  1
    pool_choice_4[20]  OBJ       5.4037024344425184e+01
    pool_choice_4[20]  R941      1
    pool_choice_4[20]  R942      -60
    pool_choice_4[20]  R956      -1
    pool_choice_4[20]  R983      -1
    pool_choice_4[20]  R999      -1
    pool_choice_4[20]  pool_cover_C97_order_d  1
    pool_choice_4[21]  OBJ       5.4037024344425184e+01
    pool_choice_4[21]  R941      1
    pool_choice_4[21]  R963      -1
    pool_choice_4[21]  R976      -1
    pool_choice_4[21]  R993      -1
    pool_choice_4[21]  pool_cover_C97_order_p  1
    pool_choice_4[22]  OBJ       5.6320511361314892e+01
    pool_choice_4[22]  R941      1
    pool_choice_4[22]  R942      -60
    pool_choice_4[22]  R957      -1
    pool_choice_4[22]  R984      -1
    pool_choice_4[22]  R1000     -1
    pool_choice_4[22]  pool_cover_C39_order_d  1
    pool_choice_4[23]  OBJ       5.6320511361314892e+01
    pool_choice_4[23]  R941      1
    pool_choice_4[23]  R964      -1
    pool_choice_4[23]  R977      -1
    pool_choice_4[23]  R994      -1
    pool_choice_4[23]  pool_cover_C39_order_p  1
    pool_choice_4[24]  OBJ       5.6885850613311568e+01
    pool_choice_4[24]  R941      1
    pool_choice_4[24]  R942      -60
    pool_choice_4[24]  R958      -1
    pool_choice_4[24]  R985      -1
    pool_choice_4[24]  R998      -1
    pool_choice_4[24]  pool_cover_C21_order_d  1
    pool_choice_4[25]  OBJ       5.6885850613311568e+01
    pool_choice_4[25]  R941      1
    pool_choice_4[25]  R965      -1
    pool_choice_4[25]  R978      -1
    pool_choice_4[25]  R995      -1
    pool_choice_4[25]  pool_cover_C21_order_p  1
    pool_choice_4[26]  OBJ       6.2289646009589745e+01
    pool_choice_4[26]  R941      1
    pool_choice_4[26]  R942      -60
    pool_choice_4[26]  R960      -1
    pool_choice_4[26]  R986      -1
    pool_choice_4[26]  R1000     -1
    pool_choice_4[26]  pool_cover_C52_order_d  1
    pool_choice_4[27]  OBJ       6.2289646009589745e+01
    pool_choice_4[27]  R941      1
    pool_choice_4[27]  R966      -1
    pool_choice_4[27]  R980      -1
    pool_choice_4[27]  R996      -1
    pool_choice_4[27]  pool_cover_C52_order_p  1
    pool_choice_4[28]  OBJ       6.4280634719952786e+01
    pool_choice_4[28]  R941      1
    pool_choice_4[28]  R942      -60
    pool_choice_4[28]  R961      -1
    pool_choice_4[28]  R987      -1
    pool_choice_4[28]  R999      -1
    pool_choice_4[28]  pool_cover_C51_order_d  1
    pool_choice_4[29]  OBJ       6.4280634719952786e+01
    pool_choice_4[29]  R941      1
    pool_choice_4[29]  R967      -1
    pool_choice_4[29]  R981      -1
    pool_choice_4[29]  R997      -1
    pool_choice_4[29]  pool_cover_C51_order_p  1
    pool_choice_4[30]  OBJ       3.6209473277964264e+01
    pool_choice_4[30]  R941      1
    pool_choice_4[30]  R942      -60
    pool_choice_4[30]  R950      -1
    pool_choice_4[30]  R975      -1
    pool_choice_4[30]  R999      -1
    pool_choice_4[30]  pool_cover_C81_order_d  1
    pool_choice_4[30]  pool_cover_C90_order_d  1
    pool_choice_4[30]  R1628     -1
    pool_choice_4[31]  OBJ       2.0478148916466086e+01
    pool_choice_4[31]  R941      1
    pool_choice_4[31]  R942      -60
    pool_choice_4[31]  R950      -1
    pool_choice_4[31]  R968      -1
    pool_choice_4[31]  R988      -1
    pool_choice_4[31]  R989      -1
    pool_choice_4[31]  R999      -1
    pool_choice_4[31]  pool_cover_C81_order_d  1
    pool_choice_4[31]  pool_cover_C81_order_p  1
    pool_choice_4[31]  pool_cover_C85_order_p  1
    pool_choice_4[31]  R1619     -1
    pool_choice_4[31]  R1629     -1
    pool_choice_4[32]  OBJ       8.4133301895330391e+01
    pool_choice_4[32]  R941      1
    pool_choice_4[32]  R942      -60
    pool_choice_4[32]  R952      -1
    pool_choice_4[32]  R984      -1
    pool_choice_4[32]  R1000     -1
    pool_choice_4[32]  pool_cover_C0_order_d  1
    pool_choice_4[32]  pool_cover_C39_order_d  1
    pool_choice_4[32]  pool_cover_C52_order_d  1
    pool_choice_4[32]  R1630     -1
    pool_choice_4[32]  R1631     -1
    pool_choice_4[33]  OBJ       4.0324927052090487e+01
    pool_choice_4[33]  R941      1
    pool_choice_4[33]  R942      -60
    pool_choice_4[33]  R952      -1
    pool_choice_4[33]  R968      -1
    pool_choice_4[33]  R988      -1
    pool_choice_4[33]  R991      -1
    pool_choice_4[33]  R992      -1
    pool_choice_4[33]  R1000     -1
    pool_choice_4[33]  pool_cover_C0_order_d  1
    pool_choice_4[33]  pool_cover_C0_order_p  1
    pool_choice_4[33]  pool_cover_C85_order_p  1
    pool_choice_4[33]  pool_cover_C75_order_p  1
    pool_choice_4[33]  R1621     -1
    pool_choice_4[33]  R1632     -1
    pool_choice_4[33]  R1633     -1
    pool_choice_4[34]  OBJ       2.0478148916466086e+01
    pool_choice_4[34]  R941      1
    pool_choice_4[34]  R954      -1
    pool_choice_4[34]  R968      -1
    pool_choice_4[34]  R988      -1
    pool_choice_4[34]  R989      -1
    pool_choice_4[34]  pool_cover_C81_order_p  1
    pool_choice_4[34]  pool_cover_C85_order_p  1
    pool_choice_4[34]  R1629     -1
    pool_choice_4[35]  OBJ       2.6263385861093521e+01
    pool_choice_4[35]  R941      1
    pool_choice_4[35]  R942      -60
    pool_choice_4[35]  R951      -1
    pool_choice_4[35]  R968      -1
    pool_choice_4[35]  R988      -1
    pool_choice_4[35]  R990      -1
    pool_choice_4[35]  R999      -1
    pool_choice_4[35]  pool_cover_C90_order_d  1
    pool_choice_4[35]  pool_cover_C90_order_p  1
    pool_choice_4[35]  pool_cover_C85_order_p  1
    pool_choice_4[35]  R1620     -1
    pool_choice_4[35]  R1634     -1
    pool_choice_4[36]  OBJ       3.3166042328794461e+01
    pool_choice_4[36]  R941      1
    pool_choice_4[36]  R942      -60
    pool_choice_4[36]  R952      -1
    pool_choice_4[36]  R968      -1
    pool_choice_4[36]  R988      -1
    pool_choice_4[36]  R991      -1
    pool_choice_4[36]  R1000     -1
    pool_choice_4[36]  pool_cover_C0_order_d  1
    pool_choice_4[36]  pool_cover_C0_order_p  1
    pool_choice_4[36]  pool_cover_C85_order_p  1
    pool_choice_4[36]  R1621     -1
    pool_choice_4[36]  R1635     -1
    pool_choice_4[37]  OBJ       3.7837287915293039e+01
    pool_choice_4[37]  R941      1
    pool_choice_4[37]  R942      -60
    pool_choice_4[37]  R948      -1
    pool_choice_4[37]  R982      -1
    pool_choice_4[37]  R998      -1
    pool_choice_4[37]  pool_cover_C85_order_d  1
    pool_choice_4[37]  pool_cover_C75_order_d  1
    pool_choice_4[37]  R1636     -1
    pool_choice_4[38]  OBJ       41.4400902933387
    pool_choice_4[38]  R941      1
    pool_choice_4[38]  R942      -60
    pool_choice_4[38]  R948      -1
    pool_choice_4[38]  R968      -1
    pool_choice_4[38]  R988      -1
    pool_choice_4[38]  R992      -1
    pool_choice_4[38]  R998      -1
    pool_choice_4[38]  pool_cover_C85_order_d  1
    pool_choice_4[38]  pool_cover_C85_order_p  1
    pool_choice_4[38]  pool_cover_C75_order_d  1
    pool_choice_4[38]  pool_cover_C75_order_p  1
    pool_choice_4[38]  R1622     -1
    pool_choice_4[38]  R1633     -1
    pool_choice_4[38]  R1636     -1
    pool_choice_4[39]  OBJ       3.5116342351967482e+01
    pool_choice_4[39]  R941      1
    pool_choice_4[39]  R955      -1
    pool_choice_4[39]  R968      -1
    pool_choice_4[39]  R988      -1
    pool_choice_4[39]  R990      -1
    pool_choice_4[39]  R991      -1
    pool_choice_4[39]  pool_cover_C90_order_p  1
    pool_choice_4[39]  pool_cover_C0_order_p  1
    pool_choice_4[39]  pool_cover_C85_order_p  1
    pool_choice_4[39]  R1635     -1
    pool_choice_4[39]  R1637     -1
    pool_choice_4[40]  OBJ       6.3709853449601354e+01
    pool_choice_4[40]  R941      1
    pool_choice_4[40]  R942      -60
    pool_choice_4[40]  R950      -1
    pool_choice_4[40]  R975      -1
    pool_choice_4[40]  R999      -1
    pool_choice_4[40]  pool_cover_C81_order_d  1
    pool_choice_4[40]  pool_cover_C90_order_d  1
    pool_choice_4[40]  pool_cover_C97_order_d  1
    pool_choice_4[40]  R1638     -1
    pool_choice_4[40]  R1639     -1
    pool_choice_4[41]  OBJ       3.5116342351967482e+01
    pool_choice_4[41]  R941      1
    pool_choice_4[41]  R942      -60
    pool_choice_4[41]  R951      -1
    pool_choice_4[41]  R968      -1
    pool_choice_4[41]  R988      -1
    pool_choice_4[41]  R990      -1
    pool_choice_4[41]  R991      -1
    pool_choice_4[41]  R999      -1
    pool_choice_4[41]  pool_cover_C90_order_d  1
    pool_choice_4[41]  pool_cover_C90_order_p  1
    pool_choice_4[41]  pool_cover_C0_order_p  1
    pool_choice_4[41]  pool_cover_C85_order_p  1
    pool_choice_4[41]  R1620     -1
    pool_choice_4[41]  R1635     -1
    pool_choice_4[41]  R1637     -1
    pool_choice_4[42]  OBJ       6.6013282617951688e+01
    pool_choice_4[42]  R941      1
    pool_choice_4[42]  R942      -60
    pool_choice_4[42]  R957      -1
    pool_choice_4[42]  R986      -1
    pool_choice_4[42]  R1000     -1
    pool_choice_4[42]  pool_cover_C39_order_d  1
    pool_choice_4[42]  pool_cover_C52_order_d  1
    pool_choice_4[42]  R1640     -1
    pool_choice_4[43]  OBJ       3.6722124674044828e+01
    pool_choice_4[43]  R941      1
    pool_choice_4[43]  R942      -60
    pool_choice_4[43]  R952      -1
    pool_choice_4[43]  R973      -1
    pool_choice_4[43]  R991      -1
    pool_choice_4[43]  R992      -1
    pool_choice_4[43]  R1000     -1
    pool_choice_4[43]  pool_cover_C0_order_d  1
    pool_choice_4[43]  pool_cover_C0_order_p  1
    pool_choice_4[43]  pool_cover_C75_order_p  1
    pool_choice_4[43]  R1621     -1
    pool_choice_4[43]  R1632     -1
    pool_choice_4[44]  OBJ       5.6938022874619705e+01
    pool_choice_4[44]  R941      1
    pool_choice_4[44]  R942      -60
    pool_choice_4[44]  R948      -1
    pool_choice_4[44]  R985      -1
    pool_choice_4[44]  R998      -1
    pool_choice_4[44]  pool_cover_C85_order_d  1
    pool_choice_4[44]  pool_cover_C21_order_d  1
    pool_choice_4[44]  R1641     -1
    pool_choice_4[45]  OBJ       3.7837287915293039e+01
    pool_choice_4[45]  R941      1
    pool_choice_4[45]  R942      -60
    pool_choice_4[45]  R953      -1
    pool_choice_4[45]  R968      -1
    pool_choice_4[45]  R988      -1
    pool_choice_4[45]  R992      -1
    pool_choice_4[45]  R998      -1
    pool_choice_4[45]  pool_cover_C85_order_p  1
    pool_choice_4[45]  pool_cover_C75_order_d  1
    pool_choice_4[45]  pool_cover_C75_order_p  1
    pool_choice_4[45]  R1622     -1
    pool_choice_4[45]  R1633     -1
    pool_choice_4[46]  OBJ       3.6291544140059209e+01
    pool_choice_4[46]  R941      1
    pool_choice_4[46]  R955      -1
    pool_choice_4[46]  R968      -1
    pool_choice_4[46]  R988      -1
    pool_choice_4[46]  R989      -1
    pool_choice_4[46]  R990      -1
    pool_choice_4[46]  pool_cover_C81_order_p  1
    pool_choice_4[46]  pool_cover_C90_order_p  1
    pool_choice_4[46]  pool_cover_C85_order_p  1
    pool_choice_4[46]  R1629     -1
    pool_choice_4[46]  R1642     -1
    pool_choice_4[47]  OBJ       6.6004157126226886e+01
    pool_choice_4[47]  R941      1
    pool_choice_4[47]  R942      -60
    pool_choice_4[47]  R950      -1
    pool_choice_4[47]  R987      -1
    pool_choice_4[47]  R999      -1
    pool_choice_4[47]  pool_cover_C81_order_d  1
    pool_choice_4[47]  pool_cover_C97_order_d  1
    pool_choice_4[47]  pool_cover_C51_order_d  1
    pool_choice_4[47]  R1638     -1
    pool_choice_4[47]  R1643     -1
    pool_choice_4[48]  OBJ       3.6291544140059209e+01
    pool_choice_4[48]  R941      1
    pool_choice_4[48]  R942      -60
    pool_choice_4[48]  R951      -1
    pool_choice_4[48]  R968      -1
    pool_choice_4[48]  R988      -1
    pool_choice_4[48]  R989      -1
    pool_choice_4[48]  R999      -1
    pool_choice_4[48]  pool_cover_C81_order_d  1
    pool_choice_4[48]  pool_cover_C81_order_p  1
    pool_choice_4[48]  pool_cover_C90_order_d  1
    pool_choice_4[48]  pool_cover_C85_order_p  1
    pool_choice_4[48]  R1619     -1
    pool_choice_4[48]  R1629     -1
    pool_choice_4[48]  R1644     -1
    pool_choice_4[49]  OBJ       71.9286437576317
    pool_choice_4[49]  R941      1
    pool_choice_4[49]  R942      -60
    pool_choice_4[49]  R952      -1
    pool_choice_4[49]  R984      -1
    pool_choice_4[49]  R1000     -1
    pool_choice_4[49]  pool_cover_C0_order_d  1
    pool_choice_4[49]  pool_cover_C39_order_d  1
    pool_choice_4[49]  R1645     -1
    pool_choice_4[50]  OBJ       4.0324927052090487e+01
    pool_choice_4[50]  R941      1
    pool_choice_4[50]  R942      -60
    pool_choice_4[50]  R952      -1
    pool_choice_4[50]  R968      -1
    pool_choice_4[50]  R988      -1
    pool_choice_4[50]  R992      -1
    pool_choice_4[50]  R1000     -1
    pool_choice_4[50]  pool_cover_C0_order_d  1
    pool_choice_4[50]  pool_cover_C85_order_p  1
    pool_choice_4[50]  pool_cover_C75_order_p  1
    pool_choice_4[50]  R1633     -1
    pool_choice_4[50]  R1646     -1
    pool_choice_4[51]  OBJ       3.7837287915293039e+01
    pool_choice_4[51]  R941      1
    pool_choice_4[51]  R942      -60
    pool_choice_4[51]  R948      -1
    pool_choice_4[51]  R973      -1
    pool_choice_4[51]  R992      -1
    pool_choice_4[51]  R998      -1
    pool_choice_4[51]  pool_cover_C85_order_d  1
    pool_choice_4[51]  pool_cover_C75_order_d  1
    pool_choice_4[51]  pool_cover_C75_order_p  1
    pool_choice_4[51]  R1622     -1
    pool_choice_4[51]  R1636     -1
    pool_choice_4[52]  OBJ       3.8672424697217842e+01
    pool_choice_4[52]  R941      1
    pool_choice_4[52]  R955      -1
    pool_choice_4[52]  R973      -1
    pool_choice_4[52]  R990      -1
    pool_choice_4[52]  R991      -1
    pool_choice_4[52]  R992      -1
    pool_choice_4[52]  pool_cover_C90_order_p  1
    pool_choice_4[52]  pool_cover_C0_order_p  1
    pool_choice_4[52]  pool_cover_C75_order_p  1
    pool_choice_4[52]  R1632     -1
    pool_choice_4[52]  R1637     -1
    pool_choice_4[53]  OBJ       3.6291544140059209e+01
    pool_choice_4[53]  R941      1
    pool_choice_4[53]  R942      -60
    pool_choice_4[53]  R951      -1
    pool_choice_4[53]  R968      -1
    pool_choice_4[53]  R988      -1
    pool_choice_4[53]  R989      -1
    pool_choice_4[53]  R990      -1
    pool_choice_4[53]  R999      -1
    pool_choice_4[53]  pool_cover_C81_order_p  1
    pool_choice_4[53]  pool_cover_C90_order_d  1
    pool_choice_4[53]  pool_cover_C90_order_p  1
    pool_choice_4[53]  pool_cover_C85_order_p  1
    pool_choice_4[53]  R1620     -1
    pool_choice_4[53]  R1629     -1
    pool_choice_4[53]  R1642     -1
    pool_choice_4[54]  OBJ       8.0409665286968448e+01
    pool_choice_4[54]  R941      1
    pool_choice_4[54]  R942      -60
    pool_choice_4[54]  R952      -1
    pool_choice_4[54]  R986      -1
    pool_choice_4[54]  R1000     -1
    pool_choice_4[54]  pool_cover_C0_order_d  1
    pool_choice_4[54]  pool_cover_C52_order_d  1
    pool_choice_4[54]  R1630     -1
    pool_choice_4[55]  OBJ       6.8348124505258170e+01
    pool_choice_4[55]  R941      1
    pool_choice_4[55]  R942      -60
    pool_choice_4[55]  R960      -1
    pool_choice_4[55]  R968      -1
    pool_choice_4[55]  R988      -1
    pool_choice_4[55]  R994      -1
    pool_choice_4[55]  R995      -1
    pool_choice_4[55]  R1000     -1
    pool_choice_4[55]  pool_cover_C39_order_d  1
    pool_choice_4[55]  pool_cover_C39_order_p  1
    pool_choice_4[55]  pool_cover_C52_order_d  1
    pool_choice_4[55]  pool_cover_C85_order_p  1
    pool_choice_4[55]  pool_cover_C21_order_p  1
    pool_choice_4[55]  R1624     -1
    pool_choice_4[55]  R1631     -1
    pool_choice_4[55]  R1647     -1
    pool_choice_4[55]  R1648     -1
    pool_choice_4[56]  OBJ       7.7871156918086484e+01
    pool_choice_4[56]  R941      1
    pool_choice_4[56]  R942      -60
    pool_choice_4[56]  R958      -1
    pool_choice_4[56]  R982      -1
    pool_choice_4[56]  R998      -1
    pool_choice_4[56]  pool_cover_C75_order_d  1
    pool_choice_4[56]  pool_cover_C21_order_d  1
    pool_choice_4[56]  R1649     -1
    pool_choice_4[57]  OBJ       3.7837287915293039e+01
    pool_choice_4[57]  R941      1
    pool_choice_4[57]  R942      -60
    pool_choice_4[57]  R948      -1
    pool_choice_4[57]  R973      -1
    pool_choice_4[57]  R988      -1
    pool_choice_4[57]  R992      -1
    pool_choice_4[57]  R998      -1
    pool_choice_4[57]  pool_cover_C85_order_d  1
    pool_choice_4[57]  pool_cover_C85_order_p  1
    pool_choice_4[57]  pool_cover_C75_order_p  1
    pool_choice_4[57]  R1618     -1
    pool_choice_4[57]  R1650     -1
    pool_choice_4[58]  OBJ       2.6263385861093521e+01
    pool_choice_4[58]  R941      1
    pool_choice_4[58]  R955      -1
    pool_choice_4[58]  R968      -1
    pool_choice_4[58]  R988      -1
    pool_choice_4[58]  R990      -1
    pool_choice_4[58]  pool_cover_C90_order_p  1
    pool_choice_4[58]  pool_cover_C85_order_p  1
    pool_choice_4[58]  R1634     -1
    pool_choice_4[59]  OBJ       7.4792579518192952e+01
    pool_choice_4[59]  R941      1
    pool_choice_4[59]  R942      -60
    pool_choice_4[59]  R951      -1
    pool_choice_4[59]  R987      -1
    pool_choice_4[59]  R999      -1
    pool_choice_4[59]  pool_cover_C90_order_d  1
    pool_choice_4[59]  pool_cover_C97_order_d  1
    pool_choice_4[59]  pool_cover_C51_order_d  1
    pool_choice_4[59]  R1643     -1
    pool_choice_4[59]  R1651     -1
    pool_choice_4[60]  OBJ       4.7159723682742595e+01
    pool_choice_4[60]  R941      1
    pool_choice_4[60]  R942      -60
    pool_choice_4[60]  R950      -1
    pool_choice_4[60]  R968      -1
    pool_choice_4[60]  R988      -1
    pool_choice_4[60]  R990      -1
    pool_choice_4[60]  R991      -1
    pool_choice_4[60]  R999      -1
    pool_choice_4[60]  pool_cover_C81_order_d  1
    pool_choice_4[60]  pool_cover_C90_order_d  1
    pool_choice_4[60]  pool_cover_C90_order_p  1
    pool_choice_4[60]  pool_cover_C0_order_p  1
    pool_choice_4[60]  pool_cover_C85_order_p  1
    pool_choice_4[60]  R1620     -1
    pool_choice_4[60]  R1628     -1
    pool_choice_4[60]  R1635     -1
    pool_choice_4[60]  R1637     -1
    pool_choice_4[61]  OBJ       6.9756020169684533e+01
    pool_choice_4[61]  R941      1
    pool_choice_4[61]  R942      -60
    pool_choice_4[61]  R957      -1
    pool_choice_4[61]  R968      -1
    pool_choice_4[61]  R988      -1
    pool_choice_4[61]  R994      -1
    pool_choice_4[61]  R996      -1
    pool_choice_4[61]  R1000     -1
    pool_choice_4[61]  pool_cover_C39_order_d  1
    pool_choice_4[61]  pool_cover_C39_order_p  1
    pool_choice_4[61]  pool_cover_C52_order_d  1
    pool_choice_4[61]  pool_cover_C52_order_p  1
    pool_choice_4[61]  pool_cover_C85_order_p  1
    pool_choice_4[61]  R1626     -1
    pool_choice_4[61]  R1640     -1
    pool_choice_4[61]  R1652     -1
    pool_choice_4[61]  R1653     -1
    pool_used_4  R941      -1
    pool_used_4  R942      -28800
    pool_used_4  R943      -75600
    pool_used_4  R944      -75540
    pool_used_4  R945      -1
    pool_used_4  R946      -80
    pool_used_4  R947      -80
    pool_used_4  R1779     -75660
    pool_used_4  R1780     -81
    pool_used_4  R1781     -75660
    pool_used_4  R1782     -81
    pool_used_4  R1783     -75660
    pool_used_4  R1784     -81
    pool_start_4  R942      1
    pool_start_4  R943      1
    pool_start_4  GC397     -1
    pool_start_4  GC399     -1
    pool_start_4  GC401     -1
    pool_start_4  GC403     -1
    pool_start_4  GC405     -1
    pool_start_4  GC407     -1
    pool_start_4  GC409     -1
    pool_start_4  GC411     -1
    pool_start_4  GC413     -1
    pool_start_4  GC415     -1
    pool_start_4  GC417     -1
    pool_start_4  GC419     -1
    pool_start_4  GC421     -1
    pool_start_4  GC423     -1
    pool_start_4  GC425     -1
    pool_start_4  GC427     -1
    pool_start_4  GC429     -1
    pool_start_4  GC431     -1
    pool_start_4  GC433     -1
    pool_start_4  GC435     -1
    pool_start_4  GC487     1
    pool_start_4  GC488     1
    pool_start_4  GC489     1
    pool_end_4  R944      1
    pool_end_4  R1779     -1
    pool_end_4  R1781     -1
    pool_end_4  R1783     -1
    pool_end_4  GC437     1
    pool_end_4  GC439     1
    pool_end_4  GC441     1
    pool_end_4  GC443     1
    pool_end_4  GC445     1
    pool_end_4  GC447     1
    pool_end_4  GC449     1
    pool_end_4  GC451     1
    pool_end_4  GC453     1
    pool_end_4  GC455     1
    pool_end_4  GC457     1
    pool_end_4  GC459     1
    pool_end_4  GC461     1
    pool_end_4  GC463     1
    pool_end_4  GC465     1
    pool_end_4  GC467     1
    pool_end_4  GC469     1
    pool_end_4  GC471     1
    pool_end_4  GC473     1
    pool_end_4  GC475     1
    pool_end_4  GC477     -1
    pool_end_4  GC478     -1
    pool_end_4  GC479     -1
    pool_end_4  GC480     -1
    pool_end_4  GC481     -1
    pool_end_4  GC482     -1
    pool_end_4  GC483     -1
    pool_end_4  GC484     -1
    pool_end_4  GC485     -1
    pool_end_4  GC486     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_4  R945      1
    pool_start_rank_4  R946      1
    pool_start_rank_4  GC398     -1
    pool_start_rank_4  GC400     -1
    pool_start_rank_4  GC402     -1
    pool_start_rank_4  GC404     -1
    pool_start_rank_4  GC406     -1
    pool_start_rank_4  GC408     -1
    pool_start_rank_4  GC410     -1
    pool_start_rank_4  GC412     -1
    pool_start_rank_4  GC414     -1
    pool_start_rank_4  GC416     -1
    pool_start_rank_4  GC418     -1
    pool_start_rank_4  GC420     -1
    pool_start_rank_4  GC422     -1
    pool_start_rank_4  GC424     -1
    pool_start_rank_4  GC426     -1
    pool_start_rank_4  GC428     -1
    pool_start_rank_4  GC430     -1
    pool_start_rank_4  GC432     -1
    pool_start_rank_4  GC434     -1
    pool_start_rank_4  GC436     -1
    pool_end_rank_4  R947      1
    pool_end_rank_4  R1780     -1
    pool_end_rank_4  R1782     -1
    pool_end_rank_4  R1784     -1
    pool_end_rank_4  GC438     1
    pool_end_rank_4  GC440     1
    pool_end_rank_4  GC442     1
    pool_end_rank_4  GC444     1
    pool_end_rank_4  GC446     1
    pool_end_rank_4  GC448     1
    pool_end_rank_4  GC450     1
    pool_end_rank_4  GC452     1
    pool_end_rank_4  GC454     1
    pool_end_rank_4  GC456     1
    pool_end_rank_4  GC458     1
    pool_end_rank_4  GC460     1
    pool_end_rank_4  GC462     1
    pool_end_rank_4  GC464     1
    pool_end_rank_4  GC466     1
    pool_end_rank_4  GC468     1
    pool_end_rank_4  GC470     1
    pool_end_rank_4  GC472     1
    pool_end_rank_4  GC474     1
    pool_end_rank_4  GC476     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_4_C85_order_d  R948      1
    pool_first_4_C85_order_p  R949      1
    pool_first_4_C81_order_d  R950      1
    pool_first_4_C90_order_d  R951      1
    pool_first_4_C0_order_d  R952      1
    pool_first_4_C75_order_d  R953      1
    pool_first_4_C81_order_p  R954      1
    pool_first_4_C90_order_p  R955      1
    pool_first_4_C97_order_d  R956      1
    pool_first_4_C39_order_d  R957      1
    pool_first_4_C21_order_d  R958      1
    pool_first_4_C0_order_p  R959      1
    pool_first_4_C52_order_d  R960      1
    pool_first_4_C51_order_d  R961      1
    pool_first_4_C75_order_p  R962      1
    pool_first_4_C97_order_p  R963      1
    pool_first_4_C39_order_p  R964      1
    pool_first_4_C21_order_p  R965      1
    pool_first_4_C52_order_p  R966      1
    pool_first_4_C51_order_p  R967      1
    pool_last_4_C85_order_p  R968      1
    pool_last_4_C85_order_d  R969      1
    pool_last_4_C81_order_p  R970      1
    pool_last_4_C90_order_p  R971      1
    pool_last_4_C0_order_p  R972      1
    pool_last_4_C75_order_p  R973      1
    pool_last_4_C81_order_d  R974      1
    pool_last_4_C90_order_d  R975      1
    pool_last_4_C97_order_p  R976      1
    pool_last_4_C39_order_p  R977      1
    pool_last_4_C21_order_p  R978      1
    pool_last_4_C0_order_d  R979      1
    pool_last_4_C52_order_p  R980      1
    pool_last_4_C51_order_p  R981      1
    pool_last_4_C75_order_d  R982      1
    pool_last_4_C97_order_d  R983      1
    pool_last_4_C39_order_d  R984      1
    pool_last_4_C21_order_d  R985      1
    pool_last_4_C52_order_d  R986      1
    pool_last_4_C51_order_d  R987      1
    pool_pickup_4_C85_order  R988      1
    pool_pickup_4_C81_order  R989      1
    pool_pickup_4_C90_order  R990      1
    pool_pickup_4_C0_order  R991      1
    pool_pickup_4_C75_order  R992      1
    pool_pickup_4_C97_order  R993      1
    pool_pickup_4_C39_order  R994      1
    pool_pickup_4_C21_order  R995      1
    pool_pickup_4_C52_order  R996      1
    pool_pickup_4_C51_order  R997      1
    pool_batch_4_b3  R998      1
    pool_batch_4_b1  R999      1
    pool_batch_4_b2  R1000     1
    pool_choice_5[0]  OBJ       2.4166091947189145e+01
    pool_choice_5[0]  R1001     1
    pool_choice_5[0]  R1002     -60
    pool_choice_5[0]  R1008     -1
    pool_choice_5[0]  R1021     -1
    pool_choice_5[0]  R1040     -1
    pool_choice_5[0]  R1050     -1
    pool_choice_5[0]  pool_cover_C90_order_d  1
    pool_choice_5[0]  pool_cover_C90_order_p  1
    pool_choice_5[0]  R1620     -1
    pool_choice_5[0]  R1779     -60
    pool_choice_5[1]  OBJ       2.6263385861093521e+01
    pool_choice_5[1]  R1001     1
    pool_choice_5[1]  R1002     -60
    pool_choice_5[1]  R1008     -1
    pool_choice_5[1]  R1022     -1
    pool_choice_5[1]  R1040     -1
    pool_choice_5[1]  R1041     -1
    pool_choice_5[1]  R1050     -1
    pool_choice_5[1]  pool_cover_C90_order_d  1
    pool_choice_5[1]  pool_cover_C90_order_p  1
    pool_choice_5[1]  pool_cover_C85_order_p  1
    pool_choice_5[1]  R1620     -1
    pool_choice_5[1]  R1634     -1
    pool_choice_5[1]  R1779     -60
    pool_choice_5[2]  OBJ       2.0396078054371138e+01
    pool_choice_5[2]  R1001     1
    pool_choice_5[2]  R1002     -60
    pool_choice_5[2]  R1009     -1
    pool_choice_5[2]  R1023     -1
    pool_choice_5[2]  R1042     -1
    pool_choice_5[2]  R1050     -1
    pool_choice_5[2]  pool_cover_C81_order_d  1
    pool_choice_5[2]  pool_cover_C81_order_p  1
    pool_choice_5[2]  R1619     -1
    pool_choice_5[2]  R1779     -60
    pool_choice_5[3]  OBJ       3.2215791924016131e+01
    pool_choice_5[3]  R1001     1
    pool_choice_5[3]  R1002     -60
    pool_choice_5[3]  R1008     -1
    pool_choice_5[3]  R1024     -1
    pool_choice_5[3]  R1040     -1
    pool_choice_5[3]  R1043     -1
    pool_choice_5[3]  R1050     -1
    pool_choice_5[3]  pool_cover_C90_order_d  1
    pool_choice_5[3]  pool_cover_C90_order_p  1
    pool_choice_5[3]  pool_cover_C0_order_p  1
    pool_choice_5[3]  R1620     -1
    pool_choice_5[3]  R1637     -1
    pool_choice_5[3]  R1779     -60
    pool_choice_5[4]  OBJ       4.8252854608739383e+01
    pool_choice_5[4]  R1001     1
    pool_choice_5[4]  R1002     -60
    pool_choice_5[4]  R1009     -1
    pool_choice_5[4]  R1023     -1
    pool_choice_5[4]  R1040     -1
    pool_choice_5[4]  R1042     -1
    pool_choice_5[4]  R1050     -1
    pool_choice_5[4]  pool_cover_C81_order_d  1
    pool_choice_5[4]  pool_cover_C81_order_p  1
    pool_choice_5[4]  pool_cover_C90_order_d  1
    pool_choice_5[4]  pool_cover_C90_order_p  1
    pool_choice_5[4]  R1620     -1
    pool_choice_5[4]  R1628     -1
    pool_choice_5[4]  R1642     -1
    pool_choice_5[4]  R1779     -60
    pool_choice_5[5]  OBJ       3.6209473277964264e+01
    pool_choice_5[5]  R1001     1
    pool_choice_5[5]  R1002     -60
    pool_choice_5[5]  R1009     -1
    pool_choice_5[5]  R1021     -1
    pool_choice_5[5]  R1040     -1
    pool_choice_5[5]  R1050     -1
    pool_choice_5[5]  pool_cover_C81_order_d  1
    pool_choice_5[5]  pool_cover_C90_order_d  1
    pool_choice_5[5]  pool_cover_C90_order_p  1
    pool_choice_5[5]  R1620     -1
    pool_choice_5[5]  R1628     -1
    pool_choice_5[5]  R1779     -60
    pool_choice_5[6]  OBJ       3.6209473277964264e+01
    pool_choice_5[6]  R1001     1
    pool_choice_5[6]  R1002     -60
    pool_choice_5[6]  R1008     -1
    pool_choice_5[6]  R1023     -1
    pool_choice_5[6]  R1040     -1
    pool_choice_5[6]  R1042     -1
    pool_choice_5[6]  R1050     -1
    pool_choice_5[6]  pool_cover_C81_order_p  1
    pool_choice_5[6]  pool_cover_C90_order_d  1
    pool_choice_5[6]  pool_cover_C90_order_p  1
    pool_choice_5[6]  R1620     -1
    pool_choice_5[6]  R1642     -1
    pool_choice_5[6]  R1779     -60
    pool_choice_5[7]  OBJ       3.8419833199511146e+01
    pool_choice_5[7]  R1001     1
    pool_choice_5[7]  R1002     -60
    pool_choice_5[7]  R1008     -1
    pool_choice_5[7]  R1025     -1
    pool_choice_5[7]  R1040     -1
    pool_choice_5[7]  R1044     -1
    pool_choice_5[7]  R1050     -1
    pool_choice_5[7]  pool_cover_C90_order_d  1
    pool_choice_5[7]  pool_cover_C90_order_p  1
    pool_choice_5[7]  pool_cover_C75_order_p  1
    pool_choice_5[7]  R1620     -1
    pool_choice_5[7]  R1687     -1
    pool_choice_5[7]  R1779     -60
    pool_choice_5[8]  OBJ       3.0265491900843113e+01
    pool_choice_5[8]  R1001     1
    pool_choice_5[8]  R1002     -60
    pool_choice_5[8]  R1010     -1
    pool_choice_5[8]  R1024     -1
    pool_choice_5[8]  R1043     -1
    pool_choice_5[8]  R1051     -1
    pool_choice_5[8]  pool_cover_C0_order_d  1
    pool_choice_5[8]  pool_cover_C0_order_p  1
    pool_choice_5[8]  R1621     -1
    pool_choice_5[8]  R1779     -60
    pool_choice_5[9]  OBJ       64.0662498323325
    pool_choice_5[9]  R1001     1
    pool_choice_5[9]  R1002     -60
    pool_choice_5[9]  R1009     -1
    pool_choice_5[9]  R1021     -1
    pool_choice_5[9]  R1040     -1
    pool_choice_5[9]  R1042     -1
    pool_choice_5[9]  R1050     -1
    pool_choice_5[9]  pool_cover_C81_order_d  1
    pool_choice_5[9]  pool_cover_C81_order_p  1
    pool_choice_5[9]  pool_cover_C90_order_d  1
    pool_choice_5[9]  pool_cover_C90_order_p  1
    pool_choice_5[9]  R1628     -1
    pool_choice_5[9]  R1688     -1
    pool_choice_5[9]  R1689     -1
    pool_choice_5[9]  R1779     -60
    pool_choice_5[10]  OBJ       3.4234485537247380e+01
    pool_choice_5[10]  R1001     1
    pool_choice_5[10]  R1002     -60
    pool_choice_5[10]  R1011     -1
    pool_choice_5[10]  R1025     -1
    pool_choice_5[10]  R1044     -1
    pool_choice_5[10]  R1052     -1
    pool_choice_5[10]  pool_cover_C75_order_d  1
    pool_choice_5[10]  pool_cover_C75_order_p  1
    pool_choice_5[10]  R1622     -1
    pool_choice_5[10]  R1779     -60
    pool_choice_5[11]  OBJ       5.2022868501557383e+01
    pool_choice_5[11]  R1001     1
    pool_choice_5[11]  R1002     -60
    pool_choice_5[11]  R1008     -1
    pool_choice_5[11]  R1021     -1
    pool_choice_5[11]  R1040     -1
    pool_choice_5[11]  R1042     -1
    pool_choice_5[11]  R1050     -1
    pool_choice_5[11]  pool_cover_C81_order_p  1
    pool_choice_5[11]  pool_cover_C90_order_d  1
    pool_choice_5[11]  pool_cover_C90_order_p  1
    pool_choice_5[11]  R1688     -1
    pool_choice_5[11]  R1689     -1
    pool_choice_5[11]  R1779     -60
    pool_choice_5[12]  OBJ       3.6209473277964264e+01
    pool_choice_5[12]  R1001     1
    pool_choice_5[12]  R1002     -60
    pool_choice_5[12]  R1009     -1
    pool_choice_5[12]  R1021     -1
    pool_choice_5[12]  R1040     -1
    pool_choice_5[12]  R1050     -1
    pool_choice_5[12]  pool_cover_C81_order_d  1
    pool_choice_5[12]  pool_cover_C90_order_p  1
    pool_choice_5[12]  R1690     -1
    pool_choice_5[12]  R1779     -60
    pool_choice_5[13]  OBJ       3.6209473277964264e+01
    pool_choice_5[13]  R1001     1
    pool_choice_5[13]  R1002     -60
    pool_choice_5[13]  R1008     -1
    pool_choice_5[13]  R1023     -1
    pool_choice_5[13]  R1042     -1
    pool_choice_5[13]  R1050     -1
    pool_choice_5[13]  pool_cover_C81_order_p  1
    pool_choice_5[13]  pool_cover_C90_order_d  1
    pool_choice_5[13]  R1688     -1
    pool_choice_5[13]  R1779     -60
    pool_choice_5[14]  OBJ       7.2498275841567434e+01
    pool_choice_5[14]  R1001     1
    pool_choice_5[14]  R1002     -60
    pool_choice_5[14]  R1008     -1
    pool_choice_5[14]  R1021     -1
    pool_choice_5[14]  R1040     -1
    pool_choice_5[14]  R1045     -1
    pool_choice_5[14]  R1050     -1
    pool_choice_5[14]  pool_cover_C90_order_d  1
    pool_choice_5[14]  pool_cover_C90_order_p  1
    pool_choice_5[14]  pool_cover_C97_order_d  1
    pool_choice_5[14]  pool_cover_C97_order_p  1
    pool_choice_5[14]  R1623     -1
    pool_choice_5[14]  R1651     -1
    pool_choice_5[14]  R1656     -1
    pool_choice_5[14]  R1779     -60
    pool_choice_5[15]  OBJ       6.3267650092996305e+01
    pool_choice_5[15]  R1001     1
    pool_choice_5[15]  R1002     -60
    pool_choice_5[15]  R1008     -1
    pool_choice_5[15]  R1026     -1
    pool_choice_5[15]  R1040     -1
    pool_choice_5[15]  R1045     -1
    pool_choice_5[15]  R1050     -1
    pool_choice_5[15]  pool_cover_C90_order_d  1
    pool_choice_5[15]  pool_cover_C90_order_p  1
    pool_choice_5[15]  pool_cover_C97_order_p  1
    pool_choice_5[15]  R1620     -1
    pool_choice_5[15]  R1665     -1
    pool_choice_5[15]  R1779     -60
    pool_choice_5[16]  OBJ       6.3267650092996313e+01
    pool_choice_5[16]  R1001     1
    pool_choice_5[16]  R1002     -60
    pool_choice_5[16]  R1012     -1
    pool_choice_5[16]  R1021     -1
    pool_choice_5[16]  R1040     -1
    pool_choice_5[16]  R1050     -1
    pool_choice_5[16]  pool_cover_C90_order_d  1
    pool_choice_5[16]  pool_cover_C90_order_p  1
    pool_choice_5[16]  pool_cover_C97_order_d  1
    pool_choice_5[16]  R1620     -1
    pool_choice_5[16]  R1639     -1
    pool_choice_5[16]  R1779     -60
    pool_choice_5[17]  OBJ       8.4993717250171358e+01
    pool_choice_5[17]  R1001     1
    pool_choice_5[17]  R1002     -60
    pool_choice_5[17]  R1008     -1
    pool_choice_5[17]  R1021     -1
    pool_choice_5[17]  R1040     -1
    pool_choice_5[17]  R1046     -1
    pool_choice_5[17]  R1050     -1
    pool_choice_5[17]  pool_cover_C90_order_d  1
    pool_choice_5[17]  pool_cover_C90_order_p  1
    pool_choice_5[17]  pool_cover_C51_order_d  1
    pool_choice_5[17]  pool_cover_C51_order_p  1
    pool_choice_5[17]  R1627     -1
    pool_choice_5[17]  R1662     -1
    pool_choice_5[17]  R1663     -1
    pool_choice_5[17]  R1779     -60
    pool_choice_5[18]  OBJ       6.4295699928259779e+01
    pool_choice_5[18]  R1001     1
    pool_choice_5[18]  R1002     -60
    pool_choice_5[18]  R1008     -1
    pool_choice_5[18]  R1027     -1
    pool_choice_5[18]  R1040     -1
    pool_choice_5[18]  R1047     -1
    pool_choice_5[18]  R1050     -1
    pool_choice_5[18]  pool_cover_C90_order_d  1
    pool_choice_5[18]  pool_cover_C90_order_p  1
    pool_choice_5[18]  pool_cover_C21_order_p  1
    pool_choice_5[18]  R1620     -1
    pool_choice_5[18]  R1677     -1
    pool_choice_5[18]  R1779     -60
    pool_choice_5[19]  OBJ       6.4594892978023864e+01
    pool_choice_5[19]  R1001     1
    pool_choice_5[19]  R1002     -60
    pool_choice_5[19]  R1008     -1
    pool_choice_5[19]  R1028     -1
    pool_choice_5[19]  R1040     -1
    pool_choice_5[19]  R1048     -1
    pool_choice_5[19]  R1050     -1
    pool_choice_5[19]  pool_cover_C90_order_d  1
    pool_choice_5[19]  pool_cover_C90_order_p  1
    pool_choice_5[19]  pool_cover_C39_order_p  1
    pool_choice_5[19]  R1620     -1
    pool_choice_5[19]  R1691     -1
    pool_choice_5[19]  R1779     -60
    pool_choice_5[20]  OBJ       2.4166091947189145e+01
    pool_choice_5[20]  R1001     1
    pool_choice_5[20]  R1002     -60
    pool_choice_5[20]  R1008     -1
    pool_choice_5[20]  R1029     -1
    pool_choice_5[20]  R1050     -1
    pool_choice_5[20]  pool_cover_C90_order_d  1
    pool_choice_5[20]  R1779     -60
    pool_choice_5[21]  OBJ       2.4166091947189145e+01
    pool_choice_5[21]  R1001     1
    pool_choice_5[21]  R1013     -1
    pool_choice_5[21]  R1021     -1
    pool_choice_5[21]  R1040     -1
    pool_choice_5[21]  pool_cover_C90_order_p  1
    pool_choice_5[22]  OBJ       7.2498275841567434e+01
    pool_choice_5[22]  R1001     1
    pool_choice_5[22]  R1002     -60
    pool_choice_5[22]  R1008     -1
    pool_choice_5[22]  R1021     -1
    pool_choice_5[22]  R1040     -1
    pool_choice_5[22]  R1045     -1
    pool_choice_5[22]  R1050     -1
    pool_choice_5[22]  pool_cover_C90_order_d  1
    pool_choice_5[22]  pool_cover_C90_order_p  1
    pool_choice_5[22]  pool_cover_C97_order_p  1
    pool_choice_5[22]  R1656     -1
    pool_choice_5[22]  R1692     -1
    pool_choice_5[22]  R1779     -60
    pool_choice_5[23]  OBJ       7.2757515098856246e+01
    pool_choice_5[23]  R1001     1
    pool_choice_5[23]  R1002     -60
    pool_choice_5[23]  R1008     -1
    pool_choice_5[23]  R1030     -1
    pool_choice_5[23]  R1040     -1
    pool_choice_5[23]  R1049     -1
    pool_choice_5[23]  R1050     -1
    pool_choice_5[23]  pool_cover_C90_order_d  1
    pool_choice_5[23]  pool_cover_C90_order_p  1
    pool_choice_5[23]  pool_cover_C52_order_p  1
    pool_choice_5[23]  R1620     -1
    pool_choice_5[23]  R1693     -1
    pool_choice_5[23]  R1779     -60
    pool_choice_5[24]  OBJ       7.4637175985062072e+01
    pool_choice_5[24]  R1001     1
    pool_choice_5[24]  R1002     -60
    pool_choice_5[24]  R1014     -1
    pool_choice_5[24]  R1021     -1
    pool_choice_5[24]  R1040     -1
    pool_choice_5[24]  R1050     -1
    pool_choice_5[24]  pool_cover_C90_order_d  1
    pool_choice_5[24]  pool_cover_C90_order_p  1
    pool_choice_5[24]  pool_cover_C51_order_d  1
    pool_choice_5[24]  R1620     -1
    pool_choice_5[24]  R1694     -1
    pool_choice_5[24]  R1779     -60
    pool_choice_5[25]  OBJ       7.4637175985062072e+01
    pool_choice_5[25]  R1001     1
    pool_choice_5[25]  R1002     -60
    pool_choice_5[25]  R1008     -1
    pool_choice_5[25]  R1031     -1
    pool_choice_5[25]  R1040     -1
    pool_choice_5[25]  R1046     -1
    pool_choice_5[25]  R1050     -1
    pool_choice_5[25]  pool_cover_C90_order_d  1
    pool_choice_5[25]  pool_cover_C90_order_p  1
    pool_choice_5[25]  pool_cover_C51_order_p  1
    pool_choice_5[25]  R1620     -1
    pool_choice_5[25]  R1695     -1
    pool_choice_5[25]  R1779     -60
    pool_choice_5[26]  OBJ       5.4037024344425184e+01
    pool_choice_5[26]  R1001     1
    pool_choice_5[26]  R1002     -60
    pool_choice_5[26]  R1012     -1
    pool_choice_5[26]  R1026     -1
    pool_choice_5[26]  R1045     -1
    pool_choice_5[26]  R1050     -1
    pool_choice_5[26]  pool_cover_C97_order_d  1
    pool_choice_5[26]  pool_cover_C97_order_p  1
    pool_choice_5[26]  R1623     -1
    pool_choice_5[26]  R1779     -60
    pool_choice_5[27]  OBJ       1.1159983398737461e+02
    pool_choice_5[27]  R1001     1
    pool_choice_5[27]  R1002     -60
    pool_choice_5[27]  R1012     -1
    pool_choice_5[27]  R1021     -1
    pool_choice_5[27]  R1040     -1
    pool_choice_5[27]  R1045     -1
    pool_choice_5[27]  R1050     -1
    pool_choice_5[27]  pool_cover_C90_order_d  1
    pool_choice_5[27]  pool_cover_C90_order_p  1
    pool_choice_5[27]  pool_cover_C97_order_d  1
    pool_choice_5[27]  pool_cover_C97_order_p  1
    pool_choice_5[27]  R1639     -1
    pool_choice_5[27]  R1656     -1
    pool_choice_5[27]  R1692     -1
    pool_choice_5[27]  R1779     -60
    pool_choice_5[28]  OBJ       8.4993717250171358e+01
    pool_choice_5[28]  R1001     1
    pool_choice_5[28]  R1002     -60
    pool_choice_5[28]  R1008     -1
    pool_choice_5[28]  R1021     -1
    pool_choice_5[28]  R1040     -1
    pool_choice_5[28]  R1046     -1
    pool_choice_5[28]  R1050     -1
    pool_choice_5[28]  pool_cover_C90_order_d  1
    pool_choice_5[28]  pool_cover_C90_order_p  1
    pool_choice_5[28]  pool_cover_C51_order_p  1
    pool_choice_5[28]  R1663     -1
    pool_choice_5[28]  R1666     -1
    pool_choice_5[28]  R1779     -60
    pool_choice_5[29]  OBJ       5.6938022874619705e+01
    pool_choice_5[29]  R1001     1
    pool_choice_5[29]  R1002     -60
    pool_choice_5[29]  R1015     -1
    pool_choice_5[29]  R1032     -1
    pool_choice_5[29]  R1052     -1
    pool_choice_5[29]  pool_cover_C85_order_d  1
    pool_choice_5[29]  pool_cover_C21_order_d  1
    pool_choice_5[29]  R1641     -1
    pool_choice_5[29]  R1779     -60
    pool_choice_5[30]  OBJ       6.3267650092996305e+01
    pool_choice_5[30]  R1001     1
    pool_choice_5[30]  R1002     -60
    pool_choice_5[30]  R1008     -1
    pool_choice_5[30]  R1026     -1
    pool_choice_5[30]  R1045     -1
    pool_choice_5[30]  R1050     -1
    pool_choice_5[30]  pool_cover_C90_order_d  1
    pool_choice_5[30]  pool_cover_C97_order_p  1
    pool_choice_5[30]  R1692     -1
    pool_choice_5[30]  R1779     -60
    pool_choice_5[31]  OBJ       6.3267650092996313e+01
    pool_choice_5[31]  R1001     1
    pool_choice_5[31]  R1002     -60
    pool_choice_5[31]  R1012     -1
    pool_choice_5[31]  R1021     -1
    pool_choice_5[31]  R1040     -1
    pool_choice_5[31]  R1050     -1
    pool_choice_5[31]  pool_cover_C90_order_p  1
    pool_choice_5[31]  pool_cover_C97_order_d  1
    pool_choice_5[31]  R1696     -1
    pool_choice_5[31]  R1779     -60
    pool_choice_5[32]  OBJ       6.4280634719952786e+01
    pool_choice_5[32]  R1001     1
    pool_choice_5[32]  R1002     -60
    pool_choice_5[32]  R1014     -1
    pool_choice_5[32]  R1031     -1
    pool_choice_5[32]  R1046     -1
    pool_choice_5[32]  R1050     -1
    pool_choice_5[32]  pool_cover_C51_order_d  1
    pool_choice_5[32]  pool_cover_C51_order_p  1
    pool_choice_5[32]  R1627     -1
    pool_choice_5[32]  R1779     -60
    pool_choice_5[33]  OBJ       6.6013282617951688e+01
    pool_choice_5[33]  R1001     1
    pool_choice_5[33]  R1002     -60
    pool_choice_5[33]  R1016     -1
    pool_choice_5[33]  R1033     -1
    pool_choice_5[33]  R1051     -1
    pool_choice_5[33]  pool_cover_C39_order_d  1
    pool_choice_5[33]  pool_cover_C52_order_d  1
    pool_choice_5[33]  R1640     -1
    pool_choice_5[33]  R1779     -60
    pool_choice_5[34]  OBJ       7.4637175985062072e+01
    pool_choice_5[34]  R1001     1
    pool_choice_5[34]  R1002     -60
    pool_choice_5[34]  R1014     -1
    pool_choice_5[34]  R1021     -1
    pool_choice_5[34]  R1040     -1
    pool_choice_5[34]  R1050     -1
    pool_choice_5[34]  pool_cover_C90_order_p  1
    pool_choice_5[34]  pool_cover_C51_order_d  1
    pool_choice_5[34]  R1667     -1
    pool_choice_5[34]  R1779     -60
    pool_choice_5[35]  OBJ       7.4637175985062072e+01
    pool_choice_5[35]  R1001     1
    pool_choice_5[35]  R1002     -60
    pool_choice_5[35]  R1008     -1
    pool_choice_5[35]  R1031     -1
    pool_choice_5[35]  R1046     -1
    pool_choice_5[35]  R1050     -1
    pool_choice_5[35]  pool_cover_C90_order_d  1
    pool_choice_5[35]  pool_cover_C51_order_p  1
    pool_choice_5[35]  R1666     -1
    pool_choice_5[35]  R1779     -60
    pool_choice_5[36]  OBJ       6
    pool_choice_5[36]  R1001     1
    pool_choice_5[36]  R1017     -1
    pool_choice_5[36]  R1022     -1
    pool_choice_5[36]  R1041     -1
    pool_choice_5[36]  pool_cover_C85_order_p  1
    pool_choice_5[37]  OBJ       3.6209473277964264e+01
    pool_choice_5[37]  R1001     1
    pool_choice_5[37]  R1002     -60
    pool_choice_5[37]  R1009     -1
    pool_choice_5[37]  R1029     -1
    pool_choice_5[37]  R1050     -1
    pool_choice_5[37]  pool_cover_C81_order_d  1
    pool_choice_5[37]  pool_cover_C90_order_d  1
    pool_choice_5[37]  R1628     -1
    pool_choice_5[37]  R1779     -60
    pool_choice_5[38]  OBJ       2.0478148916466086e+01
    pool_choice_5[38]  R1001     1
    pool_choice_5[38]  R1002     -60
    pool_choice_5[38]  R1009     -1
    pool_choice_5[38]  R1022     -1
    pool_choice_5[38]  R1041     -1
    pool_choice_5[38]  R1042     -1
    pool_choice_5[38]  R1050     -1
    pool_choice_5[38]  pool_cover_C81_order_d  1
    pool_choice_5[38]  pool_cover_C81_order_p  1
    pool_choice_5[38]  pool_cover_C85_order_p  1
    pool_choice_5[38]  R1619     -1
    pool_choice_5[38]  R1629     -1
    pool_choice_5[38]  R1779     -60
    pool_choice_5[39]  OBJ       8.4133301895330391e+01
    pool_choice_5[39]  R1001     1
    pool_choice_5[39]  R1002     -60
    pool_choice_5[39]  R1010     -1
    pool_choice_5[39]  R1034     -1
    pool_choice_5[39]  R1051     -1
    pool_choice_5[39]  pool_cover_C0_order_d  1
    pool_choice_5[39]  pool_cover_C39_order_d  1
    pool_choice_5[39]  pool_cover_C52_order_d  1
    pool_choice_5[39]  R1630     -1
    pool_choice_5[39]  R1631     -1
    pool_choice_5[39]  R1779     -60
    pool_choice_5[40]  OBJ       4.0324927052090487e+01
    pool_choice_5[40]  R1001     1
    pool_choice_5[40]  R1002     -60
    pool_choice_5[40]  R1010     -1
    pool_choice_5[40]  R1022     -1
    pool_choice_5[40]  R1041     -1
    pool_choice_5[40]  R1043     -1
    pool_choice_5[40]  R1044     -1
    pool_choice_5[40]  R1051     -1
    pool_choice_5[40]  pool_cover_C0_order_d  1
    pool_choice_5[40]  pool_cover_C0_order_p  1
    pool_choice_5[40]  pool_cover_C85_order_p  1
    pool_choice_5[40]  pool_cover_C75_order_p  1
    pool_choice_5[40]  R1621     -1
    pool_choice_5[40]  R1632     -1
    pool_choice_5[40]  R1633     -1
    pool_choice_5[40]  R1779     -60
    pool_choice_5[41]  OBJ       6
    pool_choice_5[41]  R1001     1
    pool_choice_5[41]  R1002     -60
    pool_choice_5[41]  R1015     -1
    pool_choice_5[41]  R1035     -1
    pool_choice_5[41]  R1052     -1
    pool_choice_5[41]  pool_cover_C85_order_d  1
    pool_choice_5[41]  R1779     -60
    pool_choice_5[42]  OBJ       6
    pool_choice_5[42]  R1001     1
    pool_choice_5[42]  R1002     -60
    pool_choice_5[42]  R1015     -1
    pool_choice_5[42]  R1022     -1
    pool_choice_5[42]  R1041     -1
    pool_choice_5[42]  R1052     -1
    pool_choice_5[42]  pool_cover_C85_order_d  1
    pool_choice_5[42]  pool_cover_C85_order_p  1
    pool_choice_5[42]  R1618     -1
    pool_choice_5[42]  R1779     -60
    pool_choice_5[43]  OBJ       2.0478148916466086e+01
    pool_choice_5[43]  R1001     1
    pool_choice_5[43]  R1018     -1
    pool_choice_5[43]  R1022     -1
    pool_choice_5[43]  R1041     -1
    pool_choice_5[43]  R1042     -1
    pool_choice_5[43]  pool_cover_C81_order_p  1
    pool_choice_5[43]  pool_cover_C85_order_p  1
    pool_choice_5[43]  R1629     -1
    pool_choice_5[44]  OBJ       2.0396078054371138e+01
    pool_choice_5[44]  R1001     1
    pool_choice_5[44]  R1002     -60
    pool_choice_5[44]  R1009     -1
    pool_choice_5[44]  R1036     -1
    pool_choice_5[44]  R1050     -1
    pool_choice_5[44]  pool_cover_C81_order_d  1
    pool_choice_5[44]  R1779     -60
    pool_choice_5[45]  OBJ       3.0265491900843113e+01
    pool_choice_5[45]  R1001     1
    pool_choice_5[45]  R1002     -60
    pool_choice_5[45]  R1010     -1
    pool_choice_5[45]  R1037     -1
    pool_choice_5[45]  R1051     -1
    pool_choice_5[45]  pool_cover_C0_order_d  1
    pool_choice_5[45]  R1779     -60
    pool_choice_5[46]  OBJ       3.3166042328794461e+01
    pool_choice_5[46]  R1001     1
    pool_choice_5[46]  R1002     -60
    pool_choice_5[46]  R1010     -1
    pool_choice_5[46]  R1022     -1
    pool_choice_5[46]  R1041     -1
    pool_choice_5[46]  R1043     -1
    pool_choice_5[46]  R1051     -1
    pool_choice_5[46]  pool_cover_C0_order_d  1
    pool_choice_5[46]  pool_cover_C0_order_p  1
    pool_choice_5[46]  pool_cover_C85_order_p  1
    pool_choice_5[46]  R1621     -1
    pool_choice_5[46]  R1635     -1
    pool_choice_5[46]  R1779     -60
    pool_choice_5[47]  OBJ       3.7837287915293039e+01
    pool_choice_5[47]  R1001     1
    pool_choice_5[47]  R1002     -60
    pool_choice_5[47]  R1015     -1
    pool_choice_5[47]  R1038     -1
    pool_choice_5[47]  R1052     -1
    pool_choice_5[47]  pool_cover_C85_order_d  1
    pool_choice_5[47]  pool_cover_C75_order_d  1
    pool_choice_5[47]  R1636     -1
    pool_choice_5[47]  R1779     -60
    pool_choice_5[48]  OBJ       41.4400902933387
    pool_choice_5[48]  R1001     1
    pool_choice_5[48]  R1002     -60
    pool_choice_5[48]  R1015     -1
    pool_choice_5[48]  R1022     -1
    pool_choice_5[48]  R1041     -1
    pool_choice_5[48]  R1044     -1
    pool_choice_5[48]  R1052     -1
    pool_choice_5[48]  pool_cover_C85_order_d  1
    pool_choice_5[48]  pool_cover_C85_order_p  1
    pool_choice_5[48]  pool_cover_C75_order_d  1
    pool_choice_5[48]  pool_cover_C75_order_p  1
    pool_choice_5[48]  R1622     -1
    pool_choice_5[48]  R1633     -1
    pool_choice_5[48]  R1636     -1
    pool_choice_5[48]  R1779     -60
    pool_choice_5[49]  OBJ       3.5116342351967482e+01
    pool_choice_5[49]  R1001     1
    pool_choice_5[49]  R1013     -1
    pool_choice_5[49]  R1022     -1
    pool_choice_5[49]  R1040     -1
    pool_choice_5[49]  R1041     -1
    pool_choice_5[49]  R1043     -1
    pool_choice_5[49]  pool_cover_C90_order_p  1
    pool_choice_5[49]  pool_cover_C0_order_p  1
    pool_choice_5[49]  pool_cover_C85_order_p  1
    pool_choice_5[49]  R1635     -1
    pool_choice_5[49]  R1637     -1
    pool_choice_5[50]  OBJ       6.3709853449601354e+01
    pool_choice_5[50]  R1001     1
    pool_choice_5[50]  R1002     -60
    pool_choice_5[50]  R1009     -1
    pool_choice_5[50]  R1029     -1
    pool_choice_5[50]  R1050     -1
    pool_choice_5[50]  pool_cover_C81_order_d  1
    pool_choice_5[50]  pool_cover_C90_order_d  1
    pool_choice_5[50]  pool_cover_C97_order_d  1
    pool_choice_5[50]  R1638     -1
    pool_choice_5[50]  R1639     -1
    pool_choice_5[50]  R1779     -60
    pool_choice_5[51]  OBJ       3.5116342351967482e+01
    pool_choice_5[51]  R1001     1
    pool_choice_5[51]  R1002     -60
    pool_choice_5[51]  R1008     -1
    pool_choice_5[51]  R1022     -1
    pool_choice_5[51]  R1040     -1
    pool_choice_5[51]  R1041     -1
    pool_choice_5[51]  R1043     -1
    pool_choice_5[51]  R1050     -1
    pool_choice_5[51]  pool_cover_C90_order_d  1
    pool_choice_5[51]  pool_cover_C90_order_p  1
    pool_choice_5[51]  pool_cover_C0_order_p  1
    pool_choice_5[51]  pool_cover_C85_order_p  1
    pool_choice_5[51]  R1620     -1
    pool_choice_5[51]  R1635     -1
    pool_choice_5[51]  R1637     -1
    pool_choice_5[51]  R1779     -60
    pool_choice_5[52]  OBJ       3.6722124674044828e+01
    pool_choice_5[52]  R1001     1
    pool_choice_5[52]  R1002     -60
    pool_choice_5[52]  R1010     -1
    pool_choice_5[52]  R1025     -1
    pool_choice_5[52]  R1043     -1
    pool_choice_5[52]  R1044     -1
    pool_choice_5[52]  R1051     -1
    pool_choice_5[52]  pool_cover_C0_order_d  1
    pool_choice_5[52]  pool_cover_C0_order_p  1
    pool_choice_5[52]  pool_cover_C75_order_p  1
    pool_choice_5[52]  R1621     -1
    pool_choice_5[52]  R1632     -1
    pool_choice_5[52]  R1779     -60
    pool_choice_5[53]  OBJ       3.7837287915293039e+01
    pool_choice_5[53]  R1001     1
    pool_choice_5[53]  R1002     -60
    pool_choice_5[53]  R1011     -1
    pool_choice_5[53]  R1022     -1
    pool_choice_5[53]  R1041     -1
    pool_choice_5[53]  R1044     -1
    pool_choice_5[53]  R1052     -1
    pool_choice_5[53]  pool_cover_C85_order_p  1
    pool_choice_5[53]  pool_cover_C75_order_d  1
    pool_choice_5[53]  pool_cover_C75_order_p  1
    pool_choice_5[53]  R1622     -1
    pool_choice_5[53]  R1633     -1
    pool_choice_5[53]  R1779     -60
    pool_choice_5[54]  OBJ       3.6291544140059209e+01
    pool_choice_5[54]  R1001     1
    pool_choice_5[54]  R1013     -1
    pool_choice_5[54]  R1022     -1
    pool_choice_5[54]  R1040     -1
    pool_choice_5[54]  R1041     -1
    pool_choice_5[54]  R1042     -1
    pool_choice_5[54]  pool_cover_C81_order_p  1
    pool_choice_5[54]  pool_cover_C90_order_p  1
    pool_choice_5[54]  pool_cover_C85_order_p  1
    pool_choice_5[54]  R1629     -1
    pool_choice_5[54]  R1642     -1
    pool_choice_5[55]  OBJ       6.6004157126226886e+01
    pool_choice_5[55]  R1001     1
    pool_choice_5[55]  R1002     -60
    pool_choice_5[55]  R1009     -1
    pool_choice_5[55]  R1039     -1
    pool_choice_5[55]  R1050     -1
    pool_choice_5[55]  pool_cover_C81_order_d  1
    pool_choice_5[55]  pool_cover_C97_order_d  1
    pool_choice_5[55]  pool_cover_C51_order_d  1
    pool_choice_5[55]  R1638     -1
    pool_choice_5[55]  R1643     -1
    pool_choice_5[55]  R1779     -60
    pool_choice_5[56]  OBJ       3.6291544140059209e+01
    pool_choice_5[56]  R1001     1
    pool_choice_5[56]  R1002     -60
    pool_choice_5[56]  R1008     -1
    pool_choice_5[56]  R1022     -1
    pool_choice_5[56]  R1041     -1
    pool_choice_5[56]  R1042     -1
    pool_choice_5[56]  R1050     -1
    pool_choice_5[56]  pool_cover_C81_order_d  1
    pool_choice_5[56]  pool_cover_C81_order_p  1
    pool_choice_5[56]  pool_cover_C90_order_d  1
    pool_choice_5[56]  pool_cover_C85_order_p  1
    pool_choice_5[56]  R1619     -1
    pool_choice_5[56]  R1629     -1
    pool_choice_5[56]  R1644     -1
    pool_choice_5[56]  R1779     -60
    pool_choice_5[57]  OBJ       71.9286437576317
    pool_choice_5[57]  R1001     1
    pool_choice_5[57]  R1002     -60
    pool_choice_5[57]  R1010     -1
    pool_choice_5[57]  R1034     -1
    pool_choice_5[57]  R1051     -1
    pool_choice_5[57]  pool_cover_C0_order_d  1
    pool_choice_5[57]  pool_cover_C39_order_d  1
    pool_choice_5[57]  R1645     -1
    pool_choice_5[57]  R1779     -60
    pool_choice_5[58]  OBJ       4.0324927052090487e+01
    pool_choice_5[58]  R1001     1
    pool_choice_5[58]  R1002     -60
    pool_choice_5[58]  R1010     -1
    pool_choice_5[58]  R1022     -1
    pool_choice_5[58]  R1041     -1
    pool_choice_5[58]  R1044     -1
    pool_choice_5[58]  R1051     -1
    pool_choice_5[58]  pool_cover_C0_order_d  1
    pool_choice_5[58]  pool_cover_C85_order_p  1
    pool_choice_5[58]  pool_cover_C75_order_p  1
    pool_choice_5[58]  R1633     -1
    pool_choice_5[58]  R1646     -1
    pool_choice_5[58]  R1779     -60
    pool_choice_5[59]  OBJ       3.4234485537247380e+01
    pool_choice_5[59]  R1001     1
    pool_choice_5[59]  R1002     -60
    pool_choice_5[59]  R1011     -1
    pool_choice_5[59]  R1038     -1
    pool_choice_5[59]  R1052     -1
    pool_choice_5[59]  pool_cover_C75_order_d  1
    pool_choice_5[59]  R1779     -60
    pool_choice_5[60]  OBJ       3.7837287915293039e+01
    pool_choice_5[60]  R1001     1
    pool_choice_5[60]  R1002     -60
    pool_choice_5[60]  R1015     -1
    pool_choice_5[60]  R1025     -1
    pool_choice_5[60]  R1044     -1
    pool_choice_5[60]  R1052     -1
    pool_choice_5[60]  pool_cover_C85_order_d  1
    pool_choice_5[60]  pool_cover_C75_order_d  1
    pool_choice_5[60]  pool_cover_C75_order_p  1
    pool_choice_5[60]  R1622     -1
    pool_choice_5[60]  R1636     -1
    pool_choice_5[60]  R1779     -60
    pool_choice_5[61]  OBJ       3.8672424697217842e+01
    pool_choice_5[61]  R1001     1
    pool_choice_5[61]  R1013     -1
    pool_choice_5[61]  R1025     -1
    pool_choice_5[61]  R1040     -1
    pool_choice_5[61]  R1043     -1
    pool_choice_5[61]  R1044     -1
    pool_choice_5[61]  pool_cover_C90_order_p  1
    pool_choice_5[61]  pool_cover_C0_order_p  1
    pool_choice_5[61]  pool_cover_C75_order_p  1
    pool_choice_5[61]  R1632     -1
    pool_choice_5[61]  R1637     -1
    pool_choice_5[62]  OBJ       3.6291544140059209e+01
    pool_choice_5[62]  R1001     1
    pool_choice_5[62]  R1002     -60
    pool_choice_5[62]  R1008     -1
    pool_choice_5[62]  R1022     -1
    pool_choice_5[62]  R1040     -1
    pool_choice_5[62]  R1041     -1
    pool_choice_5[62]  R1042     -1
    pool_choice_5[62]  R1050     -1
    pool_choice_5[62]  pool_cover_C81_order_p  1
    pool_choice_5[62]  pool_cover_C90_order_d  1
    pool_choice_5[62]  pool_cover_C90_order_p  1
    pool_choice_5[62]  pool_cover_C85_order_p  1
    pool_choice_5[62]  R1620     -1
    pool_choice_5[62]  R1629     -1
    pool_choice_5[62]  R1642     -1
    pool_choice_5[62]  R1779     -60
    pool_choice_5[63]  OBJ       8.0409665286968448e+01
    pool_choice_5[63]  R1001     1
    pool_choice_5[63]  R1002     -60
    pool_choice_5[63]  R1010     -1
    pool_choice_5[63]  R1033     -1
    pool_choice_5[63]  R1051     -1
    pool_choice_5[63]  pool_cover_C0_order_d  1
    pool_choice_5[63]  pool_cover_C52_order_d  1
    pool_choice_5[63]  R1630     -1
    pool_choice_5[63]  R1779     -60
    pool_choice_5[64]  OBJ       6.8348124505258170e+01
    pool_choice_5[64]  R1001     1
    pool_choice_5[64]  R1002     -60
    pool_choice_5[64]  R1019     -1
    pool_choice_5[64]  R1022     -1
    pool_choice_5[64]  R1041     -1
    pool_choice_5[64]  R1047     -1
    pool_choice_5[64]  R1048     -1
    pool_choice_5[64]  R1051     -1
    pool_choice_5[64]  pool_cover_C39_order_d  1
    pool_choice_5[64]  pool_cover_C39_order_p  1
    pool_choice_5[64]  pool_cover_C52_order_d  1
    pool_choice_5[64]  pool_cover_C85_order_p  1
    pool_choice_5[64]  pool_cover_C21_order_p  1
    pool_choice_5[64]  R1624     -1
    pool_choice_5[64]  R1631     -1
    pool_choice_5[64]  R1647     -1
    pool_choice_5[64]  R1648     -1
    pool_choice_5[64]  R1779     -60
    pool_choice_5[65]  OBJ       7.7871156918086484e+01
    pool_choice_5[65]  R1001     1
    pool_choice_5[65]  R1002     -60
    pool_choice_5[65]  R1020     -1
    pool_choice_5[65]  R1038     -1
    pool_choice_5[65]  R1052     -1
    pool_choice_5[65]  pool_cover_C75_order_d  1
    pool_choice_5[65]  pool_cover_C21_order_d  1
    pool_choice_5[65]  R1649     -1
    pool_choice_5[65]  R1779     -60
    pool_choice_5[66]  OBJ       3.7837287915293039e+01
    pool_choice_5[66]  R1001     1
    pool_choice_5[66]  R1002     -60
    pool_choice_5[66]  R1015     -1
    pool_choice_5[66]  R1025     -1
    pool_choice_5[66]  R1041     -1
    pool_choice_5[66]  R1044     -1
    pool_choice_5[66]  R1052     -1
    pool_choice_5[66]  pool_cover_C85_order_d  1
    pool_choice_5[66]  pool_cover_C85_order_p  1
    pool_choice_5[66]  pool_cover_C75_order_p  1
    pool_choice_5[66]  R1618     -1
    pool_choice_5[66]  R1650     -1
    pool_choice_5[66]  R1779     -60
    pool_choice_5[67]  OBJ       2.6263385861093521e+01
    pool_choice_5[67]  R1001     1
    pool_choice_5[67]  R1013     -1
    pool_choice_5[67]  R1022     -1
    pool_choice_5[67]  R1040     -1
    pool_choice_5[67]  R1041     -1
    pool_choice_5[67]  pool_cover_C90_order_p  1
    pool_choice_5[67]  pool_cover_C85_order_p  1
    pool_choice_5[67]  R1634     -1
    pool_used_5  R1001     -1
    pool_used_5  R1002     -28800
    pool_used_5  R1003     -75600
    pool_used_5  R1004     -75540
    pool_used_5  R1005     -1
    pool_used_5  R1006     -80
    pool_used_5  R1007     -80
    pool_used_5  R1779     -75660
    pool_used_5  R1780     -81
    pool_used_5  R1785     -75660
    pool_used_5  R1786     -81
    pool_used_5  R1787     -75660
    pool_used_5  R1788     -81
    pool_start_5  R1002     1
    pool_start_5  R1003     1
    pool_start_5  R1779     1
    pool_start_5  GC490     -1
    pool_start_5  GC492     -1
    pool_start_5  GC494     -1
    pool_start_5  GC496     -1
    pool_start_5  GC498     -1
    pool_start_5  GC500     -1
    pool_start_5  GC502     -1
    pool_start_5  GC504     -1
    pool_start_5  GC506     -1
    pool_start_5  GC508     -1
    pool_start_5  GC510     -1
    pool_start_5  GC512     -1
    pool_start_5  GC514     -1
    pool_start_5  GC564     1
    pool_start_5  GC565     1
    pool_start_5  GC566     1
    pool_end_5  R1004     1
    pool_end_5  R1785     -1
    pool_end_5  R1787     -1
    pool_end_5  GC516     1
    pool_end_5  GC518     1
    pool_end_5  GC520     1
    pool_end_5  GC522     1
    pool_end_5  GC524     1
    pool_end_5  GC526     1
    pool_end_5  GC528     1
    pool_end_5  GC530     1
    pool_end_5  GC532     1
    pool_end_5  GC534     1
    pool_end_5  GC536     1
    pool_end_5  GC538     1
    pool_end_5  GC540     1
    pool_end_5  GC542     1
    pool_end_5  GC544     1
    pool_end_5  GC546     1
    pool_end_5  GC548     1
    pool_end_5  GC550     1
    pool_end_5  GC552     1
    pool_end_5  GC554     -1
    pool_end_5  GC555     -1
    pool_end_5  GC556     -1
    pool_end_5  GC557     -1
    pool_end_5  GC558     -1
    pool_end_5  GC559     -1
    pool_end_5  GC560     -1
    pool_end_5  GC561     -1
    pool_end_5  GC562     -1
    pool_end_5  GC563     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_5  R1005     1
    pool_start_rank_5  R1006     1
    pool_start_rank_5  R1780     1
    pool_start_rank_5  GC491     -1
    pool_start_rank_5  GC493     -1
    pool_start_rank_5  GC495     -1
    pool_start_rank_5  GC497     -1
    pool_start_rank_5  GC499     -1
    pool_start_rank_5  GC501     -1
    pool_start_rank_5  GC503     -1
    pool_start_rank_5  GC505     -1
    pool_start_rank_5  GC507     -1
    pool_start_rank_5  GC509     -1
    pool_start_rank_5  GC511     -1
    pool_start_rank_5  GC513     -1
    pool_start_rank_5  GC515     -1
    pool_end_rank_5  R1007     1
    pool_end_rank_5  R1786     -1
    pool_end_rank_5  R1788     -1
    pool_end_rank_5  GC517     1
    pool_end_rank_5  GC519     1
    pool_end_rank_5  GC521     1
    pool_end_rank_5  GC523     1
    pool_end_rank_5  GC525     1
    pool_end_rank_5  GC527     1
    pool_end_rank_5  GC529     1
    pool_end_rank_5  GC531     1
    pool_end_rank_5  GC533     1
    pool_end_rank_5  GC535     1
    pool_end_rank_5  GC537     1
    pool_end_rank_5  GC539     1
    pool_end_rank_5  GC541     1
    pool_end_rank_5  GC543     1
    pool_end_rank_5  GC545     1
    pool_end_rank_5  GC547     1
    pool_end_rank_5  GC549     1
    pool_end_rank_5  GC551     1
    pool_end_rank_5  GC553     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_5_C90_order_d  R1008     1
    pool_first_5_C81_order_d  R1009     1
    pool_first_5_C0_order_d  R1010     1
    pool_first_5_C75_order_d  R1011     1
    pool_first_5_C97_order_d  R1012     1
    pool_first_5_C90_order_p  R1013     1
    pool_first_5_C51_order_d  R1014     1
    pool_first_5_C85_order_d  R1015     1
    pool_first_5_C39_order_d  R1016     1
    pool_first_5_C85_order_p  R1017     1
    pool_first_5_C81_order_p  R1018     1
    pool_first_5_C52_order_d  R1019     1
    pool_first_5_C21_order_d  R1020     1
    pool_last_5_C90_order_p  R1021     1
    pool_last_5_C85_order_p  R1022     1
    pool_last_5_C81_order_p  R1023     1
    pool_last_5_C0_order_p  R1024     1
    pool_last_5_C75_order_p  R1025     1
    pool_last_5_C97_order_p  R1026     1
    pool_last_5_C21_order_p  R1027     1
    pool_last_5_C39_order_p  R1028     1
    pool_last_5_C90_order_d  R1029     1
    pool_last_5_C52_order_p  R1030     1
    pool_last_5_C51_order_p  R1031     1
    pool_last_5_C21_order_d  R1032     1
    pool_last_5_C52_order_d  R1033     1
    pool_last_5_C39_order_d  R1034     1
    pool_last_5_C85_order_d  R1035     1
    pool_last_5_C81_order_d  R1036     1
    pool_last_5_C0_order_d  R1037     1
    pool_last_5_C75_order_d  R1038     1
    pool_last_5_C51_order_d  R1039     1
    pool_pickup_5_C90_order  R1040     1
    pool_pickup_5_C85_order  R1041     1
    pool_pickup_5_C81_order  R1042     1
    pool_pickup_5_C0_order  R1043     1
    pool_pickup_5_C75_order  R1044     1
    pool_pickup_5_C97_order  R1045     1
    pool_pickup_5_C51_order  R1046     1
    pool_pickup_5_C21_order  R1047     1
    pool_pickup_5_C39_order  R1048     1
    pool_pickup_5_C52_order  R1049     1
    pool_batch_5_b1  R1050     1
    pool_batch_5_b2  R1051     1
    pool_batch_5_b3  R1052     1
    pool_choice_6[0]  OBJ       6.9736919226313631e+01
    pool_choice_6[0]  R1053     1
    pool_choice_6[0]  R1054     -60
    pool_choice_6[0]  R1060     -1
    pool_choice_6[0]  R1070     -1
    pool_choice_6[0]  R1085     -1
    pool_choice_6[0]  R1086     -1
    pool_choice_6[0]  R1093     -1
    pool_choice_6[0]  pool_cover_C39_order_d  1
    pool_choice_6[0]  pool_cover_C39_order_p  1
    pool_choice_6[0]  pool_cover_C52_order_d  1
    pool_choice_6[0]  pool_cover_C52_order_p  1
    pool_choice_6[0]  R1626     -1
    pool_choice_6[0]  R1640     -1
    pool_choice_6[0]  R1652     -1
    pool_choice_6[0]  R1781     -60
    pool_choice_6[0]  R1785     -60
    pool_choice_6[1]  OBJ       6.9756020169684533e+01
    pool_choice_6[1]  R1053     1
    pool_choice_6[1]  R1054     -60
    pool_choice_6[1]  R1060     -1
    pool_choice_6[1]  R1071     -1
    pool_choice_6[1]  R1085     -1
    pool_choice_6[1]  R1086     -1
    pool_choice_6[1]  R1087     -1
    pool_choice_6[1]  R1093     -1
    pool_choice_6[1]  pool_cover_C39_order_d  1
    pool_choice_6[1]  pool_cover_C39_order_p  1
    pool_choice_6[1]  pool_cover_C52_order_d  1
    pool_choice_6[1]  pool_cover_C52_order_p  1
    pool_choice_6[1]  pool_cover_C85_order_p  1
    pool_choice_6[1]  R1626     -1
    pool_choice_6[1]  R1640     -1
    pool_choice_6[1]  R1652     -1
    pool_choice_6[1]  R1653     -1
    pool_choice_6[1]  R1781     -60
    pool_choice_6[1]  R1785     -60
    pool_choice_6[2]  OBJ       7.2019588852311969e+01
    pool_choice_6[2]  R1053     1
    pool_choice_6[2]  R1054     -60
    pool_choice_6[2]  R1060     -1
    pool_choice_6[2]  R1072     -1
    pool_choice_6[2]  R1085     -1
    pool_choice_6[2]  R1086     -1
    pool_choice_6[2]  R1088     -1
    pool_choice_6[2]  R1093     -1
    pool_choice_6[2]  pool_cover_C39_order_d  1
    pool_choice_6[2]  pool_cover_C39_order_p  1
    pool_choice_6[2]  pool_cover_C52_order_d  1
    pool_choice_6[2]  pool_cover_C52_order_p  1
    pool_choice_6[2]  pool_cover_C21_order_p  1
    pool_choice_6[2]  R1626     -1
    pool_choice_6[2]  R1640     -1
    pool_choice_6[2]  R1647     -1
    pool_choice_6[2]  R1652     -1
    pool_choice_6[2]  R1781     -60
    pool_choice_6[2]  R1785     -60
    pool_choice_6[3]  OBJ       8.5345051622630450e+01
    pool_choice_6[3]  R1053     1
    pool_choice_6[3]  R1054     -60
    pool_choice_6[3]  R1060     -1
    pool_choice_6[3]  R1073     -1
    pool_choice_6[3]  R1085     -1
    pool_choice_6[3]  R1086     -1
    pool_choice_6[3]  R1089     -1
    pool_choice_6[3]  R1093     -1
    pool_choice_6[3]  pool_cover_C0_order_p  1
    pool_choice_6[3]  pool_cover_C39_order_d  1
    pool_choice_6[3]  pool_cover_C39_order_p  1
    pool_choice_6[3]  pool_cover_C52_order_d  1
    pool_choice_6[3]  pool_cover_C52_order_p  1
    pool_choice_6[3]  R1626     -1
    pool_choice_6[3]  R1640     -1
    pool_choice_6[3]  R1652     -1
    pool_choice_6[3]  R1668     -1
    pool_choice_6[3]  R1781     -60
    pool_choice_6[3]  R1785     -60
    pool_choice_6[4]  OBJ       9.1799797028773582e+01
    pool_choice_6[4]  R1053     1
    pool_choice_6[4]  R1054     -60
    pool_choice_6[4]  R1060     -1
    pool_choice_6[4]  R1074     -1
    pool_choice_6[4]  R1085     -1
    pool_choice_6[4]  R1086     -1
    pool_choice_6[4]  R1090     -1
    pool_choice_6[4]  R1093     -1
    pool_choice_6[4]  pool_cover_C39_order_d  1
    pool_choice_6[4]  pool_cover_C39_order_p  1
    pool_choice_6[4]  pool_cover_C52_order_d  1
    pool_choice_6[4]  pool_cover_C52_order_p  1
    pool_choice_6[4]  pool_cover_C75_order_p  1
    pool_choice_6[4]  R1626     -1
    pool_choice_6[4]  R1640     -1
    pool_choice_6[4]  R1652     -1
    pool_choice_6[4]  R1697     -1
    pool_choice_6[4]  R1781     -60
    pool_choice_6[4]  R1785     -60
    pool_choice_6[5]  OBJ       7.6481151707218189e+01
    pool_choice_6[5]  R1053     1
    pool_choice_6[5]  R1054     -60
    pool_choice_6[5]  R1061     -1
    pool_choice_6[5]  R1070     -1
    pool_choice_6[5]  R1085     -1
    pool_choice_6[5]  R1086     -1
    pool_choice_6[5]  R1091     -1
    pool_choice_6[5]  R1094     -1
    pool_choice_6[5]  pool_cover_C90_order_d  1
    pool_choice_6[5]  pool_cover_C90_order_p  1
    pool_choice_6[5]  pool_cover_C39_order_p  1
    pool_choice_6[5]  pool_cover_C52_order_p  1
    pool_choice_6[5]  R1620     -1
    pool_choice_6[5]  R1652     -1
    pool_choice_6[5]  R1693     -1
    pool_choice_6[5]  R1781     -60
    pool_choice_6[5]  R1785     -60
    pool_choice_6[6]  OBJ       7.9429690482950434e+01
    pool_choice_6[6]  R1053     1
    pool_choice_6[6]  R1054     -60
    pool_choice_6[6]  R1062     -1
    pool_choice_6[6]  R1070     -1
    pool_choice_6[6]  R1085     -1
    pool_choice_6[6]  R1086     -1
    pool_choice_6[6]  R1093     -1
    pool_choice_6[6]  pool_cover_C39_order_d  1
    pool_choice_6[6]  pool_cover_C39_order_p  1
    pool_choice_6[6]  pool_cover_C52_order_d  1
    pool_choice_6[6]  pool_cover_C52_order_p  1
    pool_choice_6[6]  R1631     -1
    pool_choice_6[6]  R1652     -1
    pool_choice_6[6]  R1698     -1
    pool_choice_6[6]  R1781     -60
    pool_choice_6[6]  R1785     -60
    pool_choice_6[7]  OBJ       8.4133301895330391e+01
    pool_choice_6[7]  R1053     1
    pool_choice_6[7]  R1054     -60
    pool_choice_6[7]  R1063     -1
    pool_choice_6[7]  R1070     -1
    pool_choice_6[7]  R1085     -1
    pool_choice_6[7]  R1086     -1
    pool_choice_6[7]  R1089     -1
    pool_choice_6[7]  R1093     -1
    pool_choice_6[7]  pool_cover_C0_order_d  1
    pool_choice_6[7]  pool_cover_C0_order_p  1
    pool_choice_6[7]  pool_cover_C39_order_p  1
    pool_choice_6[7]  pool_cover_C52_order_p  1
    pool_choice_6[7]  R1621     -1
    pool_choice_6[7]  R1652     -1
    pool_choice_6[7]  R1672     -1
    pool_choice_6[7]  R1781     -60
    pool_choice_6[7]  R1785     -60
    pool_choice_6[8]  OBJ       8.4133301895330391e+01
    pool_choice_6[8]  R1053     1
    pool_choice_6[8]  R1054     -60
    pool_choice_6[8]  R1063     -1
    pool_choice_6[8]  R1070     -1
    pool_choice_6[8]  R1085     -1
    pool_choice_6[8]  R1086     -1
    pool_choice_6[8]  R1093     -1
    pool_choice_6[8]  pool_cover_C0_order_d  1
    pool_choice_6[8]  pool_cover_C39_order_p  1
    pool_choice_6[8]  pool_cover_C52_order_d  1
    pool_choice_6[8]  pool_cover_C52_order_p  1
    pool_choice_6[8]  R1626     -1
    pool_choice_6[8]  R1630     -1
    pool_choice_6[8]  R1652     -1
    pool_choice_6[8]  R1781     -60
    pool_choice_6[8]  R1785     -60
    pool_choice_6[9]  OBJ       8.4133301895330391e+01
    pool_choice_6[9]  R1053     1
    pool_choice_6[9]  R1054     -60
    pool_choice_6[9]  R1060     -1
    pool_choice_6[9]  R1073     -1
    pool_choice_6[9]  R1085     -1
    pool_choice_6[9]  R1089     -1
    pool_choice_6[9]  R1093     -1
    pool_choice_6[9]  pool_cover_C0_order_p  1
    pool_choice_6[9]  pool_cover_C39_order_d  1
    pool_choice_6[9]  pool_cover_C52_order_d  1
    pool_choice_6[9]  pool_cover_C52_order_p  1
    pool_choice_6[9]  R1626     -1
    pool_choice_6[9]  R1640     -1
    pool_choice_6[9]  R1671     -1
    pool_choice_6[9]  R1781     -60
    pool_choice_6[9]  R1785     -60
    pool_choice_6[10]  OBJ       6.6013282617951688e+01
    pool_choice_6[10]  R1053     1
    pool_choice_6[10]  R1054     -60
    pool_choice_6[10]  R1060     -1
    pool_choice_6[10]  R1075     -1
    pool_choice_6[10]  R1085     -1
    pool_choice_6[10]  R1093     -1
    pool_choice_6[10]  pool_cover_C39_order_d  1
    pool_choice_6[10]  pool_cover_C52_order_d  1
    pool_choice_6[10]  pool_cover_C52_order_p  1
    pool_choice_6[10]  R1626     -1
    pool_choice_6[10]  R1640     -1
    pool_choice_6[10]  R1781     -60
    pool_choice_6[10]  R1785     -60
    pool_choice_6[11]  OBJ       6.6013282617951688e+01
    pool_choice_6[11]  R1053     1
    pool_choice_6[11]  R1054     -60
    pool_choice_6[11]  R1062     -1
    pool_choice_6[11]  R1070     -1
    pool_choice_6[11]  R1085     -1
    pool_choice_6[11]  R1086     -1
    pool_choice_6[11]  R1093     -1
    pool_choice_6[11]  pool_cover_C39_order_p  1
    pool_choice_6[11]  pool_cover_C52_order_d  1
    pool_choice_6[11]  pool_cover_C52_order_p  1
    pool_choice_6[11]  R1626     -1
    pool_choice_6[11]  R1652     -1
    pool_choice_6[11]  R1781     -60
    pool_choice_6[11]  R1785     -60
    pool_choice_6[12]  OBJ       6.9736919226313631e+01
    pool_choice_6[12]  R1053     1
    pool_choice_6[12]  R1054     -60
    pool_choice_6[12]  R1060     -1
    pool_choice_6[12]  R1070     -1
    pool_choice_6[12]  R1086     -1
    pool_choice_6[12]  R1093     -1
    pool_choice_6[12]  pool_cover_C39_order_d  1
    pool_choice_6[12]  pool_cover_C39_order_p  1
    pool_choice_6[12]  pool_cover_C52_order_d  1
    pool_choice_6[12]  R1640     -1
    pool_choice_6[12]  R1699     -1
    pool_choice_6[12]  R1781     -60
    pool_choice_6[12]  R1785     -60
    pool_choice_6[13]  OBJ       6.9736919226313631e+01
    pool_choice_6[13]  R1053     1
    pool_choice_6[13]  R1054     -60
    pool_choice_6[13]  R1060     -1
    pool_choice_6[13]  R1070     -1
    pool_choice_6[13]  R1085     -1
    pool_choice_6[13]  R1086     -1
    pool_choice_6[13]  R1093     -1
    pool_choice_6[13]  pool_cover_C39_order_d  1
    pool_choice_6[13]  pool_cover_C39_order_p  1
    pool_choice_6[13]  pool_cover_C52_order_p  1
    pool_choice_6[13]  R1652     -1
    pool_choice_6[13]  R1698     -1
    pool_choice_6[13]  R1781     -60
    pool_choice_6[13]  R1785     -60
    pool_choice_6[14]  OBJ       9.8529684564347164e+01
    pool_choice_6[14]  R1053     1
    pool_choice_6[14]  R1054     -60
    pool_choice_6[14]  R1063     -1
    pool_choice_6[14]  R1073     -1
    pool_choice_6[14]  R1085     -1
    pool_choice_6[14]  R1089     -1
    pool_choice_6[14]  R1093     -1
    pool_choice_6[14]  pool_cover_C0_order_d  1
    pool_choice_6[14]  pool_cover_C0_order_p  1
    pool_choice_6[14]  pool_cover_C52_order_d  1
    pool_choice_6[14]  pool_cover_C52_order_p  1
    pool_choice_6[14]  R1626     -1
    pool_choice_6[14]  R1630     -1
    pool_choice_6[14]  R1671     -1
    pool_choice_6[14]  R1781     -60
    pool_choice_6[14]  R1785     -60
    pool_choice_6[15]  OBJ       1.3800111188981768e+02
    pool_choice_6[15]  R1053     1
    pool_choice_6[15]  R1054     -60
    pool_choice_6[15]  R1060     -1
    pool_choice_6[15]  R1070     -1
    pool_choice_6[15]  R1085     -1
    pool_choice_6[15]  R1086     -1
    pool_choice_6[15]  R1089     -1
    pool_choice_6[15]  R1093     -1
    pool_choice_6[15]  pool_cover_C0_order_p  1
    pool_choice_6[15]  pool_cover_C39_order_d  1
    pool_choice_6[15]  pool_cover_C39_order_p  1
    pool_choice_6[15]  pool_cover_C52_order_d  1
    pool_choice_6[15]  pool_cover_C52_order_p  1
    pool_choice_6[15]  R1640     -1
    pool_choice_6[15]  R1652     -1
    pool_choice_6[15]  R1672     -1
    pool_choice_6[15]  R1674     -1
    pool_choice_6[15]  R1781     -60
    pool_choice_6[15]  R1785     -60
    pool_choice_6[16]  OBJ       5.6320511361314892e+01
    pool_choice_6[16]  R1053     1
    pool_choice_6[16]  R1054     -60
    pool_choice_6[16]  R1060     -1
    pool_choice_6[16]  R1070     -1
    pool_choice_6[16]  R1086     -1
    pool_choice_6[16]  R1093     -1
    pool_choice_6[16]  pool_cover_C39_order_d  1
    pool_choice_6[16]  pool_cover_C39_order_p  1
    pool_choice_6[16]  R1624     -1
    pool_choice_6[16]  R1781     -60
    pool_choice_6[16]  R1785     -60
    pool_choice_6[17]  OBJ       6.2289646009589745e+01
    pool_choice_6[17]  R1053     1
    pool_choice_6[17]  R1054     -60
    pool_choice_6[17]  R1062     -1
    pool_choice_6[17]  R1075     -1
    pool_choice_6[17]  R1085     -1
    pool_choice_6[17]  R1093     -1
    pool_choice_6[17]  pool_cover_C52_order_d  1
    pool_choice_6[17]  pool_cover_C52_order_p  1
    pool_choice_6[17]  R1626     -1
    pool_choice_6[17]  R1781     -60
    pool_choice_6[17]  R1785     -60
    pool_choice_6[18]  OBJ       1.2579645375211899e+02
    pool_choice_6[18]  R1053     1
    pool_choice_6[18]  R1054     -60
    pool_choice_6[18]  R1060     -1
    pool_choice_6[18]  R1070     -1
    pool_choice_6[18]  R1085     -1
    pool_choice_6[18]  R1086     -1
    pool_choice_6[18]  R1089     -1
    pool_choice_6[18]  R1093     -1
    pool_choice_6[18]  pool_cover_C0_order_p  1
    pool_choice_6[18]  pool_cover_C39_order_d  1
    pool_choice_6[18]  pool_cover_C39_order_p  1
    pool_choice_6[18]  pool_cover_C52_order_p  1
    pool_choice_6[18]  R1652     -1
    pool_choice_6[18]  R1672     -1
    pool_choice_6[18]  R1673     -1
    pool_choice_6[18]  R1781     -60
    pool_choice_6[18]  R1785     -60
    pool_choice_6[19]  OBJ       1.2579645375211899e+02
    pool_choice_6[19]  R1053     1
    pool_choice_6[19]  R1054     -60
    pool_choice_6[19]  R1060     -1
    pool_choice_6[19]  R1070     -1
    pool_choice_6[19]  R1086     -1
    pool_choice_6[19]  R1089     -1
    pool_choice_6[19]  R1093     -1
    pool_choice_6[19]  pool_cover_C0_order_p  1
    pool_choice_6[19]  pool_cover_C39_order_d  1
    pool_choice_6[19]  pool_cover_C39_order_p  1
    pool_choice_6[19]  pool_cover_C52_order_d  1
    pool_choice_6[19]  R1640     -1
    pool_choice_6[19]  R1670     -1
    pool_choice_6[19]  R1674     -1
    pool_choice_6[19]  R1781     -60
    pool_choice_6[19]  R1785     -60
    pool_choice_6[20]  OBJ       6
    pool_choice_6[20]  R1053     1
    pool_choice_6[20]  R1064     -1
    pool_choice_6[20]  R1071     -1
    pool_choice_6[20]  R1087     -1
    pool_choice_6[20]  pool_cover_C85_order_p  1
    pool_choice_6[21]  OBJ       3.6209473277964264e+01
    pool_choice_6[21]  R1053     1
    pool_choice_6[21]  R1054     -60
    pool_choice_6[21]  R1065     -1
    pool_choice_6[21]  R1076     -1
    pool_choice_6[21]  R1094     -1
    pool_choice_6[21]  pool_cover_C81_order_d  1
    pool_choice_6[21]  pool_cover_C90_order_d  1
    pool_choice_6[21]  R1628     -1
    pool_choice_6[21]  R1781     -60
    pool_choice_6[21]  R1785     -60
    pool_choice_6[22]  OBJ       2.0478148916466086e+01
    pool_choice_6[22]  R1053     1
    pool_choice_6[22]  R1054     -60
    pool_choice_6[22]  R1065     -1
    pool_choice_6[22]  R1071     -1
    pool_choice_6[22]  R1087     -1
    pool_choice_6[22]  R1092     -1
    pool_choice_6[22]  R1094     -1
    pool_choice_6[22]  pool_cover_C81_order_d  1
    pool_choice_6[22]  pool_cover_C81_order_p  1
    pool_choice_6[22]  pool_cover_C85_order_p  1
    pool_choice_6[22]  R1619     -1
    pool_choice_6[22]  R1629     -1
    pool_choice_6[22]  R1781     -60
    pool_choice_6[22]  R1785     -60
    pool_choice_6[23]  OBJ       8.4133301895330391e+01
    pool_choice_6[23]  R1053     1
    pool_choice_6[23]  R1054     -60
    pool_choice_6[23]  R1063     -1
    pool_choice_6[23]  R1077     -1
    pool_choice_6[23]  R1093     -1
    pool_choice_6[23]  pool_cover_C0_order_d  1
    pool_choice_6[23]  pool_cover_C39_order_d  1
    pool_choice_6[23]  pool_cover_C52_order_d  1
    pool_choice_6[23]  R1630     -1
    pool_choice_6[23]  R1631     -1
    pool_choice_6[23]  R1781     -60
    pool_choice_6[23]  R1785     -60
    pool_choice_6[24]  OBJ       4.0324927052090487e+01
    pool_choice_6[24]  R1053     1
    pool_choice_6[24]  R1054     -60
    pool_choice_6[24]  R1063     -1
    pool_choice_6[24]  R1071     -1
    pool_choice_6[24]  R1087     -1
    pool_choice_6[24]  R1089     -1
    pool_choice_6[24]  R1090     -1
    pool_choice_6[24]  R1093     -1
    pool_choice_6[24]  pool_cover_C0_order_d  1
    pool_choice_6[24]  pool_cover_C0_order_p  1
    pool_choice_6[24]  pool_cover_C85_order_p  1
    pool_choice_6[24]  pool_cover_C75_order_p  1
    pool_choice_6[24]  R1621     -1
    pool_choice_6[24]  R1632     -1
    pool_choice_6[24]  R1633     -1
    pool_choice_6[24]  R1781     -60
    pool_choice_6[24]  R1785     -60
    pool_choice_6[25]  OBJ       6
    pool_choice_6[25]  R1053     1
    pool_choice_6[25]  R1054     -60
    pool_choice_6[25]  R1066     -1
    pool_choice_6[25]  R1078     -1
    pool_choice_6[25]  R1095     -1
    pool_choice_6[25]  pool_cover_C85_order_d  1
    pool_choice_6[25]  R1781     -60
    pool_choice_6[25]  R1785     -60
    pool_choice_6[26]  OBJ       6
    pool_choice_6[26]  R1053     1
    pool_choice_6[26]  R1054     -60
    pool_choice_6[26]  R1066     -1
    pool_choice_6[26]  R1071     -1
    pool_choice_6[26]  R1087     -1
    pool_choice_6[26]  R1095     -1
    pool_choice_6[26]  pool_cover_C85_order_d  1
    pool_choice_6[26]  pool_cover_C85_order_p  1
    pool_choice_6[26]  R1618     -1
    pool_choice_6[26]  R1781     -60
    pool_choice_6[26]  R1785     -60
    pool_choice_6[27]  OBJ       2.0478148916466086e+01
    pool_choice_6[27]  R1053     1
    pool_choice_6[27]  R1067     -1
    pool_choice_6[27]  R1071     -1
    pool_choice_6[27]  R1087     -1
    pool_choice_6[27]  R1092     -1
    pool_choice_6[27]  pool_cover_C81_order_p  1
    pool_choice_6[27]  pool_cover_C85_order_p  1
    pool_choice_6[27]  R1629     -1
    pool_choice_6[28]  OBJ       2.0396078054371138e+01
    pool_choice_6[28]  R1053     1
    pool_choice_6[28]  R1054     -60
    pool_choice_6[28]  R1065     -1
    pool_choice_6[28]  R1079     -1
    pool_choice_6[28]  R1094     -1
    pool_choice_6[28]  pool_cover_C81_order_d  1
    pool_choice_6[28]  R1781     -60
    pool_choice_6[28]  R1785     -60
    pool_choice_6[29]  OBJ       2.6263385861093521e+01
    pool_choice_6[29]  R1053     1
    pool_choice_6[29]  R1054     -60
    pool_choice_6[29]  R1061     -1
    pool_choice_6[29]  R1071     -1
    pool_choice_6[29]  R1087     -1
    pool_choice_6[29]  R1091     -1
    pool_choice_6[29]  R1094     -1
    pool_choice_6[29]  pool_cover_C90_order_d  1
    pool_choice_6[29]  pool_cover_C90_order_p  1
    pool_choice_6[29]  pool_cover_C85_order_p  1
    pool_choice_6[29]  R1620     -1
    pool_choice_6[29]  R1634     -1
    pool_choice_6[29]  R1781     -60
    pool_choice_6[29]  R1785     -60
    pool_choice_6[30]  OBJ       3.0265491900843113e+01
    pool_choice_6[30]  R1053     1
    pool_choice_6[30]  R1054     -60
    pool_choice_6[30]  R1063     -1
    pool_choice_6[30]  R1080     -1
    pool_choice_6[30]  R1093     -1
    pool_choice_6[30]  pool_cover_C0_order_d  1
    pool_choice_6[30]  R1781     -60
    pool_choice_6[30]  R1785     -60
    pool_choice_6[31]  OBJ       3.3166042328794461e+01
    pool_choice_6[31]  R1053     1
    pool_choice_6[31]  R1054     -60
    pool_choice_6[31]  R1063     -1
    pool_choice_6[31]  R1071     -1
    pool_choice_6[31]  R1087     -1
    pool_choice_6[31]  R1089     -1
    pool_choice_6[31]  R1093     -1
    pool_choice_6[31]  pool_cover_C0_order_d  1
    pool_choice_6[31]  pool_cover_C0_order_p  1
    pool_choice_6[31]  pool_cover_C85_order_p  1
    pool_choice_6[31]  R1621     -1
    pool_choice_6[31]  R1635     -1
    pool_choice_6[31]  R1781     -60
    pool_choice_6[31]  R1785     -60
    pool_choice_6[32]  OBJ       3.7837287915293039e+01
    pool_choice_6[32]  R1053     1
    pool_choice_6[32]  R1054     -60
    pool_choice_6[32]  R1066     -1
    pool_choice_6[32]  R1081     -1
    pool_choice_6[32]  R1095     -1
    pool_choice_6[32]  pool_cover_C85_order_d  1
    pool_choice_6[32]  pool_cover_C75_order_d  1
    pool_choice_6[32]  R1636     -1
    pool_choice_6[32]  R1781     -60
    pool_choice_6[32]  R1785     -60
    pool_choice_6[33]  OBJ       41.4400902933387
    pool_choice_6[33]  R1053     1
    pool_choice_6[33]  R1054     -60
    pool_choice_6[33]  R1066     -1
    pool_choice_6[33]  R1071     -1
    pool_choice_6[33]  R1087     -1
    pool_choice_6[33]  R1090     -1
    pool_choice_6[33]  R1095     -1
    pool_choice_6[33]  pool_cover_C85_order_d  1
    pool_choice_6[33]  pool_cover_C85_order_p  1
    pool_choice_6[33]  pool_cover_C75_order_d  1
    pool_choice_6[33]  pool_cover_C75_order_p  1
    pool_choice_6[33]  R1622     -1
    pool_choice_6[33]  R1633     -1
    pool_choice_6[33]  R1636     -1
    pool_choice_6[33]  R1781     -60
    pool_choice_6[33]  R1785     -60
    pool_choice_6[34]  OBJ       3.5116342351967482e+01
    pool_choice_6[34]  R1053     1
    pool_choice_6[34]  R1068     -1
    pool_choice_6[34]  R1071     -1
    pool_choice_6[34]  R1087     -1
    pool_choice_6[34]  R1089     -1
    pool_choice_6[34]  R1091     -1
    pool_choice_6[34]  pool_cover_C90_order_p  1
    pool_choice_6[34]  pool_cover_C0_order_p  1
    pool_choice_6[34]  pool_cover_C85_order_p  1
    pool_choice_6[34]  R1635     -1
    pool_choice_6[34]  R1637     -1
    pool_choice_6[35]  OBJ       6.3709853449601354e+01
    pool_choice_6[35]  R1053     1
    pool_choice_6[35]  R1054     -60
    pool_choice_6[35]  R1065     -1
    pool_choice_6[35]  R1076     -1
    pool_choice_6[35]  R1094     -1
    pool_choice_6[35]  pool_cover_C81_order_d  1
    pool_choice_6[35]  pool_cover_C90_order_d  1
    pool_choice_6[35]  pool_cover_C97_order_d  1
    pool_choice_6[35]  R1638     -1
    pool_choice_6[35]  R1639     -1
    pool_choice_6[35]  R1781     -60
    pool_choice_6[35]  R1785     -60
    pool_choice_6[36]  OBJ       3.5116342351967482e+01
    pool_choice_6[36]  R1053     1
    pool_choice_6[36]  R1054     -60
    pool_choice_6[36]  R1061     -1
    pool_choice_6[36]  R1071     -1
    pool_choice_6[36]  R1087     -1
    pool_choice_6[36]  R1089     -1
    pool_choice_6[36]  R1091     -1
    pool_choice_6[36]  R1094     -1
    pool_choice_6[36]  pool_cover_C90_order_d  1
    pool_choice_6[36]  pool_cover_C90_order_p  1
    pool_choice_6[36]  pool_cover_C0_order_p  1
    pool_choice_6[36]  pool_cover_C85_order_p  1
    pool_choice_6[36]  R1620     -1
    pool_choice_6[36]  R1635     -1
    pool_choice_6[36]  R1637     -1
    pool_choice_6[36]  R1781     -60
    pool_choice_6[36]  R1785     -60
    pool_choice_6[37]  OBJ       6.6013282617951688e+01
    pool_choice_6[37]  R1053     1
    pool_choice_6[37]  R1054     -60
    pool_choice_6[37]  R1060     -1
    pool_choice_6[37]  R1082     -1
    pool_choice_6[37]  R1093     -1
    pool_choice_6[37]  pool_cover_C39_order_d  1
    pool_choice_6[37]  pool_cover_C52_order_d  1
    pool_choice_6[37]  R1640     -1
    pool_choice_6[37]  R1781     -60
    pool_choice_6[37]  R1785     -60
    pool_choice_6[38]  OBJ       3.6722124674044828e+01
    pool_choice_6[38]  R1053     1
    pool_choice_6[38]  R1054     -60
    pool_choice_6[38]  R1063     -1
    pool_choice_6[38]  R1074     -1
    pool_choice_6[38]  R1089     -1
    pool_choice_6[38]  R1090     -1
    pool_choice_6[38]  R1093     -1
    pool_choice_6[38]  pool_cover_C0_order_d  1
    pool_choice_6[38]  pool_cover_C0_order_p  1
    pool_choice_6[38]  pool_cover_C75_order_p  1
    pool_choice_6[38]  R1621     -1
    pool_choice_6[38]  R1632     -1
    pool_choice_6[38]  R1781     -60
    pool_choice_6[38]  R1785     -60
    pool_choice_6[39]  OBJ       5.6938022874619705e+01
    pool_choice_6[39]  R1053     1
    pool_choice_6[39]  R1054     -60
    pool_choice_6[39]  R1066     -1
    pool_choice_6[39]  R1083     -1
    pool_choice_6[39]  R1095     -1
    pool_choice_6[39]  pool_cover_C85_order_d  1
    pool_choice_6[39]  pool_cover_C21_order_d  1
    pool_choice_6[39]  R1641     -1
    pool_choice_6[39]  R1781     -60
    pool_choice_6[39]  R1785     -60
    pool_choice_6[40]  OBJ       3.7837287915293039e+01
    pool_choice_6[40]  R1053     1
    pool_choice_6[40]  R1054     -60
    pool_choice_6[40]  R1069     -1
    pool_choice_6[40]  R1071     -1
    pool_choice_6[40]  R1087     -1
    pool_choice_6[40]  R1090     -1
    pool_choice_6[40]  R1095     -1
    pool_choice_6[40]  pool_cover_C85_order_p  1
    pool_choice_6[40]  pool_cover_C75_order_d  1
    pool_choice_6[40]  pool_cover_C75_order_p  1
    pool_choice_6[40]  R1622     -1
    pool_choice_6[40]  R1633     -1
    pool_choice_6[40]  R1781     -60
    pool_choice_6[40]  R1785     -60
    pool_choice_6[41]  OBJ       3.6291544140059209e+01
    pool_choice_6[41]  R1053     1
    pool_choice_6[41]  R1068     -1
    pool_choice_6[41]  R1071     -1
    pool_choice_6[41]  R1087     -1
    pool_choice_6[41]  R1091     -1
    pool_choice_6[41]  R1092     -1
    pool_choice_6[41]  pool_cover_C81_order_p  1
    pool_choice_6[41]  pool_cover_C90_order_p  1
    pool_choice_6[41]  pool_cover_C85_order_p  1
    pool_choice_6[41]  R1629     -1
    pool_choice_6[41]  R1642     -1
    pool_choice_6[42]  OBJ       6.6004157126226886e+01
    pool_choice_6[42]  R1053     1
    pool_choice_6[42]  R1054     -60
    pool_choice_6[42]  R1065     -1
    pool_choice_6[42]  R1084     -1
    pool_choice_6[42]  R1094     -1
    pool_choice_6[42]  pool_cover_C81_order_d  1
    pool_choice_6[42]  pool_cover_C97_order_d  1
    pool_choice_6[42]  pool_cover_C51_order_d  1
    pool_choice_6[42]  R1638     -1
    pool_choice_6[42]  R1643     -1
    pool_choice_6[42]  R1781     -60
    pool_choice_6[42]  R1785     -60
    pool_choice_6[43]  OBJ       3.6291544140059209e+01
    pool_choice_6[43]  R1053     1
    pool_choice_6[43]  R1054     -60
    pool_choice_6[43]  R1061     -1
    pool_choice_6[43]  R1071     -1
    pool_choice_6[43]  R1087     -1
    pool_choice_6[43]  R1092     -1
    pool_choice_6[43]  R1094     -1
    pool_choice_6[43]  pool_cover_C81_order_d  1
    pool_choice_6[43]  pool_cover_C81_order_p  1
    pool_choice_6[43]  pool_cover_C90_order_d  1
    pool_choice_6[43]  pool_cover_C85_order_p  1
    pool_choice_6[43]  R1619     -1
    pool_choice_6[43]  R1629     -1
    pool_choice_6[43]  R1644     -1
    pool_choice_6[43]  R1781     -60
    pool_choice_6[43]  R1785     -60
    pool_choice_6[44]  OBJ       71.9286437576317
    pool_choice_6[44]  R1053     1
    pool_choice_6[44]  R1054     -60
    pool_choice_6[44]  R1063     -1
    pool_choice_6[44]  R1077     -1
    pool_choice_6[44]  R1093     -1
    pool_choice_6[44]  pool_cover_C0_order_d  1
    pool_choice_6[44]  pool_cover_C39_order_d  1
    pool_choice_6[44]  R1645     -1
    pool_choice_6[44]  R1781     -60
    pool_choice_6[44]  R1785     -60
    pool_choice_6[45]  OBJ       4.0324927052090487e+01
    pool_choice_6[45]  R1053     1
    pool_choice_6[45]  R1054     -60
    pool_choice_6[45]  R1063     -1
    pool_choice_6[45]  R1071     -1
    pool_choice_6[45]  R1087     -1
    pool_choice_6[45]  R1090     -1
    pool_choice_6[45]  R1093     -1
    pool_choice_6[45]  pool_cover_C0_order_d  1
    pool_choice_6[45]  pool_cover_C85_order_p  1
    pool_choice_6[45]  pool_cover_C75_order_p  1
    pool_choice_6[45]  R1633     -1
    pool_choice_6[45]  R1646     -1
    pool_choice_6[45]  R1781     -60
    pool_choice_6[45]  R1785     -60
    pool_choice_6[46]  OBJ       3.4234485537247380e+01
    pool_choice_6[46]  R1053     1
    pool_choice_6[46]  R1054     -60
    pool_choice_6[46]  R1069     -1
    pool_choice_6[46]  R1081     -1
    pool_choice_6[46]  R1095     -1
    pool_choice_6[46]  pool_cover_C75_order_d  1
    pool_choice_6[46]  R1781     -60
    pool_choice_6[46]  R1785     -60
    pool_choice_6[47]  OBJ       3.7837287915293039e+01
    pool_choice_6[47]  R1053     1
    pool_choice_6[47]  R1054     -60
    pool_choice_6[47]  R1066     -1
    pool_choice_6[47]  R1074     -1
    pool_choice_6[47]  R1090     -1
    pool_choice_6[47]  R1095     -1
    pool_choice_6[47]  pool_cover_C85_order_d  1
    pool_choice_6[47]  pool_cover_C75_order_d  1
    pool_choice_6[47]  pool_cover_C75_order_p  1
    pool_choice_6[47]  R1622     -1
    pool_choice_6[47]  R1636     -1
    pool_choice_6[47]  R1781     -60
    pool_choice_6[47]  R1785     -60
    pool_choice_6[48]  OBJ       3.8672424697217842e+01
    pool_choice_6[48]  R1053     1
    pool_choice_6[48]  R1068     -1
    pool_choice_6[48]  R1074     -1
    pool_choice_6[48]  R1089     -1
    pool_choice_6[48]  R1090     -1
    pool_choice_6[48]  R1091     -1
    pool_choice_6[48]  pool_cover_C90_order_p  1
    pool_choice_6[48]  pool_cover_C0_order_p  1
    pool_choice_6[48]  pool_cover_C75_order_p  1
    pool_choice_6[48]  R1632     -1
    pool_choice_6[48]  R1637     -1
    pool_choice_6[49]  OBJ       2.4166091947189145e+01
    pool_choice_6[49]  R1053     1
    pool_choice_6[49]  R1054     -60
    pool_choice_6[49]  R1061     -1
    pool_choice_6[49]  R1076     -1
    pool_choice_6[49]  R1094     -1
    pool_choice_6[49]  pool_cover_C90_order_d  1
    pool_choice_6[49]  R1781     -60
    pool_choice_6[49]  R1785     -60
    pool_choice_6[50]  OBJ       3.6291544140059209e+01
    pool_choice_6[50]  R1053     1
    pool_choice_6[50]  R1054     -60
    pool_choice_6[50]  R1061     -1
    pool_choice_6[50]  R1071     -1
    pool_choice_6[50]  R1087     -1
    pool_choice_6[50]  R1091     -1
    pool_choice_6[50]  R1092     -1
    pool_choice_6[50]  R1094     -1
    pool_choice_6[50]  pool_cover_C81_order_p  1
    pool_choice_6[50]  pool_cover_C90_order_d  1
    pool_choice_6[50]  pool_cover_C90_order_p  1
    pool_choice_6[50]  pool_cover_C85_order_p  1
    pool_choice_6[50]  R1620     -1
    pool_choice_6[50]  R1629     -1
    pool_choice_6[50]  R1642     -1
    pool_choice_6[50]  R1781     -60
    pool_choice_6[50]  R1785     -60
    pool_choice_6[51]  OBJ       8.0409665286968448e+01
    pool_choice_6[51]  R1053     1
    pool_choice_6[51]  R1054     -60
    pool_choice_6[51]  R1063     -1
    pool_choice_6[51]  R1082     -1
    pool_choice_6[51]  R1093     -1
    pool_choice_6[51]  pool_cover_C0_order_d  1
    pool_choice_6[51]  pool_cover_C52_order_d  1
    pool_choice_6[51]  R1630     -1
    pool_choice_6[51]  R1781     -60
    pool_choice_6[51]  R1785     -60
    pool_used_6  R1053     -1
    pool_used_6  R1054     -28800
    pool_used_6  R1055     -75600
    pool_used_6  R1056     -75540
    pool_used_6  R1057     -1
    pool_used_6  R1058     -80
    pool_used_6  R1059     -80
    pool_used_6  R1781     -75660
    pool_used_6  R1782     -81
    pool_used_6  R1785     -75660
    pool_used_6  R1786     -81
    pool_used_6  R1789     -75660
    pool_used_6  R1790     -81
    pool_start_6  R1054     1
    pool_start_6  R1055     1
    pool_start_6  R1781     1
    pool_start_6  R1785     1
    pool_start_6  GC567     -1
    pool_start_6  GC569     -1
    pool_start_6  GC571     -1
    pool_start_6  GC573     -1
    pool_start_6  GC575     -1
    pool_start_6  GC577     -1
    pool_start_6  GC579     -1
    pool_start_6  GC581     -1
    pool_start_6  GC583     -1
    pool_start_6  GC585     -1
    pool_start_6  GC625     1
    pool_start_6  GC626     1
    pool_start_6  GC627     1
    pool_end_6  R1056     1
    pool_end_6  R1789     -1
    pool_end_6  GC587     1
    pool_end_6  GC589     1
    pool_end_6  GC591     1
    pool_end_6  GC593     1
    pool_end_6  GC595     1
    pool_end_6  GC597     1
    pool_end_6  GC599     1
    pool_end_6  GC601     1
    pool_end_6  GC603     1
    pool_end_6  GC605     1
    pool_end_6  GC607     1
    pool_end_6  GC609     1
    pool_end_6  GC611     1
    pool_end_6  GC613     1
    pool_end_6  GC615     1
    pool_end_6  GC617     -1
    pool_end_6  GC618     -1
    pool_end_6  GC619     -1
    pool_end_6  GC620     -1
    pool_end_6  GC621     -1
    pool_end_6  GC622     -1
    pool_end_6  GC623     -1
    pool_end_6  GC624     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_6  R1057     1
    pool_start_rank_6  R1058     1
    pool_start_rank_6  R1782     1
    pool_start_rank_6  R1786     1
    pool_start_rank_6  GC568     -1
    pool_start_rank_6  GC570     -1
    pool_start_rank_6  GC572     -1
    pool_start_rank_6  GC574     -1
    pool_start_rank_6  GC576     -1
    pool_start_rank_6  GC578     -1
    pool_start_rank_6  GC580     -1
    pool_start_rank_6  GC582     -1
    pool_start_rank_6  GC584     -1
    pool_start_rank_6  GC586     -1
    pool_end_rank_6  R1059     1
    pool_end_rank_6  R1790     -1
    pool_end_rank_6  GC588     1
    pool_end_rank_6  GC590     1
    pool_end_rank_6  GC592     1
    pool_end_rank_6  GC594     1
    pool_end_rank_6  GC596     1
    pool_end_rank_6  GC598     1
    pool_end_rank_6  GC600     1
    pool_end_rank_6  GC602     1
    pool_end_rank_6  GC604     1
    pool_end_rank_6  GC606     1
    pool_end_rank_6  GC608     1
    pool_end_rank_6  GC610     1
    pool_end_rank_6  GC612     1
    pool_end_rank_6  GC614     1
    pool_end_rank_6  GC616     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_6_C39_order_d  R1060     1
    pool_first_6_C90_order_d  R1061     1
    pool_first_6_C52_order_d  R1062     1
    pool_first_6_C0_order_d  R1063     1
    pool_first_6_C85_order_p  R1064     1
    pool_first_6_C81_order_d  R1065     1
    pool_first_6_C85_order_d  R1066     1
    pool_first_6_C81_order_p  R1067     1
    pool_first_6_C90_order_p  R1068     1
    pool_first_6_C75_order_d  R1069     1
    pool_last_6_C39_order_p  R1070     1
    pool_last_6_C85_order_p  R1071     1
    pool_last_6_C21_order_p  R1072     1
    pool_last_6_C0_order_p  R1073     1
    pool_last_6_C75_order_p  R1074     1
    pool_last_6_C52_order_p  R1075     1
    pool_last_6_C90_order_d  R1076     1
    pool_last_6_C39_order_d  R1077     1
    pool_last_6_C85_order_d  R1078     1
    pool_last_6_C81_order_d  R1079     1
    pool_last_6_C0_order_d  R1080     1
    pool_last_6_C75_order_d  R1081     1
    pool_last_6_C52_order_d  R1082     1
    pool_last_6_C21_order_d  R1083     1
    pool_last_6_C51_order_d  R1084     1
    pool_pickup_6_C52_order  R1085     1
    pool_pickup_6_C39_order  R1086     1
    pool_pickup_6_C85_order  R1087     1
    pool_pickup_6_C21_order  R1088     1
    pool_pickup_6_C0_order  R1089     1
    pool_pickup_6_C75_order  R1090     1
    pool_pickup_6_C90_order  R1091     1
    pool_pickup_6_C81_order  R1092     1
    pool_batch_6_b2  R1093     1
    pool_batch_6_b1  R1094     1
    pool_batch_6_b3  R1095     1
    pool_choice_7[0]  OBJ       3.4234485537247380e+01
    pool_choice_7[0]  R1096     1
    pool_choice_7[0]  R1097     -60
    pool_choice_7[0]  R1103     -1
    pool_choice_7[0]  R1115     -1
    pool_choice_7[0]  R1129     -1
    pool_choice_7[0]  R1136     -1
    pool_choice_7[0]  pool_cover_C75_order_d  1
    pool_choice_7[0]  pool_cover_C75_order_p  1
    pool_choice_7[0]  R1622     -1
    pool_choice_7[0]  R1783     -60
    pool_choice_7[0]  R1787     -60
    pool_choice_7[0]  R1789     -60
    pool_choice_7[1]  OBJ       6
    pool_choice_7[1]  R1096     1
    pool_choice_7[1]  R1097     -60
    pool_choice_7[1]  R1104     -1
    pool_choice_7[1]  R1116     -1
    pool_choice_7[1]  R1130     -1
    pool_choice_7[1]  R1136     -1
    pool_choice_7[1]  pool_cover_C85_order_d  1
    pool_choice_7[1]  pool_cover_C85_order_p  1
    pool_choice_7[1]  R1618     -1
    pool_choice_7[1]  R1783     -60
    pool_choice_7[1]  R1787     -60
    pool_choice_7[1]  R1789     -60
    pool_choice_7[2]  OBJ       41.4400902933387
    pool_choice_7[2]  R1096     1
    pool_choice_7[2]  R1097     -60
    pool_choice_7[2]  R1104     -1
    pool_choice_7[2]  R1116     -1
    pool_choice_7[2]  R1129     -1
    pool_choice_7[2]  R1130     -1
    pool_choice_7[2]  R1136     -1
    pool_choice_7[2]  pool_cover_C85_order_d  1
    pool_choice_7[2]  pool_cover_C85_order_p  1
    pool_choice_7[2]  pool_cover_C75_order_d  1
    pool_choice_7[2]  pool_cover_C75_order_p  1
    pool_choice_7[2]  R1622     -1
    pool_choice_7[2]  R1633     -1
    pool_choice_7[2]  R1636     -1
    pool_choice_7[2]  R1783     -60
    pool_choice_7[2]  R1787     -60
    pool_choice_7[2]  R1789     -60
    pool_choice_7[3]  OBJ       2.4166091947189145e+01
    pool_choice_7[3]  R1096     1
    pool_choice_7[3]  R1097     -60
    pool_choice_7[3]  R1105     -1
    pool_choice_7[3]  R1117     -1
    pool_choice_7[3]  R1131     -1
    pool_choice_7[3]  R1137     -1
    pool_choice_7[3]  pool_cover_C90_order_d  1
    pool_choice_7[3]  pool_cover_C90_order_p  1
    pool_choice_7[3]  R1620     -1
    pool_choice_7[3]  R1783     -60
    pool_choice_7[3]  R1787     -60
    pool_choice_7[3]  R1789     -60
    pool_choice_7[4]  OBJ       3.7837287915293039e+01
    pool_choice_7[4]  R1096     1
    pool_choice_7[4]  R1097     -60
    pool_choice_7[4]  R1103     -1
    pool_choice_7[4]  R1116     -1
    pool_choice_7[4]  R1129     -1
    pool_choice_7[4]  R1130     -1
    pool_choice_7[4]  R1136     -1
    pool_choice_7[4]  pool_cover_C85_order_p  1
    pool_choice_7[4]  pool_cover_C75_order_d  1
    pool_choice_7[4]  pool_cover_C75_order_p  1
    pool_choice_7[4]  R1622     -1
    pool_choice_7[4]  R1633     -1
    pool_choice_7[4]  R1783     -60
    pool_choice_7[4]  R1787     -60
    pool_choice_7[4]  R1789     -60
    pool_choice_7[5]  OBJ       3.7837287915293039e+01
    pool_choice_7[5]  R1096     1
    pool_choice_7[5]  R1097     -60
    pool_choice_7[5]  R1104     -1
    pool_choice_7[5]  R1115     -1
    pool_choice_7[5]  R1129     -1
    pool_choice_7[5]  R1136     -1
    pool_choice_7[5]  pool_cover_C85_order_d  1
    pool_choice_7[5]  pool_cover_C75_order_d  1
    pool_choice_7[5]  pool_cover_C75_order_p  1
    pool_choice_7[5]  R1622     -1
    pool_choice_7[5]  R1636     -1
    pool_choice_7[5]  R1783     -60
    pool_choice_7[5]  R1787     -60
    pool_choice_7[5]  R1789     -60
    pool_choice_7[6]  OBJ       3.0265491900843113e+01
    pool_choice_7[6]  R1096     1
    pool_choice_7[6]  R1097     -60
    pool_choice_7[6]  R1106     -1
    pool_choice_7[6]  R1118     -1
    pool_choice_7[6]  R1132     -1
    pool_choice_7[6]  R1138     -1
    pool_choice_7[6]  pool_cover_C0_order_d  1
    pool_choice_7[6]  pool_cover_C0_order_p  1
    pool_choice_7[6]  R1621     -1
    pool_choice_7[6]  R1783     -60
    pool_choice_7[6]  R1787     -60
    pool_choice_7[6]  R1789     -60
    pool_choice_7[7]  OBJ       7.3277378208631745e+01
    pool_choice_7[7]  R1096     1
    pool_choice_7[7]  R1097     -60
    pool_choice_7[7]  R1104     -1
    pool_choice_7[7]  R1115     -1
    pool_choice_7[7]  R1129     -1
    pool_choice_7[7]  R1130     -1
    pool_choice_7[7]  R1136     -1
    pool_choice_7[7]  pool_cover_C85_order_d  1
    pool_choice_7[7]  pool_cover_C85_order_p  1
    pool_choice_7[7]  pool_cover_C75_order_d  1
    pool_choice_7[7]  pool_cover_C75_order_p  1
    pool_choice_7[7]  R1636     -1
    pool_choice_7[7]  R1650     -1
    pool_choice_7[7]  R1700     -1
    pool_choice_7[7]  R1783     -60
    pool_choice_7[7]  R1787     -60
    pool_choice_7[7]  R1789     -60
    pool_choice_7[8]  OBJ       3.7837287915293039e+01
    pool_choice_7[8]  R1096     1
    pool_choice_7[8]  R1097     -60
    pool_choice_7[8]  R1103     -1
    pool_choice_7[8]  R1116     -1
    pool_choice_7[8]  R1130     -1
    pool_choice_7[8]  R1136     -1
    pool_choice_7[8]  pool_cover_C85_order_p  1
    pool_choice_7[8]  pool_cover_C75_order_d  1
    pool_choice_7[8]  R1700     -1
    pool_choice_7[8]  R1783     -60
    pool_choice_7[8]  R1787     -60
    pool_choice_7[8]  R1789     -60
    pool_choice_7[9]  OBJ       3.7837287915293039e+01
    pool_choice_7[9]  R1096     1
    pool_choice_7[9]  R1097     -60
    pool_choice_7[9]  R1104     -1
    pool_choice_7[9]  R1115     -1
    pool_choice_7[9]  R1129     -1
    pool_choice_7[9]  R1136     -1
    pool_choice_7[9]  pool_cover_C85_order_d  1
    pool_choice_7[9]  pool_cover_C75_order_p  1
    pool_choice_7[9]  R1685     -1
    pool_choice_7[9]  R1783     -60
    pool_choice_7[9]  R1787     -60
    pool_choice_7[9]  R1789     -60
    pool_choice_7[10]  OBJ       6.9674575830586079e+01
    pool_choice_7[10]  R1096     1
    pool_choice_7[10]  R1097     -60
    pool_choice_7[10]  R1103     -1
    pool_choice_7[10]  R1115     -1
    pool_choice_7[10]  R1129     -1
    pool_choice_7[10]  R1130     -1
    pool_choice_7[10]  R1136     -1
    pool_choice_7[10]  pool_cover_C85_order_p  1
    pool_choice_7[10]  pool_cover_C75_order_d  1
    pool_choice_7[10]  pool_cover_C75_order_p  1
    pool_choice_7[10]  R1650     -1
    pool_choice_7[10]  R1700     -1
    pool_choice_7[10]  R1783     -60
    pool_choice_7[10]  R1787     -60
    pool_choice_7[10]  R1789     -60
    pool_choice_7[11]  OBJ       9.8856463222861436e+01
    pool_choice_7[11]  R1096     1
    pool_choice_7[11]  R1097     -60
    pool_choice_7[11]  R1103     -1
    pool_choice_7[11]  R1115     -1
    pool_choice_7[11]  R1129     -1
    pool_choice_7[11]  R1133     -1
    pool_choice_7[11]  R1136     -1
    pool_choice_7[11]  pool_cover_C75_order_d  1
    pool_choice_7[11]  pool_cover_C75_order_p  1
    pool_choice_7[11]  pool_cover_C21_order_d  1
    pool_choice_7[11]  pool_cover_C21_order_p  1
    pool_choice_7[11]  R1625     -1
    pool_choice_7[11]  R1680     -1
    pool_choice_7[11]  R1682     -1
    pool_choice_7[11]  R1783     -60
    pool_choice_7[11]  R1787     -60
    pool_choice_7[11]  R1789     -60
    pool_choice_7[12]  OBJ       7.7871156918086484e+01
    pool_choice_7[12]  R1096     1
    pool_choice_7[12]  R1097     -60
    pool_choice_7[12]  R1107     -1
    pool_choice_7[12]  R1115     -1
    pool_choice_7[12]  R1129     -1
    pool_choice_7[12]  R1136     -1
    pool_choice_7[12]  pool_cover_C75_order_d  1
    pool_choice_7[12]  pool_cover_C75_order_p  1
    pool_choice_7[12]  pool_cover_C21_order_d  1
    pool_choice_7[12]  R1622     -1
    pool_choice_7[12]  R1649     -1
    pool_choice_7[12]  R1783     -60
    pool_choice_7[12]  R1787     -60
    pool_choice_7[12]  R1789     -60
    pool_choice_7[13]  OBJ       77.8711569180865
    pool_choice_7[13]  R1096     1
    pool_choice_7[13]  R1097     -60
    pool_choice_7[13]  R1103     -1
    pool_choice_7[13]  R1119     -1
    pool_choice_7[13]  R1129     -1
    pool_choice_7[13]  R1133     -1
    pool_choice_7[13]  R1136     -1
    pool_choice_7[13]  pool_cover_C75_order_d  1
    pool_choice_7[13]  pool_cover_C75_order_p  1
    pool_choice_7[13]  pool_cover_C21_order_p  1
    pool_choice_7[13]  R1622     -1
    pool_choice_7[13]  R1681     -1
    pool_choice_7[13]  R1783     -60
    pool_choice_7[13]  R1787     -60
    pool_choice_7[13]  R1789     -60
    pool_choice_7[14]  OBJ       5.6885850613311568e+01
    pool_choice_7[14]  R1096     1
    pool_choice_7[14]  R1097     -60
    pool_choice_7[14]  R1107     -1
    pool_choice_7[14]  R1119     -1
    pool_choice_7[14]  R1133     -1
    pool_choice_7[14]  R1136     -1
    pool_choice_7[14]  pool_cover_C21_order_d  1
    pool_choice_7[14]  pool_cover_C21_order_p  1
    pool_choice_7[14]  R1625     -1
    pool_choice_7[14]  R1783     -60
    pool_choice_7[14]  R1787     -60
    pool_choice_7[14]  R1789     -60
    pool_choice_7[15]  OBJ       5.6938022874619705e+01
    pool_choice_7[15]  R1096     1
    pool_choice_7[15]  R1097     -60
    pool_choice_7[15]  R1104     -1
    pool_choice_7[15]  R1120     -1
    pool_choice_7[15]  R1136     -1
    pool_choice_7[15]  pool_cover_C85_order_d  1
    pool_choice_7[15]  pool_cover_C21_order_d  1
    pool_choice_7[15]  R1641     -1
    pool_choice_7[15]  R1783     -60
    pool_choice_7[15]  R1787     -60
    pool_choice_7[15]  R1789     -60
    pool_choice_7[16]  OBJ       9.8856463222861436e+01
    pool_choice_7[16]  R1096     1
    pool_choice_7[16]  R1097     -60
    pool_choice_7[16]  R1103     -1
    pool_choice_7[16]  R1115     -1
    pool_choice_7[16]  R1129     -1
    pool_choice_7[16]  R1136     -1
    pool_choice_7[16]  pool_cover_C75_order_d  1
    pool_choice_7[16]  pool_cover_C75_order_p  1
    pool_choice_7[16]  pool_cover_C21_order_d  1
    pool_choice_7[16]  R1680     -1
    pool_choice_7[16]  R1683     -1
    pool_choice_7[16]  R1783     -60
    pool_choice_7[16]  R1787     -60
    pool_choice_7[16]  R1789     -60
    pool_choice_7[17]  OBJ       9.8856463222861436e+01
    pool_choice_7[17]  R1096     1
    pool_choice_7[17]  R1097     -60
    pool_choice_7[17]  R1103     -1
    pool_choice_7[17]  R1115     -1
    pool_choice_7[17]  R1129     -1
    pool_choice_7[17]  R1133     -1
    pool_choice_7[17]  R1136     -1
    pool_choice_7[17]  pool_cover_C75_order_d  1
    pool_choice_7[17]  pool_cover_C75_order_p  1
    pool_choice_7[17]  pool_cover_C21_order_p  1
    pool_choice_7[17]  R1682     -1
    pool_choice_7[17]  R1684     -1
    pool_choice_7[17]  R1783     -60
    pool_choice_7[17]  R1787     -60
    pool_choice_7[17]  R1789     -60
    pool_choice_7[18]  OBJ       3.4234485537247380e+01
    pool_choice_7[18]  R1096     1
    pool_choice_7[18]  R1097     -60
    pool_choice_7[18]  R1103     -1
    pool_choice_7[18]  R1121     -1
    pool_choice_7[18]  R1136     -1
    pool_choice_7[18]  pool_cover_C75_order_d  1
    pool_choice_7[18]  R1783     -60
    pool_choice_7[18]  R1787     -60
    pool_choice_7[18]  R1789     -60
    pool_choice_7[19]  OBJ       3.4234485537247380e+01
    pool_choice_7[19]  R1096     1
    pool_choice_7[19]  R1108     -1
    pool_choice_7[19]  R1115     -1
    pool_choice_7[19]  R1129     -1
    pool_choice_7[19]  pool_cover_C75_order_p  1
    pool_choice_7[20]  OBJ       1.4249313460370053e+02
    pool_choice_7[20]  R1096     1
    pool_choice_7[20]  R1097     -60
    pool_choice_7[20]  R1107     -1
    pool_choice_7[20]  R1115     -1
    pool_choice_7[20]  R1129     -1
    pool_choice_7[20]  R1133     -1
    pool_choice_7[20]  R1136     -1
    pool_choice_7[20]  pool_cover_C75_order_d  1
    pool_choice_7[20]  pool_cover_C75_order_p  1
    pool_choice_7[20]  pool_cover_C21_order_d  1
    pool_choice_7[20]  pool_cover_C21_order_p  1
    pool_choice_7[20]  R1649     -1
    pool_choice_7[20]  R1682     -1
    pool_choice_7[20]  R1684     -1
    pool_choice_7[20]  R1783     -60
    pool_choice_7[20]  R1787     -60
    pool_choice_7[20]  R1789     -60
    pool_choice_7[21]  OBJ       7.7871156918086484e+01
    pool_choice_7[21]  R1096     1
    pool_choice_7[21]  R1097     -60
    pool_choice_7[21]  R1107     -1
    pool_choice_7[21]  R1115     -1
    pool_choice_7[21]  R1129     -1
    pool_choice_7[21]  R1136     -1
    pool_choice_7[21]  pool_cover_C75_order_p  1
    pool_choice_7[21]  pool_cover_C21_order_d  1
    pool_choice_7[21]  R1683     -1
    pool_choice_7[21]  R1783     -60
    pool_choice_7[21]  R1787     -60
    pool_choice_7[21]  R1789     -60
    pool_choice_7[22]  OBJ       77.8711569180865
    pool_choice_7[22]  R1096     1
    pool_choice_7[22]  R1097     -60
    pool_choice_7[22]  R1103     -1
    pool_choice_7[22]  R1120     -1
    pool_choice_7[22]  R1136     -1
    pool_choice_7[22]  pool_cover_C75_order_d  1
    pool_choice_7[22]  pool_cover_C21_order_d  1
    pool_choice_7[22]  R1680     -1
    pool_choice_7[22]  R1783     -60
    pool_choice_7[22]  R1787     -60
    pool_choice_7[22]  R1789     -60
    pool_choice_7[23]  OBJ       77.8711569180865
    pool_choice_7[23]  R1096     1
    pool_choice_7[23]  R1097     -60
    pool_choice_7[23]  R1103     -1
    pool_choice_7[23]  R1119     -1
    pool_choice_7[23]  R1133     -1
    pool_choice_7[23]  R1136     -1
    pool_choice_7[23]  pool_cover_C75_order_d  1
    pool_choice_7[23]  pool_cover_C21_order_p  1
    pool_choice_7[23]  R1684     -1
    pool_choice_7[23]  R1783     -60
    pool_choice_7[23]  R1787     -60
    pool_choice_7[23]  R1789     -60
    pool_choice_7[24]  OBJ       6
    pool_choice_7[24]  R1096     1
    pool_choice_7[24]  R1109     -1
    pool_choice_7[24]  R1116     -1
    pool_choice_7[24]  R1130     -1
    pool_choice_7[24]  pool_cover_C85_order_p  1
    pool_choice_7[25]  OBJ       3.6209473277964264e+01
    pool_choice_7[25]  R1096     1
    pool_choice_7[25]  R1097     -60
    pool_choice_7[25]  R1110     -1
    pool_choice_7[25]  R1122     -1
    pool_choice_7[25]  R1137     -1
    pool_choice_7[25]  pool_cover_C81_order_d  1
    pool_choice_7[25]  pool_cover_C90_order_d  1
    pool_choice_7[25]  R1628     -1
    pool_choice_7[25]  R1783     -60
    pool_choice_7[25]  R1787     -60
    pool_choice_7[25]  R1789     -60
    pool_choice_7[26]  OBJ       2.0478148916466086e+01
    pool_choice_7[26]  R1096     1
    pool_choice_7[26]  R1097     -60
    pool_choice_7[26]  R1110     -1
    pool_choice_7[26]  R1116     -1
    pool_choice_7[26]  R1130     -1
    pool_choice_7[26]  R1134     -1
    pool_choice_7[26]  R1137     -1
    pool_choice_7[26]  pool_cover_C81_order_d  1
    pool_choice_7[26]  pool_cover_C81_order_p  1
    pool_choice_7[26]  pool_cover_C85_order_p  1
    pool_choice_7[26]  R1619     -1
    pool_choice_7[26]  R1629     -1
    pool_choice_7[26]  R1783     -60
    pool_choice_7[26]  R1787     -60
    pool_choice_7[26]  R1789     -60
    pool_choice_7[27]  OBJ       8.4133301895330391e+01
    pool_choice_7[27]  R1096     1
    pool_choice_7[27]  R1097     -60
    pool_choice_7[27]  R1106     -1
    pool_choice_7[27]  R1123     -1
    pool_choice_7[27]  R1138     -1
    pool_choice_7[27]  pool_cover_C0_order_d  1
    pool_choice_7[27]  pool_cover_C39_order_d  1
    pool_choice_7[27]  pool_cover_C52_order_d  1
    pool_choice_7[27]  R1630     -1
    pool_choice_7[27]  R1631     -1
    pool_choice_7[27]  R1783     -60
    pool_choice_7[27]  R1787     -60
    pool_choice_7[27]  R1789     -60
    pool_choice_7[28]  OBJ       4.0324927052090487e+01
    pool_choice_7[28]  R1096     1
    pool_choice_7[28]  R1097     -60
    pool_choice_7[28]  R1106     -1
    pool_choice_7[28]  R1116     -1
    pool_choice_7[28]  R1129     -1
    pool_choice_7[28]  R1130     -1
    pool_choice_7[28]  R1132     -1
    pool_choice_7[28]  R1138     -1
    pool_choice_7[28]  pool_cover_C0_order_d  1
    pool_choice_7[28]  pool_cover_C0_order_p  1
    pool_choice_7[28]  pool_cover_C85_order_p  1
    pool_choice_7[28]  pool_cover_C75_order_p  1
    pool_choice_7[28]  R1621     -1
    pool_choice_7[28]  R1632     -1
    pool_choice_7[28]  R1633     -1
    pool_choice_7[28]  R1783     -60
    pool_choice_7[28]  R1787     -60
    pool_choice_7[28]  R1789     -60
    pool_choice_7[29]  OBJ       6
    pool_choice_7[29]  R1096     1
    pool_choice_7[29]  R1097     -60
    pool_choice_7[29]  R1104     -1
    pool_choice_7[29]  R1124     -1
    pool_choice_7[29]  R1136     -1
    pool_choice_7[29]  pool_cover_C85_order_d  1
    pool_choice_7[29]  R1783     -60
    pool_choice_7[29]  R1787     -60
    pool_choice_7[29]  R1789     -60
    pool_choice_7[30]  OBJ       2.0478148916466086e+01
    pool_choice_7[30]  R1096     1
    pool_choice_7[30]  R1111     -1
    pool_choice_7[30]  R1116     -1
    pool_choice_7[30]  R1130     -1
    pool_choice_7[30]  R1134     -1
    pool_choice_7[30]  pool_cover_C81_order_p  1
    pool_choice_7[30]  pool_cover_C85_order_p  1
    pool_choice_7[30]  R1629     -1
    pool_choice_7[31]  OBJ       2.0396078054371138e+01
    pool_choice_7[31]  R1096     1
    pool_choice_7[31]  R1097     -60
    pool_choice_7[31]  R1110     -1
    pool_choice_7[31]  R1125     -1
    pool_choice_7[31]  R1137     -1
    pool_choice_7[31]  pool_cover_C81_order_d  1
    pool_choice_7[31]  R1783     -60
    pool_choice_7[31]  R1787     -60
    pool_choice_7[31]  R1789     -60
    pool_choice_7[32]  OBJ       2.6263385861093521e+01
    pool_choice_7[32]  R1096     1
    pool_choice_7[32]  R1097     -60
    pool_choice_7[32]  R1105     -1
    pool_choice_7[32]  R1116     -1
    pool_choice_7[32]  R1130     -1
    pool_choice_7[32]  R1131     -1
    pool_choice_7[32]  R1137     -1
    pool_choice_7[32]  pool_cover_C90_order_d  1
    pool_choice_7[32]  pool_cover_C90_order_p  1
    pool_choice_7[32]  pool_cover_C85_order_p  1
    pool_choice_7[32]  R1620     -1
    pool_choice_7[32]  R1634     -1
    pool_choice_7[32]  R1783     -60
    pool_choice_7[32]  R1787     -60
    pool_choice_7[32]  R1789     -60
    pool_choice_7[33]  OBJ       3.0265491900843113e+01
    pool_choice_7[33]  R1096     1
    pool_choice_7[33]  R1097     -60
    pool_choice_7[33]  R1106     -1
    pool_choice_7[33]  R1126     -1
    pool_choice_7[33]  R1138     -1
    pool_choice_7[33]  pool_cover_C0_order_d  1
    pool_choice_7[33]  R1783     -60
    pool_choice_7[33]  R1787     -60
    pool_choice_7[33]  R1789     -60
    pool_choice_7[34]  OBJ       3.3166042328794461e+01
    pool_choice_7[34]  R1096     1
    pool_choice_7[34]  R1097     -60
    pool_choice_7[34]  R1106     -1
    pool_choice_7[34]  R1116     -1
    pool_choice_7[34]  R1130     -1
    pool_choice_7[34]  R1132     -1
    pool_choice_7[34]  R1138     -1
    pool_choice_7[34]  pool_cover_C0_order_d  1
    pool_choice_7[34]  pool_cover_C0_order_p  1
    pool_choice_7[34]  pool_cover_C85_order_p  1
    pool_choice_7[34]  R1621     -1
    pool_choice_7[34]  R1635     -1
    pool_choice_7[34]  R1783     -60
    pool_choice_7[34]  R1787     -60
    pool_choice_7[34]  R1789     -60
    pool_choice_7[35]  OBJ       3.7837287915293039e+01
    pool_choice_7[35]  R1096     1
    pool_choice_7[35]  R1097     -60
    pool_choice_7[35]  R1104     -1
    pool_choice_7[35]  R1121     -1
    pool_choice_7[35]  R1136     -1
    pool_choice_7[35]  pool_cover_C85_order_d  1
    pool_choice_7[35]  pool_cover_C75_order_d  1
    pool_choice_7[35]  R1636     -1
    pool_choice_7[35]  R1783     -60
    pool_choice_7[35]  R1787     -60
    pool_choice_7[35]  R1789     -60
    pool_choice_7[36]  OBJ       3.5116342351967482e+01
    pool_choice_7[36]  R1096     1
    pool_choice_7[36]  R1112     -1
    pool_choice_7[36]  R1116     -1
    pool_choice_7[36]  R1130     -1
    pool_choice_7[36]  R1131     -1
    pool_choice_7[36]  R1132     -1
    pool_choice_7[36]  pool_cover_C90_order_p  1
    pool_choice_7[36]  pool_cover_C0_order_p  1
    pool_choice_7[36]  pool_cover_C85_order_p  1
    pool_choice_7[36]  R1635     -1
    pool_choice_7[36]  R1637     -1
    pool_choice_7[37]  OBJ       6.3709853449601354e+01
    pool_choice_7[37]  R1096     1
    pool_choice_7[37]  R1097     -60
    pool_choice_7[37]  R1110     -1
    pool_choice_7[37]  R1122     -1
    pool_choice_7[37]  R1137     -1
    pool_choice_7[37]  pool_cover_C81_order_d  1
    pool_choice_7[37]  pool_cover_C90_order_d  1
    pool_choice_7[37]  pool_cover_C97_order_d  1
    pool_choice_7[37]  R1638     -1
    pool_choice_7[37]  R1639     -1
    pool_choice_7[37]  R1783     -60
    pool_choice_7[37]  R1787     -60
    pool_choice_7[37]  R1789     -60
    pool_choice_7[38]  OBJ       3.5116342351967482e+01
    pool_choice_7[38]  R1096     1
    pool_choice_7[38]  R1097     -60
    pool_choice_7[38]  R1105     -1
    pool_choice_7[38]  R1116     -1
    pool_choice_7[38]  R1130     -1
    pool_choice_7[38]  R1131     -1
    pool_choice_7[38]  R1132     -1
    pool_choice_7[38]  R1137     -1
    pool_choice_7[38]  pool_cover_C90_order_d  1
    pool_choice_7[38]  pool_cover_C90_order_p  1
    pool_choice_7[38]  pool_cover_C0_order_p  1
    pool_choice_7[38]  pool_cover_C85_order_p  1
    pool_choice_7[38]  R1620     -1
    pool_choice_7[38]  R1635     -1
    pool_choice_7[38]  R1637     -1
    pool_choice_7[38]  R1783     -60
    pool_choice_7[38]  R1787     -60
    pool_choice_7[38]  R1789     -60
    pool_choice_7[39]  OBJ       6.6013282617951688e+01
    pool_choice_7[39]  R1096     1
    pool_choice_7[39]  R1097     -60
    pool_choice_7[39]  R1113     -1
    pool_choice_7[39]  R1127     -1
    pool_choice_7[39]  R1138     -1
    pool_choice_7[39]  pool_cover_C39_order_d  1
    pool_choice_7[39]  pool_cover_C52_order_d  1
    pool_choice_7[39]  R1640     -1
    pool_choice_7[39]  R1783     -60
    pool_choice_7[39]  R1787     -60
    pool_choice_7[39]  R1789     -60
    pool_choice_7[40]  OBJ       3.6722124674044828e+01
    pool_choice_7[40]  R1096     1
    pool_choice_7[40]  R1097     -60
    pool_choice_7[40]  R1106     -1
    pool_choice_7[40]  R1115     -1
    pool_choice_7[40]  R1129     -1
    pool_choice_7[40]  R1132     -1
    pool_choice_7[40]  R1138     -1
    pool_choice_7[40]  pool_cover_C0_order_d  1
    pool_choice_7[40]  pool_cover_C0_order_p  1
    pool_choice_7[40]  pool_cover_C75_order_p  1
    pool_choice_7[40]  R1621     -1
    pool_choice_7[40]  R1632     -1
    pool_choice_7[40]  R1783     -60
    pool_choice_7[40]  R1787     -60
    pool_choice_7[40]  R1789     -60
    pool_choice_7[41]  OBJ       3.6291544140059209e+01
    pool_choice_7[41]  R1096     1
    pool_choice_7[41]  R1112     -1
    pool_choice_7[41]  R1116     -1
    pool_choice_7[41]  R1130     -1
    pool_choice_7[41]  R1131     -1
    pool_choice_7[41]  R1134     -1
    pool_choice_7[41]  pool_cover_C81_order_p  1
    pool_choice_7[41]  pool_cover_C90_order_p  1
    pool_choice_7[41]  pool_cover_C85_order_p  1
    pool_choice_7[41]  R1629     -1
    pool_choice_7[41]  R1642     -1
    pool_choice_7[42]  OBJ       6.6004157126226886e+01
    pool_choice_7[42]  R1096     1
    pool_choice_7[42]  R1097     -60
    pool_choice_7[42]  R1110     -1
    pool_choice_7[42]  R1128     -1
    pool_choice_7[42]  R1137     -1
    pool_choice_7[42]  pool_cover_C81_order_d  1
    pool_choice_7[42]  pool_cover_C97_order_d  1
    pool_choice_7[42]  pool_cover_C51_order_d  1
    pool_choice_7[42]  R1638     -1
    pool_choice_7[42]  R1643     -1
    pool_choice_7[42]  R1783     -60
    pool_choice_7[42]  R1787     -60
    pool_choice_7[42]  R1789     -60
    pool_choice_7[43]  OBJ       3.6291544140059209e+01
    pool_choice_7[43]  R1096     1
    pool_choice_7[43]  R1097     -60
    pool_choice_7[43]  R1105     -1
    pool_choice_7[43]  R1116     -1
    pool_choice_7[43]  R1130     -1
    pool_choice_7[43]  R1134     -1
    pool_choice_7[43]  R1137     -1
    pool_choice_7[43]  pool_cover_C81_order_d  1
    pool_choice_7[43]  pool_cover_C81_order_p  1
    pool_choice_7[43]  pool_cover_C90_order_d  1
    pool_choice_7[43]  pool_cover_C85_order_p  1
    pool_choice_7[43]  R1619     -1
    pool_choice_7[43]  R1629     -1
    pool_choice_7[43]  R1644     -1
    pool_choice_7[43]  R1783     -60
    pool_choice_7[43]  R1787     -60
    pool_choice_7[43]  R1789     -60
    pool_choice_7[44]  OBJ       71.9286437576317
    pool_choice_7[44]  R1096     1
    pool_choice_7[44]  R1097     -60
    pool_choice_7[44]  R1106     -1
    pool_choice_7[44]  R1123     -1
    pool_choice_7[44]  R1138     -1
    pool_choice_7[44]  pool_cover_C0_order_d  1
    pool_choice_7[44]  pool_cover_C39_order_d  1
    pool_choice_7[44]  R1645     -1
    pool_choice_7[44]  R1783     -60
    pool_choice_7[44]  R1787     -60
    pool_choice_7[44]  R1789     -60
    pool_choice_7[45]  OBJ       4.0324927052090487e+01
    pool_choice_7[45]  R1096     1
    pool_choice_7[45]  R1097     -60
    pool_choice_7[45]  R1106     -1
    pool_choice_7[45]  R1116     -1
    pool_choice_7[45]  R1129     -1
    pool_choice_7[45]  R1130     -1
    pool_choice_7[45]  R1138     -1
    pool_choice_7[45]  pool_cover_C0_order_d  1
    pool_choice_7[45]  pool_cover_C85_order_p  1
    pool_choice_7[45]  pool_cover_C75_order_p  1
    pool_choice_7[45]  R1633     -1
    pool_choice_7[45]  R1646     -1
    pool_choice_7[45]  R1783     -60
    pool_choice_7[45]  R1787     -60
    pool_choice_7[45]  R1789     -60
    pool_choice_7[46]  OBJ       3.8672424697217842e+01
    pool_choice_7[46]  R1096     1
    pool_choice_7[46]  R1112     -1
    pool_choice_7[46]  R1115     -1
    pool_choice_7[46]  R1129     -1
    pool_choice_7[46]  R1131     -1
    pool_choice_7[46]  R1132     -1
    pool_choice_7[46]  pool_cover_C90_order_p  1
    pool_choice_7[46]  pool_cover_C0_order_p  1
    pool_choice_7[46]  pool_cover_C75_order_p  1
    pool_choice_7[46]  R1632     -1
    pool_choice_7[46]  R1637     -1
    pool_choice_7[47]  OBJ       2.4166091947189145e+01
    pool_choice_7[47]  R1096     1
    pool_choice_7[47]  R1097     -60
    pool_choice_7[47]  R1105     -1
    pool_choice_7[47]  R1122     -1
    pool_choice_7[47]  R1137     -1
    pool_choice_7[47]  pool_cover_C90_order_d  1
    pool_choice_7[47]  R1783     -60
    pool_choice_7[47]  R1787     -60
    pool_choice_7[47]  R1789     -60
    pool_choice_7[48]  OBJ       3.6291544140059209e+01
    pool_choice_7[48]  R1096     1
    pool_choice_7[48]  R1097     -60
    pool_choice_7[48]  R1105     -1
    pool_choice_7[48]  R1116     -1
    pool_choice_7[48]  R1130     -1
    pool_choice_7[48]  R1131     -1
    pool_choice_7[48]  R1134     -1
    pool_choice_7[48]  R1137     -1
    pool_choice_7[48]  pool_cover_C81_order_p  1
    pool_choice_7[48]  pool_cover_C90_order_d  1
    pool_choice_7[48]  pool_cover_C90_order_p  1
    pool_choice_7[48]  pool_cover_C85_order_p  1
    pool_choice_7[48]  R1620     -1
    pool_choice_7[48]  R1629     -1
    pool_choice_7[48]  R1642     -1
    pool_choice_7[48]  R1783     -60
    pool_choice_7[48]  R1787     -60
    pool_choice_7[48]  R1789     -60
    pool_choice_7[49]  OBJ       8.0409665286968448e+01
    pool_choice_7[49]  R1096     1
    pool_choice_7[49]  R1097     -60
    pool_choice_7[49]  R1106     -1
    pool_choice_7[49]  R1127     -1
    pool_choice_7[49]  R1138     -1
    pool_choice_7[49]  pool_cover_C0_order_d  1
    pool_choice_7[49]  pool_cover_C52_order_d  1
    pool_choice_7[49]  R1630     -1
    pool_choice_7[49]  R1783     -60
    pool_choice_7[49]  R1787     -60
    pool_choice_7[49]  R1789     -60
    pool_choice_7[50]  OBJ       6.8348124505258170e+01
    pool_choice_7[50]  R1096     1
    pool_choice_7[50]  R1097     -60
    pool_choice_7[50]  R1114     -1
    pool_choice_7[50]  R1116     -1
    pool_choice_7[50]  R1130     -1
    pool_choice_7[50]  R1133     -1
    pool_choice_7[50]  R1135     -1
    pool_choice_7[50]  R1138     -1
    pool_choice_7[50]  pool_cover_C39_order_d  1
    pool_choice_7[50]  pool_cover_C39_order_p  1
    pool_choice_7[50]  pool_cover_C52_order_d  1
    pool_choice_7[50]  pool_cover_C85_order_p  1
    pool_choice_7[50]  pool_cover_C21_order_p  1
    pool_choice_7[50]  R1624     -1
    pool_choice_7[50]  R1631     -1
    pool_choice_7[50]  R1647     -1
    pool_choice_7[50]  R1648     -1
    pool_choice_7[50]  R1783     -60
    pool_choice_7[50]  R1787     -60
    pool_choice_7[50]  R1789     -60
    pool_choice_7[51]  OBJ       7.7871156918086484e+01
    pool_choice_7[51]  R1096     1
    pool_choice_7[51]  R1097     -60
    pool_choice_7[51]  R1107     -1
    pool_choice_7[51]  R1121     -1
    pool_choice_7[51]  R1136     -1
    pool_choice_7[51]  pool_cover_C75_order_d  1
    pool_choice_7[51]  pool_cover_C21_order_d  1
    pool_choice_7[51]  R1649     -1
    pool_choice_7[51]  R1783     -60
    pool_choice_7[51]  R1787     -60
    pool_choice_7[51]  R1789     -60
    pool_choice_7[52]  OBJ       3.7837287915293039e+01
    pool_choice_7[52]  R1096     1
    pool_choice_7[52]  R1097     -60
    pool_choice_7[52]  R1104     -1
    pool_choice_7[52]  R1115     -1
    pool_choice_7[52]  R1129     -1
    pool_choice_7[52]  R1130     -1
    pool_choice_7[52]  R1136     -1
    pool_choice_7[52]  pool_cover_C85_order_d  1
    pool_choice_7[52]  pool_cover_C85_order_p  1
    pool_choice_7[52]  pool_cover_C75_order_p  1
    pool_choice_7[52]  R1618     -1
    pool_choice_7[52]  R1650     -1
    pool_choice_7[52]  R1783     -60
    pool_choice_7[52]  R1787     -60
    pool_choice_7[52]  R1789     -60
    pool_choice_7[53]  OBJ       2.6263385861093521e+01
    pool_choice_7[53]  R1096     1
    pool_choice_7[53]  R1112     -1
    pool_choice_7[53]  R1116     -1
    pool_choice_7[53]  R1130     -1
    pool_choice_7[53]  R1131     -1
    pool_choice_7[53]  pool_cover_C90_order_p  1
    pool_choice_7[53]  pool_cover_C85_order_p  1
    pool_choice_7[53]  R1634     -1
    pool_choice_7[54]  OBJ       7.4792579518192952e+01
    pool_choice_7[54]  R1096     1
    pool_choice_7[54]  R1097     -60
    pool_choice_7[54]  R1105     -1
    pool_choice_7[54]  R1128     -1
    pool_choice_7[54]  R1137     -1
    pool_choice_7[54]  pool_cover_C90_order_d  1
    pool_choice_7[54]  pool_cover_C97_order_d  1
    pool_choice_7[54]  pool_cover_C51_order_d  1
    pool_choice_7[54]  R1643     -1
    pool_choice_7[54]  R1651     -1
    pool_choice_7[54]  R1783     -60
    pool_choice_7[54]  R1787     -60
    pool_choice_7[54]  R1789     -60
    pool_choice_7[55]  OBJ       4.7159723682742595e+01
    pool_choice_7[55]  R1096     1
    pool_choice_7[55]  R1097     -60
    pool_choice_7[55]  R1110     -1
    pool_choice_7[55]  R1116     -1
    pool_choice_7[55]  R1130     -1
    pool_choice_7[55]  R1131     -1
    pool_choice_7[55]  R1132     -1
    pool_choice_7[55]  R1137     -1
    pool_choice_7[55]  pool_cover_C81_order_d  1
    pool_choice_7[55]  pool_cover_C90_order_d  1
    pool_choice_7[55]  pool_cover_C90_order_p  1
    pool_choice_7[55]  pool_cover_C0_order_p  1
    pool_choice_7[55]  pool_cover_C85_order_p  1
    pool_choice_7[55]  R1620     -1
    pool_choice_7[55]  R1628     -1
    pool_choice_7[55]  R1635     -1
    pool_choice_7[55]  R1637     -1
    pool_choice_7[55]  R1783     -60
    pool_choice_7[55]  R1787     -60
    pool_choice_7[55]  R1789     -60
    pool_used_7  R1096     -1
    pool_used_7  R1097     -28800
    pool_used_7  R1098     -75600
    pool_used_7  R1099     -75540
    pool_used_7  R1100     -1
    pool_used_7  R1101     -80
    pool_used_7  R1102     -80
    pool_used_7  R1783     -75660
    pool_used_7  R1784     -81
    pool_used_7  R1787     -75660
    pool_used_7  R1788     -81
    pool_used_7  R1789     -75660
    pool_used_7  R1790     -81
    pool_start_7  R1097     1
    pool_start_7  R1098     1
    pool_start_7  R1783     1
    pool_start_7  R1787     1
    pool_start_7  R1789     1
    pool_start_7  GC628     -1
    pool_start_7  GC630     -1
    pool_start_7  GC632     -1
    pool_start_7  GC634     -1
    pool_start_7  GC636     -1
    pool_start_7  GC638     -1
    pool_start_7  GC640     -1
    pool_start_7  GC642     -1
    pool_start_7  GC644     -1
    pool_start_7  GC646     -1
    pool_start_7  GC648     -1
    pool_start_7  GC650     -1
    pool_start_7  GC687     1
    pool_start_7  GC688     1
    pool_start_7  GC689     1
    pool_end_7  R1099     1
    pool_end_7  GC652     1
    pool_end_7  GC654     1
    pool_end_7  GC656     1
    pool_end_7  GC658     1
    pool_end_7  GC660     1
    pool_end_7  GC662     1
    pool_end_7  GC664     1
    pool_end_7  GC666     1
    pool_end_7  GC668     1
    pool_end_7  GC670     1
    pool_end_7  GC672     1
    pool_end_7  GC674     1
    pool_end_7  GC676     1
    pool_end_7  GC678     1
    pool_end_7  GC680     -1
    pool_end_7  GC681     -1
    pool_end_7  GC682     -1
    pool_end_7  GC683     -1
    pool_end_7  GC684     -1
    pool_end_7  GC685     -1
    pool_end_7  GC686     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_7  R1100     1
    pool_start_rank_7  R1101     1
    pool_start_rank_7  R1784     1
    pool_start_rank_7  R1788     1
    pool_start_rank_7  R1790     1
    pool_start_rank_7  GC629     -1
    pool_start_rank_7  GC631     -1
    pool_start_rank_7  GC633     -1
    pool_start_rank_7  GC635     -1
    pool_start_rank_7  GC637     -1
    pool_start_rank_7  GC639     -1
    pool_start_rank_7  GC641     -1
    pool_start_rank_7  GC643     -1
    pool_start_rank_7  GC645     -1
    pool_start_rank_7  GC647     -1
    pool_start_rank_7  GC649     -1
    pool_start_rank_7  GC651     -1
    pool_end_rank_7  R1102     1
    pool_end_rank_7  GC653     1
    pool_end_rank_7  GC655     1
    pool_end_rank_7  GC657     1
    pool_end_rank_7  GC659     1
    pool_end_rank_7  GC661     1
    pool_end_rank_7  GC663     1
    pool_end_rank_7  GC665     1
    pool_end_rank_7  GC667     1
    pool_end_rank_7  GC669     1
    pool_end_rank_7  GC671     1
    pool_end_rank_7  GC673     1
    pool_end_rank_7  GC675     1
    pool_end_rank_7  GC677     1
    pool_end_rank_7  GC679     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_7_C75_order_d  R1103     1
    pool_first_7_C85_order_d  R1104     1
    pool_first_7_C90_order_d  R1105     1
    pool_first_7_C0_order_d  R1106     1
    pool_first_7_C21_order_d  R1107     1
    pool_first_7_C75_order_p  R1108     1
    pool_first_7_C85_order_p  R1109     1
    pool_first_7_C81_order_d  R1110     1
    pool_first_7_C81_order_p  R1111     1
    pool_first_7_C90_order_p  R1112     1
    pool_first_7_C39_order_d  R1113     1
    pool_first_7_C52_order_d  R1114     1
    pool_last_7_C75_order_p  R1115     1
    pool_last_7_C85_order_p  R1116     1
    pool_last_7_C90_order_p  R1117     1
    pool_last_7_C0_order_p  R1118     1
    pool_last_7_C21_order_p  R1119     1
    pool_last_7_C21_order_d  R1120     1
    pool_last_7_C75_order_d  R1121     1
    pool_last_7_C90_order_d  R1122     1
    pool_last_7_C39_order_d  R1123     1
    pool_last_7_C85_order_d  R1124     1
    pool_last_7_C81_order_d  R1125     1
    pool_last_7_C0_order_d  R1126     1
    pool_last_7_C52_order_d  R1127     1
    pool_last_7_C51_order_d  R1128     1
    pool_pickup_7_C75_order  R1129     1
    pool_pickup_7_C85_order  R1130     1
    pool_pickup_7_C90_order  R1131     1
    pool_pickup_7_C0_order  R1132     1
    pool_pickup_7_C21_order  R1133     1
    pool_pickup_7_C81_order  R1134     1
    pool_pickup_7_C39_order  R1135     1
    pool_batch_7_b3  R1136     1
    pool_batch_7_b1  R1137     1
    pool_batch_7_b2  R1138     1
    pool_choice_8[0]  OBJ       1.1661903789690601e+01
    pool_choice_8[0]  R1139     1
    pool_choice_8[0]  R1140     -60
    pool_choice_8[0]  R1146     -1
    pool_choice_8[0]  R1162     -1
    pool_choice_8[0]  R1178     -1
    pool_choice_8[0]  R1186     -1
    pool_choice_8[0]  pool_cover_C47_order_d  1
    pool_choice_8[0]  pool_cover_C47_order_p  1
    pool_choice_8[0]  R1701     -1
    pool_choice_8[1]  OBJ       1.7888543819998318e+01
    pool_choice_8[1]  R1139     1
    pool_choice_8[1]  R1140     -60
    pool_choice_8[1]  R1147     -1
    pool_choice_8[1]  R1163     -1
    pool_choice_8[1]  R1179     -1
    pool_choice_8[1]  R1187     -1
    pool_choice_8[1]  pool_cover_C88_order_d  1
    pool_choice_8[1]  pool_cover_C88_order_p  1
    pool_choice_8[1]  R1702     -1
    pool_choice_8[2]  OBJ       20.591260281974
    pool_choice_8[2]  R1139     1
    pool_choice_8[2]  R1140     -60
    pool_choice_8[2]  R1148     -1
    pool_choice_8[2]  R1164     -1
    pool_choice_8[2]  R1180     -1
    pool_choice_8[2]  R1188     -1
    pool_choice_8[2]  pool_cover_C29_order_d  1
    pool_choice_8[2]  pool_cover_C29_order_p  1
    pool_choice_8[2]  R1703     -1
    pool_choice_8[3]  OBJ       1.1661903789690601e+01
    pool_choice_8[3]  R1139     1
    pool_choice_8[3]  R1140     -60
    pool_choice_8[3]  R1146     -1
    pool_choice_8[3]  R1165     -1
    pool_choice_8[3]  R1186     -1
    pool_choice_8[3]  pool_cover_C47_order_d  1
    pool_choice_8[4]  OBJ       1.1661903789690601e+01
    pool_choice_8[4]  R1139     1
    pool_choice_8[4]  R1149     -1
    pool_choice_8[4]  R1162     -1
    pool_choice_8[4]  R1178     -1
    pool_choice_8[4]  pool_cover_C47_order_p  1
    pool_choice_8[5]  OBJ       2.6076809620810597e+01
    pool_choice_8[5]  R1139     1
    pool_choice_8[5]  R1140     -60
    pool_choice_8[5]  R1150     -1
    pool_choice_8[5]  R1166     -1
    pool_choice_8[5]  R1181     -1
    pool_choice_8[5]  R1187     -1
    pool_choice_8[5]  pool_cover_C76_order_d  1
    pool_choice_8[5]  pool_cover_C76_order_p  1
    pool_choice_8[5]  R1704     -1
    pool_choice_8[6]  OBJ       1.7888543819998318e+01
    pool_choice_8[6]  R1139     1
    pool_choice_8[6]  R1140     -60
    pool_choice_8[6]  R1147     -1
    pool_choice_8[6]  R1167     -1
    pool_choice_8[6]  R1187     -1
    pool_choice_8[6]  pool_cover_C88_order_d  1
    pool_choice_8[7]  OBJ       1.7888543819998318e+01
    pool_choice_8[7]  R1139     1
    pool_choice_8[7]  R1151     -1
    pool_choice_8[7]  R1163     -1
    pool_choice_8[7]  R1179     -1
    pool_choice_8[7]  pool_cover_C88_order_p  1
    pool_choice_8[8]  OBJ       20.591260281974
    pool_choice_8[8]  R1139     1
    pool_choice_8[8]  R1140     -60
    pool_choice_8[8]  R1148     -1
    pool_choice_8[8]  R1168     -1
    pool_choice_8[8]  R1188     -1
    pool_choice_8[8]  pool_cover_C29_order_d  1
    pool_choice_8[9]  OBJ       20.591260281974
    pool_choice_8[9]  R1139     1
    pool_choice_8[9]  R1152     -1
    pool_choice_8[9]  R1164     -1
    pool_choice_8[9]  R1180     -1
    pool_choice_8[9]  pool_cover_C29_order_p  1
    pool_choice_8[10]  OBJ       4.8083261120685229e+01
    pool_choice_8[10]  R1139     1
    pool_choice_8[10]  R1140     -60
    pool_choice_8[10]  R1153     -1
    pool_choice_8[10]  R1169     -1
    pool_choice_8[10]  R1182     -1
    pool_choice_8[10]  R1187     -1
    pool_choice_8[10]  pool_cover_C27_order_d  1
    pool_choice_8[10]  pool_cover_C27_order_p  1
    pool_choice_8[10]  R1705     -1
    pool_choice_8[11]  OBJ       4.9396356140913873e+01
    pool_choice_8[11]  R1139     1
    pool_choice_8[11]  R1140     -60
    pool_choice_8[11]  R1154     -1
    pool_choice_8[11]  R1170     -1
    pool_choice_8[11]  R1183     -1
    pool_choice_8[11]  R1186     -1
    pool_choice_8[11]  pool_cover_C25_order_d  1
    pool_choice_8[11]  pool_cover_C25_order_p  1
    pool_choice_8[11]  R1706     -1
    pool_choice_8[12]  OBJ       2.6076809620810597e+01
    pool_choice_8[12]  R1139     1
    pool_choice_8[12]  R1140     -60
    pool_choice_8[12]  R1150     -1
    pool_choice_8[12]  R1171     -1
    pool_choice_8[12]  R1187     -1
    pool_choice_8[12]  pool_cover_C76_order_d  1
    pool_choice_8[13]  OBJ       2.6076809620810597e+01
    pool_choice_8[13]  R1139     1
    pool_choice_8[13]  R1155     -1
    pool_choice_8[13]  R1166     -1
    pool_choice_8[13]  R1181     -1
    pool_choice_8[13]  pool_cover_C76_order_p  1
    pool_choice_8[14]  OBJ       6.2032249677083293e+01
    pool_choice_8[14]  R1139     1
    pool_choice_8[14]  R1140     -60
    pool_choice_8[14]  R1156     -1
    pool_choice_8[14]  R1172     -1
    pool_choice_8[14]  R1184     -1
    pool_choice_8[14]  R1186     -1
    pool_choice_8[14]  pool_cover_C46_order_d  1
    pool_choice_8[14]  pool_cover_C46_order_p  1
    pool_choice_8[14]  R1707     -1
    pool_choice_8[15]  OBJ       6.3529520697074361e+01
    pool_choice_8[15]  R1139     1
    pool_choice_8[15]  R1140     -60
    pool_choice_8[15]  R1157     -1
    pool_choice_8[15]  R1173     -1
    pool_choice_8[15]  R1185     -1
    pool_choice_8[15]  R1188     -1
    pool_choice_8[15]  pool_cover_C6_order_d  1
    pool_choice_8[15]  pool_cover_C6_order_p  1
    pool_choice_8[15]  R1708     -1
    pool_choice_8[16]  OBJ       4.8083261120685229e+01
    pool_choice_8[16]  R1139     1
    pool_choice_8[16]  R1140     -60
    pool_choice_8[16]  R1153     -1
    pool_choice_8[16]  R1174     -1
    pool_choice_8[16]  R1187     -1
    pool_choice_8[16]  pool_cover_C27_order_d  1
    pool_choice_8[17]  OBJ       4.8083261120685229e+01
    pool_choice_8[17]  R1139     1
    pool_choice_8[17]  R1158     -1
    pool_choice_8[17]  R1169     -1
    pool_choice_8[17]  R1182     -1
    pool_choice_8[17]  pool_cover_C27_order_p  1
    pool_choice_8[18]  OBJ       4.9396356140913873e+01
    pool_choice_8[18]  R1139     1
    pool_choice_8[18]  R1140     -60
    pool_choice_8[18]  R1154     -1
    pool_choice_8[18]  R1175     -1
    pool_choice_8[18]  R1186     -1
    pool_choice_8[18]  pool_cover_C25_order_d  1
    pool_choice_8[19]  OBJ       4.9396356140913873e+01
    pool_choice_8[19]  R1139     1
    pool_choice_8[19]  R1159     -1
    pool_choice_8[19]  R1170     -1
    pool_choice_8[19]  R1183     -1
    pool_choice_8[19]  pool_cover_C25_order_p  1
    pool_choice_8[20]  OBJ       6.2032249677083293e+01
    pool_choice_8[20]  R1139     1
    pool_choice_8[20]  R1140     -60
    pool_choice_8[20]  R1156     -1
    pool_choice_8[20]  R1176     -1
    pool_choice_8[20]  R1186     -1
    pool_choice_8[20]  pool_cover_C46_order_d  1
    pool_choice_8[21]  OBJ       6.2032249677083293e+01
    pool_choice_8[21]  R1139     1
    pool_choice_8[21]  R1160     -1
    pool_choice_8[21]  R1172     -1
    pool_choice_8[21]  R1184     -1
    pool_choice_8[21]  pool_cover_C46_order_p  1
    pool_choice_8[22]  OBJ       6.3529520697074361e+01
    pool_choice_8[22]  R1139     1
    pool_choice_8[22]  R1140     -60
    pool_choice_8[22]  R1157     -1
    pool_choice_8[22]  R1177     -1
    pool_choice_8[22]  R1188     -1
    pool_choice_8[22]  pool_cover_C6_order_d  1
    pool_choice_8[23]  OBJ       6.3529520697074361e+01
    pool_choice_8[23]  R1139     1
    pool_choice_8[23]  R1161     -1
    pool_choice_8[23]  R1173     -1
    pool_choice_8[23]  R1185     -1
    pool_choice_8[23]  pool_cover_C6_order_p  1
    pool_choice_8[24]  OBJ       2.0654115613359256e+01
    pool_choice_8[24]  R1139     1
    pool_choice_8[24]  R1151     -1
    pool_choice_8[24]  R1164     -1
    pool_choice_8[24]  R1179     -1
    pool_choice_8[24]  R1180     -1
    pool_choice_8[24]  pool_cover_C88_order_p  1
    pool_choice_8[24]  pool_cover_C29_order_p  1
    pool_choice_8[24]  R1709     -1
    pool_choice_8[25]  OBJ       2.0654115613359256e+01
    pool_choice_8[25]  R1139     1
    pool_choice_8[25]  R1140     -60
    pool_choice_8[25]  R1147     -1
    pool_choice_8[25]  R1164     -1
    pool_choice_8[25]  R1179     -1
    pool_choice_8[25]  R1180     -1
    pool_choice_8[25]  R1187     -1
    pool_choice_8[25]  pool_cover_C88_order_d  1
    pool_choice_8[25]  pool_cover_C88_order_p  1
    pool_choice_8[25]  pool_cover_C29_order_p  1
    pool_choice_8[25]  R1702     -1
    pool_choice_8[25]  R1709     -1
    pool_choice_8[26]  OBJ       41.2180607820758
    pool_choice_8[26]  R1139     1
    pool_choice_8[26]  R1140     -60
    pool_choice_8[26]  R1147     -1
    pool_choice_8[26]  R1171     -1
    pool_choice_8[26]  R1187     -1
    pool_choice_8[26]  pool_cover_C88_order_d  1
    pool_choice_8[26]  pool_cover_C76_order_d  1
    pool_choice_8[26]  R1710     -1
    pool_choice_8[27]  OBJ       4.9397092229415449e+01
    pool_choice_8[27]  R1139     1
    pool_choice_8[27]  R1140     -60
    pool_choice_8[27]  R1146     -1
    pool_choice_8[27]  R1175     -1
    pool_choice_8[27]  R1186     -1
    pool_choice_8[27]  pool_cover_C47_order_d  1
    pool_choice_8[27]  pool_cover_C25_order_d  1
    pool_choice_8[27]  R1711     -1
    pool_choice_8[28]  OBJ       3.1747081387645608e+01
    pool_choice_8[28]  R1139     1
    pool_choice_8[28]  R1140     -60
    pool_choice_8[28]  R1146     -1
    pool_choice_8[28]  R1164     -1
    pool_choice_8[28]  R1178     -1
    pool_choice_8[28]  R1180     -1
    pool_choice_8[28]  R1186     -1
    pool_choice_8[28]  pool_cover_C47_order_d  1
    pool_choice_8[28]  pool_cover_C47_order_p  1
    pool_choice_8[28]  pool_cover_C29_order_p  1
    pool_choice_8[28]  R1701     -1
    pool_choice_8[28]  R1712     -1
    pool_choice_8[29]  OBJ       7.5601410152021032e+01
    pool_choice_8[29]  R1139     1
    pool_choice_8[29]  R1140     -60
    pool_choice_8[29]  R1148     -1
    pool_choice_8[29]  R1177     -1
    pool_choice_8[29]  R1188     -1
    pool_choice_8[29]  pool_cover_C29_order_d  1
    pool_choice_8[29]  pool_cover_C6_order_d  1
    pool_choice_8[29]  R1713     -1
    pool_choice_8[30]  OBJ       8.7673299606967689e+01
    pool_choice_8[30]  R1139     1
    pool_choice_8[30]  R1140     -60
    pool_choice_8[30]  R1148     -1
    pool_choice_8[30]  R1164     -1
    pool_choice_8[30]  R1180     -1
    pool_choice_8[30]  R1185     -1
    pool_choice_8[30]  R1188     -1
    pool_choice_8[30]  pool_cover_C29_order_d  1
    pool_choice_8[30]  pool_cover_C29_order_p  1
    pool_choice_8[30]  pool_cover_C6_order_d  1
    pool_choice_8[30]  pool_cover_C6_order_p  1
    pool_choice_8[30]  R1708     -1
    pool_choice_8[30]  R1713     -1
    pool_choice_8[30]  R1714     -1
    pool_choice_8[31]  OBJ       2.7115567956485918e+01
    pool_choice_8[31]  R1139     1
    pool_choice_8[31]  R1155     -1
    pool_choice_8[31]  R1162     -1
    pool_choice_8[31]  R1178     -1
    pool_choice_8[31]  R1181     -1
    pool_choice_8[31]  pool_cover_C76_order_p  1
    pool_choice_8[31]  pool_cover_C47_order_p  1
    pool_choice_8[31]  R1715     -1
    pool_choice_8[32]  OBJ       6.4531470933056056e+01
    pool_choice_8[32]  R1139     1
    pool_choice_8[32]  R1140     -60
    pool_choice_8[32]  R1147     -1
    pool_choice_8[32]  R1171     -1
    pool_choice_8[32]  R1187     -1
    pool_choice_8[32]  pool_cover_C88_order_d  1
    pool_choice_8[32]  pool_cover_C76_order_d  1
    pool_choice_8[32]  pool_cover_C27_order_d  1
    pool_choice_8[32]  R1716     -1
    pool_choice_8[32]  R1717     -1
    pool_choice_8[33]  OBJ       2.7115567956485918e+01
    pool_choice_8[33]  R1139     1
    pool_choice_8[33]  R1140     -60
    pool_choice_8[33]  R1150     -1
    pool_choice_8[33]  R1162     -1
    pool_choice_8[33]  R1178     -1
    pool_choice_8[33]  R1181     -1
    pool_choice_8[33]  R1187     -1
    pool_choice_8[33]  pool_cover_C76_order_d  1
    pool_choice_8[33]  pool_cover_C76_order_p  1
    pool_choice_8[33]  pool_cover_C47_order_p  1
    pool_choice_8[33]  R1704     -1
    pool_choice_8[33]  R1715     -1
    pool_choice_8[34]  OBJ       6.4631964712286560e+01
    pool_choice_8[34]  R1139     1
    pool_choice_8[34]  R1140     -60
    pool_choice_8[34]  R1146     -1
    pool_choice_8[34]  R1176     -1
    pool_choice_8[34]  R1186     -1
    pool_choice_8[34]  pool_cover_C47_order_d  1
    pool_choice_8[34]  pool_cover_C46_order_d  1
    pool_choice_8[34]  R1718     -1
    pool_choice_8[35]  OBJ       4.9397828317917018e+01
    pool_choice_8[35]  R1139     1
    pool_choice_8[35]  R1140     -60
    pool_choice_8[35]  R1146     -1
    pool_choice_8[35]  R1162     -1
    pool_choice_8[35]  R1178     -1
    pool_choice_8[35]  R1183     -1
    pool_choice_8[35]  R1186     -1
    pool_choice_8[35]  pool_cover_C47_order_d  1
    pool_choice_8[35]  pool_cover_C47_order_p  1
    pool_choice_8[35]  pool_cover_C25_order_d  1
    pool_choice_8[35]  pool_cover_C25_order_p  1
    pool_choice_8[35]  R1706     -1
    pool_choice_8[35]  R1711     -1
    pool_choice_8[35]  R1719     -1
    pool_choice_8[36]  OBJ       7.5601410152021018e+01
    pool_choice_8[36]  R1139     1
    pool_choice_8[36]  R1140     -60
    pool_choice_8[36]  R1157     -1
    pool_choice_8[36]  R1164     -1
    pool_choice_8[36]  R1180     -1
    pool_choice_8[36]  R1185     -1
    pool_choice_8[36]  R1188     -1
    pool_choice_8[36]  pool_cover_C29_order_p  1
    pool_choice_8[36]  pool_cover_C6_order_d  1
    pool_choice_8[36]  pool_cover_C6_order_p  1
    pool_choice_8[36]  R1708     -1
    pool_choice_8[36]  R1714     -1
    pool_choice_8[37]  OBJ       5.5723778079391167e+01
    pool_choice_8[37]  R1139     1
    pool_choice_8[37]  R1155     -1
    pool_choice_8[37]  R1162     -1
    pool_choice_8[37]  R1178     -1
    pool_choice_8[37]  R1181     -1
    pool_choice_8[37]  R1182     -1
    pool_choice_8[37]  R1183     -1
    pool_choice_8[37]  pool_cover_C76_order_p  1
    pool_choice_8[37]  pool_cover_C27_order_p  1
    pool_choice_8[37]  pool_cover_C47_order_p  1
    pool_choice_8[37]  pool_cover_C25_order_p  1
    pool_choice_8[37]  R1719     -1
    pool_choice_8[37]  R1720     -1
    pool_choice_8[37]  R1721     -1
    pool_choice_8[38]  OBJ       4.8741939160438513e+01
    pool_choice_8[38]  R1139     1
    pool_choice_8[38]  R1140     -60
    pool_choice_8[38]  R1153     -1
    pool_choice_8[38]  R1171     -1
    pool_choice_8[38]  R1187     -1
    pool_choice_8[38]  pool_cover_C76_order_d  1
    pool_choice_8[38]  pool_cover_C27_order_d  1
    pool_choice_8[38]  R1717     -1
    pool_choice_8[39]  OBJ       2.8987894208396355e+01
    pool_choice_8[39]  R1139     1
    pool_choice_8[39]  R1140     -60
    pool_choice_8[39]  R1147     -1
    pool_choice_8[39]  R1162     -1
    pool_choice_8[39]  R1178     -1
    pool_choice_8[39]  R1179     -1
    pool_choice_8[39]  R1187     -1
    pool_choice_8[39]  pool_cover_C88_order_d  1
    pool_choice_8[39]  pool_cover_C88_order_p  1
    pool_choice_8[39]  pool_cover_C47_order_p  1
    pool_choice_8[39]  R1702     -1
    pool_choice_8[39]  R1722     -1
    pool_choice_8[40]  OBJ       8.1012524190345616e+01
    pool_choice_8[40]  R1139     1
    pool_choice_8[40]  R1140     -60
    pool_choice_8[40]  R1154     -1
    pool_choice_8[40]  R1176     -1
    pool_choice_8[40]  R1186     -1
    pool_choice_8[40]  pool_cover_C25_order_d  1
    pool_choice_8[40]  pool_cover_C46_order_d  1
    pool_choice_8[40]  R1723     -1
    pool_choice_8[41]  OBJ       6.9483005915872027e+01
    pool_choice_8[41]  R1139     1
    pool_choice_8[41]  R1140     -60
    pool_choice_8[41]  R1146     -1
    pool_choice_8[41]  R1164     -1
    pool_choice_8[41]  R1178     -1
    pool_choice_8[41]  R1180     -1
    pool_choice_8[41]  R1183     -1
    pool_choice_8[41]  R1186     -1
    pool_choice_8[41]  pool_cover_C47_order_d  1
    pool_choice_8[41]  pool_cover_C47_order_p  1
    pool_choice_8[41]  pool_cover_C25_order_d  1
    pool_choice_8[41]  pool_cover_C25_order_p  1
    pool_choice_8[41]  pool_cover_C29_order_p  1
    pool_choice_8[41]  R1706     -1
    pool_choice_8[41]  R1711     -1
    pool_choice_8[41]  R1712     -1
    pool_choice_8[41]  R1719     -1
    pool_choice_8[42]  OBJ       7.5601410152021032e+01
    pool_choice_8[42]  R1139     1
    pool_choice_8[42]  R1140     -60
    pool_choice_8[42]  R1148     -1
    pool_choice_8[42]  R1173     -1
    pool_choice_8[42]  R1180     -1
    pool_choice_8[42]  R1185     -1
    pool_choice_8[42]  R1188     -1
    pool_choice_8[42]  pool_cover_C29_order_d  1
    pool_choice_8[42]  pool_cover_C29_order_p  1
    pool_choice_8[42]  pool_cover_C6_order_p  1
    pool_choice_8[42]  R1703     -1
    pool_choice_8[42]  R1724     -1
    pool_choice_8[43]  OBJ       4.2256819117751121e+01
    pool_choice_8[43]  R1139     1
    pool_choice_8[43]  R1151     -1
    pool_choice_8[43]  R1162     -1
    pool_choice_8[43]  R1178     -1
    pool_choice_8[43]  R1179     -1
    pool_choice_8[43]  R1181     -1
    pool_choice_8[43]  pool_cover_C88_order_p  1
    pool_choice_8[43]  pool_cover_C76_order_p  1
    pool_choice_8[43]  pool_cover_C47_order_p  1
    pool_choice_8[43]  R1715     -1
    pool_choice_8[43]  R1725     -1
    pool_choice_8[44]  OBJ       4.8741939160438520e+01
    pool_choice_8[44]  R1139     1
    pool_choice_8[44]  R1140     -60
    pool_choice_8[44]  R1150     -1
    pool_choice_8[44]  R1174     -1
    pool_choice_8[44]  R1187     -1
    pool_choice_8[44]  pool_cover_C76_order_d  1
    pool_choice_8[44]  pool_cover_C27_order_d  1
    pool_choice_8[44]  R1726     -1
    pool_choice_8[45]  OBJ       5.0439375535867129e+01
    pool_choice_8[45]  R1139     1
    pool_choice_8[45]  R1140     -60
    pool_choice_8[45]  R1150     -1
    pool_choice_8[45]  R1162     -1
    pool_choice_8[45]  R1178     -1
    pool_choice_8[45]  R1181     -1
    pool_choice_8[45]  R1182     -1
    pool_choice_8[45]  R1187     -1
    pool_choice_8[45]  pool_cover_C76_order_d  1
    pool_choice_8[45]  pool_cover_C76_order_p  1
    pool_choice_8[45]  pool_cover_C27_order_d  1
    pool_choice_8[45]  pool_cover_C27_order_p  1
    pool_choice_8[45]  pool_cover_C47_order_p  1
    pool_choice_8[45]  R1705     -1
    pool_choice_8[45]  R1715     -1
    pool_choice_8[45]  R1726     -1
    pool_choice_8[45]  R1727     -1
    pool_choice_8[46]  OBJ       3.1747081387645608e+01
    pool_choice_8[46]  R1139     1
    pool_choice_8[46]  R1140     -60
    pool_choice_8[46]  R1146     -1
    pool_choice_8[46]  R1164     -1
    pool_choice_8[46]  R1180     -1
    pool_choice_8[46]  R1186     -1
    pool_choice_8[46]  pool_cover_C47_order_d  1
    pool_choice_8[46]  pool_cover_C29_order_p  1
    pool_choice_8[46]  R1728     -1
    pool_choice_8[47]  OBJ       7.5601410152021032e+01
    pool_choice_8[47]  R1139     1
    pool_choice_8[47]  R1140     -60
    pool_choice_8[47]  R1148     -1
    pool_choice_8[47]  R1173     -1
    pool_choice_8[47]  R1185     -1
    pool_choice_8[47]  R1188     -1
    pool_choice_8[47]  pool_cover_C29_order_d  1
    pool_choice_8[47]  pool_cover_C6_order_d  1
    pool_choice_8[47]  pool_cover_C6_order_p  1
    pool_choice_8[47]  R1708     -1
    pool_choice_8[47]  R1713     -1
    pool_choice_8[48]  OBJ       2.8987894208396355e+01
    pool_choice_8[48]  R1139     1
    pool_choice_8[48]  R1151     -1
    pool_choice_8[48]  R1162     -1
    pool_choice_8[48]  R1178     -1
    pool_choice_8[48]  R1179     -1
    pool_choice_8[48]  pool_cover_C88_order_p  1
    pool_choice_8[48]  pool_cover_C47_order_p  1
    pool_choice_8[48]  R1722     -1
    pool_choice_8[49]  OBJ       2.0654115613359256e+01
    pool_choice_8[49]  R1139     1
    pool_choice_8[49]  R1140     -60
    pool_choice_8[49]  R1147     -1
    pool_choice_8[49]  R1164     -1
    pool_choice_8[49]  R1180     -1
    pool_choice_8[49]  R1187     -1
    pool_choice_8[49]  pool_cover_C88_order_d  1
    pool_choice_8[49]  pool_cover_C29_order_p  1
    pool_choice_8[49]  R1729     -1
    pool_choice_8[50]  OBJ       8.1575595302846423e+01
    pool_choice_8[50]  R1139     1
    pool_choice_8[50]  R1140     -60
    pool_choice_8[50]  R1146     -1
    pool_choice_8[50]  R1164     -1
    pool_choice_8[50]  R1180     -1
    pool_choice_8[50]  R1184     -1
    pool_choice_8[50]  R1185     -1
    pool_choice_8[50]  R1186     -1
    pool_choice_8[50]  pool_cover_C47_order_d  1
    pool_choice_8[50]  pool_cover_C46_order_d  1
    pool_choice_8[50]  pool_cover_C46_order_p  1
    pool_choice_8[50]  pool_cover_C29_order_p  1
    pool_choice_8[50]  pool_cover_C6_order_p  1
    pool_choice_8[50]  R1707     -1
    pool_choice_8[50]  R1714     -1
    pool_choice_8[50]  R1718     -1
    pool_choice_8[50]  R1730     -1
    pool_choice_8[51]  OBJ       8.7673299606967689e+01
    pool_choice_8[51]  R1139     1
    pool_choice_8[51]  R1140     -60
    pool_choice_8[51]  R1148     -1
    pool_choice_8[51]  R1164     -1
    pool_choice_8[51]  R1180     -1
    pool_choice_8[51]  R1188     -1
    pool_choice_8[51]  pool_cover_C29_order_d  1
    pool_choice_8[51]  pool_cover_C29_order_p  1
    pool_choice_8[51]  pool_cover_C6_order_d  1
    pool_choice_8[51]  R1713     -1
    pool_choice_8[51]  R1731     -1
    pool_choice_8[52]  OBJ       4.3983632575436737e+01
    pool_choice_8[52]  R1139     1
    pool_choice_8[52]  R1155     -1
    pool_choice_8[52]  R1164     -1
    pool_choice_8[52]  R1179     -1
    pool_choice_8[52]  R1180     -1
    pool_choice_8[52]  R1181     -1
    pool_choice_8[52]  pool_cover_C88_order_p  1
    pool_choice_8[52]  pool_cover_C76_order_p  1
    pool_choice_8[52]  pool_cover_C29_order_p  1
    pool_choice_8[52]  R1709     -1
    pool_choice_8[52]  R1732     -1
    pool_choice_8[53]  OBJ       6.3872792893302773e+01
    pool_choice_8[53]  R1139     1
    pool_choice_8[53]  R1140     -60
    pool_choice_8[53]  R1147     -1
    pool_choice_8[53]  R1174     -1
    pool_choice_8[53]  R1187     -1
    pool_choice_8[53]  pool_cover_C88_order_d  1
    pool_choice_8[53]  pool_cover_C27_order_d  1
    pool_choice_8[53]  R1716     -1
    pool_choice_8[54]  OBJ       4.2256819117751121e+01
    pool_choice_8[54]  R1139     1
    pool_choice_8[54]  R1140     -60
    pool_choice_8[54]  R1147     -1
    pool_choice_8[54]  R1162     -1
    pool_choice_8[54]  R1178     -1
    pool_choice_8[54]  R1181     -1
    pool_choice_8[54]  R1187     -1
    pool_choice_8[54]  pool_cover_C88_order_d  1
    pool_choice_8[54]  pool_cover_C76_order_d  1
    pool_choice_8[54]  pool_cover_C76_order_p  1
    pool_choice_8[54]  pool_cover_C47_order_p  1
    pool_choice_8[54]  R1704     -1
    pool_choice_8[54]  R1710     -1
    pool_choice_8[54]  R1715     -1
    pool_choice_8[55]  OBJ       8.1575595302846423e+01
    pool_choice_8[55]  R1139     1
    pool_choice_8[55]  R1140     -60
    pool_choice_8[55]  R1146     -1
    pool_choice_8[55]  R1164     -1
    pool_choice_8[55]  R1178     -1
    pool_choice_8[55]  R1180     -1
    pool_choice_8[55]  R1184     -1
    pool_choice_8[55]  R1185     -1
    pool_choice_8[55]  R1186     -1
    pool_choice_8[55]  pool_cover_C47_order_d  1
    pool_choice_8[55]  pool_cover_C47_order_p  1
    pool_choice_8[55]  pool_cover_C46_order_p  1
    pool_choice_8[55]  pool_cover_C29_order_p  1
    pool_choice_8[55]  pool_cover_C6_order_p  1
    pool_choice_8[55]  R1701     -1
    pool_choice_8[55]  R1714     -1
    pool_choice_8[55]  R1730     -1
    pool_choice_8[55]  R1733     -1
    pool_used_8  R1139     -1
    pool_used_8  R1140     -28800
    pool_used_8  R1141     -75600
    pool_used_8  R1142     -75540
    pool_used_8  R1143     -1
    pool_used_8  R1144     -80
    pool_used_8  R1145     -80
    pool_used_8  R1791     -75660
    pool_used_8  R1792     -81
    pool_used_8  R1793     -75660
    pool_used_8  R1794     -81
    pool_used_8  R1795     -75660
    pool_used_8  R1796     -81
    pool_start_8  R1140     1
    pool_start_8  R1141     1
    pool_start_8  GC690     -1
    pool_start_8  GC692     -1
    pool_start_8  GC694     -1
    pool_start_8  GC696     -1
    pool_start_8  GC698     -1
    pool_start_8  GC700     -1
    pool_start_8  GC702     -1
    pool_start_8  GC704     -1
    pool_start_8  GC706     -1
    pool_start_8  GC708     -1
    pool_start_8  GC710     -1
    pool_start_8  GC712     -1
    pool_start_8  GC714     -1
    pool_start_8  GC716     -1
    pool_start_8  GC718     -1
    pool_start_8  GC720     -1
    pool_start_8  GC762     1
    pool_start_8  GC763     1
    pool_start_8  GC764     1
    pool_end_8  R1142     1
    pool_end_8  R1791     -1
    pool_end_8  R1793     -1
    pool_end_8  R1795     -1
    pool_end_8  GC722     1
    pool_end_8  GC724     1
    pool_end_8  GC726     1
    pool_end_8  GC728     1
    pool_end_8  GC730     1
    pool_end_8  GC732     1
    pool_end_8  GC734     1
    pool_end_8  GC736     1
    pool_end_8  GC738     1
    pool_end_8  GC740     1
    pool_end_8  GC742     1
    pool_end_8  GC744     1
    pool_end_8  GC746     1
    pool_end_8  GC748     1
    pool_end_8  GC750     1
    pool_end_8  GC752     1
    pool_end_8  GC754     -1
    pool_end_8  GC755     -1
    pool_end_8  GC756     -1
    pool_end_8  GC757     -1
    pool_end_8  GC758     -1
    pool_end_8  GC759     -1
    pool_end_8  GC760     -1
    pool_end_8  GC761     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_8  R1143     1
    pool_start_rank_8  R1144     1
    pool_start_rank_8  GC691     -1
    pool_start_rank_8  GC693     -1
    pool_start_rank_8  GC695     -1
    pool_start_rank_8  GC697     -1
    pool_start_rank_8  GC699     -1
    pool_start_rank_8  GC701     -1
    pool_start_rank_8  GC703     -1
    pool_start_rank_8  GC705     -1
    pool_start_rank_8  GC707     -1
    pool_start_rank_8  GC709     -1
    pool_start_rank_8  GC711     -1
    pool_start_rank_8  GC713     -1
    pool_start_rank_8  GC715     -1
    pool_start_rank_8  GC717     -1
    pool_start_rank_8  GC719     -1
    pool_start_rank_8  GC721     -1
    pool_end_rank_8  R1145     1
    pool_end_rank_8  R1792     -1
    pool_end_rank_8  R1794     -1
    pool_end_rank_8  R1796     -1
    pool_end_rank_8  GC723     1
    pool_end_rank_8  GC725     1
    pool_end_rank_8  GC727     1
    pool_end_rank_8  GC729     1
    pool_end_rank_8  GC731     1
    pool_end_rank_8  GC733     1
    pool_end_rank_8  GC735     1
    pool_end_rank_8  GC737     1
    pool_end_rank_8  GC739     1
    pool_end_rank_8  GC741     1
    pool_end_rank_8  GC743     1
    pool_end_rank_8  GC745     1
    pool_end_rank_8  GC747     1
    pool_end_rank_8  GC749     1
    pool_end_rank_8  GC751     1
    pool_end_rank_8  GC753     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_8_C47_order_d  R1146     1
    pool_first_8_C88_order_d  R1147     1
    pool_first_8_C29_order_d  R1148     1
    pool_first_8_C47_order_p  R1149     1
    pool_first_8_C76_order_d  R1150     1
    pool_first_8_C88_order_p  R1151     1
    pool_first_8_C29_order_p  R1152     1
    pool_first_8_C27_order_d  R1153     1
    pool_first_8_C25_order_d  R1154     1
    pool_first_8_C76_order_p  R1155     1
    pool_first_8_C46_order_d  R1156     1
    pool_first_8_C6_order_d  R1157     1
    pool_first_8_C27_order_p  R1158     1
    pool_first_8_C25_order_p  R1159     1
    pool_first_8_C46_order_p  R1160     1
    pool_first_8_C6_order_p  R1161     1
    pool_last_8_C47_order_p  R1162     1
    pool_last_8_C88_order_p  R1163     1
    pool_last_8_C29_order_p  R1164     1
    pool_last_8_C47_order_d  R1165     1
    pool_last_8_C76_order_p  R1166     1
    pool_last_8_C88_order_d  R1167     1
    pool_last_8_C29_order_d  R1168     1
    pool_last_8_C27_order_p  R1169     1
    pool_last_8_C25_order_p  R1170     1
    pool_last_8_C76_order_d  R1171     1
    pool_last_8_C46_order_p  R1172     1
    pool_last_8_C6_order_p  R1173     1
    pool_last_8_C27_order_d  R1174     1
    pool_last_8_C25_order_d  R1175     1
    pool_last_8_C46_order_d  R1176     1
    pool_last_8_C6_order_d  R1177     1
    pool_pickup_8_C47_order  R1178     1
    pool_pickup_8_C88_order  R1179     1
    pool_pickup_8_C29_order  R1180     1
    pool_pickup_8_C76_order  R1181     1
    pool_pickup_8_C27_order  R1182     1
    pool_pickup_8_C25_order  R1183     1
    pool_pickup_8_C46_order  R1184     1
    pool_pickup_8_C6_order  R1185     1
    pool_batch_8_b2  R1186     1
    pool_batch_8_b1  R1187     1
    pool_batch_8_b3  R1188     1
    pool_choice_9[0]  OBJ       1.7888543819998318e+01
    pool_choice_9[0]  R1189     1
    pool_choice_9[0]  R1190     -60
    pool_choice_9[0]  R1196     -1
    pool_choice_9[0]  R1207     -1
    pool_choice_9[0]  R1223     -1
    pool_choice_9[0]  R1231     -1
    pool_choice_9[0]  pool_cover_C88_order_d  1
    pool_choice_9[0]  pool_cover_C88_order_p  1
    pool_choice_9[0]  R1702     -1
    pool_choice_9[0]  R1791     -60
    pool_choice_9[1]  OBJ       2.0654115613359256e+01
    pool_choice_9[1]  R1189     1
    pool_choice_9[1]  R1190     -60
    pool_choice_9[1]  R1196     -1
    pool_choice_9[1]  R1208     -1
    pool_choice_9[1]  R1223     -1
    pool_choice_9[1]  R1224     -1
    pool_choice_9[1]  R1231     -1
    pool_choice_9[1]  pool_cover_C88_order_d  1
    pool_choice_9[1]  pool_cover_C88_order_p  1
    pool_choice_9[1]  pool_cover_C29_order_p  1
    pool_choice_9[1]  R1702     -1
    pool_choice_9[1]  R1709     -1
    pool_choice_9[1]  R1791     -60
    pool_choice_9[2]  OBJ       2.8987894208396355e+01
    pool_choice_9[2]  R1189     1
    pool_choice_9[2]  R1190     -60
    pool_choice_9[2]  R1196     -1
    pool_choice_9[2]  R1209     -1
    pool_choice_9[2]  R1223     -1
    pool_choice_9[2]  R1225     -1
    pool_choice_9[2]  R1231     -1
    pool_choice_9[2]  pool_cover_C88_order_d  1
    pool_choice_9[2]  pool_cover_C88_order_p  1
    pool_choice_9[2]  pool_cover_C47_order_p  1
    pool_choice_9[2]  R1702     -1
    pool_choice_9[2]  R1722     -1
    pool_choice_9[2]  R1791     -60
    pool_choice_9[3]  OBJ       20.591260281974
    pool_choice_9[3]  R1189     1
    pool_choice_9[3]  R1190     -60
    pool_choice_9[3]  R1197     -1
    pool_choice_9[3]  R1208     -1
    pool_choice_9[3]  R1224     -1
    pool_choice_9[3]  R1232     -1
    pool_choice_9[3]  pool_cover_C29_order_d  1
    pool_choice_9[3]  pool_cover_C29_order_p  1
    pool_choice_9[3]  R1703     -1
    pool_choice_9[3]  R1791     -60
    pool_choice_9[4]  OBJ       2.6076809620810597e+01
    pool_choice_9[4]  R1189     1
    pool_choice_9[4]  R1190     -60
    pool_choice_9[4]  R1198     -1
    pool_choice_9[4]  R1210     -1
    pool_choice_9[4]  R1226     -1
    pool_choice_9[4]  R1231     -1
    pool_choice_9[4]  pool_cover_C76_order_d  1
    pool_choice_9[4]  pool_cover_C76_order_p  1
    pool_choice_9[4]  R1704     -1
    pool_choice_9[4]  R1791     -60
    pool_choice_9[5]  OBJ       41.2180607820758
    pool_choice_9[5]  R1189     1
    pool_choice_9[5]  R1190     -60
    pool_choice_9[5]  R1196     -1
    pool_choice_9[5]  R1210     -1
    pool_choice_9[5]  R1223     -1
    pool_choice_9[5]  R1226     -1
    pool_choice_9[5]  R1231     -1
    pool_choice_9[5]  pool_cover_C88_order_d  1
    pool_choice_9[5]  pool_cover_C88_order_p  1
    pool_choice_9[5]  pool_cover_C76_order_p  1
    pool_choice_9[5]  R1702     -1
    pool_choice_9[5]  R1725     -1
    pool_choice_9[5]  R1791     -60
    pool_choice_9[6]  OBJ       5.6359311943341005e+01
    pool_choice_9[6]  R1189     1
    pool_choice_9[6]  R1190     -60
    pool_choice_9[6]  R1196     -1
    pool_choice_9[6]  R1207     -1
    pool_choice_9[6]  R1223     -1
    pool_choice_9[6]  R1226     -1
    pool_choice_9[6]  R1231     -1
    pool_choice_9[6]  pool_cover_C88_order_d  1
    pool_choice_9[6]  pool_cover_C88_order_p  1
    pool_choice_9[6]  pool_cover_C76_order_d  1
    pool_choice_9[6]  pool_cover_C76_order_p  1
    pool_choice_9[6]  R1704     -1
    pool_choice_9[6]  R1710     -1
    pool_choice_9[6]  R1732     -1
    pool_choice_9[6]  R1791     -60
    pool_choice_9[7]  OBJ       1.7888543819998318e+01
    pool_choice_9[7]  R1189     1
    pool_choice_9[7]  R1190     -60
    pool_choice_9[7]  R1196     -1
    pool_choice_9[7]  R1211     -1
    pool_choice_9[7]  R1231     -1
    pool_choice_9[7]  pool_cover_C88_order_d  1
    pool_choice_9[7]  R1791     -60
    pool_choice_9[8]  OBJ       1.7888543819998318e+01
    pool_choice_9[8]  R1189     1
    pool_choice_9[8]  R1199     -1
    pool_choice_9[8]  R1207     -1
    pool_choice_9[8]  R1223     -1
    pool_choice_9[8]  pool_cover_C88_order_p  1
    pool_choice_9[9]  OBJ       5.6359311943341005e+01
    pool_choice_9[9]  R1189     1
    pool_choice_9[9]  R1190     -60
    pool_choice_9[9]  R1196     -1
    pool_choice_9[9]  R1207     -1
    pool_choice_9[9]  R1223     -1
    pool_choice_9[9]  R1231     -1
    pool_choice_9[9]  pool_cover_C88_order_d  1
    pool_choice_9[9]  pool_cover_C88_order_p  1
    pool_choice_9[9]  pool_cover_C76_order_d  1
    pool_choice_9[9]  R1710     -1
    pool_choice_9[9]  R1734     -1
    pool_choice_9[9]  R1791     -60
    pool_choice_9[10]  OBJ       7.9662324665920323e+01
    pool_choice_9[10]  R1189     1
    pool_choice_9[10]  R1190     -60
    pool_choice_9[10]  R1196     -1
    pool_choice_9[10]  R1207     -1
    pool_choice_9[10]  R1223     -1
    pool_choice_9[10]  R1227     -1
    pool_choice_9[10]  R1231     -1
    pool_choice_9[10]  pool_cover_C88_order_d  1
    pool_choice_9[10]  pool_cover_C88_order_p  1
    pool_choice_9[10]  pool_cover_C27_order_d  1
    pool_choice_9[10]  pool_cover_C27_order_p  1
    pool_choice_9[10]  R1705     -1
    pool_choice_9[10]  R1716     -1
    pool_choice_9[10]  R1735     -1
    pool_choice_9[10]  R1791     -60
    pool_choice_9[11]  OBJ       7.9688828905418490e+01
    pool_choice_9[11]  R1189     1
    pool_choice_9[11]  R1190     -60
    pool_choice_9[11]  R1196     -1
    pool_choice_9[11]  R1210     -1
    pool_choice_9[11]  R1223     -1
    pool_choice_9[11]  R1226     -1
    pool_choice_9[11]  R1231     -1
    pool_choice_9[11]  pool_cover_C88_order_d  1
    pool_choice_9[11]  pool_cover_C88_order_p  1
    pool_choice_9[11]  pool_cover_C76_order_d  1
    pool_choice_9[11]  pool_cover_C76_order_p  1
    pool_choice_9[11]  R1710     -1
    pool_choice_9[11]  R1725     -1
    pool_choice_9[11]  R1734     -1
    pool_choice_9[11]  R1791     -60
    pool_choice_9[12]  OBJ       41.2180607820758
    pool_choice_9[12]  R1189     1
    pool_choice_9[12]  R1190     -60
    pool_choice_9[12]  R1198     -1
    pool_choice_9[12]  R1207     -1
    pool_choice_9[12]  R1223     -1
    pool_choice_9[12]  R1231     -1
    pool_choice_9[12]  pool_cover_C88_order_p  1
    pool_choice_9[12]  pool_cover_C76_order_d  1
    pool_choice_9[12]  R1734     -1
    pool_choice_9[12]  R1791     -60
    pool_choice_9[13]  OBJ       41.2180607820758
    pool_choice_9[13]  R1189     1
    pool_choice_9[13]  R1190     -60
    pool_choice_9[13]  R1196     -1
    pool_choice_9[13]  R1210     -1
    pool_choice_9[13]  R1226     -1
    pool_choice_9[13]  R1231     -1
    pool_choice_9[13]  pool_cover_C88_order_d  1
    pool_choice_9[13]  pool_cover_C76_order_p  1
    pool_choice_9[13]  R1736     -1
    pool_choice_9[13]  R1791     -60
    pool_choice_9[14]  OBJ       6.3872792893302773e+01
    pool_choice_9[14]  R1189     1
    pool_choice_9[14]  R1190     -60
    pool_choice_9[14]  R1196     -1
    pool_choice_9[14]  R1212     -1
    pool_choice_9[14]  R1223     -1
    pool_choice_9[14]  R1227     -1
    pool_choice_9[14]  R1231     -1
    pool_choice_9[14]  pool_cover_C88_order_d  1
    pool_choice_9[14]  pool_cover_C88_order_p  1
    pool_choice_9[14]  pool_cover_C27_order_p  1
    pool_choice_9[14]  R1702     -1
    pool_choice_9[14]  R1737     -1
    pool_choice_9[14]  R1791     -60
    pool_choice_9[15]  OBJ       6.6292105415085118e+01
    pool_choice_9[15]  R1189     1
    pool_choice_9[15]  R1190     -60
    pool_choice_9[15]  R1196     -1
    pool_choice_9[15]  R1213     -1
    pool_choice_9[15]  R1223     -1
    pool_choice_9[15]  R1228     -1
    pool_choice_9[15]  R1231     -1
    pool_choice_9[15]  pool_cover_C88_order_d  1
    pool_choice_9[15]  pool_cover_C88_order_p  1
    pool_choice_9[15]  pool_cover_C25_order_p  1
    pool_choice_9[15]  R1702     -1
    pool_choice_9[15]  R1738     -1
    pool_choice_9[15]  R1791     -60
    pool_choice_9[16]  OBJ       7.3096479800102586e+01
    pool_choice_9[16]  R1189     1
    pool_choice_9[16]  R1190     -60
    pool_choice_9[16]  R1196     -1
    pool_choice_9[16]  R1214     -1
    pool_choice_9[16]  R1223     -1
    pool_choice_9[16]  R1229     -1
    pool_choice_9[16]  R1231     -1
    pool_choice_9[16]  pool_cover_C88_order_d  1
    pool_choice_9[16]  pool_cover_C88_order_p  1
    pool_choice_9[16]  pool_cover_C46_order_p  1
    pool_choice_9[16]  R1702     -1
    pool_choice_9[16]  R1739     -1
    pool_choice_9[16]  R1791     -60
    pool_choice_9[17]  OBJ       4.8741939160438520e+01
    pool_choice_9[17]  R1189     1
    pool_choice_9[17]  R1190     -60
    pool_choice_9[17]  R1198     -1
    pool_choice_9[17]  R1215     -1
    pool_choice_9[17]  R1231     -1
    pool_choice_9[17]  pool_cover_C76_order_d  1
    pool_choice_9[17]  pool_cover_C27_order_d  1
    pool_choice_9[17]  R1726     -1
    pool_choice_9[17]  R1791     -60
    pool_choice_9[18]  OBJ       7.3465710966854743e+01
    pool_choice_9[18]  R1189     1
    pool_choice_9[18]  R1190     -60
    pool_choice_9[18]  R1196     -1
    pool_choice_9[18]  R1216     -1
    pool_choice_9[18]  R1223     -1
    pool_choice_9[18]  R1230     -1
    pool_choice_9[18]  R1231     -1
    pool_choice_9[18]  pool_cover_C88_order_d  1
    pool_choice_9[18]  pool_cover_C88_order_p  1
    pool_choice_9[18]  pool_cover_C6_order_p  1
    pool_choice_9[18]  R1702     -1
    pool_choice_9[18]  R1740     -1
    pool_choice_9[18]  R1791     -60
    pool_choice_9[19]  OBJ       4.9397092229415449e+01
    pool_choice_9[19]  R1189     1
    pool_choice_9[19]  R1190     -60
    pool_choice_9[19]  R1200     -1
    pool_choice_9[19]  R1217     -1
    pool_choice_9[19]  R1233     -1
    pool_choice_9[19]  pool_cover_C47_order_d  1
    pool_choice_9[19]  pool_cover_C25_order_d  1
    pool_choice_9[19]  R1711     -1
    pool_choice_9[19]  R1791     -60
    pool_choice_9[20]  OBJ       7.9662324665920323e+01
    pool_choice_9[20]  R1189     1
    pool_choice_9[20]  R1190     -60
    pool_choice_9[20]  R1196     -1
    pool_choice_9[20]  R1207     -1
    pool_choice_9[20]  R1223     -1
    pool_choice_9[20]  R1231     -1
    pool_choice_9[20]  pool_cover_C88_order_d  1
    pool_choice_9[20]  pool_cover_C88_order_p  1
    pool_choice_9[20]  pool_cover_C27_order_d  1
    pool_choice_9[20]  R1716     -1
    pool_choice_9[20]  R1741     -1
    pool_choice_9[20]  R1791     -60
    pool_choice_9[21]  OBJ       6.2032249677083293e+01
    pool_choice_9[21]  R1189     1
    pool_choice_9[21]  R1190     -60
    pool_choice_9[21]  R1201     -1
    pool_choice_9[21]  R1214     -1
    pool_choice_9[21]  R1229     -1
    pool_choice_9[21]  R1233     -1
    pool_choice_9[21]  pool_cover_C46_order_d  1
    pool_choice_9[21]  pool_cover_C46_order_p  1
    pool_choice_9[21]  R1707     -1
    pool_choice_9[21]  R1791     -60
    pool_choice_9[22]  OBJ       1.2564657373922478e+02
    pool_choice_9[22]  R1189     1
    pool_choice_9[22]  R1190     -60
    pool_choice_9[22]  R1196     -1
    pool_choice_9[22]  R1212     -1
    pool_choice_9[22]  R1223     -1
    pool_choice_9[22]  R1227     -1
    pool_choice_9[22]  R1231     -1
    pool_choice_9[22]  pool_cover_C88_order_d  1
    pool_choice_9[22]  pool_cover_C88_order_p  1
    pool_choice_9[22]  pool_cover_C27_order_d  1
    pool_choice_9[22]  pool_cover_C27_order_p  1
    pool_choice_9[22]  R1716     -1
    pool_choice_9[22]  R1737     -1
    pool_choice_9[22]  R1741     -1
    pool_choice_9[22]  R1791     -60
    pool_choice_9[23]  OBJ       6.3529520697074361e+01
    pool_choice_9[23]  R1189     1
    pool_choice_9[23]  R1190     -60
    pool_choice_9[23]  R1202     -1
    pool_choice_9[23]  R1216     -1
    pool_choice_9[23]  R1230     -1
    pool_choice_9[23]  R1232     -1
    pool_choice_9[23]  pool_cover_C6_order_d  1
    pool_choice_9[23]  pool_cover_C6_order_p  1
    pool_choice_9[23]  R1708     -1
    pool_choice_9[23]  R1791     -60
    pool_choice_9[24]  OBJ       6.3872792893302773e+01
    pool_choice_9[24]  R1189     1
    pool_choice_9[24]  R1190     -60
    pool_choice_9[24]  R1196     -1
    pool_choice_9[24]  R1215     -1
    pool_choice_9[24]  R1231     -1
    pool_choice_9[24]  pool_cover_C88_order_d  1
    pool_choice_9[24]  pool_cover_C27_order_d  1
    pool_choice_9[24]  R1716     -1
    pool_choice_9[24]  R1791     -60
    pool_choice_9[25]  OBJ       6.3872792893302773e+01
    pool_choice_9[25]  R1189     1
    pool_choice_9[25]  R1190     -60
    pool_choice_9[25]  R1196     -1
    pool_choice_9[25]  R1212     -1
    pool_choice_9[25]  R1227     -1
    pool_choice_9[25]  R1231     -1
    pool_choice_9[25]  pool_cover_C88_order_d  1
    pool_choice_9[25]  pool_cover_C27_order_p  1
    pool_choice_9[25]  R1742     -1
    pool_choice_9[25]  R1791     -60
    pool_choice_9[26]  OBJ       2.0654115613359256e+01
    pool_choice_9[26]  R1189     1
    pool_choice_9[26]  R1199     -1
    pool_choice_9[26]  R1208     -1
    pool_choice_9[26]  R1223     -1
    pool_choice_9[26]  R1224     -1
    pool_choice_9[26]  pool_cover_C88_order_p  1
    pool_choice_9[26]  pool_cover_C29_order_p  1
    pool_choice_9[26]  R1709     -1
    pool_choice_9[27]  OBJ       1.1661903789690601e+01
    pool_choice_9[27]  R1189     1
    pool_choice_9[27]  R1190     -60
    pool_choice_9[27]  R1200     -1
    pool_choice_9[27]  R1218     -1
    pool_choice_9[27]  R1233     -1
    pool_choice_9[27]  pool_cover_C47_order_d  1
    pool_choice_9[27]  R1791     -60
    pool_choice_9[28]  OBJ       1.1661903789690601e+01
    pool_choice_9[28]  R1189     1
    pool_choice_9[28]  R1190     -60
    pool_choice_9[28]  R1200     -1
    pool_choice_9[28]  R1209     -1
    pool_choice_9[28]  R1225     -1
    pool_choice_9[28]  R1233     -1
    pool_choice_9[28]  pool_cover_C47_order_d  1
    pool_choice_9[28]  pool_cover_C47_order_p  1
    pool_choice_9[28]  R1701     -1
    pool_choice_9[28]  R1791     -60
    pool_choice_9[29]  OBJ       20.591260281974
    pool_choice_9[29]  R1189     1
    pool_choice_9[29]  R1190     -60
    pool_choice_9[29]  R1197     -1
    pool_choice_9[29]  R1219     -1
    pool_choice_9[29]  R1232     -1
    pool_choice_9[29]  pool_cover_C29_order_d  1
    pool_choice_9[29]  R1791     -60
    pool_choice_9[30]  OBJ       1.1661903789690601e+01
    pool_choice_9[30]  R1189     1
    pool_choice_9[30]  R1203     -1
    pool_choice_9[30]  R1209     -1
    pool_choice_9[30]  R1225     -1
    pool_choice_9[30]  pool_cover_C47_order_p  1
    pool_choice_9[31]  OBJ       41.2180607820758
    pool_choice_9[31]  R1189     1
    pool_choice_9[31]  R1190     -60
    pool_choice_9[31]  R1196     -1
    pool_choice_9[31]  R1220     -1
    pool_choice_9[31]  R1231     -1
    pool_choice_9[31]  pool_cover_C88_order_d  1
    pool_choice_9[31]  pool_cover_C76_order_d  1
    pool_choice_9[31]  R1710     -1
    pool_choice_9[31]  R1791     -60
    pool_choice_9[32]  OBJ       3.1747081387645608e+01
    pool_choice_9[32]  R1189     1
    pool_choice_9[32]  R1190     -60
    pool_choice_9[32]  R1200     -1
    pool_choice_9[32]  R1208     -1
    pool_choice_9[32]  R1224     -1
    pool_choice_9[32]  R1225     -1
    pool_choice_9[32]  R1233     -1
    pool_choice_9[32]  pool_cover_C47_order_d  1
    pool_choice_9[32]  pool_cover_C47_order_p  1
    pool_choice_9[32]  pool_cover_C29_order_p  1
    pool_choice_9[32]  R1701     -1
    pool_choice_9[32]  R1712     -1
    pool_choice_9[32]  R1791     -60
    pool_choice_9[33]  OBJ       7.5601410152021032e+01
    pool_choice_9[33]  R1189     1
    pool_choice_9[33]  R1190     -60
    pool_choice_9[33]  R1197     -1
    pool_choice_9[33]  R1221     -1
    pool_choice_9[33]  R1232     -1
    pool_choice_9[33]  pool_cover_C29_order_d  1
    pool_choice_9[33]  pool_cover_C6_order_d  1
    pool_choice_9[33]  R1713     -1
    pool_choice_9[33]  R1791     -60
    pool_choice_9[34]  OBJ       8.7673299606967689e+01
    pool_choice_9[34]  R1189     1
    pool_choice_9[34]  R1190     -60
    pool_choice_9[34]  R1197     -1
    pool_choice_9[34]  R1208     -1
    pool_choice_9[34]  R1224     -1
    pool_choice_9[34]  R1230     -1
    pool_choice_9[34]  R1232     -1
    pool_choice_9[34]  pool_cover_C29_order_d  1
    pool_choice_9[34]  pool_cover_C29_order_p  1
    pool_choice_9[34]  pool_cover_C6_order_d  1
    pool_choice_9[34]  pool_cover_C6_order_p  1
    pool_choice_9[34]  R1708     -1
    pool_choice_9[34]  R1713     -1
    pool_choice_9[34]  R1714     -1
    pool_choice_9[34]  R1791     -60
    pool_choice_9[35]  OBJ       2.7115567956485918e+01
    pool_choice_9[35]  R1189     1
    pool_choice_9[35]  R1204     -1
    pool_choice_9[35]  R1209     -1
    pool_choice_9[35]  R1225     -1
    pool_choice_9[35]  R1226     -1
    pool_choice_9[35]  pool_cover_C76_order_p  1
    pool_choice_9[35]  pool_cover_C47_order_p  1
    pool_choice_9[35]  R1715     -1
    pool_choice_9[36]  OBJ       6.4531470933056056e+01
    pool_choice_9[36]  R1189     1
    pool_choice_9[36]  R1190     -60
    pool_choice_9[36]  R1196     -1
    pool_choice_9[36]  R1220     -1
    pool_choice_9[36]  R1231     -1
    pool_choice_9[36]  pool_cover_C88_order_d  1
    pool_choice_9[36]  pool_cover_C76_order_d  1
    pool_choice_9[36]  pool_cover_C27_order_d  1
    pool_choice_9[36]  R1716     -1
    pool_choice_9[36]  R1717     -1
    pool_choice_9[36]  R1791     -60
    pool_choice_9[37]  OBJ       2.7115567956485918e+01
    pool_choice_9[37]  R1189     1
    pool_choice_9[37]  R1190     -60
    pool_choice_9[37]  R1198     -1
    pool_choice_9[37]  R1209     -1
    pool_choice_9[37]  R1225     -1
    pool_choice_9[37]  R1226     -1
    pool_choice_9[37]  R1231     -1
    pool_choice_9[37]  pool_cover_C76_order_d  1
    pool_choice_9[37]  pool_cover_C76_order_p  1
    pool_choice_9[37]  pool_cover_C47_order_p  1
    pool_choice_9[37]  R1704     -1
    pool_choice_9[37]  R1715     -1
    pool_choice_9[37]  R1791     -60
    pool_choice_9[38]  OBJ       6.4631964712286560e+01
    pool_choice_9[38]  R1189     1
    pool_choice_9[38]  R1190     -60
    pool_choice_9[38]  R1200     -1
    pool_choice_9[38]  R1222     -1
    pool_choice_9[38]  R1233     -1
    pool_choice_9[38]  pool_cover_C47_order_d  1
    pool_choice_9[38]  pool_cover_C46_order_d  1
    pool_choice_9[38]  R1718     -1
    pool_choice_9[38]  R1791     -60
    pool_choice_9[39]  OBJ       4.9397828317917018e+01
    pool_choice_9[39]  R1189     1
    pool_choice_9[39]  R1190     -60
    pool_choice_9[39]  R1200     -1
    pool_choice_9[39]  R1209     -1
    pool_choice_9[39]  R1225     -1
    pool_choice_9[39]  R1228     -1
    pool_choice_9[39]  R1233     -1
    pool_choice_9[39]  pool_cover_C47_order_d  1
    pool_choice_9[39]  pool_cover_C47_order_p  1
    pool_choice_9[39]  pool_cover_C25_order_d  1
    pool_choice_9[39]  pool_cover_C25_order_p  1
    pool_choice_9[39]  R1706     -1
    pool_choice_9[39]  R1711     -1
    pool_choice_9[39]  R1719     -1
    pool_choice_9[39]  R1791     -60
    pool_choice_9[40]  OBJ       6.3529520697074361e+01
    pool_choice_9[40]  R1189     1
    pool_choice_9[40]  R1190     -60
    pool_choice_9[40]  R1202     -1
    pool_choice_9[40]  R1221     -1
    pool_choice_9[40]  R1232     -1
    pool_choice_9[40]  pool_cover_C6_order_d  1
    pool_choice_9[40]  R1791     -60
    pool_choice_9[41]  OBJ       7.5601410152021018e+01
    pool_choice_9[41]  R1189     1
    pool_choice_9[41]  R1190     -60
    pool_choice_9[41]  R1202     -1
    pool_choice_9[41]  R1208     -1
    pool_choice_9[41]  R1224     -1
    pool_choice_9[41]  R1230     -1
    pool_choice_9[41]  R1232     -1
    pool_choice_9[41]  pool_cover_C29_order_p  1
    pool_choice_9[41]  pool_cover_C6_order_d  1
    pool_choice_9[41]  pool_cover_C6_order_p  1
    pool_choice_9[41]  R1708     -1
    pool_choice_9[41]  R1714     -1
    pool_choice_9[41]  R1791     -60
    pool_choice_9[42]  OBJ       5.5723778079391167e+01
    pool_choice_9[42]  R1189     1
    pool_choice_9[42]  R1204     -1
    pool_choice_9[42]  R1209     -1
    pool_choice_9[42]  R1225     -1
    pool_choice_9[42]  R1226     -1
    pool_choice_9[42]  R1227     -1
    pool_choice_9[42]  R1228     -1
    pool_choice_9[42]  pool_cover_C76_order_p  1
    pool_choice_9[42]  pool_cover_C27_order_p  1
    pool_choice_9[42]  pool_cover_C47_order_p  1
    pool_choice_9[42]  pool_cover_C25_order_p  1
    pool_choice_9[42]  R1719     -1
    pool_choice_9[42]  R1720     -1
    pool_choice_9[42]  R1721     -1
    pool_choice_9[43]  OBJ       4.8741939160438513e+01
    pool_choice_9[43]  R1189     1
    pool_choice_9[43]  R1190     -60
    pool_choice_9[43]  R1205     -1
    pool_choice_9[43]  R1220     -1
    pool_choice_9[43]  R1231     -1
    pool_choice_9[43]  pool_cover_C76_order_d  1
    pool_choice_9[43]  pool_cover_C27_order_d  1
    pool_choice_9[43]  R1717     -1
    pool_choice_9[43]  R1791     -60
    pool_choice_9[44]  OBJ       8.1012524190345616e+01
    pool_choice_9[44]  R1189     1
    pool_choice_9[44]  R1190     -60
    pool_choice_9[44]  R1206     -1
    pool_choice_9[44]  R1222     -1
    pool_choice_9[44]  R1233     -1
    pool_choice_9[44]  pool_cover_C25_order_d  1
    pool_choice_9[44]  pool_cover_C46_order_d  1
    pool_choice_9[44]  R1723     -1
    pool_choice_9[44]  R1791     -60
    pool_choice_9[45]  OBJ       6.9483005915872027e+01
    pool_choice_9[45]  R1189     1
    pool_choice_9[45]  R1190     -60
    pool_choice_9[45]  R1200     -1
    pool_choice_9[45]  R1208     -1
    pool_choice_9[45]  R1224     -1
    pool_choice_9[45]  R1225     -1
    pool_choice_9[45]  R1228     -1
    pool_choice_9[45]  R1233     -1
    pool_choice_9[45]  pool_cover_C47_order_d  1
    pool_choice_9[45]  pool_cover_C47_order_p  1
    pool_choice_9[45]  pool_cover_C25_order_d  1
    pool_choice_9[45]  pool_cover_C25_order_p  1
    pool_choice_9[45]  pool_cover_C29_order_p  1
    pool_choice_9[45]  R1706     -1
    pool_choice_9[45]  R1711     -1
    pool_choice_9[45]  R1712     -1
    pool_choice_9[45]  R1719     -1
    pool_choice_9[45]  R1791     -60
    pool_choice_9[46]  OBJ       7.5601410152021032e+01
    pool_choice_9[46]  R1189     1
    pool_choice_9[46]  R1190     -60
    pool_choice_9[46]  R1197     -1
    pool_choice_9[46]  R1216     -1
    pool_choice_9[46]  R1224     -1
    pool_choice_9[46]  R1230     -1
    pool_choice_9[46]  R1232     -1
    pool_choice_9[46]  pool_cover_C29_order_d  1
    pool_choice_9[46]  pool_cover_C29_order_p  1
    pool_choice_9[46]  pool_cover_C6_order_p  1
    pool_choice_9[46]  R1703     -1
    pool_choice_9[46]  R1724     -1
    pool_choice_9[46]  R1791     -60
    pool_choice_9[47]  OBJ       4.2256819117751121e+01
    pool_choice_9[47]  R1189     1
    pool_choice_9[47]  R1199     -1
    pool_choice_9[47]  R1209     -1
    pool_choice_9[47]  R1223     -1
    pool_choice_9[47]  R1225     -1
    pool_choice_9[47]  R1226     -1
    pool_choice_9[47]  pool_cover_C88_order_p  1
    pool_choice_9[47]  pool_cover_C76_order_p  1
    pool_choice_9[47]  pool_cover_C47_order_p  1
    pool_choice_9[47]  R1715     -1
    pool_choice_9[47]  R1725     -1
    pool_choice_9[48]  OBJ       5.0439375535867129e+01
    pool_choice_9[48]  R1189     1
    pool_choice_9[48]  R1190     -60
    pool_choice_9[48]  R1198     -1
    pool_choice_9[48]  R1209     -1
    pool_choice_9[48]  R1225     -1
    pool_choice_9[48]  R1226     -1
    pool_choice_9[48]  R1227     -1
    pool_choice_9[48]  R1231     -1
    pool_choice_9[48]  pool_cover_C76_order_d  1
    pool_choice_9[48]  pool_cover_C76_order_p  1
    pool_choice_9[48]  pool_cover_C27_order_d  1
    pool_choice_9[48]  pool_cover_C27_order_p  1
    pool_choice_9[48]  pool_cover_C47_order_p  1
    pool_choice_9[48]  R1705     -1
    pool_choice_9[48]  R1715     -1
    pool_choice_9[48]  R1726     -1
    pool_choice_9[48]  R1727     -1
    pool_choice_9[48]  R1791     -60
    pool_choice_9[49]  OBJ       4.9396356140913873e+01
    pool_choice_9[49]  R1189     1
    pool_choice_9[49]  R1190     -60
    pool_choice_9[49]  R1206     -1
    pool_choice_9[49]  R1217     -1
    pool_choice_9[49]  R1233     -1
    pool_choice_9[49]  pool_cover_C25_order_d  1
    pool_choice_9[49]  R1791     -60
    pool_choice_9[50]  OBJ       3.1747081387645608e+01
    pool_choice_9[50]  R1189     1
    pool_choice_9[50]  R1190     -60
    pool_choice_9[50]  R1200     -1
    pool_choice_9[50]  R1208     -1
    pool_choice_9[50]  R1224     -1
    pool_choice_9[50]  R1233     -1
    pool_choice_9[50]  pool_cover_C47_order_d  1
    pool_choice_9[50]  pool_cover_C29_order_p  1
    pool_choice_9[50]  R1728     -1
    pool_choice_9[50]  R1791     -60
    pool_choice_9[51]  OBJ       7.5601410152021032e+01
    pool_choice_9[51]  R1189     1
    pool_choice_9[51]  R1190     -60
    pool_choice_9[51]  R1197     -1
    pool_choice_9[51]  R1216     -1
    pool_choice_9[51]  R1230     -1
    pool_choice_9[51]  R1232     -1
    pool_choice_9[51]  pool_cover_C29_order_d  1
    pool_choice_9[51]  pool_cover_C6_order_d  1
    pool_choice_9[51]  pool_cover_C6_order_p  1
    pool_choice_9[51]  R1708     -1
    pool_choice_9[51]  R1713     -1
    pool_choice_9[51]  R1791     -60
    pool_choice_9[52]  OBJ       2.8987894208396355e+01
    pool_choice_9[52]  R1189     1
    pool_choice_9[52]  R1199     -1
    pool_choice_9[52]  R1209     -1
    pool_choice_9[52]  R1223     -1
    pool_choice_9[52]  R1225     -1
    pool_choice_9[52]  pool_cover_C88_order_p  1
    pool_choice_9[52]  pool_cover_C47_order_p  1
    pool_choice_9[52]  R1722     -1
    pool_choice_9[53]  OBJ       2.6076809620810597e+01
    pool_choice_9[53]  R1189     1
    pool_choice_9[53]  R1190     -60
    pool_choice_9[53]  R1198     -1
    pool_choice_9[53]  R1220     -1
    pool_choice_9[53]  R1231     -1
    pool_choice_9[53]  pool_cover_C76_order_d  1
    pool_choice_9[53]  R1791     -60
    pool_choice_9[54]  OBJ       2.0654115613359256e+01
    pool_choice_9[54]  R1189     1
    pool_choice_9[54]  R1190     -60
    pool_choice_9[54]  R1196     -1
    pool_choice_9[54]  R1208     -1
    pool_choice_9[54]  R1224     -1
    pool_choice_9[54]  R1231     -1
    pool_choice_9[54]  pool_cover_C88_order_d  1
    pool_choice_9[54]  pool_cover_C29_order_p  1
    pool_choice_9[54]  R1729     -1
    pool_choice_9[54]  R1791     -60
    pool_choice_9[55]  OBJ       6.2032249677083293e+01
    pool_choice_9[55]  R1189     1
    pool_choice_9[55]  R1190     -60
    pool_choice_9[55]  R1201     -1
    pool_choice_9[55]  R1222     -1
    pool_choice_9[55]  R1233     -1
    pool_choice_9[55]  pool_cover_C46_order_d  1
    pool_choice_9[55]  R1791     -60
    pool_choice_9[56]  OBJ       8.1575595302846423e+01
    pool_choice_9[56]  R1189     1
    pool_choice_9[56]  R1190     -60
    pool_choice_9[56]  R1200     -1
    pool_choice_9[56]  R1208     -1
    pool_choice_9[56]  R1224     -1
    pool_choice_9[56]  R1229     -1
    pool_choice_9[56]  R1230     -1
    pool_choice_9[56]  R1233     -1
    pool_choice_9[56]  pool_cover_C47_order_d  1
    pool_choice_9[56]  pool_cover_C46_order_d  1
    pool_choice_9[56]  pool_cover_C46_order_p  1
    pool_choice_9[56]  pool_cover_C29_order_p  1
    pool_choice_9[56]  pool_cover_C6_order_p  1
    pool_choice_9[56]  R1707     -1
    pool_choice_9[56]  R1714     -1
    pool_choice_9[56]  R1718     -1
    pool_choice_9[56]  R1730     -1
    pool_choice_9[56]  R1791     -60
    pool_choice_9[57]  OBJ       8.7673299606967689e+01
    pool_choice_9[57]  R1189     1
    pool_choice_9[57]  R1190     -60
    pool_choice_9[57]  R1197     -1
    pool_choice_9[57]  R1208     -1
    pool_choice_9[57]  R1224     -1
    pool_choice_9[57]  R1232     -1
    pool_choice_9[57]  pool_cover_C29_order_d  1
    pool_choice_9[57]  pool_cover_C29_order_p  1
    pool_choice_9[57]  pool_cover_C6_order_d  1
    pool_choice_9[57]  R1713     -1
    pool_choice_9[57]  R1731     -1
    pool_choice_9[57]  R1791     -60
    pool_used_9  R1189     -1
    pool_used_9  R1190     -28800
    pool_used_9  R1191     -75600
    pool_used_9  R1192     -75540
    pool_used_9  R1193     -1
    pool_used_9  R1194     -80
    pool_used_9  R1195     -80
    pool_used_9  R1791     -75660
    pool_used_9  R1792     -81
    pool_used_9  R1797     -75660
    pool_used_9  R1798     -81
    pool_used_9  R1799     -75660
    pool_used_9  R1800     -81
    pool_start_9  R1190     1
    pool_start_9  R1191     1
    pool_start_9  R1791     1
    pool_start_9  GC765     -1
    pool_start_9  GC767     -1
    pool_start_9  GC769     -1
    pool_start_9  GC771     -1
    pool_start_9  GC773     -1
    pool_start_9  GC775     -1
    pool_start_9  GC777     -1
    pool_start_9  GC779     -1
    pool_start_9  GC781     -1
    pool_start_9  GC783     -1
    pool_start_9  GC785     -1
    pool_start_9  GC827     1
    pool_start_9  GC828     1
    pool_start_9  GC829     1
    pool_end_9  R1192     1
    pool_end_9  R1797     -1
    pool_end_9  R1799     -1
    pool_end_9  GC787     1
    pool_end_9  GC789     1
    pool_end_9  GC791     1
    pool_end_9  GC793     1
    pool_end_9  GC795     1
    pool_end_9  GC797     1
    pool_end_9  GC799     1
    pool_end_9  GC801     1
    pool_end_9  GC803     1
    pool_end_9  GC805     1
    pool_end_9  GC807     1
    pool_end_9  GC809     1
    pool_end_9  GC811     1
    pool_end_9  GC813     1
    pool_end_9  GC815     1
    pool_end_9  GC817     1
    pool_end_9  GC819     -1
    pool_end_9  GC820     -1
    pool_end_9  GC821     -1
    pool_end_9  GC822     -1
    pool_end_9  GC823     -1
    pool_end_9  GC824     -1
    pool_end_9  GC825     -1
    pool_end_9  GC826     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_9  R1193     1
    pool_start_rank_9  R1194     1
    pool_start_rank_9  R1792     1
    pool_start_rank_9  GC766     -1
    pool_start_rank_9  GC768     -1
    pool_start_rank_9  GC770     -1
    pool_start_rank_9  GC772     -1
    pool_start_rank_9  GC774     -1
    pool_start_rank_9  GC776     -1
    pool_start_rank_9  GC778     -1
    pool_start_rank_9  GC780     -1
    pool_start_rank_9  GC782     -1
    pool_start_rank_9  GC784     -1
    pool_start_rank_9  GC786     -1
    pool_end_rank_9  R1195     1
    pool_end_rank_9  R1798     -1
    pool_end_rank_9  R1800     -1
    pool_end_rank_9  GC788     1
    pool_end_rank_9  GC790     1
    pool_end_rank_9  GC792     1
    pool_end_rank_9  GC794     1
    pool_end_rank_9  GC796     1
    pool_end_rank_9  GC798     1
    pool_end_rank_9  GC800     1
    pool_end_rank_9  GC802     1
    pool_end_rank_9  GC804     1
    pool_end_rank_9  GC806     1
    pool_end_rank_9  GC808     1
    pool_end_rank_9  GC810     1
    pool_end_rank_9  GC812     1
    pool_end_rank_9  GC814     1
    pool_end_rank_9  GC816     1
    pool_end_rank_9  GC818     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_9_C88_order_d  R1196     1
    pool_first_9_C29_order_d  R1197     1
    pool_first_9_C76_order_d  R1198     1
    pool_first_9_C88_order_p  R1199     1
    pool_first_9_C47_order_d  R1200     1
    pool_first_9_C46_order_d  R1201     1
    pool_first_9_C6_order_d  R1202     1
    pool_first_9_C47_order_p  R1203     1
    pool_first_9_C76_order_p  R1204     1
    pool_first_9_C27_order_d  R1205     1
    pool_first_9_C25_order_d  R1206     1
    pool_last_9_C88_order_p  R1207     1
    pool_last_9_C29_order_p  R1208     1
    pool_last_9_C47_order_p  R1209     1
    pool_last_9_C76_order_p  R1210     1
    pool_last_9_C88_order_d  R1211     1
    pool_last_9_C27_order_p  R1212     1
    pool_last_9_C25_order_p  R1213     1
    pool_last_9_C46_order_p  R1214     1
    pool_last_9_C27_order_d  R1215     1
    pool_last_9_C6_order_p  R1216     1
    pool_last_9_C25_order_d  R1217     1
    pool_last_9_C47_order_d  R1218     1
    pool_last_9_C29_order_d  R1219     1
    pool_last_9_C76_order_d  R1220     1
    pool_last_9_C6_order_d  R1221     1
    pool_last_9_C46_order_d  R1222     1
    pool_pickup_9_C88_order  R1223     1
    pool_pickup_9_C29_order  R1224     1
    pool_pickup_9_C47_order  R1225     1
    pool_pickup_9_C76_order  R1226     1
    pool_pickup_9_C27_order  R1227     1
    pool_pickup_9_C25_order  R1228     1
    pool_pickup_9_C46_order  R1229     1
    pool_pickup_9_C6_order  R1230     1
    pool_batch_9_b1  R1231     1
    pool_batch_9_b3  R1232     1
    pool_batch_9_b2  R1233     1
    pool_choice_10[0]  OBJ       4.9397828317917018e+01
    pool_choice_10[0]  R1234     1
    pool_choice_10[0]  R1235     -60
    pool_choice_10[0]  R1241     -1
    pool_choice_10[0]  R1252     -1
    pool_choice_10[0]  R1266     -1
    pool_choice_10[0]  R1267     -1
    pool_choice_10[0]  R1274     -1
    pool_choice_10[0]  pool_cover_C47_order_d  1
    pool_choice_10[0]  pool_cover_C47_order_p  1
    pool_choice_10[0]  pool_cover_C25_order_d  1
    pool_choice_10[0]  pool_cover_C25_order_p  1
    pool_choice_10[0]  R1706     -1
    pool_choice_10[0]  R1711     -1
    pool_choice_10[0]  R1719     -1
    pool_choice_10[0]  R1793     -60
    pool_choice_10[0]  R1797     -60
    pool_choice_10[1]  OBJ       1.1661903789690601e+01
    pool_choice_10[1]  R1234     1
    pool_choice_10[1]  R1235     -60
    pool_choice_10[1]  R1241     -1
    pool_choice_10[1]  R1252     -1
    pool_choice_10[1]  R1267     -1
    pool_choice_10[1]  R1274     -1
    pool_choice_10[1]  pool_cover_C47_order_d  1
    pool_choice_10[1]  pool_cover_C47_order_p  1
    pool_choice_10[1]  R1701     -1
    pool_choice_10[1]  R1793     -60
    pool_choice_10[1]  R1797     -60
    pool_choice_10[2]  OBJ       6.9483005915872027e+01
    pool_choice_10[2]  R1234     1
    pool_choice_10[2]  R1235     -60
    pool_choice_10[2]  R1241     -1
    pool_choice_10[2]  R1253     -1
    pool_choice_10[2]  R1266     -1
    pool_choice_10[2]  R1267     -1
    pool_choice_10[2]  R1268     -1
    pool_choice_10[2]  R1274     -1
    pool_choice_10[2]  pool_cover_C47_order_d  1
    pool_choice_10[2]  pool_cover_C47_order_p  1
    pool_choice_10[2]  pool_cover_C25_order_d  1
    pool_choice_10[2]  pool_cover_C25_order_p  1
    pool_choice_10[2]  pool_cover_C29_order_p  1
    pool_choice_10[2]  R1706     -1
    pool_choice_10[2]  R1711     -1
    pool_choice_10[2]  R1712     -1
    pool_choice_10[2]  R1719     -1
    pool_choice_10[2]  R1793     -60
    pool_choice_10[2]  R1797     -60
    pool_choice_10[3]  OBJ       4.9397092229415442e+01
    pool_choice_10[3]  R1234     1
    pool_choice_10[3]  R1235     -60
    pool_choice_10[3]  R1242     -1
    pool_choice_10[3]  R1252     -1
    pool_choice_10[3]  R1266     -1
    pool_choice_10[3]  R1267     -1
    pool_choice_10[3]  R1274     -1
    pool_choice_10[3]  pool_cover_C47_order_p  1
    pool_choice_10[3]  pool_cover_C25_order_d  1
    pool_choice_10[3]  pool_cover_C25_order_p  1
    pool_choice_10[3]  R1706     -1
    pool_choice_10[3]  R1719     -1
    pool_choice_10[3]  R1793     -60
    pool_choice_10[3]  R1797     -60
    pool_choice_10[4]  OBJ       4.9397092229415449e+01
    pool_choice_10[4]  R1234     1
    pool_choice_10[4]  R1235     -60
    pool_choice_10[4]  R1241     -1
    pool_choice_10[4]  R1254     -1
    pool_choice_10[4]  R1266     -1
    pool_choice_10[4]  R1274     -1
    pool_choice_10[4]  pool_cover_C47_order_d  1
    pool_choice_10[4]  pool_cover_C25_order_d  1
    pool_choice_10[4]  pool_cover_C25_order_p  1
    pool_choice_10[4]  R1706     -1
    pool_choice_10[4]  R1711     -1
    pool_choice_10[4]  R1793     -60
    pool_choice_10[4]  R1797     -60
    pool_choice_10[5]  OBJ       4.9397828317917018e+01
    pool_choice_10[5]  R1234     1
    pool_choice_10[5]  R1235     -60
    pool_choice_10[5]  R1241     -1
    pool_choice_10[5]  R1252     -1
    pool_choice_10[5]  R1267     -1
    pool_choice_10[5]  R1274     -1
    pool_choice_10[5]  pool_cover_C47_order_d  1
    pool_choice_10[5]  pool_cover_C47_order_p  1
    pool_choice_10[5]  pool_cover_C25_order_d  1
    pool_choice_10[5]  R1711     -1
    pool_choice_10[5]  R1743     -1
    pool_choice_10[5]  R1793     -60
    pool_choice_10[5]  R1797     -60
    pool_choice_10[6]  OBJ       4.9397828317917018e+01
    pool_choice_10[6]  R1234     1
    pool_choice_10[6]  R1235     -60
    pool_choice_10[6]  R1241     -1
    pool_choice_10[6]  R1252     -1
    pool_choice_10[6]  R1266     -1
    pool_choice_10[6]  R1267     -1
    pool_choice_10[6]  R1274     -1
    pool_choice_10[6]  pool_cover_C47_order_d  1
    pool_choice_10[6]  pool_cover_C47_order_p  1
    pool_choice_10[6]  pool_cover_C25_order_p  1
    pool_choice_10[6]  R1719     -1
    pool_choice_10[6]  R1744     -1
    pool_choice_10[6]  R1793     -60
    pool_choice_10[6]  R1797     -60
    pool_choice_10[7]  OBJ       6.6292841503586686e+01
    pool_choice_10[7]  R1234     1
    pool_choice_10[7]  R1235     -60
    pool_choice_10[7]  R1243     -1
    pool_choice_10[7]  R1252     -1
    pool_choice_10[7]  R1266     -1
    pool_choice_10[7]  R1267     -1
    pool_choice_10[7]  R1269     -1
    pool_choice_10[7]  R1275     -1
    pool_choice_10[7]  pool_cover_C88_order_d  1
    pool_choice_10[7]  pool_cover_C88_order_p  1
    pool_choice_10[7]  pool_cover_C47_order_p  1
    pool_choice_10[7]  pool_cover_C25_order_p  1
    pool_choice_10[7]  R1702     -1
    pool_choice_10[7]  R1719     -1
    pool_choice_10[7]  R1738     -1
    pool_choice_10[7]  R1793     -60
    pool_choice_10[7]  R1797     -60
    pool_choice_10[8]  OBJ       6.7231679747489821e+01
    pool_choice_10[8]  R1234     1
    pool_choice_10[8]  R1235     -60
    pool_choice_10[8]  R1241     -1
    pool_choice_10[8]  R1252     -1
    pool_choice_10[8]  R1267     -1
    pool_choice_10[8]  R1270     -1
    pool_choice_10[8]  R1274     -1
    pool_choice_10[8]  pool_cover_C47_order_d  1
    pool_choice_10[8]  pool_cover_C47_order_p  1
    pool_choice_10[8]  pool_cover_C46_order_d  1
    pool_choice_10[8]  pool_cover_C46_order_p  1
    pool_choice_10[8]  R1707     -1
    pool_choice_10[8]  R1718     -1
    pool_choice_10[8]  R1745     -1
    pool_choice_10[8]  R1793     -60
    pool_choice_10[8]  R1797     -60
    pool_choice_10[9]  OBJ       9.9994270880611083e+01
    pool_choice_10[9]  R1234     1
    pool_choice_10[9]  R1235     -60
    pool_choice_10[9]  R1241     -1
    pool_choice_10[9]  R1252     -1
    pool_choice_10[9]  R1266     -1
    pool_choice_10[9]  R1267     -1
    pool_choice_10[9]  R1270     -1
    pool_choice_10[9]  R1274     -1
    pool_choice_10[9]  pool_cover_C47_order_d  1
    pool_choice_10[9]  pool_cover_C47_order_p  1
    pool_choice_10[9]  pool_cover_C25_order_d  1
    pool_choice_10[9]  pool_cover_C25_order_p  1
    pool_choice_10[9]  pool_cover_C46_order_p  1
    pool_choice_10[9]  R1711     -1
    pool_choice_10[9]  R1719     -1
    pool_choice_10[9]  R1746     -1
    pool_choice_10[9]  R1747     -1
    pool_choice_10[9]  R1793     -60
    pool_choice_10[9]  R1797     -60
    pool_choice_10[10]  OBJ       8.1013260278847184e+01
    pool_choice_10[10]  R1234     1
    pool_choice_10[10]  R1235     -60
    pool_choice_10[10]  R1244     -1
    pool_choice_10[10]  R1252     -1
    pool_choice_10[10]  R1266     -1
    pool_choice_10[10]  R1267     -1
    pool_choice_10[10]  R1274     -1
    pool_choice_10[10]  pool_cover_C47_order_p  1
    pool_choice_10[10]  pool_cover_C25_order_d  1
    pool_choice_10[10]  pool_cover_C25_order_p  1
    pool_choice_10[10]  pool_cover_C46_order_d  1
    pool_choice_10[10]  R1706     -1
    pool_choice_10[10]  R1719     -1
    pool_choice_10[10]  R1748     -1
    pool_choice_10[10]  R1793     -60
    pool_choice_10[10]  R1797     -60
    pool_choice_10[11]  OBJ       8.1013260278847184e+01
    pool_choice_10[11]  R1234     1
    pool_choice_10[11]  R1235     -60
    pool_choice_10[11]  R1244     -1
    pool_choice_10[11]  R1252     -1
    pool_choice_10[11]  R1266     -1
    pool_choice_10[11]  R1267     -1
    pool_choice_10[11]  R1270     -1
    pool_choice_10[11]  R1274     -1
    pool_choice_10[11]  pool_cover_C47_order_p  1
    pool_choice_10[11]  pool_cover_C25_order_p  1
    pool_choice_10[11]  pool_cover_C46_order_d  1
    pool_choice_10[11]  pool_cover_C46_order_p  1
    pool_choice_10[11]  R1707     -1
    pool_choice_10[11]  R1719     -1
    pool_choice_10[11]  R1747     -1
    pool_choice_10[11]  R1793     -60
    pool_choice_10[11]  R1797     -60
    pool_choice_10[12]  OBJ       8.1013260278847184e+01
    pool_choice_10[12]  R1234     1
    pool_choice_10[12]  R1235     -60
    pool_choice_10[12]  R1241     -1
    pool_choice_10[12]  R1255     -1
    pool_choice_10[12]  R1266     -1
    pool_choice_10[12]  R1270     -1
    pool_choice_10[12]  R1274     -1
    pool_choice_10[12]  pool_cover_C47_order_d  1
    pool_choice_10[12]  pool_cover_C25_order_d  1
    pool_choice_10[12]  pool_cover_C25_order_p  1
    pool_choice_10[12]  pool_cover_C46_order_p  1
    pool_choice_10[12]  R1706     -1
    pool_choice_10[12]  R1711     -1
    pool_choice_10[12]  R1749     -1
    pool_choice_10[12]  R1793     -60
    pool_choice_10[12]  R1797     -60
    pool_choice_10[13]  OBJ       8.3612975314050445e+01
    pool_choice_10[13]  R1234     1
    pool_choice_10[13]  R1235     -60
    pool_choice_10[13]  R1241     -1
    pool_choice_10[13]  R1252     -1
    pool_choice_10[13]  R1267     -1
    pool_choice_10[13]  R1270     -1
    pool_choice_10[13]  R1274     -1
    pool_choice_10[13]  pool_cover_C47_order_d  1
    pool_choice_10[13]  pool_cover_C47_order_p  1
    pool_choice_10[13]  pool_cover_C25_order_d  1
    pool_choice_10[13]  pool_cover_C46_order_p  1
    pool_choice_10[13]  R1711     -1
    pool_choice_10[13]  R1745     -1
    pool_choice_10[13]  R1746     -1
    pool_choice_10[13]  R1793     -60
    pool_choice_10[13]  R1797     -60
    pool_choice_10[14]  OBJ       8.3612975314050445e+01
    pool_choice_10[14]  R1234     1
    pool_choice_10[14]  R1235     -60
    pool_choice_10[14]  R1241     -1
    pool_choice_10[14]  R1252     -1
    pool_choice_10[14]  R1266     -1
    pool_choice_10[14]  R1267     -1
    pool_choice_10[14]  R1274     -1
    pool_choice_10[14]  pool_cover_C47_order_d  1
    pool_choice_10[14]  pool_cover_C47_order_p  1
    pool_choice_10[14]  pool_cover_C25_order_p  1
    pool_choice_10[14]  pool_cover_C46_order_d  1
    pool_choice_10[14]  R1718     -1
    pool_choice_10[14]  R1719     -1
    pool_choice_10[14]  R1750     -1
    pool_choice_10[14]  R1793     -60
    pool_choice_10[14]  R1797     -60
    pool_choice_10[15]  OBJ       8.3612975314050445e+01
    pool_choice_10[15]  R1234     1
    pool_choice_10[15]  R1235     -60
    pool_choice_10[15]  R1241     -1
    pool_choice_10[15]  R1252     -1
    pool_choice_10[15]  R1266     -1
    pool_choice_10[15]  R1267     -1
    pool_choice_10[15]  R1270     -1
    pool_choice_10[15]  R1274     -1
    pool_choice_10[15]  pool_cover_C47_order_d  1
    pool_choice_10[15]  pool_cover_C47_order_p  1
    pool_choice_10[15]  pool_cover_C25_order_p  1
    pool_choice_10[15]  pool_cover_C46_order_p  1
    pool_choice_10[15]  R1719     -1
    pool_choice_10[15]  R1747     -1
    pool_choice_10[15]  R1751     -1
    pool_choice_10[15]  R1793     -60
    pool_choice_10[15]  R1797     -60
    pool_choice_10[16]  OBJ       1.0453780050462936e+02
    pool_choice_10[16]  R1234     1
    pool_choice_10[16]  R1235     -60
    pool_choice_10[16]  R1241     -1
    pool_choice_10[16]  R1256     -1
    pool_choice_10[16]  R1266     -1
    pool_choice_10[16]  R1267     -1
    pool_choice_10[16]  R1271     -1
    pool_choice_10[16]  R1274     -1
    pool_choice_10[16]  pool_cover_C47_order_d  1
    pool_choice_10[16]  pool_cover_C47_order_p  1
    pool_choice_10[16]  pool_cover_C25_order_d  1
    pool_choice_10[16]  pool_cover_C25_order_p  1
    pool_choice_10[16]  pool_cover_C6_order_p  1
    pool_choice_10[16]  R1706     -1
    pool_choice_10[16]  R1711     -1
    pool_choice_10[16]  R1719     -1
    pool_choice_10[16]  R1752     -1
    pool_choice_10[16]  R1793     -60
    pool_choice_10[16]  R1797     -60
    pool_choice_10[17]  OBJ       8.7133016757641855e+01
    pool_choice_10[17]  R1234     1
    pool_choice_10[17]  R1235     -60
    pool_choice_10[17]  R1241     -1
    pool_choice_10[17]  R1254     -1
    pool_choice_10[17]  R1266     -1
    pool_choice_10[17]  R1267     -1
    pool_choice_10[17]  R1274     -1
    pool_choice_10[17]  pool_cover_C47_order_d  1
    pool_choice_10[17]  pool_cover_C47_order_p  1
    pool_choice_10[17]  pool_cover_C25_order_d  1
    pool_choice_10[17]  pool_cover_C25_order_p  1
    pool_choice_10[17]  R1711     -1
    pool_choice_10[17]  R1743     -1
    pool_choice_10[17]  R1753     -1
    pool_choice_10[17]  R1793     -60
    pool_choice_10[17]  R1797     -60
    pool_choice_10[18]  OBJ       4.9396356140913873e+01
    pool_choice_10[18]  R1234     1
    pool_choice_10[18]  R1235     -60
    pool_choice_10[18]  R1242     -1
    pool_choice_10[18]  R1254     -1
    pool_choice_10[18]  R1266     -1
    pool_choice_10[18]  R1274     -1
    pool_choice_10[18]  pool_cover_C25_order_d  1
    pool_choice_10[18]  pool_cover_C25_order_p  1
    pool_choice_10[18]  R1706     -1
    pool_choice_10[18]  R1793     -60
    pool_choice_10[18]  R1797     -60
    pool_choice_10[19]  OBJ       1.1262869223977737e+02
    pool_choice_10[19]  R1234     1
    pool_choice_10[19]  R1235     -60
    pool_choice_10[19]  R1244     -1
    pool_choice_10[19]  R1255     -1
    pool_choice_10[19]  R1266     -1
    pool_choice_10[19]  R1270     -1
    pool_choice_10[19]  R1274     -1
    pool_choice_10[19]  pool_cover_C25_order_d  1
    pool_choice_10[19]  pool_cover_C25_order_p  1
    pool_choice_10[19]  pool_cover_C46_order_d  1
    pool_choice_10[19]  pool_cover_C46_order_p  1
    pool_choice_10[19]  R1706     -1
    pool_choice_10[19]  R1748     -1
    pool_choice_10[19]  R1749     -1
    pool_choice_10[19]  R1793     -60
    pool_choice_10[19]  R1797     -60
    pool_choice_10[20]  OBJ       2.0654115613359256e+01
    pool_choice_10[20]  R1234     1
    pool_choice_10[20]  R1245     -1
    pool_choice_10[20]  R1253     -1
    pool_choice_10[20]  R1268     -1
    pool_choice_10[20]  R1269     -1
    pool_choice_10[20]  pool_cover_C88_order_p  1
    pool_choice_10[20]  pool_cover_C29_order_p  1
    pool_choice_10[20]  R1709     -1
    pool_choice_10[21]  OBJ       1.7888543819998318e+01
    pool_choice_10[21]  R1234     1
    pool_choice_10[21]  R1235     -60
    pool_choice_10[21]  R1243     -1
    pool_choice_10[21]  R1257     -1
    pool_choice_10[21]  R1275     -1
    pool_choice_10[21]  pool_cover_C88_order_d  1
    pool_choice_10[21]  R1793     -60
    pool_choice_10[21]  R1797     -60
    pool_choice_10[22]  OBJ       2.0654115613359256e+01
    pool_choice_10[22]  R1234     1
    pool_choice_10[22]  R1235     -60
    pool_choice_10[22]  R1243     -1
    pool_choice_10[22]  R1253     -1
    pool_choice_10[22]  R1268     -1
    pool_choice_10[22]  R1269     -1
    pool_choice_10[22]  R1275     -1
    pool_choice_10[22]  pool_cover_C88_order_d  1
    pool_choice_10[22]  pool_cover_C88_order_p  1
    pool_choice_10[22]  pool_cover_C29_order_p  1
    pool_choice_10[22]  R1702     -1
    pool_choice_10[22]  R1709     -1
    pool_choice_10[22]  R1793     -60
    pool_choice_10[22]  R1797     -60
    pool_choice_10[23]  OBJ       1.1661903789690601e+01
    pool_choice_10[23]  R1234     1
    pool_choice_10[23]  R1235     -60
    pool_choice_10[23]  R1241     -1
    pool_choice_10[23]  R1258     -1
    pool_choice_10[23]  R1274     -1
    pool_choice_10[23]  pool_cover_C47_order_d  1
    pool_choice_10[23]  R1793     -60
    pool_choice_10[23]  R1797     -60
    pool_choice_10[24]  OBJ       20.591260281974
    pool_choice_10[24]  R1234     1
    pool_choice_10[24]  R1235     -60
    pool_choice_10[24]  R1246     -1
    pool_choice_10[24]  R1259     -1
    pool_choice_10[24]  R1276     -1
    pool_choice_10[24]  pool_cover_C29_order_d  1
    pool_choice_10[24]  R1793     -60
    pool_choice_10[24]  R1797     -60
    pool_choice_10[25]  OBJ       20.591260281974
    pool_choice_10[25]  R1234     1
    pool_choice_10[25]  R1235     -60
    pool_choice_10[25]  R1246     -1
    pool_choice_10[25]  R1253     -1
    pool_choice_10[25]  R1268     -1
    pool_choice_10[25]  R1276     -1
    pool_choice_10[25]  pool_cover_C29_order_d  1
    pool_choice_10[25]  pool_cover_C29_order_p  1
    pool_choice_10[25]  R1703     -1
    pool_choice_10[25]  R1793     -60
    pool_choice_10[25]  R1797     -60
    pool_choice_10[26]  OBJ       1.1661903789690601e+01
    pool_choice_10[26]  R1234     1
    pool_choice_10[26]  R1247     -1
    pool_choice_10[26]  R1252     -1
    pool_choice_10[26]  R1267     -1
    pool_choice_10[26]  pool_cover_C47_order_p  1
    pool_choice_10[27]  OBJ       41.2180607820758
    pool_choice_10[27]  R1234     1
    pool_choice_10[27]  R1235     -60
    pool_choice_10[27]  R1243     -1
    pool_choice_10[27]  R1260     -1
    pool_choice_10[27]  R1275     -1
    pool_choice_10[27]  pool_cover_C88_order_d  1
    pool_choice_10[27]  pool_cover_C76_order_d  1
    pool_choice_10[27]  R1710     -1
    pool_choice_10[27]  R1793     -60
    pool_choice_10[27]  R1797     -60
    pool_choice_10[28]  OBJ       1.7888543819998318e+01
    pool_choice_10[28]  R1234     1
    pool_choice_10[28]  R1235     -60
    pool_choice_10[28]  R1243     -1
    pool_choice_10[28]  R1261     -1
    pool_choice_10[28]  R1269     -1
    pool_choice_10[28]  R1275     -1
    pool_choice_10[28]  pool_cover_C88_order_d  1
    pool_choice_10[28]  pool_cover_C88_order_p  1
    pool_choice_10[28]  R1702     -1
    pool_choice_10[28]  R1793     -60
    pool_choice_10[28]  R1797     -60
    pool_choice_10[29]  OBJ       4.9397092229415449e+01
    pool_choice_10[29]  R1234     1
    pool_choice_10[29]  R1235     -60
    pool_choice_10[29]  R1241     -1
    pool_choice_10[29]  R1262     -1
    pool_choice_10[29]  R1274     -1
    pool_choice_10[29]  pool_cover_C47_order_d  1
    pool_choice_10[29]  pool_cover_C25_order_d  1
    pool_choice_10[29]  R1711     -1
    pool_choice_10[29]  R1793     -60
    pool_choice_10[29]  R1797     -60
    pool_choice_10[30]  OBJ       3.1747081387645608e+01
    pool_choice_10[30]  R1234     1
    pool_choice_10[30]  R1235     -60
    pool_choice_10[30]  R1241     -1
    pool_choice_10[30]  R1253     -1
    pool_choice_10[30]  R1267     -1
    pool_choice_10[30]  R1268     -1
    pool_choice_10[30]  R1274     -1
    pool_choice_10[30]  pool_cover_C47_order_d  1
    pool_choice_10[30]  pool_cover_C47_order_p  1
    pool_choice_10[30]  pool_cover_C29_order_p  1
    pool_choice_10[30]  R1701     -1
    pool_choice_10[30]  R1712     -1
    pool_choice_10[30]  R1793     -60
    pool_choice_10[30]  R1797     -60
    pool_choice_10[31]  OBJ       7.5601410152021032e+01
    pool_choice_10[31]  R1234     1
    pool_choice_10[31]  R1235     -60
    pool_choice_10[31]  R1246     -1
    pool_choice_10[31]  R1263     -1
    pool_choice_10[31]  R1276     -1
    pool_choice_10[31]  pool_cover_C29_order_d  1
    pool_choice_10[31]  pool_cover_C6_order_d  1
    pool_choice_10[31]  R1713     -1
    pool_choice_10[31]  R1793     -60
    pool_choice_10[31]  R1797     -60
    pool_choice_10[32]  OBJ       8.7673299606967689e+01
    pool_choice_10[32]  R1234     1
    pool_choice_10[32]  R1235     -60
    pool_choice_10[32]  R1246     -1
    pool_choice_10[32]  R1253     -1
    pool_choice_10[32]  R1268     -1
    pool_choice_10[32]  R1271     -1
    pool_choice_10[32]  R1276     -1
    pool_choice_10[32]  pool_cover_C29_order_d  1
    pool_choice_10[32]  pool_cover_C29_order_p  1
    pool_choice_10[32]  pool_cover_C6_order_d  1
    pool_choice_10[32]  pool_cover_C6_order_p  1
    pool_choice_10[32]  R1708     -1
    pool_choice_10[32]  R1713     -1
    pool_choice_10[32]  R1714     -1
    pool_choice_10[32]  R1793     -60
    pool_choice_10[32]  R1797     -60
    pool_choice_10[33]  OBJ       2.7115567956485918e+01
    pool_choice_10[33]  R1234     1
    pool_choice_10[33]  R1248     -1
    pool_choice_10[33]  R1252     -1
    pool_choice_10[33]  R1267     -1
    pool_choice_10[33]  R1272     -1
    pool_choice_10[33]  pool_cover_C76_order_p  1
    pool_choice_10[33]  pool_cover_C47_order_p  1
    pool_choice_10[33]  R1715     -1
    pool_choice_10[34]  OBJ       6.4531470933056056e+01
    pool_choice_10[34]  R1234     1
    pool_choice_10[34]  R1235     -60
    pool_choice_10[34]  R1243     -1
    pool_choice_10[34]  R1260     -1
    pool_choice_10[34]  R1275     -1
    pool_choice_10[34]  pool_cover_C88_order_d  1
    pool_choice_10[34]  pool_cover_C76_order_d  1
    pool_choice_10[34]  pool_cover_C27_order_d  1
    pool_choice_10[34]  R1716     -1
    pool_choice_10[34]  R1717     -1
    pool_choice_10[34]  R1793     -60
    pool_choice_10[34]  R1797     -60
    pool_choice_10[35]  OBJ       2.7115567956485918e+01
    pool_choice_10[35]  R1234     1
    pool_choice_10[35]  R1235     -60
    pool_choice_10[35]  R1249     -1
    pool_choice_10[35]  R1252     -1
    pool_choice_10[35]  R1267     -1
    pool_choice_10[35]  R1272     -1
    pool_choice_10[35]  R1275     -1
    pool_choice_10[35]  pool_cover_C76_order_d  1
    pool_choice_10[35]  pool_cover_C76_order_p  1
    pool_choice_10[35]  pool_cover_C47_order_p  1
    pool_choice_10[35]  R1704     -1
    pool_choice_10[35]  R1715     -1
    pool_choice_10[35]  R1793     -60
    pool_choice_10[35]  R1797     -60
    pool_choice_10[36]  OBJ       6.4631964712286560e+01
    pool_choice_10[36]  R1234     1
    pool_choice_10[36]  R1235     -60
    pool_choice_10[36]  R1241     -1
    pool_choice_10[36]  R1264     -1
    pool_choice_10[36]  R1274     -1
    pool_choice_10[36]  pool_cover_C47_order_d  1
    pool_choice_10[36]  pool_cover_C46_order_d  1
    pool_choice_10[36]  R1718     -1
    pool_choice_10[36]  R1793     -60
    pool_choice_10[36]  R1797     -60
    pool_choice_10[37]  OBJ       6.3529520697074361e+01
    pool_choice_10[37]  R1234     1
    pool_choice_10[37]  R1235     -60
    pool_choice_10[37]  R1250     -1
    pool_choice_10[37]  R1263     -1
    pool_choice_10[37]  R1276     -1
    pool_choice_10[37]  pool_cover_C6_order_d  1
    pool_choice_10[37]  R1793     -60
    pool_choice_10[37]  R1797     -60
    pool_choice_10[38]  OBJ       7.5601410152021018e+01
    pool_choice_10[38]  R1234     1
    pool_choice_10[38]  R1235     -60
    pool_choice_10[38]  R1250     -1
    pool_choice_10[38]  R1253     -1
    pool_choice_10[38]  R1268     -1
    pool_choice_10[38]  R1271     -1
    pool_choice_10[38]  R1276     -1
    pool_choice_10[38]  pool_cover_C29_order_p  1
    pool_choice_10[38]  pool_cover_C6_order_d  1
    pool_choice_10[38]  pool_cover_C6_order_p  1
    pool_choice_10[38]  R1708     -1
    pool_choice_10[38]  R1714     -1
    pool_choice_10[38]  R1793     -60
    pool_choice_10[38]  R1797     -60
    pool_choice_10[39]  OBJ       5.5723778079391167e+01
    pool_choice_10[39]  R1234     1
    pool_choice_10[39]  R1248     -1
    pool_choice_10[39]  R1252     -1
    pool_choice_10[39]  R1266     -1
    pool_choice_10[39]  R1267     -1
    pool_choice_10[39]  R1272     -1
    pool_choice_10[39]  R1273     -1
    pool_choice_10[39]  pool_cover_C76_order_p  1
    pool_choice_10[39]  pool_cover_C27_order_p  1
    pool_choice_10[39]  pool_cover_C47_order_p  1
    pool_choice_10[39]  pool_cover_C25_order_p  1
    pool_choice_10[39]  R1719     -1
    pool_choice_10[39]  R1720     -1
    pool_choice_10[39]  R1721     -1
    pool_choice_10[40]  OBJ       4.8741939160438513e+01
    pool_choice_10[40]  R1234     1
    pool_choice_10[40]  R1235     -60
    pool_choice_10[40]  R1251     -1
    pool_choice_10[40]  R1260     -1
    pool_choice_10[40]  R1275     -1
    pool_choice_10[40]  pool_cover_C76_order_d  1
    pool_choice_10[40]  pool_cover_C27_order_d  1
    pool_choice_10[40]  R1717     -1
    pool_choice_10[40]  R1793     -60
    pool_choice_10[40]  R1797     -60
    pool_choice_10[41]  OBJ       2.8987894208396355e+01
    pool_choice_10[41]  R1234     1
    pool_choice_10[41]  R1235     -60
    pool_choice_10[41]  R1243     -1
    pool_choice_10[41]  R1252     -1
    pool_choice_10[41]  R1267     -1
    pool_choice_10[41]  R1269     -1
    pool_choice_10[41]  R1275     -1
    pool_choice_10[41]  pool_cover_C88_order_d  1
    pool_choice_10[41]  pool_cover_C88_order_p  1
    pool_choice_10[41]  pool_cover_C47_order_p  1
    pool_choice_10[41]  R1702     -1
    pool_choice_10[41]  R1722     -1
    pool_choice_10[41]  R1793     -60
    pool_choice_10[41]  R1797     -60
    pool_choice_10[42]  OBJ       8.1012524190345616e+01
    pool_choice_10[42]  R1234     1
    pool_choice_10[42]  R1235     -60
    pool_choice_10[42]  R1242     -1
    pool_choice_10[42]  R1264     -1
    pool_choice_10[42]  R1274     -1
    pool_choice_10[42]  pool_cover_C25_order_d  1
    pool_choice_10[42]  pool_cover_C46_order_d  1
    pool_choice_10[42]  R1723     -1
    pool_choice_10[42]  R1793     -60
    pool_choice_10[42]  R1797     -60
    pool_choice_10[43]  OBJ       7.5601410152021032e+01
    pool_choice_10[43]  R1234     1
    pool_choice_10[43]  R1235     -60
    pool_choice_10[43]  R1246     -1
    pool_choice_10[43]  R1256     -1
    pool_choice_10[43]  R1268     -1
    pool_choice_10[43]  R1271     -1
    pool_choice_10[43]  R1276     -1
    pool_choice_10[43]  pool_cover_C29_order_d  1
    pool_choice_10[43]  pool_cover_C29_order_p  1
    pool_choice_10[43]  pool_cover_C6_order_p  1
    pool_choice_10[43]  R1703     -1
    pool_choice_10[43]  R1724     -1
    pool_choice_10[43]  R1793     -60
    pool_choice_10[43]  R1797     -60
    pool_choice_10[44]  OBJ       4.2256819117751121e+01
    pool_choice_10[44]  R1234     1
    pool_choice_10[44]  R1245     -1
    pool_choice_10[44]  R1252     -1
    pool_choice_10[44]  R1267     -1
    pool_choice_10[44]  R1269     -1
    pool_choice_10[44]  R1272     -1
    pool_choice_10[44]  pool_cover_C88_order_p  1
    pool_choice_10[44]  pool_cover_C76_order_p  1
    pool_choice_10[44]  pool_cover_C47_order_p  1
    pool_choice_10[44]  R1715     -1
    pool_choice_10[44]  R1725     -1
    pool_choice_10[45]  OBJ       4.8741939160438520e+01
    pool_choice_10[45]  R1234     1
    pool_choice_10[45]  R1235     -60
    pool_choice_10[45]  R1249     -1
    pool_choice_10[45]  R1265     -1
    pool_choice_10[45]  R1275     -1
    pool_choice_10[45]  pool_cover_C76_order_d  1
    pool_choice_10[45]  pool_cover_C27_order_d  1
    pool_choice_10[45]  R1726     -1
    pool_choice_10[45]  R1793     -60
    pool_choice_10[45]  R1797     -60
    pool_choice_10[46]  OBJ       5.0439375535867129e+01
    pool_choice_10[46]  R1234     1
    pool_choice_10[46]  R1235     -60
    pool_choice_10[46]  R1249     -1
    pool_choice_10[46]  R1252     -1
    pool_choice_10[46]  R1267     -1
    pool_choice_10[46]  R1272     -1
    pool_choice_10[46]  R1273     -1
    pool_choice_10[46]  R1275     -1
    pool_choice_10[46]  pool_cover_C76_order_d  1
    pool_choice_10[46]  pool_cover_C76_order_p  1
    pool_choice_10[46]  pool_cover_C27_order_d  1
    pool_choice_10[46]  pool_cover_C27_order_p  1
    pool_choice_10[46]  pool_cover_C47_order_p  1
    pool_choice_10[46]  R1705     -1
    pool_choice_10[46]  R1715     -1
    pool_choice_10[46]  R1726     -1
    pool_choice_10[46]  R1727     -1
    pool_choice_10[46]  R1793     -60
    pool_choice_10[46]  R1797     -60
    pool_choice_10[47]  OBJ       4.9396356140913873e+01
    pool_choice_10[47]  R1234     1
    pool_choice_10[47]  R1235     -60
    pool_choice_10[47]  R1242     -1
    pool_choice_10[47]  R1262     -1
    pool_choice_10[47]  R1274     -1
    pool_choice_10[47]  pool_cover_C25_order_d  1
    pool_choice_10[47]  R1793     -60
    pool_choice_10[47]  R1797     -60
    pool_choice_10[48]  OBJ       3.1747081387645608e+01
    pool_choice_10[48]  R1234     1
    pool_choice_10[48]  R1235     -60
    pool_choice_10[48]  R1241     -1
    pool_choice_10[48]  R1253     -1
    pool_choice_10[48]  R1268     -1
    pool_choice_10[48]  R1274     -1
    pool_choice_10[48]  pool_cover_C47_order_d  1
    pool_choice_10[48]  pool_cover_C29_order_p  1
    pool_choice_10[48]  R1728     -1
    pool_choice_10[48]  R1793     -60
    pool_choice_10[48]  R1797     -60
    pool_choice_10[49]  OBJ       7.5601410152021032e+01
    pool_choice_10[49]  R1234     1
    pool_choice_10[49]  R1235     -60
    pool_choice_10[49]  R1246     -1
    pool_choice_10[49]  R1256     -1
    pool_choice_10[49]  R1271     -1
    pool_choice_10[49]  R1276     -1
    pool_choice_10[49]  pool_cover_C29_order_d  1
    pool_choice_10[49]  pool_cover_C6_order_d  1
    pool_choice_10[49]  pool_cover_C6_order_p  1
    pool_choice_10[49]  R1708     -1
    pool_choice_10[49]  R1713     -1
    pool_choice_10[49]  R1793     -60
    pool_choice_10[49]  R1797     -60
    pool_choice_10[50]  OBJ       2.8987894208396355e+01
    pool_choice_10[50]  R1234     1
    pool_choice_10[50]  R1245     -1
    pool_choice_10[50]  R1252     -1
    pool_choice_10[50]  R1267     -1
    pool_choice_10[50]  R1269     -1
    pool_choice_10[50]  pool_cover_C88_order_p  1
    pool_choice_10[50]  pool_cover_C47_order_p  1
    pool_choice_10[50]  R1722     -1
    pool_choice_10[51]  OBJ       2.6076809620810597e+01
    pool_choice_10[51]  R1234     1
    pool_choice_10[51]  R1235     -60
    pool_choice_10[51]  R1249     -1
    pool_choice_10[51]  R1260     -1
    pool_choice_10[51]  R1275     -1
    pool_choice_10[51]  pool_cover_C76_order_d  1
    pool_choice_10[51]  R1793     -60
    pool_choice_10[51]  R1797     -60
    pool_used_10  R1234     -1
    pool_used_10  R1235     -28800
    pool_used_10  R1236     -75600
    pool_used_10  R1237     -75540
    pool_used_10  R1238     -1
    pool_used_10  R1239     -80
    pool_used_10  R1240     -80
    pool_used_10  R1793     -75660
    pool_used_10  R1794     -81
    pool_used_10  R1797     -75660
    pool_used_10  R1798     -81
    pool_used_10  R1801     -75660
    pool_used_10  R1802     -81
    pool_start_10  R1235     1
    pool_start_10  R1236     1
    pool_start_10  R1793     1
    pool_start_10  R1797     1
    pool_start_10  GC830     -1
    pool_start_10  GC832     -1
    pool_start_10  GC834     -1
    pool_start_10  GC836     -1
    pool_start_10  GC838     -1
    pool_start_10  GC840     -1
    pool_start_10  GC842     -1
    pool_start_10  GC844     -1
    pool_start_10  GC846     -1
    pool_start_10  GC848     -1
    pool_start_10  GC850     -1
    pool_start_10  GC888     1
    pool_start_10  GC889     1
    pool_start_10  GC890     1
    pool_end_10  R1237     1
    pool_end_10  R1801     -1
    pool_end_10  GC852     1
    pool_end_10  GC854     1
    pool_end_10  GC856     1
    pool_end_10  GC858     1
    pool_end_10  GC860     1
    pool_end_10  GC862     1
    pool_end_10  GC864     1
    pool_end_10  GC866     1
    pool_end_10  GC868     1
    pool_end_10  GC870     1
    pool_end_10  GC872     1
    pool_end_10  GC874     1
    pool_end_10  GC876     1
    pool_end_10  GC878     1
    pool_end_10  GC880     -1
    pool_end_10  GC881     -1
    pool_end_10  GC882     -1
    pool_end_10  GC883     -1
    pool_end_10  GC884     -1
    pool_end_10  GC885     -1
    pool_end_10  GC886     -1
    pool_end_10  GC887     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_10  R1238     1
    pool_start_rank_10  R1239     1
    pool_start_rank_10  R1794     1
    pool_start_rank_10  R1798     1
    pool_start_rank_10  GC831     -1
    pool_start_rank_10  GC833     -1
    pool_start_rank_10  GC835     -1
    pool_start_rank_10  GC837     -1
    pool_start_rank_10  GC839     -1
    pool_start_rank_10  GC841     -1
    pool_start_rank_10  GC843     -1
    pool_start_rank_10  GC845     -1
    pool_start_rank_10  GC847     -1
    pool_start_rank_10  GC849     -1
    pool_start_rank_10  GC851     -1
    pool_end_rank_10  R1240     1
    pool_end_rank_10  R1802     -1
    pool_end_rank_10  GC853     1
    pool_end_rank_10  GC855     1
    pool_end_rank_10  GC857     1
    pool_end_rank_10  GC859     1
    pool_end_rank_10  GC861     1
    pool_end_rank_10  GC863     1
    pool_end_rank_10  GC865     1
    pool_end_rank_10  GC867     1
    pool_end_rank_10  GC869     1
    pool_end_rank_10  GC871     1
    pool_end_rank_10  GC873     1
    pool_end_rank_10  GC875     1
    pool_end_rank_10  GC877     1
    pool_end_rank_10  GC879     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_10_C47_order_d  R1241     1
    pool_first_10_C25_order_d  R1242     1
    pool_first_10_C88_order_d  R1243     1
    pool_first_10_C46_order_d  R1244     1
    pool_first_10_C88_order_p  R1245     1
    pool_first_10_C29_order_d  R1246     1
    pool_first_10_C47_order_p  R1247     1
    pool_first_10_C76_order_p  R1248     1
    pool_first_10_C76_order_d  R1249     1
    pool_first_10_C6_order_d  R1250     1
    pool_first_10_C27_order_d  R1251     1
    pool_last_10_C47_order_p  R1252     1
    pool_last_10_C29_order_p  R1253     1
    pool_last_10_C25_order_p  R1254     1
    pool_last_10_C46_order_p  R1255     1
    pool_last_10_C6_order_p  R1256     1
    pool_last_10_C88_order_d  R1257     1
    pool_last_10_C47_order_d  R1258     1
    pool_last_10_C29_order_d  R1259     1
    pool_last_10_C76_order_d  R1260     1
    pool_last_10_C88_order_p  R1261     1
    pool_last_10_C25_order_d  R1262     1
    pool_last_10_C6_order_d  R1263     1
    pool_last_10_C46_order_d  R1264     1
    pool_last_10_C27_order_d  R1265     1
    pool_pickup_10_C25_order  R1266     1
    pool_pickup_10_C47_order  R1267     1
    pool_pickup_10_C29_order  R1268     1
    pool_pickup_10_C88_order  R1269     1
    pool_pickup_10_C46_order  R1270     1
    pool_pickup_10_C6_order  R1271     1
    pool_pickup_10_C76_order  R1272     1
    pool_pickup_10_C27_order  R1273     1
    pool_batch_10_b2  R1274     1
    pool_batch_10_b1  R1275     1
    pool_batch_10_b3  R1276     1
    pool_choice_11[0]  OBJ       20.591260281974
    pool_choice_11[0]  R1277     1
    pool_choice_11[0]  R1278     -60
    pool_choice_11[0]  R1284     -1
    pool_choice_11[0]  R1296     -1
    pool_choice_11[0]  R1309     -1
    pool_choice_11[0]  R1317     -1
    pool_choice_11[0]  pool_cover_C29_order_d  1
    pool_choice_11[0]  pool_cover_C29_order_p  1
    pool_choice_11[0]  R1703     -1
    pool_choice_11[0]  R1795     -60
    pool_choice_11[0]  R1799     -60
    pool_choice_11[0]  R1801     -60
    pool_choice_11[1]  OBJ       1.7888543819998318e+01
    pool_choice_11[1]  R1277     1
    pool_choice_11[1]  R1278     -60
    pool_choice_11[1]  R1285     -1
    pool_choice_11[1]  R1297     -1
    pool_choice_11[1]  R1310     -1
    pool_choice_11[1]  R1318     -1
    pool_choice_11[1]  pool_cover_C88_order_d  1
    pool_choice_11[1]  pool_cover_C88_order_p  1
    pool_choice_11[1]  R1702     -1
    pool_choice_11[1]  R1795     -60
    pool_choice_11[1]  R1799     -60
    pool_choice_11[1]  R1801     -60
    pool_choice_11[2]  OBJ       20.591260281974
    pool_choice_11[2]  R1277     1
    pool_choice_11[2]  R1278     -60
    pool_choice_11[2]  R1284     -1
    pool_choice_11[2]  R1298     -1
    pool_choice_11[2]  R1317     -1
    pool_choice_11[2]  pool_cover_C29_order_d  1
    pool_choice_11[2]  R1795     -60
    pool_choice_11[2]  R1799     -60
    pool_choice_11[2]  R1801     -60
    pool_choice_11[3]  OBJ       20.591260281974
    pool_choice_11[3]  R1277     1
    pool_choice_11[3]  R1286     -1
    pool_choice_11[3]  R1296     -1
    pool_choice_11[3]  R1309     -1
    pool_choice_11[3]  pool_cover_C29_order_p  1
    pool_choice_11[4]  OBJ       8.7673299606967689e+01
    pool_choice_11[4]  R1277     1
    pool_choice_11[4]  R1278     -60
    pool_choice_11[4]  R1284     -1
    pool_choice_11[4]  R1296     -1
    pool_choice_11[4]  R1309     -1
    pool_choice_11[4]  R1311     -1
    pool_choice_11[4]  R1317     -1
    pool_choice_11[4]  pool_cover_C29_order_d  1
    pool_choice_11[4]  pool_cover_C29_order_p  1
    pool_choice_11[4]  pool_cover_C6_order_d  1
    pool_choice_11[4]  pool_cover_C6_order_p  1
    pool_choice_11[4]  R1708     -1
    pool_choice_11[4]  R1713     -1
    pool_choice_11[4]  R1714     -1
    pool_choice_11[4]  R1795     -60
    pool_choice_11[4]  R1799     -60
    pool_choice_11[4]  R1801     -60
    pool_choice_11[5]  OBJ       7.5601410152021032e+01
    pool_choice_11[5]  R1277     1
    pool_choice_11[5]  R1278     -60
    pool_choice_11[5]  R1284     -1
    pool_choice_11[5]  R1299     -1
    pool_choice_11[5]  R1309     -1
    pool_choice_11[5]  R1311     -1
    pool_choice_11[5]  R1317     -1
    pool_choice_11[5]  pool_cover_C29_order_d  1
    pool_choice_11[5]  pool_cover_C29_order_p  1
    pool_choice_11[5]  pool_cover_C6_order_p  1
    pool_choice_11[5]  R1703     -1
    pool_choice_11[5]  R1724     -1
    pool_choice_11[5]  R1795     -60
    pool_choice_11[5]  R1799     -60
    pool_choice_11[5]  R1801     -60
    pool_choice_11[6]  OBJ       8.7673299606967689e+01
    pool_choice_11[6]  R1277     1
    pool_choice_11[6]  R1278     -60
    pool_choice_11[6]  R1284     -1
    pool_choice_11[6]  R1296     -1
    pool_choice_11[6]  R1309     -1
    pool_choice_11[6]  R1317     -1
    pool_choice_11[6]  pool_cover_C29_order_d  1
    pool_choice_11[6]  pool_cover_C29_order_p  1
    pool_choice_11[6]  pool_cover_C6_order_d  1
    pool_choice_11[6]  R1713     -1
    pool_choice_11[6]  R1731     -1
    pool_choice_11[6]  R1795     -60
    pool_choice_11[6]  R1799     -60
    pool_choice_11[6]  R1801     -60
    pool_choice_11[7]  OBJ       6.2032249677083293e+01
    pool_choice_11[7]  R1277     1
    pool_choice_11[7]  R1278     -60
    pool_choice_11[7]  R1287     -1
    pool_choice_11[7]  R1300     -1
    pool_choice_11[7]  R1312     -1
    pool_choice_11[7]  R1319     -1
    pool_choice_11[7]  pool_cover_C46_order_d  1
    pool_choice_11[7]  pool_cover_C46_order_p  1
    pool_choice_11[7]  R1707     -1
    pool_choice_11[7]  R1795     -60
    pool_choice_11[7]  R1799     -60
    pool_choice_11[7]  R1801     -60
    pool_choice_11[8]  OBJ       6.3529520697074361e+01
    pool_choice_11[8]  R1277     1
    pool_choice_11[8]  R1278     -60
    pool_choice_11[8]  R1288     -1
    pool_choice_11[8]  R1299     -1
    pool_choice_11[8]  R1311     -1
    pool_choice_11[8]  R1317     -1
    pool_choice_11[8]  pool_cover_C6_order_d  1
    pool_choice_11[8]  pool_cover_C6_order_p  1
    pool_choice_11[8]  R1708     -1
    pool_choice_11[8]  R1795     -60
    pool_choice_11[8]  R1799     -60
    pool_choice_11[8]  R1801     -60
    pool_choice_11[9]  OBJ       1.4268344947701470e+02
    pool_choice_11[9]  R1277     1
    pool_choice_11[9]  R1278     -60
    pool_choice_11[9]  R1284     -1
    pool_choice_11[9]  R1299     -1
    pool_choice_11[9]  R1309     -1
    pool_choice_11[9]  R1311     -1
    pool_choice_11[9]  R1317     -1
    pool_choice_11[9]  pool_cover_C29_order_d  1
    pool_choice_11[9]  pool_cover_C29_order_p  1
    pool_choice_11[9]  pool_cover_C6_order_d  1
    pool_choice_11[9]  pool_cover_C6_order_p  1
    pool_choice_11[9]  R1713     -1
    pool_choice_11[9]  R1724     -1
    pool_choice_11[9]  R1731     -1
    pool_choice_11[9]  R1795     -60
    pool_choice_11[9]  R1799     -60
    pool_choice_11[9]  R1801     -60
    pool_choice_11[10]  OBJ       7.5601410152021018e+01
    pool_choice_11[10]  R1277     1
    pool_choice_11[10]  R1278     -60
    pool_choice_11[10]  R1288     -1
    pool_choice_11[10]  R1296     -1
    pool_choice_11[10]  R1309     -1
    pool_choice_11[10]  R1317     -1
    pool_choice_11[10]  pool_cover_C29_order_p  1
    pool_choice_11[10]  pool_cover_C6_order_d  1
    pool_choice_11[10]  R1731     -1
    pool_choice_11[10]  R1795     -60
    pool_choice_11[10]  R1799     -60
    pool_choice_11[10]  R1801     -60
    pool_choice_11[11]  OBJ       7.5601410152021032e+01
    pool_choice_11[11]  R1277     1
    pool_choice_11[11]  R1278     -60
    pool_choice_11[11]  R1284     -1
    pool_choice_11[11]  R1301     -1
    pool_choice_11[11]  R1317     -1
    pool_choice_11[11]  pool_cover_C29_order_d  1
    pool_choice_11[11]  pool_cover_C6_order_d  1
    pool_choice_11[11]  R1713     -1
    pool_choice_11[11]  R1795     -60
    pool_choice_11[11]  R1799     -60
    pool_choice_11[11]  R1801     -60
    pool_choice_11[12]  OBJ       7.5601410152021032e+01
    pool_choice_11[12]  R1277     1
    pool_choice_11[12]  R1278     -60
    pool_choice_11[12]  R1284     -1
    pool_choice_11[12]  R1299     -1
    pool_choice_11[12]  R1311     -1
    pool_choice_11[12]  R1317     -1
    pool_choice_11[12]  pool_cover_C29_order_d  1
    pool_choice_11[12]  pool_cover_C6_order_p  1
    pool_choice_11[12]  R1754     -1
    pool_choice_11[12]  R1795     -60
    pool_choice_11[12]  R1799     -60
    pool_choice_11[12]  R1801     -60
    pool_choice_11[13]  OBJ       2.0654115613359256e+01
    pool_choice_11[13]  R1277     1
    pool_choice_11[13]  R1289     -1
    pool_choice_11[13]  R1296     -1
    pool_choice_11[13]  R1309     -1
    pool_choice_11[13]  R1310     -1
    pool_choice_11[13]  pool_cover_C88_order_p  1
    pool_choice_11[13]  pool_cover_C29_order_p  1
    pool_choice_11[13]  R1709     -1
    pool_choice_11[14]  OBJ       1.7888543819998318e+01
    pool_choice_11[14]  R1277     1
    pool_choice_11[14]  R1278     -60
    pool_choice_11[14]  R1285     -1
    pool_choice_11[14]  R1302     -1
    pool_choice_11[14]  R1318     -1
    pool_choice_11[14]  pool_cover_C88_order_d  1
    pool_choice_11[14]  R1795     -60
    pool_choice_11[14]  R1799     -60
    pool_choice_11[14]  R1801     -60
    pool_choice_11[15]  OBJ       2.0654115613359256e+01
    pool_choice_11[15]  R1277     1
    pool_choice_11[15]  R1278     -60
    pool_choice_11[15]  R1285     -1
    pool_choice_11[15]  R1296     -1
    pool_choice_11[15]  R1309     -1
    pool_choice_11[15]  R1310     -1
    pool_choice_11[15]  R1318     -1
    pool_choice_11[15]  pool_cover_C88_order_d  1
    pool_choice_11[15]  pool_cover_C88_order_p  1
    pool_choice_11[15]  pool_cover_C29_order_p  1
    pool_choice_11[15]  R1702     -1
    pool_choice_11[15]  R1709     -1
    pool_choice_11[15]  R1795     -60
    pool_choice_11[15]  R1799     -60
    pool_choice_11[15]  R1801     -60
    pool_choice_11[16]  OBJ       1.1661903789690601e+01
    pool_choice_11[16]  R1277     1
    pool_choice_11[16]  R1278     -60
    pool_choice_11[16]  R1290     -1
    pool_choice_11[16]  R1303     -1
    pool_choice_11[16]  R1319     -1
    pool_choice_11[16]  pool_cover_C47_order_d  1
    pool_choice_11[16]  R1795     -60
    pool_choice_11[16]  R1799     -60
    pool_choice_11[16]  R1801     -60
    pool_choice_11[17]  OBJ       1.1661903789690601e+01
    pool_choice_11[17]  R1277     1
    pool_choice_11[17]  R1278     -60
    pool_choice_11[17]  R1290     -1
    pool_choice_11[17]  R1304     -1
    pool_choice_11[17]  R1313     -1
    pool_choice_11[17]  R1319     -1
    pool_choice_11[17]  pool_cover_C47_order_d  1
    pool_choice_11[17]  pool_cover_C47_order_p  1
    pool_choice_11[17]  R1701     -1
    pool_choice_11[17]  R1795     -60
    pool_choice_11[17]  R1799     -60
    pool_choice_11[17]  R1801     -60
    pool_choice_11[18]  OBJ       1.1661903789690601e+01
    pool_choice_11[18]  R1277     1
    pool_choice_11[18]  R1291     -1
    pool_choice_11[18]  R1304     -1
    pool_choice_11[18]  R1313     -1
    pool_choice_11[18]  pool_cover_C47_order_p  1
    pool_choice_11[19]  OBJ       41.2180607820758
    pool_choice_11[19]  R1277     1
    pool_choice_11[19]  R1278     -60
    pool_choice_11[19]  R1285     -1
    pool_choice_11[19]  R1305     -1
    pool_choice_11[19]  R1318     -1
    pool_choice_11[19]  pool_cover_C88_order_d  1
    pool_choice_11[19]  pool_cover_C76_order_d  1
    pool_choice_11[19]  R1710     -1
    pool_choice_11[19]  R1795     -60
    pool_choice_11[19]  R1799     -60
    pool_choice_11[19]  R1801     -60
    pool_choice_11[20]  OBJ       4.9397092229415449e+01
    pool_choice_11[20]  R1277     1
    pool_choice_11[20]  R1278     -60
    pool_choice_11[20]  R1290     -1
    pool_choice_11[20]  R1306     -1
    pool_choice_11[20]  R1319     -1
    pool_choice_11[20]  pool_cover_C47_order_d  1
    pool_choice_11[20]  pool_cover_C25_order_d  1
    pool_choice_11[20]  R1711     -1
    pool_choice_11[20]  R1795     -60
    pool_choice_11[20]  R1799     -60
    pool_choice_11[20]  R1801     -60
    pool_choice_11[21]  OBJ       3.1747081387645608e+01
    pool_choice_11[21]  R1277     1
    pool_choice_11[21]  R1278     -60
    pool_choice_11[21]  R1290     -1
    pool_choice_11[21]  R1296     -1
    pool_choice_11[21]  R1309     -1
    pool_choice_11[21]  R1313     -1
    pool_choice_11[21]  R1319     -1
    pool_choice_11[21]  pool_cover_C47_order_d  1
    pool_choice_11[21]  pool_cover_C47_order_p  1
    pool_choice_11[21]  pool_cover_C29_order_p  1
    pool_choice_11[21]  R1701     -1
    pool_choice_11[21]  R1712     -1
    pool_choice_11[21]  R1795     -60
    pool_choice_11[21]  R1799     -60
    pool_choice_11[21]  R1801     -60
    pool_choice_11[22]  OBJ       2.7115567956485918e+01
    pool_choice_11[22]  R1277     1
    pool_choice_11[22]  R1292     -1
    pool_choice_11[22]  R1304     -1
    pool_choice_11[22]  R1313     -1
    pool_choice_11[22]  R1314     -1
    pool_choice_11[22]  pool_cover_C76_order_p  1
    pool_choice_11[22]  pool_cover_C47_order_p  1
    pool_choice_11[22]  R1715     -1
    pool_choice_11[23]  OBJ       6.4531470933056056e+01
    pool_choice_11[23]  R1277     1
    pool_choice_11[23]  R1278     -60
    pool_choice_11[23]  R1285     -1
    pool_choice_11[23]  R1305     -1
    pool_choice_11[23]  R1318     -1
    pool_choice_11[23]  pool_cover_C88_order_d  1
    pool_choice_11[23]  pool_cover_C76_order_d  1
    pool_choice_11[23]  pool_cover_C27_order_d  1
    pool_choice_11[23]  R1716     -1
    pool_choice_11[23]  R1717     -1
    pool_choice_11[23]  R1795     -60
    pool_choice_11[23]  R1799     -60
    pool_choice_11[23]  R1801     -60
    pool_choice_11[24]  OBJ       2.7115567956485918e+01
    pool_choice_11[24]  R1277     1
    pool_choice_11[24]  R1278     -60
    pool_choice_11[24]  R1293     -1
    pool_choice_11[24]  R1304     -1
    pool_choice_11[24]  R1313     -1
    pool_choice_11[24]  R1314     -1
    pool_choice_11[24]  R1318     -1
    pool_choice_11[24]  pool_cover_C76_order_d  1
    pool_choice_11[24]  pool_cover_C76_order_p  1
    pool_choice_11[24]  pool_cover_C47_order_p  1
    pool_choice_11[24]  R1704     -1
    pool_choice_11[24]  R1715     -1
    pool_choice_11[24]  R1795     -60
    pool_choice_11[24]  R1799     -60
    pool_choice_11[24]  R1801     -60
    pool_choice_11[25]  OBJ       6.4631964712286560e+01
    pool_choice_11[25]  R1277     1
    pool_choice_11[25]  R1278     -60
    pool_choice_11[25]  R1290     -1
    pool_choice_11[25]  R1307     -1
    pool_choice_11[25]  R1319     -1
    pool_choice_11[25]  pool_cover_C47_order_d  1
    pool_choice_11[25]  pool_cover_C46_order_d  1
    pool_choice_11[25]  R1718     -1
    pool_choice_11[25]  R1795     -60
    pool_choice_11[25]  R1799     -60
    pool_choice_11[25]  R1801     -60
    pool_choice_11[26]  OBJ       4.9397828317917018e+01
    pool_choice_11[26]  R1277     1
    pool_choice_11[26]  R1278     -60
    pool_choice_11[26]  R1290     -1
    pool_choice_11[26]  R1304     -1
    pool_choice_11[26]  R1313     -1
    pool_choice_11[26]  R1315     -1
    pool_choice_11[26]  R1319     -1
    pool_choice_11[26]  pool_cover_C47_order_d  1
    pool_choice_11[26]  pool_cover_C47_order_p  1
    pool_choice_11[26]  pool_cover_C25_order_d  1
    pool_choice_11[26]  pool_cover_C25_order_p  1
    pool_choice_11[26]  R1706     -1
    pool_choice_11[26]  R1711     -1
    pool_choice_11[26]  R1719     -1
    pool_choice_11[26]  R1795     -60
    pool_choice_11[26]  R1799     -60
    pool_choice_11[26]  R1801     -60
    pool_choice_11[27]  OBJ       6.3529520697074361e+01
    pool_choice_11[27]  R1277     1
    pool_choice_11[27]  R1278     -60
    pool_choice_11[27]  R1288     -1
    pool_choice_11[27]  R1301     -1
    pool_choice_11[27]  R1317     -1
    pool_choice_11[27]  pool_cover_C6_order_d  1
    pool_choice_11[27]  R1795     -60
    pool_choice_11[27]  R1799     -60
    pool_choice_11[27]  R1801     -60
    pool_choice_11[28]  OBJ       7.5601410152021018e+01
    pool_choice_11[28]  R1277     1
    pool_choice_11[28]  R1278     -60
    pool_choice_11[28]  R1288     -1
    pool_choice_11[28]  R1296     -1
    pool_choice_11[28]  R1309     -1
    pool_choice_11[28]  R1311     -1
    pool_choice_11[28]  R1317     -1
    pool_choice_11[28]  pool_cover_C29_order_p  1
    pool_choice_11[28]  pool_cover_C6_order_d  1
    pool_choice_11[28]  pool_cover_C6_order_p  1
    pool_choice_11[28]  R1708     -1
    pool_choice_11[28]  R1714     -1
    pool_choice_11[28]  R1795     -60
    pool_choice_11[28]  R1799     -60
    pool_choice_11[28]  R1801     -60
    pool_choice_11[29]  OBJ       5.5723778079391167e+01
    pool_choice_11[29]  R1277     1
    pool_choice_11[29]  R1292     -1
    pool_choice_11[29]  R1304     -1
    pool_choice_11[29]  R1313     -1
    pool_choice_11[29]  R1314     -1
    pool_choice_11[29]  R1315     -1
    pool_choice_11[29]  R1316     -1
    pool_choice_11[29]  pool_cover_C76_order_p  1
    pool_choice_11[29]  pool_cover_C27_order_p  1
    pool_choice_11[29]  pool_cover_C47_order_p  1
    pool_choice_11[29]  pool_cover_C25_order_p  1
    pool_choice_11[29]  R1719     -1
    pool_choice_11[29]  R1720     -1
    pool_choice_11[29]  R1721     -1
    pool_choice_11[30]  OBJ       4.8741939160438513e+01
    pool_choice_11[30]  R1277     1
    pool_choice_11[30]  R1278     -60
    pool_choice_11[30]  R1294     -1
    pool_choice_11[30]  R1305     -1
    pool_choice_11[30]  R1318     -1
    pool_choice_11[30]  pool_cover_C76_order_d  1
    pool_choice_11[30]  pool_cover_C27_order_d  1
    pool_choice_11[30]  R1717     -1
    pool_choice_11[30]  R1795     -60
    pool_choice_11[30]  R1799     -60
    pool_choice_11[30]  R1801     -60
    pool_choice_11[31]  OBJ       2.8987894208396355e+01
    pool_choice_11[31]  R1277     1
    pool_choice_11[31]  R1278     -60
    pool_choice_11[31]  R1285     -1
    pool_choice_11[31]  R1304     -1
    pool_choice_11[31]  R1310     -1
    pool_choice_11[31]  R1313     -1
    pool_choice_11[31]  R1318     -1
    pool_choice_11[31]  pool_cover_C88_order_d  1
    pool_choice_11[31]  pool_cover_C88_order_p  1
    pool_choice_11[31]  pool_cover_C47_order_p  1
    pool_choice_11[31]  R1702     -1
    pool_choice_11[31]  R1722     -1
    pool_choice_11[31]  R1795     -60
    pool_choice_11[31]  R1799     -60
    pool_choice_11[31]  R1801     -60
    pool_choice_11[32]  OBJ       8.1012524190345616e+01
    pool_choice_11[32]  R1277     1
    pool_choice_11[32]  R1278     -60
    pool_choice_11[32]  R1295     -1
    pool_choice_11[32]  R1307     -1
    pool_choice_11[32]  R1319     -1
    pool_choice_11[32]  pool_cover_C25_order_d  1
    pool_choice_11[32]  pool_cover_C46_order_d  1
    pool_choice_11[32]  R1723     -1
    pool_choice_11[32]  R1795     -60
    pool_choice_11[32]  R1799     -60
    pool_choice_11[32]  R1801     -60
    pool_choice_11[33]  OBJ       6.9483005915872027e+01
    pool_choice_11[33]  R1277     1
    pool_choice_11[33]  R1278     -60
    pool_choice_11[33]  R1290     -1
    pool_choice_11[33]  R1296     -1
    pool_choice_11[33]  R1309     -1
    pool_choice_11[33]  R1313     -1
    pool_choice_11[33]  R1315     -1
    pool_choice_11[33]  R1319     -1
    pool_choice_11[33]  pool_cover_C47_order_d  1
    pool_choice_11[33]  pool_cover_C47_order_p  1
    pool_choice_11[33]  pool_cover_C25_order_d  1
    pool_choice_11[33]  pool_cover_C25_order_p  1
    pool_choice_11[33]  pool_cover_C29_order_p  1
    pool_choice_11[33]  R1706     -1
    pool_choice_11[33]  R1711     -1
    pool_choice_11[33]  R1712     -1
    pool_choice_11[33]  R1719     -1
    pool_choice_11[33]  R1795     -60
    pool_choice_11[33]  R1799     -60
    pool_choice_11[33]  R1801     -60
    pool_choice_11[34]  OBJ       4.2256819117751121e+01
    pool_choice_11[34]  R1277     1
    pool_choice_11[34]  R1289     -1
    pool_choice_11[34]  R1304     -1
    pool_choice_11[34]  R1310     -1
    pool_choice_11[34]  R1313     -1
    pool_choice_11[34]  R1314     -1
    pool_choice_11[34]  pool_cover_C88_order_p  1
    pool_choice_11[34]  pool_cover_C76_order_p  1
    pool_choice_11[34]  pool_cover_C47_order_p  1
    pool_choice_11[34]  R1715     -1
    pool_choice_11[34]  R1725     -1
    pool_choice_11[35]  OBJ       4.8741939160438520e+01
    pool_choice_11[35]  R1277     1
    pool_choice_11[35]  R1278     -60
    pool_choice_11[35]  R1293     -1
    pool_choice_11[35]  R1308     -1
    pool_choice_11[35]  R1318     -1
    pool_choice_11[35]  pool_cover_C76_order_d  1
    pool_choice_11[35]  pool_cover_C27_order_d  1
    pool_choice_11[35]  R1726     -1
    pool_choice_11[35]  R1795     -60
    pool_choice_11[35]  R1799     -60
    pool_choice_11[35]  R1801     -60
    pool_choice_11[36]  OBJ       5.0439375535867129e+01
    pool_choice_11[36]  R1277     1
    pool_choice_11[36]  R1278     -60
    pool_choice_11[36]  R1293     -1
    pool_choice_11[36]  R1304     -1
    pool_choice_11[36]  R1313     -1
    pool_choice_11[36]  R1314     -1
    pool_choice_11[36]  R1316     -1
    pool_choice_11[36]  R1318     -1
    pool_choice_11[36]  pool_cover_C76_order_d  1
    pool_choice_11[36]  pool_cover_C76_order_p  1
    pool_choice_11[36]  pool_cover_C27_order_d  1
    pool_choice_11[36]  pool_cover_C27_order_p  1
    pool_choice_11[36]  pool_cover_C47_order_p  1
    pool_choice_11[36]  R1705     -1
    pool_choice_11[36]  R1715     -1
    pool_choice_11[36]  R1726     -1
    pool_choice_11[36]  R1727     -1
    pool_choice_11[36]  R1795     -60
    pool_choice_11[36]  R1799     -60
    pool_choice_11[36]  R1801     -60
    pool_choice_11[37]  OBJ       4.9396356140913873e+01
    pool_choice_11[37]  R1277     1
    pool_choice_11[37]  R1278     -60
    pool_choice_11[37]  R1295     -1
    pool_choice_11[37]  R1306     -1
    pool_choice_11[37]  R1319     -1
    pool_choice_11[37]  pool_cover_C25_order_d  1
    pool_choice_11[37]  R1795     -60
    pool_choice_11[37]  R1799     -60
    pool_choice_11[37]  R1801     -60
    pool_choice_11[38]  OBJ       3.1747081387645608e+01
    pool_choice_11[38]  R1277     1
    pool_choice_11[38]  R1278     -60
    pool_choice_11[38]  R1290     -1
    pool_choice_11[38]  R1296     -1
    pool_choice_11[38]  R1309     -1
    pool_choice_11[38]  R1319     -1
    pool_choice_11[38]  pool_cover_C47_order_d  1
    pool_choice_11[38]  pool_cover_C29_order_p  1
    pool_choice_11[38]  R1728     -1
    pool_choice_11[38]  R1795     -60
    pool_choice_11[38]  R1799     -60
    pool_choice_11[38]  R1801     -60
    pool_choice_11[39]  OBJ       7.5601410152021032e+01
    pool_choice_11[39]  R1277     1
    pool_choice_11[39]  R1278     -60
    pool_choice_11[39]  R1284     -1
    pool_choice_11[39]  R1299     -1
    pool_choice_11[39]  R1311     -1
    pool_choice_11[39]  R1317     -1
    pool_choice_11[39]  pool_cover_C29_order_d  1
    pool_choice_11[39]  pool_cover_C6_order_d  1
    pool_choice_11[39]  pool_cover_C6_order_p  1
    pool_choice_11[39]  R1708     -1
    pool_choice_11[39]  R1713     -1
    pool_choice_11[39]  R1795     -60
    pool_choice_11[39]  R1799     -60
    pool_choice_11[39]  R1801     -60
    pool_choice_11[40]  OBJ       2.8987894208396355e+01
    pool_choice_11[40]  R1277     1
    pool_choice_11[40]  R1289     -1
    pool_choice_11[40]  R1304     -1
    pool_choice_11[40]  R1310     -1
    pool_choice_11[40]  R1313     -1
    pool_choice_11[40]  pool_cover_C88_order_p  1
    pool_choice_11[40]  pool_cover_C47_order_p  1
    pool_choice_11[40]  R1722     -1
    pool_choice_11[41]  OBJ       2.6076809620810597e+01
    pool_choice_11[41]  R1277     1
    pool_choice_11[41]  R1278     -60
    pool_choice_11[41]  R1293     -1
    pool_choice_11[41]  R1305     -1
    pool_choice_11[41]  R1318     -1
    pool_choice_11[41]  pool_cover_C76_order_d  1
    pool_choice_11[41]  R1795     -60
    pool_choice_11[41]  R1799     -60
    pool_choice_11[41]  R1801     -60
    pool_choice_11[42]  OBJ       2.0654115613359256e+01
    pool_choice_11[42]  R1277     1
    pool_choice_11[42]  R1278     -60
    pool_choice_11[42]  R1285     -1
    pool_choice_11[42]  R1296     -1
    pool_choice_11[42]  R1309     -1
    pool_choice_11[42]  R1318     -1
    pool_choice_11[42]  pool_cover_C88_order_d  1
    pool_choice_11[42]  pool_cover_C29_order_p  1
    pool_choice_11[42]  R1729     -1
    pool_choice_11[42]  R1795     -60
    pool_choice_11[42]  R1799     -60
    pool_choice_11[42]  R1801     -60
    pool_choice_11[43]  OBJ       6.2032249677083293e+01
    pool_choice_11[43]  R1277     1
    pool_choice_11[43]  R1278     -60
    pool_choice_11[43]  R1287     -1
    pool_choice_11[43]  R1307     -1
    pool_choice_11[43]  R1319     -1
    pool_choice_11[43]  pool_cover_C46_order_d  1
    pool_choice_11[43]  R1795     -60
    pool_choice_11[43]  R1799     -60
    pool_choice_11[43]  R1801     -60
    pool_choice_11[44]  OBJ       8.1575595302846423e+01
    pool_choice_11[44]  R1277     1
    pool_choice_11[44]  R1278     -60
    pool_choice_11[44]  R1290     -1
    pool_choice_11[44]  R1296     -1
    pool_choice_11[44]  R1309     -1
    pool_choice_11[44]  R1311     -1
    pool_choice_11[44]  R1312     -1
    pool_choice_11[44]  R1319     -1
    pool_choice_11[44]  pool_cover_C47_order_d  1
    pool_choice_11[44]  pool_cover_C46_order_d  1
    pool_choice_11[44]  pool_cover_C46_order_p  1
    pool_choice_11[44]  pool_cover_C29_order_p  1
    pool_choice_11[44]  pool_cover_C6_order_p  1
    pool_choice_11[44]  R1707     -1
    pool_choice_11[44]  R1714     -1
    pool_choice_11[44]  R1718     -1
    pool_choice_11[44]  R1730     -1
    pool_choice_11[44]  R1795     -60
    pool_choice_11[44]  R1799     -60
    pool_choice_11[44]  R1801     -60
    pool_used_11  R1277     -1
    pool_used_11  R1278     -28800
    pool_used_11  R1279     -75600
    pool_used_11  R1280     -75540
    pool_used_11  R1281     -1
    pool_used_11  R1282     -80
    pool_used_11  R1283     -80
    pool_used_11  R1795     -75660
    pool_used_11  R1796     -81
    pool_used_11  R1799     -75660
    pool_used_11  R1800     -81
    pool_used_11  R1801     -75660
    pool_used_11  R1802     -81
    pool_start_11  R1278     1
    pool_start_11  R1279     1
    pool_start_11  R1795     1
    pool_start_11  R1799     1
    pool_start_11  R1801     1
    pool_start_11  GC891     -1
    pool_start_11  GC893     -1
    pool_start_11  GC895     -1
    pool_start_11  GC897     -1
    pool_start_11  GC899     -1
    pool_start_11  GC901     -1
    pool_start_11  GC903     -1
    pool_start_11  GC905     -1
    pool_start_11  GC907     -1
    pool_start_11  GC909     -1
    pool_start_11  GC911     -1
    pool_start_11  GC913     -1
    pool_start_11  GC949     1
    pool_start_11  GC950     1
    pool_start_11  GC951     1
    pool_end_11  R1280     1
    pool_end_11  GC915     1
    pool_end_11  GC917     1
    pool_end_11  GC919     1
    pool_end_11  GC921     1
    pool_end_11  GC923     1
    pool_end_11  GC925     1
    pool_end_11  GC927     1
    pool_end_11  GC929     1
    pool_end_11  GC931     1
    pool_end_11  GC933     1
    pool_end_11  GC935     1
    pool_end_11  GC937     1
    pool_end_11  GC939     1
    pool_end_11  GC941     -1
    pool_end_11  GC942     -1
    pool_end_11  GC943     -1
    pool_end_11  GC944     -1
    pool_end_11  GC945     -1
    pool_end_11  GC946     -1
    pool_end_11  GC947     -1
    pool_end_11  GC948     -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_11  R1281     1
    pool_start_rank_11  R1282     1
    pool_start_rank_11  R1796     1
    pool_start_rank_11  R1800     1
    pool_start_rank_11  R1802     1
    pool_start_rank_11  GC892     -1
    pool_start_rank_11  GC894     -1
    pool_start_rank_11  GC896     -1
    pool_start_rank_11  GC898     -1
    pool_start_rank_11  GC900     -1
    pool_start_rank_11  GC902     -1
    pool_start_rank_11  GC904     -1
    pool_start_rank_11  GC906     -1
    pool_start_rank_11  GC908     -1
    pool_start_rank_11  GC910     -1
    pool_start_rank_11  GC912     -1
    pool_start_rank_11  GC914     -1
    pool_end_rank_11  R1283     1
    pool_end_rank_11  GC916     1
    pool_end_rank_11  GC918     1
    pool_end_rank_11  GC920     1
    pool_end_rank_11  GC922     1
    pool_end_rank_11  GC924     1
    pool_end_rank_11  GC926     1
    pool_end_rank_11  GC928     1
    pool_end_rank_11  GC930     1
    pool_end_rank_11  GC932     1
    pool_end_rank_11  GC934     1
    pool_end_rank_11  GC936     1
    pool_end_rank_11  GC938     1
    pool_end_rank_11  GC940     1
    MARKER    'MARKER'                 'INTORG'
    pool_first_11_C29_order_d  R1284     1
    pool_first_11_C88_order_d  R1285     1
    pool_first_11_C29_order_p  R1286     1
    pool_first_11_C46_order_d  R1287     1
    pool_first_11_C6_order_d  R1288     1
    pool_first_11_C88_order_p  R1289     1
    pool_first_11_C47_order_d  R1290     1
    pool_first_11_C47_order_p  R1291     1
    pool_first_11_C76_order_p  R1292     1
    pool_first_11_C76_order_d  R1293     1
    pool_first_11_C27_order_d  R1294     1
    pool_first_11_C25_order_d  R1295     1
    pool_last_11_C29_order_p  R1296     1
    pool_last_11_C88_order_p  R1297     1
    pool_last_11_C29_order_d  R1298     1
    pool_last_11_C6_order_p  R1299     1
    pool_last_11_C46_order_p  R1300     1
    pool_last_11_C6_order_d  R1301     1
    pool_last_11_C88_order_d  R1302     1
    pool_last_11_C47_order_d  R1303     1
    pool_last_11_C47_order_p  R1304     1
    pool_last_11_C76_order_d  R1305     1
    pool_last_11_C25_order_d  R1306     1
    pool_last_11_C46_order_d  R1307     1
    pool_last_11_C27_order_d  R1308     1
    pool_pickup_11_C29_order  R1309     1
    pool_pickup_11_C88_order  R1310     1
    pool_pickup_11_C6_order  R1311     1
    pool_pickup_11_C46_order  R1312     1
    pool_pickup_11_C47_order  R1313     1
    pool_pickup_11_C76_order  R1314     1
    pool_pickup_11_C25_order  R1315     1
    pool_pickup_11_C27_order  R1316     1
    pool_batch_11_b3  R1317     1
    pool_batch_11_b1  R1318     1
    pool_batch_11_b2  R1319     1
    pool_choice_12[0]  OBJ       1.1661903789690601e+01
    pool_choice_12[0]  R1320     1
    pool_choice_12[0]  R1321     -60
    pool_choice_12[0]  R1327     -1
    pool_choice_12[0]  R1343     -1
    pool_choice_12[0]  R1359     -1
    pool_choice_12[0]  R1367     -1
    pool_choice_12[0]  pool_cover_C47_order_d  1
    pool_choice_12[0]  pool_cover_C47_order_p  1
    pool_choice_12[0]  R1701     -1
    pool_choice_12[1]  OBJ       1.7888543819998318e+01
    pool_choice_12[1]  R1320     1
    pool_choice_12[1]  R1321     -60
    pool_choice_12[1]  R1328     -1
    pool_choice_12[1]  R1344     -1
    pool_choice_12[1]  R1360     -1
    pool_choice_12[1]  R1368     -1
    pool_choice_12[1]  pool_cover_C88_order_d  1
    pool_choice_12[1]  pool_cover_C88_order_p  1
    pool_choice_12[1]  R1702     -1
    pool_choice_12[2]  OBJ       20.591260281974
    pool_choice_12[2]  R1320     1
    pool_choice_12[2]  R1321     -60
    pool_choice_12[2]  R1329     -1
    pool_choice_12[2]  R1345     -1
    pool_choice_12[2]  R1361     -1
    pool_choice_12[2]  R1369     -1
    pool_choice_12[2]  pool_cover_C29_order_d  1
    pool_choice_12[2]  pool_cover_C29_order_p  1
    pool_choice_12[2]  R1703     -1
    pool_choice_12[3]  OBJ       1.1661903789690601e+01
    pool_choice_12[3]  R1320     1
    pool_choice_12[3]  R1321     -60
    pool_choice_12[3]  R1327     -1
    pool_choice_12[3]  R1346     -1
    pool_choice_12[3]  R1367     -1
    pool_choice_12[3]  pool_cover_C47_order_d  1
    pool_choice_12[4]  OBJ       1.1661903789690601e+01
    pool_choice_12[4]  R1320     1
    pool_choice_12[4]  R1330     -1
    pool_choice_12[4]  R1343     -1
    pool_choice_12[4]  R1359     -1
    pool_choice_12[4]  pool_cover_C47_order_p  1
    pool_choice_12[5]  OBJ       2.6076809620810597e+01
    pool_choice_12[5]  R1320     1
    pool_choice_12[5]  R1321     -60
    pool_choice_12[5]  R1331     -1
    pool_choice_12[5]  R1347     -1
    pool_choice_12[5]  R1362     -1
    pool_choice_12[5]  R1368     -1
    pool_choice_12[5]  pool_cover_C76_order_d  1
    pool_choice_12[5]  pool_cover_C76_order_p  1
    pool_choice_12[5]  R1704     -1
    pool_choice_12[6]  OBJ       1.7888543819998318e+01
    pool_choice_12[6]  R1320     1
    pool_choice_12[6]  R1321     -60
    pool_choice_12[6]  R1328     -1
    pool_choice_12[6]  R1348     -1
    pool_choice_12[6]  R1368     -1
    pool_choice_12[6]  pool_cover_C88_order_d  1
    pool_choice_12[7]  OBJ       1.7888543819998318e+01
    pool_choice_12[7]  R1320     1
    pool_choice_12[7]  R1332     -1
    pool_choice_12[7]  R1344     -1
    pool_choice_12[7]  R1360     -1
    pool_choice_12[7]  pool_cover_C88_order_p  1
    pool_choice_12[8]  OBJ       20.591260281974
    pool_choice_12[8]  R1320     1
    pool_choice_12[8]  R1321     -60
    pool_choice_12[8]  R1329     -1
    pool_choice_12[8]  R1349     -1
    pool_choice_12[8]  R1369     -1
    pool_choice_12[8]  pool_cover_C29_order_d  1
    pool_choice_12[9]  OBJ       20.591260281974
    pool_choice_12[9]  R1320     1
    pool_choice_12[9]  R1333     -1
    pool_choice_12[9]  R1345     -1
    pool_choice_12[9]  R1361     -1
    pool_choice_12[9]  pool_cover_C29_order_p  1
    pool_choice_12[10]  OBJ       4.8083261120685229e+01
    pool_choice_12[10]  R1320     1
    pool_choice_12[10]  R1321     -60
    pool_choice_12[10]  R1334     -1
    pool_choice_12[10]  R1350     -1
    pool_choice_12[10]  R1363     -1
    pool_choice_12[10]  R1368     -1
    pool_choice_12[10]  pool_cover_C27_order_d  1
    pool_choice_12[10]  pool_cover_C27_order_p  1
    pool_choice_12[10]  R1705     -1
    pool_choice_12[11]  OBJ       4.9396356140913873e+01
    pool_choice_12[11]  R1320     1
    pool_choice_12[11]  R1321     -60
    pool_choice_12[11]  R1335     -1
    pool_choice_12[11]  R1351     -1
    pool_choice_12[11]  R1364     -1
    pool_choice_12[11]  R1367     -1
    pool_choice_12[11]  pool_cover_C25_order_d  1
    pool_choice_12[11]  pool_cover_C25_order_p  1
    pool_choice_12[11]  R1706     -1
    pool_choice_12[12]  OBJ       2.6076809620810597e+01
    pool_choice_12[12]  R1320     1
    pool_choice_12[12]  R1321     -60
    pool_choice_12[12]  R1331     -1
    pool_choice_12[12]  R1352     -1
    pool_choice_12[12]  R1368     -1
    pool_choice_12[12]  pool_cover_C76_order_d  1
    pool_choice_12[13]  OBJ       2.6076809620810597e+01
    pool_choice_12[13]  R1320     1
    pool_choice_12[13]  R1336     -1
    pool_choice_12[13]  R1347     -1
    pool_choice_12[13]  R1362     -1
    pool_choice_12[13]  pool_cover_C76_order_p  1
    pool_choice_12[14]  OBJ       6.2032249677083293e+01
    pool_choice_12[14]  R1320     1
    pool_choice_12[14]  R1321     -60
    pool_choice_12[14]  R1337     -1
    pool_choice_12[14]  R1353     -1
    pool_choice_12[14]  R1365     -1
    pool_choice_12[14]  R1367     -1
    pool_choice_12[14]  pool_cover_C46_order_d  1
    pool_choice_12[14]  pool_cover_C46_order_p  1
    pool_choice_12[14]  R1707     -1
    pool_choice_12[15]  OBJ       6.3529520697074361e+01
    pool_choice_12[15]  R1320     1
    pool_choice_12[15]  R1321     -60
    pool_choice_12[15]  R1338     -1
    pool_choice_12[15]  R1354     -1
    pool_choice_12[15]  R1366     -1
    pool_choice_12[15]  R1369     -1
    pool_choice_12[15]  pool_cover_C6_order_d  1
    pool_choice_12[15]  pool_cover_C6_order_p  1
    pool_choice_12[15]  R1708     -1
    pool_choice_12[16]  OBJ       4.8083261120685229e+01
    pool_choice_12[16]  R1320     1
    pool_choice_12[16]  R1321     -60
    pool_choice_12[16]  R1334     -1
    pool_choice_12[16]  R1355     -1
    pool_choice_12[16]  R1368     -1
    pool_choice_12[16]  pool_cover_C27_order_d  1
    pool_choice_12[17]  OBJ       4.8083261120685229e+01
    pool_choice_12[17]  R1320     1
    pool_choice_12[17]  R1339     -1
    pool_choice_12[17]  R1350     -1
    pool_choice_12[17]  R1363     -1
    pool_choice_12[17]  pool_cover_C27_order_p  1
    pool_choice_12[18]  OBJ       4.9396356140913873e+01
    pool_choice_12[18]  R1320     1
    pool_choice_12[18]  R1321     -60
    pool_choice_12[18]  R1335     -1
    pool_choice_12[18]  R1356     -1
    pool_choice_12[18]  R1367     -1
    pool_choice_12[18]  pool_cover_C25_order_d  1
    pool_choice_12[19]  OBJ       4.9396356140913873e+01
    pool_choice_12[19]  R1320     1
    pool_choice_12[19]  R1340     -1
    pool_choice_12[19]  R1351     -1
    pool_choice_12[19]  R1364     -1
    pool_choice_12[19]  pool_cover_C25_order_p  1
    pool_choice_12[20]  OBJ       6.2032249677083293e+01
    pool_choice_12[20]  R1320     1
    pool_choice_12[20]  R1321     -60
    pool_choice_12[20]  R1337     -1
    pool_choice_12[20]  R1357     -1
    pool_choice_12[20]  R1367     -1
    pool_choice_12[20]  pool_cover_C46_order_d  1
    pool_choice_12[21]  OBJ       6.2032249677083293e+01
    pool_choice_12[21]  R1320     1
    pool_choice_12[21]  R1341     -1
    pool_choice_12[21]  R1353     -1
    pool_choice_12[21]  R1365     -1
    pool_choice_12[21]  pool_cover_C46_order_p  1
    pool_choice_12[22]  OBJ       6.3529520697074361e+01
    pool_choice_12[22]  R1320     1
    pool_choice_12[22]  R1321     -60
    pool_choice_12[22]  R1338     -1
    pool_choice_12[22]  R1358     -1
    pool_choice_12[22]  R1369     -1
    pool_choice_12[22]  pool_cover_C6_order_d  1
    pool_choice_12[23]  OBJ       6.3529520697074361e+01
    pool_choice_12[23]  R1320     1
    pool_choice_12[23]  R1342     -1
    pool_choice_12[23]  R1354     -1
    pool_choice_12[23]  R1366     -1
    pool_choice_12[23]  pool_cover_C6_order_p  1
    pool_choice_12[24]  OBJ       2.0654115613359256e+01
    pool_choice_12[24]  R1320     1
    pool_choice_12[24]  R1332     -1
    pool_choice_12[24]  R1345     -1
    pool_choice_12[24]  R1360     -1
    pool_choice_12[24]  R1361     -1
    pool_choice_12[24]  pool_cover_C88_order_p  1
    pool_choice_12[24]  pool_cover_C29_order_p  1
    pool_choice_12[24]  R1709     -1
    pool_choice_12[25]  OBJ       2.0654115613359256e+01
    pool_choice_12[25]  R1320     1
    pool_choice_12[25]  R1321     -60
    pool_choice_12[25]  R1328     -1
    pool_choice_12[25]  R1345     -1
    pool_choice_12[25]  R1360     -1
    pool_choice_12[25]  R1361     -1
    pool_choice_12[25]  R1368     -1
    pool_choice_12[25]  pool_cover_C88_order_d  1
    pool_choice_12[25]  pool_cover_C88_order_p  1
    pool_choice_12[25]  pool_cover_C29_order_p  1
    pool_choice_12[25]  R1702     -1
    pool_choice_12[25]  R1709     -1
    pool_choice_12[26]  OBJ       41.2180607820758
    pool_choice_12[26]  R1320     1
    pool_choice_12[26]  R1321     -60
    pool_choice_12[26]  R1328     -1
    pool_choice_12[26]  R1352     -1
    pool_choice_12[26]  R1368     -1
    pool_choice_12[26]  pool_cover_C88_order_d  1
    pool_choice_12[26]  pool_cover_C76_order_d  1
    pool_choice_12[26]  R1710     -1
    pool_choice_12[27]  OBJ       4.9397092229415449e+01
    pool_choice_12[27]  R1320     1
    pool_choice_12[27]  R1321     -60
    pool_choice_12[27]  R1327     -1
    pool_choice_12[27]  R1356     -1
    pool_choice_12[27]  R1367     -1
    pool_choice_12[27]  pool_cover_C47_order_d  1
    pool_choice_12[27]  pool_cover_C25_order_d  1
    pool_choice_12[27]  R1711     -1
    pool_choice_12[28]  OBJ       3.1747081387645608e+01
    pool_choice_12[28]  R1320     1
    pool_choice_12[28]  R1321     -60
    pool_choice_12[28]  R1327     -1
    pool_choice_12[28]  R1345     -1
    pool_choice_12[28]  R1359     -1
    pool_choice_12[28]  R1361     -1
    pool_choice_12[28]  R1367     -1
    pool_choice_12[28]  pool_cover_C47_order_d  1
    pool_choice_12[28]  pool_cover_C47_order_p  1
    pool_choice_12[28]  pool_cover_C29_order_p  1
    pool_choice_12[28]  R1701     -1
    pool_choice_12[28]  R1712     -1
    pool_choice_12[29]  OBJ       7.5601410152021032e+01
    pool_choice_12[29]  R1320     1
    pool_choice_12[29]  R1321     -60
    pool_choice_12[29]  R1329     -1
    pool_choice_12[29]  R1358     -1
    pool_choice_12[29]  R1369     -1
    pool_choice_12[29]  pool_cover_C29_order_d  1
    pool_choice_12[29]  pool_cover_C6_order_d  1
    pool_choice_12[29]  R1713     -1
    pool_choice_12[30]  OBJ       8.7673299606967689e+01
    pool_choice_12[30]  R1320     1
    pool_choice_12[30]  R1321     -60
    pool_choice_12[30]  R1329     -1
    pool_choice_12[30]  R1345     -1
    pool_choice_12[30]  R1361     -1
    pool_choice_12[30]  R1366     -1
    pool_choice_12[30]  R1369     -1
    pool_choice_12[30]  pool_cover_C29_order_d  1
    pool_choice_12[30]  pool_cover_C29_order_p  1
    pool_choice_12[30]  pool_cover_C6_order_d  1
    pool_choice_12[30]  pool_cover_C6_order_p  1
    pool_choice_12[30]  R1708     -1
    pool_choice_12[30]  R1713     -1
    pool_choice_12[30]  R1714     -1
    pool_choice_12[31]  OBJ       2.7115567956485918e+01
    pool_choice_12[31]  R1320     1
    pool_choice_12[31]  R1336     -1
    pool_choice_12[31]  R1343     -1
    pool_choice_12[31]  R1359     -1
    pool_choice_12[31]  R1362     -1
    pool_choice_12[31]  pool_cover_C76_order_p  1
    pool_choice_12[31]  pool_cover_C47_order_p  1
    pool_choice_12[31]  R1715     -1
    pool_choice_12[32]  OBJ       6.4531470933056056e+01
    pool_choice_12[32]  R1320     1
    pool_choice_12[32]  R1321     -60
    pool_choice_12[32]  R1328     -1
    pool_choice_12[32]  R1352     -1
    pool_choice_12[32]  R1368     -1
    pool_choice_12[32]  pool_cover_C88_order_d  1
    pool_choice_12[32]  pool_cover_C76_order_d  1
    pool_choice_12[32]  pool_cover_C27_order_d  1
    pool_choice_12[32]  R1716     -1
    pool_choice_12[32]  R1717     -1
    pool_choice_12[33]  OBJ       2.7115567956485918e+01
    pool_choice_12[33]  R1320     1
    pool_choice_12[33]  R1321     -60
    pool_choice_12[33]  R1331     -1
    pool_choice_12[33]  R1343     -1
    pool_choice_12[33]  R1359     -1
    pool_choice_12[33]  R1362     -1
    pool_choice_12[33]  R1368     -1
    pool_choice_12[33]  pool_cover_C76_order_d  1
    pool_choice_12[33]  pool_cover_C76_order_p  1
    pool_choice_12[33]  pool_cover_C47_order_p  1
    pool_choice_12[33]  R1704     -1
    pool_choice_12[33]  R1715     -1
    pool_choice_12[34]  OBJ       6.4631964712286560e+01
    pool_choice_12[34]  R1320     1
    pool_choice_12[34]  R1321     -60
    pool_choice_12[34]  R1327     -1
    pool_choice_12[34]  R1357     -1
    pool_choice_12[34]  R1367     -1
    pool_choice_12[34]  pool_cover_C47_order_d  1
    pool_choice_12[34]  pool_cover_C46_order_d  1
    pool_choice_12[34]  R1718     -1
    pool_choice_12[35]  OBJ       4.9397828317917018e+01
    pool_choice_12[35]  R1320     1
    pool_choice_12[35]  R1321     -60
    pool_choice_12[35]  R1327     -1
    pool_choice_12[35]  R1343     -1
    pool_choice_12[35]  R1359     -1
    pool_choice_12[35]  R1364     -1
    pool_choice_12[35]  R1367     -1
    pool_choice_12[35]  pool_cover_C47_order_d  1
    pool_choice_12[35]  pool_cover_C47_order_p  1
    pool_choice_12[35]  pool_cover_C25_order_d  1
    pool_choice_12[35]  pool_cover_C25_order_p  1
    pool_choice_12[35]  R1706     -1
    pool_choice_12[35]  R1711     -1
    pool_choice_12[35]  R1719     -1
    pool_choice_12[36]  OBJ       7.5601410152021018e+01
    pool_choice_12[36]  R1320     1
    pool_choice_12[36]  R1321     -60
    pool_choice_12[36]  R1338     -1
    pool_choice_12[36]  R1345     -1
    pool_choice_12[36]  R1361     -1
    pool_choice_12[36]  R1366     -1
    pool_choice_12[36]  R1369     -1
    pool_choice_12[36]  pool_cover_C29_order_p  1
    pool_choice_12[36]  pool_cover_C6_order_d  1
    pool_choice_12[36]  pool_cover_C6_order_p  1
    pool_choice_12[36]  R1708     -1
    pool_choice_12[36]  R1714     -1
    pool_choice_12[37]  OBJ       5.5723778079391167e+01
    pool_choice_12[37]  R1320     1
    pool_choice_12[37]  R1336     -1
    pool_choice_12[37]  R1343     -1
    pool_choice_12[37]  R1359     -1
    pool_choice_12[37]  R1362     -1
    pool_choice_12[37]  R1363     -1
    pool_choice_12[37]  R1364     -1
    pool_choice_12[37]  pool_cover_C76_order_p  1
    pool_choice_12[37]  pool_cover_C27_order_p  1
    pool_choice_12[37]  pool_cover_C47_order_p  1
    pool_choice_12[37]  pool_cover_C25_order_p  1
    pool_choice_12[37]  R1719     -1
    pool_choice_12[37]  R1720     -1
    pool_choice_12[37]  R1721     -1
    pool_choice_12[38]  OBJ       4.8741939160438513e+01
    pool_choice_12[38]  R1320     1
    pool_choice_12[38]  R1321     -60
    pool_choice_12[38]  R1334     -1
    pool_choice_12[38]  R1352     -1
    pool_choice_12[38]  R1368     -1
    pool_choice_12[38]  pool_cover_C76_order_d  1
    pool_choice_12[38]  pool_cover_C27_order_d  1
    pool_choice_12[38]  R1717     -1
    pool_choice_12[39]  OBJ       2.8987894208396355e+01
    pool_choice_12[39]  R1320     1
    pool_choice_12[39]  R1321     -60
    pool_choice_12[39]  R1328     -1
    pool_choice_12[39]  R1343     -1
    pool_choice_12[39]  R1359     -1
    pool_choice_12[39]  R1360     -1
    pool_choice_12[39]  R1368     -1
    pool_choice_12[39]  pool_cover_C88_order_d  1
    pool_choice_12[39]  pool_cover_C88_order_p  1
    pool_choice_12[39]  pool_cover_C47_order_p  1
    pool_choice_12[39]  R1702     -1
    pool_choice_12[39]  R1722     -1
    pool_choice_12[40]  OBJ       8.1012524190345616e+01
    pool_choice_12[40]  R1320     1
    pool_choice_12[40]  R1321     -60
    pool_choice_12[40]  R1335     -1
    pool_choice_12[40]  R1357     -1
    pool_choice_12[40]  R1367     -1
    pool_choice_12[40]  pool_cover_C25_order_d  1
    pool_choice_12[40]  pool_cover_C46_order_d  1
    pool_choice_12[40]  R1723     -1
    pool_choice_12[41]  OBJ       6.9483005915872027e+01
    pool_choice_12[41]  R1320     1
    pool_choice_12[41]  R1321     -60
    pool_choice_12[41]  R1327     -1
    pool_choice_12[41]  R1345     -1
    pool_choice_12[41]  R1359     -1
    pool_choice_12[41]  R1361     -1
    pool_choice_12[41]  R1364     -1
    pool_choice_12[41]  R1367     -1
    pool_choice_12[41]  pool_cover_C47_order_d  1
    pool_choice_12[41]  pool_cover_C47_order_p  1
    pool_choice_12[41]  pool_cover_C25_order_d  1
    pool_choice_12[41]  pool_cover_C25_order_p  1
    pool_choice_12[41]  pool_cover_C29_order_p  1
    pool_choice_12[41]  R1706     -1
    pool_choice_12[41]  R1711     -1
    pool_choice_12[41]  R1712     -1
    pool_choice_12[41]  R1719     -1
    pool_choice_12[42]  OBJ       7.5601410152021032e+01
    pool_choice_12[42]  R1320     1
    pool_choice_12[42]  R1321     -60
    pool_choice_12[42]  R1329     -1
    pool_choice_12[42]  R1354     -1
    pool_choice_12[42]  R1361     -1
    pool_choice_12[42]  R1366     -1
    pool_choice_12[42]  R1369     -1
    pool_choice_12[42]  pool_cover_C29_order_d  1
    pool_choice_12[42]  pool_cover_C29_order_p  1
    pool_choice_12[42]  pool_cover_C6_order_p  1
    pool_choice_12[42]  R1703     -1
    pool_choice_12[42]  R1724     -1
    pool_choice_12[43]  OBJ       4.2256819117751121e+01
    pool_choice_12[43]  R1320     1
    pool_choice_12[43]  R1332     -1
    pool_choice_12[43]  R1343     -1
    pool_choice_12[43]  R1359     -1
    pool_choice_12[43]  R1360     -1
    pool_choice_12[43]  R1362     -1
    pool_choice_12[43]  pool_cover_C88_order_p  1
    pool_choice_12[43]  pool_cover_C76_order_p  1
    pool_choice_12[43]  pool_cover_C47_order_p  1
    pool_choice_12[43]  R1715     -1
    pool_choice_12[43]  R1725     -1
    pool_choice_12[44]  OBJ       4.8741939160438520e+01
    pool_choice_12[44]  R1320     1
    pool_choice_12[44]  R1321     -60
    pool_choice_12[44]  R1331     -1
    pool_choice_12[44]  R1355     -1
    pool_choice_12[44]  R1368     -1
    pool_choice_12[44]  pool_cover_C76_order_d  1
    pool_choice_12[44]  pool_cover_C27_order_d  1
    pool_choice_12[44]  R1726     -1
    pool_choice_12[45]  OBJ       5.0439375535867129e+01
    pool_choice_12[45]  R1320     1
    pool_choice_12[45]  R1321     -60
    pool_choice_12[45]  R1331     -1
    pool_choice_12[45]  R1343     -1
    pool_choice_12[45]  R1359     -1
    pool_choice_12[45]  R1362     -1
    pool_choice_12[45]  R1363     -1
    pool_choice_12[45]  R1368     -1
    pool_choice_12[45]  pool_cover_C76_order_d  1
    pool_choice_12[45]  pool_cover_C76_order_p  1
    pool_choice_12[45]  pool_cover_C27_order_d  1
    pool_choice_12[45]  pool_cover_C27_order_p  1
    pool_choice_12[45]  pool_cover_C47_order_p  1
    pool_choice_12[45]  R1705     -1
    pool_choice_12[45]  R1715     -1
    pool_choice_12[45]  R1726     -1
    pool_choice_12[45]  R1727     -1
    pool_choice_12[46]  OBJ       3.1747081387645608e+01
    pool_choice_12[46]  R1320     1
    pool_choice_12[46]  R1321     -60
    pool_choice_12[46]  R1327     -1
    pool_choice_12[46]  R1345     -1
    pool_choice_12[46]  R1361     -1
    pool_choice_12[46]  R1367     -1
    pool_choice_12[46]  pool_cover_C47_order_d  1
    pool_choice_12[46]  pool_cover_C29_order_p  1
    pool_choice_12[46]  R1728     -1
    pool_choice_12[47]  OBJ       7.5601410152021032e+01
    pool_choice_12[47]  R1320     1
    pool_choice_12[47]  R1321     -60
    pool_choice_12[47]  R1329     -1
    pool_choice_12[47]  R1354     -1
    pool_choice_12[47]  R1366     -1
    pool_choice_12[47]  R1369     -1
    pool_choice_12[47]  pool_cover_C29_order_d  1
    pool_choice_12[47]  pool_cover_C6_order_d  1
    pool_choice_12[47]  pool_cover_C6_order_p  1
    pool_choice_12[47]  R1708     -1
    pool_choice_12[47]  R1713     -1
    pool_choice_12[48]  OBJ       2.8987894208396355e+01
    pool_choice_12[48]  R1320     1
    pool_choice_12[48]  R1332     -1
    pool_choice_12[48]  R1343     -1
    pool_choice_12[48]  R1359     -1
    pool_choice_12[48]  R1360     -1
    pool_choice_12[48]  pool_cover_C88_order_p  1
    pool_choice_12[48]  pool_cover_C47_order_p  1
    pool_choice_12[48]  R1722     -1
    pool_choice_12[49]  OBJ       2.0654115613359256e+01
    pool_choice_12[49]  R1320     1
    pool_choice_12[49]  R1321     -60
    pool_choice_12[49]  R1328     -1
    pool_choice_12[49]  R1345     -1
    pool_choice_12[49]  R1361     -1
    pool_choice_12[49]  R1368     -1
    pool_choice_12[49]  pool_cover_C88_order_d  1
    pool_choice_12[49]  pool_cover_C29_order_p  1
    pool_choice_12[49]  R1729     -1
    pool_choice_12[50]  OBJ       8.1575595302846423e+01
    pool_choice_12[50]  R1320     1
    pool_choice_12[50]  R1321     -60
    pool_choice_12[50]  R1327     -1
    pool_choice_12[50]  R1345     -1
    pool_choice_12[50]  R1361     -1
    pool_choice_12[50]  R1365     -1
    pool_choice_12[50]  R1366     -1
    pool_choice_12[50]  R1367     -1
    pool_choice_12[50]  pool_cover_C47_order_d  1
    pool_choice_12[50]  pool_cover_C46_order_d  1
    pool_choice_12[50]  pool_cover_C46_order_p  1
    pool_choice_12[50]  pool_cover_C29_order_p  1
    pool_choice_12[50]  pool_cover_C6_order_p  1
    pool_choice_12[50]  R1707     -1
    pool_choice_12[50]  R1714     -1
    pool_choice_12[50]  R1718     -1
    pool_choice_12[50]  R1730     -1
    pool_choice_12[51]  OBJ       8.7673299606967689e+01
    pool_choice_12[51]  R1320     1
    pool_choice_12[51]  R1321     -60
    pool_choice_12[51]  R1329     -1
    pool_choice_12[51]  R1345     -1
    pool_choice_12[51]  R1361     -1
    pool_choice_12[51]  R1369     -1
    pool_choice_12[51]  pool_cover_C29_order_d  1
    pool_choice_12[51]  pool_cover_C29_order_p  1
    pool_choice_12[51]  pool_cover_C6_order_d  1
    pool_choice_12[51]  R1713     -1
    pool_choice_12[51]  R1731     -1
    pool_choice_12[52]  OBJ       4.3983632575436737e+01
    pool_choice_12[52]  R1320     1
    pool_choice_12[52]  R1336     -1
    pool_choice_12[52]  R1345     -1
    pool_choice_12[52]  R1360     -1
    pool_choice_12[52]  R1361     -1
    pool_choice_12[52]  R1362     -1
    pool_choice_12[52]  pool_cover_C88_order_p  1
    pool_choice_12[52]  pool_cover_C76_order_p  1
    pool_choice_12[52]  pool_cover_C29_order_p  1
    pool_choice_12[52]  R1709     -1
    pool_choice_12[52]  R1732     -1
    pool_choice_12[53]  OBJ       6.3872792893302773e+01
    pool_choice_12[53]  R1320     1
    pool_choice_12[53]  R1321     -60
    pool_choice_12[53]  R1328     -1
    pool_choice_12[53]  R1355     -1
    pool_choice_12[53]  R1368     -1
    pool_choice_12[53]  pool_cover_C88_order_d  1
    pool_choice_12[53]  pool_cover_C27_order_d  1
    pool_choice_12[53]  R1716     -1
    pool_choice_12[54]  OBJ       4.2256819117751121e+01
    pool_choice_12[54]  R1320     1
    pool_choice_12[54]  R1321     -60
    pool_choice_12[54]  R1328     -1
    pool_choice_12[54]  R1343     -1
    pool_choice_12[54]  R1359     -1
    pool_choice_12[54]  R1362     -1
    pool_choice_12[54]  R1368     -1
    pool_choice_12[54]  pool_cover_C88_order_d  1
    pool_choice_12[54]  pool_cover_C76_order_d  1
    pool_choice_12[54]  pool_cover_C76_order_p  1
    pool_choice_12[54]  pool_cover_C47_order_p  1
    pool_choice_12[54]  R1704     -1
    pool_choice_12[54]  R1710     -1
    pool_choice_12[54]  R1715     -1
    pool_choice_12[55]  OBJ       8.1575595302846423e+01
    pool_choice_12[55]  R1320     1
    pool_choice_12[55]  R1321     -60
    pool_choice_12[55]  R1327     -1
    pool_choice_12[55]  R1345     -1
    pool_choice_12[55]  R1359     -1
    pool_choice_12[55]  R1361     -1
    pool_choice_12[55]  R1365     -1
    pool_choice_12[55]  R1366     -1
    pool_choice_12[55]  R1367     -1
    pool_choice_12[55]  pool_cover_C47_order_d  1
    pool_choice_12[55]  pool_cover_C47_order_p  1
    pool_choice_12[55]  pool_cover_C46_order_p  1
    pool_choice_12[55]  pool_cover_C29_order_p  1
    pool_choice_12[55]  pool_cover_C6_order_p  1
    pool_choice_12[55]  R1701     -1
    pool_choice_12[55]  R1714     -1
    pool_choice_12[55]  R1730     -1
    pool_choice_12[55]  R1733     -1
    pool_used_12  R1320     -1
    pool_used_12  R1321     -28800
    pool_used_12  R1322     -75600
    pool_used_12  R1323     -75540
    pool_used_12  R1324     -1
    pool_used_12  R1325     -80
    pool_used_12  R1326     -80
    pool_used_12  R1803     -75660
    pool_used_12  R1804     -81
    pool_used_12  R1805     -75660
    pool_used_12  R1806     -81
    pool_used_12  R1807     -75660
    pool_used_12  R1808     -81
    pool_start_12  R1321     1
    pool_start_12  R1322     1
    pool_start_12  GC952     -1
    pool_start_12  GC954     -1
    pool_start_12  GC956     -1
    pool_start_12  GC958     -1
    pool_start_12  GC960     -1
    pool_start_12  GC962     -1
    pool_start_12  GC964     -1
    pool_start_12  GC966     -1
    pool_start_12  GC968     -1
    pool_start_12  GC970     -1
    pool_start_12  GC972     -1
    pool_start_12  GC974     -1
    pool_start_12  GC976     -1
    pool_start_12  GC978     -1
    pool_start_12  GC980     -1
    pool_start_12  GC982     -1
    pool_start_12  GC1024    1
    pool_start_12  GC1025    1
    pool_start_12  GC1026    1
    pool_end_12  R1323     1
    pool_end_12  R1803     -1
    pool_end_12  R1805     -1
    pool_end_12  R1807     -1
    pool_end_12  GC984     1
    pool_end_12  GC986     1
    pool_end_12  GC988     1
    pool_end_12  GC990     1
    pool_end_12  GC992     1
    pool_end_12  GC994     1
    pool_end_12  GC996     1
    pool_end_12  GC998     1
    pool_end_12  GC1000    1
    pool_end_12  GC1002    1
    pool_end_12  GC1004    1
    pool_end_12  GC1006    1
    pool_end_12  GC1008    1
    pool_end_12  GC1010    1
    pool_end_12  GC1012    1
    pool_end_12  GC1014    1
    pool_end_12  GC1016    -1
    pool_end_12  GC1017    -1
    pool_end_12  GC1018    -1
    pool_end_12  GC1019    -1
    pool_end_12  GC1020    -1
    pool_end_12  GC1021    -1
    pool_end_12  GC1022    -1
    pool_end_12  GC1023    -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_12  R1324     1
    pool_start_rank_12  R1325     1
    pool_start_rank_12  GC953     -1
    pool_start_rank_12  GC955     -1
    pool_start_rank_12  GC957     -1
    pool_start_rank_12  GC959     -1
    pool_start_rank_12  GC961     -1
    pool_start_rank_12  GC963     -1
    pool_start_rank_12  GC965     -1
    pool_start_rank_12  GC967     -1
    pool_start_rank_12  GC969     -1
    pool_start_rank_12  GC971     -1
    pool_start_rank_12  GC973     -1
    pool_start_rank_12  GC975     -1
    pool_start_rank_12  GC977     -1
    pool_start_rank_12  GC979     -1
    pool_start_rank_12  GC981     -1
    pool_start_rank_12  GC983     -1
    pool_end_rank_12  R1326     1
    pool_end_rank_12  R1804     -1
    pool_end_rank_12  R1806     -1
    pool_end_rank_12  R1808     -1
    pool_end_rank_12  GC985     1
    pool_end_rank_12  GC987     1
    pool_end_rank_12  GC989     1
    pool_end_rank_12  GC991     1
    pool_end_rank_12  GC993     1
    pool_end_rank_12  GC995     1
    pool_end_rank_12  GC997     1
    pool_end_rank_12  GC999     1
    pool_end_rank_12  GC1001    1
    pool_end_rank_12  GC1003    1
    pool_end_rank_12  GC1005    1
    pool_end_rank_12  GC1007    1
    pool_end_rank_12  GC1009    1
    pool_end_rank_12  GC1011    1
    pool_end_rank_12  GC1013    1
    pool_end_rank_12  GC1015    1
    MARKER    'MARKER'                 'INTORG'
    pool_first_12_C47_order_d  R1327     1
    pool_first_12_C88_order_d  R1328     1
    pool_first_12_C29_order_d  R1329     1
    pool_first_12_C47_order_p  R1330     1
    pool_first_12_C76_order_d  R1331     1
    pool_first_12_C88_order_p  R1332     1
    pool_first_12_C29_order_p  R1333     1
    pool_first_12_C27_order_d  R1334     1
    pool_first_12_C25_order_d  R1335     1
    pool_first_12_C76_order_p  R1336     1
    pool_first_12_C46_order_d  R1337     1
    pool_first_12_C6_order_d  R1338     1
    pool_first_12_C27_order_p  R1339     1
    pool_first_12_C25_order_p  R1340     1
    pool_first_12_C46_order_p  R1341     1
    pool_first_12_C6_order_p  R1342     1
    pool_last_12_C47_order_p  R1343     1
    pool_last_12_C88_order_p  R1344     1
    pool_last_12_C29_order_p  R1345     1
    pool_last_12_C47_order_d  R1346     1
    pool_last_12_C76_order_p  R1347     1
    pool_last_12_C88_order_d  R1348     1
    pool_last_12_C29_order_d  R1349     1
    pool_last_12_C27_order_p  R1350     1
    pool_last_12_C25_order_p  R1351     1
    pool_last_12_C76_order_d  R1352     1
    pool_last_12_C46_order_p  R1353     1
    pool_last_12_C6_order_p  R1354     1
    pool_last_12_C27_order_d  R1355     1
    pool_last_12_C25_order_d  R1356     1
    pool_last_12_C46_order_d  R1357     1
    pool_last_12_C6_order_d  R1358     1
    pool_pickup_12_C47_order  R1359     1
    pool_pickup_12_C88_order  R1360     1
    pool_pickup_12_C29_order  R1361     1
    pool_pickup_12_C76_order  R1362     1
    pool_pickup_12_C27_order  R1363     1
    pool_pickup_12_C25_order  R1364     1
    pool_pickup_12_C46_order  R1365     1
    pool_pickup_12_C6_order  R1366     1
    pool_batch_12_b2  R1367     1
    pool_batch_12_b1  R1368     1
    pool_batch_12_b3  R1369     1
    pool_choice_13[0]  OBJ       49.4006172001918
    pool_choice_13[0]  R1370     1
    pool_choice_13[0]  R1371     -60
    pool_choice_13[0]  R1377     -1
    pool_choice_13[0]  R1387     -1
    pool_choice_13[0]  R1403     -1
    pool_choice_13[0]  R1404     -1
    pool_choice_13[0]  R1411     -1
    pool_choice_13[0]  pool_cover_C76_order_d  1
    pool_choice_13[0]  pool_cover_C76_order_p  1
    pool_choice_13[0]  pool_cover_C27_order_d  1
    pool_choice_13[0]  pool_cover_C27_order_p  1
    pool_choice_13[0]  R1705     -1
    pool_choice_13[0]  R1726     -1
    pool_choice_13[0]  R1727     -1
    pool_choice_13[0]  R1803     -60
    pool_choice_13[1]  OBJ       5.0439375535867129e+01
    pool_choice_13[1]  R1370     1
    pool_choice_13[1]  R1371     -60
    pool_choice_13[1]  R1377     -1
    pool_choice_13[1]  R1388     -1
    pool_choice_13[1]  R1403     -1
    pool_choice_13[1]  R1404     -1
    pool_choice_13[1]  R1405     -1
    pool_choice_13[1]  R1411     -1
    pool_choice_13[1]  pool_cover_C76_order_d  1
    pool_choice_13[1]  pool_cover_C76_order_p  1
    pool_choice_13[1]  pool_cover_C27_order_d  1
    pool_choice_13[1]  pool_cover_C27_order_p  1
    pool_choice_13[1]  pool_cover_C47_order_p  1
    pool_choice_13[1]  R1705     -1
    pool_choice_13[1]  R1715     -1
    pool_choice_13[1]  R1726     -1
    pool_choice_13[1]  R1727     -1
    pool_choice_13[1]  R1803     -60
    pool_choice_13[2]  OBJ       2.6076809620810597e+01
    pool_choice_13[2]  R1370     1
    pool_choice_13[2]  R1371     -60
    pool_choice_13[2]  R1377     -1
    pool_choice_13[2]  R1387     -1
    pool_choice_13[2]  R1404     -1
    pool_choice_13[2]  R1411     -1
    pool_choice_13[2]  pool_cover_C76_order_d  1
    pool_choice_13[2]  pool_cover_C76_order_p  1
    pool_choice_13[2]  R1704     -1
    pool_choice_13[2]  R1803     -60
    pool_choice_13[3]  OBJ       6.7249102812747509e+01
    pool_choice_13[3]  R1370     1
    pool_choice_13[3]  R1371     -60
    pool_choice_13[3]  R1377     -1
    pool_choice_13[3]  R1389     -1
    pool_choice_13[3]  R1403     -1
    pool_choice_13[3]  R1404     -1
    pool_choice_13[3]  R1406     -1
    pool_choice_13[3]  R1411     -1
    pool_choice_13[3]  pool_cover_C76_order_d  1
    pool_choice_13[3]  pool_cover_C76_order_p  1
    pool_choice_13[3]  pool_cover_C27_order_d  1
    pool_choice_13[3]  pool_cover_C27_order_p  1
    pool_choice_13[3]  pool_cover_C29_order_p  1
    pool_choice_13[3]  R1705     -1
    pool_choice_13[3]  R1726     -1
    pool_choice_13[3]  R1727     -1
    pool_choice_13[3]  R1755     -1
    pool_choice_13[3]  R1803     -60
    pool_choice_13[4]  OBJ       75.4825955620994
    pool_choice_13[4]  R1370     1
    pool_choice_13[4]  R1371     -60
    pool_choice_13[4]  R1377     -1
    pool_choice_13[4]  R1390     -1
    pool_choice_13[4]  R1403     -1
    pool_choice_13[4]  R1404     -1
    pool_choice_13[4]  R1407     -1
    pool_choice_13[4]  R1411     -1
    pool_choice_13[4]  pool_cover_C76_order_d  1
    pool_choice_13[4]  pool_cover_C76_order_p  1
    pool_choice_13[4]  pool_cover_C27_order_d  1
    pool_choice_13[4]  pool_cover_C27_order_p  1
    pool_choice_13[4]  pool_cover_C25_order_p  1
    pool_choice_13[4]  R1705     -1
    pool_choice_13[4]  R1726     -1
    pool_choice_13[4]  R1727     -1
    pool_choice_13[4]  R1756     -1
    pool_choice_13[4]  R1803     -60
    pool_choice_13[5]  OBJ       6.4531470933056056e+01
    pool_choice_13[5]  R1370     1
    pool_choice_13[5]  R1371     -60
    pool_choice_13[5]  R1377     -1
    pool_choice_13[5]  R1391     -1
    pool_choice_13[5]  R1403     -1
    pool_choice_13[5]  R1408     -1
    pool_choice_13[5]  R1411     -1
    pool_choice_13[5]  pool_cover_C88_order_p  1
    pool_choice_13[5]  pool_cover_C76_order_d  1
    pool_choice_13[5]  pool_cover_C27_order_d  1
    pool_choice_13[5]  pool_cover_C27_order_p  1
    pool_choice_13[5]  R1705     -1
    pool_choice_13[5]  R1726     -1
    pool_choice_13[5]  R1735     -1
    pool_choice_13[5]  R1803     -60
    pool_choice_13[6]  OBJ       6.4531470933056056e+01
    pool_choice_13[6]  R1370     1
    pool_choice_13[6]  R1371     -60
    pool_choice_13[6]  R1378     -1
    pool_choice_13[6]  R1387     -1
    pool_choice_13[6]  R1403     -1
    pool_choice_13[6]  R1404     -1
    pool_choice_13[6]  R1411     -1
    pool_choice_13[6]  pool_cover_C88_order_d  1
    pool_choice_13[6]  pool_cover_C76_order_p  1
    pool_choice_13[6]  pool_cover_C27_order_d  1
    pool_choice_13[6]  pool_cover_C27_order_p  1
    pool_choice_13[6]  R1705     -1
    pool_choice_13[6]  R1716     -1
    pool_choice_13[6]  R1727     -1
    pool_choice_13[6]  R1803     -60
    pool_choice_13[7]  OBJ       6.4531470933056056e+01
    pool_choice_13[7]  R1370     1
    pool_choice_13[7]  R1371     -60
    pool_choice_13[7]  R1378     -1
    pool_choice_13[7]  R1387     -1
    pool_choice_13[7]  R1403     -1
    pool_choice_13[7]  R1404     -1
    pool_choice_13[7]  R1408     -1
    pool_choice_13[7]  R1411     -1
    pool_choice_13[7]  pool_cover_C88_order_d  1
    pool_choice_13[7]  pool_cover_C88_order_p  1
    pool_choice_13[7]  pool_cover_C76_order_p  1
    pool_choice_13[7]  pool_cover_C27_order_p  1
    pool_choice_13[7]  R1702     -1
    pool_choice_13[7]  R1727     -1
    pool_choice_13[7]  R1737     -1
    pool_choice_13[7]  R1803     -60
    pool_choice_13[8]  OBJ       4.8741939160438513e+01
    pool_choice_13[8]  R1370     1
    pool_choice_13[8]  R1371     -60
    pool_choice_13[8]  R1379     -1
    pool_choice_13[8]  R1387     -1
    pool_choice_13[8]  R1403     -1
    pool_choice_13[8]  R1404     -1
    pool_choice_13[8]  R1411     -1
    pool_choice_13[8]  pool_cover_C76_order_p  1
    pool_choice_13[8]  pool_cover_C27_order_d  1
    pool_choice_13[8]  pool_cover_C27_order_p  1
    pool_choice_13[8]  R1705     -1
    pool_choice_13[8]  R1727     -1
    pool_choice_13[8]  R1803     -60
    pool_choice_13[9]  OBJ       4.8741939160438520e+01
    pool_choice_13[9]  R1370     1
    pool_choice_13[9]  R1371     -60
    pool_choice_13[9]  R1377     -1
    pool_choice_13[9]  R1392     -1
    pool_choice_13[9]  R1403     -1
    pool_choice_13[9]  R1411     -1
    pool_choice_13[9]  pool_cover_C76_order_d  1
    pool_choice_13[9]  pool_cover_C27_order_d  1
    pool_choice_13[9]  pool_cover_C27_order_p  1
    pool_choice_13[9]  R1705     -1
    pool_choice_13[9]  R1726     -1
    pool_choice_13[9]  R1803     -60
    pool_choice_13[10]  OBJ       49.4006172001918
    pool_choice_13[10]  R1370     1
    pool_choice_13[10]  R1371     -60
    pool_choice_13[10]  R1377     -1
    pool_choice_13[10]  R1387     -1
    pool_choice_13[10]  R1404     -1
    pool_choice_13[10]  R1411     -1
    pool_choice_13[10]  pool_cover_C76_order_d  1
    pool_choice_13[10]  pool_cover_C76_order_p  1
    pool_choice_13[10]  pool_cover_C27_order_d  1
    pool_choice_13[10]  R1726     -1
    pool_choice_13[10]  R1757     -1
    pool_choice_13[10]  R1803     -60
    pool_choice_13[11]  OBJ       49.4006172001918
    pool_choice_13[11]  R1370     1
    pool_choice_13[11]  R1371     -60
    pool_choice_13[11]  R1377     -1
    pool_choice_13[11]  R1387     -1
    pool_choice_13[11]  R1403     -1
    pool_choice_13[11]  R1404     -1
    pool_choice_13[11]  R1411     -1
    pool_choice_13[11]  pool_cover_C76_order_d  1
    pool_choice_13[11]  pool_cover_C76_order_p  1
    pool_choice_13[11]  pool_cover_C27_order_p  1
    pool_choice_13[11]  R1727     -1
    pool_choice_13[11]  R1758     -1
    pool_choice_13[11]  R1803     -60
    pool_choice_13[12]  OBJ       8.7378337228328149e+01
    pool_choice_13[12]  R1370     1
    pool_choice_13[12]  R1371     -60
    pool_choice_13[12]  R1377     -1
    pool_choice_13[12]  R1393     -1
    pool_choice_13[12]  R1403     -1
    pool_choice_13[12]  R1404     -1
    pool_choice_13[12]  R1409     -1
    pool_choice_13[12]  R1411     -1
    pool_choice_13[12]  pool_cover_C76_order_d  1
    pool_choice_13[12]  pool_cover_C76_order_p  1
    pool_choice_13[12]  pool_cover_C27_order_d  1
    pool_choice_13[12]  pool_cover_C27_order_p  1
    pool_choice_13[12]  pool_cover_C46_order_p  1
    pool_choice_13[12]  R1705     -1
    pool_choice_13[12]  R1726     -1
    pool_choice_13[12]  R1727     -1
    pool_choice_13[12]  R1759     -1
    pool_choice_13[12]  R1803     -60
    pool_choice_13[13]  OBJ       8.7860987895133547e+01
    pool_choice_13[13]  R1370     1
    pool_choice_13[13]  R1371     -60
    pool_choice_13[13]  R1377     -1
    pool_choice_13[13]  R1387     -1
    pool_choice_13[13]  R1403     -1
    pool_choice_13[13]  R1404     -1
    pool_choice_13[13]  R1408     -1
    pool_choice_13[13]  R1411     -1
    pool_choice_13[13]  pool_cover_C88_order_p  1
    pool_choice_13[13]  pool_cover_C76_order_d  1
    pool_choice_13[13]  pool_cover_C76_order_p  1
    pool_choice_13[13]  pool_cover_C27_order_d  1
    pool_choice_13[13]  pool_cover_C27_order_p  1
    pool_choice_13[13]  R1705     -1
    pool_choice_13[13]  R1725     -1
    pool_choice_13[13]  R1726     -1
    pool_choice_13[13]  R1735     -1
    pool_choice_13[13]  R1803     -60
    pool_choice_13[14]  OBJ       9.0058684937784989e+01
    pool_choice_13[14]  R1370     1
    pool_choice_13[14]  R1371     -60
    pool_choice_13[14]  R1377     -1
    pool_choice_13[14]  R1394     -1
    pool_choice_13[14]  R1403     -1
    pool_choice_13[14]  R1404     -1
    pool_choice_13[14]  R1410     -1
    pool_choice_13[14]  R1411     -1
    pool_choice_13[14]  pool_cover_C76_order_d  1
    pool_choice_13[14]  pool_cover_C76_order_p  1
    pool_choice_13[14]  pool_cover_C27_order_d  1
    pool_choice_13[14]  pool_cover_C27_order_p  1
    pool_choice_13[14]  pool_cover_C6_order_p  1
    pool_choice_13[14]  R1705     -1
    pool_choice_13[14]  R1726     -1
    pool_choice_13[14]  R1727     -1
    pool_choice_13[14]  R1760     -1
    pool_choice_13[14]  R1803     -60
    pool_choice_13[15]  OBJ       7.2065746739819716e+01
    pool_choice_13[15]  R1370     1
    pool_choice_13[15]  R1371     -60
    pool_choice_13[15]  R1379     -1
    pool_choice_13[15]  R1387     -1
    pool_choice_13[15]  R1403     -1
    pool_choice_13[15]  R1404     -1
    pool_choice_13[15]  R1411     -1
    pool_choice_13[15]  pool_cover_C76_order_d  1
    pool_choice_13[15]  pool_cover_C76_order_p  1
    pool_choice_13[15]  pool_cover_C27_order_d  1
    pool_choice_13[15]  pool_cover_C27_order_p  1
    pool_choice_13[15]  R1717     -1
    pool_choice_13[15]  R1727     -1
    pool_choice_13[15]  R1758     -1
    pool_choice_13[15]  R1803     -60
    pool_choice_13[16]  OBJ       7.9662324665920323e+01
    pool_choice_13[16]  R1370     1
    pool_choice_13[16]  R1371     -60
    pool_choice_13[16]  R1378     -1
    pool_choice_13[16]  R1391     -1
    pool_choice_13[16]  R1403     -1
    pool_choice_13[16]  R1408     -1
    pool_choice_13[16]  R1411     -1
    pool_choice_13[16]  pool_cover_C88_order_d  1
    pool_choice_13[16]  pool_cover_C88_order_p  1
    pool_choice_13[16]  pool_cover_C27_order_d  1
    pool_choice_13[16]  pool_cover_C27_order_p  1
    pool_choice_13[16]  R1705     -1
    pool_choice_13[16]  R1716     -1
    pool_choice_13[16]  R1735     -1
    pool_choice_13[16]  R1803     -60
    pool_choice_13[17]  OBJ       8.7860987895133547e+01
    pool_choice_13[17]  R1370     1
    pool_choice_13[17]  R1371     -60
    pool_choice_13[17]  R1377     -1
    pool_choice_13[17]  R1387     -1
    pool_choice_13[17]  R1404     -1
    pool_choice_13[17]  R1408     -1
    pool_choice_13[17]  R1411     -1
    pool_choice_13[17]  pool_cover_C88_order_p  1
    pool_choice_13[17]  pool_cover_C76_order_d  1
    pool_choice_13[17]  pool_cover_C76_order_p  1
    pool_choice_13[17]  pool_cover_C27_order_d  1
    pool_choice_13[17]  R1725     -1
    pool_choice_13[17]  R1726     -1
    pool_choice_13[17]  R1741     -1
    pool_choice_13[17]  R1803     -60
    pool_choice_13[18]  OBJ       8.7860987895133547e+01
    pool_choice_13[18]  R1370     1
    pool_choice_13[18]  R1371     -60
    pool_choice_13[18]  R1377     -1
    pool_choice_13[18]  R1387     -1
    pool_choice_13[18]  R1403     -1
    pool_choice_13[18]  R1404     -1
    pool_choice_13[18]  R1408     -1
    pool_choice_13[18]  R1411     -1
    pool_choice_13[18]  pool_cover_C88_order_p  1
    pool_choice_13[18]  pool_cover_C76_order_d  1
    pool_choice_13[18]  pool_cover_C76_order_p  1
    pool_choice_13[18]  pool_cover_C27_order_p  1
    pool_choice_13[18]  R1727     -1
    pool_choice_13[18]  R1734     -1
    pool_choice_13[18]  R1737     -1
    pool_choice_13[18]  R1803     -60
    pool_choice_13[19]  OBJ       1.1117439804611379e+02
    pool_choice_13[19]  R1370     1
    pool_choice_13[19]  R1371     -60
    pool_choice_13[19]  R1377     -1
    pool_choice_13[19]  R1387     -1
    pool_choice_13[19]  R1403     -1
    pool_choice_13[19]  R1404     -1
    pool_choice_13[19]  R1408     -1
    pool_choice_13[19]  R1411     -1
    pool_choice_13[19]  pool_cover_C88_order_p  1
    pool_choice_13[19]  pool_cover_C76_order_d  1
    pool_choice_13[19]  pool_cover_C76_order_p  1
    pool_choice_13[19]  pool_cover_C27_order_d  1
    pool_choice_13[19]  pool_cover_C27_order_p  1
    pool_choice_13[19]  R1726     -1
    pool_choice_13[19]  R1727     -1
    pool_choice_13[19]  R1737     -1
    pool_choice_13[19]  R1741     -1
    pool_choice_13[19]  R1803     -60
    pool_choice_13[20]  OBJ       4.8083261120685229e+01
    pool_choice_13[20]  R1370     1
    pool_choice_13[20]  R1371     -60
    pool_choice_13[20]  R1379     -1
    pool_choice_13[20]  R1392     -1
    pool_choice_13[20]  R1403     -1
    pool_choice_13[20]  R1411     -1
    pool_choice_13[20]  pool_cover_C27_order_d  1
    pool_choice_13[20]  pool_cover_C27_order_p  1
    pool_choice_13[20]  R1705     -1
    pool_choice_13[20]  R1803     -60
    pool_choice_13[21]  OBJ       2.0654115613359256e+01
    pool_choice_13[21]  R1370     1
    pool_choice_13[21]  R1380     -1
    pool_choice_13[21]  R1389     -1
    pool_choice_13[21]  R1406     -1
    pool_choice_13[21]  R1408     -1
    pool_choice_13[21]  pool_cover_C88_order_p  1
    pool_choice_13[21]  pool_cover_C29_order_p  1
    pool_choice_13[21]  R1709     -1
    pool_choice_13[22]  OBJ       1.7888543819998318e+01
    pool_choice_13[22]  R1370     1
    pool_choice_13[22]  R1371     -60
    pool_choice_13[22]  R1378     -1
    pool_choice_13[22]  R1395     -1
    pool_choice_13[22]  R1411     -1
    pool_choice_13[22]  pool_cover_C88_order_d  1
    pool_choice_13[22]  R1803     -60
    pool_choice_13[23]  OBJ       2.0654115613359256e+01
    pool_choice_13[23]  R1370     1
    pool_choice_13[23]  R1371     -60
    pool_choice_13[23]  R1378     -1
    pool_choice_13[23]  R1389     -1
    pool_choice_13[23]  R1406     -1
    pool_choice_13[23]  R1408     -1
    pool_choice_13[23]  R1411     -1
    pool_choice_13[23]  pool_cover_C88_order_d  1
    pool_choice_13[23]  pool_cover_C88_order_p  1
    pool_choice_13[23]  pool_cover_C29_order_p  1
    pool_choice_13[23]  R1702     -1
    pool_choice_13[23]  R1709     -1
    pool_choice_13[23]  R1803     -60
    pool_choice_13[24]  OBJ       1.1661903789690601e+01
    pool_choice_13[24]  R1370     1
    pool_choice_13[24]  R1371     -60
    pool_choice_13[24]  R1381     -1
    pool_choice_13[24]  R1396     -1
    pool_choice_13[24]  R1412     -1
    pool_choice_13[24]  pool_cover_C47_order_d  1
    pool_choice_13[24]  R1803     -60
    pool_choice_13[25]  OBJ       1.1661903789690601e+01
    pool_choice_13[25]  R1370     1
    pool_choice_13[25]  R1371     -60
    pool_choice_13[25]  R1381     -1
    pool_choice_13[25]  R1388     -1
    pool_choice_13[25]  R1405     -1
    pool_choice_13[25]  R1412     -1
    pool_choice_13[25]  pool_cover_C47_order_d  1
    pool_choice_13[25]  pool_cover_C47_order_p  1
    pool_choice_13[25]  R1701     -1
    pool_choice_13[25]  R1803     -60
    pool_choice_13[26]  OBJ       20.591260281974
    pool_choice_13[26]  R1370     1
    pool_choice_13[26]  R1371     -60
    pool_choice_13[26]  R1382     -1
    pool_choice_13[26]  R1397     -1
    pool_choice_13[26]  R1413     -1
    pool_choice_13[26]  pool_cover_C29_order_d  1
    pool_choice_13[26]  R1803     -60
    pool_choice_13[27]  OBJ       20.591260281974
    pool_choice_13[27]  R1370     1
    pool_choice_13[27]  R1371     -60
    pool_choice_13[27]  R1382     -1
    pool_choice_13[27]  R1389     -1
    pool_choice_13[27]  R1406     -1
    pool_choice_13[27]  R1413     -1
    pool_choice_13[27]  pool_cover_C29_order_d  1
    pool_choice_13[27]  pool_cover_C29_order_p  1
    pool_choice_13[27]  R1703     -1
    pool_choice_13[27]  R1803     -60
    pool_choice_13[28]  OBJ       1.1661903789690601e+01
    pool_choice_13[28]  R1370     1
    pool_choice_13[28]  R1383     -1
    pool_choice_13[28]  R1388     -1
    pool_choice_13[28]  R1405     -1
    pool_choice_13[28]  pool_cover_C47_order_p  1
    pool_choice_13[29]  OBJ       41.2180607820758
    pool_choice_13[29]  R1370     1
    pool_choice_13[29]  R1371     -60
    pool_choice_13[29]  R1378     -1
    pool_choice_13[29]  R1398     -1
    pool_choice_13[29]  R1411     -1
    pool_choice_13[29]  pool_cover_C88_order_d  1
    pool_choice_13[29]  pool_cover_C76_order_d  1
    pool_choice_13[29]  R1710     -1
    pool_choice_13[29]  R1803     -60
    pool_choice_13[30]  OBJ       1.7888543819998318e+01
    pool_choice_13[30]  R1370     1
    pool_choice_13[30]  R1371     -60
    pool_choice_13[30]  R1378     -1
    pool_choice_13[30]  R1391     -1
    pool_choice_13[30]  R1408     -1
    pool_choice_13[30]  R1411     -1
    pool_choice_13[30]  pool_cover_C88_order_d  1
    pool_choice_13[30]  pool_cover_C88_order_p  1
    pool_choice_13[30]  R1702     -1
    pool_choice_13[30]  R1803     -60
    pool_choice_13[31]  OBJ       4.9397092229415449e+01
    pool_choice_13[31]  R1370     1
    pool_choice_13[31]  R1371     -60
    pool_choice_13[31]  R1381     -1
    pool_choice_13[31]  R1399     -1
    pool_choice_13[31]  R1412     -1
    pool_choice_13[31]  pool_cover_C47_order_d  1
    pool_choice_13[31]  pool_cover_C25_order_d  1
    pool_choice_13[31]  R1711     -1
    pool_choice_13[31]  R1803     -60
    pool_choice_13[32]  OBJ       3.1747081387645608e+01
    pool_choice_13[32]  R1370     1
    pool_choice_13[32]  R1371     -60
    pool_choice_13[32]  R1381     -1
    pool_choice_13[32]  R1389     -1
    pool_choice_13[32]  R1405     -1
    pool_choice_13[32]  R1406     -1
    pool_choice_13[32]  R1412     -1
    pool_choice_13[32]  pool_cover_C47_order_d  1
    pool_choice_13[32]  pool_cover_C47_order_p  1
    pool_choice_13[32]  pool_cover_C29_order_p  1
    pool_choice_13[32]  R1701     -1
    pool_choice_13[32]  R1712     -1
    pool_choice_13[32]  R1803     -60
    pool_choice_13[33]  OBJ       7.5601410152021032e+01
    pool_choice_13[33]  R1370     1
    pool_choice_13[33]  R1371     -60
    pool_choice_13[33]  R1382     -1
    pool_choice_13[33]  R1400     -1
    pool_choice_13[33]  R1413     -1
    pool_choice_13[33]  pool_cover_C29_order_d  1
    pool_choice_13[33]  pool_cover_C6_order_d  1
    pool_choice_13[33]  R1713     -1
    pool_choice_13[33]  R1803     -60
    pool_choice_13[34]  OBJ       8.7673299606967689e+01
    pool_choice_13[34]  R1370     1
    pool_choice_13[34]  R1371     -60
    pool_choice_13[34]  R1382     -1
    pool_choice_13[34]  R1389     -1
    pool_choice_13[34]  R1406     -1
    pool_choice_13[34]  R1410     -1
    pool_choice_13[34]  R1413     -1
    pool_choice_13[34]  pool_cover_C29_order_d  1
    pool_choice_13[34]  pool_cover_C29_order_p  1
    pool_choice_13[34]  pool_cover_C6_order_d  1
    pool_choice_13[34]  pool_cover_C6_order_p  1
    pool_choice_13[34]  R1708     -1
    pool_choice_13[34]  R1713     -1
    pool_choice_13[34]  R1714     -1
    pool_choice_13[34]  R1803     -60
    pool_choice_13[35]  OBJ       2.7115567956485918e+01
    pool_choice_13[35]  R1370     1
    pool_choice_13[35]  R1384     -1
    pool_choice_13[35]  R1388     -1
    pool_choice_13[35]  R1404     -1
    pool_choice_13[35]  R1405     -1
    pool_choice_13[35]  pool_cover_C76_order_p  1
    pool_choice_13[35]  pool_cover_C47_order_p  1
    pool_choice_13[35]  R1715     -1
    pool_choice_13[36]  OBJ       6.4531470933056056e+01
    pool_choice_13[36]  R1370     1
    pool_choice_13[36]  R1371     -60
    pool_choice_13[36]  R1378     -1
    pool_choice_13[36]  R1398     -1
    pool_choice_13[36]  R1411     -1
    pool_choice_13[36]  pool_cover_C88_order_d  1
    pool_choice_13[36]  pool_cover_C76_order_d  1
    pool_choice_13[36]  pool_cover_C27_order_d  1
    pool_choice_13[36]  R1716     -1
    pool_choice_13[36]  R1717     -1
    pool_choice_13[36]  R1803     -60
    pool_choice_13[37]  OBJ       2.7115567956485918e+01
    pool_choice_13[37]  R1370     1
    pool_choice_13[37]  R1371     -60
    pool_choice_13[37]  R1377     -1
    pool_choice_13[37]  R1388     -1
    pool_choice_13[37]  R1404     -1
    pool_choice_13[37]  R1405     -1
    pool_choice_13[37]  R1411     -1
    pool_choice_13[37]  pool_cover_C76_order_d  1
    pool_choice_13[37]  pool_cover_C76_order_p  1
    pool_choice_13[37]  pool_cover_C47_order_p  1
    pool_choice_13[37]  R1704     -1
    pool_choice_13[37]  R1715     -1
    pool_choice_13[37]  R1803     -60
    pool_choice_13[38]  OBJ       6.4631964712286560e+01
    pool_choice_13[38]  R1370     1
    pool_choice_13[38]  R1371     -60
    pool_choice_13[38]  R1381     -1
    pool_choice_13[38]  R1401     -1
    pool_choice_13[38]  R1412     -1
    pool_choice_13[38]  pool_cover_C47_order_d  1
    pool_choice_13[38]  pool_cover_C46_order_d  1
    pool_choice_13[38]  R1718     -1
    pool_choice_13[38]  R1803     -60
    pool_choice_13[39]  OBJ       4.9397828317917018e+01
    pool_choice_13[39]  R1370     1
    pool_choice_13[39]  R1371     -60
    pool_choice_13[39]  R1381     -1
    pool_choice_13[39]  R1388     -1
    pool_choice_13[39]  R1405     -1
    pool_choice_13[39]  R1407     -1
    pool_choice_13[39]  R1412     -1
    pool_choice_13[39]  pool_cover_C47_order_d  1
    pool_choice_13[39]  pool_cover_C47_order_p  1
    pool_choice_13[39]  pool_cover_C25_order_d  1
    pool_choice_13[39]  pool_cover_C25_order_p  1
    pool_choice_13[39]  R1706     -1
    pool_choice_13[39]  R1711     -1
    pool_choice_13[39]  R1719     -1
    pool_choice_13[39]  R1803     -60
    pool_choice_13[40]  OBJ       6.3529520697074361e+01
    pool_choice_13[40]  R1370     1
    pool_choice_13[40]  R1371     -60
    pool_choice_13[40]  R1385     -1
    pool_choice_13[40]  R1400     -1
    pool_choice_13[40]  R1413     -1
    pool_choice_13[40]  pool_cover_C6_order_d  1
    pool_choice_13[40]  R1803     -60
    pool_choice_13[41]  OBJ       7.5601410152021018e+01
    pool_choice_13[41]  R1370     1
    pool_choice_13[41]  R1371     -60
    pool_choice_13[41]  R1385     -1
    pool_choice_13[41]  R1389     -1
    pool_choice_13[41]  R1406     -1
    pool_choice_13[41]  R1410     -1
    pool_choice_13[41]  R1413     -1
    pool_choice_13[41]  pool_cover_C29_order_p  1
    pool_choice_13[41]  pool_cover_C6_order_d  1
    pool_choice_13[41]  pool_cover_C6_order_p  1
    pool_choice_13[41]  R1708     -1
    pool_choice_13[41]  R1714     -1
    pool_choice_13[41]  R1803     -60
    pool_choice_13[42]  OBJ       5.5723778079391167e+01
    pool_choice_13[42]  R1370     1
    pool_choice_13[42]  R1384     -1
    pool_choice_13[42]  R1388     -1
    pool_choice_13[42]  R1403     -1
    pool_choice_13[42]  R1404     -1
    pool_choice_13[42]  R1405     -1
    pool_choice_13[42]  R1407     -1
    pool_choice_13[42]  pool_cover_C76_order_p  1
    pool_choice_13[42]  pool_cover_C27_order_p  1
    pool_choice_13[42]  pool_cover_C47_order_p  1
    pool_choice_13[42]  pool_cover_C25_order_p  1
    pool_choice_13[42]  R1719     -1
    pool_choice_13[42]  R1720     -1
    pool_choice_13[42]  R1721     -1
    pool_choice_13[43]  OBJ       4.8741939160438513e+01
    pool_choice_13[43]  R1370     1
    pool_choice_13[43]  R1371     -60
    pool_choice_13[43]  R1379     -1
    pool_choice_13[43]  R1398     -1
    pool_choice_13[43]  R1411     -1
    pool_choice_13[43]  pool_cover_C76_order_d  1
    pool_choice_13[43]  pool_cover_C27_order_d  1
    pool_choice_13[43]  R1717     -1
    pool_choice_13[43]  R1803     -60
    pool_choice_13[44]  OBJ       2.8987894208396355e+01
    pool_choice_13[44]  R1370     1
    pool_choice_13[44]  R1371     -60
    pool_choice_13[44]  R1378     -1
    pool_choice_13[44]  R1388     -1
    pool_choice_13[44]  R1405     -1
    pool_choice_13[44]  R1408     -1
    pool_choice_13[44]  R1411     -1
    pool_choice_13[44]  pool_cover_C88_order_d  1
    pool_choice_13[44]  pool_cover_C88_order_p  1
    pool_choice_13[44]  pool_cover_C47_order_p  1
    pool_choice_13[44]  R1702     -1
    pool_choice_13[44]  R1722     -1
    pool_choice_13[44]  R1803     -60
    pool_choice_13[45]  OBJ       8.1012524190345616e+01
    pool_choice_13[45]  R1370     1
    pool_choice_13[45]  R1371     -60
    pool_choice_13[45]  R1386     -1
    pool_choice_13[45]  R1401     -1
    pool_choice_13[45]  R1412     -1
    pool_choice_13[45]  pool_cover_C25_order_d  1
    pool_choice_13[45]  pool_cover_C46_order_d  1
    pool_choice_13[45]  R1723     -1
    pool_choice_13[45]  R1803     -60
    pool_choice_13[46]  OBJ       6.9483005915872027e+01
    pool_choice_13[46]  R1370     1
    pool_choice_13[46]  R1371     -60
    pool_choice_13[46]  R1381     -1
    pool_choice_13[46]  R1389     -1
    pool_choice_13[46]  R1405     -1
    pool_choice_13[46]  R1406     -1
    pool_choice_13[46]  R1407     -1
    pool_choice_13[46]  R1412     -1
    pool_choice_13[46]  pool_cover_C47_order_d  1
    pool_choice_13[46]  pool_cover_C47_order_p  1
    pool_choice_13[46]  pool_cover_C25_order_d  1
    pool_choice_13[46]  pool_cover_C25_order_p  1
    pool_choice_13[46]  pool_cover_C29_order_p  1
    pool_choice_13[46]  R1706     -1
    pool_choice_13[46]  R1711     -1
    pool_choice_13[46]  R1712     -1
    pool_choice_13[46]  R1719     -1
    pool_choice_13[46]  R1803     -60
    pool_choice_13[47]  OBJ       7.5601410152021032e+01
    pool_choice_13[47]  R1370     1
    pool_choice_13[47]  R1371     -60
    pool_choice_13[47]  R1382     -1
    pool_choice_13[47]  R1394     -1
    pool_choice_13[47]  R1406     -1
    pool_choice_13[47]  R1410     -1
    pool_choice_13[47]  R1413     -1
    pool_choice_13[47]  pool_cover_C29_order_d  1
    pool_choice_13[47]  pool_cover_C29_order_p  1
    pool_choice_13[47]  pool_cover_C6_order_p  1
    pool_choice_13[47]  R1703     -1
    pool_choice_13[47]  R1724     -1
    pool_choice_13[47]  R1803     -60
    pool_choice_13[48]  OBJ       4.2256819117751121e+01
    pool_choice_13[48]  R1370     1
    pool_choice_13[48]  R1380     -1
    pool_choice_13[48]  R1388     -1
    pool_choice_13[48]  R1404     -1
    pool_choice_13[48]  R1405     -1
    pool_choice_13[48]  R1408     -1
    pool_choice_13[48]  pool_cover_C88_order_p  1
    pool_choice_13[48]  pool_cover_C76_order_p  1
    pool_choice_13[48]  pool_cover_C47_order_p  1
    pool_choice_13[48]  R1715     -1
    pool_choice_13[48]  R1725     -1
    pool_choice_13[49]  OBJ       4.8741939160438520e+01
    pool_choice_13[49]  R1370     1
    pool_choice_13[49]  R1371     -60
    pool_choice_13[49]  R1377     -1
    pool_choice_13[49]  R1402     -1
    pool_choice_13[49]  R1411     -1
    pool_choice_13[49]  pool_cover_C76_order_d  1
    pool_choice_13[49]  pool_cover_C27_order_d  1
    pool_choice_13[49]  R1726     -1
    pool_choice_13[49]  R1803     -60
    pool_choice_13[50]  OBJ       4.9396356140913873e+01
    pool_choice_13[50]  R1370     1
    pool_choice_13[50]  R1371     -60
    pool_choice_13[50]  R1386     -1
    pool_choice_13[50]  R1399     -1
    pool_choice_13[50]  R1412     -1
    pool_choice_13[50]  pool_cover_C25_order_d  1
    pool_choice_13[50]  R1803     -60
    pool_choice_13[51]  OBJ       3.1747081387645608e+01
    pool_choice_13[51]  R1370     1
    pool_choice_13[51]  R1371     -60
    pool_choice_13[51]  R1381     -1
    pool_choice_13[51]  R1389     -1
    pool_choice_13[51]  R1406     -1
    pool_choice_13[51]  R1412     -1
    pool_choice_13[51]  pool_cover_C47_order_d  1
    pool_choice_13[51]  pool_cover_C29_order_p  1
    pool_choice_13[51]  R1728     -1
    pool_choice_13[51]  R1803     -60
    pool_choice_13[52]  OBJ       7.5601410152021032e+01
    pool_choice_13[52]  R1370     1
    pool_choice_13[52]  R1371     -60
    pool_choice_13[52]  R1382     -1
    pool_choice_13[52]  R1394     -1
    pool_choice_13[52]  R1410     -1
    pool_choice_13[52]  R1413     -1
    pool_choice_13[52]  pool_cover_C29_order_d  1
    pool_choice_13[52]  pool_cover_C6_order_d  1
    pool_choice_13[52]  pool_cover_C6_order_p  1
    pool_choice_13[52]  R1708     -1
    pool_choice_13[52]  R1713     -1
    pool_choice_13[52]  R1803     -60
    pool_used_13  R1370     -1
    pool_used_13  R1371     -28800
    pool_used_13  R1372     -75600
    pool_used_13  R1373     -75540
    pool_used_13  R1374     -1
    pool_used_13  R1375     -80
    pool_used_13  R1376     -80
    pool_used_13  R1803     -75660
    pool_used_13  R1804     -81
    pool_used_13  R1809     -75660
    pool_used_13  R1810     -81
    pool_used_13  R1811     -75660
    pool_used_13  R1812     -81
    pool_start_13  R1371     1
    pool_start_13  R1372     1
    pool_start_13  R1803     1
    pool_start_13  GC1027    -1
    pool_start_13  GC1029    -1
    pool_start_13  GC1031    -1
    pool_start_13  GC1033    -1
    pool_start_13  GC1035    -1
    pool_start_13  GC1037    -1
    pool_start_13  GC1039    -1
    pool_start_13  GC1041    -1
    pool_start_13  GC1043    -1
    pool_start_13  GC1045    -1
    pool_start_13  GC1087    1
    pool_start_13  GC1088    1
    pool_start_13  GC1089    1
    pool_end_13  R1373     1
    pool_end_13  R1809     -1
    pool_end_13  R1811     -1
    pool_end_13  GC1047    1
    pool_end_13  GC1049    1
    pool_end_13  GC1051    1
    pool_end_13  GC1053    1
    pool_end_13  GC1055    1
    pool_end_13  GC1057    1
    pool_end_13  GC1059    1
    pool_end_13  GC1061    1
    pool_end_13  GC1063    1
    pool_end_13  GC1065    1
    pool_end_13  GC1067    1
    pool_end_13  GC1069    1
    pool_end_13  GC1071    1
    pool_end_13  GC1073    1
    pool_end_13  GC1075    1
    pool_end_13  GC1077    1
    pool_end_13  GC1079    -1
    pool_end_13  GC1080    -1
    pool_end_13  GC1081    -1
    pool_end_13  GC1082    -1
    pool_end_13  GC1083    -1
    pool_end_13  GC1084    -1
    pool_end_13  GC1085    -1
    pool_end_13  GC1086    -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_13  R1374     1
    pool_start_rank_13  R1375     1
    pool_start_rank_13  R1804     1
    pool_start_rank_13  GC1028    -1
    pool_start_rank_13  GC1030    -1
    pool_start_rank_13  GC1032    -1
    pool_start_rank_13  GC1034    -1
    pool_start_rank_13  GC1036    -1
    pool_start_rank_13  GC1038    -1
    pool_start_rank_13  GC1040    -1
    pool_start_rank_13  GC1042    -1
    pool_start_rank_13  GC1044    -1
    pool_start_rank_13  GC1046    -1
    pool_end_rank_13  R1376     1
    pool_end_rank_13  R1810     -1
    pool_end_rank_13  R1812     -1
    pool_end_rank_13  GC1048    1
    pool_end_rank_13  GC1050    1
    pool_end_rank_13  GC1052    1
    pool_end_rank_13  GC1054    1
    pool_end_rank_13  GC1056    1
    pool_end_rank_13  GC1058    1
    pool_end_rank_13  GC1060    1
    pool_end_rank_13  GC1062    1
    pool_end_rank_13  GC1064    1
    pool_end_rank_13  GC1066    1
    pool_end_rank_13  GC1068    1
    pool_end_rank_13  GC1070    1
    pool_end_rank_13  GC1072    1
    pool_end_rank_13  GC1074    1
    pool_end_rank_13  GC1076    1
    pool_end_rank_13  GC1078    1
    MARKER    'MARKER'                 'INTORG'
    pool_first_13_C76_order_d  R1377     1
    pool_first_13_C88_order_d  R1378     1
    pool_first_13_C27_order_d  R1379     1
    pool_first_13_C88_order_p  R1380     1
    pool_first_13_C47_order_d  R1381     1
    pool_first_13_C29_order_d  R1382     1
    pool_first_13_C47_order_p  R1383     1
    pool_first_13_C76_order_p  R1384     1
    pool_first_13_C6_order_d  R1385     1
    pool_first_13_C25_order_d  R1386     1
    pool_last_13_C76_order_p  R1387     1
    pool_last_13_C47_order_p  R1388     1
    pool_last_13_C29_order_p  R1389     1
    pool_last_13_C25_order_p  R1390     1
    pool_last_13_C88_order_p  R1391     1
    pool_last_13_C27_order_p  R1392     1
    pool_last_13_C46_order_p  R1393     1
    pool_last_13_C6_order_p  R1394     1
    pool_last_13_C88_order_d  R1395     1
    pool_last_13_C47_order_d  R1396     1
    pool_last_13_C29_order_d  R1397     1
    pool_last_13_C76_order_d  R1398     1
    pool_last_13_C25_order_d  R1399     1
    pool_last_13_C6_order_d  R1400     1
    pool_last_13_C46_order_d  R1401     1
    pool_last_13_C27_order_d  R1402     1
    pool_pickup_13_C27_order  R1403     1
    pool_pickup_13_C76_order  R1404     1
    pool_pickup_13_C47_order  R1405     1
    pool_pickup_13_C29_order  R1406     1
    pool_pickup_13_C25_order  R1407     1
    pool_pickup_13_C88_order  R1408     1
    pool_pickup_13_C46_order  R1409     1
    pool_pickup_13_C6_order  R1410     1
    pool_batch_13_b1  R1411     1
    pool_batch_13_b2  R1412     1
    pool_batch_13_b3  R1413     1
    pool_choice_14[0]  OBJ       6.2032249677083293e+01
    pool_choice_14[0]  R1414     1
    pool_choice_14[0]  R1415     -60
    pool_choice_14[0]  R1421     -1
    pool_choice_14[0]  R1433     -1
    pool_choice_14[0]  R1447     -1
    pool_choice_14[0]  R1455     -1
    pool_choice_14[0]  pool_cover_C46_order_d  1
    pool_choice_14[0]  pool_cover_C46_order_p  1
    pool_choice_14[0]  R1707     -1
    pool_choice_14[0]  R1805     -60
    pool_choice_14[0]  R1809     -60
    pool_choice_14[1]  OBJ       1.1661903789690601e+01
    pool_choice_14[1]  R1414     1
    pool_choice_14[1]  R1415     -60
    pool_choice_14[1]  R1422     -1
    pool_choice_14[1]  R1434     -1
    pool_choice_14[1]  R1448     -1
    pool_choice_14[1]  R1455     -1
    pool_choice_14[1]  pool_cover_C47_order_d  1
    pool_choice_14[1]  pool_cover_C47_order_p  1
    pool_choice_14[1]  R1701     -1
    pool_choice_14[1]  R1805     -60
    pool_choice_14[1]  R1809     -60
    pool_choice_14[2]  OBJ       1.7888543819998318e+01
    pool_choice_14[2]  R1414     1
    pool_choice_14[2]  R1415     -60
    pool_choice_14[2]  R1423     -1
    pool_choice_14[2]  R1435     -1
    pool_choice_14[2]  R1449     -1
    pool_choice_14[2]  R1456     -1
    pool_choice_14[2]  pool_cover_C88_order_d  1
    pool_choice_14[2]  pool_cover_C88_order_p  1
    pool_choice_14[2]  R1702     -1
    pool_choice_14[2]  R1805     -60
    pool_choice_14[2]  R1809     -60
    pool_choice_14[3]  OBJ       20.591260281974
    pool_choice_14[3]  R1414     1
    pool_choice_14[3]  R1415     -60
    pool_choice_14[3]  R1424     -1
    pool_choice_14[3]  R1436     -1
    pool_choice_14[3]  R1450     -1
    pool_choice_14[3]  R1457     -1
    pool_choice_14[3]  pool_cover_C29_order_d  1
    pool_choice_14[3]  pool_cover_C29_order_p  1
    pool_choice_14[3]  R1703     -1
    pool_choice_14[3]  R1805     -60
    pool_choice_14[3]  R1809     -60
    pool_choice_14[4]  OBJ       6.7231679747489821e+01
    pool_choice_14[4]  R1414     1
    pool_choice_14[4]  R1415     -60
    pool_choice_14[4]  R1422     -1
    pool_choice_14[4]  R1434     -1
    pool_choice_14[4]  R1447     -1
    pool_choice_14[4]  R1448     -1
    pool_choice_14[4]  R1455     -1
    pool_choice_14[4]  pool_cover_C47_order_d  1
    pool_choice_14[4]  pool_cover_C47_order_p  1
    pool_choice_14[4]  pool_cover_C46_order_d  1
    pool_choice_14[4]  pool_cover_C46_order_p  1
    pool_choice_14[4]  R1707     -1
    pool_choice_14[4]  R1718     -1
    pool_choice_14[4]  R1745     -1
    pool_choice_14[4]  R1805     -60
    pool_choice_14[4]  R1809     -60
    pool_choice_14[5]  OBJ       6.4631964712286560e+01
    pool_choice_14[5]  R1414     1
    pool_choice_14[5]  R1415     -60
    pool_choice_14[5]  R1421     -1
    pool_choice_14[5]  R1434     -1
    pool_choice_14[5]  R1447     -1
    pool_choice_14[5]  R1448     -1
    pool_choice_14[5]  R1455     -1
    pool_choice_14[5]  pool_cover_C47_order_p  1
    pool_choice_14[5]  pool_cover_C46_order_d  1
    pool_choice_14[5]  pool_cover_C46_order_p  1
    pool_choice_14[5]  R1707     -1
    pool_choice_14[5]  R1745     -1
    pool_choice_14[5]  R1805     -60
    pool_choice_14[5]  R1809     -60
    pool_choice_14[6]  OBJ       6.4631964712286560e+01
    pool_choice_14[6]  R1414     1
    pool_choice_14[6]  R1415     -60
    pool_choice_14[6]  R1422     -1
    pool_choice_14[6]  R1433     -1
    pool_choice_14[6]  R1447     -1
    pool_choice_14[6]  R1455     -1
    pool_choice_14[6]  pool_cover_C47_order_d  1
    pool_choice_14[6]  pool_cover_C46_order_d  1
    pool_choice_14[6]  pool_cover_C46_order_p  1
    pool_choice_14[6]  R1707     -1
    pool_choice_14[6]  R1718     -1
    pool_choice_14[6]  R1805     -60
    pool_choice_14[6]  R1809     -60
    pool_choice_14[7]  OBJ       6.6903990812696492e+01
    pool_choice_14[7]  R1414     1
    pool_choice_14[7]  R1415     -60
    pool_choice_14[7]  R1421     -1
    pool_choice_14[7]  R1437     -1
    pool_choice_14[7]  R1447     -1
    pool_choice_14[7]  R1451     -1
    pool_choice_14[7]  R1455     -1
    pool_choice_14[7]  pool_cover_C46_order_d  1
    pool_choice_14[7]  pool_cover_C46_order_p  1
    pool_choice_14[7]  pool_cover_C6_order_p  1
    pool_choice_14[7]  R1707     -1
    pool_choice_14[7]  R1730     -1
    pool_choice_14[7]  R1805     -60
    pool_choice_14[7]  R1809     -60
    pool_choice_14[8]  OBJ       4.9396356140913873e+01
    pool_choice_14[8]  R1414     1
    pool_choice_14[8]  R1415     -60
    pool_choice_14[8]  R1425     -1
    pool_choice_14[8]  R1438     -1
    pool_choice_14[8]  R1452     -1
    pool_choice_14[8]  R1455     -1
    pool_choice_14[8]  pool_cover_C25_order_d  1
    pool_choice_14[8]  pool_cover_C25_order_p  1
    pool_choice_14[8]  R1706     -1
    pool_choice_14[8]  R1805     -60
    pool_choice_14[8]  R1809     -60
    pool_choice_14[9]  OBJ       4.9397092229415449e+01
    pool_choice_14[9]  R1414     1
    pool_choice_14[9]  R1415     -60
    pool_choice_14[9]  R1422     -1
    pool_choice_14[9]  R1439     -1
    pool_choice_14[9]  R1455     -1
    pool_choice_14[9]  pool_cover_C47_order_d  1
    pool_choice_14[9]  pool_cover_C25_order_d  1
    pool_choice_14[9]  R1711     -1
    pool_choice_14[9]  R1805     -60
    pool_choice_14[9]  R1809     -60
    pool_choice_14[10]  OBJ       9.9992798703607946e+01
    pool_choice_14[10]  R1414     1
    pool_choice_14[10]  R1415     -60
    pool_choice_14[10]  R1425     -1
    pool_choice_14[10]  R1438     -1
    pool_choice_14[10]  R1447     -1
    pool_choice_14[10]  R1452     -1
    pool_choice_14[10]  R1455     -1
    pool_choice_14[10]  pool_cover_C25_order_d  1
    pool_choice_14[10]  pool_cover_C25_order_p  1
    pool_choice_14[10]  pool_cover_C46_order_d  1
    pool_choice_14[10]  pool_cover_C46_order_p  1
    pool_choice_14[10]  R1707     -1
    pool_choice_14[10]  R1723     -1
    pool_choice_14[10]  R1747     -1
    pool_choice_14[10]  R1805     -60
    pool_choice_14[10]  R1809     -60
    pool_choice_14[11]  OBJ       7.5370527711381456e+01
    pool_choice_14[11]  R1414     1
    pool_choice_14[11]  R1415     -60
    pool_choice_14[11]  R1421     -1
    pool_choice_14[11]  R1436     -1
    pool_choice_14[11]  R1447     -1
    pool_choice_14[11]  R1450     -1
    pool_choice_14[11]  R1455     -1
    pool_choice_14[11]  pool_cover_C46_order_d  1
    pool_choice_14[11]  pool_cover_C46_order_p  1
    pool_choice_14[11]  pool_cover_C29_order_p  1
    pool_choice_14[11]  R1707     -1
    pool_choice_14[11]  R1761     -1
    pool_choice_14[11]  R1805     -60
    pool_choice_14[11]  R1809     -60
    pool_choice_14[12]  OBJ       8.1012524190345616e+01
    pool_choice_14[12]  R1414     1
    pool_choice_14[12]  R1415     -60
    pool_choice_14[12]  R1425     -1
    pool_choice_14[12]  R1433     -1
    pool_choice_14[12]  R1447     -1
    pool_choice_14[12]  R1455     -1
    pool_choice_14[12]  pool_cover_C25_order_d  1
    pool_choice_14[12]  pool_cover_C46_order_d  1
    pool_choice_14[12]  pool_cover_C46_order_p  1
    pool_choice_14[12]  R1707     -1
    pool_choice_14[12]  R1723     -1
    pool_choice_14[12]  R1805     -60
    pool_choice_14[12]  R1809     -60
    pool_choice_14[13]  OBJ       8.1012524190345616e+01
    pool_choice_14[13]  R1414     1
    pool_choice_14[13]  R1415     -60
    pool_choice_14[13]  R1421     -1
    pool_choice_14[13]  R1438     -1
    pool_choice_14[13]  R1447     -1
    pool_choice_14[13]  R1452     -1
    pool_choice_14[13]  R1455     -1
    pool_choice_14[13]  pool_cover_C25_order_p  1
    pool_choice_14[13]  pool_cover_C46_order_d  1
    pool_choice_14[13]  pool_cover_C46_order_p  1
    pool_choice_14[13]  R1707     -1
    pool_choice_14[13]  R1747     -1
    pool_choice_14[13]  R1805     -60
    pool_choice_14[13]  R1809     -60
    pool_choice_14[14]  OBJ       1.2020174067008577e+02
    pool_choice_14[14]  R1414     1
    pool_choice_14[14]  R1415     -60
    pool_choice_14[14]  R1422     -1
    pool_choice_14[14]  R1433     -1
    pool_choice_14[14]  R1447     -1
    pool_choice_14[14]  R1448     -1
    pool_choice_14[14]  R1455     -1
    pool_choice_14[14]  pool_cover_C47_order_d  1
    pool_choice_14[14]  pool_cover_C47_order_p  1
    pool_choice_14[14]  pool_cover_C46_order_d  1
    pool_choice_14[14]  pool_cover_C46_order_p  1
    pool_choice_14[14]  R1718     -1
    pool_choice_14[14]  R1733     -1
    pool_choice_14[14]  R1762     -1
    pool_choice_14[14]  R1805     -60
    pool_choice_14[14]  R1809     -60
    pool_choice_14[15]  OBJ       6.3529520697074361e+01
    pool_choice_14[15]  R1414     1
    pool_choice_14[15]  R1415     -60
    pool_choice_14[15]  R1426     -1
    pool_choice_14[15]  R1437     -1
    pool_choice_14[15]  R1451     -1
    pool_choice_14[15]  R1457     -1
    pool_choice_14[15]  pool_cover_C6_order_d  1
    pool_choice_14[15]  pool_cover_C6_order_p  1
    pool_choice_14[15]  R1708     -1
    pool_choice_14[15]  R1805     -60
    pool_choice_14[15]  R1809     -60
    pool_choice_14[16]  OBJ       6.4631964712286560e+01
    pool_choice_14[16]  R1414     1
    pool_choice_14[16]  R1415     -60
    pool_choice_14[16]  R1421     -1
    pool_choice_14[16]  R1434     -1
    pool_choice_14[16]  R1448     -1
    pool_choice_14[16]  R1455     -1
    pool_choice_14[16]  pool_cover_C47_order_p  1
    pool_choice_14[16]  pool_cover_C46_order_d  1
    pool_choice_14[16]  R1762     -1
    pool_choice_14[16]  R1805     -60
    pool_choice_14[16]  R1809     -60
    pool_choice_14[17]  OBJ       6.4631964712286560e+01
    pool_choice_14[17]  R1414     1
    pool_choice_14[17]  R1415     -60
    pool_choice_14[17]  R1422     -1
    pool_choice_14[17]  R1433     -1
    pool_choice_14[17]  R1447     -1
    pool_choice_14[17]  R1455     -1
    pool_choice_14[17]  pool_cover_C47_order_d  1
    pool_choice_14[17]  pool_cover_C46_order_p  1
    pool_choice_14[17]  R1751     -1
    pool_choice_14[17]  R1805     -60
    pool_choice_14[17]  R1809     -60
    pool_choice_14[18]  OBJ       1.3160896675303971e+02
    pool_choice_14[18]  R1414     1
    pool_choice_14[18]  R1415     -60
    pool_choice_14[18]  R1421     -1
    pool_choice_14[18]  R1438     -1
    pool_choice_14[18]  R1447     -1
    pool_choice_14[18]  R1452     -1
    pool_choice_14[18]  R1455     -1
    pool_choice_14[18]  pool_cover_C25_order_d  1
    pool_choice_14[18]  pool_cover_C25_order_p  1
    pool_choice_14[18]  pool_cover_C46_order_d  1
    pool_choice_14[18]  pool_cover_C46_order_p  1
    pool_choice_14[18]  R1746     -1
    pool_choice_14[18]  R1747     -1
    pool_choice_14[18]  R1748     -1
    pool_choice_14[18]  R1805     -60
    pool_choice_14[18]  R1809     -60
    pool_choice_14[19]  OBJ       1.1262869223977737e+02
    pool_choice_14[19]  R1414     1
    pool_choice_14[19]  R1415     -60
    pool_choice_14[19]  R1421     -1
    pool_choice_14[19]  R1433     -1
    pool_choice_14[19]  R1447     -1
    pool_choice_14[19]  R1455     -1
    pool_choice_14[19]  pool_cover_C25_order_d  1
    pool_choice_14[19]  pool_cover_C46_order_d  1
    pool_choice_14[19]  pool_cover_C46_order_p  1
    pool_choice_14[19]  R1746     -1
    pool_choice_14[19]  R1748     -1
    pool_choice_14[19]  R1805     -60
    pool_choice_14[19]  R1809     -60
    pool_choice_14[20]  OBJ       1.1760202563488251e+02
    pool_choice_14[20]  R1414     1
    pool_choice_14[20]  R1415     -60
    pool_choice_14[20]  R1421     -1
    pool_choice_14[20]  R1433     -1
    pool_choice_14[20]  R1447     -1
    pool_choice_14[20]  R1448     -1
    pool_choice_14[20]  R1455     -1
    pool_choice_14[20]  pool_cover_C47_order_p  1
    pool_choice_14[20]  pool_cover_C46_order_d  1
    pool_choice_14[20]  pool_cover_C46_order_p  1
    pool_choice_14[20]  R1733     -1
    pool_choice_14[20]  R1762     -1
    pool_choice_14[20]  R1805     -60
    pool_choice_14[20]  R1809     -60
    pool_choice_14[21]  OBJ       8.1012524190345616e+01
    pool_choice_14[21]  R1414     1
    pool_choice_14[21]  R1415     -60
    pool_choice_14[21]  R1425     -1
    pool_choice_14[21]  R1433     -1
    pool_choice_14[21]  R1447     -1
    pool_choice_14[21]  R1455     -1
    pool_choice_14[21]  pool_cover_C25_order_d  1
    pool_choice_14[21]  pool_cover_C46_order_p  1
    pool_choice_14[21]  R1746     -1
    pool_choice_14[21]  R1805     -60
    pool_choice_14[21]  R1809     -60
    pool_choice_14[22]  OBJ       8.1012524190345616e+01
    pool_choice_14[22]  R1414     1
    pool_choice_14[22]  R1415     -60
    pool_choice_14[22]  R1421     -1
    pool_choice_14[22]  R1439     -1
    pool_choice_14[22]  R1455     -1
    pool_choice_14[22]  pool_cover_C25_order_d  1
    pool_choice_14[22]  pool_cover_C46_order_d  1
    pool_choice_14[22]  R1748     -1
    pool_choice_14[22]  R1805     -60
    pool_choice_14[22]  R1809     -60
    pool_choice_14[23]  OBJ       8.1012524190345616e+01
    pool_choice_14[23]  R1414     1
    pool_choice_14[23]  R1415     -60
    pool_choice_14[23]  R1421     -1
    pool_choice_14[23]  R1438     -1
    pool_choice_14[23]  R1452     -1
    pool_choice_14[23]  R1455     -1
    pool_choice_14[23]  pool_cover_C25_order_p  1
    pool_choice_14[23]  pool_cover_C46_order_d  1
    pool_choice_14[23]  R1750     -1
    pool_choice_14[23]  R1805     -60
    pool_choice_14[23]  R1809     -60
    pool_choice_14[24]  OBJ       6.2032249677083293e+01
    pool_choice_14[24]  R1414     1
    pool_choice_14[24]  R1415     -60
    pool_choice_14[24]  R1421     -1
    pool_choice_14[24]  R1440     -1
    pool_choice_14[24]  R1455     -1
    pool_choice_14[24]  pool_cover_C46_order_d  1
    pool_choice_14[24]  R1805     -60
    pool_choice_14[24]  R1809     -60
    pool_choice_14[25]  OBJ       6.2032249677083293e+01
    pool_choice_14[25]  R1414     1
    pool_choice_14[25]  R1427     -1
    pool_choice_14[25]  R1433     -1
    pool_choice_14[25]  R1447     -1
    pool_choice_14[25]  pool_cover_C46_order_p  1
    pool_choice_14[26]  OBJ       2.0654115613359256e+01
    pool_choice_14[26]  R1414     1
    pool_choice_14[26]  R1428     -1
    pool_choice_14[26]  R1436     -1
    pool_choice_14[26]  R1449     -1
    pool_choice_14[26]  R1450     -1
    pool_choice_14[26]  pool_cover_C88_order_p  1
    pool_choice_14[26]  pool_cover_C29_order_p  1
    pool_choice_14[26]  R1709     -1
    pool_choice_14[27]  OBJ       1.7888543819998318e+01
    pool_choice_14[27]  R1414     1
    pool_choice_14[27]  R1415     -60
    pool_choice_14[27]  R1423     -1
    pool_choice_14[27]  R1441     -1
    pool_choice_14[27]  R1456     -1
    pool_choice_14[27]  pool_cover_C88_order_d  1
    pool_choice_14[27]  R1805     -60
    pool_choice_14[27]  R1809     -60
    pool_choice_14[28]  OBJ       2.0654115613359256e+01
    pool_choice_14[28]  R1414     1
    pool_choice_14[28]  R1415     -60
    pool_choice_14[28]  R1423     -1
    pool_choice_14[28]  R1436     -1
    pool_choice_14[28]  R1449     -1
    pool_choice_14[28]  R1450     -1
    pool_choice_14[28]  R1456     -1
    pool_choice_14[28]  pool_cover_C88_order_d  1
    pool_choice_14[28]  pool_cover_C88_order_p  1
    pool_choice_14[28]  pool_cover_C29_order_p  1
    pool_choice_14[28]  R1702     -1
    pool_choice_14[28]  R1709     -1
    pool_choice_14[28]  R1805     -60
    pool_choice_14[28]  R1809     -60
    pool_choice_14[29]  OBJ       1.1661903789690601e+01
    pool_choice_14[29]  R1414     1
    pool_choice_14[29]  R1415     -60
    pool_choice_14[29]  R1422     -1
    pool_choice_14[29]  R1442     -1
    pool_choice_14[29]  R1455     -1
    pool_choice_14[29]  pool_cover_C47_order_d  1
    pool_choice_14[29]  R1805     -60
    pool_choice_14[29]  R1809     -60
    pool_choice_14[30]  OBJ       20.591260281974
    pool_choice_14[30]  R1414     1
    pool_choice_14[30]  R1415     -60
    pool_choice_14[30]  R1424     -1
    pool_choice_14[30]  R1443     -1
    pool_choice_14[30]  R1457     -1
    pool_choice_14[30]  pool_cover_C29_order_d  1
    pool_choice_14[30]  R1805     -60
    pool_choice_14[30]  R1809     -60
    pool_choice_14[31]  OBJ       1.1661903789690601e+01
    pool_choice_14[31]  R1414     1
    pool_choice_14[31]  R1429     -1
    pool_choice_14[31]  R1434     -1
    pool_choice_14[31]  R1448     -1
    pool_choice_14[31]  pool_cover_C47_order_p  1
    pool_choice_14[32]  OBJ       41.2180607820758
    pool_choice_14[32]  R1414     1
    pool_choice_14[32]  R1415     -60
    pool_choice_14[32]  R1423     -1
    pool_choice_14[32]  R1444     -1
    pool_choice_14[32]  R1456     -1
    pool_choice_14[32]  pool_cover_C88_order_d  1
    pool_choice_14[32]  pool_cover_C76_order_d  1
    pool_choice_14[32]  R1710     -1
    pool_choice_14[32]  R1805     -60
    pool_choice_14[32]  R1809     -60
    pool_choice_14[33]  OBJ       3.1747081387645608e+01
    pool_choice_14[33]  R1414     1
    pool_choice_14[33]  R1415     -60
    pool_choice_14[33]  R1422     -1
    pool_choice_14[33]  R1436     -1
    pool_choice_14[33]  R1448     -1
    pool_choice_14[33]  R1450     -1
    pool_choice_14[33]  R1455     -1
    pool_choice_14[33]  pool_cover_C47_order_d  1
    pool_choice_14[33]  pool_cover_C47_order_p  1
    pool_choice_14[33]  pool_cover_C29_order_p  1
    pool_choice_14[33]  R1701     -1
    pool_choice_14[33]  R1712     -1
    pool_choice_14[33]  R1805     -60
    pool_choice_14[33]  R1809     -60
    pool_choice_14[34]  OBJ       7.5601410152021032e+01
    pool_choice_14[34]  R1414     1
    pool_choice_14[34]  R1415     -60
    pool_choice_14[34]  R1424     -1
    pool_choice_14[34]  R1445     -1
    pool_choice_14[34]  R1457     -1
    pool_choice_14[34]  pool_cover_C29_order_d  1
    pool_choice_14[34]  pool_cover_C6_order_d  1
    pool_choice_14[34]  R1713     -1
    pool_choice_14[34]  R1805     -60
    pool_choice_14[34]  R1809     -60
    pool_choice_14[35]  OBJ       8.7673299606967689e+01
    pool_choice_14[35]  R1414     1
    pool_choice_14[35]  R1415     -60
    pool_choice_14[35]  R1424     -1
    pool_choice_14[35]  R1436     -1
    pool_choice_14[35]  R1450     -1
    pool_choice_14[35]  R1451     -1
    pool_choice_14[35]  R1457     -1
    pool_choice_14[35]  pool_cover_C29_order_d  1
    pool_choice_14[35]  pool_cover_C29_order_p  1
    pool_choice_14[35]  pool_cover_C6_order_d  1
    pool_choice_14[35]  pool_cover_C6_order_p  1
    pool_choice_14[35]  R1708     -1
    pool_choice_14[35]  R1713     -1
    pool_choice_14[35]  R1714     -1
    pool_choice_14[35]  R1805     -60
    pool_choice_14[35]  R1809     -60
    pool_choice_14[36]  OBJ       2.7115567956485918e+01
    pool_choice_14[36]  R1414     1
    pool_choice_14[36]  R1430     -1
    pool_choice_14[36]  R1434     -1
    pool_choice_14[36]  R1448     -1
    pool_choice_14[36]  R1453     -1
    pool_choice_14[36]  pool_cover_C76_order_p  1
    pool_choice_14[36]  pool_cover_C47_order_p  1
    pool_choice_14[36]  R1715     -1
    pool_choice_14[37]  OBJ       6.4531470933056056e+01
    pool_choice_14[37]  R1414     1
    pool_choice_14[37]  R1415     -60
    pool_choice_14[37]  R1423     -1
    pool_choice_14[37]  R1444     -1
    pool_choice_14[37]  R1456     -1
    pool_choice_14[37]  pool_cover_C88_order_d  1
    pool_choice_14[37]  pool_cover_C76_order_d  1
    pool_choice_14[37]  pool_cover_C27_order_d  1
    pool_choice_14[37]  R1716     -1
    pool_choice_14[37]  R1717     -1
    pool_choice_14[37]  R1805     -60
    pool_choice_14[37]  R1809     -60
    pool_choice_14[38]  OBJ       2.7115567956485918e+01
    pool_choice_14[38]  R1414     1
    pool_choice_14[38]  R1415     -60
    pool_choice_14[38]  R1431     -1
    pool_choice_14[38]  R1434     -1
    pool_choice_14[38]  R1448     -1
    pool_choice_14[38]  R1453     -1
    pool_choice_14[38]  R1456     -1
    pool_choice_14[38]  pool_cover_C76_order_d  1
    pool_choice_14[38]  pool_cover_C76_order_p  1
    pool_choice_14[38]  pool_cover_C47_order_p  1
    pool_choice_14[38]  R1704     -1
    pool_choice_14[38]  R1715     -1
    pool_choice_14[38]  R1805     -60
    pool_choice_14[38]  R1809     -60
    pool_choice_14[39]  OBJ       6.4631964712286560e+01
    pool_choice_14[39]  R1414     1
    pool_choice_14[39]  R1415     -60
    pool_choice_14[39]  R1422     -1
    pool_choice_14[39]  R1440     -1
    pool_choice_14[39]  R1455     -1
    pool_choice_14[39]  pool_cover_C47_order_d  1
    pool_choice_14[39]  pool_cover_C46_order_d  1
    pool_choice_14[39]  R1718     -1
    pool_choice_14[39]  R1805     -60
    pool_choice_14[39]  R1809     -60
    pool_choice_14[40]  OBJ       4.9397828317917018e+01
    pool_choice_14[40]  R1414     1
    pool_choice_14[40]  R1415     -60
    pool_choice_14[40]  R1422     -1
    pool_choice_14[40]  R1434     -1
    pool_choice_14[40]  R1448     -1
    pool_choice_14[40]  R1452     -1
    pool_choice_14[40]  R1455     -1
    pool_choice_14[40]  pool_cover_C47_order_d  1
    pool_choice_14[40]  pool_cover_C47_order_p  1
    pool_choice_14[40]  pool_cover_C25_order_d  1
    pool_choice_14[40]  pool_cover_C25_order_p  1
    pool_choice_14[40]  R1706     -1
    pool_choice_14[40]  R1711     -1
    pool_choice_14[40]  R1719     -1
    pool_choice_14[40]  R1805     -60
    pool_choice_14[40]  R1809     -60
    pool_choice_14[41]  OBJ       6.3529520697074361e+01
    pool_choice_14[41]  R1414     1
    pool_choice_14[41]  R1415     -60
    pool_choice_14[41]  R1426     -1
    pool_choice_14[41]  R1445     -1
    pool_choice_14[41]  R1457     -1
    pool_choice_14[41]  pool_cover_C6_order_d  1
    pool_choice_14[41]  R1805     -60
    pool_choice_14[41]  R1809     -60
    pool_choice_14[42]  OBJ       7.5601410152021018e+01
    pool_choice_14[42]  R1414     1
    pool_choice_14[42]  R1415     -60
    pool_choice_14[42]  R1426     -1
    pool_choice_14[42]  R1436     -1
    pool_choice_14[42]  R1450     -1
    pool_choice_14[42]  R1451     -1
    pool_choice_14[42]  R1457     -1
    pool_choice_14[42]  pool_cover_C29_order_p  1
    pool_choice_14[42]  pool_cover_C6_order_d  1
    pool_choice_14[42]  pool_cover_C6_order_p  1
    pool_choice_14[42]  R1708     -1
    pool_choice_14[42]  R1714     -1
    pool_choice_14[42]  R1805     -60
    pool_choice_14[42]  R1809     -60
    pool_choice_14[43]  OBJ       5.5723778079391167e+01
    pool_choice_14[43]  R1414     1
    pool_choice_14[43]  R1430     -1
    pool_choice_14[43]  R1434     -1
    pool_choice_14[43]  R1448     -1
    pool_choice_14[43]  R1452     -1
    pool_choice_14[43]  R1453     -1
    pool_choice_14[43]  R1454     -1
    pool_choice_14[43]  pool_cover_C76_order_p  1
    pool_choice_14[43]  pool_cover_C27_order_p  1
    pool_choice_14[43]  pool_cover_C47_order_p  1
    pool_choice_14[43]  pool_cover_C25_order_p  1
    pool_choice_14[43]  R1719     -1
    pool_choice_14[43]  R1720     -1
    pool_choice_14[43]  R1721     -1
    pool_choice_14[44]  OBJ       4.8741939160438513e+01
    pool_choice_14[44]  R1414     1
    pool_choice_14[44]  R1415     -60
    pool_choice_14[44]  R1432     -1
    pool_choice_14[44]  R1444     -1
    pool_choice_14[44]  R1456     -1
    pool_choice_14[44]  pool_cover_C76_order_d  1
    pool_choice_14[44]  pool_cover_C27_order_d  1
    pool_choice_14[44]  R1717     -1
    pool_choice_14[44]  R1805     -60
    pool_choice_14[44]  R1809     -60
    pool_choice_14[45]  OBJ       2.8987894208396355e+01
    pool_choice_14[45]  R1414     1
    pool_choice_14[45]  R1415     -60
    pool_choice_14[45]  R1423     -1
    pool_choice_14[45]  R1434     -1
    pool_choice_14[45]  R1448     -1
    pool_choice_14[45]  R1449     -1
    pool_choice_14[45]  R1456     -1
    pool_choice_14[45]  pool_cover_C88_order_d  1
    pool_choice_14[45]  pool_cover_C88_order_p  1
    pool_choice_14[45]  pool_cover_C47_order_p  1
    pool_choice_14[45]  R1702     -1
    pool_choice_14[45]  R1722     -1
    pool_choice_14[45]  R1805     -60
    pool_choice_14[45]  R1809     -60
    pool_choice_14[46]  OBJ       8.1012524190345616e+01
    pool_choice_14[46]  R1414     1
    pool_choice_14[46]  R1415     -60
    pool_choice_14[46]  R1425     -1
    pool_choice_14[46]  R1440     -1
    pool_choice_14[46]  R1455     -1
    pool_choice_14[46]  pool_cover_C25_order_d  1
    pool_choice_14[46]  pool_cover_C46_order_d  1
    pool_choice_14[46]  R1723     -1
    pool_choice_14[46]  R1805     -60
    pool_choice_14[46]  R1809     -60
    pool_choice_14[47]  OBJ       6.9483005915872027e+01
    pool_choice_14[47]  R1414     1
    pool_choice_14[47]  R1415     -60
    pool_choice_14[47]  R1422     -1
    pool_choice_14[47]  R1436     -1
    pool_choice_14[47]  R1448     -1
    pool_choice_14[47]  R1450     -1
    pool_choice_14[47]  R1452     -1
    pool_choice_14[47]  R1455     -1
    pool_choice_14[47]  pool_cover_C47_order_d  1
    pool_choice_14[47]  pool_cover_C47_order_p  1
    pool_choice_14[47]  pool_cover_C25_order_d  1
    pool_choice_14[47]  pool_cover_C25_order_p  1
    pool_choice_14[47]  pool_cover_C29_order_p  1
    pool_choice_14[47]  R1706     -1
    pool_choice_14[47]  R1711     -1
    pool_choice_14[47]  R1712     -1
    pool_choice_14[47]  R1719     -1
    pool_choice_14[47]  R1805     -60
    pool_choice_14[47]  R1809     -60
    pool_choice_14[48]  OBJ       7.5601410152021032e+01
    pool_choice_14[48]  R1414     1
    pool_choice_14[48]  R1415     -60
    pool_choice_14[48]  R1424     -1
    pool_choice_14[48]  R1437     -1
    pool_choice_14[48]  R1450     -1
    pool_choice_14[48]  R1451     -1
    pool_choice_14[48]  R1457     -1
    pool_choice_14[48]  pool_cover_C29_order_d  1
    pool_choice_14[48]  pool_cover_C29_order_p  1
    pool_choice_14[48]  pool_cover_C6_order_p  1
    pool_choice_14[48]  R1703     -1
    pool_choice_14[48]  R1724     -1
    pool_choice_14[48]  R1805     -60
    pool_choice_14[48]  R1809     -60
    pool_choice_14[49]  OBJ       4.2256819117751121e+01
    pool_choice_14[49]  R1414     1
    pool_choice_14[49]  R1428     -1
    pool_choice_14[49]  R1434     -1
    pool_choice_14[49]  R1448     -1
    pool_choice_14[49]  R1449     -1
    pool_choice_14[49]  R1453     -1
    pool_choice_14[49]  pool_cover_C88_order_p  1
    pool_choice_14[49]  pool_cover_C76_order_p  1
    pool_choice_14[49]  pool_cover_C47_order_p  1
    pool_choice_14[49]  R1715     -1
    pool_choice_14[49]  R1725     -1
    pool_choice_14[50]  OBJ       4.8741939160438520e+01
    pool_choice_14[50]  R1414     1
    pool_choice_14[50]  R1415     -60
    pool_choice_14[50]  R1431     -1
    pool_choice_14[50]  R1446     -1
    pool_choice_14[50]  R1456     -1
    pool_choice_14[50]  pool_cover_C76_order_d  1
    pool_choice_14[50]  pool_cover_C27_order_d  1
    pool_choice_14[50]  R1726     -1
    pool_choice_14[50]  R1805     -60
    pool_choice_14[50]  R1809     -60
    pool_choice_14[51]  OBJ       5.0439375535867129e+01
    pool_choice_14[51]  R1414     1
    pool_choice_14[51]  R1415     -60
    pool_choice_14[51]  R1431     -1
    pool_choice_14[51]  R1434     -1
    pool_choice_14[51]  R1448     -1
    pool_choice_14[51]  R1453     -1
    pool_choice_14[51]  R1454     -1
    pool_choice_14[51]  R1456     -1
    pool_choice_14[51]  pool_cover_C76_order_d  1
    pool_choice_14[51]  pool_cover_C76_order_p  1
    pool_choice_14[51]  pool_cover_C27_order_d  1
    pool_choice_14[51]  pool_cover_C27_order_p  1
    pool_choice_14[51]  pool_cover_C47_order_p  1
    pool_choice_14[51]  R1705     -1
    pool_choice_14[51]  R1715     -1
    pool_choice_14[51]  R1726     -1
    pool_choice_14[51]  R1727     -1
    pool_choice_14[51]  R1805     -60
    pool_choice_14[51]  R1809     -60
    pool_choice_14[52]  OBJ       4.9396356140913873e+01
    pool_choice_14[52]  R1414     1
    pool_choice_14[52]  R1415     -60
    pool_choice_14[52]  R1425     -1
    pool_choice_14[52]  R1439     -1
    pool_choice_14[52]  R1455     -1
    pool_choice_14[52]  pool_cover_C25_order_d  1
    pool_choice_14[52]  R1805     -60
    pool_choice_14[52]  R1809     -60
    pool_choice_14[53]  OBJ       3.1747081387645608e+01
    pool_choice_14[53]  R1414     1
    pool_choice_14[53]  R1415     -60
    pool_choice_14[53]  R1422     -1
    pool_choice_14[53]  R1436     -1
    pool_choice_14[53]  R1450     -1
    pool_choice_14[53]  R1455     -1
    pool_choice_14[53]  pool_cover_C47_order_d  1
    pool_choice_14[53]  pool_cover_C29_order_p  1
    pool_choice_14[53]  R1728     -1
    pool_choice_14[53]  R1805     -60
    pool_choice_14[53]  R1809     -60
    pool_choice_14[54]  OBJ       7.5601410152021032e+01
    pool_choice_14[54]  R1414     1
    pool_choice_14[54]  R1415     -60
    pool_choice_14[54]  R1424     -1
    pool_choice_14[54]  R1437     -1
    pool_choice_14[54]  R1451     -1
    pool_choice_14[54]  R1457     -1
    pool_choice_14[54]  pool_cover_C29_order_d  1
    pool_choice_14[54]  pool_cover_C6_order_d  1
    pool_choice_14[54]  pool_cover_C6_order_p  1
    pool_choice_14[54]  R1708     -1
    pool_choice_14[54]  R1713     -1
    pool_choice_14[54]  R1805     -60
    pool_choice_14[54]  R1809     -60
    pool_choice_14[55]  OBJ       2.8987894208396355e+01
    pool_choice_14[55]  R1414     1
    pool_choice_14[55]  R1428     -1
    pool_choice_14[55]  R1434     -1
    pool_choice_14[55]  R1448     -1
    pool_choice_14[55]  R1449     -1
    pool_choice_14[55]  pool_cover_C88_order_p  1
    pool_choice_14[55]  pool_cover_C47_order_p  1
    pool_choice_14[55]  R1722     -1
    pool_choice_14[56]  OBJ       2.6076809620810597e+01
    pool_choice_14[56]  R1414     1
    pool_choice_14[56]  R1415     -60
    pool_choice_14[56]  R1431     -1
    pool_choice_14[56]  R1444     -1
    pool_choice_14[56]  R1456     -1
    pool_choice_14[56]  pool_cover_C76_order_d  1
    pool_choice_14[56]  R1805     -60
    pool_choice_14[56]  R1809     -60
    pool_choice_14[57]  OBJ       2.0654115613359256e+01
    pool_choice_14[57]  R1414     1
    pool_choice_14[57]  R1415     -60
    pool_choice_14[57]  R1423     -1
    pool_choice_14[57]  R1436     -1
    pool_choice_14[57]  R1450     -1
    pool_choice_14[57]  R1456     -1
    pool_choice_14[57]  pool_cover_C88_order_d  1
    pool_choice_14[57]  pool_cover_C29_order_p  1
    pool_choice_14[57]  R1729     -1
    pool_choice_14[57]  R1805     -60
    pool_choice_14[57]  R1809     -60
    pool_used_14  R1414     -1
    pool_used_14  R1415     -28800
    pool_used_14  R1416     -75600
    pool_used_14  R1417     -75540
    pool_used_14  R1418     -1
    pool_used_14  R1419     -80
    pool_used_14  R1420     -80
    pool_used_14  R1805     -75660
    pool_used_14  R1806     -81
    pool_used_14  R1809     -75660
    pool_used_14  R1810     -81
    pool_used_14  R1813     -75660
    pool_used_14  R1814     -81
    pool_start_14  R1415     1
    pool_start_14  R1416     1
    pool_start_14  R1805     1
    pool_start_14  R1809     1
    pool_start_14  GC1090    -1
    pool_start_14  GC1092    -1
    pool_start_14  GC1094    -1
    pool_start_14  GC1096    -1
    pool_start_14  GC1098    -1
    pool_start_14  GC1100    -1
    pool_start_14  GC1102    -1
    pool_start_14  GC1104    -1
    pool_start_14  GC1106    -1
    pool_start_14  GC1108    -1
    pool_start_14  GC1110    -1
    pool_start_14  GC1112    -1
    pool_start_14  GC1150    1
    pool_start_14  GC1151    1
    pool_start_14  GC1152    1
    pool_end_14  R1417     1
    pool_end_14  R1813     -1
    pool_end_14  GC1114    1
    pool_end_14  GC1116    1
    pool_end_14  GC1118    1
    pool_end_14  GC1120    1
    pool_end_14  GC1122    1
    pool_end_14  GC1124    1
    pool_end_14  GC1126    1
    pool_end_14  GC1128    1
    pool_end_14  GC1130    1
    pool_end_14  GC1132    1
    pool_end_14  GC1134    1
    pool_end_14  GC1136    1
    pool_end_14  GC1138    1
    pool_end_14  GC1140    1
    pool_end_14  GC1142    -1
    pool_end_14  GC1143    -1
    pool_end_14  GC1144    -1
    pool_end_14  GC1145    -1
    pool_end_14  GC1146    -1
    pool_end_14  GC1147    -1
    pool_end_14  GC1148    -1
    pool_end_14  GC1149    -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_14  R1418     1
    pool_start_rank_14  R1419     1
    pool_start_rank_14  R1806     1
    pool_start_rank_14  R1810     1
    pool_start_rank_14  GC1091    -1
    pool_start_rank_14  GC1093    -1
    pool_start_rank_14  GC1095    -1
    pool_start_rank_14  GC1097    -1
    pool_start_rank_14  GC1099    -1
    pool_start_rank_14  GC1101    -1
    pool_start_rank_14  GC1103    -1
    pool_start_rank_14  GC1105    -1
    pool_start_rank_14  GC1107    -1
    pool_start_rank_14  GC1109    -1
    pool_start_rank_14  GC1111    -1
    pool_start_rank_14  GC1113    -1
    pool_end_rank_14  R1420     1
    pool_end_rank_14  R1814     -1
    pool_end_rank_14  GC1115    1
    pool_end_rank_14  GC1117    1
    pool_end_rank_14  GC1119    1
    pool_end_rank_14  GC1121    1
    pool_end_rank_14  GC1123    1
    pool_end_rank_14  GC1125    1
    pool_end_rank_14  GC1127    1
    pool_end_rank_14  GC1129    1
    pool_end_rank_14  GC1131    1
    pool_end_rank_14  GC1133    1
    pool_end_rank_14  GC1135    1
    pool_end_rank_14  GC1137    1
    pool_end_rank_14  GC1139    1
    pool_end_rank_14  GC1141    1
    MARKER    'MARKER'                 'INTORG'
    pool_first_14_C46_order_d  R1421     1
    pool_first_14_C47_order_d  R1422     1
    pool_first_14_C88_order_d  R1423     1
    pool_first_14_C29_order_d  R1424     1
    pool_first_14_C25_order_d  R1425     1
    pool_first_14_C6_order_d  R1426     1
    pool_first_14_C46_order_p  R1427     1
    pool_first_14_C88_order_p  R1428     1
    pool_first_14_C47_order_p  R1429     1
    pool_first_14_C76_order_p  R1430     1
    pool_first_14_C76_order_d  R1431     1
    pool_first_14_C27_order_d  R1432     1
    pool_last_14_C46_order_p  R1433     1
    pool_last_14_C47_order_p  R1434     1
    pool_last_14_C88_order_p  R1435     1
    pool_last_14_C29_order_p  R1436     1
    pool_last_14_C6_order_p  R1437     1
    pool_last_14_C25_order_p  R1438     1
    pool_last_14_C25_order_d  R1439     1
    pool_last_14_C46_order_d  R1440     1
    pool_last_14_C88_order_d  R1441     1
    pool_last_14_C47_order_d  R1442     1
    pool_last_14_C29_order_d  R1443     1
    pool_last_14_C76_order_d  R1444     1
    pool_last_14_C6_order_d  R1445     1
    pool_last_14_C27_order_d  R1446     1
    pool_pickup_14_C46_order  R1447     1
    pool_pickup_14_C47_order  R1448     1
    pool_pickup_14_C88_order  R1449     1
    pool_pickup_14_C29_order  R1450     1
    pool_pickup_14_C6_order  R1451     1
    pool_pickup_14_C25_order  R1452     1
    pool_pickup_14_C76_order  R1453     1
    pool_pickup_14_C27_order  R1454     1
    pool_batch_14_b2  R1455     1
    pool_batch_14_b1  R1456     1
    pool_batch_14_b3  R1457     1
    pool_choice_15[0]  OBJ       6.3529520697074361e+01
    pool_choice_15[0]  R1458     1
    pool_choice_15[0]  R1459     -60
    pool_choice_15[0]  R1465     -1
    pool_choice_15[0]  R1478     -1
    pool_choice_15[0]  R1491     -1
    pool_choice_15[0]  R1499     -1
    pool_choice_15[0]  pool_cover_C6_order_d  1
    pool_choice_15[0]  pool_cover_C6_order_p  1
    pool_choice_15[0]  R1708     -1
    pool_choice_15[0]  R1807     -60
    pool_choice_15[0]  R1811     -60
    pool_choice_15[0]  R1813     -60
    pool_choice_15[1]  OBJ       1.7888543819998318e+01
    pool_choice_15[1]  R1458     1
    pool_choice_15[1]  R1459     -60
    pool_choice_15[1]  R1466     -1
    pool_choice_15[1]  R1479     -1
    pool_choice_15[1]  R1492     -1
    pool_choice_15[1]  R1500     -1
    pool_choice_15[1]  pool_cover_C88_order_d  1
    pool_choice_15[1]  pool_cover_C88_order_p  1
    pool_choice_15[1]  R1702     -1
    pool_choice_15[1]  R1807     -60
    pool_choice_15[1]  R1811     -60
    pool_choice_15[1]  R1813     -60
    pool_choice_15[2]  OBJ       20.591260281974
    pool_choice_15[2]  R1458     1
    pool_choice_15[2]  R1459     -60
    pool_choice_15[2]  R1467     -1
    pool_choice_15[2]  R1480     -1
    pool_choice_15[2]  R1493     -1
    pool_choice_15[2]  R1499     -1
    pool_choice_15[2]  pool_cover_C29_order_d  1
    pool_choice_15[2]  pool_cover_C29_order_p  1
    pool_choice_15[2]  R1703     -1
    pool_choice_15[2]  R1807     -60
    pool_choice_15[2]  R1811     -60
    pool_choice_15[2]  R1813     -60
    pool_choice_15[3]  OBJ       8.7673299606967689e+01
    pool_choice_15[3]  R1458     1
    pool_choice_15[3]  R1459     -60
    pool_choice_15[3]  R1467     -1
    pool_choice_15[3]  R1480     -1
    pool_choice_15[3]  R1491     -1
    pool_choice_15[3]  R1493     -1
    pool_choice_15[3]  R1499     -1
    pool_choice_15[3]  pool_cover_C29_order_d  1
    pool_choice_15[3]  pool_cover_C29_order_p  1
    pool_choice_15[3]  pool_cover_C6_order_d  1
    pool_choice_15[3]  pool_cover_C6_order_p  1
    pool_choice_15[3]  R1708     -1
    pool_choice_15[3]  R1713     -1
    pool_choice_15[3]  R1714     -1
    pool_choice_15[3]  R1807     -60
    pool_choice_15[3]  R1811     -60
    pool_choice_15[3]  R1813     -60
    pool_choice_15[4]  OBJ       7.5601410152021018e+01
    pool_choice_15[4]  R1458     1
    pool_choice_15[4]  R1459     -60
    pool_choice_15[4]  R1465     -1
    pool_choice_15[4]  R1480     -1
    pool_choice_15[4]  R1491     -1
    pool_choice_15[4]  R1493     -1
    pool_choice_15[4]  R1499     -1
    pool_choice_15[4]  pool_cover_C29_order_p  1
    pool_choice_15[4]  pool_cover_C6_order_d  1
    pool_choice_15[4]  pool_cover_C6_order_p  1
    pool_choice_15[4]  R1708     -1
    pool_choice_15[4]  R1714     -1
    pool_choice_15[4]  R1807     -60
    pool_choice_15[4]  R1811     -60
    pool_choice_15[4]  R1813     -60
    pool_choice_15[5]  OBJ       7.5601410152021032e+01
    pool_choice_15[5]  R1458     1
    pool_choice_15[5]  R1459     -60
    pool_choice_15[5]  R1467     -1
    pool_choice_15[5]  R1478     -1
    pool_choice_15[5]  R1491     -1
    pool_choice_15[5]  R1499     -1
    pool_choice_15[5]  pool_cover_C29_order_d  1
    pool_choice_15[5]  pool_cover_C6_order_d  1
    pool_choice_15[5]  pool_cover_C6_order_p  1
    pool_choice_15[5]  R1708     -1
    pool_choice_15[5]  R1713     -1
    pool_choice_15[5]  R1807     -60
    pool_choice_15[5]  R1811     -60
    pool_choice_15[5]  R1813     -60
    pool_choice_15[6]  OBJ       6.2032249677083293e+01
    pool_choice_15[6]  R1458     1
    pool_choice_15[6]  R1459     -60
    pool_choice_15[6]  R1468     -1
    pool_choice_15[6]  R1481     -1
    pool_choice_15[6]  R1494     -1
    pool_choice_15[6]  R1501     -1
    pool_choice_15[6]  pool_cover_C46_order_d  1
    pool_choice_15[6]  pool_cover_C46_order_p  1
    pool_choice_15[6]  R1707     -1
    pool_choice_15[6]  R1807     -60
    pool_choice_15[6]  R1811     -60
    pool_choice_15[6]  R1813     -60
    pool_choice_15[7]  OBJ       1.4268344947701470e+02
    pool_choice_15[7]  R1458     1
    pool_choice_15[7]  R1459     -60
    pool_choice_15[7]  R1467     -1
    pool_choice_15[7]  R1478     -1
    pool_choice_15[7]  R1491     -1
    pool_choice_15[7]  R1493     -1
    pool_choice_15[7]  R1499     -1
    pool_choice_15[7]  pool_cover_C29_order_d  1
    pool_choice_15[7]  pool_cover_C29_order_p  1
    pool_choice_15[7]  pool_cover_C6_order_d  1
    pool_choice_15[7]  pool_cover_C6_order_p  1
    pool_choice_15[7]  R1713     -1
    pool_choice_15[7]  R1724     -1
    pool_choice_15[7]  R1731     -1
    pool_choice_15[7]  R1807     -60
    pool_choice_15[7]  R1811     -60
    pool_choice_15[7]  R1813     -60
    pool_choice_15[8]  OBJ       7.5601410152021018e+01
    pool_choice_15[8]  R1458     1
    pool_choice_15[8]  R1459     -60
    pool_choice_15[8]  R1465     -1
    pool_choice_15[8]  R1480     -1
    pool_choice_15[8]  R1493     -1
    pool_choice_15[8]  R1499     -1
    pool_choice_15[8]  pool_cover_C29_order_p  1
    pool_choice_15[8]  pool_cover_C6_order_d  1
    pool_choice_15[8]  R1731     -1
    pool_choice_15[8]  R1807     -60
    pool_choice_15[8]  R1811     -60
    pool_choice_15[8]  R1813     -60
    pool_choice_15[9]  OBJ       7.5601410152021032e+01
    pool_choice_15[9]  R1458     1
    pool_choice_15[9]  R1459     -60
    pool_choice_15[9]  R1467     -1
    pool_choice_15[9]  R1478     -1
    pool_choice_15[9]  R1491     -1
    pool_choice_15[9]  R1499     -1
    pool_choice_15[9]  pool_cover_C29_order_d  1
    pool_choice_15[9]  pool_cover_C6_order_p  1
    pool_choice_15[9]  R1754     -1
    pool_choice_15[9]  R1807     -60
    pool_choice_15[9]  R1811     -60
    pool_choice_15[9]  R1813     -60
    pool_choice_15[10]  OBJ       7.5601410152021032e+01
    pool_choice_15[10]  R1458     1
    pool_choice_15[10]  R1469     -1
    pool_choice_15[10]  R1478     -1
    pool_choice_15[10]  R1491     -1
    pool_choice_15[10]  R1493     -1
    pool_choice_15[10]  pool_cover_C29_order_p  1
    pool_choice_15[10]  pool_cover_C6_order_p  1
    pool_choice_15[10]  R1724     -1
    pool_choice_15[11]  OBJ       1.3061156002206803e+02
    pool_choice_15[11]  R1458     1
    pool_choice_15[11]  R1459     -60
    pool_choice_15[11]  R1465     -1
    pool_choice_15[11]  R1478     -1
    pool_choice_15[11]  R1491     -1
    pool_choice_15[11]  R1493     -1
    pool_choice_15[11]  R1499     -1
    pool_choice_15[11]  pool_cover_C29_order_p  1
    pool_choice_15[11]  pool_cover_C6_order_d  1
    pool_choice_15[11]  pool_cover_C6_order_p  1
    pool_choice_15[11]  R1724     -1
    pool_choice_15[11]  R1731     -1
    pool_choice_15[11]  R1807     -60
    pool_choice_15[11]  R1811     -60
    pool_choice_15[11]  R1813     -60
    pool_choice_15[12]  OBJ       6.3529520697074361e+01
    pool_choice_15[12]  R1458     1
    pool_choice_15[12]  R1459     -60
    pool_choice_15[12]  R1465     -1
    pool_choice_15[12]  R1482     -1
    pool_choice_15[12]  R1499     -1
    pool_choice_15[12]  pool_cover_C6_order_d  1
    pool_choice_15[12]  R1807     -60
    pool_choice_15[12]  R1811     -60
    pool_choice_15[12]  R1813     -60
    pool_choice_15[13]  OBJ       6.3529520697074361e+01
    pool_choice_15[13]  R1458     1
    pool_choice_15[13]  R1470     -1
    pool_choice_15[13]  R1478     -1
    pool_choice_15[13]  R1491     -1
    pool_choice_15[13]  pool_cover_C6_order_p  1
    pool_choice_15[14]  OBJ       2.0654115613359256e+01
    pool_choice_15[14]  R1458     1
    pool_choice_15[14]  R1471     -1
    pool_choice_15[14]  R1480     -1
    pool_choice_15[14]  R1492     -1
    pool_choice_15[14]  R1493     -1
    pool_choice_15[14]  pool_cover_C88_order_p  1
    pool_choice_15[14]  pool_cover_C29_order_p  1
    pool_choice_15[14]  R1709     -1
    pool_choice_15[15]  OBJ       1.7888543819998318e+01
    pool_choice_15[15]  R1458     1
    pool_choice_15[15]  R1459     -60
    pool_choice_15[15]  R1466     -1
    pool_choice_15[15]  R1483     -1
    pool_choice_15[15]  R1500     -1
    pool_choice_15[15]  pool_cover_C88_order_d  1
    pool_choice_15[15]  R1807     -60
    pool_choice_15[15]  R1811     -60
    pool_choice_15[15]  R1813     -60
    pool_choice_15[16]  OBJ       2.0654115613359256e+01
    pool_choice_15[16]  R1458     1
    pool_choice_15[16]  R1459     -60
    pool_choice_15[16]  R1466     -1
    pool_choice_15[16]  R1480     -1
    pool_choice_15[16]  R1492     -1
    pool_choice_15[16]  R1493     -1
    pool_choice_15[16]  R1500     -1
    pool_choice_15[16]  pool_cover_C88_order_d  1
    pool_choice_15[16]  pool_cover_C88_order_p  1
    pool_choice_15[16]  pool_cover_C29_order_p  1
    pool_choice_15[16]  R1702     -1
    pool_choice_15[16]  R1709     -1
    pool_choice_15[16]  R1807     -60
    pool_choice_15[16]  R1811     -60
    pool_choice_15[16]  R1813     -60
    pool_choice_15[17]  OBJ       1.1661903789690601e+01
    pool_choice_15[17]  R1458     1
    pool_choice_15[17]  R1459     -60
    pool_choice_15[17]  R1472     -1
    pool_choice_15[17]  R1484     -1
    pool_choice_15[17]  R1501     -1
    pool_choice_15[17]  pool_cover_C47_order_d  1
    pool_choice_15[17]  R1807     -60
    pool_choice_15[17]  R1811     -60
    pool_choice_15[17]  R1813     -60
    pool_choice_15[18]  OBJ       1.1661903789690601e+01
    pool_choice_15[18]  R1458     1
    pool_choice_15[18]  R1459     -60
    pool_choice_15[18]  R1472     -1
    pool_choice_15[18]  R1485     -1
    pool_choice_15[18]  R1495     -1
    pool_choice_15[18]  R1501     -1
    pool_choice_15[18]  pool_cover_C47_order_d  1
    pool_choice_15[18]  pool_cover_C47_order_p  1
    pool_choice_15[18]  R1701     -1
    pool_choice_15[18]  R1807     -60
    pool_choice_15[18]  R1811     -60
    pool_choice_15[18]  R1813     -60
    pool_choice_15[19]  OBJ       20.591260281974
    pool_choice_15[19]  R1458     1
    pool_choice_15[19]  R1459     -60
    pool_choice_15[19]  R1467     -1
    pool_choice_15[19]  R1486     -1
    pool_choice_15[19]  R1499     -1
    pool_choice_15[19]  pool_cover_C29_order_d  1
    pool_choice_15[19]  R1807     -60
    pool_choice_15[19]  R1811     -60
    pool_choice_15[19]  R1813     -60
    pool_choice_15[20]  OBJ       1.1661903789690601e+01
    pool_choice_15[20]  R1458     1
    pool_choice_15[20]  R1473     -1
    pool_choice_15[20]  R1485     -1
    pool_choice_15[20]  R1495     -1
    pool_choice_15[20]  pool_cover_C47_order_p  1
    pool_choice_15[21]  OBJ       41.2180607820758
    pool_choice_15[21]  R1458     1
    pool_choice_15[21]  R1459     -60
    pool_choice_15[21]  R1466     -1
    pool_choice_15[21]  R1487     -1
    pool_choice_15[21]  R1500     -1
    pool_choice_15[21]  pool_cover_C88_order_d  1
    pool_choice_15[21]  pool_cover_C76_order_d  1
    pool_choice_15[21]  R1710     -1
    pool_choice_15[21]  R1807     -60
    pool_choice_15[21]  R1811     -60
    pool_choice_15[21]  R1813     -60
    pool_choice_15[22]  OBJ       4.9397092229415449e+01
    pool_choice_15[22]  R1458     1
    pool_choice_15[22]  R1459     -60
    pool_choice_15[22]  R1472     -1
    pool_choice_15[22]  R1488     -1
    pool_choice_15[22]  R1501     -1
    pool_choice_15[22]  pool_cover_C47_order_d  1
    pool_choice_15[22]  pool_cover_C25_order_d  1
    pool_choice_15[22]  R1711     -1
    pool_choice_15[22]  R1807     -60
    pool_choice_15[22]  R1811     -60
    pool_choice_15[22]  R1813     -60
    pool_choice_15[23]  OBJ       3.1747081387645608e+01
    pool_choice_15[23]  R1458     1
    pool_choice_15[23]  R1459     -60
    pool_choice_15[23]  R1472     -1
    pool_choice_15[23]  R1480     -1
    pool_choice_15[23]  R1493     -1
    pool_choice_15[23]  R1495     -1
    pool_choice_15[23]  R1501     -1
    pool_choice_15[23]  pool_cover_C47_order_d  1
    pool_choice_15[23]  pool_cover_C47_order_p  1
    pool_choice_15[23]  pool_cover_C29_order_p  1
    pool_choice_15[23]  R1701     -1
    pool_choice_15[23]  R1712     -1
    pool_choice_15[23]  R1807     -60
    pool_choice_15[23]  R1811     -60
    pool_choice_15[23]  R1813     -60
    pool_choice_15[24]  OBJ       7.5601410152021032e+01
    pool_choice_15[24]  R1458     1
    pool_choice_15[24]  R1459     -60
    pool_choice_15[24]  R1467     -1
    pool_choice_15[24]  R1482     -1
    pool_choice_15[24]  R1499     -1
    pool_choice_15[24]  pool_cover_C29_order_d  1
    pool_choice_15[24]  pool_cover_C6_order_d  1
    pool_choice_15[24]  R1713     -1
    pool_choice_15[24]  R1807     -60
    pool_choice_15[24]  R1811     -60
    pool_choice_15[24]  R1813     -60
    pool_choice_15[25]  OBJ       2.7115567956485918e+01
    pool_choice_15[25]  R1458     1
    pool_choice_15[25]  R1474     -1
    pool_choice_15[25]  R1485     -1
    pool_choice_15[25]  R1495     -1
    pool_choice_15[25]  R1496     -1
    pool_choice_15[25]  pool_cover_C76_order_p  1
    pool_choice_15[25]  pool_cover_C47_order_p  1
    pool_choice_15[25]  R1715     -1
    pool_choice_15[26]  OBJ       6.4531470933056056e+01
    pool_choice_15[26]  R1458     1
    pool_choice_15[26]  R1459     -60
    pool_choice_15[26]  R1466     -1
    pool_choice_15[26]  R1487     -1
    pool_choice_15[26]  R1500     -1
    pool_choice_15[26]  pool_cover_C88_order_d  1
    pool_choice_15[26]  pool_cover_C76_order_d  1
    pool_choice_15[26]  pool_cover_C27_order_d  1
    pool_choice_15[26]  R1716     -1
    pool_choice_15[26]  R1717     -1
    pool_choice_15[26]  R1807     -60
    pool_choice_15[26]  R1811     -60
    pool_choice_15[26]  R1813     -60
    pool_choice_15[27]  OBJ       2.7115567956485918e+01
    pool_choice_15[27]  R1458     1
    pool_choice_15[27]  R1459     -60
    pool_choice_15[27]  R1475     -1
    pool_choice_15[27]  R1485     -1
    pool_choice_15[27]  R1495     -1
    pool_choice_15[27]  R1496     -1
    pool_choice_15[27]  R1500     -1
    pool_choice_15[27]  pool_cover_C76_order_d  1
    pool_choice_15[27]  pool_cover_C76_order_p  1
    pool_choice_15[27]  pool_cover_C47_order_p  1
    pool_choice_15[27]  R1704     -1
    pool_choice_15[27]  R1715     -1
    pool_choice_15[27]  R1807     -60
    pool_choice_15[27]  R1811     -60
    pool_choice_15[27]  R1813     -60
    pool_choice_15[28]  OBJ       6.4631964712286560e+01
    pool_choice_15[28]  R1458     1
    pool_choice_15[28]  R1459     -60
    pool_choice_15[28]  R1472     -1
    pool_choice_15[28]  R1489     -1
    pool_choice_15[28]  R1501     -1
    pool_choice_15[28]  pool_cover_C47_order_d  1
    pool_choice_15[28]  pool_cover_C46_order_d  1
    pool_choice_15[28]  R1718     -1
    pool_choice_15[28]  R1807     -60
    pool_choice_15[28]  R1811     -60
    pool_choice_15[28]  R1813     -60
    pool_choice_15[29]  OBJ       4.9397828317917018e+01
    pool_choice_15[29]  R1458     1
    pool_choice_15[29]  R1459     -60
    pool_choice_15[29]  R1472     -1
    pool_choice_15[29]  R1485     -1
    pool_choice_15[29]  R1495     -1
    pool_choice_15[29]  R1497     -1
    pool_choice_15[29]  R1501     -1
    pool_choice_15[29]  pool_cover_C47_order_d  1
    pool_choice_15[29]  pool_cover_C47_order_p  1
    pool_choice_15[29]  pool_cover_C25_order_d  1
    pool_choice_15[29]  pool_cover_C25_order_p  1
    pool_choice_15[29]  R1706     -1
    pool_choice_15[29]  R1711     -1
    pool_choice_15[29]  R1719     -1
    pool_choice_15[29]  R1807     -60
    pool_choice_15[29]  R1811     -60
    pool_choice_15[29]  R1813     -60
    pool_choice_15[30]  OBJ       5.5723778079391167e+01
    pool_choice_15[30]  R1458     1
    pool_choice_15[30]  R1474     -1
    pool_choice_15[30]  R1485     -1
    pool_choice_15[30]  R1495     -1
    pool_choice_15[30]  R1496     -1
    pool_choice_15[30]  R1497     -1
    pool_choice_15[30]  R1498     -1
    pool_choice_15[30]  pool_cover_C76_order_p  1
    pool_choice_15[30]  pool_cover_C27_order_p  1
    pool_choice_15[30]  pool_cover_C47_order_p  1
    pool_choice_15[30]  pool_cover_C25_order_p  1
    pool_choice_15[30]  R1719     -1
    pool_choice_15[30]  R1720     -1
    pool_choice_15[30]  R1721     -1
    pool_choice_15[31]  OBJ       4.8741939160438513e+01
    pool_choice_15[31]  R1458     1
    pool_choice_15[31]  R1459     -60
    pool_choice_15[31]  R1476     -1
    pool_choice_15[31]  R1487     -1
    pool_choice_15[31]  R1500     -1
    pool_choice_15[31]  pool_cover_C76_order_d  1
    pool_choice_15[31]  pool_cover_C27_order_d  1
    pool_choice_15[31]  R1717     -1
    pool_choice_15[31]  R1807     -60
    pool_choice_15[31]  R1811     -60
    pool_choice_15[31]  R1813     -60
    pool_choice_15[32]  OBJ       2.8987894208396355e+01
    pool_choice_15[32]  R1458     1
    pool_choice_15[32]  R1459     -60
    pool_choice_15[32]  R1466     -1
    pool_choice_15[32]  R1485     -1
    pool_choice_15[32]  R1492     -1
    pool_choice_15[32]  R1495     -1
    pool_choice_15[32]  R1500     -1
    pool_choice_15[32]  pool_cover_C88_order_d  1
    pool_choice_15[32]  pool_cover_C88_order_p  1
    pool_choice_15[32]  pool_cover_C47_order_p  1
    pool_choice_15[32]  R1702     -1
    pool_choice_15[32]  R1722     -1
    pool_choice_15[32]  R1807     -60
    pool_choice_15[32]  R1811     -60
    pool_choice_15[32]  R1813     -60
    pool_choice_15[33]  OBJ       8.1012524190345616e+01
    pool_choice_15[33]  R1458     1
    pool_choice_15[33]  R1459     -60
    pool_choice_15[33]  R1477     -1
    pool_choice_15[33]  R1489     -1
    pool_choice_15[33]  R1501     -1
    pool_choice_15[33]  pool_cover_C25_order_d  1
    pool_choice_15[33]  pool_cover_C46_order_d  1
    pool_choice_15[33]  R1723     -1
    pool_choice_15[33]  R1807     -60
    pool_choice_15[33]  R1811     -60
    pool_choice_15[33]  R1813     -60
    pool_choice_15[34]  OBJ       6.9483005915872027e+01
    pool_choice_15[34]  R1458     1
    pool_choice_15[34]  R1459     -60
    pool_choice_15[34]  R1472     -1
    pool_choice_15[34]  R1480     -1
    pool_choice_15[34]  R1493     -1
    pool_choice_15[34]  R1495     -1
    pool_choice_15[34]  R1497     -1
    pool_choice_15[34]  R1501     -1
    pool_choice_15[34]  pool_cover_C47_order_d  1
    pool_choice_15[34]  pool_cover_C47_order_p  1
    pool_choice_15[34]  pool_cover_C25_order_d  1
    pool_choice_15[34]  pool_cover_C25_order_p  1
    pool_choice_15[34]  pool_cover_C29_order_p  1
    pool_choice_15[34]  R1706     -1
    pool_choice_15[34]  R1711     -1
    pool_choice_15[34]  R1712     -1
    pool_choice_15[34]  R1719     -1
    pool_choice_15[34]  R1807     -60
    pool_choice_15[34]  R1811     -60
    pool_choice_15[34]  R1813     -60
    pool_choice_15[35]  OBJ       7.5601410152021032e+01
    pool_choice_15[35]  R1458     1
    pool_choice_15[35]  R1459     -60
    pool_choice_15[35]  R1467     -1
    pool_choice_15[35]  R1478     -1
    pool_choice_15[35]  R1491     -1
    pool_choice_15[35]  R1493     -1
    pool_choice_15[35]  R1499     -1
    pool_choice_15[35]  pool_cover_C29_order_d  1
    pool_choice_15[35]  pool_cover_C29_order_p  1
    pool_choice_15[35]  pool_cover_C6_order_p  1
    pool_choice_15[35]  R1703     -1
    pool_choice_15[35]  R1724     -1
    pool_choice_15[35]  R1807     -60
    pool_choice_15[35]  R1811     -60
    pool_choice_15[35]  R1813     -60
    pool_choice_15[36]  OBJ       4.2256819117751121e+01
    pool_choice_15[36]  R1458     1
    pool_choice_15[36]  R1471     -1
    pool_choice_15[36]  R1485     -1
    pool_choice_15[36]  R1492     -1
    pool_choice_15[36]  R1495     -1
    pool_choice_15[36]  R1496     -1
    pool_choice_15[36]  pool_cover_C88_order_p  1
    pool_choice_15[36]  pool_cover_C76_order_p  1
    pool_choice_15[36]  pool_cover_C47_order_p  1
    pool_choice_15[36]  R1715     -1
    pool_choice_15[36]  R1725     -1
    pool_choice_15[37]  OBJ       4.8741939160438520e+01
    pool_choice_15[37]  R1458     1
    pool_choice_15[37]  R1459     -60
    pool_choice_15[37]  R1475     -1
    pool_choice_15[37]  R1490     -1
    pool_choice_15[37]  R1500     -1
    pool_choice_15[37]  pool_cover_C76_order_d  1
    pool_choice_15[37]  pool_cover_C27_order_d  1
    pool_choice_15[37]  R1726     -1
    pool_choice_15[37]  R1807     -60
    pool_choice_15[37]  R1811     -60
    pool_choice_15[37]  R1813     -60
    pool_choice_15[38]  OBJ       5.0439375535867129e+01
    pool_choice_15[38]  R1458     1
    pool_choice_15[38]  R1459     -60
    pool_choice_15[38]  R1475     -1
    pool_choice_15[38]  R1485     -1
    pool_choice_15[38]  R1495     -1
    pool_choice_15[38]  R1496     -1
    pool_choice_15[38]  R1498     -1
    pool_choice_15[38]  R1500     -1
    pool_choice_15[38]  pool_cover_C76_order_d  1
    pool_choice_15[38]  pool_cover_C76_order_p  1
    pool_choice_15[38]  pool_cover_C27_order_d  1
    pool_choice_15[38]  pool_cover_C27_order_p  1
    pool_choice_15[38]  pool_cover_C47_order_p  1
    pool_choice_15[38]  R1705     -1
    pool_choice_15[38]  R1715     -1
    pool_choice_15[38]  R1726     -1
    pool_choice_15[38]  R1727     -1
    pool_choice_15[38]  R1807     -60
    pool_choice_15[38]  R1811     -60
    pool_choice_15[38]  R1813     -60
    pool_choice_15[39]  OBJ       4.9396356140913873e+01
    pool_choice_15[39]  R1458     1
    pool_choice_15[39]  R1459     -60
    pool_choice_15[39]  R1477     -1
    pool_choice_15[39]  R1488     -1
    pool_choice_15[39]  R1501     -1
    pool_choice_15[39]  pool_cover_C25_order_d  1
    pool_choice_15[39]  R1807     -60
    pool_choice_15[39]  R1811     -60
    pool_choice_15[39]  R1813     -60
    pool_choice_15[40]  OBJ       3.1747081387645608e+01
    pool_choice_15[40]  R1458     1
    pool_choice_15[40]  R1459     -60
    pool_choice_15[40]  R1472     -1
    pool_choice_15[40]  R1480     -1
    pool_choice_15[40]  R1493     -1
    pool_choice_15[40]  R1501     -1
    pool_choice_15[40]  pool_cover_C47_order_d  1
    pool_choice_15[40]  pool_cover_C29_order_p  1
    pool_choice_15[40]  R1728     -1
    pool_choice_15[40]  R1807     -60
    pool_choice_15[40]  R1811     -60
    pool_choice_15[40]  R1813     -60
    pool_choice_15[41]  OBJ       2.8987894208396355e+01
    pool_choice_15[41]  R1458     1
    pool_choice_15[41]  R1471     -1
    pool_choice_15[41]  R1485     -1
    pool_choice_15[41]  R1492     -1
    pool_choice_15[41]  R1495     -1
    pool_choice_15[41]  pool_cover_C88_order_p  1
    pool_choice_15[41]  pool_cover_C47_order_p  1
    pool_choice_15[41]  R1722     -1
    pool_choice_15[42]  OBJ       2.6076809620810597e+01
    pool_choice_15[42]  R1458     1
    pool_choice_15[42]  R1459     -60
    pool_choice_15[42]  R1475     -1
    pool_choice_15[42]  R1487     -1
    pool_choice_15[42]  R1500     -1
    pool_choice_15[42]  pool_cover_C76_order_d  1
    pool_choice_15[42]  R1807     -60
    pool_choice_15[42]  R1811     -60
    pool_choice_15[42]  R1813     -60
    pool_choice_15[43]  OBJ       2.0654115613359256e+01
    pool_choice_15[43]  R1458     1
    pool_choice_15[43]  R1459     -60
    pool_choice_15[43]  R1466     -1
    pool_choice_15[43]  R1480     -1
    pool_choice_15[43]  R1493     -1
    pool_choice_15[43]  R1500     -1
    pool_choice_15[43]  pool_cover_C88_order_d  1
    pool_choice_15[43]  pool_cover_C29_order_p  1
    pool_choice_15[43]  R1729     -1
    pool_choice_15[43]  R1807     -60
    pool_choice_15[43]  R1811     -60
    pool_choice_15[43]  R1813     -60
    pool_choice_15[44]  OBJ       6.2032249677083293e+01
    pool_choice_15[44]  R1458     1
    pool_choice_15[44]  R1459     -60
    pool_choice_15[44]  R1468     -1
    pool_choice_15[44]  R1489     -1
    pool_choice_15[44]  R1501     -1
    pool_choice_15[44]  pool_cover_C46_order_d  1
    pool_choice_15[44]  R1807     -60
    pool_choice_15[44]  R1811     -60
    pool_choice_15[44]  R1813     -60
    pool_choice_15[45]  OBJ       8.1575595302846423e+01
    pool_choice_15[45]  R1458     1
    pool_choice_15[45]  R1459     -60
    pool_choice_15[45]  R1472     -1
    pool_choice_15[45]  R1480     -1
    pool_choice_15[45]  R1491     -1
    pool_choice_15[45]  R1493     -1
    pool_choice_15[45]  R1494     -1
    pool_choice_15[45]  R1501     -1
    pool_choice_15[45]  pool_cover_C47_order_d  1
    pool_choice_15[45]  pool_cover_C46_order_d  1
    pool_choice_15[45]  pool_cover_C46_order_p  1
    pool_choice_15[45]  pool_cover_C29_order_p  1
    pool_choice_15[45]  pool_cover_C6_order_p  1
    pool_choice_15[45]  R1707     -1
    pool_choice_15[45]  R1714     -1
    pool_choice_15[45]  R1718     -1
    pool_choice_15[45]  R1730     -1
    pool_choice_15[45]  R1807     -60
    pool_choice_15[45]  R1811     -60
    pool_choice_15[45]  R1813     -60
    pool_used_15  R1458     -1
    pool_used_15  R1459     -28800
    pool_used_15  R1460     -75600
    pool_used_15  R1461     -75540
    pool_used_15  R1462     -1
    pool_used_15  R1463     -80
    pool_used_15  R1464     -80
    pool_used_15  R1807     -75660
    pool_used_15  R1808     -81
    pool_used_15  R1811     -75660
    pool_used_15  R1812     -81
    pool_used_15  R1813     -75660
    pool_used_15  R1814     -81
    pool_start_15  R1459     1
    pool_start_15  R1460     1
    pool_start_15  R1807     1
    pool_start_15  R1811     1
    pool_start_15  R1813     1
    pool_start_15  GC1153    -1
    pool_start_15  GC1155    -1
    pool_start_15  GC1157    -1
    pool_start_15  GC1159    -1
    pool_start_15  GC1161    -1
    pool_start_15  GC1163    -1
    pool_start_15  GC1165    -1
    pool_start_15  GC1167    -1
    pool_start_15  GC1169    -1
    pool_start_15  GC1171    -1
    pool_start_15  GC1173    -1
    pool_start_15  GC1175    -1
    pool_start_15  GC1177    -1
    pool_start_15  GC1213    1
    pool_start_15  GC1214    1
    pool_start_15  GC1215    1
    pool_end_15  R1461     1
    pool_end_15  GC1179    1
    pool_end_15  GC1181    1
    pool_end_15  GC1183    1
    pool_end_15  GC1185    1
    pool_end_15  GC1187    1
    pool_end_15  GC1189    1
    pool_end_15  GC1191    1
    pool_end_15  GC1193    1
    pool_end_15  GC1195    1
    pool_end_15  GC1197    1
    pool_end_15  GC1199    1
    pool_end_15  GC1201    1
    pool_end_15  GC1203    1
    pool_end_15  GC1205    -1
    pool_end_15  GC1206    -1
    pool_end_15  GC1207    -1
    pool_end_15  GC1208    -1
    pool_end_15  GC1209    -1
    pool_end_15  GC1210    -1
    pool_end_15  GC1211    -1
    pool_end_15  GC1212    -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_15  R1462     1
    pool_start_rank_15  R1463     1
    pool_start_rank_15  R1808     1
    pool_start_rank_15  R1812     1
    pool_start_rank_15  R1814     1
    pool_start_rank_15  GC1154    -1
    pool_start_rank_15  GC1156    -1
    pool_start_rank_15  GC1158    -1
    pool_start_rank_15  GC1160    -1
    pool_start_rank_15  GC1162    -1
    pool_start_rank_15  GC1164    -1
    pool_start_rank_15  GC1166    -1
    pool_start_rank_15  GC1168    -1
    pool_start_rank_15  GC1170    -1
    pool_start_rank_15  GC1172    -1
    pool_start_rank_15  GC1174    -1
    pool_start_rank_15  GC1176    -1
    pool_start_rank_15  GC1178    -1
    pool_end_rank_15  R1464     1
    pool_end_rank_15  GC1180    1
    pool_end_rank_15  GC1182    1
    pool_end_rank_15  GC1184    1
    pool_end_rank_15  GC1186    1
    pool_end_rank_15  GC1188    1
    pool_end_rank_15  GC1190    1
    pool_end_rank_15  GC1192    1
    pool_end_rank_15  GC1194    1
    pool_end_rank_15  GC1196    1
    pool_end_rank_15  GC1198    1
    pool_end_rank_15  GC1200    1
    pool_end_rank_15  GC1202    1
    pool_end_rank_15  GC1204    1
    MARKER    'MARKER'                 'INTORG'
    pool_first_15_C6_order_d  R1465     1
    pool_first_15_C88_order_d  R1466     1
    pool_first_15_C29_order_d  R1467     1
    pool_first_15_C46_order_d  R1468     1
    pool_first_15_C29_order_p  R1469     1
    pool_first_15_C6_order_p  R1470     1
    pool_first_15_C88_order_p  R1471     1
    pool_first_15_C47_order_d  R1472     1
    pool_first_15_C47_order_p  R1473     1
    pool_first_15_C76_order_p  R1474     1
    pool_first_15_C76_order_d  R1475     1
    pool_first_15_C27_order_d  R1476     1
    pool_first_15_C25_order_d  R1477     1
    pool_last_15_C6_order_p  R1478     1
    pool_last_15_C88_order_p  R1479     1
    pool_last_15_C29_order_p  R1480     1
    pool_last_15_C46_order_p  R1481     1
    pool_last_15_C6_order_d  R1482     1
    pool_last_15_C88_order_d  R1483     1
    pool_last_15_C47_order_d  R1484     1
    pool_last_15_C47_order_p  R1485     1
    pool_last_15_C29_order_d  R1486     1
    pool_last_15_C76_order_d  R1487     1
    pool_last_15_C25_order_d  R1488     1
    pool_last_15_C46_order_d  R1489     1
    pool_last_15_C27_order_d  R1490     1
    pool_pickup_15_C6_order  R1491     1
    pool_pickup_15_C88_order  R1492     1
    pool_pickup_15_C29_order  R1493     1
    pool_pickup_15_C46_order  R1494     1
    pool_pickup_15_C47_order  R1495     1
    pool_pickup_15_C76_order  R1496     1
    pool_pickup_15_C25_order  R1497     1
    pool_pickup_15_C27_order  R1498     1
    pool_batch_15_b3  R1499     1
    pool_batch_15_b1  R1500     1
    pool_batch_15_b2  R1501     1
    pool_choice_16[0]  OBJ       1.6970562748477139e+01
    pool_choice_16[0]  R1502     1
    pool_choice_16[0]  R1503     -60
    pool_choice_16[0]  R1509     -1
    pool_choice_16[0]  R1513     -1
    pool_choice_16[0]  R1517     -1
    pool_choice_16[0]  R1519     -1
    pool_choice_16[0]  pool_cover_C95_order_d  1
    pool_choice_16[0]  pool_cover_C95_order_p  1
    pool_choice_16[0]  R1763     -1
    pool_choice_16[1]  OBJ       1.6970562748477139e+01
    pool_choice_16[1]  R1502     1
    pool_choice_16[1]  R1503     -60
    pool_choice_16[1]  R1509     -1
    pool_choice_16[1]  R1514     -1
    pool_choice_16[1]  R1519     -1
    pool_choice_16[1]  pool_cover_C95_order_d  1
    pool_choice_16[2]  OBJ       1.6970562748477139e+01
    pool_choice_16[2]  R1502     1
    pool_choice_16[2]  R1510     -1
    pool_choice_16[2]  R1513     -1
    pool_choice_16[2]  R1517     -1
    pool_choice_16[2]  pool_cover_C95_order_p  1
    pool_choice_16[3]  OBJ       7.6550636836018555e+01
    pool_choice_16[3]  R1502     1
    pool_choice_16[3]  R1503     -60
    pool_choice_16[3]  R1511     -1
    pool_choice_16[3]  R1515     -1
    pool_choice_16[3]  R1518     -1
    pool_choice_16[3]  R1520     -1
    pool_choice_16[3]  pool_cover_C34_order_d  1
    pool_choice_16[3]  pool_cover_C34_order_p  1
    pool_choice_16[3]  R1764     -1
    pool_choice_16[4]  OBJ       7.6550636836018555e+01
    pool_choice_16[4]  R1502     1
    pool_choice_16[4]  R1503     -60
    pool_choice_16[4]  R1511     -1
    pool_choice_16[4]  R1516     -1
    pool_choice_16[4]  R1520     -1
    pool_choice_16[4]  pool_cover_C34_order_d  1
    pool_choice_16[5]  OBJ       7.6550636836018555e+01
    pool_choice_16[5]  R1502     1
    pool_choice_16[5]  R1512     -1
    pool_choice_16[5]  R1515     -1
    pool_choice_16[5]  R1518     -1
    pool_choice_16[5]  pool_cover_C34_order_p  1
    pool_choice_16[6]  OBJ       7.7566443393746567e+01
    pool_choice_16[6]  R1502     1
    pool_choice_16[6]  R1503     -60
    pool_choice_16[6]  R1511     -1
    pool_choice_16[6]  R1513     -1
    pool_choice_16[6]  R1517     -1
    pool_choice_16[6]  R1518     -1
    pool_choice_16[6]  R1520     -1
    pool_choice_16[6]  pool_cover_C34_order_d  1
    pool_choice_16[6]  pool_cover_C34_order_p  1
    pool_choice_16[6]  pool_cover_C95_order_p  1
    pool_choice_16[6]  R1764     -1
    pool_choice_16[6]  R1765     -1
    pool_choice_16[7]  OBJ       7.7566443393746567e+01
    pool_choice_16[7]  R1502     1
    pool_choice_16[7]  R1512     -1
    pool_choice_16[7]  R1513     -1
    pool_choice_16[7]  R1517     -1
    pool_choice_16[7]  R1518     -1
    pool_choice_16[7]  pool_cover_C34_order_p  1
    pool_choice_16[7]  pool_cover_C95_order_p  1
    pool_choice_16[7]  R1765     -1
    pool_choice_16[8]  OBJ       7.7566443393746567e+01
    pool_choice_16[8]  R1502     1
    pool_choice_16[8]  R1503     -60
    pool_choice_16[8]  R1511     -1
    pool_choice_16[8]  R1513     -1
    pool_choice_16[8]  R1517     -1
    pool_choice_16[8]  R1520     -1
    pool_choice_16[8]  pool_cover_C34_order_d  1
    pool_choice_16[8]  pool_cover_C95_order_p  1
    pool_choice_16[8]  R1766     -1
    pool_used_16  R1502     -1
    pool_used_16  R1503     -28800
    pool_used_16  R1504     -75600
    pool_used_16  R1505     -75540
    pool_used_16  R1506     -1
    pool_used_16  R1507     -80
    pool_used_16  R1508     -80
    pool_used_16  R1815     -75660
    pool_used_16  R1816     -81
    pool_start_16  R1503     1
    pool_start_16  R1504     1
    pool_start_16  GC1216    -1
    pool_start_16  GC1218    -1
    pool_start_16  GC1220    -1
    pool_start_16  GC1222    -1
    pool_start_16  GC1234    1
    pool_start_16  GC1235    1
    pool_end_16  R1505     1
    pool_end_16  R1815     -1
    pool_end_16  GC1224    1
    pool_end_16  GC1226    1
    pool_end_16  GC1228    1
    pool_end_16  GC1230    1
    pool_end_16  GC1232    -1
    pool_end_16  GC1233    -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_16  R1506     1
    pool_start_rank_16  R1507     1
    pool_start_rank_16  GC1217    -1
    pool_start_rank_16  GC1219    -1
    pool_start_rank_16  GC1221    -1
    pool_start_rank_16  GC1223    -1
    pool_end_rank_16  R1508     1
    pool_end_rank_16  R1816     -1
    pool_end_rank_16  GC1225    1
    pool_end_rank_16  GC1227    1
    pool_end_rank_16  GC1229    1
    pool_end_rank_16  GC1231    1
    MARKER    'MARKER'                 'INTORG'
    pool_first_16_C95_order_d  R1509     1
    pool_first_16_C95_order_p  R1510     1
    pool_first_16_C34_order_d  R1511     1
    pool_first_16_C34_order_p  R1512     1
    pool_last_16_C95_order_p  R1513     1
    pool_last_16_C95_order_d  R1514     1
    pool_last_16_C34_order_p  R1515     1
    pool_last_16_C34_order_d  R1516     1
    pool_pickup_16_C95_order  R1517     1
    pool_pickup_16_C34_order  R1518     1
    pool_batch_16_b2  R1519     1
    pool_batch_16_b1  R1520     1
    pool_choice_17[0]  OBJ       1.6970562748477139e+01
    pool_choice_17[0]  R1521     1
    pool_choice_17[0]  R1522     -60
    pool_choice_17[0]  R1528     -1
    pool_choice_17[0]  R1532     -1
    pool_choice_17[0]  R1536     -1
    pool_choice_17[0]  R1538     -1
    pool_choice_17[0]  pool_cover_C95_order_d  1
    pool_choice_17[0]  pool_cover_C95_order_p  1
    pool_choice_17[0]  R1763     -1
    pool_choice_17[0]  R1815     -60
    pool_choice_17[1]  OBJ       1.6970562748477139e+01
    pool_choice_17[1]  R1521     1
    pool_choice_17[1]  R1522     -60
    pool_choice_17[1]  R1528     -1
    pool_choice_17[1]  R1533     -1
    pool_choice_17[1]  R1538     -1
    pool_choice_17[1]  pool_cover_C95_order_d  1
    pool_choice_17[1]  R1815     -60
    pool_choice_17[2]  OBJ       1.6970562748477139e+01
    pool_choice_17[2]  R1521     1
    pool_choice_17[2]  R1529     -1
    pool_choice_17[2]  R1532     -1
    pool_choice_17[2]  R1536     -1
    pool_choice_17[2]  pool_cover_C95_order_p  1
    pool_choice_17[3]  OBJ       7.6550636836018555e+01
    pool_choice_17[3]  R1521     1
    pool_choice_17[3]  R1522     -60
    pool_choice_17[3]  R1530     -1
    pool_choice_17[3]  R1534     -1
    pool_choice_17[3]  R1537     -1
    pool_choice_17[3]  R1539     -1
    pool_choice_17[3]  pool_cover_C34_order_d  1
    pool_choice_17[3]  pool_cover_C34_order_p  1
    pool_choice_17[3]  R1764     -1
    pool_choice_17[3]  R1815     -60
    pool_choice_17[4]  OBJ       7.6550636836018555e+01
    pool_choice_17[4]  R1521     1
    pool_choice_17[4]  R1522     -60
    pool_choice_17[4]  R1530     -1
    pool_choice_17[4]  R1535     -1
    pool_choice_17[4]  R1539     -1
    pool_choice_17[4]  pool_cover_C34_order_d  1
    pool_choice_17[4]  R1815     -60
    pool_choice_17[5]  OBJ       7.7566443393746567e+01
    pool_choice_17[5]  R1521     1
    pool_choice_17[5]  R1522     -60
    pool_choice_17[5]  R1530     -1
    pool_choice_17[5]  R1532     -1
    pool_choice_17[5]  R1536     -1
    pool_choice_17[5]  R1537     -1
    pool_choice_17[5]  R1539     -1
    pool_choice_17[5]  pool_cover_C34_order_d  1
    pool_choice_17[5]  pool_cover_C34_order_p  1
    pool_choice_17[5]  pool_cover_C95_order_p  1
    pool_choice_17[5]  R1764     -1
    pool_choice_17[5]  R1765     -1
    pool_choice_17[5]  R1815     -60
    pool_choice_17[6]  OBJ       7.7566443393746567e+01
    pool_choice_17[6]  R1521     1
    pool_choice_17[6]  R1531     -1
    pool_choice_17[6]  R1532     -1
    pool_choice_17[6]  R1536     -1
    pool_choice_17[6]  R1537     -1
    pool_choice_17[6]  pool_cover_C34_order_p  1
    pool_choice_17[6]  pool_cover_C95_order_p  1
    pool_choice_17[6]  R1765     -1
    pool_choice_17[7]  OBJ       7.6550636836018555e+01
    pool_choice_17[7]  R1521     1
    pool_choice_17[7]  R1531     -1
    pool_choice_17[7]  R1534     -1
    pool_choice_17[7]  R1537     -1
    pool_choice_17[7]  pool_cover_C34_order_p  1
    pool_choice_17[8]  OBJ       7.7566443393746567e+01
    pool_choice_17[8]  R1521     1
    pool_choice_17[8]  R1522     -60
    pool_choice_17[8]  R1530     -1
    pool_choice_17[8]  R1532     -1
    pool_choice_17[8]  R1536     -1
    pool_choice_17[8]  R1539     -1
    pool_choice_17[8]  pool_cover_C34_order_d  1
    pool_choice_17[8]  pool_cover_C95_order_p  1
    pool_choice_17[8]  R1766     -1
    pool_choice_17[8]  R1815     -60
    pool_used_17  R1521     -1
    pool_used_17  R1522     -28800
    pool_used_17  R1523     -75600
    pool_used_17  R1524     -75540
    pool_used_17  R1525     -1
    pool_used_17  R1526     -80
    pool_used_17  R1527     -80
    pool_used_17  R1815     -75660
    pool_used_17  R1816     -81
    pool_start_17  R1522     1
    pool_start_17  R1523     1
    pool_start_17  R1815     1
    pool_start_17  GC1236    -1
    pool_start_17  GC1238    -1
    pool_start_17  GC1240    -1
    pool_start_17  GC1242    -1
    pool_start_17  GC1254    1
    pool_start_17  GC1255    1
    pool_end_17  R1524     1
    pool_end_17  GC1244    1
    pool_end_17  GC1246    1
    pool_end_17  GC1248    1
    pool_end_17  GC1250    1
    pool_end_17  GC1252    -1
    pool_end_17  GC1253    -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_17  R1525     1
    pool_start_rank_17  R1526     1
    pool_start_rank_17  R1816     1
    pool_start_rank_17  GC1237    -1
    pool_start_rank_17  GC1239    -1
    pool_start_rank_17  GC1241    -1
    pool_start_rank_17  GC1243    -1
    pool_end_rank_17  R1527     1
    pool_end_rank_17  GC1245    1
    pool_end_rank_17  GC1247    1
    pool_end_rank_17  GC1249    1
    pool_end_rank_17  GC1251    1
    MARKER    'MARKER'                 'INTORG'
    pool_first_17_C95_order_d  R1528     1
    pool_first_17_C95_order_p  R1529     1
    pool_first_17_C34_order_d  R1530     1
    pool_first_17_C34_order_p  R1531     1
    pool_last_17_C95_order_p  R1532     1
    pool_last_17_C95_order_d  R1533     1
    pool_last_17_C34_order_p  R1534     1
    pool_last_17_C34_order_d  R1535     1
    pool_pickup_17_C95_order  R1536     1
    pool_pickup_17_C34_order  R1537     1
    pool_batch_17_b2  R1538     1
    pool_batch_17_b1  R1539     1
    pool_choice_18[0]  OBJ       1.6970562748477139e+01
    pool_choice_18[0]  R1540     1
    pool_choice_18[0]  R1541     -60
    pool_choice_18[0]  R1547     -1
    pool_choice_18[0]  R1551     -1
    pool_choice_18[0]  R1555     -1
    pool_choice_18[0]  R1557     -1
    pool_choice_18[0]  pool_cover_C95_order_d  1
    pool_choice_18[0]  pool_cover_C95_order_p  1
    pool_choice_18[0]  R1763     -1
    pool_choice_18[1]  OBJ       1.6970562748477139e+01
    pool_choice_18[1]  R1540     1
    pool_choice_18[1]  R1541     -60
    pool_choice_18[1]  R1547     -1
    pool_choice_18[1]  R1552     -1
    pool_choice_18[1]  R1557     -1
    pool_choice_18[1]  pool_cover_C95_order_d  1
    pool_choice_18[2]  OBJ       1.6970562748477139e+01
    pool_choice_18[2]  R1540     1
    pool_choice_18[2]  R1548     -1
    pool_choice_18[2]  R1551     -1
    pool_choice_18[2]  R1555     -1
    pool_choice_18[2]  pool_cover_C95_order_p  1
    pool_choice_18[3]  OBJ       7.6550636836018555e+01
    pool_choice_18[3]  R1540     1
    pool_choice_18[3]  R1541     -60
    pool_choice_18[3]  R1549     -1
    pool_choice_18[3]  R1553     -1
    pool_choice_18[3]  R1556     -1
    pool_choice_18[3]  R1558     -1
    pool_choice_18[3]  pool_cover_C34_order_d  1
    pool_choice_18[3]  pool_cover_C34_order_p  1
    pool_choice_18[3]  R1764     -1
    pool_choice_18[4]  OBJ       7.6550636836018555e+01
    pool_choice_18[4]  R1540     1
    pool_choice_18[4]  R1541     -60
    pool_choice_18[4]  R1549     -1
    pool_choice_18[4]  R1554     -1
    pool_choice_18[4]  R1558     -1
    pool_choice_18[4]  pool_cover_C34_order_d  1
    pool_choice_18[5]  OBJ       7.6550636836018555e+01
    pool_choice_18[5]  R1540     1
    pool_choice_18[5]  R1550     -1
    pool_choice_18[5]  R1553     -1
    pool_choice_18[5]  R1556     -1
    pool_choice_18[5]  pool_cover_C34_order_p  1
    pool_choice_18[6]  OBJ       7.7566443393746567e+01
    pool_choice_18[6]  R1540     1
    pool_choice_18[6]  R1541     -60
    pool_choice_18[6]  R1549     -1
    pool_choice_18[6]  R1551     -1
    pool_choice_18[6]  R1555     -1
    pool_choice_18[6]  R1556     -1
    pool_choice_18[6]  R1558     -1
    pool_choice_18[6]  pool_cover_C34_order_d  1
    pool_choice_18[6]  pool_cover_C34_order_p  1
    pool_choice_18[6]  pool_cover_C95_order_p  1
    pool_choice_18[6]  R1764     -1
    pool_choice_18[6]  R1765     -1
    pool_choice_18[7]  OBJ       7.7566443393746567e+01
    pool_choice_18[7]  R1540     1
    pool_choice_18[7]  R1550     -1
    pool_choice_18[7]  R1551     -1
    pool_choice_18[7]  R1555     -1
    pool_choice_18[7]  R1556     -1
    pool_choice_18[7]  pool_cover_C34_order_p  1
    pool_choice_18[7]  pool_cover_C95_order_p  1
    pool_choice_18[7]  R1765     -1
    pool_choice_18[8]  OBJ       7.7566443393746567e+01
    pool_choice_18[8]  R1540     1
    pool_choice_18[8]  R1541     -60
    pool_choice_18[8]  R1549     -1
    pool_choice_18[8]  R1551     -1
    pool_choice_18[8]  R1555     -1
    pool_choice_18[8]  R1558     -1
    pool_choice_18[8]  pool_cover_C34_order_d  1
    pool_choice_18[8]  pool_cover_C95_order_p  1
    pool_choice_18[8]  R1766     -1
    pool_used_18  R1540     -1
    pool_used_18  R1541     -28800
    pool_used_18  R1542     -75600
    pool_used_18  R1543     -75540
    pool_used_18  R1544     -1
    pool_used_18  R1545     -80
    pool_used_18  R1546     -80
    pool_used_18  R1817     -75660
    pool_used_18  R1818     -81
    pool_start_18  R1541     1
    pool_start_18  R1542     1
    pool_start_18  GC1256    -1
    pool_start_18  GC1258    -1
    pool_start_18  GC1260    -1
    pool_start_18  GC1262    -1
    pool_start_18  GC1274    1
    pool_start_18  GC1275    1
    pool_end_18  R1543     1
    pool_end_18  R1817     -1
    pool_end_18  GC1264    1
    pool_end_18  GC1266    1
    pool_end_18  GC1268    1
    pool_end_18  GC1270    1
    pool_end_18  GC1272    -1
    pool_end_18  GC1273    -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_18  R1544     1
    pool_start_rank_18  R1545     1
    pool_start_rank_18  GC1257    -1
    pool_start_rank_18  GC1259    -1
    pool_start_rank_18  GC1261    -1
    pool_start_rank_18  GC1263    -1
    pool_end_rank_18  R1546     1
    pool_end_rank_18  R1818     -1
    pool_end_rank_18  GC1265    1
    pool_end_rank_18  GC1267    1
    pool_end_rank_18  GC1269    1
    pool_end_rank_18  GC1271    1
    MARKER    'MARKER'                 'INTORG'
    pool_first_18_C95_order_d  R1547     1
    pool_first_18_C95_order_p  R1548     1
    pool_first_18_C34_order_d  R1549     1
    pool_first_18_C34_order_p  R1550     1
    pool_last_18_C95_order_p  R1551     1
    pool_last_18_C95_order_d  R1552     1
    pool_last_18_C34_order_p  R1553     1
    pool_last_18_C34_order_d  R1554     1
    pool_pickup_18_C95_order  R1555     1
    pool_pickup_18_C34_order  R1556     1
    pool_batch_18_b2  R1557     1
    pool_batch_18_b1  R1558     1
    pool_choice_19[0]  OBJ       7.6550636836018555e+01
    pool_choice_19[0]  R1559     1
    pool_choice_19[0]  R1560     -60
    pool_choice_19[0]  R1566     -1
    pool_choice_19[0]  R1570     -1
    pool_choice_19[0]  R1574     -1
    pool_choice_19[0]  R1576     -1
    pool_choice_19[0]  pool_cover_C34_order_d  1
    pool_choice_19[0]  pool_cover_C34_order_p  1
    pool_choice_19[0]  R1764     -1
    pool_choice_19[0]  R1817     -60
    pool_choice_19[1]  OBJ       1.6970562748477139e+01
    pool_choice_19[1]  R1559     1
    pool_choice_19[1]  R1560     -60
    pool_choice_19[1]  R1567     -1
    pool_choice_19[1]  R1571     -1
    pool_choice_19[1]  R1575     -1
    pool_choice_19[1]  R1577     -1
    pool_choice_19[1]  pool_cover_C95_order_d  1
    pool_choice_19[1]  pool_cover_C95_order_p  1
    pool_choice_19[1]  R1763     -1
    pool_choice_19[1]  R1817     -60
    pool_choice_19[2]  OBJ       7.7566443393746567e+01
    pool_choice_19[2]  R1559     1
    pool_choice_19[2]  R1560     -60
    pool_choice_19[2]  R1566     -1
    pool_choice_19[2]  R1571     -1
    pool_choice_19[2]  R1574     -1
    pool_choice_19[2]  R1575     -1
    pool_choice_19[2]  R1576     -1
    pool_choice_19[2]  pool_cover_C34_order_d  1
    pool_choice_19[2]  pool_cover_C34_order_p  1
    pool_choice_19[2]  pool_cover_C95_order_p  1
    pool_choice_19[2]  R1764     -1
    pool_choice_19[2]  R1765     -1
    pool_choice_19[2]  R1817     -60
    pool_choice_19[3]  OBJ       7.6550636836018555e+01
    pool_choice_19[3]  R1559     1
    pool_choice_19[3]  R1560     -60
    pool_choice_19[3]  R1566     -1
    pool_choice_19[3]  R1572     -1
    pool_choice_19[3]  R1576     -1
    pool_choice_19[3]  pool_cover_C34_order_d  1
    pool_choice_19[3]  R1817     -60
    pool_choice_19[4]  OBJ       7.6550636836018555e+01
    pool_choice_19[4]  R1559     1
    pool_choice_19[4]  R1568     -1
    pool_choice_19[4]  R1570     -1
    pool_choice_19[4]  R1574     -1
    pool_choice_19[4]  pool_cover_C34_order_p  1
    pool_choice_19[5]  OBJ       1.6970562748477139e+01
    pool_choice_19[5]  R1559     1
    pool_choice_19[5]  R1569     -1
    pool_choice_19[5]  R1571     -1
    pool_choice_19[5]  R1575     -1
    pool_choice_19[5]  pool_cover_C95_order_p  1
    pool_choice_19[6]  OBJ       1.6970562748477139e+01
    pool_choice_19[6]  R1559     1
    pool_choice_19[6]  R1560     -60
    pool_choice_19[6]  R1567     -1
    pool_choice_19[6]  R1573     -1
    pool_choice_19[6]  R1577     -1
    pool_choice_19[6]  pool_cover_C95_order_d  1
    pool_choice_19[6]  R1817     -60
    pool_choice_19[7]  OBJ       7.7566443393746567e+01
    pool_choice_19[7]  R1559     1
    pool_choice_19[7]  R1568     -1
    pool_choice_19[7]  R1571     -1
    pool_choice_19[7]  R1574     -1
    pool_choice_19[7]  R1575     -1
    pool_choice_19[7]  pool_cover_C34_order_p  1
    pool_choice_19[7]  pool_cover_C95_order_p  1
    pool_choice_19[7]  R1765     -1
    pool_choice_19[8]  OBJ       7.7566443393746567e+01
    pool_choice_19[8]  R1559     1
    pool_choice_19[8]  R1560     -60
    pool_choice_19[8]  R1566     -1
    pool_choice_19[8]  R1571     -1
    pool_choice_19[8]  R1575     -1
    pool_choice_19[8]  R1576     -1
    pool_choice_19[8]  pool_cover_C34_order_d  1
    pool_choice_19[8]  pool_cover_C95_order_p  1
    pool_choice_19[8]  R1766     -1
    pool_choice_19[8]  R1817     -60
    pool_used_19  R1559     -1
    pool_used_19  R1560     -28800
    pool_used_19  R1561     -75600
    pool_used_19  R1562     -75540
    pool_used_19  R1563     -1
    pool_used_19  R1564     -80
    pool_used_19  R1565     -80
    pool_used_19  R1817     -75660
    pool_used_19  R1818     -81
    pool_start_19  R1560     1
    pool_start_19  R1561     1
    pool_start_19  R1817     1
    pool_start_19  GC1276    -1
    pool_start_19  GC1278    -1
    pool_start_19  GC1280    -1
    pool_start_19  GC1282    -1
    pool_start_19  GC1294    1
    pool_start_19  GC1295    1
    pool_end_19  R1562     1
    pool_end_19  GC1284    1
    pool_end_19  GC1286    1
    pool_end_19  GC1288    1
    pool_end_19  GC1290    1
    pool_end_19  GC1292    -1
    pool_end_19  GC1293    -1
    MARKER    'MARKER'                 'INTEND'
    pool_start_rank_19  R1563     1
    pool_start_rank_19  R1564     1
    pool_start_rank_19  R1818     1
    pool_start_rank_19  GC1277    -1
    pool_start_rank_19  GC1279    -1
    pool_start_rank_19  GC1281    -1
    pool_start_rank_19  GC1283    -1
    pool_end_rank_19  R1565     1
    pool_end_rank_19  GC1285    1
    pool_end_rank_19  GC1287    1
    pool_end_rank_19  GC1289    1
    pool_end_rank_19  GC1291    1
    MARKER    'MARKER'                 'INTORG'
    pool_first_19_C34_order_d  R1566     1
    pool_first_19_C95_order_d  R1567     1
    pool_first_19_C34_order_p  R1568     1
    pool_first_19_C95_order_p  R1569     1
    pool_last_19_C34_order_p  R1570     1
    pool_last_19_C95_order_p  R1571     1
    pool_last_19_C34_order_d  R1572     1
    pool_last_19_C95_order_d  R1573     1
    pool_pickup_19_C34_order  R1574     1
    pool_pickup_19_C95_order  R1575     1
    pool_batch_19_b1  R1576     1
    pool_batch_19_b2  R1577     1
    pool_link_0  R1618     1
    pool_link_1  R1619     1
    pool_link_2  R1620     1
    pool_link_3  R1621     1
    pool_link_4  R1622     1
    pool_link_5  R1623     1
    pool_link_6  R1624     1
    pool_link_7  R1625     1
    pool_link_8  R1626     1
    pool_link_9  R1627     1
    pool_link_10  R1628     1
    pool_link_11  R1629     1
    pool_link_12  R1630     1
    pool_link_13  R1631     1
    pool_link_14  R1632     1
    pool_link_15  R1633     1
    pool_link_16  R1634     1
    pool_link_17  R1635     1
    pool_link_18  R1636     1
    pool_link_19  R1637     1
    pool_link_20  R1638     1
    pool_link_21  R1639     1
    pool_link_22  R1640     1
    pool_link_23  R1641     1
    pool_link_24  R1642     1
    pool_link_25  R1643     1
    pool_link_26  R1644     1
    pool_link_27  R1645     1
    pool_link_28  R1646     1
    pool_link_29  R1647     1
    pool_link_30  R1648     1
    pool_link_31  R1649     1
    pool_link_32  R1650     1
    pool_link_33  R1651     1
    pool_link_34  R1652     1
    pool_link_35  R1653     1
    pool_link_36  R1654     1
    pool_link_37  R1655     1
    pool_link_38  R1656     1
    pool_link_39  R1657     1
    pool_link_40  R1658     1
    pool_link_41  R1659     1
    pool_link_42  R1660     1
    pool_link_43  R1661     1
    pool_link_44  R1662     1
    pool_link_45  R1663     1
    pool_link_46  R1664     1
    pool_link_47  R1665     1
    pool_link_48  R1666     1
    pool_link_49  R1667     1
    pool_link_50  R1668     1
    pool_link_51  R1669     1
    pool_link_52  R1670     1
    pool_link_53  R1671     1
    pool_link_54  R1672     1
    pool_link_55  R1673     1
    pool_link_56  R1674     1
    pool_link_57  R1675     1
    pool_link_58  R1676     1
    pool_link_59  R1677     1
    pool_link_60  R1678     1
    pool_link_61  R1679     1
    pool_link_62  R1680     1
    pool_link_63  R1681     1
    pool_link_64  R1682     1
    pool_link_65  R1683     1
    pool_link_66  R1684     1
    pool_link_67  R1685     1
    pool_link_68  R1686     1
    pool_link_69  R1687     1
    pool_link_70  R1688     1
    pool_link_71  R1689     1
    pool_link_72  R1690     1
    pool_link_73  R1691     1
    pool_link_74  R1692     1
    pool_link_75  R1693     1
    pool_link_76  R1694     1
    pool_link_77  R1695     1
    pool_link_78  R1696     1
    pool_link_79  R1697     1
    pool_link_80  R1698     1
    pool_link_81  R1699     1
    pool_link_82  R1700     1
    pool_link_83  R1701     1
    pool_link_84  R1702     1
    pool_link_85  R1703     1
    pool_link_86  R1704     1
    pool_link_87  R1705     1
    pool_link_88  R1706     1
    pool_link_89  R1707     1
    pool_link_90  R1708     1
    pool_link_91  R1709     1
    pool_link_92  R1710     1
    pool_link_93  R1711     1
    pool_link_94  R1712     1
    pool_link_95  R1713     1
    pool_link_96  R1714     1
    pool_link_97  R1715     1
    pool_link_98  R1716     1
    pool_link_99  R1717     1
    pool_link_100  R1718     1
    pool_link_101  R1719     1
    pool_link_102  R1720     1
    pool_link_103  R1721     1
    pool_link_104  R1722     1
    pool_link_105  R1723     1
    pool_link_106  R1724     1
    pool_link_107  R1725     1
    pool_link_108  R1726     1
    pool_link_109  R1727     1
    pool_link_110  R1728     1
    pool_link_111  R1729     1
    pool_link_112  R1730     1
    pool_link_113  R1731     1
    pool_link_114  R1732     1
    pool_link_115  R1733     1
    pool_link_116  R1734     1
    pool_link_117  R1735     1
    pool_link_118  R1736     1
    pool_link_119  R1737     1
    pool_link_120  R1738     1
    pool_link_121  R1739     1
    pool_link_122  R1740     1
    pool_link_123  R1741     1
    pool_link_124  R1742     1
    pool_link_125  R1743     1
    pool_link_126  R1744     1
    pool_link_127  R1745     1
    pool_link_128  R1746     1
    pool_link_129  R1747     1
    pool_link_130  R1748     1
    pool_link_131  R1749     1
    pool_link_132  R1750     1
    pool_link_133  R1751     1
    pool_link_134  R1752     1
    pool_link_135  R1753     1
    pool_link_136  R1754     1
    pool_link_137  R1755     1
    pool_link_138  R1756     1
    pool_link_139  R1757     1
    pool_link_140  R1758     1
    pool_link_141  R1759     1
    pool_link_142  R1760     1
    pool_link_143  R1761     1
    pool_link_144  R1762     1
    pool_link_145  R1763     1
    pool_link_146  R1764     1
    pool_link_147  R1765     1
    pool_link_148  R1766     1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      R592      3
    RHS1      R593      1
    RHS1      R595      1
    RHS1      R596      1
    RHS1      R598      1
    RHS1      R599      1
    RHS1      R601      1
    RHS1      R602      3
    RHS1      R603      1
    RHS1      R605      1
    RHS1      R606      1
    RHS1      R608      1
    RHS1      R609      1
    RHS1      R611      1
    RHS1      R612      3
    RHS1      R613      1
    RHS1      R615      1
    RHS1      R616      1
    RHS1      R618      1
    RHS1      R619      1
    RHS1      R620      32574
    RHS1      R621      366
    RHS1      R622      3000
    RHS1      R623      966
    RHS1      R624      1
    RHS1      R625      33537
    RHS1      R626      423
    RHS1      R627      2400
    RHS1      R628      1023
    RHS1      R629      1
    RHS1      R630      32549
    RHS1      R631      871
    RHS1      R632      2400
    RHS1      R633      1471
    RHS1      R634      1
    RHS1      R635      33175
    RHS1      R636      1025
    RHS1      R637      2400
    RHS1      R638      1625
    RHS1      R639      1
    RHS1      R640      46946
    RHS1      R641      514
    RHS1      R642      3000
    RHS1      R643      1114
    RHS1      R644      1
    RHS1      R645      48055
    RHS1      R646      905
    RHS1      R647      2400
    RHS1      R648      1505
    RHS1      R649      1
    RHS1      R650      46945
    RHS1      R651      995
    RHS1      R652      3000
    RHS1      R653      1595
    RHS1      R654      1
    RHS1      R655      61350
    RHS1      R656      150
    RHS1      R657      1800
    RHS1      R658      750
    RHS1      R659      1
    RHS1      R660      62066
    RHS1      R661      574
    RHS1      R662      2400
    RHS1      R663      1174
    RHS1      R664      1
    RHS1      R665      61366
    RHS1      R666      914
    RHS1      R667      2400
    RHS1      R668      1514
    RHS1      R669      1
    RHS1      R670      32731
    RHS1      R671      329
    RHS1      R672      3000
    RHS1      R673      929
    RHS1      R674      1
    RHS1      R675      33808
    RHS1      R676      452
    RHS1      R677      3000
    RHS1      R678      1052
    RHS1      R679      1
    RHS1      R680      32758
    RHS1      R681      782
    RHS1      R682      3000
    RHS1      R683      1382
    RHS1      R684      1
    RHS1      R685      47165
    RHS1      R686      235
    RHS1      R687      2400
    RHS1      R688      835
    RHS1      R689      1
    RHS1      R690      47739
    RHS1      R691      801
    RHS1      R692      3000
    RHS1      R693      1401
    RHS1      R694      1
    RHS1      R695      47129
    RHS1      R696      991
    RHS1      R697      2400
    RHS1      R698      1591
    RHS1      R699      1
    RHS1      R700      61551
    RHS1      R701      369
    RHS1      R702      2400
    RHS1      R703      969
    RHS1      R704      1
    RHS1      R705      62527
    RHS1      R706      1013
    RHS1      R707      2400
    RHS1      R708      1613
    RHS1      R709      1
    RHS1      R710      32691
    RHS1      R711      1209
    RHS1      R712      2400
    RHS1      R713      1809
    RHS1      R714      1
    RHS1      R715      47085
    RHS1      R716      315
    RHS1      R717      1800
    RHS1      R718      915
    RHS1      R719      1
    RHS1      clean_stock_b1  -20
    RHS1      clean_stock_b2  -7
    RHS1      R732      1
    RHS1      R733      1
    RHS1      R734      1
    RHS1      R735      1
    RHS1      R736      1
    RHS1      R737      1
    RHS1      R738      1
    RHS1      R739      1
    RHS1      R740      1
    RHS1      R741      1
    RHS1      R742      1
    RHS1      R743      1
    RHS1      R744      1
    RHS1      R745      1
    RHS1      R746      1
    RHS1      R747      1
    RHS1      R748      1
    RHS1      R749      1
    RHS1      R750      1
    RHS1      R751      1
    RHS1      pool_cover_C81_order_d  1
    RHS1      pool_cover_C81_order_p  1
    RHS1      pool_cover_C90_order_d  1
    RHS1      pool_cover_C90_order_p  1
    RHS1      pool_cover_C97_order_d  1
    RHS1      pool_cover_C97_order_p  1
    RHS1      pool_cover_C51_order_d  1
    RHS1      pool_cover_C51_order_p  1
    RHS1      pool_cover_C0_order_d  1
    RHS1      pool_cover_C0_order_p  1
    RHS1      pool_cover_C39_order_d  1
    RHS1      pool_cover_C39_order_p  1
    RHS1      pool_cover_C52_order_d  1
    RHS1      pool_cover_C52_order_p  1
    RHS1      pool_cover_C85_order_d  1
    RHS1      pool_cover_C85_order_p  1
    RHS1      pool_cover_C75_order_d  1
    RHS1      pool_cover_C75_order_p  1
    RHS1      pool_cover_C21_order_d  1
    RHS1      pool_cover_C21_order_p  1
    RHS1      pool_cover_C88_order_d  1
    RHS1      pool_cover_C88_order_p  1
    RHS1      pool_cover_C76_order_d  1
    RHS1      pool_cover_C76_order_p  1
    RHS1      pool_cover_C27_order_d  1
    RHS1      pool_cover_C27_order_p  1
    RHS1      pool_cover_C47_order_d  1
    RHS1      pool_cover_C47_order_p  1
    RHS1      pool_cover_C25_order_d  1
    RHS1      pool_cover_C25_order_p  1
    RHS1      pool_cover_C46_order_d  1
    RHS1      pool_cover_C46_order_p  1
    RHS1      pool_cover_C29_order_d  1
    RHS1      pool_cover_C29_order_p  1
    RHS1      pool_cover_C6_order_d  1
    RHS1      pool_cover_C6_order_p  1
    RHS1      pool_cover_C34_order_d  1
    RHS1      pool_cover_C34_order_p  1
    RHS1      pool_cover_C95_order_d  1
    RHS1      pool_cover_C95_order_p  1
    RHS1      R1767     -151260
    RHS1      R1768     -161
    RHS1      R1769     -151260
    RHS1      R1770     -161
    RHS1      R1771     -151260
    RHS1      R1772     -161
    RHS1      R1773     -151260
    RHS1      R1774     -161
    RHS1      R1775     -151260
    RHS1      R1776     -161
    RHS1      R1777     -151260
    RHS1      R1778     -161
    RHS1      R1779     -151260
    RHS1      R1780     -161
    RHS1      R1781     -151260
    RHS1      R1782     -161
    RHS1      R1783     -151260
    RHS1      R1784     -161
    RHS1      R1785     -151260
    RHS1      R1786     -161
    RHS1      R1787     -151260
    RHS1      R1788     -161
    RHS1      R1789     -151260
    RHS1      R1790     -161
    RHS1      R1791     -151260
    RHS1      R1792     -161
    RHS1      R1793     -151260
    RHS1      R1794     -161
    RHS1      R1795     -151260
    RHS1      R1796     -161
    RHS1      R1797     -151260
    RHS1      R1798     -161
    RHS1      R1799     -151260
    RHS1      R1800     -161
    RHS1      R1801     -151260
    RHS1      R1802     -161
    RHS1      R1803     -151260
    RHS1      R1804     -161
    RHS1      R1805     -151260
    RHS1      R1806     -161
    RHS1      R1807     -151260
    RHS1      R1808     -161
    RHS1      R1809     -151260
    RHS1      R1810     -161
    RHS1      R1811     -151260
    RHS1      R1812     -161
    RHS1      R1813     -151260
    RHS1      R1814     -161
    RHS1      R1815     -151260
    RHS1      R1816     -161
    RHS1      R1817     -151260
    RHS1      R1818     -161
    RHS1      GC0       28800
    RHS1      GC1       39600
    RHS1      GC2       39601
    RHS1      GC3       54000
    RHS1      GC4       54001
    RHS1      GC5       71100
    RHS1      GC6       28800
    RHS1      GC7       39600
    RHS1      GC8       39601
    RHS1      GC9       54000
    RHS1      GC10      54001
    RHS1      GC11      71100
    RHS1      GC12      28800
    RHS1      GC13      39600
    RHS1      GC14      39601
    RHS1      GC15      54000
    RHS1      GC16      54001
    RHS1      GC17      71100
    RHS1      GC18      28800
    RHS1      GC19      39600
    RHS1      GC20      39601
    RHS1      GC21      54000
    RHS1      GC22      54001
    RHS1      GC23      71100
    RHS1      GC24      28800
    RHS1      GC25      39600
    RHS1      GC26      39601
    RHS1      GC27      54000
    RHS1      GC28      54001
    RHS1      GC29      71100
    RHS1      GC30      28800
    RHS1      GC31      39600
    RHS1      GC32      39601
    RHS1      GC33      54000
    RHS1      GC34      54001
    RHS1      GC35      71100
    RHS1      GC36      28800
    RHS1      GC37      39600
    RHS1      GC38      39601
    RHS1      GC39      54000
    RHS1      GC40      54001
    RHS1      GC41      71100
    RHS1      GC42      28800
    RHS1      GC43      39600
    RHS1      GC44      39601
    RHS1      GC45      54000
    RHS1      GC46      54001
    RHS1      GC47      71100
    RHS1      GC48      28800
    RHS1      GC49      39600
    RHS1      GC50      39601
    RHS1      GC51      54000
    RHS1      GC52      54001
    RHS1      GC53      71100
    RHS1      GC54      28800
    RHS1      GC55      39600
    RHS1      GC56      39601
    RHS1      GC57      54000
    RHS1      GC58      54001
    RHS1      GC59      71100
    RHS1      GC60      28800
    RHS1      GC61      39600
    RHS1      GC62      39601
    RHS1      GC63      54000
    RHS1      GC64      54001
    RHS1      GC65      71100
    RHS1      GC66      28800
    RHS1      GC67      39600
    RHS1      GC68      39601
    RHS1      GC69      54000
    RHS1      GC70      54001
    RHS1      GC71      71100
    RHS1      GC72      28800
    RHS1      GC73      39600
    RHS1      GC74      39601
    RHS1      GC75      54000
    RHS1      GC76      54001
    RHS1      GC77      71100
    RHS1      GC78      28800
    RHS1      GC79      39600
    RHS1      GC80      39601
    RHS1      GC81      54000
    RHS1      GC82      54001
    RHS1      GC83      71100
    RHS1      GC84      28800
    RHS1      GC85      39600
    RHS1      GC86      39601
    RHS1      GC87      54000
    RHS1      GC88      54001
    RHS1      GC89      71100
    RHS1      GC90      28800
    RHS1      GC91      39600
    RHS1      GC92      39601
    RHS1      GC93      54000
    RHS1      GC94      54001
    RHS1      GC95      71100
    RHS1      GC96      28800
    RHS1      GC97      39600
    RHS1      GC98      39601
    RHS1      GC99      54000
    RHS1      GC100     54001
    RHS1      GC101     71100
    RHS1      GC102     28800
    RHS1      GC103     39600
    RHS1      GC104     39601
    RHS1      GC105     54000
    RHS1      GC106     54001
    RHS1      GC107     71100
    RHS1      GC108     28800
    RHS1      GC109     39600
    RHS1      GC110     39601
    RHS1      GC111     54000
    RHS1      GC112     54001
    RHS1      GC113     71100
    RHS1      GC114     28800
    RHS1      GC115     39600
    RHS1      GC116     39601
    RHS1      GC117     54000
    RHS1      GC118     54001
    RHS1      GC119     71100
    RHS1      GC120     90
    RHS1      GC121     1
    RHS1      GC122     90
    RHS1      GC123     1
    RHS1      GC124     306
    RHS1      GC125     1
    RHS1      GC126     363
    RHS1      GC127     1
    RHS1      GC128     454
    RHS1      GC129     1
    RHS1      GC130     514
    RHS1      GC131     1
    RHS1      GC132     306
    RHS1      GC133     1
    RHS1      GC134     363
    RHS1      GC135     1
    RHS1      GC136     811
    RHS1      GC137     1
    RHS1      GC138     845
    RHS1      GC139     1
    RHS1      GC140     854
    RHS1      GC141     1
    RHS1      GC142     454
    RHS1      GC143     1
    RHS1      GC144     935
    RHS1      GC145     1
    RHS1      GC146     965
    RHS1      GC147     1
    RHS1      GC148     514
    RHS1      GC149     1
    RHS1      GC150     811
    RHS1      GC151     1
    RHS1      GC152     845
    RHS1      GC153     1
    RHS1      GC154     854
    RHS1      GC155     1
    RHS1      GC156     935
    RHS1      GC157     1
    RHS1      GC158     965
    RHS1      GC159     1
    RHS1      GC160     750
    RHS1      GC161     1
    RHS1      GC162     750
    RHS1      GC163     1
    RHS1      GC164     966
    RHS1      GC165     1
    RHS1      GC166     1023
    RHS1      GC167     1
    RHS1      GC168     1114
    RHS1      GC169     1
    RHS1      GC170     1174
    RHS1      GC171     1
    RHS1      GC172     966
    RHS1      GC173     1
    RHS1      GC174     1023
    RHS1      GC175     1
    RHS1      GC176     1471
    RHS1      GC177     1
    RHS1      GC178     1505
    RHS1      GC179     1
    RHS1      GC180     1514
    RHS1      GC181     1
    RHS1      GC182     1114
    RHS1      GC183     1
    RHS1      GC184     1595
    RHS1      GC185     1
    RHS1      GC186     1625
    RHS1      GC187     1
    RHS1      GC188     1174
    RHS1      GC189     1
    RHS1      GC190     1471
    RHS1      GC191     1
    RHS1      GC192     1505
    RHS1      GC193     1
    RHS1      GC194     1514
    RHS1      GC195     1
    RHS1      GC196     1595
    RHS1      GC197     1
    RHS1      GC198     1625
    RHS1      GC199     1
    RHS1      GC200     0
    RHS1      GC201     0
    RHS1      GC202     0
    RHS1      GC203     0
    RHS1      GC204     0
    RHS1      GC205     0
    RHS1      GC206     0
    RHS1      GC207     0
    RHS1      GC208     0
    RHS1      GC209     0
    RHS1      GC210     60
    RHS1      GC211     60
    RHS1      GC212     60
    RHS1      GC213     306
    RHS1      GC214     1
    RHS1      GC215     363
    RHS1      GC216     1
    RHS1      GC217     811
    RHS1      GC218     1
    RHS1      GC219     90
    RHS1      GC220     1
    RHS1      GC221     454
    RHS1      GC222     1
    RHS1      GC223     90
    RHS1      GC224     1
    RHS1      GC225     306
    RHS1      GC226     1
    RHS1      GC227     363
    RHS1      GC228     1
    RHS1      GC229     845
    RHS1      GC230     1
    RHS1      GC231     514
    RHS1      GC232     1
    RHS1      GC233     966
    RHS1      GC234     1
    RHS1      GC235     1023
    RHS1      GC236     1
    RHS1      GC237     1471
    RHS1      GC238     1
    RHS1      GC239     1514
    RHS1      GC240     1
    RHS1      GC241     750
    RHS1      GC242     1
    RHS1      GC243     1023
    RHS1      GC244     1
    RHS1      GC245     1505
    RHS1      GC246     1
    RHS1      GC247     750
    RHS1      GC248     1
    RHS1      GC249     966
    RHS1      GC250     1
    RHS1      GC251     1114
    RHS1      GC252     1
    RHS1      GC253     1174
    RHS1      GC254     1
    RHS1      GC255     1595
    RHS1      GC256     1
    RHS1      GC257     1174
    RHS1      GC258     1
    RHS1      GC259     1514
    RHS1      GC260     1
    RHS1      GC261     1625
    RHS1      GC262     1
    RHS1      GC263     0
    RHS1      GC264     0
    RHS1      GC265     0
    RHS1      GC266     0
    RHS1      GC267     0
    RHS1      GC268     0
    RHS1      GC269     0
    RHS1      GC270     0
    RHS1      GC271     60
    RHS1      GC272     60
    RHS1      GC273     60
    RHS1      GC274     454
    RHS1      GC275     1
    RHS1      GC276     363
    RHS1      GC277     1
    RHS1      GC278     514
    RHS1      GC279     1
    RHS1      GC280     845
    RHS1      GC281     1
    RHS1      GC282     90
    RHS1      GC283     1
    RHS1      GC284     454
    RHS1      GC285     1
    RHS1      GC286     90
    RHS1      GC287     1
    RHS1      GC288     306
    RHS1      GC289     1
    RHS1      GC290     306
    RHS1      GC291     1
    RHS1      GC292     363
    RHS1      GC293     1
    RHS1      GC294     935
    RHS1      GC295     1
    RHS1      GC296     854
    RHS1      GC297     1
    RHS1      GC298     1114
    RHS1      GC299     1
    RHS1      GC300     750
    RHS1      GC301     1
    RHS1      GC302     1023
    RHS1      GC303     1
    RHS1      GC304     1174
    RHS1      GC305     1
    RHS1      GC306     1514
    RHS1      GC307     1
    RHS1      GC308     1505
    RHS1      GC309     1
    RHS1      GC310     1595
    RHS1      GC311     1
    RHS1      GC312     1514
    RHS1      GC313     1
    RHS1      GC314     1114
    RHS1      GC315     1
    RHS1      GC316     1595
    RHS1      GC317     1
    RHS1      GC318     1023
    RHS1      GC319     1
    RHS1      GC320     1505
    RHS1      GC321     1
    RHS1      GC322     750
    RHS1      GC323     1
    RHS1      GC324     966
    RHS1      GC325     1
    RHS1      GC326     1174
    RHS1      GC327     1
    RHS1      GC328     1625
    RHS1      GC329     1
    RHS1      GC330     0
    RHS1      GC331     0
    RHS1      GC332     0
    RHS1      GC333     0
    RHS1      GC334     0
    RHS1      GC335     0
    RHS1      GC336     0
    RHS1      GC337     0
    RHS1      GC338     60
    RHS1      GC339     60
    RHS1      GC340     60
    RHS1      GC341     90
    RHS1      GC342     1
    RHS1      GC343     363
    RHS1      GC344     1
    RHS1      GC345     454
    RHS1      GC346     1
    RHS1      GC347     854
    RHS1      GC348     1
    RHS1      GC349     514
    RHS1      GC350     1
    RHS1      GC351     90
    RHS1      GC352     1
    RHS1      GC353     306
    RHS1      GC354     1
    RHS1      GC355     306
    RHS1      GC356     1
    RHS1      GC357     363
    RHS1      GC358     1
    RHS1      GC359     845
    RHS1      GC360     1
    RHS1      GC361     935
    RHS1      GC362     1
    RHS1      GC363     750
    RHS1      GC364     1
    RHS1      GC365     1174
    RHS1      GC366     1
    RHS1      GC367     1514
    RHS1      GC368     1
    RHS1      GC369     1023
    RHS1      GC370     1
    RHS1      GC371     1505
    RHS1      GC372     1
    RHS1      GC373     750
    RHS1      GC374     1
    RHS1      GC375     966
    RHS1      GC376     1
    RHS1      GC377     1114
    RHS1      GC378     1
    RHS1      GC379     1174
    RHS1      GC380     1
    RHS1      GC381     1595
    RHS1      GC382     1
    RHS1      GC383     1514
    RHS1      GC384     1
    RHS1      GC385     1625
    RHS1      GC386     1
    RHS1      GC387     0
    RHS1      GC388     0
    RHS1      GC389     0
    RHS1      GC390     0
    RHS1      GC391     0
    RHS1      GC392     0
    RHS1      GC393     0
    RHS1      GC394     60
    RHS1      GC395     60
    RHS1      GC396     60
    RHS1      GC397     90
    RHS1      GC398     1
    RHS1      GC399     90
    RHS1      GC400     1
    RHS1      GC401     306
    RHS1      GC402     1
    RHS1      GC403     363
    RHS1      GC404     1
    RHS1      GC405     454
    RHS1      GC406     1
    RHS1      GC407     514
    RHS1      GC408     1
    RHS1      GC409     306
    RHS1      GC410     1
    RHS1      GC411     363
    RHS1      GC412     1
    RHS1      GC413     811
    RHS1      GC414     1
    RHS1      GC415     845
    RHS1      GC416     1
    RHS1      GC417     854
    RHS1      GC418     1
    RHS1      GC419     454
    RHS1      GC420     1
    RHS1      GC421     935
    RHS1      GC422     1
    RHS1      GC423     965
    RHS1      GC424     1
    RHS1      GC425     514
    RHS1      GC426     1
    RHS1      GC427     811
    RHS1      GC428     1
    RHS1      GC429     845
    RHS1      GC430     1
    RHS1      GC431     854
    RHS1      GC432     1
    RHS1      GC433     935
    RHS1      GC434     1
    RHS1      GC435     965
    RHS1      GC436     1
    RHS1      GC437     750
    RHS1      GC438     1
    RHS1      GC439     750
    RHS1      GC440     1
    RHS1      GC441     966
    RHS1      GC442     1
    RHS1      GC443     1023
    RHS1      GC444     1
    RHS1      GC445     1114
    RHS1      GC446     1
    RHS1      GC447     1174
    RHS1      GC448     1
    RHS1      GC449     966
    RHS1      GC450     1
    RHS1      GC451     1023
    RHS1      GC452     1
    RHS1      GC453     1471
    RHS1      GC454     1
    RHS1      GC455     1505
    RHS1      GC456     1
    RHS1      GC457     1514
    RHS1      GC458     1
    RHS1      GC459     1114
    RHS1      GC460     1
    RHS1      GC461     1595
    RHS1      GC462     1
    RHS1      GC463     1625
    RHS1      GC464     1
    RHS1      GC465     1174
    RHS1      GC466     1
    RHS1      GC467     1471
    RHS1      GC468     1
    RHS1      GC469     1505
    RHS1      GC470     1
    RHS1      GC471     1514
    RHS1      GC472     1
    RHS1      GC473     1595
    RHS1      GC474     1
    RHS1      GC475     1625
    RHS1      GC476     1
    RHS1      GC477     0
    RHS1      GC478     0
    RHS1      GC479     0
    RHS1      GC480     0
    RHS1      GC481     0
    RHS1      GC482     0
    RHS1      GC483     0
    RHS1      GC484     0
    RHS1      GC485     0
    RHS1      GC486     0
    RHS1      GC487     60
    RHS1      GC488     60
    RHS1      GC489     60
    RHS1      GC490     363
    RHS1      GC491     1
    RHS1      GC492     306
    RHS1      GC493     1
    RHS1      GC494     454
    RHS1      GC495     1
    RHS1      GC496     514
    RHS1      GC497     1
    RHS1      GC498     811
    RHS1      GC499     1
    RHS1      GC500     363
    RHS1      GC501     1
    RHS1      GC502     965
    RHS1      GC503     1
    RHS1      GC504     90
    RHS1      GC505     1
    RHS1      GC506     845
    RHS1      GC507     1
    RHS1      GC508     90
    RHS1      GC509     1
    RHS1      GC510     306
    RHS1      GC511     1
    RHS1      GC512     935
    RHS1      GC513     1
    RHS1      GC514     854
    RHS1      GC515     1
    RHS1      GC516     1023
    RHS1      GC517     1
    RHS1      GC518     750
    RHS1      GC519     1
    RHS1      GC520     966
    RHS1      GC521     1
    RHS1      GC522     1114
    RHS1      GC523     1
    RHS1      GC524     1174
    RHS1      GC525     1
    RHS1      GC526     1471
    RHS1      GC527     1
    RHS1      GC528     1514
    RHS1      GC529     1
    RHS1      GC530     1505
    RHS1      GC531     1
    RHS1      GC532     1023
    RHS1      GC533     1
    RHS1      GC534     1595
    RHS1      GC535     1
    RHS1      GC536     1625
    RHS1      GC537     1
    RHS1      GC538     1514
    RHS1      GC539     1
    RHS1      GC540     1595
    RHS1      GC541     1
    RHS1      GC542     1505
    RHS1      GC543     1
    RHS1      GC544     750
    RHS1      GC545     1
    RHS1      GC546     966
    RHS1      GC547     1
    RHS1      GC548     1114
    RHS1      GC549     1
    RHS1      GC550     1174
    RHS1      GC551     1
    RHS1      GC552     1625
    RHS1      GC553     1
    RHS1      GC554     0
    RHS1      GC555     0
    RHS1      GC556     0
    RHS1      GC557     0
    RHS1      GC558     0
    RHS1      GC559     0
    RHS1      GC560     0
    RHS1      GC561     0
    RHS1      GC562     0
    RHS1      GC563     0
    RHS1      GC564     60
    RHS1      GC565     60
    RHS1      GC566     60
    RHS1      GC567     845
    RHS1      GC568     1
    RHS1      GC569     363
    RHS1      GC570     1
    RHS1      GC571     935
    RHS1      GC572     1
    RHS1      GC573     454
    RHS1      GC574     1
    RHS1      GC575     90
    RHS1      GC576     1
    RHS1      GC577     306
    RHS1      GC578     1
    RHS1      GC579     90
    RHS1      GC580     1
    RHS1      GC581     306
    RHS1      GC582     1
    RHS1      GC583     363
    RHS1      GC584     1
    RHS1      GC585     514
    RHS1      GC586     1
    RHS1      GC587     1505
    RHS1      GC588     1
    RHS1      GC589     750
    RHS1      GC590     1
    RHS1      GC591     1514
    RHS1      GC592     1
    RHS1      GC593     1114
    RHS1      GC594     1
    RHS1      GC595     1174
    RHS1      GC596     1
    RHS1      GC597     1595
    RHS1      GC598     1
    RHS1      GC599     1023
    RHS1      GC600     1
    RHS1      GC601     1505
    RHS1      GC602     1
    RHS1      GC603     750
    RHS1      GC604     1
    RHS1      GC605     966
    RHS1      GC606     1
    RHS1      GC607     1114
    RHS1      GC608     1
    RHS1      GC609     1174
    RHS1      GC610     1
    RHS1      GC611     1595
    RHS1      GC612     1
    RHS1      GC613     1514
    RHS1      GC614     1
    RHS1      GC615     1625
    RHS1      GC616     1
    RHS1      GC617     0
    RHS1      GC618     0
    RHS1      GC619     0
    RHS1      GC620     0
    RHS1      GC621     0
    RHS1      GC622     0
    RHS1      GC623     0
    RHS1      GC624     0
    RHS1      GC625     60
    RHS1      GC626     60
    RHS1      GC627     60
    RHS1      GC628     514
    RHS1      GC629     1
    RHS1      GC630     90
    RHS1      GC631     1
    RHS1      GC632     363
    RHS1      GC633     1
    RHS1      GC634     454
    RHS1      GC635     1
    RHS1      GC636     854
    RHS1      GC637     1
    RHS1      GC638     514
    RHS1      GC639     1
    RHS1      GC640     90
    RHS1      GC641     1
    RHS1      GC642     306
    RHS1      GC643     1
    RHS1      GC644     306
    RHS1      GC645     1
    RHS1      GC646     363
    RHS1      GC647     1
    RHS1      GC648     845
    RHS1      GC649     1
    RHS1      GC650     935
    RHS1      GC651     1
    RHS1      GC652     1174
    RHS1      GC653     1
    RHS1      GC654     750
    RHS1      GC655     1
    RHS1      GC656     1023
    RHS1      GC657     1
    RHS1      GC658     1114
    RHS1      GC659     1
    RHS1      GC660     1514
    RHS1      GC661     1
    RHS1      GC662     1514
    RHS1      GC663     1
    RHS1      GC664     1174
    RHS1      GC665     1
    RHS1      GC666     1023
    RHS1      GC667     1
    RHS1      GC668     1505
    RHS1      GC669     1
    RHS1      GC670     750
    RHS1      GC671     1
    RHS1      GC672     966
    RHS1      GC673     1
    RHS1      GC674     1114
    RHS1      GC675     1
    RHS1      GC676     1595
    RHS1      GC677     1
    RHS1      GC678     1625
    RHS1      GC679     1
    RHS1      GC680     0
    RHS1      GC681     0
    RHS1      GC682     0
    RHS1      GC683     0
    RHS1      GC684     0
    RHS1      GC685     0
    RHS1      GC686     0
    RHS1      GC687     60
    RHS1      GC688     60
    RHS1      GC689     60
    RHS1      GC690     175
    RHS1      GC691     1
    RHS1      GC692     269
    RHS1      GC693     1
    RHS1      GC694     309
    RHS1      GC695     1
    RHS1      GC696     175
    RHS1      GC697     1
    RHS1      GC698     392
    RHS1      GC699     1
    RHS1      GC700     269
    RHS1      GC701     1
    RHS1      GC702     309
    RHS1      GC703     1
    RHS1      GC704     722
    RHS1      GC705     1
    RHS1      GC706     741
    RHS1      GC707     1
    RHS1      GC708     392
    RHS1      GC709     1
    RHS1      GC710     931
    RHS1      GC711     1
    RHS1      GC712     953
    RHS1      GC713     1
    RHS1      GC714     722
    RHS1      GC715     1
    RHS1      GC716     741
    RHS1      GC717     1
    RHS1      GC718     931
    RHS1      GC719     1
    RHS1      GC720     953
    RHS1      GC721     1
    RHS1      GC722     835
    RHS1      GC723     1
    RHS1      GC724     929
    RHS1      GC725     1
    RHS1      GC726     969
    RHS1      GC727     1
    RHS1      GC728     835
    RHS1      GC729     1
    RHS1      GC730     1052
    RHS1      GC731     1
    RHS1      GC732     929
    RHS1      GC733     1
    RHS1      GC734     969
    RHS1      GC735     1
    RHS1      GC736     1382
    RHS1      GC737     1
    RHS1      GC738     1401
    RHS1      GC739     1
    RHS1      GC740     1052
    RHS1      GC741     1
    RHS1      GC742     1591
    RHS1      GC743     1
    RHS1      GC744     1613
    RHS1      GC745     1
    RHS1      GC746     1382
    RHS1      GC747     1
    RHS1      GC748     1401
    RHS1      GC749     1
    RHS1      GC750     1591
    RHS1      GC751     1
    RHS1      GC752     1613
    RHS1      GC753     1
    RHS1      GC754     0
    RHS1      GC755     0
    RHS1      GC756     0
    RHS1      GC757     0
    RHS1      GC758     0
    RHS1      GC759     0
    RHS1      GC760     0
    RHS1      GC761     0
    RHS1      GC762     60
    RHS1      GC763     60
    RHS1      GC764     60
    RHS1      GC765     269
    RHS1      GC766     1
    RHS1      GC767     309
    RHS1      GC768     1
    RHS1      GC769     392
    RHS1      GC770     1
    RHS1      GC771     269
    RHS1      GC772     1
    RHS1      GC773     175
    RHS1      GC774     1
    RHS1      GC775     931
    RHS1      GC776     1
    RHS1      GC777     953
    RHS1      GC778     1
    RHS1      GC779     175
    RHS1      GC780     1
    RHS1      GC781     392
    RHS1      GC782     1
    RHS1      GC783     722
    RHS1      GC784     1
    RHS1      GC785     741
    RHS1      GC786     1
    RHS1      GC787     929
    RHS1      GC788     1
    RHS1      GC789     969
    RHS1      GC790     1
    RHS1      GC791     835
    RHS1      GC792     1
    RHS1      GC793     1052
    RHS1      GC794     1
    RHS1      GC795     929
    RHS1      GC796     1
    RHS1      GC797     1382
    RHS1      GC798     1
    RHS1      GC799     1401
    RHS1      GC800     1
    RHS1      GC801     1591
    RHS1      GC802     1
    RHS1      GC803     1382
    RHS1      GC804     1
    RHS1      GC805     1613
    RHS1      GC806     1
    RHS1      GC807     1401
    RHS1      GC808     1
    RHS1      GC809     835
    RHS1      GC810     1
    RHS1      GC811     969
    RHS1      GC812     1
    RHS1      GC813     1052
    RHS1      GC814     1
    RHS1      GC815     1613
    RHS1      GC816     1
    RHS1      GC817     1591
    RHS1      GC818     1
    RHS1      GC819     0
    RHS1      GC820     0
    RHS1      GC821     0
    RHS1      GC822     0
    RHS1      GC823     0
    RHS1      GC824     0
    RHS1      GC825     0
    RHS1      GC826     0
    RHS1      GC827     60
    RHS1      GC828     60
    RHS1      GC829     60
    RHS1      GC830     175
    RHS1      GC831     1
    RHS1      GC832     741
    RHS1      GC833     1
    RHS1      GC834     269
    RHS1      GC835     1
    RHS1      GC836     931
    RHS1      GC837     1
    RHS1      GC838     269
    RHS1      GC839     1
    RHS1      GC840     309
    RHS1      GC841     1
    RHS1      GC842     175
    RHS1      GC843     1
    RHS1      GC844     392
    RHS1      GC845     1
    RHS1      GC846     392
    RHS1      GC847     1
    RHS1      GC848     953
    RHS1      GC849     1
    RHS1      GC850     722
    RHS1      GC851     1
    RHS1      GC852     835
    RHS1      GC853     1
    RHS1      GC854     969
    RHS1      GC855     1
    RHS1      GC856     1401
    RHS1      GC857     1
    RHS1      GC858     1591
    RHS1      GC859     1
    RHS1      GC860     1613
    RHS1      GC861     1
    RHS1      GC862     929
    RHS1      GC863     1
    RHS1      GC864     835
    RHS1      GC865     1
    RHS1      GC866     969
    RHS1      GC867     1
    RHS1      GC868     1052
    RHS1      GC869     1
    RHS1      GC870     929
    RHS1      GC871     1
    RHS1      GC872     1401
    RHS1      GC873     1
    RHS1      GC874     1613
    RHS1      GC875     1
    RHS1      GC876     1591
    RHS1      GC877     1
    RHS1      GC878     1382
    RHS1      GC879     1
    RHS1      GC880     0
    RHS1      GC881     0
    RHS1      GC882     0
    RHS1      GC883     0
    RHS1      GC884     0
    RHS1      GC885     0
    RHS1      GC886     0
    RHS1      GC887     0
    RHS1      GC888     60
    RHS1      GC889     60
    RHS1      GC890     60
    RHS1      GC891     309
    RHS1      GC892     1
    RHS1      GC893     269
    RHS1      GC894     1
    RHS1      GC895     309
    RHS1      GC896     1
    RHS1      GC897     931
    RHS1      GC898     1
    RHS1      GC899     953
    RHS1      GC900     1
    RHS1      GC901     269
    RHS1      GC902     1
    RHS1      GC903     175
    RHS1      GC904     1
    RHS1      GC905     175
    RHS1      GC906     1
    RHS1      GC907     392
    RHS1      GC908     1
    RHS1      GC909     392
    RHS1      GC910     1
    RHS1      GC911     722
    RHS1      GC912     1
    RHS1      GC913     741
    RHS1      GC914     1
    RHS1      GC915     969
    RHS1      GC916     1
    RHS1      GC917     929
    RHS1      GC918     1
    RHS1      GC919     969
    RHS1      GC920     1
    RHS1      GC921     1613
    RHS1      GC922     1
    RHS1      GC923     1591
    RHS1      GC924     1
    RHS1      GC925     1613
    RHS1      GC926     1
    RHS1      GC927     929
    RHS1      GC928     1
    RHS1      GC929     835
    RHS1      GC930     1
    RHS1      GC931     835
    RHS1      GC932     1
    RHS1      GC933     1052
    RHS1      GC934     1
    RHS1      GC935     1401
    RHS1      GC936     1
    RHS1      GC937     1591
    RHS1      GC938     1
    RHS1      GC939     1382
    RHS1      GC940     1
    RHS1      GC941     0
    RHS1      GC942     0
    RHS1      GC943     0
    RHS1      GC944     0
    RHS1      GC945     0
    RHS1      GC946     0
    RHS1      GC947     0
    RHS1      GC948     0
    RHS1      GC949     60
    RHS1      GC950     60
    RHS1      GC951     60
    RHS1      GC952     175
    RHS1      GC953     1
    RHS1      GC954     269
    RHS1      GC955     1
    RHS1      GC956     309
    RHS1      GC957     1
    RHS1      GC958     175
    RHS1      GC959     1
    RHS1      GC960     392
    RHS1      GC961     1
    RHS1      GC962     269
    RHS1      GC963     1
    RHS1      GC964     309
    RHS1      GC965     1
    RHS1      GC966     722
    RHS1      GC967     1
    RHS1      GC968     741
    RHS1      GC969     1
    RHS1      GC970     392
    RHS1      GC971     1
    RHS1      GC972     931
    RHS1      GC973     1
    RHS1      GC974     953
    RHS1      GC975     1
    RHS1      GC976     722
    RHS1      GC977     1
    RHS1      GC978     741
    RHS1      GC979     1
    RHS1      GC980     931
    RHS1      GC981     1
    RHS1      GC982     953
    RHS1      GC983     1
    RHS1      GC984     835
    RHS1      GC985     1
    RHS1      GC986     929
    RHS1      GC987     1
    RHS1      GC988     969
    RHS1      GC989     1
    RHS1      GC990     835
    RHS1      GC991     1
    RHS1      GC992     1052
    RHS1      GC993     1
    RHS1      GC994     929
    RHS1      GC995     1
    RHS1      GC996     969
    RHS1      GC997     1
    RHS1      GC998     1382
    RHS1      GC999     1
    RHS1      GC1000    1401
    RHS1      GC1001    1
    RHS1      GC1002    1052
    RHS1      GC1003    1
    RHS1      GC1004    1591
    RHS1      GC1005    1
    RHS1      GC1006    1613
    RHS1      GC1007    1
    RHS1      GC1008    1382
    RHS1      GC1009    1
    RHS1      GC1010    1401
    RHS1      GC1011    1
    RHS1      GC1012    1591
    RHS1      GC1013    1
    RHS1      GC1014    1613
    RHS1      GC1015    1
    RHS1      GC1016    0
    RHS1      GC1017    0
    RHS1      GC1018    0
    RHS1      GC1019    0
    RHS1      GC1020    0
    RHS1      GC1021    0
    RHS1      GC1022    0
    RHS1      GC1023    0
    RHS1      GC1024    60
    RHS1      GC1025    60
    RHS1      GC1026    60
    RHS1      GC1027    392
    RHS1      GC1028    1
    RHS1      GC1029    269
    RHS1      GC1030    1
    RHS1      GC1031    722
    RHS1      GC1032    1
    RHS1      GC1033    269
    RHS1      GC1034    1
    RHS1      GC1035    175
    RHS1      GC1036    1
    RHS1      GC1037    309
    RHS1      GC1038    1
    RHS1      GC1039    175
    RHS1      GC1040    1
    RHS1      GC1041    392
    RHS1      GC1042    1
    RHS1      GC1043    953
    RHS1      GC1044    1
    RHS1      GC1045    741
    RHS1      GC1046    1
    RHS1      GC1047    1052
    RHS1      GC1048    1
    RHS1      GC1049    835
    RHS1      GC1050    1
    RHS1      GC1051    969
    RHS1      GC1052    1
    RHS1      GC1053    1401
    RHS1      GC1054    1
    RHS1      GC1055    929
    RHS1      GC1056    1
    RHS1      GC1057    1382
    RHS1      GC1058    1
    RHS1      GC1059    1591
    RHS1      GC1060    1
    RHS1      GC1061    1613
    RHS1      GC1062    1
    RHS1      GC1063    929
    RHS1      GC1064    1
    RHS1      GC1065    835
    RHS1      GC1066    1
    RHS1      GC1067    969
    RHS1      GC1068    1
    RHS1      GC1069    1052
    RHS1      GC1070    1
    RHS1      GC1071    1401
    RHS1      GC1072    1
    RHS1      GC1073    1613
    RHS1      GC1074    1
    RHS1      GC1075    1591
    RHS1      GC1076    1
    RHS1      GC1077    1382
    RHS1      GC1078    1
    RHS1      GC1079    0
    RHS1      GC1080    0
    RHS1      GC1081    0
    RHS1      GC1082    0
    RHS1      GC1083    0
    RHS1      GC1084    0
    RHS1      GC1085    0
    RHS1      GC1086    0
    RHS1      GC1087    60
    RHS1      GC1088    60
    RHS1      GC1089    60
    RHS1      GC1090    931
    RHS1      GC1091    1
    RHS1      GC1092    175
    RHS1      GC1093    1
    RHS1      GC1094    269
    RHS1      GC1095    1
    RHS1      GC1096    309
    RHS1      GC1097    1
    RHS1      GC1098    741
    RHS1      GC1099    1
    RHS1      GC1100    953
    RHS1      GC1101    1
    RHS1      GC1102    931
    RHS1      GC1103    1
    RHS1      GC1104    269
    RHS1      GC1105    1
    RHS1      GC1106    175
    RHS1      GC1107    1
    RHS1      GC1108    392
    RHS1      GC1109    1
    RHS1      GC1110    392
    RHS1      GC1111    1
    RHS1      GC1112    722
    RHS1      GC1113    1
    RHS1      GC1114    1591
    RHS1      GC1115    1
    RHS1      GC1116    835
    RHS1      GC1117    1
    RHS1      GC1118    929
    RHS1      GC1119    1
    RHS1      GC1120    969
    RHS1      GC1121    1
    RHS1      GC1122    1613
    RHS1      GC1123    1
    RHS1      GC1124    1401
    RHS1      GC1125    1
    RHS1      GC1126    1401
    RHS1      GC1127    1
    RHS1      GC1128    1591
    RHS1      GC1129    1
    RHS1      GC1130    929
    RHS1      GC1131    1
    RHS1      GC1132    835
    RHS1      GC1133    1
    RHS1      GC1134    969
    RHS1      GC1135    1
    RHS1      GC1136    1052
    RHS1      GC1137    1
    RHS1      GC1138    1613
    RHS1      GC1139    1
    RHS1      GC1140    1382
    RHS1      GC1141    1
    RHS1      GC1142    0
    RHS1      GC1143    0
    RHS1      GC1144    0
    RHS1      GC1145    0
    RHS1      GC1146    0
    RHS1      GC1147    0
    RHS1      GC1148    0
    RHS1      GC1149    0
    RHS1      GC1150    60
    RHS1      GC1151    60
    RHS1      GC1152    60
    RHS1      GC1153    953
    RHS1      GC1154    1
    RHS1      GC1155    269
    RHS1      GC1156    1
    RHS1      GC1157    309
    RHS1      GC1158    1
    RHS1      GC1159    931
    RHS1      GC1160    1
    RHS1      GC1161    309
    RHS1      GC1162    1
    RHS1      GC1163    953
    RHS1      GC1164    1
    RHS1      GC1165    269
    RHS1      GC1166    1
    RHS1      GC1167    175
    RHS1      GC1168    1
    RHS1      GC1169    175
    RHS1      GC1170    1
    RHS1      GC1171    392
    RHS1      GC1172    1
    RHS1      GC1173    392
    RHS1      GC1174    1
    RHS1      GC1175    722
    RHS1      GC1176    1
    RHS1      GC1177    741
    RHS1      GC1178    1
    RHS1      GC1179    1613
    RHS1      GC1180    1
    RHS1      GC1181    929
    RHS1      GC1182    1
    RHS1      GC1183    969
    RHS1      GC1184    1
    RHS1      GC1185    1591
    RHS1      GC1186    1
    RHS1      GC1187    1613
    RHS1      GC1188    1
    RHS1      GC1189    929
    RHS1      GC1190    1
    RHS1      GC1191    835
    RHS1      GC1192    1
    RHS1      GC1193    835
    RHS1      GC1194    1
    RHS1      GC1195    969
    RHS1      GC1196    1
    RHS1      GC1197    1052
    RHS1      GC1198    1
    RHS1      GC1199    1401
    RHS1      GC1200    1
    RHS1      GC1201    1591
    RHS1      GC1202    1
    RHS1      GC1203    1382
    RHS1      GC1204    1
    RHS1      GC1205    0
    RHS1      GC1206    0
    RHS1      GC1207    0
    RHS1      GC1208    0
    RHS1      GC1209    0
    RHS1      GC1210    0
    RHS1      GC1211    0
    RHS1      GC1212    0
    RHS1      GC1213    60
    RHS1      GC1214    60
    RHS1      GC1215    60
    RHS1      GC1216    255
    RHS1      GC1217    1
    RHS1      GC1218    255
    RHS1      GC1219    1
    RHS1      GC1220    1149
    RHS1      GC1221    1
    RHS1      GC1222    1149
    RHS1      GC1223    1
    RHS1      GC1224    915
    RHS1      GC1225    1
    RHS1      GC1226    915
    RHS1      GC1227    1
    RHS1      GC1228    1809
    RHS1      GC1229    1
    RHS1      GC1230    1809
    RHS1      GC1231    1
    RHS1      GC1232    0
    RHS1      GC1233    0
    RHS1      GC1234    60
    RHS1      GC1235    60
    RHS1      GC1236    255
    RHS1      GC1237    1
    RHS1      GC1238    255
    RHS1      GC1239    1
    RHS1      GC1240    1149
    RHS1      GC1241    1
    RHS1      GC1242    1149
    RHS1      GC1243    1
    RHS1      GC1244    915
    RHS1      GC1245    1
    RHS1      GC1246    915
    RHS1      GC1247    1
    RHS1      GC1248    1809
    RHS1      GC1249    1
    RHS1      GC1250    1809
    RHS1      GC1251    1
    RHS1      GC1252    0
    RHS1      GC1253    0
    RHS1      GC1254    60
    RHS1      GC1255    60
    RHS1      GC1256    255
    RHS1      GC1257    1
    RHS1      GC1258    255
    RHS1      GC1259    1
    RHS1      GC1260    1149
    RHS1      GC1261    1
    RHS1      GC1262    1149
    RHS1      GC1263    1
    RHS1      GC1264    915
    RHS1      GC1265    1
    RHS1      GC1266    915
    RHS1      GC1267    1
    RHS1      GC1268    1809
    RHS1      GC1269    1
    RHS1      GC1270    1809
    RHS1      GC1271    1
    RHS1      GC1272    0
    RHS1      GC1273    0
    RHS1      GC1274    60
    RHS1      GC1275    60
    RHS1      GC1276    1149
    RHS1      GC1277    1
    RHS1      GC1278    255
    RHS1      GC1279    1
    RHS1      GC1280    1149
    RHS1      GC1281    1
    RHS1      GC1282    255
    RHS1      GC1283    1
    RHS1      GC1284    1809
    RHS1      GC1285    1
    RHS1      GC1286    915
    RHS1      GC1287    1
    RHS1      GC1288    1809
    RHS1      GC1289    1
    RHS1      GC1290    915
    RHS1      GC1291    1
    RHS1      GC1292    0
    RHS1      GC1293    0
    RHS1      GC1294    60
    RHS1      GC1295    60
    RHS1      GC1296    600
    RHS1      GC1297    1
    RHS1      GC1298    600
    RHS1      GC1299    1
    RHS1      GC1300    600
    RHS1      GC1301    1
    RHS1      GC1302    600
    RHS1      GC1303    1
    RHS1      GC1304    600
    RHS1      GC1305    1
    RHS1      GC1306    600
    RHS1      GC1307    1
    RHS1      GC1308    600
    RHS1      GC1309    1
    RHS1      GC1310    600
    RHS1      GC1311    1
    RHS1      GC1312    600
    RHS1      GC1313    1
    RHS1      GC1314    600
    RHS1      GC1315    1
    RHS1      GC1316    1018
    RHS1      GC1317    1
    RHS1      GC1318    819
    RHS1      GC1319    1
    RHS1      GC1320    1624
    RHS1      GC1321    1
    RHS1      GC1322    802
    RHS1      GC1323    1
    RHS1      GC1324    735
    RHS1      GC1325    1
    RHS1      GC1326    1132
    RHS1      GC1327    1
    RHS1      GC1328    936
    RHS1      GC1329    1
    RHS1      GC1330    1051
    RHS1      GC1331    1
    RHS1      GC1332    1132
    RHS1      GC1333    1
    RHS1      GC1334    750
    RHS1      GC1335    1
    RHS1      GC1336    1118
    RHS1      GC1337    1
    RHS1      GC1338    1325
    RHS1      GC1339    1
    RHS1      GC1340    802
    RHS1      GC1341    1
    RHS1      GC1342    1365
    RHS1      GC1343    1
    RHS1      GC1344    1018
    RHS1      GC1345    1
    RHS1      GC1346    793
    RHS1      GC1347    1
    RHS1      GC1348    1018
    RHS1      GC1349    1
    RHS1      GC1350    1460
    RHS1      GC1351    1
    RHS1      GC1352    735
    RHS1      GC1353    1
    RHS1      GC1354    660
    RHS1      GC1355    1
    RHS1      GC1356    1365
    RHS1      GC1357    1
    RHS1      GC1358    1570
    RHS1      GC1359    1
    RHS1      GC1360    1132
    RHS1      GC1361    1
    RHS1      GC1362    1325
    RHS1      GC1363    1
    RHS1      GC1364    802
    RHS1      GC1365    1
    RHS1      GC1366    1356
    RHS1      GC1367    1
    RHS1      GC1368    793
    RHS1      GC1369    1
    RHS1      GC1370    1118
    RHS1      GC1371    1
    RHS1      GC1372    1325
    RHS1      GC1373    1
    RHS1      GC1374    793
    RHS1      GC1375    1
    RHS1      GC1376    793
    RHS1      GC1377    1
    RHS1      GC1378    1261
    RHS1      GC1379    1
    RHS1      GC1380    1261
    RHS1      GC1381    1
    RHS1      GC1382    793
    RHS1      GC1383    1
    RHS1      GC1384    1513
    RHS1      GC1385    1
    RHS1      GC1386    1513
    RHS1      GC1387    1
    RHS1      GC1388    1180
    RHS1      GC1389    1
    RHS1      GC1390    1325
    RHS1      GC1391    1
    RHS1      GC1392    1513
    RHS1      GC1393    1
    RHS1      GC1394    1513
    RHS1      GC1395    1
    RHS1      GC1396    1460
    RHS1      GC1397    1
    RHS1      GC1398    1436
    RHS1      GC1399    1
    RHS1      GC1400    1460
    RHS1      GC1401    1
    RHS1      GC1402    1624
    RHS1      GC1403    1
    RHS1      GC1404    1624
    RHS1      GC1405    1
    RHS1      GC1406    1460
    RHS1      GC1407    1
    RHS1      GC1408    1624
    RHS1      GC1409    1
    RHS1      GC1410    1460
    RHS1      GC1411    1
    RHS1      GC1412    1624
    RHS1      GC1413    1
    RHS1      GC1414    1314
    RHS1      GC1415    1
    RHS1      GC1416    1365
    RHS1      GC1417    1
    RHS1      GC1418    1365
    RHS1      GC1419    1
    RHS1      GC1420    1570
    RHS1      GC1421    1
    RHS1      GC1422    1570
    RHS1      GC1423    1
    RHS1      GC1424    1570
    RHS1      GC1425    1
    RHS1      GC1426    1570
    RHS1      GC1427    1
    RHS1      GC1428    1570
    RHS1      GC1429    1
    RHS1      GC1430    1132
    RHS1      GC1431    1
    RHS1      GC1432    1365
    RHS1      GC1433    1
    RHS1      GC1434    877
    RHS1      GC1435    1
    RHS1      GC1436    1018
    RHS1      GC1437    1
    RHS1      GC1438    1018
    RHS1      GC1439    1
    RHS1      GC1440    1018
    RHS1      GC1441    1
    RHS1      GC1442    1331
    RHS1      GC1443    1
    RHS1      GC1444    1325
    RHS1      GC1445    1
    RHS1      GC1446    1486
    RHS1      GC1447    1
    RHS1      GC1448    1513
    RHS1      GC1449    1
    RHS1      GC1450    1513
    RHS1      GC1451    1
    RHS1      GC1452    1325
    RHS1      GC1453    1
    RHS1      GC1454    1594
    RHS1      GC1455    1
    RHS1      GC1456    802
    RHS1      GC1457    1
    RHS1      GC1458    802
    RHS1      GC1459    1
    RHS1      GC1460    1132
    RHS1      GC1461    1
    RHS1      GC1462    600
    RHS1      GC1463    1
    RHS1      GC1464    600
    RHS1      GC1465    1
    RHS1      GC1466    600
    RHS1      GC1467    1
    RHS1      GC1468    600
    RHS1      GC1469    1
    RHS1      GC1470    600
    RHS1      GC1471    1
    RHS1      GC1472    600
    RHS1      GC1473    1
    RHS1      GC1474    600
    RHS1      GC1475    1
    RHS1      GC1476    600
    RHS1      GC1477    1
    RHS1      GC1478    643
    RHS1      GC1479    1
    RHS1      GC1480    1178
    RHS1      GC1481    1
    RHS1      GC1482    1167
    RHS1      GC1483    1
    RHS1      GC1484    1069
    RHS1      GC1485    1
    RHS1      GC1486    1607
    RHS1      GC1487    1
    RHS1      GC1488    1607
    RHS1      GC1489    1
    RHS1      GC1490    848
    RHS1      GC1491    1
    RHS1      GC1492    1527
    RHS1      GC1493    1
    RHS1      GC1494    950
    RHS1      GC1495    1
    RHS1      GC1496    1434
    RHS1      GC1497    1
    RHS1      GC1498    1167
    RHS1      GC1499    1
    RHS1      GC1500    950
    RHS1      GC1501    1
    RHS1      GC1502    790
    RHS1      GC1503    1
    RHS1      GC1504    1027
    RHS1      GC1505    1
    RHS1      GC1506    1359
    RHS1      GC1507    1
    RHS1      GC1508    1607
    RHS1      GC1509    1
    RHS1      GC1510    1178
    RHS1      GC1511    1
    RHS1      GC1512    950
    RHS1      GC1513    1
    RHS1      GC1514    950
    RHS1      GC1515    1
    RHS1      GC1516    1069
    RHS1      GC1517    1
    RHS1      GC1518    643
    RHS1      GC1519    1
    RHS1      GC1520    724
    RHS1      GC1521    1
    RHS1      GC1522    1607
    RHS1      GC1523    1
    RHS1      GC1524    1178
    RHS1      GC1525    1
    RHS1      GC1526    1434
    RHS1      GC1527    1
    RHS1      GC1528    1178
    RHS1      GC1529    1
    RHS1      GC1530    1527
    RHS1      GC1531    1
    RHS1      GC1532    1178
    RHS1      GC1533    1
    RHS1      GC1534    1527
    RHS1      GC1535    1
    RHS1      GC1536    1580
    RHS1      GC1537    1
    RHS1      GC1538    1595
    RHS1      GC1539    1
    RHS1      GC1540    1583
    RHS1      GC1541    1
    RHS1      GC1542    1527
    RHS1      GC1543    1
    RHS1      GC1544    1527
    RHS1      GC1545    1
    RHS1      GC1546    1167
    RHS1      GC1547    1
    RHS1      GC1548    1167
    RHS1      GC1549    1
    RHS1      GC1550    1434
    RHS1      GC1551    1
    RHS1      GC1552    1359
    RHS1      GC1553    1
    RHS1      GC1554    1359
    RHS1      GC1555    1
    RHS1      GC1556    1359
    RHS1      GC1557    1
    RHS1      GC1558    1359
    RHS1      GC1559    1
    RHS1      GC1560    1359
    RHS1      GC1561    1
    RHS1      GC1562    1434
    RHS1      GC1563    1
    RHS1      GC1564    1477
    RHS1      GC1565    1
    RHS1      GC1566    1167
    RHS1      GC1567    1
    RHS1      GC1568    1607
    RHS1      GC1569    1
    RHS1      GC1570    1218
    RHS1      GC1571    1
    RHS1      GC1572    1033
    RHS1      GC1573    1
    RHS1      GC1574    950
    RHS1      GC1575    1
    RHS1      GC1576    950
    RHS1      GC1577    1
    RHS1      GC1578    1200
    RHS1      GC1579    1
    RHS1      GC1580    1258
    RHS1      GC1581    1
    RHS1      GC1582    1622
    RHS1      GC1583    1
    RHS1      GC1584    1434
    RHS1      GC1585    1
    RHS1      GC1586    600
    RHS1      GC1587    1
    RHS1      GC1588    600
    RHS1      GC1589    1
    RHS1      GC1590    1525
    RHS1      GC1591    1
    RHS1      GC1592    1525
    RHS1      GC1593    1
BOUNDS
 BV BND1      route[0]
 BV BND1      route[1]
 BV BND1      route[2]
 BV BND1      route[3]
 BV BND1      route[4]
 BV BND1      route[5]
 BV BND1      route[6]
 BV BND1      route[7]
 BV BND1      route[8]
 BV BND1      route[9]
 BV BND1      route[10]
 BV BND1      route[11]
 BV BND1      route[12]
 BV BND1      route[13]
 BV BND1      route[14]
 BV BND1      route[15]
 BV BND1      route[16]
 BV BND1      route[17]
 BV BND1      route[18]
 BV BND1      route[19]
 BV BND1      route[20]
 BV BND1      route[21]
 BV BND1      route[22]
 BV BND1      route[23]
 BV BND1      route[24]
 BV BND1      route[25]
 BV BND1      route[26]
 BV BND1      route[27]
 BV BND1      route[28]
 BV BND1      route[29]
 BV BND1      route[30]
 BV BND1      route[31]
 BV BND1      route[32]
 BV BND1      route[33]
 BV BND1      route[34]
 BV BND1      route[35]
 BV BND1      route[36]
 BV BND1      route[37]
 BV BND1      route[38]
 BV BND1      route[39]
 BV BND1      route[40]
 BV BND1      route[41]
 BV BND1      route[42]
 BV BND1      route[43]
 BV BND1      route[44]
 BV BND1      route[45]
 BV BND1      route[46]
 BV BND1      route[47]
 BV BND1      route[48]
 BV BND1      route[49]
 BV BND1      route[50]
 BV BND1      route[51]
 BV BND1      route[52]
 BV BND1      route[53]
 BV BND1      route[54]
 BV BND1      route[55]
 BV BND1      route[56]
 BV BND1      route[57]
 BV BND1      route[58]
 BV BND1      route[59]
 BV BND1      route[60]
 BV BND1      route[61]
 BV BND1      route[62]
 BV BND1      route[63]
 BV BND1      route[64]
 BV BND1      route[65]
 BV BND1      route[66]
 BV BND1      route[67]
 BV BND1      route[68]
 BV BND1      route[69]
 BV BND1      route[70]
 BV BND1      route[71]
 BV BND1      route[72]
 BV BND1      route[73]
 BV BND1      route[74]
 BV BND1      route[75]
 BV BND1      route[76]
 BV BND1      route[77]
 BV BND1      route[78]
 BV BND1      route[79]
 BV BND1      route[80]
 BV BND1      route[81]
 BV BND1      route[82]
 BV BND1      route[83]
 BV BND1      route[84]
 BV BND1      route[85]
 BV BND1      route[86]
 BV BND1      route[87]
 BV BND1      route[88]
 BV BND1      route[89]
 BV BND1      route[90]
 BV BND1      route[91]
 BV BND1      route[92]
 BV BND1      route[93]
 BV BND1      route[94]
 BV BND1      route[95]
 BV BND1      route[96]
 BV BND1      route[97]
 BV BND1      route[98]
 BV BND1      route[99]
 BV BND1      route[100]
 BV BND1      route[101]
 BV BND1      route[102]
 BV BND1      route[103]
 BV BND1      route[104]
 BV BND1      route[105]
 BV BND1      route[106]
 BV BND1      route[107]
 BV BND1      route[108]
 BV BND1      route[109]
 BV BND1      route[110]
 BV BND1      route[111]
 BV BND1      route[112]
 BV BND1      route[113]
 BV BND1      route[114]
 BV BND1      route[115]
 BV BND1      route[116]
 BV BND1      route[117]
 BV BND1      route[118]
 BV BND1      route[119]
 BV BND1      route[120]
 BV BND1      route[121]
 BV BND1      route[122]
 BV BND1      route[123]
 BV BND1      route[124]
 BV BND1      route[125]
 BV BND1      route[126]
 BV BND1      route[127]
 BV BND1      route[128]
 BV BND1      route[129]
 BV BND1      route[130]
 BV BND1      route[131]
 BV BND1      route[132]
 BV BND1      route[133]
 BV BND1      route[134]
 BV BND1      route[135]
 BV BND1      route[136]
 BV BND1      route[137]
 BV BND1      route[138]
 BV BND1      route[139]
 BV BND1      route[140]
 BV BND1      route[141]
 BV BND1      route[142]
 BV BND1      route[143]
 BV BND1      route[144]
 BV BND1      route[145]
 BV BND1      route[146]
 BV BND1      route[147]
 UP BND1      quantity_1_S1  18
 UP BND1      quantity_2_S3  11
 UP BND1      quantity_4_S1  18
 UP BND1      quantity_5_S3  11
 UP BND1      quantity_6_S4  4
 UP BND1      quantity_7_S3  11
 UP BND1      quantity_7_S1  18
 UP BND1      quantity_8_S3  11
 UP BND1      quantity_8_S4  4
 UP BND1      quantity_10_S3  11
 UP BND1      quantity_11_S4  4
 UP BND1      quantity_12_S4  4
 UP BND1      quantity_12_S3  11
 UP BND1      quantity_14_S1  18
 UP BND1      quantity_15_S3  11
 UP BND1      quantity_16_S4  4
 UP BND1      quantity_17_S3  11
 UP BND1      quantity_17_S1  18
 UP BND1      quantity_18_S3  11
 UP BND1      quantity_18_S4  4
 UP BND1      quantity_20_S3  11
 UP BND1      quantity_21_S4  4
 UP BND1      quantity_22_S4  4
 UP BND1      quantity_22_S3  11
 UP BND1      quantity_24_S1  18
 UP BND1      quantity_25_S3  11
 UP BND1      quantity_27_S3  11
 UP BND1      quantity_28_S4  4
 UP BND1      quantity_29_S4  4
 UP BND1      quantity_29_S3  11
 UP BND1      quantity_31_S1  18
 UP BND1      quantity_32_S3  11
 UP BND1      quantity_34_S1  18
 UP BND1      quantity_35_S3  11
 UP BND1      quantity_36_S4  4
 UP BND1      quantity_37_S3  11
 UP BND1      quantity_37_S1  18
 UP BND1      quantity_38_S3  11
 UP BND1      quantity_38_S4  4
 UP BND1      quantity_40_S3  11
 UP BND1      quantity_41_S4  4
 UP BND1      quantity_42_S4  4
 UP BND1      quantity_42_S3  11
 UP BND1      quantity_44_S1  18
 UP BND1      quantity_45_S3  11
 UP BND1      quantity_46_S4  4
 UP BND1      quantity_47_S3  11
 UP BND1      quantity_47_S1  18
 UP BND1      quantity_48_S3  11
 UP BND1      quantity_48_S4  4
 UP BND1      quantity_50_S3  11
 UP BND1      quantity_51_S4  4
 UP BND1      quantity_52_S4  4
 UP BND1      quantity_52_S3  11
 UP BND1      quantity_54_S1  18
 UP BND1      quantity_55_S3  11
 UP BND1      quantity_57_S1  18
 UP BND1      quantity_58_S3  11
 UP BND1      quantity_59_S4  4
 UP BND1      quantity_60_S3  11
 UP BND1      quantity_60_S1  18
 UP BND1      quantity_61_S3  11
 UP BND1      quantity_61_S4  4
 UP BND1      quantity_63_S1  18
 UP BND1      quantity_64_S3  11
 UP BND1      quantity_66_S1  18
 UP BND1      quantity_67_S3  11
 UP BND1      quantity_69_S1  18
 UP BND1      quantity_70_S3  11
 UP BND1      quantity_71_S4  4
 UP BND1      quantity_72_S3  11
 UP BND1      quantity_72_S1  18
 UP BND1      quantity_73_S3  11
 UP BND1      quantity_73_S4  4
 UP BND1      quantity_75_S3  11
 UP BND1      quantity_76_S4  4
 UP BND1      quantity_77_S4  4
 UP BND1      quantity_77_S3  11
 UP BND1      quantity_79_S1  18
 UP BND1      quantity_80_S3  11
 UP BND1      quantity_81_S4  4
 UP BND1      quantity_82_S3  11
 UP BND1      quantity_82_S1  18
 UP BND1      quantity_83_S3  11
 UP BND1      quantity_83_S4  4
 UP BND1      quantity_85_S3  11
 UP BND1      quantity_86_S4  4
 UP BND1      quantity_87_S4  4
 UP BND1      quantity_87_S3  11
 UP BND1      quantity_89_S1  18
 UP BND1      quantity_90_S3  11
 UP BND1      quantity_92_S3  11
 UP BND1      quantity_93_S4  4
 UP BND1      quantity_94_S4  4
 UP BND1      quantity_94_S3  11
 UP BND1      quantity_96_S1  18
 UP BND1      quantity_97_S3  11
 UP BND1      quantity_99_S1  18
 UP BND1      quantity_100_S3  11
 UP BND1      quantity_101_S4  4
 UP BND1      quantity_102_S3  11
 UP BND1      quantity_102_S1  18
 UP BND1      quantity_103_S3  11
 UP BND1      quantity_103_S4  4
 UP BND1      quantity_105_S3  11
 UP BND1      quantity_106_S4  4
 UP BND1      quantity_107_S4  4
 UP BND1      quantity_107_S3  11
 UP BND1      quantity_109_S1  18
 UP BND1      quantity_110_S3  11
 UP BND1      quantity_111_S4  4
 UP BND1      quantity_112_S3  11
 UP BND1      quantity_112_S1  18
 UP BND1      quantity_113_S3  11
 UP BND1      quantity_113_S4  4
 UP BND1      quantity_115_S3  11
 UP BND1      quantity_116_S4  4
 UP BND1      quantity_117_S4  4
 UP BND1      quantity_117_S3  11
 UP BND1      quantity_119_S1  18
 UP BND1      quantity_120_S3  11
 UP BND1      quantity_122_S1  18
 UP BND1      quantity_123_S3  11
 UP BND1      quantity_124_S4  4
 UP BND1      quantity_125_S3  11
 UP BND1      quantity_125_S1  18
 UP BND1      quantity_126_S3  11
 UP BND1      quantity_126_S4  4
 UP BND1      quantity_128_S1  18
 UP BND1      quantity_129_S3  11
 UP BND1      quantity_131_S1  18
 UP BND1      quantity_132_S3  11
 UP BND1      quantity_134_S1  18
 UP BND1      quantity_135_S3  11
 UP BND1      quantity_136_S4  4
 UP BND1      quantity_137_S3  11
 UP BND1      quantity_137_S1  18
 UP BND1      quantity_138_S3  11
 UP BND1      quantity_138_S4  4
 UP BND1      quantity_140_S1  18
 UP BND1      quantity_141_S3  11
 UP BND1      quantity_142_S4  4
 UP BND1      quantity_143_S3  11
 UP BND1      quantity_143_S1  18
 UP BND1      quantity_144_S3  11
 UP BND1      quantity_144_S4  4
 UP BND1      quantity_146_S1  18
 UP BND1      quantity_147_S3  11
 UP BND1      supply_S1_b1  75600
 UP BND1      supply_S3_b1  75600
 UP BND1      supply_S4_b1  75600
 UP BND1      supply_S1_b2  75600
 UP BND1      supply_S3_b2  75600
 UP BND1      supply_S4_b2  75600
 UP BND1      supply_S1_b3  75600
 UP BND1      supply_S3_b3  75600
 LO BND1      delivery_C81_order  30840
 UP BND1      delivery_C81_order  32940
 LO BND1      pickup_time_C81_order  35640
 UP BND1      pickup_time_C81_order  40200
 LO BND1      e2_return_C81_order  28800
 UP BND1      e2_return_C81_order  71100
 BV BND1      cutoff_C81_order_b1
 BV BND1      cutoff_C81_order_b2
 BV BND1      cutoff_C81_order_b3
 LO BND1      delivery_C90_order  31860
 UP BND1      delivery_C90_order  33960
 LO BND1      pickup_time_C90_order  36660
 UP BND1      pickup_time_C90_order  41220
 LO BND1      e2_return_C90_order  28800
 UP BND1      e2_return_C90_order  71100
 BV BND1      cutoff_C90_order_b1
 BV BND1      cutoff_C90_order_b2
 BV BND1      cutoff_C90_order_b3
 LO BND1      delivery_C97_order  31320
 UP BND1      delivery_C97_order  33420
 LO BND1      pickup_time_C97_order  35520
 UP BND1      pickup_time_C97_order  40080
 LO BND1      e2_return_C97_order  28800
 UP BND1      e2_return_C97_order  71100
 BV BND1      cutoff_C97_order_b1
 BV BND1      cutoff_C97_order_b2
 BV BND1      cutoff_C97_order_b3
 LO BND1      delivery_C51_order  32100
 UP BND1      delivery_C51_order  34200
 LO BND1      pickup_time_C51_order  36300
 UP BND1      pickup_time_C51_order  40860
 LO BND1      e2_return_C51_order  28800
 UP BND1      e2_return_C51_order  71100
 BV BND1      cutoff_C51_order_b1
 BV BND1      cutoff_C51_order_b2
 BV BND1      cutoff_C51_order_b3
 LO BND1      delivery_C0_order  45360
 UP BND1      delivery_C0_order  47460
 LO BND1      pickup_time_C0_order  48960
 UP BND1      pickup_time_C0_order  53520
 LO BND1      e2_return_C0_order  28800
 UP BND1      e2_return_C0_order  71100
 BV BND1      cutoff_C0_order_b1
 BV BND1      cutoff_C0_order_b2
 BV BND1      cutoff_C0_order_b3
 LO BND1      delivery_C39_order  46860
 UP BND1      delivery_C39_order  48960
 LO BND1      pickup_time_C39_order  50460
 UP BND1      pickup_time_C39_order  55020
 LO BND1      e2_return_C39_order  28800
 UP BND1      e2_return_C39_order  71100
 BV BND1      cutoff_C39_order_b1
 BV BND1      cutoff_C39_order_b2
 BV BND1      cutoff_C39_order_b3
 LO BND1      delivery_C52_order  45840
 UP BND1      delivery_C52_order  47940
 LO BND1      pickup_time_C52_order  49440
 UP BND1      pickup_time_C52_order  54000
 LO BND1      e2_return_C52_order  28800
 UP BND1      e2_return_C52_order  71100
 BV BND1      cutoff_C52_order_b1
 BV BND1      cutoff_C52_order_b2
 BV BND1      cutoff_C52_order_b3
 LO BND1      delivery_C85_order  59400
 UP BND1      delivery_C85_order  61500
 LO BND1      pickup_time_C85_order  61800
 UP BND1      pickup_time_C85_order  66360
 LO BND1      e2_return_C85_order  28800
 UP BND1      e2_return_C85_order  71100
 BV BND1      cutoff_C85_order_b1
 BV BND1      cutoff_C85_order_b2
 BV BND1      cutoff_C85_order_b3
 LO BND1      delivery_C75_order  60540
 UP BND1      delivery_C75_order  62640
 LO BND1      pickup_time_C75_order  62940
 UP BND1      pickup_time_C75_order  67500
 LO BND1      e2_return_C75_order  28800
 UP BND1      e2_return_C75_order  71100
 BV BND1      cutoff_C75_order_b1
 BV BND1      cutoff_C75_order_b2
 BV BND1      cutoff_C75_order_b3
 LO BND1      delivery_C21_order  60180
 UP BND1      delivery_C21_order  62280
 LO BND1      pickup_time_C21_order  63180
 UP BND1      pickup_time_C21_order  67740
 LO BND1      e2_return_C21_order  28800
 UP BND1      e2_return_C21_order  71100
 BV BND1      cutoff_C21_order_b1
 BV BND1      cutoff_C21_order_b2
 BV BND1      cutoff_C21_order_b3
 LO BND1      delivery_C88_order  30960
 UP BND1      delivery_C88_order  33060
 LO BND1      pickup_time_C88_order  33660
 UP BND1      pickup_time_C88_order  38220
 LO BND1      e2_return_C88_order  28800
 UP BND1      e2_return_C88_order  71100
 BV BND1      cutoff_C88_order_b1
 BV BND1      cutoff_C88_order_b2
 BV BND1      cutoff_C88_order_b3
 LO BND1      delivery_C76_order  32160
 UP BND1      delivery_C76_order  34260
 LO BND1      pickup_time_C76_order  36960
 UP BND1      pickup_time_C76_order  41520
 LO BND1      e2_return_C76_order  28800
 UP BND1      e2_return_C76_order  71100
 BV BND1      cutoff_C76_order_b1
 BV BND1      cutoff_C76_order_b2
 BV BND1      cutoff_C76_order_b3
 LO BND1      delivery_C27_order  31440
 UP BND1      delivery_C27_order  33540
 LO BND1      pickup_time_C27_order  35040
 UP BND1      pickup_time_C27_order  39600
 LO BND1      e2_return_C27_order  28800
 UP BND1      e2_return_C27_order  71100
 BV BND1      cutoff_C27_order_b1
 BV BND1      cutoff_C27_order_b2
 BV BND1      cutoff_C27_order_b3
 LO BND1      delivery_C47_order  45300
 UP BND1      delivery_C47_order  47400
 LO BND1      pickup_time_C47_order  48300
 UP BND1      pickup_time_C47_order  52860
 LO BND1      e2_return_C47_order  28800
 UP BND1      e2_return_C47_order  71100
 BV BND1      cutoff_C47_order_b1
 BV BND1      cutoff_C47_order_b2
 BV BND1      cutoff_C47_order_b3
 LO BND1      delivery_C25_order  46440
 UP BND1      delivery_C25_order  48540
 LO BND1      pickup_time_C25_order  50040
 UP BND1      pickup_time_C25_order  54600
 LO BND1      e2_return_C25_order  28800
 UP BND1      e2_return_C25_order  71100
 BV BND1      cutoff_C25_order_b1
 BV BND1      cutoff_C25_order_b2
 BV BND1      cutoff_C25_order_b3
 LO BND1      delivery_C46_order  46020
 UP BND1      delivery_C46_order  48120
 LO BND1      pickup_time_C46_order  50220
 UP BND1      pickup_time_C46_order  54780
 LO BND1      e2_return_C46_order  28800
 UP BND1      e2_return_C46_order  71100
 BV BND1      cutoff_C46_order_b1
 BV BND1      cutoff_C46_order_b2
 BV BND1      cutoff_C46_order_b3
 LO BND1      delivery_C29_order  59820
 UP BND1      delivery_C29_order  61920
 LO BND1      pickup_time_C29_order  64020
 UP BND1      pickup_time_C29_order  68580
 LO BND1      e2_return_C29_order  28800
 UP BND1      e2_return_C29_order  71100
 BV BND1      cutoff_C29_order_b1
 BV BND1      cutoff_C29_order_b2
 BV BND1      cutoff_C29_order_b3
 LO BND1      delivery_C6_order  61440
 UP BND1      delivery_C6_order  63540
 LO BND1      pickup_time_C6_order  65640
 UP BND1      pickup_time_C6_order  69480
 LO BND1      e2_return_C6_order  28800
 UP BND1      e2_return_C6_order  71100
 BV BND1      cutoff_C6_order_b1
 BV BND1      cutoff_C6_order_b2
 BV BND1      cutoff_C6_order_b3
 LO BND1      delivery_C34_order  31800
 UP BND1      delivery_C34_order  33900
 LO BND1      pickup_time_C34_order  36000
 UP BND1      pickup_time_C34_order  40560
 LO BND1      e2_return_C34_order  28800
 UP BND1      e2_return_C34_order  71100
 BV BND1      cutoff_C34_order_b1
 BV BND1      cutoff_C34_order_b2
 BV BND1      cutoff_C34_order_b3
 LO BND1      delivery_C95_order  45300
 UP BND1      delivery_C95_order  47400
 LO BND1      pickup_time_C95_order  46800
 UP BND1      pickup_time_C95_order  51360
 LO BND1      e2_return_C95_order  28800
 UP BND1      e2_return_C95_order  71100
 BV BND1      cutoff_C95_order_b1
 BV BND1      cutoff_C95_order_b2
 BV BND1      cutoff_C95_order_b3
 UP BND1      pool_task_rank_C81_order_d  80
 UP BND1      pool_task_rank_C81_order_p  80
 UP BND1      pool_task_rank_C90_order_d  80
 UP BND1      pool_task_rank_C90_order_p  80
 UP BND1      pool_task_rank_C97_order_d  80
 UP BND1      pool_task_rank_C97_order_p  80
 UP BND1      pool_task_rank_C51_order_d  80
 UP BND1      pool_task_rank_C51_order_p  80
 UP BND1      pool_task_rank_C0_order_d  80
 UP BND1      pool_task_rank_C0_order_p  80
 UP BND1      pool_task_rank_C39_order_d  80
 UP BND1      pool_task_rank_C39_order_p  80
 UP BND1      pool_task_rank_C52_order_d  80
 UP BND1      pool_task_rank_C52_order_p  80
 UP BND1      pool_task_rank_C85_order_d  80
 UP BND1      pool_task_rank_C85_order_p  80
 UP BND1      pool_task_rank_C75_order_d  80
 UP BND1      pool_task_rank_C75_order_p  80
 UP BND1      pool_task_rank_C21_order_d  80
 UP BND1      pool_task_rank_C21_order_p  80
 UP BND1      pool_task_rank_C88_order_d  80
 UP BND1      pool_task_rank_C88_order_p  80
 UP BND1      pool_task_rank_C76_order_d  80
 UP BND1      pool_task_rank_C76_order_p  80
 UP BND1      pool_task_rank_C27_order_d  80
 UP BND1      pool_task_rank_C27_order_p  80
 UP BND1      pool_task_rank_C47_order_d  80
 UP BND1      pool_task_rank_C47_order_p  80
 UP BND1      pool_task_rank_C25_order_d  80
 UP BND1      pool_task_rank_C25_order_p  80
 UP BND1      pool_task_rank_C46_order_d  80
 UP BND1      pool_task_rank_C46_order_p  80
 UP BND1      pool_task_rank_C29_order_d  80
 UP BND1      pool_task_rank_C29_order_p  80
 UP BND1      pool_task_rank_C6_order_d  80
 UP BND1      pool_task_rank_C6_order_p  80
 UP BND1      pool_task_rank_C34_order_d  80
 UP BND1      pool_task_rank_C34_order_p  80
 UP BND1      pool_task_rank_C95_order_d  80
 UP BND1      pool_task_rank_C95_order_p  80
 BV BND1      pool_choice_0[0]
 BV BND1      pool_choice_0[1]
 BV BND1      pool_choice_0[2]
 BV BND1      pool_choice_0[3]
 BV BND1      pool_choice_0[4]
 BV BND1      pool_choice_0[5]
 BV BND1      pool_choice_0[6]
 BV BND1      pool_choice_0[7]
 BV BND1      pool_choice_0[8]
 BV BND1      pool_choice_0[9]
 BV BND1      pool_choice_0[10]
 BV BND1      pool_choice_0[11]
 BV BND1      pool_choice_0[12]
 BV BND1      pool_choice_0[13]
 BV BND1      pool_choice_0[14]
 BV BND1      pool_choice_0[15]
 BV BND1      pool_choice_0[16]
 BV BND1      pool_choice_0[17]
 BV BND1      pool_choice_0[18]
 BV BND1      pool_choice_0[19]
 BV BND1      pool_choice_0[20]
 BV BND1      pool_choice_0[21]
 BV BND1      pool_choice_0[22]
 BV BND1      pool_choice_0[23]
 BV BND1      pool_choice_0[24]
 BV BND1      pool_choice_0[25]
 BV BND1      pool_choice_0[26]
 BV BND1      pool_choice_0[27]
 BV BND1      pool_choice_0[28]
 BV BND1      pool_choice_0[29]
 BV BND1      pool_choice_0[30]
 BV BND1      pool_choice_0[31]
 BV BND1      pool_choice_0[32]
 BV BND1      pool_choice_0[33]
 BV BND1      pool_choice_0[34]
 BV BND1      pool_choice_0[35]
 BV BND1      pool_choice_0[36]
 BV BND1      pool_choice_0[37]
 BV BND1      pool_choice_0[38]
 BV BND1      pool_choice_0[39]
 BV BND1      pool_choice_0[40]
 BV BND1      pool_choice_0[41]
 BV BND1      pool_choice_0[42]
 BV BND1      pool_choice_0[43]
 BV BND1      pool_choice_0[44]
 BV BND1      pool_choice_0[45]
 BV BND1      pool_choice_0[46]
 BV BND1      pool_choice_0[47]
 BV BND1      pool_choice_0[48]
 BV BND1      pool_choice_0[49]
 BV BND1      pool_choice_0[50]
 BV BND1      pool_choice_0[51]
 BV BND1      pool_choice_0[52]
 BV BND1      pool_choice_0[53]
 BV BND1      pool_choice_0[54]
 BV BND1      pool_choice_0[55]
 BV BND1      pool_choice_0[56]
 BV BND1      pool_choice_0[57]
 BV BND1      pool_choice_0[58]
 BV BND1      pool_choice_0[59]
 BV BND1      pool_choice_0[60]
 BV BND1      pool_choice_0[61]
 BV BND1      pool_used_0
 UP BND1      pool_start_0  75600
 UP BND1      pool_end_0  75600
 UP BND1      pool_start_rank_0  80
 UP BND1      pool_end_rank_0  80
 BV BND1      pool_first_0_C85_order_d
 BV BND1      pool_first_0_C85_order_p
 BV BND1      pool_first_0_C81_order_d
 BV BND1      pool_first_0_C90_order_d
 BV BND1      pool_first_0_C0_order_d
 BV BND1      pool_first_0_C75_order_d
 BV BND1      pool_first_0_C81_order_p
 BV BND1      pool_first_0_C90_order_p
 BV BND1      pool_first_0_C97_order_d
 BV BND1      pool_first_0_C39_order_d
 BV BND1      pool_first_0_C21_order_d
 BV BND1      pool_first_0_C0_order_p
 BV BND1      pool_first_0_C52_order_d
 BV BND1      pool_first_0_C51_order_d
 BV BND1      pool_first_0_C75_order_p
 BV BND1      pool_first_0_C97_order_p
 BV BND1      pool_first_0_C39_order_p
 BV BND1      pool_first_0_C21_order_p
 BV BND1      pool_first_0_C52_order_p
 BV BND1      pool_first_0_C51_order_p
 BV BND1      pool_last_0_C85_order_p
 BV BND1      pool_last_0_C85_order_d
 BV BND1      pool_last_0_C81_order_p
 BV BND1      pool_last_0_C90_order_p
 BV BND1      pool_last_0_C0_order_p
 BV BND1      pool_last_0_C75_order_p
 BV BND1      pool_last_0_C81_order_d
 BV BND1      pool_last_0_C90_order_d
 BV BND1      pool_last_0_C97_order_p
 BV BND1      pool_last_0_C39_order_p
 BV BND1      pool_last_0_C21_order_p
 BV BND1      pool_last_0_C0_order_d
 BV BND1      pool_last_0_C52_order_p
 BV BND1      pool_last_0_C51_order_p
 BV BND1      pool_last_0_C75_order_d
 BV BND1      pool_last_0_C97_order_d
 BV BND1      pool_last_0_C39_order_d
 BV BND1      pool_last_0_C21_order_d
 BV BND1      pool_last_0_C52_order_d
 BV BND1      pool_last_0_C51_order_d
 BV BND1      pool_pickup_0_C85_order
 BV BND1      pool_pickup_0_C81_order
 BV BND1      pool_pickup_0_C90_order
 BV BND1      pool_pickup_0_C0_order
 BV BND1      pool_pickup_0_C75_order
 BV BND1      pool_pickup_0_C97_order
 BV BND1      pool_pickup_0_C39_order
 BV BND1      pool_pickup_0_C21_order
 BV BND1      pool_pickup_0_C52_order
 BV BND1      pool_pickup_0_C51_order
 BV BND1      pool_batch_0_b3
 BV BND1      pool_batch_0_b1
 BV BND1      pool_batch_0_b2
 BV BND1      pool_choice_1[0]
 BV BND1      pool_choice_1[1]
 BV BND1      pool_choice_1[2]
 BV BND1      pool_choice_1[3]
 BV BND1      pool_choice_1[4]
 BV BND1      pool_choice_1[5]
 BV BND1      pool_choice_1[6]
 BV BND1      pool_choice_1[7]
 BV BND1      pool_choice_1[8]
 BV BND1      pool_choice_1[9]
 BV BND1      pool_choice_1[10]
 BV BND1      pool_choice_1[11]
 BV BND1      pool_choice_1[12]
 BV BND1      pool_choice_1[13]
 BV BND1      pool_choice_1[14]
 BV BND1      pool_choice_1[15]
 BV BND1      pool_choice_1[16]
 BV BND1      pool_choice_1[17]
 BV BND1      pool_choice_1[18]
 BV BND1      pool_choice_1[19]
 BV BND1      pool_choice_1[20]
 BV BND1      pool_choice_1[21]
 BV BND1      pool_choice_1[22]
 BV BND1      pool_choice_1[23]
 BV BND1      pool_choice_1[24]
 BV BND1      pool_choice_1[25]
 BV BND1      pool_choice_1[26]
 BV BND1      pool_choice_1[27]
 BV BND1      pool_choice_1[28]
 BV BND1      pool_choice_1[29]
 BV BND1      pool_choice_1[30]
 BV BND1      pool_choice_1[31]
 BV BND1      pool_choice_1[32]
 BV BND1      pool_choice_1[33]
 BV BND1      pool_choice_1[34]
 BV BND1      pool_choice_1[35]
 BV BND1      pool_choice_1[36]
 BV BND1      pool_choice_1[37]
 BV BND1      pool_choice_1[38]
 BV BND1      pool_choice_1[39]
 BV BND1      pool_choice_1[40]
 BV BND1      pool_choice_1[41]
 BV BND1      pool_choice_1[42]
 BV BND1      pool_choice_1[43]
 BV BND1      pool_choice_1[44]
 BV BND1      pool_choice_1[45]
 BV BND1      pool_choice_1[46]
 BV BND1      pool_choice_1[47]
 BV BND1      pool_choice_1[48]
 BV BND1      pool_choice_1[49]
 BV BND1      pool_choice_1[50]
 BV BND1      pool_choice_1[51]
 BV BND1      pool_choice_1[52]
 BV BND1      pool_used_1
 UP BND1      pool_start_1  75600
 UP BND1      pool_end_1  75600
 UP BND1      pool_start_rank_1  80
 UP BND1      pool_end_rank_1  80
 BV BND1      pool_first_1_C81_order_d
 BV BND1      pool_first_1_C90_order_d
 BV BND1      pool_first_1_C97_order_d
 BV BND1      pool_first_1_C85_order_p
 BV BND1      pool_first_1_C0_order_d
 BV BND1      pool_first_1_C85_order_d
 BV BND1      pool_first_1_C81_order_p
 BV BND1      pool_first_1_C90_order_p
 BV BND1      pool_first_1_C39_order_d
 BV BND1      pool_first_1_C75_order_d
 BV BND1      pool_last_1_C81_order_p
 BV BND1      pool_last_1_C90_order_p
 BV BND1      pool_last_1_C97_order_p
 BV BND1      pool_last_1_C21_order_p
 BV BND1      pool_last_1_C85_order_p
 BV BND1      pool_last_1_C90_order_d
 BV BND1      pool_last_1_C39_order_d
 BV BND1      pool_last_1_C85_order_d
 BV BND1      pool_last_1_C81_order_d
 BV BND1      pool_last_1_C0_order_d
 BV BND1      pool_last_1_C75_order_d
 BV BND1      pool_last_1_C52_order_d
 BV BND1      pool_last_1_C75_order_p
 BV BND1      pool_last_1_C21_order_d
 BV BND1      pool_last_1_C51_order_d
 BV BND1      pool_pickup_1_C51_order
 BV BND1      pool_pickup_1_C97_order
 BV BND1      pool_pickup_1_C81_order
 BV BND1      pool_pickup_1_C90_order
 BV BND1      pool_pickup_1_C21_order
 BV BND1      pool_pickup_1_C85_order
 BV BND1      pool_pickup_1_C0_order
 BV BND1      pool_pickup_1_C75_order
 BV BND1      pool_batch_1_b1
 BV BND1      pool_batch_1_b2
 BV BND1      pool_batch_1_b3
 BV BND1      pool_choice_2[0]
 BV BND1      pool_choice_2[1]
 BV BND1      pool_choice_2[2]
 BV BND1      pool_choice_2[3]
 BV BND1      pool_choice_2[4]
 BV BND1      pool_choice_2[5]
 BV BND1      pool_choice_2[6]
 BV BND1      pool_choice_2[7]
 BV BND1      pool_choice_2[8]
 BV BND1      pool_choice_2[9]
 BV BND1      pool_choice_2[10]
 BV BND1      pool_choice_2[11]
 BV BND1      pool_choice_2[12]
 BV BND1      pool_choice_2[13]
 BV BND1      pool_choice_2[14]
 BV BND1      pool_choice_2[15]
 BV BND1      pool_choice_2[16]
 BV BND1      pool_choice_2[17]
 BV BND1      pool_choice_2[18]
 BV BND1      pool_choice_2[19]
 BV BND1      pool_choice_2[20]
 BV BND1      pool_choice_2[21]
 BV BND1      pool_choice_2[22]
 BV BND1      pool_choice_2[23]
 BV BND1      pool_choice_2[24]
 BV BND1      pool_choice_2[25]
 BV BND1      pool_choice_2[26]
 BV BND1      pool_choice_2[27]
 BV BND1      pool_choice_2[28]
 BV BND1      pool_choice_2[29]
 BV BND1      pool_choice_2[30]
 BV BND1      pool_choice_2[31]
 BV BND1      pool_choice_2[32]
 BV BND1      pool_choice_2[33]
 BV BND1      pool_choice_2[34]
 BV BND1      pool_choice_2[35]
 BV BND1      pool_choice_2[36]
 BV BND1      pool_choice_2[37]
 BV BND1      pool_choice_2[38]
 BV BND1      pool_choice_2[39]
 BV BND1      pool_choice_2[40]
 BV BND1      pool_choice_2[41]
 BV BND1      pool_choice_2[42]
 BV BND1      pool_choice_2[43]
 BV BND1      pool_choice_2[44]
 BV BND1      pool_choice_2[45]
 BV BND1      pool_choice_2[46]
 BV BND1      pool_choice_2[47]
 BV BND1      pool_choice_2[48]
 BV BND1      pool_choice_2[49]
 BV BND1      pool_choice_2[50]
 BV BND1      pool_choice_2[51]
 BV BND1      pool_choice_2[52]
 BV BND1      pool_choice_2[53]
 BV BND1      pool_choice_2[54]
 BV BND1      pool_used_2
 UP BND1      pool_start_2  75600
 UP BND1      pool_end_2  75600
 UP BND1      pool_start_rank_2  80
 UP BND1      pool_end_rank_2  80
 BV BND1      pool_first_2_C0_order_d
 BV BND1      pool_first_2_C90_order_d
 BV BND1      pool_first_2_C75_order_d
 BV BND1      pool_first_2_C39_order_d
 BV BND1      pool_first_2_C85_order_d
 BV BND1      pool_first_2_C0_order_p
 BV BND1      pool_first_2_C85_order_p
 BV BND1      pool_first_2_C81_order_d
 BV BND1      pool_first_2_C81_order_p
 BV BND1      pool_first_2_C90_order_p
 BV BND1      pool_first_2_C52_order_d
 BV BND1      pool_first_2_C21_order_d
 BV BND1      pool_last_2_C0_order_p
 BV BND1      pool_last_2_C85_order_p
 BV BND1      pool_last_2_C90_order_p
 BV BND1      pool_last_2_C75_order_p
 BV BND1      pool_last_2_C21_order_p
 BV BND1      pool_last_2_C39_order_p
 BV BND1      pool_last_2_C52_order_p
 BV BND1      pool_last_2_C21_order_d
 BV BND1      pool_last_2_C0_order_d
 BV BND1      pool_last_2_C52_order_d
 BV BND1      pool_last_2_C90_order_d
 BV BND1      pool_last_2_C39_order_d
 BV BND1      pool_last_2_C85_order_d
 BV BND1      pool_last_2_C81_order_d
 BV BND1      pool_last_2_C75_order_d
 BV BND1      pool_last_2_C51_order_d
 BV BND1      pool_pickup_2_C0_order
 BV BND1      pool_pickup_2_C85_order
 BV BND1      pool_pickup_2_C90_order
 BV BND1      pool_pickup_2_C75_order
 BV BND1      pool_pickup_2_C39_order
 BV BND1      pool_pickup_2_C21_order
 BV BND1      pool_pickup_2_C52_order
 BV BND1      pool_pickup_2_C81_order
 BV BND1      pool_batch_2_b2
 BV BND1      pool_batch_2_b1
 BV BND1      pool_batch_2_b3
 BV BND1      pool_choice_3[0]
 BV BND1      pool_choice_3[1]
 BV BND1      pool_choice_3[2]
 BV BND1      pool_choice_3[3]
 BV BND1      pool_choice_3[4]
 BV BND1      pool_choice_3[5]
 BV BND1      pool_choice_3[6]
 BV BND1      pool_choice_3[7]
 BV BND1      pool_choice_3[8]
 BV BND1      pool_choice_3[9]
 BV BND1      pool_choice_3[10]
 BV BND1      pool_choice_3[11]
 BV BND1      pool_choice_3[12]
 BV BND1      pool_choice_3[13]
 BV BND1      pool_choice_3[14]
 BV BND1      pool_choice_3[15]
 BV BND1      pool_choice_3[16]
 BV BND1      pool_choice_3[17]
 BV BND1      pool_choice_3[18]
 BV BND1      pool_choice_3[19]
 BV BND1      pool_choice_3[20]
 BV BND1      pool_choice_3[21]
 BV BND1      pool_choice_3[22]
 BV BND1      pool_choice_3[23]
 BV BND1      pool_choice_3[24]
 BV BND1      pool_choice_3[25]
 BV BND1      pool_choice_3[26]
 BV BND1      pool_choice_3[27]
 BV BND1      pool_choice_3[28]
 BV BND1      pool_choice_3[29]
 BV BND1      pool_choice_3[30]
 BV BND1      pool_choice_3[31]
 BV BND1      pool_choice_3[32]
 BV BND1      pool_choice_3[33]
 BV BND1      pool_choice_3[34]
 BV BND1      pool_choice_3[35]
 BV BND1      pool_choice_3[36]
 BV BND1      pool_choice_3[37]
 BV BND1      pool_choice_3[38]
 BV BND1      pool_choice_3[39]
 BV BND1      pool_choice_3[40]
 BV BND1      pool_choice_3[41]
 BV BND1      pool_choice_3[42]
 BV BND1      pool_choice_3[43]
 BV BND1      pool_choice_3[44]
 BV BND1      pool_choice_3[45]
 BV BND1      pool_choice_3[46]
 BV BND1      pool_choice_3[47]
 BV BND1      pool_choice_3[48]
 BV BND1      pool_choice_3[49]
 BV BND1      pool_choice_3[50]
 BV BND1      pool_choice_3[51]
 BV BND1      pool_used_3
 UP BND1      pool_start_3  75600
 UP BND1      pool_end_3  75600
 UP BND1      pool_start_rank_3  80
 UP BND1      pool_end_rank_3  80
 BV BND1      pool_first_3_C85_order_d
 BV BND1      pool_first_3_C90_order_d
 BV BND1      pool_first_3_C0_order_d
 BV BND1      pool_first_3_C21_order_d
 BV BND1      pool_first_3_C75_order_d
 BV BND1      pool_first_3_C85_order_p
 BV BND1      pool_first_3_C81_order_d
 BV BND1      pool_first_3_C81_order_p
 BV BND1      pool_first_3_C90_order_p
 BV BND1      pool_first_3_C39_order_d
 BV BND1      pool_first_3_C52_order_d
 BV BND1      pool_last_3_C85_order_p
 BV BND1      pool_last_3_C75_order_p
 BV BND1      pool_last_3_C21_order_p
 BV BND1      pool_last_3_C90_order_d
 BV BND1      pool_last_3_C39_order_d
 BV BND1      pool_last_3_C85_order_d
 BV BND1      pool_last_3_C81_order_d
 BV BND1      pool_last_3_C0_order_d
 BV BND1      pool_last_3_C75_order_d
 BV BND1      pool_last_3_C52_order_d
 BV BND1      pool_last_3_C21_order_d
 BV BND1      pool_last_3_C51_order_d
 BV BND1      pool_pickup_3_C21_order
 BV BND1      pool_pickup_3_C85_order
 BV BND1      pool_pickup_3_C75_order
 BV BND1      pool_pickup_3_C90_order
 BV BND1      pool_pickup_3_C0_order
 BV BND1      pool_pickup_3_C81_order
 BV BND1      pool_pickup_3_C39_order
 BV BND1      pool_batch_3_b3
 BV BND1      pool_batch_3_b1
 BV BND1      pool_batch_3_b2
 BV BND1      pool_choice_4[0]
 BV BND1      pool_choice_4[1]
 BV BND1      pool_choice_4[2]
 BV BND1      pool_choice_4[3]
 BV BND1      pool_choice_4[4]
 BV BND1      pool_choice_4[5]
 BV BND1      pool_choice_4[6]
 BV BND1      pool_choice_4[7]
 BV BND1      pool_choice_4[8]
 BV BND1      pool_choice_4[9]
 BV BND1      pool_choice_4[10]
 BV BND1      pool_choice_4[11]
 BV BND1      pool_choice_4[12]
 BV BND1      pool_choice_4[13]
 BV BND1      pool_choice_4[14]
 BV BND1      pool_choice_4[15]
 BV BND1      pool_choice_4[16]
 BV BND1      pool_choice_4[17]
 BV BND1      pool_choice_4[18]
 BV BND1      pool_choice_4[19]
 BV BND1      pool_choice_4[20]
 BV BND1      pool_choice_4[21]
 BV BND1      pool_choice_4[22]
 BV BND1      pool_choice_4[23]
 BV BND1      pool_choice_4[24]
 BV BND1      pool_choice_4[25]
 BV BND1      pool_choice_4[26]
 BV BND1      pool_choice_4[27]
 BV BND1      pool_choice_4[28]
 BV BND1      pool_choice_4[29]
 BV BND1      pool_choice_4[30]
 BV BND1      pool_choice_4[31]
 BV BND1      pool_choice_4[32]
 BV BND1      pool_choice_4[33]
 BV BND1      pool_choice_4[34]
 BV BND1      pool_choice_4[35]
 BV BND1      pool_choice_4[36]
 BV BND1      pool_choice_4[37]
 BV BND1      pool_choice_4[38]
 BV BND1      pool_choice_4[39]
 BV BND1      pool_choice_4[40]
 BV BND1      pool_choice_4[41]
 BV BND1      pool_choice_4[42]
 BV BND1      pool_choice_4[43]
 BV BND1      pool_choice_4[44]
 BV BND1      pool_choice_4[45]
 BV BND1      pool_choice_4[46]
 BV BND1      pool_choice_4[47]
 BV BND1      pool_choice_4[48]
 BV BND1      pool_choice_4[49]
 BV BND1      pool_choice_4[50]
 BV BND1      pool_choice_4[51]
 BV BND1      pool_choice_4[52]
 BV BND1      pool_choice_4[53]
 BV BND1      pool_choice_4[54]
 BV BND1      pool_choice_4[55]
 BV BND1      pool_choice_4[56]
 BV BND1      pool_choice_4[57]
 BV BND1      pool_choice_4[58]
 BV BND1      pool_choice_4[59]
 BV BND1      pool_choice_4[60]
 BV BND1      pool_choice_4[61]
 BV BND1      pool_used_4
 UP BND1      pool_start_4  75600
 UP BND1      pool_end_4  75600
 UP BND1      pool_start_rank_4  80
 UP BND1      pool_end_rank_4  80
 BV BND1      pool_first_4_C85_order_d
 BV BND1      pool_first_4_C85_order_p
 BV BND1      pool_first_4_C81_order_d
 BV BND1      pool_first_4_C90_order_d
 BV BND1      pool_first_4_C0_order_d
 BV BND1      pool_first_4_C75_order_d
 BV BND1      pool_first_4_C81_order_p
 BV BND1      pool_first_4_C90_order_p
 BV BND1      pool_first_4_C97_order_d
 BV BND1      pool_first_4_C39_order_d
 BV BND1      pool_first_4_C21_order_d
 BV BND1      pool_first_4_C0_order_p
 BV BND1      pool_first_4_C52_order_d
 BV BND1      pool_first_4_C51_order_d
 BV BND1      pool_first_4_C75_order_p
 BV BND1      pool_first_4_C97_order_p
 BV BND1      pool_first_4_C39_order_p
 BV BND1      pool_first_4_C21_order_p
 BV BND1      pool_first_4_C52_order_p
 BV BND1      pool_first_4_C51_order_p
 BV BND1      pool_last_4_C85_order_p
 BV BND1      pool_last_4_C85_order_d
 BV BND1      pool_last_4_C81_order_p
 BV BND1      pool_last_4_C90_order_p
 BV BND1      pool_last_4_C0_order_p
 BV BND1      pool_last_4_C75_order_p
 BV BND1      pool_last_4_C81_order_d
 BV BND1      pool_last_4_C90_order_d
 BV BND1      pool_last_4_C97_order_p
 BV BND1      pool_last_4_C39_order_p
 BV BND1      pool_last_4_C21_order_p
 BV BND1      pool_last_4_C0_order_d
 BV BND1      pool_last_4_C52_order_p
 BV BND1      pool_last_4_C51_order_p
 BV BND1      pool_last_4_C75_order_d
 BV BND1      pool_last_4_C97_order_d
 BV BND1      pool_last_4_C39_order_d
 BV BND1      pool_last_4_C21_order_d
 BV BND1      pool_last_4_C52_order_d
 BV BND1      pool_last_4_C51_order_d
 BV BND1      pool_pickup_4_C85_order
 BV BND1      pool_pickup_4_C81_order
 BV BND1      pool_pickup_4_C90_order
 BV BND1      pool_pickup_4_C0_order
 BV BND1      pool_pickup_4_C75_order
 BV BND1      pool_pickup_4_C97_order
 BV BND1      pool_pickup_4_C39_order
 BV BND1      pool_pickup_4_C21_order
 BV BND1      pool_pickup_4_C52_order
 BV BND1      pool_pickup_4_C51_order
 BV BND1      pool_batch_4_b3
 BV BND1      pool_batch_4_b1
 BV BND1      pool_batch_4_b2
 BV BND1      pool_choice_5[0]
 BV BND1      pool_choice_5[1]
 BV BND1      pool_choice_5[2]
 BV BND1      pool_choice_5[3]
 BV BND1      pool_choice_5[4]
 BV BND1      pool_choice_5[5]
 BV BND1      pool_choice_5[6]
 BV BND1      pool_choice_5[7]
 BV BND1      pool_choice_5[8]
 BV BND1      pool_choice_5[9]
 BV BND1      pool_choice_5[10]
 BV BND1      pool_choice_5[11]
 BV BND1      pool_choice_5[12]
 BV BND1      pool_choice_5[13]
 BV BND1      pool_choice_5[14]
 BV BND1      pool_choice_5[15]
 BV BND1      pool_choice_5[16]
 BV BND1      pool_choice_5[17]
 BV BND1      pool_choice_5[18]
 BV BND1      pool_choice_5[19]
 BV BND1      pool_choice_5[20]
 BV BND1      pool_choice_5[21]
 BV BND1      pool_choice_5[22]
 BV BND1      pool_choice_5[23]
 BV BND1      pool_choice_5[24]
 BV BND1      pool_choice_5[25]
 BV BND1      pool_choice_5[26]
 BV BND1      pool_choice_5[27]
 BV BND1      pool_choice_5[28]
 BV BND1      pool_choice_5[29]
 BV BND1      pool_choice_5[30]
 BV BND1      pool_choice_5[31]
 BV BND1      pool_choice_5[32]
 BV BND1      pool_choice_5[33]
 BV BND1      pool_choice_5[34]
 BV BND1      pool_choice_5[35]
 BV BND1      pool_choice_5[36]
 BV BND1      pool_choice_5[37]
 BV BND1      pool_choice_5[38]
 BV BND1      pool_choice_5[39]
 BV BND1      pool_choice_5[40]
 BV BND1      pool_choice_5[41]
 BV BND1      pool_choice_5[42]
 BV BND1      pool_choice_5[43]
 BV BND1      pool_choice_5[44]
 BV BND1      pool_choice_5[45]
 BV BND1      pool_choice_5[46]
 BV BND1      pool_choice_5[47]
 BV BND1      pool_choice_5[48]
 BV BND1      pool_choice_5[49]
 BV BND1      pool_choice_5[50]
 BV BND1      pool_choice_5[51]
 BV BND1      pool_choice_5[52]
 BV BND1      pool_choice_5[53]
 BV BND1      pool_choice_5[54]
 BV BND1      pool_choice_5[55]
 BV BND1      pool_choice_5[56]
 BV BND1      pool_choice_5[57]
 BV BND1      pool_choice_5[58]
 BV BND1      pool_choice_5[59]
 BV BND1      pool_choice_5[60]
 BV BND1      pool_choice_5[61]
 BV BND1      pool_choice_5[62]
 BV BND1      pool_choice_5[63]
 BV BND1      pool_choice_5[64]
 BV BND1      pool_choice_5[65]
 BV BND1      pool_choice_5[66]
 BV BND1      pool_choice_5[67]
 BV BND1      pool_used_5
 UP BND1      pool_start_5  75600
 UP BND1      pool_end_5  75600
 UP BND1      pool_start_rank_5  80
 UP BND1      pool_end_rank_5  80
 BV BND1      pool_first_5_C90_order_d
 BV BND1      pool_first_5_C81_order_d
 BV BND1      pool_first_5_C0_order_d
 BV BND1      pool_first_5_C75_order_d
 BV BND1      pool_first_5_C97_order_d
 BV BND1      pool_first_5_C90_order_p
 BV BND1      pool_first_5_C51_order_d
 BV BND1      pool_first_5_C85_order_d
 BV BND1      pool_first_5_C39_order_d
 BV BND1      pool_first_5_C85_order_p
 BV BND1      pool_first_5_C81_order_p
 BV BND1      pool_first_5_C52_order_d
 BV BND1      pool_first_5_C21_order_d
 BV BND1      pool_last_5_C90_order_p
 BV BND1      pool_last_5_C85_order_p
 BV BND1      pool_last_5_C81_order_p
 BV BND1      pool_last_5_C0_order_p
 BV BND1      pool_last_5_C75_order_p
 BV BND1      pool_last_5_C97_order_p
 BV BND1      pool_last_5_C21_order_p
 BV BND1      pool_last_5_C39_order_p
 BV BND1      pool_last_5_C90_order_d
 BV BND1      pool_last_5_C52_order_p
 BV BND1      pool_last_5_C51_order_p
 BV BND1      pool_last_5_C21_order_d
 BV BND1      pool_last_5_C52_order_d
 BV BND1      pool_last_5_C39_order_d
 BV BND1      pool_last_5_C85_order_d
 BV BND1      pool_last_5_C81_order_d
 BV BND1      pool_last_5_C0_order_d
 BV BND1      pool_last_5_C75_order_d
 BV BND1      pool_last_5_C51_order_d
 BV BND1      pool_pickup_5_C90_order
 BV BND1      pool_pickup_5_C85_order
 BV BND1      pool_pickup_5_C81_order
 BV BND1      pool_pickup_5_C0_order
 BV BND1      pool_pickup_5_C75_order
 BV BND1      pool_pickup_5_C97_order
 BV BND1      pool_pickup_5_C51_order
 BV BND1      pool_pickup_5_C21_order
 BV BND1      pool_pickup_5_C39_order
 BV BND1      pool_pickup_5_C52_order
 BV BND1      pool_batch_5_b1
 BV BND1      pool_batch_5_b2
 BV BND1      pool_batch_5_b3
 BV BND1      pool_choice_6[0]
 BV BND1      pool_choice_6[1]
 BV BND1      pool_choice_6[2]
 BV BND1      pool_choice_6[3]
 BV BND1      pool_choice_6[4]
 BV BND1      pool_choice_6[5]
 BV BND1      pool_choice_6[6]
 BV BND1      pool_choice_6[7]
 BV BND1      pool_choice_6[8]
 BV BND1      pool_choice_6[9]
 BV BND1      pool_choice_6[10]
 BV BND1      pool_choice_6[11]
 BV BND1      pool_choice_6[12]
 BV BND1      pool_choice_6[13]
 BV BND1      pool_choice_6[14]
 BV BND1      pool_choice_6[15]
 BV BND1      pool_choice_6[16]
 BV BND1      pool_choice_6[17]
 BV BND1      pool_choice_6[18]
 BV BND1      pool_choice_6[19]
 BV BND1      pool_choice_6[20]
 BV BND1      pool_choice_6[21]
 BV BND1      pool_choice_6[22]
 BV BND1      pool_choice_6[23]
 BV BND1      pool_choice_6[24]
 BV BND1      pool_choice_6[25]
 BV BND1      pool_choice_6[26]
 BV BND1      pool_choice_6[27]
 BV BND1      pool_choice_6[28]
 BV BND1      pool_choice_6[29]
 BV BND1      pool_choice_6[30]
 BV BND1      pool_choice_6[31]
 BV BND1      pool_choice_6[32]
 BV BND1      pool_choice_6[33]
 BV BND1      pool_choice_6[34]
 BV BND1      pool_choice_6[35]
 BV BND1      pool_choice_6[36]
 BV BND1      pool_choice_6[37]
 BV BND1      pool_choice_6[38]
 BV BND1      pool_choice_6[39]
 BV BND1      pool_choice_6[40]
 BV BND1      pool_choice_6[41]
 BV BND1      pool_choice_6[42]
 BV BND1      pool_choice_6[43]
 BV BND1      pool_choice_6[44]
 BV BND1      pool_choice_6[45]
 BV BND1      pool_choice_6[46]
 BV BND1      pool_choice_6[47]
 BV BND1      pool_choice_6[48]
 BV BND1      pool_choice_6[49]
 BV BND1      pool_choice_6[50]
 BV BND1      pool_choice_6[51]
 BV BND1      pool_used_6
 UP BND1      pool_start_6  75600
 UP BND1      pool_end_6  75600
 UP BND1      pool_start_rank_6  80
 UP BND1      pool_end_rank_6  80
 BV BND1      pool_first_6_C39_order_d
 BV BND1      pool_first_6_C90_order_d
 BV BND1      pool_first_6_C52_order_d
 BV BND1      pool_first_6_C0_order_d
 BV BND1      pool_first_6_C85_order_p
 BV BND1      pool_first_6_C81_order_d
 BV BND1      pool_first_6_C85_order_d
 BV BND1      pool_first_6_C81_order_p
 BV BND1      pool_first_6_C90_order_p
 BV BND1      pool_first_6_C75_order_d
 BV BND1      pool_last_6_C39_order_p
 BV BND1      pool_last_6_C85_order_p
 BV BND1      pool_last_6_C21_order_p
 BV BND1      pool_last_6_C0_order_p
 BV BND1      pool_last_6_C75_order_p
 BV BND1      pool_last_6_C52_order_p
 BV BND1      pool_last_6_C90_order_d
 BV BND1      pool_last_6_C39_order_d
 BV BND1      pool_last_6_C85_order_d
 BV BND1      pool_last_6_C81_order_d
 BV BND1      pool_last_6_C0_order_d
 BV BND1      pool_last_6_C75_order_d
 BV BND1      pool_last_6_C52_order_d
 BV BND1      pool_last_6_C21_order_d
 BV BND1      pool_last_6_C51_order_d
 BV BND1      pool_pickup_6_C52_order
 BV BND1      pool_pickup_6_C39_order
 BV BND1      pool_pickup_6_C85_order
 BV BND1      pool_pickup_6_C21_order
 BV BND1      pool_pickup_6_C0_order
 BV BND1      pool_pickup_6_C75_order
 BV BND1      pool_pickup_6_C90_order
 BV BND1      pool_pickup_6_C81_order
 BV BND1      pool_batch_6_b2
 BV BND1      pool_batch_6_b1
 BV BND1      pool_batch_6_b3
 BV BND1      pool_choice_7[0]
 BV BND1      pool_choice_7[1]
 BV BND1      pool_choice_7[2]
 BV BND1      pool_choice_7[3]
 BV BND1      pool_choice_7[4]
 BV BND1      pool_choice_7[5]
 BV BND1      pool_choice_7[6]
 BV BND1      pool_choice_7[7]
 BV BND1      pool_choice_7[8]
 BV BND1      pool_choice_7[9]
 BV BND1      pool_choice_7[10]
 BV BND1      pool_choice_7[11]
 BV BND1      pool_choice_7[12]
 BV BND1      pool_choice_7[13]
 BV BND1      pool_choice_7[14]
 BV BND1      pool_choice_7[15]
 BV BND1      pool_choice_7[16]
 BV BND1      pool_choice_7[17]
 BV BND1      pool_choice_7[18]
 BV BND1      pool_choice_7[19]
 BV BND1      pool_choice_7[20]
 BV BND1      pool_choice_7[21]
 BV BND1      pool_choice_7[22]
 BV BND1      pool_choice_7[23]
 BV BND1      pool_choice_7[24]
 BV BND1      pool_choice_7[25]
 BV BND1      pool_choice_7[26]
 BV BND1      pool_choice_7[27]
 BV BND1      pool_choice_7[28]
 BV BND1      pool_choice_7[29]
 BV BND1      pool_choice_7[30]
 BV BND1      pool_choice_7[31]
 BV BND1      pool_choice_7[32]
 BV BND1      pool_choice_7[33]
 BV BND1      pool_choice_7[34]
 BV BND1      pool_choice_7[35]
 BV BND1      pool_choice_7[36]
 BV BND1      pool_choice_7[37]
 BV BND1      pool_choice_7[38]
 BV BND1      pool_choice_7[39]
 BV BND1      pool_choice_7[40]
 BV BND1      pool_choice_7[41]
 BV BND1      pool_choice_7[42]
 BV BND1      pool_choice_7[43]
 BV BND1      pool_choice_7[44]
 BV BND1      pool_choice_7[45]
 BV BND1      pool_choice_7[46]
 BV BND1      pool_choice_7[47]
 BV BND1      pool_choice_7[48]
 BV BND1      pool_choice_7[49]
 BV BND1      pool_choice_7[50]
 BV BND1      pool_choice_7[51]
 BV BND1      pool_choice_7[52]
 BV BND1      pool_choice_7[53]
 BV BND1      pool_choice_7[54]
 BV BND1      pool_choice_7[55]
 BV BND1      pool_used_7
 UP BND1      pool_start_7  75600
 UP BND1      pool_end_7  75600
 UP BND1      pool_start_rank_7  80
 UP BND1      pool_end_rank_7  80
 BV BND1      pool_first_7_C75_order_d
 BV BND1      pool_first_7_C85_order_d
 BV BND1      pool_first_7_C90_order_d
 BV BND1      pool_first_7_C0_order_d
 BV BND1      pool_first_7_C21_order_d
 BV BND1      pool_first_7_C75_order_p
 BV BND1      pool_first_7_C85_order_p
 BV BND1      pool_first_7_C81_order_d
 BV BND1      pool_first_7_C81_order_p
 BV BND1      pool_first_7_C90_order_p
 BV BND1      pool_first_7_C39_order_d
 BV BND1      pool_first_7_C52_order_d
 BV BND1      pool_last_7_C75_order_p
 BV BND1      pool_last_7_C85_order_p
 BV BND1      pool_last_7_C90_order_p
 BV BND1      pool_last_7_C0_order_p
 BV BND1      pool_last_7_C21_order_p
 BV BND1      pool_last_7_C21_order_d
 BV BND1      pool_last_7_C75_order_d
 BV BND1      pool_last_7_C90_order_d
 BV BND1      pool_last_7_C39_order_d
 BV BND1      pool_last_7_C85_order_d
 BV BND1      pool_last_7_C81_order_d
 BV BND1      pool_last_7_C0_order_d
 BV BND1      pool_last_7_C52_order_d
 BV BND1      pool_last_7_C51_order_d
 BV BND1      pool_pickup_7_C75_order
 BV BND1      pool_pickup_7_C85_order
 BV BND1      pool_pickup_7_C90_order
 BV BND1      pool_pickup_7_C0_order
 BV BND1      pool_pickup_7_C21_order
 BV BND1      pool_pickup_7_C81_order
 BV BND1      pool_pickup_7_C39_order
 BV BND1      pool_batch_7_b3
 BV BND1      pool_batch_7_b1
 BV BND1      pool_batch_7_b2
 BV BND1      pool_choice_8[0]
 BV BND1      pool_choice_8[1]
 BV BND1      pool_choice_8[2]
 BV BND1      pool_choice_8[3]
 BV BND1      pool_choice_8[4]
 BV BND1      pool_choice_8[5]
 BV BND1      pool_choice_8[6]
 BV BND1      pool_choice_8[7]
 BV BND1      pool_choice_8[8]
 BV BND1      pool_choice_8[9]
 BV BND1      pool_choice_8[10]
 BV BND1      pool_choice_8[11]
 BV BND1      pool_choice_8[12]
 BV BND1      pool_choice_8[13]
 BV BND1      pool_choice_8[14]
 BV BND1      pool_choice_8[15]
 BV BND1      pool_choice_8[16]
 BV BND1      pool_choice_8[17]
 BV BND1      pool_choice_8[18]
 BV BND1      pool_choice_8[19]
 BV BND1      pool_choice_8[20]
 BV BND1      pool_choice_8[21]
 BV BND1      pool_choice_8[22]
 BV BND1      pool_choice_8[23]
 BV BND1      pool_choice_8[24]
 BV BND1      pool_choice_8[25]
 BV BND1      pool_choice_8[26]
 BV BND1      pool_choice_8[27]
 BV BND1      pool_choice_8[28]
 BV BND1      pool_choice_8[29]
 BV BND1      pool_choice_8[30]
 BV BND1      pool_choice_8[31]
 BV BND1      pool_choice_8[32]
 BV BND1      pool_choice_8[33]
 BV BND1      pool_choice_8[34]
 BV BND1      pool_choice_8[35]
 BV BND1      pool_choice_8[36]
 BV BND1      pool_choice_8[37]
 BV BND1      pool_choice_8[38]
 BV BND1      pool_choice_8[39]
 BV BND1      pool_choice_8[40]
 BV BND1      pool_choice_8[41]
 BV BND1      pool_choice_8[42]
 BV BND1      pool_choice_8[43]
 BV BND1      pool_choice_8[44]
 BV BND1      pool_choice_8[45]
 BV BND1      pool_choice_8[46]
 BV BND1      pool_choice_8[47]
 BV BND1      pool_choice_8[48]
 BV BND1      pool_choice_8[49]
 BV BND1      pool_choice_8[50]
 BV BND1      pool_choice_8[51]
 BV BND1      pool_choice_8[52]
 BV BND1      pool_choice_8[53]
 BV BND1      pool_choice_8[54]
 BV BND1      pool_choice_8[55]
 BV BND1      pool_used_8
 UP BND1      pool_start_8  75600
 UP BND1      pool_end_8  75600
 UP BND1      pool_start_rank_8  80
 UP BND1      pool_end_rank_8  80
 BV BND1      pool_first_8_C47_order_d
 BV BND1      pool_first_8_C88_order_d
 BV BND1      pool_first_8_C29_order_d
 BV BND1      pool_first_8_C47_order_p
 BV BND1      pool_first_8_C76_order_d
 BV BND1      pool_first_8_C88_order_p
 BV BND1      pool_first_8_C29_order_p
 BV BND1      pool_first_8_C27_order_d
 BV BND1      pool_first_8_C25_order_d
 BV BND1      pool_first_8_C76_order_p
 BV BND1      pool_first_8_C46_order_d
 BV BND1      pool_first_8_C6_order_d
 BV BND1      pool_first_8_C27_order_p
 BV BND1      pool_first_8_C25_order_p
 BV BND1      pool_first_8_C46_order_p
 BV BND1      pool_first_8_C6_order_p
 BV BND1      pool_last_8_C47_order_p
 BV BND1      pool_last_8_C88_order_p
 BV BND1      pool_last_8_C29_order_p
 BV BND1      pool_last_8_C47_order_d
 BV BND1      pool_last_8_C76_order_p
 BV BND1      pool_last_8_C88_order_d
 BV BND1      pool_last_8_C29_order_d
 BV BND1      pool_last_8_C27_order_p
 BV BND1      pool_last_8_C25_order_p
 BV BND1      pool_last_8_C76_order_d
 BV BND1      pool_last_8_C46_order_p
 BV BND1      pool_last_8_C6_order_p
 BV BND1      pool_last_8_C27_order_d
 BV BND1      pool_last_8_C25_order_d
 BV BND1      pool_last_8_C46_order_d
 BV BND1      pool_last_8_C6_order_d
 BV BND1      pool_pickup_8_C47_order
 BV BND1      pool_pickup_8_C88_order
 BV BND1      pool_pickup_8_C29_order
 BV BND1      pool_pickup_8_C76_order
 BV BND1      pool_pickup_8_C27_order
 BV BND1      pool_pickup_8_C25_order
 BV BND1      pool_pickup_8_C46_order
 BV BND1      pool_pickup_8_C6_order
 BV BND1      pool_batch_8_b2
 BV BND1      pool_batch_8_b1
 BV BND1      pool_batch_8_b3
 BV BND1      pool_choice_9[0]
 BV BND1      pool_choice_9[1]
 BV BND1      pool_choice_9[2]
 BV BND1      pool_choice_9[3]
 BV BND1      pool_choice_9[4]
 BV BND1      pool_choice_9[5]
 BV BND1      pool_choice_9[6]
 BV BND1      pool_choice_9[7]
 BV BND1      pool_choice_9[8]
 BV BND1      pool_choice_9[9]
 BV BND1      pool_choice_9[10]
 BV BND1      pool_choice_9[11]
 BV BND1      pool_choice_9[12]
 BV BND1      pool_choice_9[13]
 BV BND1      pool_choice_9[14]
 BV BND1      pool_choice_9[15]
 BV BND1      pool_choice_9[16]
 BV BND1      pool_choice_9[17]
 BV BND1      pool_choice_9[18]
 BV BND1      pool_choice_9[19]
 BV BND1      pool_choice_9[20]
 BV BND1      pool_choice_9[21]
 BV BND1      pool_choice_9[22]
 BV BND1      pool_choice_9[23]
 BV BND1      pool_choice_9[24]
 BV BND1      pool_choice_9[25]
 BV BND1      pool_choice_9[26]
 BV BND1      pool_choice_9[27]
 BV BND1      pool_choice_9[28]
 BV BND1      pool_choice_9[29]
 BV BND1      pool_choice_9[30]
 BV BND1      pool_choice_9[31]
 BV BND1      pool_choice_9[32]
 BV BND1      pool_choice_9[33]
 BV BND1      pool_choice_9[34]
 BV BND1      pool_choice_9[35]
 BV BND1      pool_choice_9[36]
 BV BND1      pool_choice_9[37]
 BV BND1      pool_choice_9[38]
 BV BND1      pool_choice_9[39]
 BV BND1      pool_choice_9[40]
 BV BND1      pool_choice_9[41]
 BV BND1      pool_choice_9[42]
 BV BND1      pool_choice_9[43]
 BV BND1      pool_choice_9[44]
 BV BND1      pool_choice_9[45]
 BV BND1      pool_choice_9[46]
 BV BND1      pool_choice_9[47]
 BV BND1      pool_choice_9[48]
 BV BND1      pool_choice_9[49]
 BV BND1      pool_choice_9[50]
 BV BND1      pool_choice_9[51]
 BV BND1      pool_choice_9[52]
 BV BND1      pool_choice_9[53]
 BV BND1      pool_choice_9[54]
 BV BND1      pool_choice_9[55]
 BV BND1      pool_choice_9[56]
 BV BND1      pool_choice_9[57]
 BV BND1      pool_used_9
 UP BND1      pool_start_9  75600
 UP BND1      pool_end_9  75600
 UP BND1      pool_start_rank_9  80
 UP BND1      pool_end_rank_9  80
 BV BND1      pool_first_9_C88_order_d
 BV BND1      pool_first_9_C29_order_d
 BV BND1      pool_first_9_C76_order_d
 BV BND1      pool_first_9_C88_order_p
 BV BND1      pool_first_9_C47_order_d
 BV BND1      pool_first_9_C46_order_d
 BV BND1      pool_first_9_C6_order_d
 BV BND1      pool_first_9_C47_order_p
 BV BND1      pool_first_9_C76_order_p
 BV BND1      pool_first_9_C27_order_d
 BV BND1      pool_first_9_C25_order_d
 BV BND1      pool_last_9_C88_order_p
 BV BND1      pool_last_9_C29_order_p
 BV BND1      pool_last_9_C47_order_p
 BV BND1      pool_last_9_C76_order_p
 BV BND1      pool_last_9_C88_order_d
 BV BND1      pool_last_9_C27_order_p
 BV BND1      pool_last_9_C25_order_p
 BV BND1      pool_last_9_C46_order_p
 BV BND1      pool_last_9_C27_order_d
 BV BND1      pool_last_9_C6_order_p
 BV BND1      pool_last_9_C25_order_d
 BV BND1      pool_last_9_C47_order_d
 BV BND1      pool_last_9_C29_order_d
 BV BND1      pool_last_9_C76_order_d
 BV BND1      pool_last_9_C6_order_d
 BV BND1      pool_last_9_C46_order_d
 BV BND1      pool_pickup_9_C88_order
 BV BND1      pool_pickup_9_C29_order
 BV BND1      pool_pickup_9_C47_order
 BV BND1      pool_pickup_9_C76_order
 BV BND1      pool_pickup_9_C27_order
 BV BND1      pool_pickup_9_C25_order
 BV BND1      pool_pickup_9_C46_order
 BV BND1      pool_pickup_9_C6_order
 BV BND1      pool_batch_9_b1
 BV BND1      pool_batch_9_b3
 BV BND1      pool_batch_9_b2
 BV BND1      pool_choice_10[0]
 BV BND1      pool_choice_10[1]
 BV BND1      pool_choice_10[2]
 BV BND1      pool_choice_10[3]
 BV BND1      pool_choice_10[4]
 BV BND1      pool_choice_10[5]
 BV BND1      pool_choice_10[6]
 BV BND1      pool_choice_10[7]
 BV BND1      pool_choice_10[8]
 BV BND1      pool_choice_10[9]
 BV BND1      pool_choice_10[10]
 BV BND1      pool_choice_10[11]
 BV BND1      pool_choice_10[12]
 BV BND1      pool_choice_10[13]
 BV BND1      pool_choice_10[14]
 BV BND1      pool_choice_10[15]
 BV BND1      pool_choice_10[16]
 BV BND1      pool_choice_10[17]
 BV BND1      pool_choice_10[18]
 BV BND1      pool_choice_10[19]
 BV BND1      pool_choice_10[20]
 BV BND1      pool_choice_10[21]
 BV BND1      pool_choice_10[22]
 BV BND1      pool_choice_10[23]
 BV BND1      pool_choice_10[24]
 BV BND1      pool_choice_10[25]
 BV BND1      pool_choice_10[26]
 BV BND1      pool_choice_10[27]
 BV BND1      pool_choice_10[28]
 BV BND1      pool_choice_10[29]
 BV BND1      pool_choice_10[30]
 BV BND1      pool_choice_10[31]
 BV BND1      pool_choice_10[32]
 BV BND1      pool_choice_10[33]
 BV BND1      pool_choice_10[34]
 BV BND1      pool_choice_10[35]
 BV BND1      pool_choice_10[36]
 BV BND1      pool_choice_10[37]
 BV BND1      pool_choice_10[38]
 BV BND1      pool_choice_10[39]
 BV BND1      pool_choice_10[40]
 BV BND1      pool_choice_10[41]
 BV BND1      pool_choice_10[42]
 BV BND1      pool_choice_10[43]
 BV BND1      pool_choice_10[44]
 BV BND1      pool_choice_10[45]
 BV BND1      pool_choice_10[46]
 BV BND1      pool_choice_10[47]
 BV BND1      pool_choice_10[48]
 BV BND1      pool_choice_10[49]
 BV BND1      pool_choice_10[50]
 BV BND1      pool_choice_10[51]
 BV BND1      pool_used_10
 UP BND1      pool_start_10  75600
 UP BND1      pool_end_10  75600
 UP BND1      pool_start_rank_10  80
 UP BND1      pool_end_rank_10  80
 BV BND1      pool_first_10_C47_order_d
 BV BND1      pool_first_10_C25_order_d
 BV BND1      pool_first_10_C88_order_d
 BV BND1      pool_first_10_C46_order_d
 BV BND1      pool_first_10_C88_order_p
 BV BND1      pool_first_10_C29_order_d
 BV BND1      pool_first_10_C47_order_p
 BV BND1      pool_first_10_C76_order_p
 BV BND1      pool_first_10_C76_order_d
 BV BND1      pool_first_10_C6_order_d
 BV BND1      pool_first_10_C27_order_d
 BV BND1      pool_last_10_C47_order_p
 BV BND1      pool_last_10_C29_order_p
 BV BND1      pool_last_10_C25_order_p
 BV BND1      pool_last_10_C46_order_p
 BV BND1      pool_last_10_C6_order_p
 BV BND1      pool_last_10_C88_order_d
 BV BND1      pool_last_10_C47_order_d
 BV BND1      pool_last_10_C29_order_d
 BV BND1      pool_last_10_C76_order_d
 BV BND1      pool_last_10_C88_order_p
 BV BND1      pool_last_10_C25_order_d
 BV BND1      pool_last_10_C6_order_d
 BV BND1      pool_last_10_C46_order_d
 BV BND1      pool_last_10_C27_order_d
 BV BND1      pool_pickup_10_C25_order
 BV BND1      pool_pickup_10_C47_order
 BV BND1      pool_pickup_10_C29_order
 BV BND1      pool_pickup_10_C88_order
 BV BND1      pool_pickup_10_C46_order
 BV BND1      pool_pickup_10_C6_order
 BV BND1      pool_pickup_10_C76_order
 BV BND1      pool_pickup_10_C27_order
 BV BND1      pool_batch_10_b2
 BV BND1      pool_batch_10_b1
 BV BND1      pool_batch_10_b3
 BV BND1      pool_choice_11[0]
 BV BND1      pool_choice_11[1]
 BV BND1      pool_choice_11[2]
 BV BND1      pool_choice_11[3]
 BV BND1      pool_choice_11[4]
 BV BND1      pool_choice_11[5]
 BV BND1      pool_choice_11[6]
 BV BND1      pool_choice_11[7]
 BV BND1      pool_choice_11[8]
 BV BND1      pool_choice_11[9]
 BV BND1      pool_choice_11[10]
 BV BND1      pool_choice_11[11]
 BV BND1      pool_choice_11[12]
 BV BND1      pool_choice_11[13]
 BV BND1      pool_choice_11[14]
 BV BND1      pool_choice_11[15]
 BV BND1      pool_choice_11[16]
 BV BND1      pool_choice_11[17]
 BV BND1      pool_choice_11[18]
 BV BND1      pool_choice_11[19]
 BV BND1      pool_choice_11[20]
 BV BND1      pool_choice_11[21]
 BV BND1      pool_choice_11[22]
 BV BND1      pool_choice_11[23]
 BV BND1      pool_choice_11[24]
 BV BND1      pool_choice_11[25]
 BV BND1      pool_choice_11[26]
 BV BND1      pool_choice_11[27]
 BV BND1      pool_choice_11[28]
 BV BND1      pool_choice_11[29]
 BV BND1      pool_choice_11[30]
 BV BND1      pool_choice_11[31]
 BV BND1      pool_choice_11[32]
 BV BND1      pool_choice_11[33]
 BV BND1      pool_choice_11[34]
 BV BND1      pool_choice_11[35]
 BV BND1      pool_choice_11[36]
 BV BND1      pool_choice_11[37]
 BV BND1      pool_choice_11[38]
 BV BND1      pool_choice_11[39]
 BV BND1      pool_choice_11[40]
 BV BND1      pool_choice_11[41]
 BV BND1      pool_choice_11[42]
 BV BND1      pool_choice_11[43]
 BV BND1      pool_choice_11[44]
 BV BND1      pool_used_11
 UP BND1      pool_start_11  75600
 UP BND1      pool_end_11  75600
 UP BND1      pool_start_rank_11  80
 UP BND1      pool_end_rank_11  80
 BV BND1      pool_first_11_C29_order_d
 BV BND1      pool_first_11_C88_order_d
 BV BND1      pool_first_11_C29_order_p
 BV BND1      pool_first_11_C46_order_d
 BV BND1      pool_first_11_C6_order_d
 BV BND1      pool_first_11_C88_order_p
 BV BND1      pool_first_11_C47_order_d
 BV BND1      pool_first_11_C47_order_p
 BV BND1      pool_first_11_C76_order_p
 BV BND1      pool_first_11_C76_order_d
 BV BND1      pool_first_11_C27_order_d
 BV BND1      pool_first_11_C25_order_d
 BV BND1      pool_last_11_C29_order_p
 BV BND1      pool_last_11_C88_order_p
 BV BND1      pool_last_11_C29_order_d
 BV BND1      pool_last_11_C6_order_p
 BV BND1      pool_last_11_C46_order_p
 BV BND1      pool_last_11_C6_order_d
 BV BND1      pool_last_11_C88_order_d
 BV BND1      pool_last_11_C47_order_d
 BV BND1      pool_last_11_C47_order_p
 BV BND1      pool_last_11_C76_order_d
 BV BND1      pool_last_11_C25_order_d
 BV BND1      pool_last_11_C46_order_d
 BV BND1      pool_last_11_C27_order_d
 BV BND1      pool_pickup_11_C29_order
 BV BND1      pool_pickup_11_C88_order
 BV BND1      pool_pickup_11_C6_order
 BV BND1      pool_pickup_11_C46_order
 BV BND1      pool_pickup_11_C47_order
 BV BND1      pool_pickup_11_C76_order
 BV BND1      pool_pickup_11_C25_order
 BV BND1      pool_pickup_11_C27_order
 BV BND1      pool_batch_11_b3
 BV BND1      pool_batch_11_b1
 BV BND1      pool_batch_11_b2
 BV BND1      pool_choice_12[0]
 BV BND1      pool_choice_12[1]
 BV BND1      pool_choice_12[2]
 BV BND1      pool_choice_12[3]
 BV BND1      pool_choice_12[4]
 BV BND1      pool_choice_12[5]
 BV BND1      pool_choice_12[6]
 BV BND1      pool_choice_12[7]
 BV BND1      pool_choice_12[8]
 BV BND1      pool_choice_12[9]
 BV BND1      pool_choice_12[10]
 BV BND1      pool_choice_12[11]
 BV BND1      pool_choice_12[12]
 BV BND1      pool_choice_12[13]
 BV BND1      pool_choice_12[14]
 BV BND1      pool_choice_12[15]
 BV BND1      pool_choice_12[16]
 BV BND1      pool_choice_12[17]
 BV BND1      pool_choice_12[18]
 BV BND1      pool_choice_12[19]
 BV BND1      pool_choice_12[20]
 BV BND1      pool_choice_12[21]
 BV BND1      pool_choice_12[22]
 BV BND1      pool_choice_12[23]
 BV BND1      pool_choice_12[24]
 BV BND1      pool_choice_12[25]
 BV BND1      pool_choice_12[26]
 BV BND1      pool_choice_12[27]
 BV BND1      pool_choice_12[28]
 BV BND1      pool_choice_12[29]
 BV BND1      pool_choice_12[30]
 BV BND1      pool_choice_12[31]
 BV BND1      pool_choice_12[32]
 BV BND1      pool_choice_12[33]
 BV BND1      pool_choice_12[34]
 BV BND1      pool_choice_12[35]
 BV BND1      pool_choice_12[36]
 BV BND1      pool_choice_12[37]
 BV BND1      pool_choice_12[38]
 BV BND1      pool_choice_12[39]
 BV BND1      pool_choice_12[40]
 BV BND1      pool_choice_12[41]
 BV BND1      pool_choice_12[42]
 BV BND1      pool_choice_12[43]
 BV BND1      pool_choice_12[44]
 BV BND1      pool_choice_12[45]
 BV BND1      pool_choice_12[46]
 BV BND1      pool_choice_12[47]
 BV BND1      pool_choice_12[48]
 BV BND1      pool_choice_12[49]
 BV BND1      pool_choice_12[50]
 BV BND1      pool_choice_12[51]
 BV BND1      pool_choice_12[52]
 BV BND1      pool_choice_12[53]
 BV BND1      pool_choice_12[54]
 BV BND1      pool_choice_12[55]
 BV BND1      pool_used_12
 UP BND1      pool_start_12  75600
 UP BND1      pool_end_12  75600
 UP BND1      pool_start_rank_12  80
 UP BND1      pool_end_rank_12  80
 BV BND1      pool_first_12_C47_order_d
 BV BND1      pool_first_12_C88_order_d
 BV BND1      pool_first_12_C29_order_d
 BV BND1      pool_first_12_C47_order_p
 BV BND1      pool_first_12_C76_order_d
 BV BND1      pool_first_12_C88_order_p
 BV BND1      pool_first_12_C29_order_p
 BV BND1      pool_first_12_C27_order_d
 BV BND1      pool_first_12_C25_order_d
 BV BND1      pool_first_12_C76_order_p
 BV BND1      pool_first_12_C46_order_d
 BV BND1      pool_first_12_C6_order_d
 BV BND1      pool_first_12_C27_order_p
 BV BND1      pool_first_12_C25_order_p
 BV BND1      pool_first_12_C46_order_p
 BV BND1      pool_first_12_C6_order_p
 BV BND1      pool_last_12_C47_order_p
 BV BND1      pool_last_12_C88_order_p
 BV BND1      pool_last_12_C29_order_p
 BV BND1      pool_last_12_C47_order_d
 BV BND1      pool_last_12_C76_order_p
 BV BND1      pool_last_12_C88_order_d
 BV BND1      pool_last_12_C29_order_d
 BV BND1      pool_last_12_C27_order_p
 BV BND1      pool_last_12_C25_order_p
 BV BND1      pool_last_12_C76_order_d
 BV BND1      pool_last_12_C46_order_p
 BV BND1      pool_last_12_C6_order_p
 BV BND1      pool_last_12_C27_order_d
 BV BND1      pool_last_12_C25_order_d
 BV BND1      pool_last_12_C46_order_d
 BV BND1      pool_last_12_C6_order_d
 BV BND1      pool_pickup_12_C47_order
 BV BND1      pool_pickup_12_C88_order
 BV BND1      pool_pickup_12_C29_order
 BV BND1      pool_pickup_12_C76_order
 BV BND1      pool_pickup_12_C27_order
 BV BND1      pool_pickup_12_C25_order
 BV BND1      pool_pickup_12_C46_order
 BV BND1      pool_pickup_12_C6_order
 BV BND1      pool_batch_12_b2
 BV BND1      pool_batch_12_b1
 BV BND1      pool_batch_12_b3
 BV BND1      pool_choice_13[0]
 BV BND1      pool_choice_13[1]
 BV BND1      pool_choice_13[2]
 BV BND1      pool_choice_13[3]
 BV BND1      pool_choice_13[4]
 BV BND1      pool_choice_13[5]
 BV BND1      pool_choice_13[6]
 BV BND1      pool_choice_13[7]
 BV BND1      pool_choice_13[8]
 BV BND1      pool_choice_13[9]
 BV BND1      pool_choice_13[10]
 BV BND1      pool_choice_13[11]
 BV BND1      pool_choice_13[12]
 BV BND1      pool_choice_13[13]
 BV BND1      pool_choice_13[14]
 BV BND1      pool_choice_13[15]
 BV BND1      pool_choice_13[16]
 BV BND1      pool_choice_13[17]
 BV BND1      pool_choice_13[18]
 BV BND1      pool_choice_13[19]
 BV BND1      pool_choice_13[20]
 BV BND1      pool_choice_13[21]
 BV BND1      pool_choice_13[22]
 BV BND1      pool_choice_13[23]
 BV BND1      pool_choice_13[24]
 BV BND1      pool_choice_13[25]
 BV BND1      pool_choice_13[26]
 BV BND1      pool_choice_13[27]
 BV BND1      pool_choice_13[28]
 BV BND1      pool_choice_13[29]
 BV BND1      pool_choice_13[30]
 BV BND1      pool_choice_13[31]
 BV BND1      pool_choice_13[32]
 BV BND1      pool_choice_13[33]
 BV BND1      pool_choice_13[34]
 BV BND1      pool_choice_13[35]
 BV BND1      pool_choice_13[36]
 BV BND1      pool_choice_13[37]
 BV BND1      pool_choice_13[38]
 BV BND1      pool_choice_13[39]
 BV BND1      pool_choice_13[40]
 BV BND1      pool_choice_13[41]
 BV BND1      pool_choice_13[42]
 BV BND1      pool_choice_13[43]
 BV BND1      pool_choice_13[44]
 BV BND1      pool_choice_13[45]
 BV BND1      pool_choice_13[46]
 BV BND1      pool_choice_13[47]
 BV BND1      pool_choice_13[48]
 BV BND1      pool_choice_13[49]
 BV BND1      pool_choice_13[50]
 BV BND1      pool_choice_13[51]
 BV BND1      pool_choice_13[52]
 BV BND1      pool_used_13
 UP BND1      pool_start_13  75600
 UP BND1      pool_end_13  75600
 UP BND1      pool_start_rank_13  80
 UP BND1      pool_end_rank_13  80
 BV BND1      pool_first_13_C76_order_d
 BV BND1      pool_first_13_C88_order_d
 BV BND1      pool_first_13_C27_order_d
 BV BND1      pool_first_13_C88_order_p
 BV BND1      pool_first_13_C47_order_d
 BV BND1      pool_first_13_C29_order_d
 BV BND1      pool_first_13_C47_order_p
 BV BND1      pool_first_13_C76_order_p
 BV BND1      pool_first_13_C6_order_d
 BV BND1      pool_first_13_C25_order_d
 BV BND1      pool_last_13_C76_order_p
 BV BND1      pool_last_13_C47_order_p
 BV BND1      pool_last_13_C29_order_p
 BV BND1      pool_last_13_C25_order_p
 BV BND1      pool_last_13_C88_order_p
 BV BND1      pool_last_13_C27_order_p
 BV BND1      pool_last_13_C46_order_p
 BV BND1      pool_last_13_C6_order_p
 BV BND1      pool_last_13_C88_order_d
 BV BND1      pool_last_13_C47_order_d
 BV BND1      pool_last_13_C29_order_d
 BV BND1      pool_last_13_C76_order_d
 BV BND1      pool_last_13_C25_order_d
 BV BND1      pool_last_13_C6_order_d
 BV BND1      pool_last_13_C46_order_d
 BV BND1      pool_last_13_C27_order_d
 BV BND1      pool_pickup_13_C27_order
 BV BND1      pool_pickup_13_C76_order
 BV BND1      pool_pickup_13_C47_order
 BV BND1      pool_pickup_13_C29_order
 BV BND1      pool_pickup_13_C25_order
 BV BND1      pool_pickup_13_C88_order
 BV BND1      pool_pickup_13_C46_order
 BV BND1      pool_pickup_13_C6_order
 BV BND1      pool_batch_13_b1
 BV BND1      pool_batch_13_b2
 BV BND1      pool_batch_13_b3
 BV BND1      pool_choice_14[0]
 BV BND1      pool_choice_14[1]
 BV BND1      pool_choice_14[2]
 BV BND1      pool_choice_14[3]
 BV BND1      pool_choice_14[4]
 BV BND1      pool_choice_14[5]
 BV BND1      pool_choice_14[6]
 BV BND1      pool_choice_14[7]
 BV BND1      pool_choice_14[8]
 BV BND1      pool_choice_14[9]
 BV BND1      pool_choice_14[10]
 BV BND1      pool_choice_14[11]
 BV BND1      pool_choice_14[12]
 BV BND1      pool_choice_14[13]
 BV BND1      pool_choice_14[14]
 BV BND1      pool_choice_14[15]
 BV BND1      pool_choice_14[16]
 BV BND1      pool_choice_14[17]
 BV BND1      pool_choice_14[18]
 BV BND1      pool_choice_14[19]
 BV BND1      pool_choice_14[20]
 BV BND1      pool_choice_14[21]
 BV BND1      pool_choice_14[22]
 BV BND1      pool_choice_14[23]
 BV BND1      pool_choice_14[24]
 BV BND1      pool_choice_14[25]
 BV BND1      pool_choice_14[26]
 BV BND1      pool_choice_14[27]
 BV BND1      pool_choice_14[28]
 BV BND1      pool_choice_14[29]
 BV BND1      pool_choice_14[30]
 BV BND1      pool_choice_14[31]
 BV BND1      pool_choice_14[32]
 BV BND1      pool_choice_14[33]
 BV BND1      pool_choice_14[34]
 BV BND1      pool_choice_14[35]
 BV BND1      pool_choice_14[36]
 BV BND1      pool_choice_14[37]
 BV BND1      pool_choice_14[38]
 BV BND1      pool_choice_14[39]
 BV BND1      pool_choice_14[40]
 BV BND1      pool_choice_14[41]
 BV BND1      pool_choice_14[42]
 BV BND1      pool_choice_14[43]
 BV BND1      pool_choice_14[44]
 BV BND1      pool_choice_14[45]
 BV BND1      pool_choice_14[46]
 BV BND1      pool_choice_14[47]
 BV BND1      pool_choice_14[48]
 BV BND1      pool_choice_14[49]
 BV BND1      pool_choice_14[50]
 BV BND1      pool_choice_14[51]
 BV BND1      pool_choice_14[52]
 BV BND1      pool_choice_14[53]
 BV BND1      pool_choice_14[54]
 BV BND1      pool_choice_14[55]
 BV BND1      pool_choice_14[56]
 BV BND1      pool_choice_14[57]
 BV BND1      pool_used_14
 UP BND1      pool_start_14  75600
 UP BND1      pool_end_14  75600
 UP BND1      pool_start_rank_14  80
 UP BND1      pool_end_rank_14  80
 BV BND1      pool_first_14_C46_order_d
 BV BND1      pool_first_14_C47_order_d
 BV BND1      pool_first_14_C88_order_d
 BV BND1      pool_first_14_C29_order_d
 BV BND1      pool_first_14_C25_order_d
 BV BND1      pool_first_14_C6_order_d
 BV BND1      pool_first_14_C46_order_p
 BV BND1      pool_first_14_C88_order_p
 BV BND1      pool_first_14_C47_order_p
 BV BND1      pool_first_14_C76_order_p
 BV BND1      pool_first_14_C76_order_d
 BV BND1      pool_first_14_C27_order_d
 BV BND1      pool_last_14_C46_order_p
 BV BND1      pool_last_14_C47_order_p
 BV BND1      pool_last_14_C88_order_p
 BV BND1      pool_last_14_C29_order_p
 BV BND1      pool_last_14_C6_order_p
 BV BND1      pool_last_14_C25_order_p
 BV BND1      pool_last_14_C25_order_d
 BV BND1      pool_last_14_C46_order_d
 BV BND1      pool_last_14_C88_order_d
 BV BND1      pool_last_14_C47_order_d
 BV BND1      pool_last_14_C29_order_d
 BV BND1      pool_last_14_C76_order_d
 BV BND1      pool_last_14_C6_order_d
 BV BND1      pool_last_14_C27_order_d
 BV BND1      pool_pickup_14_C46_order
 BV BND1      pool_pickup_14_C47_order
 BV BND1      pool_pickup_14_C88_order
 BV BND1      pool_pickup_14_C29_order
 BV BND1      pool_pickup_14_C6_order
 BV BND1      pool_pickup_14_C25_order
 BV BND1      pool_pickup_14_C76_order
 BV BND1      pool_pickup_14_C27_order
 BV BND1      pool_batch_14_b2
 BV BND1      pool_batch_14_b1
 BV BND1      pool_batch_14_b3
 BV BND1      pool_choice_15[0]
 BV BND1      pool_choice_15[1]
 BV BND1      pool_choice_15[2]
 BV BND1      pool_choice_15[3]
 BV BND1      pool_choice_15[4]
 BV BND1      pool_choice_15[5]
 BV BND1      pool_choice_15[6]
 BV BND1      pool_choice_15[7]
 BV BND1      pool_choice_15[8]
 BV BND1      pool_choice_15[9]
 BV BND1      pool_choice_15[10]
 BV BND1      pool_choice_15[11]
 BV BND1      pool_choice_15[12]
 BV BND1      pool_choice_15[13]
 BV BND1      pool_choice_15[14]
 BV BND1      pool_choice_15[15]
 BV BND1      pool_choice_15[16]
 BV BND1      pool_choice_15[17]
 BV BND1      pool_choice_15[18]
 BV BND1      pool_choice_15[19]
 BV BND1      pool_choice_15[20]
 BV BND1      pool_choice_15[21]
 BV BND1      pool_choice_15[22]
 BV BND1      pool_choice_15[23]
 BV BND1      pool_choice_15[24]
 BV BND1      pool_choice_15[25]
 BV BND1      pool_choice_15[26]
 BV BND1      pool_choice_15[27]
 BV BND1      pool_choice_15[28]
 BV BND1      pool_choice_15[29]
 BV BND1      pool_choice_15[30]
 BV BND1      pool_choice_15[31]
 BV BND1      pool_choice_15[32]
 BV BND1      pool_choice_15[33]
 BV BND1      pool_choice_15[34]
 BV BND1      pool_choice_15[35]
 BV BND1      pool_choice_15[36]
 BV BND1      pool_choice_15[37]
 BV BND1      pool_choice_15[38]
 BV BND1      pool_choice_15[39]
 BV BND1      pool_choice_15[40]
 BV BND1      pool_choice_15[41]
 BV BND1      pool_choice_15[42]
 BV BND1      pool_choice_15[43]
 BV BND1      pool_choice_15[44]
 BV BND1      pool_choice_15[45]
 BV BND1      pool_used_15
 UP BND1      pool_start_15  75600
 UP BND1      pool_end_15  75600
 UP BND1      pool_start_rank_15  80
 UP BND1      pool_end_rank_15  80
 BV BND1      pool_first_15_C6_order_d
 BV BND1      pool_first_15_C88_order_d
 BV BND1      pool_first_15_C29_order_d
 BV BND1      pool_first_15_C46_order_d
 BV BND1      pool_first_15_C29_order_p
 BV BND1      pool_first_15_C6_order_p
 BV BND1      pool_first_15_C88_order_p
 BV BND1      pool_first_15_C47_order_d
 BV BND1      pool_first_15_C47_order_p
 BV BND1      pool_first_15_C76_order_p
 BV BND1      pool_first_15_C76_order_d
 BV BND1      pool_first_15_C27_order_d
 BV BND1      pool_first_15_C25_order_d
 BV BND1      pool_last_15_C6_order_p
 BV BND1      pool_last_15_C88_order_p
 BV BND1      pool_last_15_C29_order_p
 BV BND1      pool_last_15_C46_order_p
 BV BND1      pool_last_15_C6_order_d
 BV BND1      pool_last_15_C88_order_d
 BV BND1      pool_last_15_C47_order_d
 BV BND1      pool_last_15_C47_order_p
 BV BND1      pool_last_15_C29_order_d
 BV BND1      pool_last_15_C76_order_d
 BV BND1      pool_last_15_C25_order_d
 BV BND1      pool_last_15_C46_order_d
 BV BND1      pool_last_15_C27_order_d
 BV BND1      pool_pickup_15_C6_order
 BV BND1      pool_pickup_15_C88_order
 BV BND1      pool_pickup_15_C29_order
 BV BND1      pool_pickup_15_C46_order
 BV BND1      pool_pickup_15_C47_order
 BV BND1      pool_pickup_15_C76_order
 BV BND1      pool_pickup_15_C25_order
 BV BND1      pool_pickup_15_C27_order
 BV BND1      pool_batch_15_b3
 BV BND1      pool_batch_15_b1
 BV BND1      pool_batch_15_b2
 BV BND1      pool_choice_16[0]
 BV BND1      pool_choice_16[1]
 BV BND1      pool_choice_16[2]
 BV BND1      pool_choice_16[3]
 BV BND1      pool_choice_16[4]
 BV BND1      pool_choice_16[5]
 BV BND1      pool_choice_16[6]
 BV BND1      pool_choice_16[7]
 BV BND1      pool_choice_16[8]
 BV BND1      pool_used_16
 UP BND1      pool_start_16  75600
 UP BND1      pool_end_16  75600
 UP BND1      pool_start_rank_16  80
 UP BND1      pool_end_rank_16  80
 BV BND1      pool_first_16_C95_order_d
 BV BND1      pool_first_16_C95_order_p
 BV BND1      pool_first_16_C34_order_d
 BV BND1      pool_first_16_C34_order_p
 BV BND1      pool_last_16_C95_order_p
 BV BND1      pool_last_16_C95_order_d
 BV BND1      pool_last_16_C34_order_p
 BV BND1      pool_last_16_C34_order_d
 BV BND1      pool_pickup_16_C95_order
 BV BND1      pool_pickup_16_C34_order
 BV BND1      pool_batch_16_b2
 BV BND1      pool_batch_16_b1
 BV BND1      pool_choice_17[0]
 BV BND1      pool_choice_17[1]
 BV BND1      pool_choice_17[2]
 BV BND1      pool_choice_17[3]
 BV BND1      pool_choice_17[4]
 BV BND1      pool_choice_17[5]
 BV BND1      pool_choice_17[6]
 BV BND1      pool_choice_17[7]
 BV BND1      pool_choice_17[8]
 BV BND1      pool_used_17
 UP BND1      pool_start_17  75600
 UP BND1      pool_end_17  75600
 UP BND1      pool_start_rank_17  80
 UP BND1      pool_end_rank_17  80
 BV BND1      pool_first_17_C95_order_d
 BV BND1      pool_first_17_C95_order_p
 BV BND1      pool_first_17_C34_order_d
 BV BND1      pool_first_17_C34_order_p
 BV BND1      pool_last_17_C95_order_p
 BV BND1      pool_last_17_C95_order_d
 BV BND1      pool_last_17_C34_order_p
 BV BND1      pool_last_17_C34_order_d
 BV BND1      pool_pickup_17_C95_order
 BV BND1      pool_pickup_17_C34_order
 BV BND1      pool_batch_17_b2
 BV BND1      pool_batch_17_b1
 BV BND1      pool_choice_18[0]
 BV BND1      pool_choice_18[1]
 BV BND1      pool_choice_18[2]
 BV BND1      pool_choice_18[3]
 BV BND1      pool_choice_18[4]
 BV BND1      pool_choice_18[5]
 BV BND1      pool_choice_18[6]
 BV BND1      pool_choice_18[7]
 BV BND1      pool_choice_18[8]
 BV BND1      pool_used_18
 UP BND1      pool_start_18  75600
 UP BND1      pool_end_18  75600
 UP BND1      pool_start_rank_18  80
 UP BND1      pool_end_rank_18  80
 BV BND1      pool_first_18_C95_order_d
 BV BND1      pool_first_18_C95_order_p
 BV BND1      pool_first_18_C34_order_d
 BV BND1      pool_first_18_C34_order_p
 BV BND1      pool_last_18_C95_order_p
 BV BND1      pool_last_18_C95_order_d
 BV BND1      pool_last_18_C34_order_p
 BV BND1      pool_last_18_C34_order_d
 BV BND1      pool_pickup_18_C95_order
 BV BND1      pool_pickup_18_C34_order
 BV BND1      pool_batch_18_b2
 BV BND1      pool_batch_18_b1
 BV BND1      pool_choice_19[0]
 BV BND1      pool_choice_19[1]
 BV BND1      pool_choice_19[2]
 BV BND1      pool_choice_19[3]
 BV BND1      pool_choice_19[4]
 BV BND1      pool_choice_19[5]
 BV BND1      pool_choice_19[6]
 BV BND1      pool_choice_19[7]
 BV BND1      pool_choice_19[8]
 BV BND1      pool_used_19
 UP BND1      pool_start_19  75600
 UP BND1      pool_end_19  75600
 UP BND1      pool_start_rank_19  80
 UP BND1      pool_end_rank_19  80
 BV BND1      pool_first_19_C34_order_d
 BV BND1      pool_first_19_C95_order_d
 BV BND1      pool_first_19_C34_order_p
 BV BND1      pool_first_19_C95_order_p
 BV BND1      pool_last_19_C34_order_p
 BV BND1      pool_last_19_C95_order_p
 BV BND1      pool_last_19_C34_order_d
 BV BND1      pool_last_19_C95_order_d
 BV BND1      pool_pickup_19_C34_order
 BV BND1      pool_pickup_19_C95_order
 BV BND1      pool_batch_19_b1
 BV BND1      pool_batch_19_b2
 BV BND1      pool_link_0
 BV BND1      pool_link_1
 BV BND1      pool_link_2
 BV BND1      pool_link_3
 BV BND1      pool_link_4
 BV BND1      pool_link_5
 BV BND1      pool_link_6
 BV BND1      pool_link_7
 BV BND1      pool_link_8
 BV BND1      pool_link_9
 BV BND1      pool_link_10
 BV BND1      pool_link_11
 BV BND1      pool_link_12
 BV BND1      pool_link_13
 BV BND1      pool_link_14
 BV BND1      pool_link_15
 BV BND1      pool_link_16
 BV BND1      pool_link_17
 BV BND1      pool_link_18
 BV BND1      pool_link_19
 BV BND1      pool_link_20
 BV BND1      pool_link_21
 BV BND1      pool_link_22
 BV BND1      pool_link_23
 BV BND1      pool_link_24
 BV BND1      pool_link_25
 BV BND1      pool_link_26
 BV BND1      pool_link_27
 BV BND1      pool_link_28
 BV BND1      pool_link_29
 BV BND1      pool_link_30
 BV BND1      pool_link_31
 BV BND1      pool_link_32
 BV BND1      pool_link_33
 BV BND1      pool_link_34
 BV BND1      pool_link_35
 BV BND1      pool_link_36
 BV BND1      pool_link_37
 BV BND1      pool_link_38
 BV BND1      pool_link_39
 BV BND1      pool_link_40
 BV BND1      pool_link_41
 BV BND1      pool_link_42
 BV BND1      pool_link_43
 BV BND1      pool_link_44
 BV BND1      pool_link_45
 BV BND1      pool_link_46
 BV BND1      pool_link_47
 BV BND1      pool_link_48
 BV BND1      pool_link_49
 BV BND1      pool_link_50
 BV BND1      pool_link_51
 BV BND1      pool_link_52
 BV BND1      pool_link_53
 BV BND1      pool_link_54
 BV BND1      pool_link_55
 BV BND1      pool_link_56
 BV BND1      pool_link_57
 BV BND1      pool_link_58
 BV BND1      pool_link_59
 BV BND1      pool_link_60
 BV BND1      pool_link_61
 BV BND1      pool_link_62
 BV BND1      pool_link_63
 BV BND1      pool_link_64
 BV BND1      pool_link_65
 BV BND1      pool_link_66
 BV BND1      pool_link_67
 BV BND1      pool_link_68
 BV BND1      pool_link_69
 BV BND1      pool_link_70
 BV BND1      pool_link_71
 BV BND1      pool_link_72
 BV BND1      pool_link_73
 BV BND1      pool_link_74
 BV BND1      pool_link_75
 BV BND1      pool_link_76
 BV BND1      pool_link_77
 BV BND1      pool_link_78
 BV BND1      pool_link_79
 BV BND1      pool_link_80
 BV BND1      pool_link_81
 BV BND1      pool_link_82
 BV BND1      pool_link_83
 BV BND1      pool_link_84
 BV BND1      pool_link_85
 BV BND1      pool_link_86
 BV BND1      pool_link_87
 BV BND1      pool_link_88
 BV BND1      pool_link_89
 BV BND1      pool_link_90
 BV BND1      pool_link_91
 BV BND1      pool_link_92
 BV BND1      pool_link_93
 BV BND1      pool_link_94
 BV BND1      pool_link_95
 BV BND1      pool_link_96
 BV BND1      pool_link_97
 BV BND1      pool_link_98
 BV BND1      pool_link_99
 BV BND1      pool_link_100
 BV BND1      pool_link_101
 BV BND1      pool_link_102
 BV BND1      pool_link_103
 BV BND1      pool_link_104
 BV BND1      pool_link_105
 BV BND1      pool_link_106
 BV BND1      pool_link_107
 BV BND1      pool_link_108
 BV BND1      pool_link_109
 BV BND1      pool_link_110
 BV BND1      pool_link_111
 BV BND1      pool_link_112
 BV BND1      pool_link_113
 BV BND1      pool_link_114
 BV BND1      pool_link_115
 BV BND1      pool_link_116
 BV BND1      pool_link_117
 BV BND1      pool_link_118
 BV BND1      pool_link_119
 BV BND1      pool_link_120
 BV BND1      pool_link_121
 BV BND1      pool_link_122
 BV BND1      pool_link_123
 BV BND1      pool_link_124
 BV BND1      pool_link_125
 BV BND1      pool_link_126
 BV BND1      pool_link_127
 BV BND1      pool_link_128
 BV BND1      pool_link_129
 BV BND1      pool_link_130
 BV BND1      pool_link_131
 BV BND1      pool_link_132
 BV BND1      pool_link_133
 BV BND1      pool_link_134
 BV BND1      pool_link_135
 BV BND1      pool_link_136
 BV BND1      pool_link_137
 BV BND1      pool_link_138
 BV BND1      pool_link_139
 BV BND1      pool_link_140
 BV BND1      pool_link_141
 BV BND1      pool_link_142
 BV BND1      pool_link_143
 BV BND1      pool_link_144
 BV BND1      pool_link_145
 BV BND1      pool_link_146
 BV BND1      pool_link_147
 BV BND1      pool_link_148
INDICATORS
 IF GC0       cutoff_C81_order_b1  1
 IF GC1       cutoff_C81_order_b1  1
 IF GC2       cutoff_C81_order_b2  1
 IF GC3       cutoff_C81_order_b2  1
 IF GC4       cutoff_C81_order_b3  1
 IF GC5       cutoff_C81_order_b3  1
 IF GC6       cutoff_C90_order_b1  1
 IF GC7       cutoff_C90_order_b1  1
 IF GC8       cutoff_C90_order_b2  1
 IF GC9       cutoff_C90_order_b2  1
 IF GC10      cutoff_C90_order_b3  1
 IF GC11      cutoff_C90_order_b3  1
 IF GC12      cutoff_C97_order_b1  1
 IF GC13      cutoff_C97_order_b1  1
 IF GC14      cutoff_C97_order_b2  1
 IF GC15      cutoff_C97_order_b2  1
 IF GC16      cutoff_C97_order_b3  1
 IF GC17      cutoff_C97_order_b3  1
 IF GC18      cutoff_C51_order_b1  1
 IF GC19      cutoff_C51_order_b1  1
 IF GC20      cutoff_C51_order_b2  1
 IF GC21      cutoff_C51_order_b2  1
 IF GC22      cutoff_C51_order_b3  1
 IF GC23      cutoff_C51_order_b3  1
 IF GC24      cutoff_C0_order_b1  1
 IF GC25      cutoff_C0_order_b1  1
 IF GC26      cutoff_C0_order_b2  1
 IF GC27      cutoff_C0_order_b2  1
 IF GC28      cutoff_C0_order_b3  1
 IF GC29      cutoff_C0_order_b3  1
 IF GC30      cutoff_C39_order_b1  1
 IF GC31      cutoff_C39_order_b1  1
 IF GC32      cutoff_C39_order_b2  1
 IF GC33      cutoff_C39_order_b2  1
 IF GC34      cutoff_C39_order_b3  1
 IF GC35      cutoff_C39_order_b3  1
 IF GC36      cutoff_C52_order_b1  1
 IF GC37      cutoff_C52_order_b1  1
 IF GC38      cutoff_C52_order_b2  1
 IF GC39      cutoff_C52_order_b2  1
 IF GC40      cutoff_C52_order_b3  1
 IF GC41      cutoff_C52_order_b3  1
 IF GC42      cutoff_C85_order_b1  1
 IF GC43      cutoff_C85_order_b1  1
 IF GC44      cutoff_C85_order_b2  1
 IF GC45      cutoff_C85_order_b2  1
 IF GC46      cutoff_C85_order_b3  1
 IF GC47      cutoff_C85_order_b3  1
 IF GC48      cutoff_C75_order_b1  1
 IF GC49      cutoff_C75_order_b1  1
 IF GC50      cutoff_C75_order_b2  1
 IF GC51      cutoff_C75_order_b2  1
 IF GC52      cutoff_C75_order_b3  1
 IF GC53      cutoff_C75_order_b3  1
 IF GC54      cutoff_C21_order_b1  1
 IF GC55      cutoff_C21_order_b1  1
 IF GC56      cutoff_C21_order_b2  1
 IF GC57      cutoff_C21_order_b2  1
 IF GC58      cutoff_C21_order_b3  1
 IF GC59      cutoff_C21_order_b3  1
 IF GC60      cutoff_C88_order_b1  1
 IF GC61      cutoff_C88_order_b1  1
 IF GC62      cutoff_C88_order_b2  1
 IF GC63      cutoff_C88_order_b2  1
 IF GC64      cutoff_C88_order_b3  1
 IF GC65      cutoff_C88_order_b3  1
 IF GC66      cutoff_C76_order_b1  1
 IF GC67      cutoff_C76_order_b1  1
 IF GC68      cutoff_C76_order_b2  1
 IF GC69      cutoff_C76_order_b2  1
 IF GC70      cutoff_C76_order_b3  1
 IF GC71      cutoff_C76_order_b3  1
 IF GC72      cutoff_C27_order_b1  1
 IF GC73      cutoff_C27_order_b1  1
 IF GC74      cutoff_C27_order_b2  1
 IF GC75      cutoff_C27_order_b2  1
 IF GC76      cutoff_C27_order_b3  1
 IF GC77      cutoff_C27_order_b3  1
 IF GC78      cutoff_C47_order_b1  1
 IF GC79      cutoff_C47_order_b1  1
 IF GC80      cutoff_C47_order_b2  1
 IF GC81      cutoff_C47_order_b2  1
 IF GC82      cutoff_C47_order_b3  1
 IF GC83      cutoff_C47_order_b3  1
 IF GC84      cutoff_C25_order_b1  1
 IF GC85      cutoff_C25_order_b1  1
 IF GC86      cutoff_C25_order_b2  1
 IF GC87      cutoff_C25_order_b2  1
 IF GC88      cutoff_C25_order_b3  1
 IF GC89      cutoff_C25_order_b3  1
 IF GC90      cutoff_C46_order_b1  1
 IF GC91      cutoff_C46_order_b1  1
 IF GC92      cutoff_C46_order_b2  1
 IF GC93      cutoff_C46_order_b2  1
 IF GC94      cutoff_C46_order_b3  1
 IF GC95      cutoff_C46_order_b3  1
 IF GC96      cutoff_C29_order_b1  1
 IF GC97      cutoff_C29_order_b1  1
 IF GC98      cutoff_C29_order_b2  1
 IF GC99      cutoff_C29_order_b2  1
 IF GC100     cutoff_C29_order_b3  1
 IF GC101     cutoff_C29_order_b3  1
 IF GC102     cutoff_C6_order_b1  1
 IF GC103     cutoff_C6_order_b1  1
 IF GC104     cutoff_C6_order_b2  1
 IF GC105     cutoff_C6_order_b2  1
 IF GC106     cutoff_C6_order_b3  1
 IF GC107     cutoff_C6_order_b3  1
 IF GC108     cutoff_C34_order_b1  1
 IF GC109     cutoff_C34_order_b1  1
 IF GC110     cutoff_C34_order_b2  1
 IF GC111     cutoff_C34_order_b2  1
 IF GC112     cutoff_C34_order_b3  1
 IF GC113     cutoff_C34_order_b3  1
 IF GC114     cutoff_C95_order_b1  1
 IF GC115     cutoff_C95_order_b1  1
 IF GC116     cutoff_C95_order_b2  1
 IF GC117     cutoff_C95_order_b2  1
 IF GC118     cutoff_C95_order_b3  1
 IF GC119     cutoff_C95_order_b3  1
 IF GC120     pool_first_0_C85_order_d  1
 IF GC121     pool_first_0_C85_order_d  1
 IF GC122     pool_first_0_C85_order_p  1
 IF GC123     pool_first_0_C85_order_p  1
 IF GC124     pool_first_0_C81_order_d  1
 IF GC125     pool_first_0_C81_order_d  1
 IF GC126     pool_first_0_C90_order_d  1
 IF GC127     pool_first_0_C90_order_d  1
 IF GC128     pool_first_0_C0_order_d  1
 IF GC129     pool_first_0_C0_order_d  1
 IF GC130     pool_first_0_C75_order_d  1
 IF GC131     pool_first_0_C75_order_d  1
 IF GC132     pool_first_0_C81_order_p  1
 IF GC133     pool_first_0_C81_order_p  1
 IF GC134     pool_first_0_C90_order_p  1
 IF GC135     pool_first_0_C90_order_p  1
 IF GC136     pool_first_0_C97_order_d  1
 IF GC137     pool_first_0_C97_order_d  1
 IF GC138     pool_first_0_C39_order_d  1
 IF GC139     pool_first_0_C39_order_d  1
 IF GC140     pool_first_0_C21_order_d  1
 IF GC141     pool_first_0_C21_order_d  1
 IF GC142     pool_first_0_C0_order_p  1
 IF GC143     pool_first_0_C0_order_p  1
 IF GC144     pool_first_0_C52_order_d  1
 IF GC145     pool_first_0_C52_order_d  1
 IF GC146     pool_first_0_C51_order_d  1
 IF GC147     pool_first_0_C51_order_d  1
 IF GC148     pool_first_0_C75_order_p  1
 IF GC149     pool_first_0_C75_order_p  1
 IF GC150     pool_first_0_C97_order_p  1
 IF GC151     pool_first_0_C97_order_p  1
 IF GC152     pool_first_0_C39_order_p  1
 IF GC153     pool_first_0_C39_order_p  1
 IF GC154     pool_first_0_C21_order_p  1
 IF GC155     pool_first_0_C21_order_p  1
 IF GC156     pool_first_0_C52_order_p  1
 IF GC157     pool_first_0_C52_order_p  1
 IF GC158     pool_first_0_C51_order_p  1
 IF GC159     pool_first_0_C51_order_p  1
 IF GC160     pool_last_0_C85_order_p  1
 IF GC161     pool_last_0_C85_order_p  1
 IF GC162     pool_last_0_C85_order_d  1
 IF GC163     pool_last_0_C85_order_d  1
 IF GC164     pool_last_0_C81_order_p  1
 IF GC165     pool_last_0_C81_order_p  1
 IF GC166     pool_last_0_C90_order_p  1
 IF GC167     pool_last_0_C90_order_p  1
 IF GC168     pool_last_0_C0_order_p  1
 IF GC169     pool_last_0_C0_order_p  1
 IF GC170     pool_last_0_C75_order_p  1
 IF GC171     pool_last_0_C75_order_p  1
 IF GC172     pool_last_0_C81_order_d  1
 IF GC173     pool_last_0_C81_order_d  1
 IF GC174     pool_last_0_C90_order_d  1
 IF GC175     pool_last_0_C90_order_d  1
 IF GC176     pool_last_0_C97_order_p  1
 IF GC177     pool_last_0_C97_order_p  1
 IF GC178     pool_last_0_C39_order_p  1
 IF GC179     pool_last_0_C39_order_p  1
 IF GC180     pool_last_0_C21_order_p  1
 IF GC181     pool_last_0_C21_order_p  1
 IF GC182     pool_last_0_C0_order_d  1
 IF GC183     pool_last_0_C0_order_d  1
 IF GC184     pool_last_0_C52_order_p  1
 IF GC185     pool_last_0_C52_order_p  1
 IF GC186     pool_last_0_C51_order_p  1
 IF GC187     pool_last_0_C51_order_p  1
 IF GC188     pool_last_0_C75_order_d  1
 IF GC189     pool_last_0_C75_order_d  1
 IF GC190     pool_last_0_C97_order_d  1
 IF GC191     pool_last_0_C97_order_d  1
 IF GC192     pool_last_0_C39_order_d  1
 IF GC193     pool_last_0_C39_order_d  1
 IF GC194     pool_last_0_C21_order_d  1
 IF GC195     pool_last_0_C21_order_d  1
 IF GC196     pool_last_0_C52_order_d  1
 IF GC197     pool_last_0_C52_order_d  1
 IF GC198     pool_last_0_C51_order_d  1
 IF GC199     pool_last_0_C51_order_d  1
 IF GC200     pool_pickup_0_C85_order  1
 IF GC201     pool_pickup_0_C81_order  1
 IF GC202     pool_pickup_0_C90_order  1
 IF GC203     pool_pickup_0_C0_order  1
 IF GC204     pool_pickup_0_C75_order  1
 IF GC205     pool_pickup_0_C97_order  1
 IF GC206     pool_pickup_0_C39_order  1
 IF GC207     pool_pickup_0_C21_order  1
 IF GC208     pool_pickup_0_C52_order  1
 IF GC209     pool_pickup_0_C51_order  1
 IF GC210     pool_batch_0_b3  1
 IF GC211     pool_batch_0_b1  1
 IF GC212     pool_batch_0_b2  1
 IF GC213     pool_first_1_C81_order_d  1
 IF GC214     pool_first_1_C81_order_d  1
 IF GC215     pool_first_1_C90_order_d  1
 IF GC216     pool_first_1_C90_order_d  1
 IF GC217     pool_first_1_C97_order_d  1
 IF GC218     pool_first_1_C97_order_d  1
 IF GC219     pool_first_1_C85_order_p  1
 IF GC220     pool_first_1_C85_order_p  1
 IF GC221     pool_first_1_C0_order_d  1
 IF GC222     pool_first_1_C0_order_d  1
 IF GC223     pool_first_1_C85_order_d  1
 IF GC224     pool_first_1_C85_order_d  1
 IF GC225     pool_first_1_C81_order_p  1
 IF GC226     pool_first_1_C81_order_p  1
 IF GC227     pool_first_1_C90_order_p  1
 IF GC228     pool_first_1_C90_order_p  1
 IF GC229     pool_first_1_C39_order_d  1
 IF GC230     pool_first_1_C39_order_d  1
 IF GC231     pool_first_1_C75_order_d  1
 IF GC232     pool_first_1_C75_order_d  1
 IF GC233     pool_last_1_C81_order_p  1
 IF GC234     pool_last_1_C81_order_p  1
 IF GC235     pool_last_1_C90_order_p  1
 IF GC236     pool_last_1_C90_order_p  1
 IF GC237     pool_last_1_C97_order_p  1
 IF GC238     pool_last_1_C97_order_p  1
 IF GC239     pool_last_1_C21_order_p  1
 IF GC240     pool_last_1_C21_order_p  1
 IF GC241     pool_last_1_C85_order_p  1
 IF GC242     pool_last_1_C85_order_p  1
 IF GC243     pool_last_1_C90_order_d  1
 IF GC244     pool_last_1_C90_order_d  1
 IF GC245     pool_last_1_C39_order_d  1
 IF GC246     pool_last_1_C39_order_d  1
 IF GC247     pool_last_1_C85_order_d  1
 IF GC248     pool_last_1_C85_order_d  1
 IF GC249     pool_last_1_C81_order_d  1
 IF GC250     pool_last_1_C81_order_d  1
 IF GC251     pool_last_1_C0_order_d  1
 IF GC252     pool_last_1_C0_order_d  1
 IF GC253     pool_last_1_C75_order_d  1
 IF GC254     pool_last_1_C75_order_d  1
 IF GC255     pool_last_1_C52_order_d  1
 IF GC256     pool_last_1_C52_order_d  1
 IF GC257     pool_last_1_C75_order_p  1
 IF GC258     pool_last_1_C75_order_p  1
 IF GC259     pool_last_1_C21_order_d  1
 IF GC260     pool_last_1_C21_order_d  1
 IF GC261     pool_last_1_C51_order_d  1
 IF GC262     pool_last_1_C51_order_d  1
 IF GC263     pool_pickup_1_C51_order  1
 IF GC264     pool_pickup_1_C97_order  1
 IF GC265     pool_pickup_1_C81_order  1
 IF GC266     pool_pickup_1_C90_order  1
 IF GC267     pool_pickup_1_C21_order  1
 IF GC268     pool_pickup_1_C85_order  1
 IF GC269     pool_pickup_1_C0_order  1
 IF GC270     pool_pickup_1_C75_order  1
 IF GC271     pool_batch_1_b1  1
 IF GC272     pool_batch_1_b2  1
 IF GC273     pool_batch_1_b3  1
 IF GC274     pool_first_2_C0_order_d  1
 IF GC275     pool_first_2_C0_order_d  1
 IF GC276     pool_first_2_C90_order_d  1
 IF GC277     pool_first_2_C90_order_d  1
 IF GC278     pool_first_2_C75_order_d  1
 IF GC279     pool_first_2_C75_order_d  1
 IF GC280     pool_first_2_C39_order_d  1
 IF GC281     pool_first_2_C39_order_d  1
 IF GC282     pool_first_2_C85_order_d  1
 IF GC283     pool_first_2_C85_order_d  1
 IF GC284     pool_first_2_C0_order_p  1
 IF GC285     pool_first_2_C0_order_p  1
 IF GC286     pool_first_2_C85_order_p  1
 IF GC287     pool_first_2_C85_order_p  1
 IF GC288     pool_first_2_C81_order_d  1
 IF GC289     pool_first_2_C81_order_d  1
 IF GC290     pool_first_2_C81_order_p  1
 IF GC291     pool_first_2_C81_order_p  1
 IF GC292     pool_first_2_C90_order_p  1
 IF GC293     pool_first_2_C90_order_p  1
 IF GC294     pool_first_2_C52_order_d  1
 IF GC295     pool_first_2_C52_order_d  1
 IF GC296     pool_first_2_C21_order_d  1
 IF GC297     pool_first_2_C21_order_d  1
 IF GC298     pool_last_2_C0_order_p  1
 IF GC299     pool_last_2_C0_order_p  1
 IF GC300     pool_last_2_C85_order_p  1
 IF GC301     pool_last_2_C85_order_p  1
 IF GC302     pool_last_2_C90_order_p  1
 IF GC303     pool_last_2_C90_order_p  1
 IF GC304     pool_last_2_C75_order_p  1
 IF GC305     pool_last_2_C75_order_p  1
 IF GC306     pool_last_2_C21_order_p  1
 IF GC307     pool_last_2_C21_order_p  1
 IF GC308     pool_last_2_C39_order_p  1
 IF GC309     pool_last_2_C39_order_p  1
 IF GC310     pool_last_2_C52_order_p  1
 IF GC311     pool_last_2_C52_order_p  1
 IF GC312     pool_last_2_C21_order_d  1
 IF GC313     pool_last_2_C21_order_d  1
 IF GC314     pool_last_2_C0_order_d  1
 IF GC315     pool_last_2_C0_order_d  1
 IF GC316     pool_last_2_C52_order_d  1
 IF GC317     pool_last_2_C52_order_d  1
 IF GC318     pool_last_2_C90_order_d  1
 IF GC319     pool_last_2_C90_order_d  1
 IF GC320     pool_last_2_C39_order_d  1
 IF GC321     pool_last_2_C39_order_d  1
 IF GC322     pool_last_2_C85_order_d  1
 IF GC323     pool_last_2_C85_order_d  1
 IF GC324     pool_last_2_C81_order_d  1
 IF GC325     pool_last_2_C81_order_d  1
 IF GC326     pool_last_2_C75_order_d  1
 IF GC327     pool_last_2_C75_order_d  1
 IF GC328     pool_last_2_C51_order_d  1
 IF GC329     pool_last_2_C51_order_d  1
 IF GC330     pool_pickup_2_C0_order  1
 IF GC331     pool_pickup_2_C85_order  1
 IF GC332     pool_pickup_2_C90_order  1
 IF GC333     pool_pickup_2_C75_order  1
 IF GC334     pool_pickup_2_C39_order  1
 IF GC335     pool_pickup_2_C21_order  1
 IF GC336     pool_pickup_2_C52_order  1
 IF GC337     pool_pickup_2_C81_order  1
 IF GC338     pool_batch_2_b2  1
 IF GC339     pool_batch_2_b1  1
 IF GC340     pool_batch_2_b3  1
 IF GC341     pool_first_3_C85_order_d  1
 IF GC342     pool_first_3_C85_order_d  1
 IF GC343     pool_first_3_C90_order_d  1
 IF GC344     pool_first_3_C90_order_d  1
 IF GC345     pool_first_3_C0_order_d  1
 IF GC346     pool_first_3_C0_order_d  1
 IF GC347     pool_first_3_C21_order_d  1
 IF GC348     pool_first_3_C21_order_d  1
 IF GC349     pool_first_3_C75_order_d  1
 IF GC350     pool_first_3_C75_order_d  1
 IF GC351     pool_first_3_C85_order_p  1
 IF GC352     pool_first_3_C85_order_p  1
 IF GC353     pool_first_3_C81_order_d  1
 IF GC354     pool_first_3_C81_order_d  1
 IF GC355     pool_first_3_C81_order_p  1
 IF GC356     pool_first_3_C81_order_p  1
 IF GC357     pool_first_3_C90_order_p  1
 IF GC358     pool_first_3_C90_order_p  1
 IF GC359     pool_first_3_C39_order_d  1
 IF GC360     pool_first_3_C39_order_d  1
 IF GC361     pool_first_3_C52_order_d  1
 IF GC362     pool_first_3_C52_order_d  1
 IF GC363     pool_last_3_C85_order_p  1
 IF GC364     pool_last_3_C85_order_p  1
 IF GC365     pool_last_3_C75_order_p  1
 IF GC366     pool_last_3_C75_order_p  1
 IF GC367     pool_last_3_C21_order_p  1
 IF GC368     pool_last_3_C21_order_p  1
 IF GC369     pool_last_3_C90_order_d  1
 IF GC370     pool_last_3_C90_order_d  1
 IF GC371     pool_last_3_C39_order_d  1
 IF GC372     pool_last_3_C39_order_d  1
 IF GC373     pool_last_3_C85_order_d  1
 IF GC374     pool_last_3_C85_order_d  1
 IF GC375     pool_last_3_C81_order_d  1
 IF GC376     pool_last_3_C81_order_d  1
 IF GC377     pool_last_3_C0_order_d  1
 IF GC378     pool_last_3_C0_order_d  1
 IF GC379     pool_last_3_C75_order_d  1
 IF GC380     pool_last_3_C75_order_d  1
 IF GC381     pool_last_3_C52_order_d  1
 IF GC382     pool_last_3_C52_order_d  1
 IF GC383     pool_last_3_C21_order_d  1
 IF GC384     pool_last_3_C21_order_d  1
 IF GC385     pool_last_3_C51_order_d  1
 IF GC386     pool_last_3_C51_order_d  1
 IF GC387     pool_pickup_3_C21_order  1
 IF GC388     pool_pickup_3_C85_order  1
 IF GC389     pool_pickup_3_C75_order  1
 IF GC390     pool_pickup_3_C90_order  1
 IF GC391     pool_pickup_3_C0_order  1
 IF GC392     pool_pickup_3_C81_order  1
 IF GC393     pool_pickup_3_C39_order  1
 IF GC394     pool_batch_3_b3  1
 IF GC395     pool_batch_3_b1  1
 IF GC396     pool_batch_3_b2  1
 IF GC397     pool_first_4_C85_order_d  1
 IF GC398     pool_first_4_C85_order_d  1
 IF GC399     pool_first_4_C85_order_p  1
 IF GC400     pool_first_4_C85_order_p  1
 IF GC401     pool_first_4_C81_order_d  1
 IF GC402     pool_first_4_C81_order_d  1
 IF GC403     pool_first_4_C90_order_d  1
 IF GC404     pool_first_4_C90_order_d  1
 IF GC405     pool_first_4_C0_order_d  1
 IF GC406     pool_first_4_C0_order_d  1
 IF GC407     pool_first_4_C75_order_d  1
 IF GC408     pool_first_4_C75_order_d  1
 IF GC409     pool_first_4_C81_order_p  1
 IF GC410     pool_first_4_C81_order_p  1
 IF GC411     pool_first_4_C90_order_p  1
 IF GC412     pool_first_4_C90_order_p  1
 IF GC413     pool_first_4_C97_order_d  1
 IF GC414     pool_first_4_C97_order_d  1
 IF GC415     pool_first_4_C39_order_d  1
 IF GC416     pool_first_4_C39_order_d  1
 IF GC417     pool_first_4_C21_order_d  1
 IF GC418     pool_first_4_C21_order_d  1
 IF GC419     pool_first_4_C0_order_p  1
 IF GC420     pool_first_4_C0_order_p  1
 IF GC421     pool_first_4_C52_order_d  1
 IF GC422     pool_first_4_C52_order_d  1
 IF GC423     pool_first_4_C51_order_d  1
 IF GC424     pool_first_4_C51_order_d  1
 IF GC425     pool_first_4_C75_order_p  1
 IF GC426     pool_first_4_C75_order_p  1
 IF GC427     pool_first_4_C97_order_p  1
 IF GC428     pool_first_4_C97_order_p  1
 IF GC429     pool_first_4_C39_order_p  1
 IF GC430     pool_first_4_C39_order_p  1
 IF GC431     pool_first_4_C21_order_p  1
 IF GC432     pool_first_4_C21_order_p  1
 IF GC433     pool_first_4_C52_order_p  1
 IF GC434     pool_first_4_C52_order_p  1
 IF GC435     pool_first_4_C51_order_p  1
 IF GC436     pool_first_4_C51_order_p  1
 IF GC437     pool_last_4_C85_order_p  1
 IF GC438     pool_last_4_C85_order_p  1
 IF GC439     pool_last_4_C85_order_d  1
 IF GC440     pool_last_4_C85_order_d  1
 IF GC441     pool_last_4_C81_order_p  1
 IF GC442     pool_last_4_C81_order_p  1
 IF GC443     pool_last_4_C90_order_p  1
 IF GC444     pool_last_4_C90_order_p  1
 IF GC445     pool_last_4_C0_order_p  1
 IF GC446     pool_last_4_C0_order_p  1
 IF GC447     pool_last_4_C75_order_p  1
 IF GC448     pool_last_4_C75_order_p  1
 IF GC449     pool_last_4_C81_order_d  1
 IF GC450     pool_last_4_C81_order_d  1
 IF GC451     pool_last_4_C90_order_d  1
 IF GC452     pool_last_4_C90_order_d  1
 IF GC453     pool_last_4_C97_order_p  1
 IF GC454     pool_last_4_C97_order_p  1
 IF GC455     pool_last_4_C39_order_p  1
 IF GC456     pool_last_4_C39_order_p  1
 IF GC457     pool_last_4_C21_order_p  1
 IF GC458     pool_last_4_C21_order_p  1
 IF GC459     pool_last_4_C0_order_d  1
 IF GC460     pool_last_4_C0_order_d  1
 IF GC461     pool_last_4_C52_order_p  1
 IF GC462     pool_last_4_C52_order_p  1
 IF GC463     pool_last_4_C51_order_p  1
 IF GC464     pool_last_4_C51_order_p  1
 IF GC465     pool_last_4_C75_order_d  1
 IF GC466     pool_last_4_C75_order_d  1
 IF GC467     pool_last_4_C97_order_d  1
 IF GC468     pool_last_4_C97_order_d  1
 IF GC469     pool_last_4_C39_order_d  1
 IF GC470     pool_last_4_C39_order_d  1
 IF GC471     pool_last_4_C21_order_d  1
 IF GC472     pool_last_4_C21_order_d  1
 IF GC473     pool_last_4_C52_order_d  1
 IF GC474     pool_last_4_C52_order_d  1
 IF GC475     pool_last_4_C51_order_d  1
 IF GC476     pool_last_4_C51_order_d  1
 IF GC477     pool_pickup_4_C85_order  1
 IF GC478     pool_pickup_4_C81_order  1
 IF GC479     pool_pickup_4_C90_order  1
 IF GC480     pool_pickup_4_C0_order  1
 IF GC481     pool_pickup_4_C75_order  1
 IF GC482     pool_pickup_4_C97_order  1
 IF GC483     pool_pickup_4_C39_order  1
 IF GC484     pool_pickup_4_C21_order  1
 IF GC485     pool_pickup_4_C52_order  1
 IF GC486     pool_pickup_4_C51_order  1
 IF GC487     pool_batch_4_b3  1
 IF GC488     pool_batch_4_b1  1
 IF GC489     pool_batch_4_b2  1
 IF GC490     pool_first_5_C90_order_d  1
 IF GC491     pool_first_5_C90_order_d  1
 IF GC492     pool_first_5_C81_order_d  1
 IF GC493     pool_first_5_C81_order_d  1
 IF GC494     pool_first_5_C0_order_d  1
 IF GC495     pool_first_5_C0_order_d  1
 IF GC496     pool_first_5_C75_order_d  1
 IF GC497     pool_first_5_C75_order_d  1
 IF GC498     pool_first_5_C97_order_d  1
 IF GC499     pool_first_5_C97_order_d  1
 IF GC500     pool_first_5_C90_order_p  1
 IF GC501     pool_first_5_C90_order_p  1
 IF GC502     pool_first_5_C51_order_d  1
 IF GC503     pool_first_5_C51_order_d  1
 IF GC504     pool_first_5_C85_order_d  1
 IF GC505     pool_first_5_C85_order_d  1
 IF GC506     pool_first_5_C39_order_d  1
 IF GC507     pool_first_5_C39_order_d  1
 IF GC508     pool_first_5_C85_order_p  1
 IF GC509     pool_first_5_C85_order_p  1
 IF GC510     pool_first_5_C81_order_p  1
 IF GC511     pool_first_5_C81_order_p  1
 IF GC512     pool_first_5_C52_order_d  1
 IF GC513     pool_first_5_C52_order_d  1
 IF GC514     pool_first_5_C21_order_d  1
 IF GC515     pool_first_5_C21_order_d  1
 IF GC516     pool_last_5_C90_order_p  1
 IF GC517     pool_last_5_C90_order_p  1
 IF GC518     pool_last_5_C85_order_p  1
 IF GC519     pool_last_5_C85_order_p  1
 IF GC520     pool_last_5_C81_order_p  1
 IF GC521     pool_last_5_C81_order_p  1
 IF GC522     pool_last_5_C0_order_p  1
 IF GC523     pool_last_5_C0_order_p  1
 IF GC524     pool_last_5_C75_order_p  1
 IF GC525     pool_last_5_C75_order_p  1
 IF GC526     pool_last_5_C97_order_p  1
 IF GC527     pool_last_5_C97_order_p  1
 IF GC528     pool_last_5_C21_order_p  1
 IF GC529     pool_last_5_C21_order_p  1
 IF GC530     pool_last_5_C39_order_p  1
 IF GC531     pool_last_5_C39_order_p  1
 IF GC532     pool_last_5_C90_order_d  1
 IF GC533     pool_last_5_C90_order_d  1
 IF GC534     pool_last_5_C52_order_p  1
 IF GC535     pool_last_5_C52_order_p  1
 IF GC536     pool_last_5_C51_order_p  1
 IF GC537     pool_last_5_C51_order_p  1
 IF GC538     pool_last_5_C21_order_d  1
 IF GC539     pool_last_5_C21_order_d  1
 IF GC540     pool_last_5_C52_order_d  1
 IF GC541     pool_last_5_C52_order_d  1
 IF GC542     pool_last_5_C39_order_d  1
 IF GC543     pool_last_5_C39_order_d  1
 IF GC544     pool_last_5_C85_order_d  1
 IF GC545     pool_last_5_C85_order_d  1
 IF GC546     pool_last_5_C81_order_d  1
 IF GC547     pool_last_5_C81_order_d  1
 IF GC548     pool_last_5_C0_order_d  1
 IF GC549     pool_last_5_C0_order_d  1
 IF GC550     pool_last_5_C75_order_d  1
 IF GC551     pool_last_5_C75_order_d  1
 IF GC552     pool_last_5_C51_order_d  1
 IF GC553     pool_last_5_C51_order_d  1
 IF GC554     pool_pickup_5_C90_order  1
 IF GC555     pool_pickup_5_C85_order  1
 IF GC556     pool_pickup_5_C81_order  1
 IF GC557     pool_pickup_5_C0_order  1
 IF GC558     pool_pickup_5_C75_order  1
 IF GC559     pool_pickup_5_C97_order  1
 IF GC560     pool_pickup_5_C51_order  1
 IF GC561     pool_pickup_5_C21_order  1
 IF GC562     pool_pickup_5_C39_order  1
 IF GC563     pool_pickup_5_C52_order  1
 IF GC564     pool_batch_5_b1  1
 IF GC565     pool_batch_5_b2  1
 IF GC566     pool_batch_5_b3  1
 IF GC567     pool_first_6_C39_order_d  1
 IF GC568     pool_first_6_C39_order_d  1
 IF GC569     pool_first_6_C90_order_d  1
 IF GC570     pool_first_6_C90_order_d  1
 IF GC571     pool_first_6_C52_order_d  1
 IF GC572     pool_first_6_C52_order_d  1
 IF GC573     pool_first_6_C0_order_d  1
 IF GC574     pool_first_6_C0_order_d  1
 IF GC575     pool_first_6_C85_order_p  1
 IF GC576     pool_first_6_C85_order_p  1
 IF GC577     pool_first_6_C81_order_d  1
 IF GC578     pool_first_6_C81_order_d  1
 IF GC579     pool_first_6_C85_order_d  1
 IF GC580     pool_first_6_C85_order_d  1
 IF GC581     pool_first_6_C81_order_p  1
 IF GC582     pool_first_6_C81_order_p  1
 IF GC583     pool_first_6_C90_order_p  1
 IF GC584     pool_first_6_C90_order_p  1
 IF GC585     pool_first_6_C75_order_d  1
 IF GC586     pool_first_6_C75_order_d  1
 IF GC587     pool_last_6_C39_order_p  1
 IF GC588     pool_last_6_C39_order_p  1
 IF GC589     pool_last_6_C85_order_p  1
 IF GC590     pool_last_6_C85_order_p  1
 IF GC591     pool_last_6_C21_order_p  1
 IF GC592     pool_last_6_C21_order_p  1
 IF GC593     pool_last_6_C0_order_p  1
 IF GC594     pool_last_6_C0_order_p  1
 IF GC595     pool_last_6_C75_order_p  1
 IF GC596     pool_last_6_C75_order_p  1
 IF GC597     pool_last_6_C52_order_p  1
 IF GC598     pool_last_6_C52_order_p  1
 IF GC599     pool_last_6_C90_order_d  1
 IF GC600     pool_last_6_C90_order_d  1
 IF GC601     pool_last_6_C39_order_d  1
 IF GC602     pool_last_6_C39_order_d  1
 IF GC603     pool_last_6_C85_order_d  1
 IF GC604     pool_last_6_C85_order_d  1
 IF GC605     pool_last_6_C81_order_d  1
 IF GC606     pool_last_6_C81_order_d  1
 IF GC607     pool_last_6_C0_order_d  1
 IF GC608     pool_last_6_C0_order_d  1
 IF GC609     pool_last_6_C75_order_d  1
 IF GC610     pool_last_6_C75_order_d  1
 IF GC611     pool_last_6_C52_order_d  1
 IF GC612     pool_last_6_C52_order_d  1
 IF GC613     pool_last_6_C21_order_d  1
 IF GC614     pool_last_6_C21_order_d  1
 IF GC615     pool_last_6_C51_order_d  1
 IF GC616     pool_last_6_C51_order_d  1
 IF GC617     pool_pickup_6_C52_order  1
 IF GC618     pool_pickup_6_C39_order  1
 IF GC619     pool_pickup_6_C85_order  1
 IF GC620     pool_pickup_6_C21_order  1
 IF GC621     pool_pickup_6_C0_order  1
 IF GC622     pool_pickup_6_C75_order  1
 IF GC623     pool_pickup_6_C90_order  1
 IF GC624     pool_pickup_6_C81_order  1
 IF GC625     pool_batch_6_b2  1
 IF GC626     pool_batch_6_b1  1
 IF GC627     pool_batch_6_b3  1
 IF GC628     pool_first_7_C75_order_d  1
 IF GC629     pool_first_7_C75_order_d  1
 IF GC630     pool_first_7_C85_order_d  1
 IF GC631     pool_first_7_C85_order_d  1
 IF GC632     pool_first_7_C90_order_d  1
 IF GC633     pool_first_7_C90_order_d  1
 IF GC634     pool_first_7_C0_order_d  1
 IF GC635     pool_first_7_C0_order_d  1
 IF GC636     pool_first_7_C21_order_d  1
 IF GC637     pool_first_7_C21_order_d  1
 IF GC638     pool_first_7_C75_order_p  1
 IF GC639     pool_first_7_C75_order_p  1
 IF GC640     pool_first_7_C85_order_p  1
 IF GC641     pool_first_7_C85_order_p  1
 IF GC642     pool_first_7_C81_order_d  1
 IF GC643     pool_first_7_C81_order_d  1
 IF GC644     pool_first_7_C81_order_p  1
 IF GC645     pool_first_7_C81_order_p  1
 IF GC646     pool_first_7_C90_order_p  1
 IF GC647     pool_first_7_C90_order_p  1
 IF GC648     pool_first_7_C39_order_d  1
 IF GC649     pool_first_7_C39_order_d  1
 IF GC650     pool_first_7_C52_order_d  1
 IF GC651     pool_first_7_C52_order_d  1
 IF GC652     pool_last_7_C75_order_p  1
 IF GC653     pool_last_7_C75_order_p  1
 IF GC654     pool_last_7_C85_order_p  1
 IF GC655     pool_last_7_C85_order_p  1
 IF GC656     pool_last_7_C90_order_p  1
 IF GC657     pool_last_7_C90_order_p  1
 IF GC658     pool_last_7_C0_order_p  1
 IF GC659     pool_last_7_C0_order_p  1
 IF GC660     pool_last_7_C21_order_p  1
 IF GC661     pool_last_7_C21_order_p  1
 IF GC662     pool_last_7_C21_order_d  1
 IF GC663     pool_last_7_C21_order_d  1
 IF GC664     pool_last_7_C75_order_d  1
 IF GC665     pool_last_7_C75_order_d  1
 IF GC666     pool_last_7_C90_order_d  1
 IF GC667     pool_last_7_C90_order_d  1
 IF GC668     pool_last_7_C39_order_d  1
 IF GC669     pool_last_7_C39_order_d  1
 IF GC670     pool_last_7_C85_order_d  1
 IF GC671     pool_last_7_C85_order_d  1
 IF GC672     pool_last_7_C81_order_d  1
 IF GC673     pool_last_7_C81_order_d  1
 IF GC674     pool_last_7_C0_order_d  1
 IF GC675     pool_last_7_C0_order_d  1
 IF GC676     pool_last_7_C52_order_d  1
 IF GC677     pool_last_7_C52_order_d  1
 IF GC678     pool_last_7_C51_order_d  1
 IF GC679     pool_last_7_C51_order_d  1
 IF GC680     pool_pickup_7_C75_order  1
 IF GC681     pool_pickup_7_C85_order  1
 IF GC682     pool_pickup_7_C90_order  1
 IF GC683     pool_pickup_7_C0_order  1
 IF GC684     pool_pickup_7_C21_order  1
 IF GC685     pool_pickup_7_C81_order  1
 IF GC686     pool_pickup_7_C39_order  1
 IF GC687     pool_batch_7_b3  1
 IF GC688     pool_batch_7_b1  1
 IF GC689     pool_batch_7_b2  1
 IF GC690     pool_first_8_C47_order_d  1
 IF GC691     pool_first_8_C47_order_d  1
 IF GC692     pool_first_8_C88_order_d  1
 IF GC693     pool_first_8_C88_order_d  1
 IF GC694     pool_first_8_C29_order_d  1
 IF GC695     pool_first_8_C29_order_d  1
 IF GC696     pool_first_8_C47_order_p  1
 IF GC697     pool_first_8_C47_order_p  1
 IF GC698     pool_first_8_C76_order_d  1
 IF GC699     pool_first_8_C76_order_d  1
 IF GC700     pool_first_8_C88_order_p  1
 IF GC701     pool_first_8_C88_order_p  1
 IF GC702     pool_first_8_C29_order_p  1
 IF GC703     pool_first_8_C29_order_p  1
 IF GC704     pool_first_8_C27_order_d  1
 IF GC705     pool_first_8_C27_order_d  1
 IF GC706     pool_first_8_C25_order_d  1
 IF GC707     pool_first_8_C25_order_d  1
 IF GC708     pool_first_8_C76_order_p  1
 IF GC709     pool_first_8_C76_order_p  1
 IF GC710     pool_first_8_C46_order_d  1
 IF GC711     pool_first_8_C46_order_d  1
 IF GC712     pool_first_8_C6_order_d  1
 IF GC713     pool_first_8_C6_order_d  1
 IF GC714     pool_first_8_C27_order_p  1
 IF GC715     pool_first_8_C27_order_p  1
 IF GC716     pool_first_8_C25_order_p  1
 IF GC717     pool_first_8_C25_order_p  1
 IF GC718     pool_first_8_C46_order_p  1
 IF GC719     pool_first_8_C46_order_p  1
 IF GC720     pool_first_8_C6_order_p  1
 IF GC721     pool_first_8_C6_order_p  1
 IF GC722     pool_last_8_C47_order_p  1
 IF GC723     pool_last_8_C47_order_p  1
 IF GC724     pool_last_8_C88_order_p  1
 IF GC725     pool_last_8_C88_order_p  1
 IF GC726     pool_last_8_C29_order_p  1
 IF GC727     pool_last_8_C29_order_p  1
 IF GC728     pool_last_8_C47_order_d  1
 IF GC729     pool_last_8_C47_order_d  1
 IF GC730     pool_last_8_C76_order_p  1
 IF GC731     pool_last_8_C76_order_p  1
 IF GC732     pool_last_8_C88_order_d  1
 IF GC733     pool_last_8_C88_order_d  1
 IF GC734     pool_last_8_C29_order_d  1
 IF GC735     pool_last_8_C29_order_d  1
 IF GC736     pool_last_8_C27_order_p  1
 IF GC737     pool_last_8_C27_order_p  1
 IF GC738     pool_last_8_C25_order_p  1
 IF GC739     pool_last_8_C25_order_p  1
 IF GC740     pool_last_8_C76_order_d  1
 IF GC741     pool_last_8_C76_order_d  1
 IF GC742     pool_last_8_C46_order_p  1
 IF GC743     pool_last_8_C46_order_p  1
 IF GC744     pool_last_8_C6_order_p  1
 IF GC745     pool_last_8_C6_order_p  1
 IF GC746     pool_last_8_C27_order_d  1
 IF GC747     pool_last_8_C27_order_d  1
 IF GC748     pool_last_8_C25_order_d  1
 IF GC749     pool_last_8_C25_order_d  1
 IF GC750     pool_last_8_C46_order_d  1
 IF GC751     pool_last_8_C46_order_d  1
 IF GC752     pool_last_8_C6_order_d  1
 IF GC753     pool_last_8_C6_order_d  1
 IF GC754     pool_pickup_8_C47_order  1
 IF GC755     pool_pickup_8_C88_order  1
 IF GC756     pool_pickup_8_C29_order  1
 IF GC757     pool_pickup_8_C76_order  1
 IF GC758     pool_pickup_8_C27_order  1
 IF GC759     pool_pickup_8_C25_order  1
 IF GC760     pool_pickup_8_C46_order  1
 IF GC761     pool_pickup_8_C6_order  1
 IF GC762     pool_batch_8_b2  1
 IF GC763     pool_batch_8_b1  1
 IF GC764     pool_batch_8_b3  1
 IF GC765     pool_first_9_C88_order_d  1
 IF GC766     pool_first_9_C88_order_d  1
 IF GC767     pool_first_9_C29_order_d  1
 IF GC768     pool_first_9_C29_order_d  1
 IF GC769     pool_first_9_C76_order_d  1
 IF GC770     pool_first_9_C76_order_d  1
 IF GC771     pool_first_9_C88_order_p  1
 IF GC772     pool_first_9_C88_order_p  1
 IF GC773     pool_first_9_C47_order_d  1
 IF GC774     pool_first_9_C47_order_d  1
 IF GC775     pool_first_9_C46_order_d  1
 IF GC776     pool_first_9_C46_order_d  1
 IF GC777     pool_first_9_C6_order_d  1
 IF GC778     pool_first_9_C6_order_d  1
 IF GC779     pool_first_9_C47_order_p  1
 IF GC780     pool_first_9_C47_order_p  1
 IF GC781     pool_first_9_C76_order_p  1
 IF GC782     pool_first_9_C76_order_p  1
 IF GC783     pool_first_9_C27_order_d  1
 IF GC784     pool_first_9_C27_order_d  1
 IF GC785     pool_first_9_C25_order_d  1
 IF GC786     pool_first_9_C25_order_d  1
 IF GC787     pool_last_9_C88_order_p  1
 IF GC788     pool_last_9_C88_order_p  1
 IF GC789     pool_last_9_C29_order_p  1
 IF GC790     pool_last_9_C29_order_p  1
 IF GC791     pool_last_9_C47_order_p  1
 IF GC792     pool_last_9_C47_order_p  1
 IF GC793     pool_last_9_C76_order_p  1
 IF GC794     pool_last_9_C76_order_p  1
 IF GC795     pool_last_9_C88_order_d  1
 IF GC796     pool_last_9_C88_order_d  1
 IF GC797     pool_last_9_C27_order_p  1
 IF GC798     pool_last_9_C27_order_p  1
 IF GC799     pool_last_9_C25_order_p  1
 IF GC800     pool_last_9_C25_order_p  1
 IF GC801     pool_last_9_C46_order_p  1
 IF GC802     pool_last_9_C46_order_p  1
 IF GC803     pool_last_9_C27_order_d  1
 IF GC804     pool_last_9_C27_order_d  1
 IF GC805     pool_last_9_C6_order_p  1
 IF GC806     pool_last_9_C6_order_p  1
 IF GC807     pool_last_9_C25_order_d  1
 IF GC808     pool_last_9_C25_order_d  1
 IF GC809     pool_last_9_C47_order_d  1
 IF GC810     pool_last_9_C47_order_d  1
 IF GC811     pool_last_9_C29_order_d  1
 IF GC812     pool_last_9_C29_order_d  1
 IF GC813     pool_last_9_C76_order_d  1
 IF GC814     pool_last_9_C76_order_d  1
 IF GC815     pool_last_9_C6_order_d  1
 IF GC816     pool_last_9_C6_order_d  1
 IF GC817     pool_last_9_C46_order_d  1
 IF GC818     pool_last_9_C46_order_d  1
 IF GC819     pool_pickup_9_C88_order  1
 IF GC820     pool_pickup_9_C29_order  1
 IF GC821     pool_pickup_9_C47_order  1
 IF GC822     pool_pickup_9_C76_order  1
 IF GC823     pool_pickup_9_C27_order  1
 IF GC824     pool_pickup_9_C25_order  1
 IF GC825     pool_pickup_9_C46_order  1
 IF GC826     pool_pickup_9_C6_order  1
 IF GC827     pool_batch_9_b1  1
 IF GC828     pool_batch_9_b3  1
 IF GC829     pool_batch_9_b2  1
 IF GC830     pool_first_10_C47_order_d  1
 IF GC831     pool_first_10_C47_order_d  1
 IF GC832     pool_first_10_C25_order_d  1
 IF GC833     pool_first_10_C25_order_d  1
 IF GC834     pool_first_10_C88_order_d  1
 IF GC835     pool_first_10_C88_order_d  1
 IF GC836     pool_first_10_C46_order_d  1
 IF GC837     pool_first_10_C46_order_d  1
 IF GC838     pool_first_10_C88_order_p  1
 IF GC839     pool_first_10_C88_order_p  1
 IF GC840     pool_first_10_C29_order_d  1
 IF GC841     pool_first_10_C29_order_d  1
 IF GC842     pool_first_10_C47_order_p  1
 IF GC843     pool_first_10_C47_order_p  1
 IF GC844     pool_first_10_C76_order_p  1
 IF GC845     pool_first_10_C76_order_p  1
 IF GC846     pool_first_10_C76_order_d  1
 IF GC847     pool_first_10_C76_order_d  1
 IF GC848     pool_first_10_C6_order_d  1
 IF GC849     pool_first_10_C6_order_d  1
 IF GC850     pool_first_10_C27_order_d  1
 IF GC851     pool_first_10_C27_order_d  1
 IF GC852     pool_last_10_C47_order_p  1
 IF GC853     pool_last_10_C47_order_p  1
 IF GC854     pool_last_10_C29_order_p  1
 IF GC855     pool_last_10_C29_order_p  1
 IF GC856     pool_last_10_C25_order_p  1
 IF GC857     pool_last_10_C25_order_p  1
 IF GC858     pool_last_10_C46_order_p  1
 IF GC859     pool_last_10_C46_order_p  1
 IF GC860     pool_last_10_C6_order_p  1
 IF GC861     pool_last_10_C6_order_p  1
 IF GC862     pool_last_10_C88_order_d  1
 IF GC863     pool_last_10_C88_order_d  1
 IF GC864     pool_last_10_C47_order_d  1
 IF GC865     pool_last_10_C47_order_d  1
 IF GC866     pool_last_10_C29_order_d  1
 IF GC867     pool_last_10_C29_order_d  1
 IF GC868     pool_last_10_C76_order_d  1
 IF GC869     pool_last_10_C76_order_d  1
 IF GC870     pool_last_10_C88_order_p  1
 IF GC871     pool_last_10_C88_order_p  1
 IF GC872     pool_last_10_C25_order_d  1
 IF GC873     pool_last_10_C25_order_d  1
 IF GC874     pool_last_10_C6_order_d  1
 IF GC875     pool_last_10_C6_order_d  1
 IF GC876     pool_last_10_C46_order_d  1
 IF GC877     pool_last_10_C46_order_d  1
 IF GC878     pool_last_10_C27_order_d  1
 IF GC879     pool_last_10_C27_order_d  1
 IF GC880     pool_pickup_10_C25_order  1
 IF GC881     pool_pickup_10_C47_order  1
 IF GC882     pool_pickup_10_C29_order  1
 IF GC883     pool_pickup_10_C88_order  1
 IF GC884     pool_pickup_10_C46_order  1
 IF GC885     pool_pickup_10_C6_order  1
 IF GC886     pool_pickup_10_C76_order  1
 IF GC887     pool_pickup_10_C27_order  1
 IF GC888     pool_batch_10_b2  1
 IF GC889     pool_batch_10_b1  1
 IF GC890     pool_batch_10_b3  1
 IF GC891     pool_first_11_C29_order_d  1
 IF GC892     pool_first_11_C29_order_d  1
 IF GC893     pool_first_11_C88_order_d  1
 IF GC894     pool_first_11_C88_order_d  1
 IF GC895     pool_first_11_C29_order_p  1
 IF GC896     pool_first_11_C29_order_p  1
 IF GC897     pool_first_11_C46_order_d  1
 IF GC898     pool_first_11_C46_order_d  1
 IF GC899     pool_first_11_C6_order_d  1
 IF GC900     pool_first_11_C6_order_d  1
 IF GC901     pool_first_11_C88_order_p  1
 IF GC902     pool_first_11_C88_order_p  1
 IF GC903     pool_first_11_C47_order_d  1
 IF GC904     pool_first_11_C47_order_d  1
 IF GC905     pool_first_11_C47_order_p  1
 IF GC906     pool_first_11_C47_order_p  1
 IF GC907     pool_first_11_C76_order_p  1
 IF GC908     pool_first_11_C76_order_p  1
 IF GC909     pool_first_11_C76_order_d  1
 IF GC910     pool_first_11_C76_order_d  1
 IF GC911     pool_first_11_C27_order_d  1
 IF GC912     pool_first_11_C27_order_d  1
 IF GC913     pool_first_11_C25_order_d  1
 IF GC914     pool_first_11_C25_order_d  1
 IF GC915     pool_last_11_C29_order_p  1
 IF GC916     pool_last_11_C29_order_p  1
 IF GC917     pool_last_11_C88_order_p  1
 IF GC918     pool_last_11_C88_order_p  1
 IF GC919     pool_last_11_C29_order_d  1
 IF GC920     pool_last_11_C29_order_d  1
 IF GC921     pool_last_11_C6_order_p  1
 IF GC922     pool_last_11_C6_order_p  1
 IF GC923     pool_last_11_C46_order_p  1
 IF GC924     pool_last_11_C46_order_p  1
 IF GC925     pool_last_11_C6_order_d  1
 IF GC926     pool_last_11_C6_order_d  1
 IF GC927     pool_last_11_C88_order_d  1
 IF GC928     pool_last_11_C88_order_d  1
 IF GC929     pool_last_11_C47_order_d  1
 IF GC930     pool_last_11_C47_order_d  1
 IF GC931     pool_last_11_C47_order_p  1
 IF GC932     pool_last_11_C47_order_p  1
 IF GC933     pool_last_11_C76_order_d  1
 IF GC934     pool_last_11_C76_order_d  1
 IF GC935     pool_last_11_C25_order_d  1
 IF GC936     pool_last_11_C25_order_d  1
 IF GC937     pool_last_11_C46_order_d  1
 IF GC938     pool_last_11_C46_order_d  1
 IF GC939     pool_last_11_C27_order_d  1
 IF GC940     pool_last_11_C27_order_d  1
 IF GC941     pool_pickup_11_C29_order  1
 IF GC942     pool_pickup_11_C88_order  1
 IF GC943     pool_pickup_11_C6_order  1
 IF GC944     pool_pickup_11_C46_order  1
 IF GC945     pool_pickup_11_C47_order  1
 IF GC946     pool_pickup_11_C76_order  1
 IF GC947     pool_pickup_11_C25_order  1
 IF GC948     pool_pickup_11_C27_order  1
 IF GC949     pool_batch_11_b3  1
 IF GC950     pool_batch_11_b1  1
 IF GC951     pool_batch_11_b2  1
 IF GC952     pool_first_12_C47_order_d  1
 IF GC953     pool_first_12_C47_order_d  1
 IF GC954     pool_first_12_C88_order_d  1
 IF GC955     pool_first_12_C88_order_d  1
 IF GC956     pool_first_12_C29_order_d  1
 IF GC957     pool_first_12_C29_order_d  1
 IF GC958     pool_first_12_C47_order_p  1
 IF GC959     pool_first_12_C47_order_p  1
 IF GC960     pool_first_12_C76_order_d  1
 IF GC961     pool_first_12_C76_order_d  1
 IF GC962     pool_first_12_C88_order_p  1
 IF GC963     pool_first_12_C88_order_p  1
 IF GC964     pool_first_12_C29_order_p  1
 IF GC965     pool_first_12_C29_order_p  1
 IF GC966     pool_first_12_C27_order_d  1
 IF GC967     pool_first_12_C27_order_d  1
 IF GC968     pool_first_12_C25_order_d  1
 IF GC969     pool_first_12_C25_order_d  1
 IF GC970     pool_first_12_C76_order_p  1
 IF GC971     pool_first_12_C76_order_p  1
 IF GC972     pool_first_12_C46_order_d  1
 IF GC973     pool_first_12_C46_order_d  1
 IF GC974     pool_first_12_C6_order_d  1
 IF GC975     pool_first_12_C6_order_d  1
 IF GC976     pool_first_12_C27_order_p  1
 IF GC977     pool_first_12_C27_order_p  1
 IF GC978     pool_first_12_C25_order_p  1
 IF GC979     pool_first_12_C25_order_p  1
 IF GC980     pool_first_12_C46_order_p  1
 IF GC981     pool_first_12_C46_order_p  1
 IF GC982     pool_first_12_C6_order_p  1
 IF GC983     pool_first_12_C6_order_p  1
 IF GC984     pool_last_12_C47_order_p  1
 IF GC985     pool_last_12_C47_order_p  1
 IF GC986     pool_last_12_C88_order_p  1
 IF GC987     pool_last_12_C88_order_p  1
 IF GC988     pool_last_12_C29_order_p  1
 IF GC989     pool_last_12_C29_order_p  1
 IF GC990     pool_last_12_C47_order_d  1
 IF GC991     pool_last_12_C47_order_d  1
 IF GC992     pool_last_12_C76_order_p  1
 IF GC993     pool_last_12_C76_order_p  1
 IF GC994     pool_last_12_C88_order_d  1
 IF GC995     pool_last_12_C88_order_d  1
 IF GC996     pool_last_12_C29_order_d  1
 IF GC997     pool_last_12_C29_order_d  1
 IF GC998     pool_last_12_C27_order_p  1
 IF GC999     pool_last_12_C27_order_p  1
 IF GC1000    pool_last_12_C25_order_p  1
 IF GC1001    pool_last_12_C25_order_p  1
 IF GC1002    pool_last_12_C76_order_d  1
 IF GC1003    pool_last_12_C76_order_d  1
 IF GC1004    pool_last_12_C46_order_p  1
 IF GC1005    pool_last_12_C46_order_p  1
 IF GC1006    pool_last_12_C6_order_p  1
 IF GC1007    pool_last_12_C6_order_p  1
 IF GC1008    pool_last_12_C27_order_d  1
 IF GC1009    pool_last_12_C27_order_d  1
 IF GC1010    pool_last_12_C25_order_d  1
 IF GC1011    pool_last_12_C25_order_d  1
 IF GC1012    pool_last_12_C46_order_d  1
 IF GC1013    pool_last_12_C46_order_d  1
 IF GC1014    pool_last_12_C6_order_d  1
 IF GC1015    pool_last_12_C6_order_d  1
 IF GC1016    pool_pickup_12_C47_order  1
 IF GC1017    pool_pickup_12_C88_order  1
 IF GC1018    pool_pickup_12_C29_order  1
 IF GC1019    pool_pickup_12_C76_order  1
 IF GC1020    pool_pickup_12_C27_order  1
 IF GC1021    pool_pickup_12_C25_order  1
 IF GC1022    pool_pickup_12_C46_order  1
 IF GC1023    pool_pickup_12_C6_order  1
 IF GC1024    pool_batch_12_b2  1
 IF GC1025    pool_batch_12_b1  1
 IF GC1026    pool_batch_12_b3  1
 IF GC1027    pool_first_13_C76_order_d  1
 IF GC1028    pool_first_13_C76_order_d  1
 IF GC1029    pool_first_13_C88_order_d  1
 IF GC1030    pool_first_13_C88_order_d  1
 IF GC1031    pool_first_13_C27_order_d  1
 IF GC1032    pool_first_13_C27_order_d  1
 IF GC1033    pool_first_13_C88_order_p  1
 IF GC1034    pool_first_13_C88_order_p  1
 IF GC1035    pool_first_13_C47_order_d  1
 IF GC1036    pool_first_13_C47_order_d  1
 IF GC1037    pool_first_13_C29_order_d  1
 IF GC1038    pool_first_13_C29_order_d  1
 IF GC1039    pool_first_13_C47_order_p  1
 IF GC1040    pool_first_13_C47_order_p  1
 IF GC1041    pool_first_13_C76_order_p  1
 IF GC1042    pool_first_13_C76_order_p  1
 IF GC1043    pool_first_13_C6_order_d  1
 IF GC1044    pool_first_13_C6_order_d  1
 IF GC1045    pool_first_13_C25_order_d  1
 IF GC1046    pool_first_13_C25_order_d  1
 IF GC1047    pool_last_13_C76_order_p  1
 IF GC1048    pool_last_13_C76_order_p  1
 IF GC1049    pool_last_13_C47_order_p  1
 IF GC1050    pool_last_13_C47_order_p  1
 IF GC1051    pool_last_13_C29_order_p  1
 IF GC1052    pool_last_13_C29_order_p  1
 IF GC1053    pool_last_13_C25_order_p  1
 IF GC1054    pool_last_13_C25_order_p  1
 IF GC1055    pool_last_13_C88_order_p  1
 IF GC1056    pool_last_13_C88_order_p  1
 IF GC1057    pool_last_13_C27_order_p  1
 IF GC1058    pool_last_13_C27_order_p  1
 IF GC1059    pool_last_13_C46_order_p  1
 IF GC1060    pool_last_13_C46_order_p  1
 IF GC1061    pool_last_13_C6_order_p  1
 IF GC1062    pool_last_13_C6_order_p  1
 IF GC1063    pool_last_13_C88_order_d  1
 IF GC1064    pool_last_13_C88_order_d  1
 IF GC1065    pool_last_13_C47_order_d  1
 IF GC1066    pool_last_13_C47_order_d  1
 IF GC1067    pool_last_13_C29_order_d  1
 IF GC1068    pool_last_13_C29_order_d  1
 IF GC1069    pool_last_13_C76_order_d  1
 IF GC1070    pool_last_13_C76_order_d  1
 IF GC1071    pool_last_13_C25_order_d  1
 IF GC1072    pool_last_13_C25_order_d  1
 IF GC1073    pool_last_13_C6_order_d  1
 IF GC1074    pool_last_13_C6_order_d  1
 IF GC1075    pool_last_13_C46_order_d  1
 IF GC1076    pool_last_13_C46_order_d  1
 IF GC1077    pool_last_13_C27_order_d  1
 IF GC1078    pool_last_13_C27_order_d  1
 IF GC1079    pool_pickup_13_C27_order  1
 IF GC1080    pool_pickup_13_C76_order  1
 IF GC1081    pool_pickup_13_C47_order  1
 IF GC1082    pool_pickup_13_C29_order  1
 IF GC1083    pool_pickup_13_C25_order  1
 IF GC1084    pool_pickup_13_C88_order  1
 IF GC1085    pool_pickup_13_C46_order  1
 IF GC1086    pool_pickup_13_C6_order  1
 IF GC1087    pool_batch_13_b1  1
 IF GC1088    pool_batch_13_b2  1
 IF GC1089    pool_batch_13_b3  1
 IF GC1090    pool_first_14_C46_order_d  1
 IF GC1091    pool_first_14_C46_order_d  1
 IF GC1092    pool_first_14_C47_order_d  1
 IF GC1093    pool_first_14_C47_order_d  1
 IF GC1094    pool_first_14_C88_order_d  1
 IF GC1095    pool_first_14_C88_order_d  1
 IF GC1096    pool_first_14_C29_order_d  1
 IF GC1097    pool_first_14_C29_order_d  1
 IF GC1098    pool_first_14_C25_order_d  1
 IF GC1099    pool_first_14_C25_order_d  1
 IF GC1100    pool_first_14_C6_order_d  1
 IF GC1101    pool_first_14_C6_order_d  1
 IF GC1102    pool_first_14_C46_order_p  1
 IF GC1103    pool_first_14_C46_order_p  1
 IF GC1104    pool_first_14_C88_order_p  1
 IF GC1105    pool_first_14_C88_order_p  1
 IF GC1106    pool_first_14_C47_order_p  1
 IF GC1107    pool_first_14_C47_order_p  1
 IF GC1108    pool_first_14_C76_order_p  1
 IF GC1109    pool_first_14_C76_order_p  1
 IF GC1110    pool_first_14_C76_order_d  1
 IF GC1111    pool_first_14_C76_order_d  1
 IF GC1112    pool_first_14_C27_order_d  1
 IF GC1113    pool_first_14_C27_order_d  1
 IF GC1114    pool_last_14_C46_order_p  1
 IF GC1115    pool_last_14_C46_order_p  1
 IF GC1116    pool_last_14_C47_order_p  1
 IF GC1117    pool_last_14_C47_order_p  1
 IF GC1118    pool_last_14_C88_order_p  1
 IF GC1119    pool_last_14_C88_order_p  1
 IF GC1120    pool_last_14_C29_order_p  1
 IF GC1121    pool_last_14_C29_order_p  1
 IF GC1122    pool_last_14_C6_order_p  1
 IF GC1123    pool_last_14_C6_order_p  1
 IF GC1124    pool_last_14_C25_order_p  1
 IF GC1125    pool_last_14_C25_order_p  1
 IF GC1126    pool_last_14_C25_order_d  1
 IF GC1127    pool_last_14_C25_order_d  1
 IF GC1128    pool_last_14_C46_order_d  1
 IF GC1129    pool_last_14_C46_order_d  1
 IF GC1130    pool_last_14_C88_order_d  1
 IF GC1131    pool_last_14_C88_order_d  1
 IF GC1132    pool_last_14_C47_order_d  1
 IF GC1133    pool_last_14_C47_order_d  1
 IF GC1134    pool_last_14_C29_order_d  1
 IF GC1135    pool_last_14_C29_order_d  1
 IF GC1136    pool_last_14_C76_order_d  1
 IF GC1137    pool_last_14_C76_order_d  1
 IF GC1138    pool_last_14_C6_order_d  1
 IF GC1139    pool_last_14_C6_order_d  1
 IF GC1140    pool_last_14_C27_order_d  1
 IF GC1141    pool_last_14_C27_order_d  1
 IF GC1142    pool_pickup_14_C46_order  1
 IF GC1143    pool_pickup_14_C47_order  1
 IF GC1144    pool_pickup_14_C88_order  1
 IF GC1145    pool_pickup_14_C29_order  1
 IF GC1146    pool_pickup_14_C6_order  1
 IF GC1147    pool_pickup_14_C25_order  1
 IF GC1148    pool_pickup_14_C76_order  1
 IF GC1149    pool_pickup_14_C27_order  1
 IF GC1150    pool_batch_14_b2  1
 IF GC1151    pool_batch_14_b1  1
 IF GC1152    pool_batch_14_b3  1
 IF GC1153    pool_first_15_C6_order_d  1
 IF GC1154    pool_first_15_C6_order_d  1
 IF GC1155    pool_first_15_C88_order_d  1
 IF GC1156    pool_first_15_C88_order_d  1
 IF GC1157    pool_first_15_C29_order_d  1
 IF GC1158    pool_first_15_C29_order_d  1
 IF GC1159    pool_first_15_C46_order_d  1
 IF GC1160    pool_first_15_C46_order_d  1
 IF GC1161    pool_first_15_C29_order_p  1
 IF GC1162    pool_first_15_C29_order_p  1
 IF GC1163    pool_first_15_C6_order_p  1
 IF GC1164    pool_first_15_C6_order_p  1
 IF GC1165    pool_first_15_C88_order_p  1
 IF GC1166    pool_first_15_C88_order_p  1
 IF GC1167    pool_first_15_C47_order_d  1
 IF GC1168    pool_first_15_C47_order_d  1
 IF GC1169    pool_first_15_C47_order_p  1
 IF GC1170    pool_first_15_C47_order_p  1
 IF GC1171    pool_first_15_C76_order_p  1
 IF GC1172    pool_first_15_C76_order_p  1
 IF GC1173    pool_first_15_C76_order_d  1
 IF GC1174    pool_first_15_C76_order_d  1
 IF GC1175    pool_first_15_C27_order_d  1
 IF GC1176    pool_first_15_C27_order_d  1
 IF GC1177    pool_first_15_C25_order_d  1
 IF GC1178    pool_first_15_C25_order_d  1
 IF GC1179    pool_last_15_C6_order_p  1
 IF GC1180    pool_last_15_C6_order_p  1
 IF GC1181    pool_last_15_C88_order_p  1
 IF GC1182    pool_last_15_C88_order_p  1
 IF GC1183    pool_last_15_C29_order_p  1
 IF GC1184    pool_last_15_C29_order_p  1
 IF GC1185    pool_last_15_C46_order_p  1
 IF GC1186    pool_last_15_C46_order_p  1
 IF GC1187    pool_last_15_C6_order_d  1
 IF GC1188    pool_last_15_C6_order_d  1
 IF GC1189    pool_last_15_C88_order_d  1
 IF GC1190    pool_last_15_C88_order_d  1
 IF GC1191    pool_last_15_C47_order_d  1
 IF GC1192    pool_last_15_C47_order_d  1
 IF GC1193    pool_last_15_C47_order_p  1
 IF GC1194    pool_last_15_C47_order_p  1
 IF GC1195    pool_last_15_C29_order_d  1
 IF GC1196    pool_last_15_C29_order_d  1
 IF GC1197    pool_last_15_C76_order_d  1
 IF GC1198    pool_last_15_C76_order_d  1
 IF GC1199    pool_last_15_C25_order_d  1
 IF GC1200    pool_last_15_C25_order_d  1
 IF GC1201    pool_last_15_C46_order_d  1
 IF GC1202    pool_last_15_C46_order_d  1
 IF GC1203    pool_last_15_C27_order_d  1
 IF GC1204    pool_last_15_C27_order_d  1
 IF GC1205    pool_pickup_15_C6_order  1
 IF GC1206    pool_pickup_15_C88_order  1
 IF GC1207    pool_pickup_15_C29_order  1
 IF GC1208    pool_pickup_15_C46_order  1
 IF GC1209    pool_pickup_15_C47_order  1
 IF GC1210    pool_pickup_15_C76_order  1
 IF GC1211    pool_pickup_15_C25_order  1
 IF GC1212    pool_pickup_15_C27_order  1
 IF GC1213    pool_batch_15_b3  1
 IF GC1214    pool_batch_15_b1  1
 IF GC1215    pool_batch_15_b2  1
 IF GC1216    pool_first_16_C95_order_d  1
 IF GC1217    pool_first_16_C95_order_d  1
 IF GC1218    pool_first_16_C95_order_p  1
 IF GC1219    pool_first_16_C95_order_p  1
 IF GC1220    pool_first_16_C34_order_d  1
 IF GC1221    pool_first_16_C34_order_d  1
 IF GC1222    pool_first_16_C34_order_p  1
 IF GC1223    pool_first_16_C34_order_p  1
 IF GC1224    pool_last_16_C95_order_p  1
 IF GC1225    pool_last_16_C95_order_p  1
 IF GC1226    pool_last_16_C95_order_d  1
 IF GC1227    pool_last_16_C95_order_d  1
 IF GC1228    pool_last_16_C34_order_p  1
 IF GC1229    pool_last_16_C34_order_p  1
 IF GC1230    pool_last_16_C34_order_d  1
 IF GC1231    pool_last_16_C34_order_d  1
 IF GC1232    pool_pickup_16_C95_order  1
 IF GC1233    pool_pickup_16_C34_order  1
 IF GC1234    pool_batch_16_b2  1
 IF GC1235    pool_batch_16_b1  1
 IF GC1236    pool_first_17_C95_order_d  1
 IF GC1237    pool_first_17_C95_order_d  1
 IF GC1238    pool_first_17_C95_order_p  1
 IF GC1239    pool_first_17_C95_order_p  1
 IF GC1240    pool_first_17_C34_order_d  1
 IF GC1241    pool_first_17_C34_order_d  1
 IF GC1242    pool_first_17_C34_order_p  1
 IF GC1243    pool_first_17_C34_order_p  1
 IF GC1244    pool_last_17_C95_order_p  1
 IF GC1245    pool_last_17_C95_order_p  1
 IF GC1246    pool_last_17_C95_order_d  1
 IF GC1247    pool_last_17_C95_order_d  1
 IF GC1248    pool_last_17_C34_order_p  1
 IF GC1249    pool_last_17_C34_order_p  1
 IF GC1250    pool_last_17_C34_order_d  1
 IF GC1251    pool_last_17_C34_order_d  1
 IF GC1252    pool_pickup_17_C95_order  1
 IF GC1253    pool_pickup_17_C34_order  1
 IF GC1254    pool_batch_17_b2  1
 IF GC1255    pool_batch_17_b1  1
 IF GC1256    pool_first_18_C95_order_d  1
 IF GC1257    pool_first_18_C95_order_d  1
 IF GC1258    pool_first_18_C95_order_p  1
 IF GC1259    pool_first_18_C95_order_p  1
 IF GC1260    pool_first_18_C34_order_d  1
 IF GC1261    pool_first_18_C34_order_d  1
 IF GC1262    pool_first_18_C34_order_p  1
 IF GC1263    pool_first_18_C34_order_p  1
 IF GC1264    pool_last_18_C95_order_p  1
 IF GC1265    pool_last_18_C95_order_p  1
 IF GC1266    pool_last_18_C95_order_d  1
 IF GC1267    pool_last_18_C95_order_d  1
 IF GC1268    pool_last_18_C34_order_p  1
 IF GC1269    pool_last_18_C34_order_p  1
 IF GC1270    pool_last_18_C34_order_d  1
 IF GC1271    pool_last_18_C34_order_d  1
 IF GC1272    pool_pickup_18_C95_order  1
 IF GC1273    pool_pickup_18_C34_order  1
 IF GC1274    pool_batch_18_b2  1
 IF GC1275    pool_batch_18_b1  1
 IF GC1276    pool_first_19_C34_order_d  1
 IF GC1277    pool_first_19_C34_order_d  1
 IF GC1278    pool_first_19_C95_order_d  1
 IF GC1279    pool_first_19_C95_order_d  1
 IF GC1280    pool_first_19_C34_order_p  1
 IF GC1281    pool_first_19_C34_order_p  1
 IF GC1282    pool_first_19_C95_order_p  1
 IF GC1283    pool_first_19_C95_order_p  1
 IF GC1284    pool_last_19_C34_order_p  1
 IF GC1285    pool_last_19_C34_order_p  1
 IF GC1286    pool_last_19_C95_order_p  1
 IF GC1287    pool_last_19_C95_order_p  1
 IF GC1288    pool_last_19_C34_order_d  1
 IF GC1289    pool_last_19_C34_order_d  1
 IF GC1290    pool_last_19_C95_order_d  1
 IF GC1291    pool_last_19_C95_order_d  1
 IF GC1292    pool_pickup_19_C34_order  1
 IF GC1293    pool_pickup_19_C95_order  1
 IF GC1294    pool_batch_19_b1  1
 IF GC1295    pool_batch_19_b2  1
 IF GC1296    pool_link_0  1
 IF GC1297    pool_link_0  1
 IF GC1298    pool_link_1  1
 IF GC1299    pool_link_1  1
 IF GC1300    pool_link_2  1
 IF GC1301    pool_link_2  1
 IF GC1302    pool_link_3  1
 IF GC1303    pool_link_3  1
 IF GC1304    pool_link_4  1
 IF GC1305    pool_link_4  1
 IF GC1306    pool_link_5  1
 IF GC1307    pool_link_5  1
 IF GC1308    pool_link_6  1
 IF GC1309    pool_link_6  1
 IF GC1310    pool_link_7  1
 IF GC1311    pool_link_7  1
 IF GC1312    pool_link_8  1
 IF GC1313    pool_link_8  1
 IF GC1314    pool_link_9  1
 IF GC1315    pool_link_9  1
 IF GC1316    pool_link_10  1
 IF GC1317    pool_link_10  1
 IF GC1318    pool_link_11  1
 IF GC1319    pool_link_11  1
 IF GC1320    pool_link_12  1
 IF GC1321    pool_link_12  1
 IF GC1322    pool_link_13  1
 IF GC1323    pool_link_13  1
 IF GC1324    pool_link_14  1
 IF GC1325    pool_link_14  1
 IF GC1326    pool_link_15  1
 IF GC1327    pool_link_15  1
 IF GC1328    pool_link_16  1
 IF GC1329    pool_link_16  1
 IF GC1330    pool_link_17  1
 IF GC1331    pool_link_17  1
 IF GC1332    pool_link_18  1
 IF GC1333    pool_link_18  1
 IF GC1334    pool_link_19  1
 IF GC1335    pool_link_19  1
 IF GC1336    pool_link_20  1
 IF GC1337    pool_link_20  1
 IF GC1338    pool_link_21  1
 IF GC1339    pool_link_21  1
 IF GC1340    pool_link_22  1
 IF GC1341    pool_link_22  1
 IF GC1342    pool_link_23  1
 IF GC1343    pool_link_23  1
 IF GC1344    pool_link_24  1
 IF GC1345    pool_link_24  1
 IF GC1346    pool_link_25  1
 IF GC1347    pool_link_25  1
 IF GC1348    pool_link_26  1
 IF GC1349    pool_link_26  1
 IF GC1350    pool_link_27  1
 IF GC1351    pool_link_27  1
 IF GC1352    pool_link_28  1
 IF GC1353    pool_link_28  1
 IF GC1354    pool_link_29  1
 IF GC1355    pool_link_29  1
 IF GC1356    pool_link_30  1
 IF GC1357    pool_link_30  1
 IF GC1358    pool_link_31  1
 IF GC1359    pool_link_31  1
 IF GC1360    pool_link_32  1
 IF GC1361    pool_link_32  1
 IF GC1362    pool_link_33  1
 IF GC1363    pool_link_33  1
 IF GC1364    pool_link_34  1
 IF GC1365    pool_link_34  1
 IF GC1366    pool_link_35  1
 IF GC1367    pool_link_35  1
 IF GC1368    pool_link_36  1
 IF GC1369    pool_link_36  1
 IF GC1370    pool_link_37  1
 IF GC1371    pool_link_37  1
 IF GC1372    pool_link_38  1
 IF GC1373    pool_link_38  1
 IF GC1374    pool_link_39  1
 IF GC1375    pool_link_39  1
 IF GC1376    pool_link_40  1
 IF GC1377    pool_link_40  1
 IF GC1378    pool_link_41  1
 IF GC1379    pool_link_41  1
 IF GC1380    pool_link_42  1
 IF GC1381    pool_link_42  1
 IF GC1382    pool_link_43  1
 IF GC1383    pool_link_43  1
 IF GC1384    pool_link_44  1
 IF GC1385    pool_link_44  1
 IF GC1386    pool_link_45  1
 IF GC1387    pool_link_45  1
 IF GC1388    pool_link_46  1
 IF GC1389    pool_link_46  1
 IF GC1390    pool_link_47  1
 IF GC1391    pool_link_47  1
 IF GC1392    pool_link_48  1
 IF GC1393    pool_link_48  1
 IF GC1394    pool_link_49  1
 IF GC1395    pool_link_49  1
 IF GC1396    pool_link_50  1
 IF GC1397    pool_link_50  1
 IF GC1398    pool_link_51  1
 IF GC1399    pool_link_51  1
 IF GC1400    pool_link_52  1
 IF GC1401    pool_link_52  1
 IF GC1402    pool_link_53  1
 IF GC1403    pool_link_53  1
 IF GC1404    pool_link_54  1
 IF GC1405    pool_link_54  1
 IF GC1406    pool_link_55  1
 IF GC1407    pool_link_55  1
 IF GC1408    pool_link_56  1
 IF GC1409    pool_link_56  1
 IF GC1410    pool_link_57  1
 IF GC1411    pool_link_57  1
 IF GC1412    pool_link_58  1
 IF GC1413    pool_link_58  1
 IF GC1414    pool_link_59  1
 IF GC1415    pool_link_59  1
 IF GC1416    pool_link_60  1
 IF GC1417    pool_link_60  1
 IF GC1418    pool_link_61  1
 IF GC1419    pool_link_61  1
 IF GC1420    pool_link_62  1
 IF GC1421    pool_link_62  1
 IF GC1422    pool_link_63  1
 IF GC1423    pool_link_63  1
 IF GC1424    pool_link_64  1
 IF GC1425    pool_link_64  1
 IF GC1426    pool_link_65  1
 IF GC1427    pool_link_65  1
 IF GC1428    pool_link_66  1
 IF GC1429    pool_link_66  1
 IF GC1430    pool_link_67  1
 IF GC1431    pool_link_67  1
 IF GC1432    pool_link_68  1
 IF GC1433    pool_link_68  1
 IF GC1434    pool_link_69  1
 IF GC1435    pool_link_69  1
 IF GC1436    pool_link_70  1
 IF GC1437    pool_link_70  1
 IF GC1438    pool_link_71  1
 IF GC1439    pool_link_71  1
 IF GC1440    pool_link_72  1
 IF GC1441    pool_link_72  1
 IF GC1442    pool_link_73  1
 IF GC1443    pool_link_73  1
 IF GC1444    pool_link_74  1
 IF GC1445    pool_link_74  1
 IF GC1446    pool_link_75  1
 IF GC1447    pool_link_75  1
 IF GC1448    pool_link_76  1
 IF GC1449    pool_link_76  1
 IF GC1450    pool_link_77  1
 IF GC1451    pool_link_77  1
 IF GC1452    pool_link_78  1
 IF GC1453    pool_link_78  1
 IF GC1454    pool_link_79  1
 IF GC1455    pool_link_79  1
 IF GC1456    pool_link_80  1
 IF GC1457    pool_link_80  1
 IF GC1458    pool_link_81  1
 IF GC1459    pool_link_81  1
 IF GC1460    pool_link_82  1
 IF GC1461    pool_link_82  1
 IF GC1462    pool_link_83  1
 IF GC1463    pool_link_83  1
 IF GC1464    pool_link_84  1
 IF GC1465    pool_link_84  1
 IF GC1466    pool_link_85  1
 IF GC1467    pool_link_85  1
 IF GC1468    pool_link_86  1
 IF GC1469    pool_link_86  1
 IF GC1470    pool_link_87  1
 IF GC1471    pool_link_87  1
 IF GC1472    pool_link_88  1
 IF GC1473    pool_link_88  1
 IF GC1474    pool_link_89  1
 IF GC1475    pool_link_89  1
 IF GC1476    pool_link_90  1
 IF GC1477    pool_link_90  1
 IF GC1478    pool_link_91  1
 IF GC1479    pool_link_91  1
 IF GC1480    pool_link_92  1
 IF GC1481    pool_link_92  1
 IF GC1482    pool_link_93  1
 IF GC1483    pool_link_93  1
 IF GC1484    pool_link_94  1
 IF GC1485    pool_link_94  1
 IF GC1486    pool_link_95  1
 IF GC1487    pool_link_95  1
 IF GC1488    pool_link_96  1
 IF GC1489    pool_link_96  1
 IF GC1490    pool_link_97  1
 IF GC1491    pool_link_97  1
 IF GC1492    pool_link_98  1
 IF GC1493    pool_link_98  1
 IF GC1494    pool_link_99  1
 IF GC1495    pool_link_99  1
 IF GC1496    pool_link_100  1
 IF GC1497    pool_link_100  1
 IF GC1498    pool_link_101  1
 IF GC1499    pool_link_101  1
 IF GC1500    pool_link_102  1
 IF GC1501    pool_link_102  1
 IF GC1502    pool_link_103  1
 IF GC1503    pool_link_103  1
 IF GC1504    pool_link_104  1
 IF GC1505    pool_link_104  1
 IF GC1506    pool_link_105  1
 IF GC1507    pool_link_105  1
 IF GC1508    pool_link_106  1
 IF GC1509    pool_link_106  1
 IF GC1510    pool_link_107  1
 IF GC1511    pool_link_107  1
 IF GC1512    pool_link_108  1
 IF GC1513    pool_link_108  1
 IF GC1514    pool_link_109  1
 IF GC1515    pool_link_109  1
 IF GC1516    pool_link_110  1
 IF GC1517    pool_link_110  1
 IF GC1518    pool_link_111  1
 IF GC1519    pool_link_111  1
 IF GC1520    pool_link_112  1
 IF GC1521    pool_link_112  1
 IF GC1522    pool_link_113  1
 IF GC1523    pool_link_113  1
 IF GC1524    pool_link_114  1
 IF GC1525    pool_link_114  1
 IF GC1526    pool_link_115  1
 IF GC1527    pool_link_115  1
 IF GC1528    pool_link_116  1
 IF GC1529    pool_link_116  1
 IF GC1530    pool_link_117  1
 IF GC1531    pool_link_117  1
 IF GC1532    pool_link_118  1
 IF GC1533    pool_link_118  1
 IF GC1534    pool_link_119  1
 IF GC1535    pool_link_119  1
 IF GC1536    pool_link_120  1
 IF GC1537    pool_link_120  1
 IF GC1538    pool_link_121  1
 IF GC1539    pool_link_121  1
 IF GC1540    pool_link_122  1
 IF GC1541    pool_link_122  1
 IF GC1542    pool_link_123  1
 IF GC1543    pool_link_123  1
 IF GC1544    pool_link_124  1
 IF GC1545    pool_link_124  1
 IF GC1546    pool_link_125  1
 IF GC1547    pool_link_125  1
 IF GC1548    pool_link_126  1
 IF GC1549    pool_link_126  1
 IF GC1550    pool_link_127  1
 IF GC1551    pool_link_127  1
 IF GC1552    pool_link_128  1
 IF GC1553    pool_link_128  1
 IF GC1554    pool_link_129  1
 IF GC1555    pool_link_129  1
 IF GC1556    pool_link_130  1
 IF GC1557    pool_link_130  1
 IF GC1558    pool_link_131  1
 IF GC1559    pool_link_131  1
 IF GC1560    pool_link_132  1
 IF GC1561    pool_link_132  1
 IF GC1562    pool_link_133  1
 IF GC1563    pool_link_133  1
 IF GC1564    pool_link_134  1
 IF GC1565    pool_link_134  1
 IF GC1566    pool_link_135  1
 IF GC1567    pool_link_135  1
 IF GC1568    pool_link_136  1
 IF GC1569    pool_link_136  1
 IF GC1570    pool_link_137  1
 IF GC1571    pool_link_137  1
 IF GC1572    pool_link_138  1
 IF GC1573    pool_link_138  1
 IF GC1574    pool_link_139  1
 IF GC1575    pool_link_139  1
 IF GC1576    pool_link_140  1
 IF GC1577    pool_link_140  1
 IF GC1578    pool_link_141  1
 IF GC1579    pool_link_141  1
 IF GC1580    pool_link_142  1
 IF GC1581    pool_link_142  1
 IF GC1582    pool_link_143  1
 IF GC1583    pool_link_143  1
 IF GC1584    pool_link_144  1
 IF GC1585    pool_link_144  1
 IF GC1586    pool_link_145  1
 IF GC1587    pool_link_145  1
 IF GC1588    pool_link_146  1
 IF GC1589    pool_link_146  1
 IF GC1590    pool_link_147  1
 IF GC1591    pool_link_147  1
 IF GC1592    pool_link_148  1
 IF GC1593    pool_link_148  1
ENDATA
