* Signature: 0x57e0df896fc5027f
NAME multi_batch_cutoff_v1
ROWS
 N  OBJ
 G  R311    
 L  R312    
 G  R313    
 G  R314    
 L  R315    
 G  R316    
 G  R317    
 G  R318    
 L  R319    
 G  R320    
 G  R321    
 L  R322    
 L  R323    
 G  R324    
 E  R325    
 E  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 G  R343    
 G  R344    
 L  R345    
 G  R346    
 L  R347    
 G  R348    
 G  R349    
 L  R350    
 G  R351    
 L  R352    
 G  R353    
 G  R354    
 L  R355    
 G  R356    
 L  R357    
 G  R358    
 G  R359    
 L  R360    
 G  R361    
 L  R362    
 G  R363    
 G  R364    
 G  R365    
 G  R366    
 L  R367    
 L  R368    
 L  R369    
 G  R370    
 L  R371    
 L  R372    
 L  R373    
 G  R374    
 L  R375    
 L  R376    
 L  R377    
 G  R378    
 L  R379    
 L  R380    
 G  R381    
 L  R382    
 G  R383    
 G  R384    
 G  R385    
 G  R386    
 G  R387    
 G  R388    
 G  R389    
 G  R390    
 L  R391    
 L  R392    
 G  R393    
 E  R394    
 E  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 G  R412    
 G  R413    
 L  R414    
 G  R415    
 L  R416    
 G  R417    
 G  R418    
 L  R419    
 G  R420    
 L  R421    
 G  R422    
 G  R423    
 L  R424    
 G  R425    
 L  R426    
 G  R427    
 G  R428    
 L  R429    
 G  R430    
 L  R431    
 G  R432    
 G  R433    
 G  R434    
 G  R435    
 L  R436    
 L  R437    
 G  R438    
 L  R439    
 G  R440    
 L  R441    
 G  R442    
 L  R443    
 L  R444    
 L  R445    
 G  R446    
 L  R447    
 L  R448    
 L  R449    
 G  R450    
 L  R451    
 L  R452    
 G  R453    
 L  R454    
 G  R455    
 G  R456    
 G  R457    
 G  R458    
 G  R459    
 G  R460    
 G  R461    
 G  R462    
 L  R463    
 L  R464    
 G  R465    
 E  R466    
 E  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 G  R484    
 G  R485    
 L  R486    
 G  R487    
 L  R488    
 G  R489    
 G  R490    
 L  R491    
 G  R492    
 L  R493    
 G  R494    
 G  R495    
 L  R496    
 G  R497    
 L  R498    
 G  R499    
 G  R500    
 L  R501    
 G  R502    
 L  R503    
 G  R504    
 G  R505    
 G  R506    
 G  R507    
 L  R508    
 L  R509    
 G  R510    
 L  R511    
 G  R512    
 L  R513    
 G  R514    
 L  R515    
 L  R516    
 L  R517    
 G  R518    
 L  R519    
 L  R520    
 L  R521    
 G  R522    
 L  R523    
 L  R524    
 G  R525    
 L  R526    
 G  R527    
 G  R528    
 G  R529    
 G  R530    
 G  R531    
 G  R532    
 G  R533    
 G  R534    
 L  R535    
 L  R536    
 G  R537    
 E  R538    
 E  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 G  R556    
 G  R557    
 L  R558    
 G  R559    
 L  R560    
 G  R561    
 G  R562    
 L  R563    
 G  R564    
 L  R565    
 G  R566    
 G  R567    
 L  R568    
 G  R569    
 L  R570    
 G  R571    
 G  R572    
 L  R573    
 G  R574    
 L  R575    
 G  R576    
 G  R577    
 G  R578    
 G  R579    
 L  R580    
 L  R581    
 G  R582    
 L  R583    
 G  R584    
 L  R585    
 G  R586    
 L  R587    
 L  R588    
 L  R589    
 G  R590    
 L  R591    
 L  R592    
 L  R593    
 G  R594    
 L  R595    
 L  R596    
 G  R597    
 L  R598    
 G  R599    
 G  R600    
 G  R601    
 G  R602    
 G  R603    
 G  R604    
 G  R605    
 G  R606    
 L  R607    
 L  R608    
 G  R609    
 E  R610    
 E  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 G  R628    
 G  R629    
 L  R630    
 G  R631    
 L  R632    
 G  R633    
 G  R634    
 L  R635    
 G  R636    
 L  R637    
 G  R638    
 G  R639    
 L  R640    
 G  R641    
 L  R642    
 G  R643    
 G  R644    
 L  R645    
 G  R646    
 L  R647    
 G  R648    
 G  R649    
 G  R650    
 G  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 G  R656    
 L  R657    
 L  R658    
 L  R659    
 G  R660    
 L  R661    
 L  R662    
 L  R663    
 G  R664    
 L  R665    
 L  R666    
 G  R667    
 L  R668    
 G  R669    
 G  R670    
 G  R671    
 G  R672    
 G  R673    
 G  R674    
 G  R675    
 G  R676    
 L  R677    
 L  R678    
 G  R679    
 E  R680    
 E  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 G  R698    
 G  R699    
 L  R700    
 G  R701    
 L  R702    
 G  R703    
 G  R704    
 L  R705    
 G  R706    
 L  R707    
 G  R708    
 G  R709    
 L  R710    
 G  R711    
 L  R712    
 G  R713    
 G  R714    
 L  R715    
 G  R716    
 L  R717    
 G  R718    
 G  R719    
 G  R720    
 G  R721    
 L  R722    
 L  R723    
 G  R724    
 L  R725    
 G  R726    
 L  R727    
 G  R728    
 L  R729    
 L  R730    
 L  R731    
 G  R732    
 L  R733    
 L  R734    
 L  R735    
 G  R736    
 L  R737    
 L  R738    
 G  R739    
 L  R740    
 G  R741    
 G  R742    
 G  R743    
 G  R744    
 G  R745    
 G  R746    
 G  R747    
 G  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 E  R760    
 E  R761    
 E  R762    
 E  R763    
 E  R764    
 E  R765    
 E  R766    
 E  R767    
 E  R768    
 E  R769    
 E  R770    
 E  R771    
 G  R772    
 G  R773    
 L  R774    
 G  R775    
 L  R776    
 G  R777    
 G  R778    
 G  R779    
 L  R780    
 G  R781    
 L  R782    
 G  R783    
 G  R784    
 G  R785    
 L  R786    
 G  R787    
 L  R788    
 G  R789    
 G  R790    
 G  R791    
 L  R792    
 G  R793    
 L  R794    
 G  R795    
 G  R796    
 G  R797    
 L  R798    
 G  R799    
 L  R800    
 G  R801    
 E  R802    
 E  R803    
 G  R804    
 G  R805    
 E  R806    
 E  R807    
 G  R808    
 G  R809    
 L  R830    
 L  R834    
 L  R838    
 L  R842    
 L  R846    
 L  R850    
 L  R854    
 L  R858    
 L  R862    
 G  clean_stock_b1
 L  R867    
 L  R871    
 L  R875    
 L  R879    
 L  R883    
 L  R887    
 L  R891    
 L  R895    
 L  R899    
 G  clean_stock_b2
 L  R904    
 L  R908    
 L  R912    
 L  R916    
 L  R920    
 L  R924    
 L  R928    
 L  R932    
 L  R936    
 G  clean_stock_b3
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    delivery_S4_b1  R370      -1
    delivery_S4_b1  R442      -1
    delivery_S4_b1  R514      -1
    delivery_S4_b1  R586      -1
    delivery_S4_b1  R656      -1
    delivery_S4_b1  R728      -1
    delivery_S4_b2  R374      -1
    delivery_S4_b2  R446      -1
    delivery_S4_b2  R518      -1
    delivery_S4_b2  R590      -1
    delivery_S4_b2  R660      -1
    delivery_S4_b2  R732      -1
    C34_order_d  R343      1
    C34_order_d  R363      -1
    C34_order_d  R412      1
    C34_order_d  R432      -1
    C34_order_d  R484      1
    C34_order_d  R504      -1
    C34_order_d  R556      1
    C34_order_d  R576      -1
    C34_order_d  R628      1
    C34_order_d  R648      -1
    C34_order_d  R698      1
    C34_order_d  R718      -1
    C34_order_d  R772      -1
    C34_order_d  R778      -1
    C34_order_d  R804      -1
    C34_order_p  R311      -1
    C34_order_p  R348      1
    C34_order_p  R364      -1
    C34_order_p  R417      1
    C34_order_p  R433      -1
    C34_order_p  R489      1
    C34_order_p  R505      -1
    C34_order_p  R561      1
    C34_order_p  R577      -1
    C34_order_p  R633      1
    C34_order_p  R649      -1
    C34_order_p  R703      1
    C34_order_p  R719      -1
    C34_order_p  R772      1
    C34_order_p  R784      -1
    C34_order_p  R790      -1
    C34_order_p  R804      1
    C95_order_d  R353      1
    C95_order_d  R365      -1
    C95_order_d  R422      1
    C95_order_d  R434      -1
    C95_order_d  R494      1
    C95_order_d  R506      -1
    C95_order_d  R566      1
    C95_order_d  R578      -1
    C95_order_d  R638      1
    C95_order_d  R650      -1
    C95_order_d  R708      1
    C95_order_d  R720      -1
    C95_order_d  R784      1
    C95_order_d  R796      -1
    C95_order_d  R808      -1
    C95_order_p  R318      -1
    C95_order_p  R358      1
    C95_order_p  R366      -1
    C95_order_p  R427      1
    C95_order_p  R435      -1
    C95_order_p  R499      1
    C95_order_p  R507      -1
    C95_order_p  R571      1
    C95_order_p  R579      -1
    C95_order_p  R643      1
    C95_order_p  R651      -1
    C95_order_p  R713      1
    C95_order_p  R721      -1
    C95_order_p  R778      1
    C95_order_p  R790      1
    C95_order_p  R796      1
    C95_order_p  R808      1
    MARKER    'MARKER'                 'INTEND'
    C6        R344      1
    C6        R345      1
    C6        R413      1
    C6        R414      1
    C6        R485      1
    C6        R486      1
    C6        R557      1
    C6        R558      1
    C6        R629      1
    C6        R630      1
    C6        R699      1
    C6        R700      1
    C6        R773      -1
    C6        R774      -1
    C6        R779      -1
    C6        R780      -1
    C7        R349      1
    C7        R350      1
    C7        R418      1
    C7        R419      1
    C7        R490      1
    C7        R491      1
    C7        R562      1
    C7        R563      1
    C7        R634      1
    C7        R635      1
    C7        R704      1
    C7        R705      1
    C7        R773      1
    C7        R774      1
    C7        R785      -1
    C7        R786      -1
    C7        R791      -1
    C7        R792      -1
    C8        R354      1
    C8        R355      1
    C8        R423      1
    C8        R424      1
    C8        R495      1
    C8        R496      1
    C8        R567      1
    C8        R568      1
    C8        R639      1
    C8        R640      1
    C8        R709      1
    C8        R710      1
    C8        R785      1
    C8        R786      1
    C8        R797      -1
    C8        R798      -1
    C9        R359      1
    C9        R360      1
    C9        R428      1
    C9        R429      1
    C9        R500      1
    C9        R501      1
    C9        R572      1
    C9        R573      1
    C9        R644      1
    C9        R645      1
    C9        R714      1
    C9        R715      1
    C9        R779      1
    C9        R780      1
    C9        R791      1
    C9        R792      1
    C9        R797      1
    C9        R798      1
    C10       R346      1
    C10       R347      1
    C10       R415      1
    C10       R416      1
    C10       R487      1
    C10       R488      1
    C10       R559      1
    C10       R560      1
    C10       R631      1
    C10       R632      1
    C10       R701      1
    C10       R702      1
    C10       R775      -1
    C10       R776      -1
    C10       R781      -1
    C10       R782      -1
    C11       R351      1
    C11       R352      1
    C11       R420      1
    C11       R421      1
    C11       R492      1
    C11       R493      1
    C11       R564      1
    C11       R565      1
    C11       R636      1
    C11       R637      1
    C11       R706      1
    C11       R707      1
    C11       R775      1
    C11       R776      1
    C11       R787      -1
    C11       R788      -1
    C11       R793      -1
    C11       R794      -1
    C12       R356      1
    C12       R357      1
    C12       R425      1
    C12       R426      1
    C12       R497      1
    C12       R498      1
    C12       R569      1
    C12       R570      1
    C12       R641      1
    C12       R642      1
    C12       R711      1
    C12       R712      1
    C12       R787      1
    C12       R788      1
    C12       R799      -1
    C12       R800      -1
    C13       R361      1
    C13       R362      1
    C13       R430      1
    C13       R431      1
    C13       R502      1
    C13       R503      1
    C13       R574      1
    C13       R575      1
    C13       R646      1
    C13       R647      1
    C13       R716      1
    C13       R717      1
    C13       R781      1
    C13       R782      1
    C13       R793      1
    C13       R794      1
    C13       R799      1
    C13       R800      1
    C14       R383      1
    C14       R387      -1
    C14       R455      1
    C14       R459      -1
    C14       R527      1
    C14       R531      -1
    C14       R599      1
    C14       R603      -1
    C14       R669      1
    C14       R673      -1
    C14       R741      1
    C14       R745      -1
    C14       R777      -1
    C14       R783      -1
    C14       R805      -1
    C15       R384      1
    C15       R388      -1
    C15       R456      1
    C15       R460      -1
    C15       R528      1
    C15       R532      -1
    C15       R600      1
    C15       R604      -1
    C15       R670      1
    C15       R674      -1
    C15       R742      1
    C15       R746      -1
    C15       R777      1
    C15       R789      -1
    C15       R795      -1
    C15       R805      1
    C16       R385      1
    C16       R389      -1
    C16       R457      1
    C16       R461      -1
    C16       R529      1
    C16       R533      -1
    C16       R601      1
    C16       R605      -1
    C16       R671      1
    C16       R675      -1
    C16       R743      1
    C16       R747      -1
    C16       R789      1
    C16       R801      -1
    C16       R809      -1
    C17       R386      1
    C17       R390      -1
    C17       R458      1
    C17       R462      -1
    C17       R530      1
    C17       R534      -1
    C17       R602      1
    C17       R606      -1
    C17       R672      1
    C17       R676      -1
    C17       R744      1
    C17       R748      -1
    C17       R783      1
    C17       R795      1
    C17       R801      1
    C17       R809      1
    e1_b1_0_weight[0]  OBJ       0
    e1_b1_0_weight[1]  OBJ       0
    e1_b1_0_weight[2]  OBJ       0
    e1_b1_0_weight[3]  OBJ       0
    e1_b1_0_volume[0]  OBJ       0
    e1_b1_0_volume[1]  OBJ       0
    e1_b1_0_volume[2]  OBJ       0
    e1_b1_0_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C62       OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b1_1_weight[0]  OBJ       0
    e1_b1_1_weight[1]  OBJ       0
    e1_b1_1_weight[2]  OBJ       0
    e1_b1_1_weight[3]  OBJ       0
    e1_b1_1_volume[0]  OBJ       0
    e1_b1_1_volume[1]  OBJ       0
    e1_b1_1_volume[2]  OBJ       0
    e1_b1_1_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C107      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b1_2_weight[0]  OBJ       0
    e1_b1_2_weight[1]  OBJ       0
    e1_b1_2_weight[2]  OBJ       0
    e1_b1_2_weight[3]  OBJ       0
    e1_b1_2_volume[0]  OBJ       0
    e1_b1_2_volume[1]  OBJ       0
    e1_b1_2_volume[2]  OBJ       0
    e1_b1_2_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C152      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b2_0_weight[0]  OBJ       0
    e1_b2_0_weight[1]  OBJ       0
    e1_b2_0_weight[2]  OBJ       0
    e1_b2_0_weight[3]  OBJ       0
    e1_b2_0_volume[0]  OBJ       0
    e1_b2_0_volume[1]  OBJ       0
    e1_b2_0_volume[2]  OBJ       0
    e1_b2_0_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C197      OBJ       0
    C198      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b2_1_weight[0]  OBJ       0
    e1_b2_1_weight[1]  OBJ       0
    e1_b2_1_weight[2]  OBJ       0
    e1_b2_1_weight[3]  OBJ       0
    e1_b2_1_volume[0]  OBJ       0
    e1_b2_1_volume[1]  OBJ       0
    e1_b2_1_volume[2]  OBJ       0
    e1_b2_1_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C243      OBJ       0
    C244      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b2_2_weight[0]  OBJ       0
    e1_b2_2_weight[1]  OBJ       0
    e1_b2_2_weight[2]  OBJ       0
    e1_b2_2_weight[3]  OBJ       0
    e1_b2_2_volume[0]  OBJ       0
    e1_b2_2_volume[1]  OBJ       0
    e1_b2_2_volume[2]  OBJ       0
    e1_b2_2_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C289      OBJ       0
    C290      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b3_0_weight[0]  OBJ       0
    e1_b3_0_weight[1]  OBJ       0
    e1_b3_0_weight[2]  OBJ       0
    e1_b3_0_volume[0]  OBJ       0
    e1_b3_0_volume[1]  OBJ       0
    e1_b3_0_volume[2]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C325      OBJ       0
    C326      OBJ       0
    C327      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b3_1_weight[0]  OBJ       0
    e1_b3_1_weight[1]  OBJ       0
    e1_b3_1_weight[2]  OBJ       0
    e1_b3_1_volume[0]  OBJ       0
    e1_b3_1_volume[1]  OBJ       0
    e1_b3_1_volume[2]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C362      OBJ       0
    C363      OBJ       0
    C364      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b3_2_weight[0]  OBJ       0
    e1_b3_2_weight[1]  OBJ       0
    e1_b3_2_weight[2]  OBJ       0
    e1_b3_2_volume[0]  OBJ       0
    e1_b3_2_volume[1]  OBJ       0
    e1_b3_2_volume[2]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C399      OBJ       0
    C400      OBJ       0
    C401      OBJ       0
    pickup_return_C34_order  R311      1
    pickup_return_C34_order  R312      1
    pickup_return_C34_order  R313      1
    pickup_return_C34_order  R315      1
    pickup_return_C34_order  R316      1
    pickup_return_C34_order  R378      1
    pickup_return_C34_order  R379      1
    pickup_return_C34_order  R450      1
    pickup_return_C34_order  R451      1
    pickup_return_C34_order  R522      1
    pickup_return_C34_order  R523      1
    pickup_return_C34_order  R594      1
    pickup_return_C34_order  R595      1
    pickup_return_C34_order  R664      1
    pickup_return_C34_order  R665      1
    pickup_return_C34_order  R736      1
    pickup_return_C34_order  R737      1
    eligible_C34_order_b1  R312      31500
    eligible_C34_order_b1  R313      1792
    eligible_C34_order_b1  R314      1
    eligible_C34_order_b1  R317      -1
    eligible_C34_order_b2  R315      17100
    eligible_C34_order_b2  R316      16192
    eligible_C34_order_b2  R317      1
    pickup_return_C95_order  R318      1
    pickup_return_C95_order  R319      1
    pickup_return_C95_order  R320      1
    pickup_return_C95_order  R381      1
    pickup_return_C95_order  R382      1
    pickup_return_C95_order  R453      1
    pickup_return_C95_order  R454      1
    pickup_return_C95_order  R525      1
    pickup_return_C95_order  R526      1
    pickup_return_C95_order  R597      1
    pickup_return_C95_order  R598      1
    pickup_return_C95_order  R667      1
    pickup_return_C95_order  R668      1
    pickup_return_C95_order  R739      1
    pickup_return_C95_order  R740      1
    eligible_C95_order_b2  R319      17100
    eligible_C95_order_b2  R320      5350
    eligible_C95_order_b2  R321      1
    e2_S4_0_0_used  R322      -75600
    e2_S4_0_0_used  R323      -75600
    e2_S4_0_0_used  R324      -28800
    e2_S4_0_0_used  R325      -1
    e2_S4_0_0_used  R326      -1
    e2_S4_0_0_used  R327      -180
    e2_S4_0_0_used  R328      -6
    e2_S4_0_0_used  R329      -180
    e2_S4_0_0_used  R330      -6
    e2_S4_0_0_used  R333      -1
    e2_S4_0_0_used  R336      -1
    e2_S4_0_0_used  R339      -1
    e2_S4_0_0_used  R342      -1
    e2_S4_0_0_used  R367      -75540
    e2_S4_0_0_used  R368      -1
    e2_S4_0_0_used  R437      -1
    e2_S4_0_0_used  R652      -1
    e2_S4_0_0_used  R749      -1
    e2_S4_0_0_start  R322      1
    e2_S4_0_0_start  R324      1
    e2_S4_0_0_start  R343      -1
    e2_S4_0_0_start  R348      -1
    e2_S4_0_0_start  R353      -1
    e2_S4_0_0_start  R358      -1
    e2_S4_0_0_start  R370      1
    e2_S4_0_0_start  R374      1
    e2_S4_0_0_end  R323      1
    e2_S4_0_0_end  R363      1
    e2_S4_0_0_end  R364      1
    e2_S4_0_0_end  R365      1
    e2_S4_0_0_end  R366      1
    e2_S4_0_0_end  R367      1
    e2_S4_0_0_end  R378      -1
    e2_S4_0_0_end  R379      -1
    e2_S4_0_0_end  R381      -1
    e2_S4_0_0_end  R382      -1
    e2_S4_0_0_end  R440      -1
    e2_S4_0_0_visit[0]  R327      23
    e2_S4_0_0_visit[0]  R328      2
    e2_S4_0_0_visit[0]  R331      -1
    e2_S4_0_0_visit[0]  R332      -1
    e2_S4_0_0_visit[0]  R333      1
    e2_S4_0_0_visit[0]  R344      -23
    e2_S4_0_0_visit[0]  R345      -23
    e2_S4_0_0_visit[0]  R346      -2
    e2_S4_0_0_visit[0]  R347      -2
    e2_S4_0_0_visit[0]  R349      -23
    e2_S4_0_0_visit[0]  R350      -23
    e2_S4_0_0_visit[0]  R351      -2
    e2_S4_0_0_visit[0]  R352      -2
    e2_S4_0_0_visit[0]  R354      -23
    e2_S4_0_0_visit[0]  R355      -23
    e2_S4_0_0_visit[0]  R356      -2
    e2_S4_0_0_visit[0]  R357      -2
    e2_S4_0_0_visit[0]  R359      -23
    e2_S4_0_0_visit[0]  R360      -23
    e2_S4_0_0_visit[0]  R361      -2
    e2_S4_0_0_visit[0]  R362      -2
    e2_S4_0_0_visit[0]  R369      -1
    e2_S4_0_0_visit[0]  R371      23
    e2_S4_0_0_visit[0]  R372      2
    e2_S4_0_0_visit[0]  R377      1
    e2_S4_0_0_visit[0]  R760      -1
    e2_S4_0_0_visit[0]  R802      1
    e2_S4_0_0_visit[1]  R329      4
    e2_S4_0_0_visit[1]  R330      2
    e2_S4_0_0_visit[1]  R334      -1
    e2_S4_0_0_visit[1]  R335      -1
    e2_S4_0_0_visit[1]  R336      1
    e2_S4_0_0_visit[1]  R378      -37791
    e2_S4_0_0_visit[1]  R379      71100
    e2_S4_0_0_visit[1]  R763      -1
    e2_S4_0_0_visit[1]  R803      1
    e2_S4_0_0_visit[2]  R327      21
    e2_S4_0_0_visit[2]  R328      2
    e2_S4_0_0_visit[2]  R337      -1
    e2_S4_0_0_visit[2]  R338      -1
    e2_S4_0_0_visit[2]  R339      1
    e2_S4_0_0_visit[2]  R344      -21
    e2_S4_0_0_visit[2]  R345      -21
    e2_S4_0_0_visit[2]  R346      -2
    e2_S4_0_0_visit[2]  R347      -2
    e2_S4_0_0_visit[2]  R349      -21
    e2_S4_0_0_visit[2]  R350      -21
    e2_S4_0_0_visit[2]  R351      -2
    e2_S4_0_0_visit[2]  R352      -2
    e2_S4_0_0_visit[2]  R354      -21
    e2_S4_0_0_visit[2]  R355      -21
    e2_S4_0_0_visit[2]  R356      -2
    e2_S4_0_0_visit[2]  R357      -2
    e2_S4_0_0_visit[2]  R359      -21
    e2_S4_0_0_visit[2]  R360      -21
    e2_S4_0_0_visit[2]  R361      -2
    e2_S4_0_0_visit[2]  R362      -2
    e2_S4_0_0_visit[2]  R373      -1
    e2_S4_0_0_visit[2]  R375      21
    e2_S4_0_0_visit[2]  R376      2
    e2_S4_0_0_visit[2]  R380      1
    e2_S4_0_0_visit[2]  R766      -1
    e2_S4_0_0_visit[2]  R806      1
    e2_S4_0_0_visit[3]  R329      4
    e2_S4_0_0_visit[3]  R330      2
    e2_S4_0_0_visit[3]  R340      -1
    e2_S4_0_0_visit[3]  R341      -1
    e2_S4_0_0_visit[3]  R342      1
    e2_S4_0_0_visit[3]  R381      -26949
    e2_S4_0_0_visit[3]  R382      71100
    e2_S4_0_0_visit[3]  R769      -1
    e2_S4_0_0_visit[3]  R807      1
    e2_S4_0_0_arc[-1,0]  OBJ       3.8275318418009277e+01
    e2_S4_0_0_arc[-1,0]  R325      1
    e2_S4_0_0_arc[-1,0]  R331      1
    e2_S4_0_0_arc[-1,0]  R343      -44319
    e2_S4_0_0_arc[-1,0]  R344      -157
    e2_S4_0_0_arc[-1,0]  R345      180
    e2_S4_0_0_arc[-1,0]  R346      -4
    e2_S4_0_0_arc[-1,0]  R347      6
    e2_S4_0_0_arc[-1,0]  R383      -12
    e2_S4_0_0_arc[-1,0]  R761      1
    e2_S4_0_0_arc[-1,1]  OBJ       3.8275318418009277e+01
    e2_S4_0_0_arc[-1,1]  R325      1
    e2_S4_0_0_arc[-1,1]  R334      1
    e2_S4_0_0_arc[-1,1]  R348      -40749
    e2_S4_0_0_arc[-1,1]  R349      -180
    e2_S4_0_0_arc[-1,1]  R350      176
    e2_S4_0_0_arc[-1,1]  R351      -6
    e2_S4_0_0_arc[-1,1]  R352      4
    e2_S4_0_0_arc[-1,1]  R384      -12
    e2_S4_0_0_arc[-1,1]  R764      1
    e2_S4_0_0_arc[-1,2]  OBJ       8.48528137423857
    e2_S4_0_0_arc[-1,2]  R325      1
    e2_S4_0_0_arc[-1,2]  R337      1
    e2_S4_0_0_arc[-1,2]  R353      -29919
    e2_S4_0_0_arc[-1,2]  R354      -159
    e2_S4_0_0_arc[-1,2]  R355      180
    e2_S4_0_0_arc[-1,2]  R356      -4
    e2_S4_0_0_arc[-1,2]  R357      6
    e2_S4_0_0_arc[-1,2]  R385      -12
    e2_S4_0_0_arc[-1,2]  R767      1
    e2_S4_0_0_arc[-1,3]  OBJ       8.48528137423857
    e2_S4_0_0_arc[-1,3]  R325      1
    e2_S4_0_0_arc[-1,3]  R340      1
    e2_S4_0_0_arc[-1,3]  R358      -28119
    e2_S4_0_0_arc[-1,3]  R359      -180
    e2_S4_0_0_arc[-1,3]  R360      176
    e2_S4_0_0_arc[-1,3]  R361      -6
    e2_S4_0_0_arc[-1,3]  R362      4
    e2_S4_0_0_arc[-1,3]  R386      -12
    e2_S4_0_0_arc[-1,3]  R770      1
    e2_S4_0_0_arc[0,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_0_arc[0,-2]  R326      1
    e2_S4_0_0_arc[0,-2]  R332      1
    e2_S4_0_0_arc[0,-2]  R363      -35709
    e2_S4_0_0_arc[0,-2]  R387      -12
    e2_S4_0_0_arc[0,-2]  R762      1
    e2_S4_0_0_arc[1,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_0_arc[1,-2]  R326      1
    e2_S4_0_0_arc[1,-2]  R335      1
    e2_S4_0_0_arc[1,-2]  R364      -42369
    e2_S4_0_0_arc[1,-2]  R388      -12
    e2_S4_0_0_arc[1,-2]  R765      1
    e2_S4_0_0_arc[2,-2]  OBJ       8.48528137423857
    e2_S4_0_0_arc[2,-2]  R326      1
    e2_S4_0_0_arc[2,-2]  R338      1
    e2_S4_0_0_arc[2,-2]  R365      -48315
    e2_S4_0_0_arc[2,-2]  R389      -12
    e2_S4_0_0_arc[2,-2]  R768      1
    e2_S4_0_0_arc[3,-2]  OBJ       8.48528137423857
    e2_S4_0_0_arc[3,-2]  R326      1
    e2_S4_0_0_arc[3,-2]  R341      1
    e2_S4_0_0_arc[3,-2]  R366      -52275
    e2_S4_0_0_arc[3,-2]  R390      -12
    e2_S4_0_0_arc[3,-2]  R771      1
    m5_link_0  R750      5
    m5_link_0  R751      5
    m5_link_0  R762      1
    m5_link_0  R764      1
    m5_link_0  R773      -157
    m5_link_0  R774      176
    m5_link_0  R775      -4
    m5_link_0  R776      4
    m5_link_0  R777      -12
    m5_link_1  OBJ       3.0805843601498726e+01
    m5_link_1  R752      5
    m5_link_1  R753      5
    m5_link_1  R762      1
    m5_link_1  R770      1
    m5_link_1  R779      -157
    m5_link_1  R780      176
    m5_link_1  R781      -4
    m5_link_1  R782      4
    m5_link_1  R783      -12
    m5_link_2  OBJ       3.0805843601498726e+01
    m5_link_2  R754      5
    m5_link_2  R755      5
    m5_link_2  R765      1
    m5_link_2  R767      1
    m5_link_2  R785      -159
    m5_link_2  R786      176
    m5_link_2  R787      -4
    m5_link_2  R788      4
    m5_link_2  R789      -12
    m5_link_3  OBJ       3.0805843601498726e+01
    m5_link_3  R756      5
    m5_link_3  R757      5
    m5_link_3  R765      1
    m5_link_3  R770      1
    m5_link_3  R791      -180
    m5_link_3  R792      172
    m5_link_3  R793      -6
    m5_link_3  R794      2
    m5_link_3  R795      -12
    m5_link_4  R758      5
    m5_link_4  R759      5
    m5_link_4  R768      1
    m5_link_4  R770      1
    m5_link_4  R796      -264
    m5_link_4  R797      -159
    m5_link_4  R798      176
    m5_link_4  R799      -4
    m5_link_4  R800      4
    m5_link_4  R801      -12
    MARKER    'MARKER'                 'INTEND'
    C427      R383      -1
    C427      R384      -1
    C427      R385      -1
    C427      R386      -1
    C428      R387      1
    C428      R388      1
    C428      R389      1
    C428      R390      1
    C428      R438      -1
    MARKER    'MARKER'                 'INTORG'
    C429      R368      1
    C429      R369      1
    C429      R370      -39660
    C429      R371      -180
    C429      R372      -6
    C429      R377      -1
    C430      R368      1
    C430      R373      1
    C430      R374      -54060
    C430      R375      -180
    C430      R376      -6
    C430      R380      -1
    e2_S4_0_1_used  R391      -75600
    e2_S4_0_1_used  R392      -75600
    e2_S4_0_1_used  R393      -28800
    e2_S4_0_1_used  R394      -1
    e2_S4_0_1_used  R395      -1
    e2_S4_0_1_used  R396      -180
    e2_S4_0_1_used  R397      -6
    e2_S4_0_1_used  R398      -180
    e2_S4_0_1_used  R399      -6
    e2_S4_0_1_used  R402      -1
    e2_S4_0_1_used  R405      -1
    e2_S4_0_1_used  R408      -1
    e2_S4_0_1_used  R411      -1
    e2_S4_0_1_used  R436      -75540
    e2_S4_0_1_used  R437      1
    e2_S4_0_1_used  R438      -12
    e2_S4_0_1_used  R439      -1
    e2_S4_0_1_used  R440      -75600
    e2_S4_0_1_used  R509      -1
    e2_S4_0_1_used  R749      -1
    e2_S4_0_1_start  R391      1
    e2_S4_0_1_start  R393      1
    e2_S4_0_1_start  R412      -1
    e2_S4_0_1_start  R417      -1
    e2_S4_0_1_start  R422      -1
    e2_S4_0_1_start  R427      -1
    e2_S4_0_1_start  R440      1
    e2_S4_0_1_start  R442      1
    e2_S4_0_1_start  R446      1
    e2_S4_0_1_end  R392      1
    e2_S4_0_1_end  R432      1
    e2_S4_0_1_end  R433      1
    e2_S4_0_1_end  R434      1
    e2_S4_0_1_end  R435      1
    e2_S4_0_1_end  R436      1
    e2_S4_0_1_end  R450      -1
    e2_S4_0_1_end  R451      -1
    e2_S4_0_1_end  R453      -1
    e2_S4_0_1_end  R454      -1
    e2_S4_0_1_end  R512      -1
    e2_S4_0_1_visit[0]  R396      23
    e2_S4_0_1_visit[0]  R397      2
    e2_S4_0_1_visit[0]  R400      -1
    e2_S4_0_1_visit[0]  R401      -1
    e2_S4_0_1_visit[0]  R402      1
    e2_S4_0_1_visit[0]  R413      -23
    e2_S4_0_1_visit[0]  R414      -23
    e2_S4_0_1_visit[0]  R415      -2
    e2_S4_0_1_visit[0]  R416      -2
    e2_S4_0_1_visit[0]  R418      -23
    e2_S4_0_1_visit[0]  R419      -23
    e2_S4_0_1_visit[0]  R420      -2
    e2_S4_0_1_visit[0]  R421      -2
    e2_S4_0_1_visit[0]  R423      -23
    e2_S4_0_1_visit[0]  R424      -23
    e2_S4_0_1_visit[0]  R425      -2
    e2_S4_0_1_visit[0]  R426      -2
    e2_S4_0_1_visit[0]  R428      -23
    e2_S4_0_1_visit[0]  R429      -23
    e2_S4_0_1_visit[0]  R430      -2
    e2_S4_0_1_visit[0]  R431      -2
    e2_S4_0_1_visit[0]  R441      -1
    e2_S4_0_1_visit[0]  R443      23
    e2_S4_0_1_visit[0]  R444      2
    e2_S4_0_1_visit[0]  R449      1
    e2_S4_0_1_visit[0]  R760      -2
    e2_S4_0_1_visit[0]  R802      1
    e2_S4_0_1_visit[1]  R398      4
    e2_S4_0_1_visit[1]  R399      2
    e2_S4_0_1_visit[1]  R403      -1
    e2_S4_0_1_visit[1]  R404      -1
    e2_S4_0_1_visit[1]  R405      1
    e2_S4_0_1_visit[1]  R450      -37791
    e2_S4_0_1_visit[1]  R451      71100
    e2_S4_0_1_visit[1]  R763      -2
    e2_S4_0_1_visit[1]  R803      1
    e2_S4_0_1_visit[2]  R396      21
    e2_S4_0_1_visit[2]  R397      2
    e2_S4_0_1_visit[2]  R406      -1
    e2_S4_0_1_visit[2]  R407      -1
    e2_S4_0_1_visit[2]  R408      1
    e2_S4_0_1_visit[2]  R413      -21
    e2_S4_0_1_visit[2]  R414      -21
    e2_S4_0_1_visit[2]  R415      -2
    e2_S4_0_1_visit[2]  R416      -2
    e2_S4_0_1_visit[2]  R418      -21
    e2_S4_0_1_visit[2]  R419      -21
    e2_S4_0_1_visit[2]  R420      -2
    e2_S4_0_1_visit[2]  R421      -2
    e2_S4_0_1_visit[2]  R423      -21
    e2_S4_0_1_visit[2]  R424      -21
    e2_S4_0_1_visit[2]  R425      -2
    e2_S4_0_1_visit[2]  R426      -2
    e2_S4_0_1_visit[2]  R428      -21
    e2_S4_0_1_visit[2]  R429      -21
    e2_S4_0_1_visit[2]  R430      -2
    e2_S4_0_1_visit[2]  R431      -2
    e2_S4_0_1_visit[2]  R445      -1
    e2_S4_0_1_visit[2]  R447      21
    e2_S4_0_1_visit[2]  R448      2
    e2_S4_0_1_visit[2]  R452      1
    e2_S4_0_1_visit[2]  R766      -2
    e2_S4_0_1_visit[2]  R806      1
    e2_S4_0_1_visit[3]  R398      4
    e2_S4_0_1_visit[3]  R399      2
    e2_S4_0_1_visit[3]  R409      -1
    e2_S4_0_1_visit[3]  R410      -1
    e2_S4_0_1_visit[3]  R411      1
    e2_S4_0_1_visit[3]  R453      -26949
    e2_S4_0_1_visit[3]  R454      71100
    e2_S4_0_1_visit[3]  R769      -2
    e2_S4_0_1_visit[3]  R807      1
    e2_S4_0_1_arc[-1,0]  OBJ       3.8275318418009277e+01
    e2_S4_0_1_arc[-1,0]  R394      1
    e2_S4_0_1_arc[-1,0]  R400      1
    e2_S4_0_1_arc[-1,0]  R412      -44319
    e2_S4_0_1_arc[-1,0]  R413      -157
    e2_S4_0_1_arc[-1,0]  R414      180
    e2_S4_0_1_arc[-1,0]  R415      -4
    e2_S4_0_1_arc[-1,0]  R416      6
    e2_S4_0_1_arc[-1,0]  R455      -12
    e2_S4_0_1_arc[-1,0]  R761      1
    e2_S4_0_1_arc[-1,1]  OBJ       3.8275318418009277e+01
    e2_S4_0_1_arc[-1,1]  R394      1
    e2_S4_0_1_arc[-1,1]  R403      1
    e2_S4_0_1_arc[-1,1]  R417      -40749
    e2_S4_0_1_arc[-1,1]  R418      -180
    e2_S4_0_1_arc[-1,1]  R419      176
    e2_S4_0_1_arc[-1,1]  R420      -6
    e2_S4_0_1_arc[-1,1]  R421      4
    e2_S4_0_1_arc[-1,1]  R456      -12
    e2_S4_0_1_arc[-1,1]  R764      1
    e2_S4_0_1_arc[-1,2]  OBJ       8.48528137423857
    e2_S4_0_1_arc[-1,2]  R394      1
    e2_S4_0_1_arc[-1,2]  R406      1
    e2_S4_0_1_arc[-1,2]  R422      -29919
    e2_S4_0_1_arc[-1,2]  R423      -159
    e2_S4_0_1_arc[-1,2]  R424      180
    e2_S4_0_1_arc[-1,2]  R425      -4
    e2_S4_0_1_arc[-1,2]  R426      6
    e2_S4_0_1_arc[-1,2]  R457      -12
    e2_S4_0_1_arc[-1,2]  R767      1
    e2_S4_0_1_arc[-1,3]  OBJ       8.48528137423857
    e2_S4_0_1_arc[-1,3]  R394      1
    e2_S4_0_1_arc[-1,3]  R409      1
    e2_S4_0_1_arc[-1,3]  R427      -28119
    e2_S4_0_1_arc[-1,3]  R428      -180
    e2_S4_0_1_arc[-1,3]  R429      176
    e2_S4_0_1_arc[-1,3]  R430      -6
    e2_S4_0_1_arc[-1,3]  R431      4
    e2_S4_0_1_arc[-1,3]  R458      -12
    e2_S4_0_1_arc[-1,3]  R770      1
    e2_S4_0_1_arc[0,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_1_arc[0,-2]  R395      1
    e2_S4_0_1_arc[0,-2]  R401      1
    e2_S4_0_1_arc[0,-2]  R432      -35709
    e2_S4_0_1_arc[0,-2]  R459      -12
    e2_S4_0_1_arc[0,-2]  R762      1
    e2_S4_0_1_arc[1,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_1_arc[1,-2]  R395      1
    e2_S4_0_1_arc[1,-2]  R404      1
    e2_S4_0_1_arc[1,-2]  R433      -42369
    e2_S4_0_1_arc[1,-2]  R460      -12
    e2_S4_0_1_arc[1,-2]  R765      1
    e2_S4_0_1_arc[2,-2]  OBJ       8.48528137423857
    e2_S4_0_1_arc[2,-2]  R395      1
    e2_S4_0_1_arc[2,-2]  R407      1
    e2_S4_0_1_arc[2,-2]  R434      -48315
    e2_S4_0_1_arc[2,-2]  R461      -12
    e2_S4_0_1_arc[2,-2]  R768      1
    e2_S4_0_1_arc[3,-2]  OBJ       8.48528137423857
    e2_S4_0_1_arc[3,-2]  R395      1
    e2_S4_0_1_arc[3,-2]  R410      1
    e2_S4_0_1_arc[3,-2]  R435      -52275
    e2_S4_0_1_arc[3,-2]  R462      -12
    e2_S4_0_1_arc[3,-2]  R771      1
    MARKER    'MARKER'                 'INTEND'
    C446      R438      1
    C446      R455      -1
    C446      R456      -1
    C446      R457      -1
    C446      R458      -1
    C447      R459      1
    C447      R460      1
    C447      R461      1
    C447      R462      1
    C447      R510      -1
    MARKER    'MARKER'                 'INTORG'
    C448      R439      1
    C448      R440      -60
    C448      R441      1
    C448      R442      -39660
    C448      R443      -180
    C448      R444      -6
    C448      R449      -1
    C449      R439      1
    C449      R440      -60
    C449      R445      1
    C449      R446      -54060
    C449      R447      -180
    C449      R448      -6
    C449      R452      -1
    e2_S4_0_2_used  R463      -75600
    e2_S4_0_2_used  R464      -75600
    e2_S4_0_2_used  R465      -28800
    e2_S4_0_2_used  R466      -1
    e2_S4_0_2_used  R467      -1
    e2_S4_0_2_used  R468      -180
    e2_S4_0_2_used  R469      -6
    e2_S4_0_2_used  R470      -180
    e2_S4_0_2_used  R471      -6
    e2_S4_0_2_used  R474      -1
    e2_S4_0_2_used  R477      -1
    e2_S4_0_2_used  R480      -1
    e2_S4_0_2_used  R483      -1
    e2_S4_0_2_used  R508      -75540
    e2_S4_0_2_used  R509      1
    e2_S4_0_2_used  R510      -12
    e2_S4_0_2_used  R511      -1
    e2_S4_0_2_used  R512      -75600
    e2_S4_0_2_used  R581      -1
    e2_S4_0_2_used  R749      -1
    e2_S4_0_2_start  R463      1
    e2_S4_0_2_start  R465      1
    e2_S4_0_2_start  R484      -1
    e2_S4_0_2_start  R489      -1
    e2_S4_0_2_start  R494      -1
    e2_S4_0_2_start  R499      -1
    e2_S4_0_2_start  R512      1
    e2_S4_0_2_start  R514      1
    e2_S4_0_2_start  R518      1
    e2_S4_0_2_end  R464      1
    e2_S4_0_2_end  R504      1
    e2_S4_0_2_end  R505      1
    e2_S4_0_2_end  R506      1
    e2_S4_0_2_end  R507      1
    e2_S4_0_2_end  R508      1
    e2_S4_0_2_end  R522      -1
    e2_S4_0_2_end  R523      -1
    e2_S4_0_2_end  R525      -1
    e2_S4_0_2_end  R526      -1
    e2_S4_0_2_end  R584      -1
    e2_S4_0_2_visit[0]  R468      23
    e2_S4_0_2_visit[0]  R469      2
    e2_S4_0_2_visit[0]  R472      -1
    e2_S4_0_2_visit[0]  R473      -1
    e2_S4_0_2_visit[0]  R474      1
    e2_S4_0_2_visit[0]  R485      -23
    e2_S4_0_2_visit[0]  R486      -23
    e2_S4_0_2_visit[0]  R487      -2
    e2_S4_0_2_visit[0]  R488      -2
    e2_S4_0_2_visit[0]  R490      -23
    e2_S4_0_2_visit[0]  R491      -23
    e2_S4_0_2_visit[0]  R492      -2
    e2_S4_0_2_visit[0]  R493      -2
    e2_S4_0_2_visit[0]  R495      -23
    e2_S4_0_2_visit[0]  R496      -23
    e2_S4_0_2_visit[0]  R497      -2
    e2_S4_0_2_visit[0]  R498      -2
    e2_S4_0_2_visit[0]  R500      -23
    e2_S4_0_2_visit[0]  R501      -23
    e2_S4_0_2_visit[0]  R502      -2
    e2_S4_0_2_visit[0]  R503      -2
    e2_S4_0_2_visit[0]  R513      -1
    e2_S4_0_2_visit[0]  R515      23
    e2_S4_0_2_visit[0]  R516      2
    e2_S4_0_2_visit[0]  R521      1
    e2_S4_0_2_visit[0]  R760      -3
    e2_S4_0_2_visit[0]  R802      1
    e2_S4_0_2_visit[1]  R470      4
    e2_S4_0_2_visit[1]  R471      2
    e2_S4_0_2_visit[1]  R475      -1
    e2_S4_0_2_visit[1]  R476      -1
    e2_S4_0_2_visit[1]  R477      1
    e2_S4_0_2_visit[1]  R522      -37791
    e2_S4_0_2_visit[1]  R523      71100
    e2_S4_0_2_visit[1]  R763      -3
    e2_S4_0_2_visit[1]  R803      1
    e2_S4_0_2_visit[2]  R468      21
    e2_S4_0_2_visit[2]  R469      2
    e2_S4_0_2_visit[2]  R478      -1
    e2_S4_0_2_visit[2]  R479      -1
    e2_S4_0_2_visit[2]  R480      1
    e2_S4_0_2_visit[2]  R485      -21
    e2_S4_0_2_visit[2]  R486      -21
    e2_S4_0_2_visit[2]  R487      -2
    e2_S4_0_2_visit[2]  R488      -2
    e2_S4_0_2_visit[2]  R490      -21
    e2_S4_0_2_visit[2]  R491      -21
    e2_S4_0_2_visit[2]  R492      -2
    e2_S4_0_2_visit[2]  R493      -2
    e2_S4_0_2_visit[2]  R495      -21
    e2_S4_0_2_visit[2]  R496      -21
    e2_S4_0_2_visit[2]  R497      -2
    e2_S4_0_2_visit[2]  R498      -2
    e2_S4_0_2_visit[2]  R500      -21
    e2_S4_0_2_visit[2]  R501      -21
    e2_S4_0_2_visit[2]  R502      -2
    e2_S4_0_2_visit[2]  R503      -2
    e2_S4_0_2_visit[2]  R517      -1
    e2_S4_0_2_visit[2]  R519      21
    e2_S4_0_2_visit[2]  R520      2
    e2_S4_0_2_visit[2]  R524      1
    e2_S4_0_2_visit[2]  R766      -3
    e2_S4_0_2_visit[2]  R806      1
    e2_S4_0_2_visit[3]  R470      4
    e2_S4_0_2_visit[3]  R471      2
    e2_S4_0_2_visit[3]  R481      -1
    e2_S4_0_2_visit[3]  R482      -1
    e2_S4_0_2_visit[3]  R483      1
    e2_S4_0_2_visit[3]  R525      -26949
    e2_S4_0_2_visit[3]  R526      71100
    e2_S4_0_2_visit[3]  R769      -3
    e2_S4_0_2_visit[3]  R807      1
    e2_S4_0_2_arc[-1,0]  OBJ       3.8275318418009277e+01
    e2_S4_0_2_arc[-1,0]  R466      1
    e2_S4_0_2_arc[-1,0]  R472      1
    e2_S4_0_2_arc[-1,0]  R484      -44319
    e2_S4_0_2_arc[-1,0]  R485      -157
    e2_S4_0_2_arc[-1,0]  R486      180
    e2_S4_0_2_arc[-1,0]  R487      -4
    e2_S4_0_2_arc[-1,0]  R488      6
    e2_S4_0_2_arc[-1,0]  R527      -12
    e2_S4_0_2_arc[-1,0]  R761      1
    e2_S4_0_2_arc[-1,1]  OBJ       3.8275318418009277e+01
    e2_S4_0_2_arc[-1,1]  R466      1
    e2_S4_0_2_arc[-1,1]  R475      1
    e2_S4_0_2_arc[-1,1]  R489      -40749
    e2_S4_0_2_arc[-1,1]  R490      -180
    e2_S4_0_2_arc[-1,1]  R491      176
    e2_S4_0_2_arc[-1,1]  R492      -6
    e2_S4_0_2_arc[-1,1]  R493      4
    e2_S4_0_2_arc[-1,1]  R528      -12
    e2_S4_0_2_arc[-1,1]  R764      1
    e2_S4_0_2_arc[-1,2]  OBJ       8.48528137423857
    e2_S4_0_2_arc[-1,2]  R466      1
    e2_S4_0_2_arc[-1,2]  R478      1
    e2_S4_0_2_arc[-1,2]  R494      -29919
    e2_S4_0_2_arc[-1,2]  R495      -159
    e2_S4_0_2_arc[-1,2]  R496      180
    e2_S4_0_2_arc[-1,2]  R497      -4
    e2_S4_0_2_arc[-1,2]  R498      6
    e2_S4_0_2_arc[-1,2]  R529      -12
    e2_S4_0_2_arc[-1,2]  R767      1
    e2_S4_0_2_arc[-1,3]  OBJ       8.48528137423857
    e2_S4_0_2_arc[-1,3]  R466      1
    e2_S4_0_2_arc[-1,3]  R481      1
    e2_S4_0_2_arc[-1,3]  R499      -28119
    e2_S4_0_2_arc[-1,3]  R500      -180
    e2_S4_0_2_arc[-1,3]  R501      176
    e2_S4_0_2_arc[-1,3]  R502      -6
    e2_S4_0_2_arc[-1,3]  R503      4
    e2_S4_0_2_arc[-1,3]  R530      -12
    e2_S4_0_2_arc[-1,3]  R770      1
    e2_S4_0_2_arc[0,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_2_arc[0,-2]  R467      1
    e2_S4_0_2_arc[0,-2]  R473      1
    e2_S4_0_2_arc[0,-2]  R504      -35709
    e2_S4_0_2_arc[0,-2]  R531      -12
    e2_S4_0_2_arc[0,-2]  R762      1
    e2_S4_0_2_arc[1,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_2_arc[1,-2]  R467      1
    e2_S4_0_2_arc[1,-2]  R476      1
    e2_S4_0_2_arc[1,-2]  R505      -42369
    e2_S4_0_2_arc[1,-2]  R532      -12
    e2_S4_0_2_arc[1,-2]  R765      1
    e2_S4_0_2_arc[2,-2]  OBJ       8.48528137423857
    e2_S4_0_2_arc[2,-2]  R467      1
    e2_S4_0_2_arc[2,-2]  R479      1
    e2_S4_0_2_arc[2,-2]  R506      -48315
    e2_S4_0_2_arc[2,-2]  R533      -12
    e2_S4_0_2_arc[2,-2]  R768      1
    e2_S4_0_2_arc[3,-2]  OBJ       8.48528137423857
    e2_S4_0_2_arc[3,-2]  R467      1
    e2_S4_0_2_arc[3,-2]  R482      1
    e2_S4_0_2_arc[3,-2]  R507      -52275
    e2_S4_0_2_arc[3,-2]  R534      -12
    e2_S4_0_2_arc[3,-2]  R771      1
    MARKER    'MARKER'                 'INTEND'
    C465      R510      1
    C465      R527      -1
    C465      R528      -1
    C465      R529      -1
    C465      R530      -1
    C466      R531      1
    C466      R532      1
    C466      R533      1
    C466      R534      1
    C466      R582      -1
    MARKER    'MARKER'                 'INTORG'
    C467      R511      1
    C467      R512      -60
    C467      R513      1
    C467      R514      -39660
    C467      R515      -180
    C467      R516      -6
    C467      R521      -1
    C468      R511      1
    C468      R512      -60
    C468      R517      1
    C468      R518      -54060
    C468      R519      -180
    C468      R520      -6
    C468      R524      -1
    e2_S4_0_3_used  R535      -75600
    e2_S4_0_3_used  R536      -75600
    e2_S4_0_3_used  R537      -28800
    e2_S4_0_3_used  R538      -1
    e2_S4_0_3_used  R539      -1
    e2_S4_0_3_used  R540      -180
    e2_S4_0_3_used  R541      -6
    e2_S4_0_3_used  R542      -180
    e2_S4_0_3_used  R543      -6
    e2_S4_0_3_used  R546      -1
    e2_S4_0_3_used  R549      -1
    e2_S4_0_3_used  R552      -1
    e2_S4_0_3_used  R555      -1
    e2_S4_0_3_used  R580      -75540
    e2_S4_0_3_used  R581      1
    e2_S4_0_3_used  R582      -12
    e2_S4_0_3_used  R583      -1
    e2_S4_0_3_used  R584      -75600
    e2_S4_0_3_used  R749      -1
    e2_S4_0_3_start  R535      1
    e2_S4_0_3_start  R537      1
    e2_S4_0_3_start  R556      -1
    e2_S4_0_3_start  R561      -1
    e2_S4_0_3_start  R566      -1
    e2_S4_0_3_start  R571      -1
    e2_S4_0_3_start  R584      1
    e2_S4_0_3_start  R586      1
    e2_S4_0_3_start  R590      1
    e2_S4_0_3_end  R536      1
    e2_S4_0_3_end  R576      1
    e2_S4_0_3_end  R577      1
    e2_S4_0_3_end  R578      1
    e2_S4_0_3_end  R579      1
    e2_S4_0_3_end  R580      1
    e2_S4_0_3_end  R594      -1
    e2_S4_0_3_end  R595      -1
    e2_S4_0_3_end  R597      -1
    e2_S4_0_3_end  R598      -1
    e2_S4_0_3_visit[0]  R540      23
    e2_S4_0_3_visit[0]  R541      2
    e2_S4_0_3_visit[0]  R544      -1
    e2_S4_0_3_visit[0]  R545      -1
    e2_S4_0_3_visit[0]  R546      1
    e2_S4_0_3_visit[0]  R557      -23
    e2_S4_0_3_visit[0]  R558      -23
    e2_S4_0_3_visit[0]  R559      -2
    e2_S4_0_3_visit[0]  R560      -2
    e2_S4_0_3_visit[0]  R562      -23
    e2_S4_0_3_visit[0]  R563      -23
    e2_S4_0_3_visit[0]  R564      -2
    e2_S4_0_3_visit[0]  R565      -2
    e2_S4_0_3_visit[0]  R567      -23
    e2_S4_0_3_visit[0]  R568      -23
    e2_S4_0_3_visit[0]  R569      -2
    e2_S4_0_3_visit[0]  R570      -2
    e2_S4_0_3_visit[0]  R572      -23
    e2_S4_0_3_visit[0]  R573      -23
    e2_S4_0_3_visit[0]  R574      -2
    e2_S4_0_3_visit[0]  R575      -2
    e2_S4_0_3_visit[0]  R585      -1
    e2_S4_0_3_visit[0]  R587      23
    e2_S4_0_3_visit[0]  R588      2
    e2_S4_0_3_visit[0]  R593      1
    e2_S4_0_3_visit[0]  R760      -4
    e2_S4_0_3_visit[0]  R802      1
    e2_S4_0_3_visit[1]  R542      4
    e2_S4_0_3_visit[1]  R543      2
    e2_S4_0_3_visit[1]  R547      -1
    e2_S4_0_3_visit[1]  R548      -1
    e2_S4_0_3_visit[1]  R549      1
    e2_S4_0_3_visit[1]  R594      -37791
    e2_S4_0_3_visit[1]  R595      71100
    e2_S4_0_3_visit[1]  R763      -4
    e2_S4_0_3_visit[1]  R803      1
    e2_S4_0_3_visit[2]  R540      21
    e2_S4_0_3_visit[2]  R541      2
    e2_S4_0_3_visit[2]  R550      -1
    e2_S4_0_3_visit[2]  R551      -1
    e2_S4_0_3_visit[2]  R552      1
    e2_S4_0_3_visit[2]  R557      -21
    e2_S4_0_3_visit[2]  R558      -21
    e2_S4_0_3_visit[2]  R559      -2
    e2_S4_0_3_visit[2]  R560      -2
    e2_S4_0_3_visit[2]  R562      -21
    e2_S4_0_3_visit[2]  R563      -21
    e2_S4_0_3_visit[2]  R564      -2
    e2_S4_0_3_visit[2]  R565      -2
    e2_S4_0_3_visit[2]  R567      -21
    e2_S4_0_3_visit[2]  R568      -21
    e2_S4_0_3_visit[2]  R569      -2
    e2_S4_0_3_visit[2]  R570      -2
    e2_S4_0_3_visit[2]  R572      -21
    e2_S4_0_3_visit[2]  R573      -21
    e2_S4_0_3_visit[2]  R574      -2
    e2_S4_0_3_visit[2]  R575      -2
    e2_S4_0_3_visit[2]  R589      -1
    e2_S4_0_3_visit[2]  R591      21
    e2_S4_0_3_visit[2]  R592      2
    e2_S4_0_3_visit[2]  R596      1
    e2_S4_0_3_visit[2]  R766      -4
    e2_S4_0_3_visit[2]  R806      1
    e2_S4_0_3_visit[3]  R542      4
    e2_S4_0_3_visit[3]  R543      2
    e2_S4_0_3_visit[3]  R553      -1
    e2_S4_0_3_visit[3]  R554      -1
    e2_S4_0_3_visit[3]  R555      1
    e2_S4_0_3_visit[3]  R597      -26949
    e2_S4_0_3_visit[3]  R598      71100
    e2_S4_0_3_visit[3]  R769      -4
    e2_S4_0_3_visit[3]  R807      1
    e2_S4_0_3_arc[-1,0]  OBJ       3.8275318418009277e+01
    e2_S4_0_3_arc[-1,0]  R538      1
    e2_S4_0_3_arc[-1,0]  R544      1
    e2_S4_0_3_arc[-1,0]  R556      -44319
    e2_S4_0_3_arc[-1,0]  R557      -157
    e2_S4_0_3_arc[-1,0]  R558      180
    e2_S4_0_3_arc[-1,0]  R559      -4
    e2_S4_0_3_arc[-1,0]  R560      6
    e2_S4_0_3_arc[-1,0]  R599      -12
    e2_S4_0_3_arc[-1,0]  R761      1
    e2_S4_0_3_arc[-1,1]  OBJ       3.8275318418009277e+01
    e2_S4_0_3_arc[-1,1]  R538      1
    e2_S4_0_3_arc[-1,1]  R547      1
    e2_S4_0_3_arc[-1,1]  R561      -40749
    e2_S4_0_3_arc[-1,1]  R562      -180
    e2_S4_0_3_arc[-1,1]  R563      176
    e2_S4_0_3_arc[-1,1]  R564      -6
    e2_S4_0_3_arc[-1,1]  R565      4
    e2_S4_0_3_arc[-1,1]  R600      -12
    e2_S4_0_3_arc[-1,1]  R764      1
    e2_S4_0_3_arc[-1,2]  OBJ       8.48528137423857
    e2_S4_0_3_arc[-1,2]  R538      1
    e2_S4_0_3_arc[-1,2]  R550      1
    e2_S4_0_3_arc[-1,2]  R566      -29919
    e2_S4_0_3_arc[-1,2]  R567      -159
    e2_S4_0_3_arc[-1,2]  R568      180
    e2_S4_0_3_arc[-1,2]  R569      -4
    e2_S4_0_3_arc[-1,2]  R570      6
    e2_S4_0_3_arc[-1,2]  R601      -12
    e2_S4_0_3_arc[-1,2]  R767      1
    e2_S4_0_3_arc[-1,3]  OBJ       8.48528137423857
    e2_S4_0_3_arc[-1,3]  R538      1
    e2_S4_0_3_arc[-1,3]  R553      1
    e2_S4_0_3_arc[-1,3]  R571      -28119
    e2_S4_0_3_arc[-1,3]  R572      -180
    e2_S4_0_3_arc[-1,3]  R573      176
    e2_S4_0_3_arc[-1,3]  R574      -6
    e2_S4_0_3_arc[-1,3]  R575      4
    e2_S4_0_3_arc[-1,3]  R602      -12
    e2_S4_0_3_arc[-1,3]  R770      1
    e2_S4_0_3_arc[0,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_3_arc[0,-2]  R539      1
    e2_S4_0_3_arc[0,-2]  R545      1
    e2_S4_0_3_arc[0,-2]  R576      -35709
    e2_S4_0_3_arc[0,-2]  R603      -12
    e2_S4_0_3_arc[0,-2]  R762      1
    e2_S4_0_3_arc[1,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_3_arc[1,-2]  R539      1
    e2_S4_0_3_arc[1,-2]  R548      1
    e2_S4_0_3_arc[1,-2]  R577      -42369
    e2_S4_0_3_arc[1,-2]  R604      -12
    e2_S4_0_3_arc[1,-2]  R765      1
    e2_S4_0_3_arc[2,-2]  OBJ       8.48528137423857
    e2_S4_0_3_arc[2,-2]  R539      1
    e2_S4_0_3_arc[2,-2]  R551      1
    e2_S4_0_3_arc[2,-2]  R578      -48315
    e2_S4_0_3_arc[2,-2]  R605      -12
    e2_S4_0_3_arc[2,-2]  R768      1
    e2_S4_0_3_arc[3,-2]  OBJ       8.48528137423857
    e2_S4_0_3_arc[3,-2]  R539      1
    e2_S4_0_3_arc[3,-2]  R554      1
    e2_S4_0_3_arc[3,-2]  R579      -52275
    e2_S4_0_3_arc[3,-2]  R606      -12
    e2_S4_0_3_arc[3,-2]  R771      1
    MARKER    'MARKER'                 'INTEND'
    C484      R582      1
    C484      R599      -1
    C484      R600      -1
    C484      R601      -1
    C484      R602      -1
    C485      R603      1
    C485      R604      1
    C485      R605      1
    C485      R606      1
    MARKER    'MARKER'                 'INTORG'
    C486      R583      1
    C486      R584      -60
    C486      R585      1
    C486      R586      -39660
    C486      R587      -180
    C486      R588      -6
    C486      R593      -1
    C487      R583      1
    C487      R584      -60
    C487      R589      1
    C487      R590      -54060
    C487      R591      -180
    C487      R592      -6
    C487      R596      -1
    e2_S4_1_0_used  R607      -75600
    e2_S4_1_0_used  R608      -75600
    e2_S4_1_0_used  R609      -28800
    e2_S4_1_0_used  R610      -1
    e2_S4_1_0_used  R611      -1
    e2_S4_1_0_used  R612      -180
    e2_S4_1_0_used  R613      -6
    e2_S4_1_0_used  R614      -180
    e2_S4_1_0_used  R615      -6
    e2_S4_1_0_used  R618      -1
    e2_S4_1_0_used  R621      -1
    e2_S4_1_0_used  R624      -1
    e2_S4_1_0_used  R627      -1
    e2_S4_1_0_used  R652      1
    e2_S4_1_0_used  R653      -75540
    e2_S4_1_0_used  R654      -1
    e2_S4_1_0_used  R723      -1
    e2_S4_1_0_used  R749      1
    e2_S4_1_0_start  R607      1
    e2_S4_1_0_start  R609      1
    e2_S4_1_0_start  R628      -1
    e2_S4_1_0_start  R633      -1
    e2_S4_1_0_start  R638      -1
    e2_S4_1_0_start  R643      -1
    e2_S4_1_0_start  R656      1
    e2_S4_1_0_start  R660      1
    e2_S4_1_0_end  R608      1
    e2_S4_1_0_end  R648      1
    e2_S4_1_0_end  R649      1
    e2_S4_1_0_end  R650      1
    e2_S4_1_0_end  R651      1
    e2_S4_1_0_end  R653      1
    e2_S4_1_0_end  R664      -1
    e2_S4_1_0_end  R665      -1
    e2_S4_1_0_end  R667      -1
    e2_S4_1_0_end  R668      -1
    e2_S4_1_0_end  R726      -1
    e2_S4_1_0_visit[0]  R612      23
    e2_S4_1_0_visit[0]  R613      2
    e2_S4_1_0_visit[0]  R616      -1
    e2_S4_1_0_visit[0]  R617      -1
    e2_S4_1_0_visit[0]  R618      1
    e2_S4_1_0_visit[0]  R629      -23
    e2_S4_1_0_visit[0]  R630      -23
    e2_S4_1_0_visit[0]  R631      -2
    e2_S4_1_0_visit[0]  R632      -2
    e2_S4_1_0_visit[0]  R634      -23
    e2_S4_1_0_visit[0]  R635      -23
    e2_S4_1_0_visit[0]  R636      -2
    e2_S4_1_0_visit[0]  R637      -2
    e2_S4_1_0_visit[0]  R639      -23
    e2_S4_1_0_visit[0]  R640      -23
    e2_S4_1_0_visit[0]  R641      -2
    e2_S4_1_0_visit[0]  R642      -2
    e2_S4_1_0_visit[0]  R644      -23
    e2_S4_1_0_visit[0]  R645      -23
    e2_S4_1_0_visit[0]  R646      -2
    e2_S4_1_0_visit[0]  R647      -2
    e2_S4_1_0_visit[0]  R655      -1
    e2_S4_1_0_visit[0]  R657      23
    e2_S4_1_0_visit[0]  R658      2
    e2_S4_1_0_visit[0]  R663      1
    e2_S4_1_0_visit[0]  R760      -5
    e2_S4_1_0_visit[0]  R802      1
    e2_S4_1_0_visit[1]  R614      4
    e2_S4_1_0_visit[1]  R615      2
    e2_S4_1_0_visit[1]  R619      -1
    e2_S4_1_0_visit[1]  R620      -1
    e2_S4_1_0_visit[1]  R621      1
    e2_S4_1_0_visit[1]  R664      -37791
    e2_S4_1_0_visit[1]  R665      71100
    e2_S4_1_0_visit[1]  R763      -5
    e2_S4_1_0_visit[1]  R803      1
    e2_S4_1_0_visit[2]  R612      21
    e2_S4_1_0_visit[2]  R613      2
    e2_S4_1_0_visit[2]  R622      -1
    e2_S4_1_0_visit[2]  R623      -1
    e2_S4_1_0_visit[2]  R624      1
    e2_S4_1_0_visit[2]  R629      -21
    e2_S4_1_0_visit[2]  R630      -21
    e2_S4_1_0_visit[2]  R631      -2
    e2_S4_1_0_visit[2]  R632      -2
    e2_S4_1_0_visit[2]  R634      -21
    e2_S4_1_0_visit[2]  R635      -21
    e2_S4_1_0_visit[2]  R636      -2
    e2_S4_1_0_visit[2]  R637      -2
    e2_S4_1_0_visit[2]  R639      -21
    e2_S4_1_0_visit[2]  R640      -21
    e2_S4_1_0_visit[2]  R641      -2
    e2_S4_1_0_visit[2]  R642      -2
    e2_S4_1_0_visit[2]  R644      -21
    e2_S4_1_0_visit[2]  R645      -21
    e2_S4_1_0_visit[2]  R646      -2
    e2_S4_1_0_visit[2]  R647      -2
    e2_S4_1_0_visit[2]  R659      -1
    e2_S4_1_0_visit[2]  R661      21
    e2_S4_1_0_visit[2]  R662      2
    e2_S4_1_0_visit[2]  R666      1
    e2_S4_1_0_visit[2]  R766      -5
    e2_S4_1_0_visit[2]  R806      1
    e2_S4_1_0_visit[3]  R614      4
    e2_S4_1_0_visit[3]  R615      2
    e2_S4_1_0_visit[3]  R625      -1
    e2_S4_1_0_visit[3]  R626      -1
    e2_S4_1_0_visit[3]  R627      1
    e2_S4_1_0_visit[3]  R667      -26949
    e2_S4_1_0_visit[3]  R668      71100
    e2_S4_1_0_visit[3]  R769      -5
    e2_S4_1_0_visit[3]  R807      1
    e2_S4_1_0_arc[-1,0]  OBJ       3.8275318418009277e+01
    e2_S4_1_0_arc[-1,0]  R610      1
    e2_S4_1_0_arc[-1,0]  R616      1
    e2_S4_1_0_arc[-1,0]  R628      -44319
    e2_S4_1_0_arc[-1,0]  R629      -157
    e2_S4_1_0_arc[-1,0]  R630      180
    e2_S4_1_0_arc[-1,0]  R631      -4
    e2_S4_1_0_arc[-1,0]  R632      6
    e2_S4_1_0_arc[-1,0]  R669      -12
    e2_S4_1_0_arc[-1,0]  R761      1
    e2_S4_1_0_arc[-1,1]  OBJ       3.8275318418009277e+01
    e2_S4_1_0_arc[-1,1]  R610      1
    e2_S4_1_0_arc[-1,1]  R619      1
    e2_S4_1_0_arc[-1,1]  R633      -40749
    e2_S4_1_0_arc[-1,1]  R634      -180
    e2_S4_1_0_arc[-1,1]  R635      176
    e2_S4_1_0_arc[-1,1]  R636      -6
    e2_S4_1_0_arc[-1,1]  R637      4
    e2_S4_1_0_arc[-1,1]  R670      -12
    e2_S4_1_0_arc[-1,1]  R764      1
    e2_S4_1_0_arc[-1,2]  OBJ       8.48528137423857
    e2_S4_1_0_arc[-1,2]  R610      1
    e2_S4_1_0_arc[-1,2]  R622      1
    e2_S4_1_0_arc[-1,2]  R638      -29919
    e2_S4_1_0_arc[-1,2]  R639      -159
    e2_S4_1_0_arc[-1,2]  R640      180
    e2_S4_1_0_arc[-1,2]  R641      -4
    e2_S4_1_0_arc[-1,2]  R642      6
    e2_S4_1_0_arc[-1,2]  R671      -12
    e2_S4_1_0_arc[-1,2]  R767      1
    e2_S4_1_0_arc[-1,3]  OBJ       8.48528137423857
    e2_S4_1_0_arc[-1,3]  R610      1
    e2_S4_1_0_arc[-1,3]  R625      1
    e2_S4_1_0_arc[-1,3]  R643      -28119
    e2_S4_1_0_arc[-1,3]  R644      -180
    e2_S4_1_0_arc[-1,3]  R645      176
    e2_S4_1_0_arc[-1,3]  R646      -6
    e2_S4_1_0_arc[-1,3]  R647      4
    e2_S4_1_0_arc[-1,3]  R672      -12
    e2_S4_1_0_arc[-1,3]  R770      1
    e2_S4_1_0_arc[0,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_0_arc[0,-2]  R611      1
    e2_S4_1_0_arc[0,-2]  R617      1
    e2_S4_1_0_arc[0,-2]  R648      -35709
    e2_S4_1_0_arc[0,-2]  R673      -12
    e2_S4_1_0_arc[0,-2]  R762      1
    e2_S4_1_0_arc[1,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_0_arc[1,-2]  R611      1
    e2_S4_1_0_arc[1,-2]  R620      1
    e2_S4_1_0_arc[1,-2]  R649      -42369
    e2_S4_1_0_arc[1,-2]  R674      -12
    e2_S4_1_0_arc[1,-2]  R765      1
    e2_S4_1_0_arc[2,-2]  OBJ       8.48528137423857
    e2_S4_1_0_arc[2,-2]  R611      1
    e2_S4_1_0_arc[2,-2]  R623      1
    e2_S4_1_0_arc[2,-2]  R650      -48315
    e2_S4_1_0_arc[2,-2]  R675      -12
    e2_S4_1_0_arc[2,-2]  R768      1
    e2_S4_1_0_arc[3,-2]  OBJ       8.48528137423857
    e2_S4_1_0_arc[3,-2]  R611      1
    e2_S4_1_0_arc[3,-2]  R626      1
    e2_S4_1_0_arc[3,-2]  R651      -52275
    e2_S4_1_0_arc[3,-2]  R676      -12
    e2_S4_1_0_arc[3,-2]  R771      1
    MARKER    'MARKER'                 'INTEND'
    C503      R669      -1
    C503      R670      -1
    C503      R671      -1
    C503      R672      -1
    C504      R673      1
    C504      R674      1
    C504      R675      1
    C504      R676      1
    C504      R724      -1
    MARKER    'MARKER'                 'INTORG'
    C505      R654      1
    C505      R655      1
    C505      R656      -39660
    C505      R657      -180
    C505      R658      -6
    C505      R663      -1
    C506      R654      1
    C506      R659      1
    C506      R660      -54060
    C506      R661      -180
    C506      R662      -6
    C506      R666      -1
    e2_S4_1_1_used  R677      -75600
    e2_S4_1_1_used  R678      -75600
    e2_S4_1_1_used  R679      -28800
    e2_S4_1_1_used  R680      -1
    e2_S4_1_1_used  R681      -1
    e2_S4_1_1_used  R682      -180
    e2_S4_1_1_used  R683      -6
    e2_S4_1_1_used  R684      -180
    e2_S4_1_1_used  R685      -6
    e2_S4_1_1_used  R688      -1
    e2_S4_1_1_used  R691      -1
    e2_S4_1_1_used  R694      -1
    e2_S4_1_1_used  R697      -1
    e2_S4_1_1_used  R722      -75540
    e2_S4_1_1_used  R723      1
    e2_S4_1_1_used  R724      -12
    e2_S4_1_1_used  R725      -1
    e2_S4_1_1_used  R726      -75600
    e2_S4_1_1_used  R749      1
    e2_S4_1_1_start  R677      1
    e2_S4_1_1_start  R679      1
    e2_S4_1_1_start  R698      -1
    e2_S4_1_1_start  R703      -1
    e2_S4_1_1_start  R708      -1
    e2_S4_1_1_start  R713      -1
    e2_S4_1_1_start  R726      1
    e2_S4_1_1_start  R728      1
    e2_S4_1_1_start  R732      1
    e2_S4_1_1_end  R678      1
    e2_S4_1_1_end  R718      1
    e2_S4_1_1_end  R719      1
    e2_S4_1_1_end  R720      1
    e2_S4_1_1_end  R721      1
    e2_S4_1_1_end  R722      1
    e2_S4_1_1_end  R736      -1
    e2_S4_1_1_end  R737      -1
    e2_S4_1_1_end  R739      -1
    e2_S4_1_1_end  R740      -1
    e2_S4_1_1_visit[0]  R682      23
    e2_S4_1_1_visit[0]  R683      2
    e2_S4_1_1_visit[0]  R686      -1
    e2_S4_1_1_visit[0]  R687      -1
    e2_S4_1_1_visit[0]  R688      1
    e2_S4_1_1_visit[0]  R699      -23
    e2_S4_1_1_visit[0]  R700      -23
    e2_S4_1_1_visit[0]  R701      -2
    e2_S4_1_1_visit[0]  R702      -2
    e2_S4_1_1_visit[0]  R704      -23
    e2_S4_1_1_visit[0]  R705      -23
    e2_S4_1_1_visit[0]  R706      -2
    e2_S4_1_1_visit[0]  R707      -2
    e2_S4_1_1_visit[0]  R709      -23
    e2_S4_1_1_visit[0]  R710      -23
    e2_S4_1_1_visit[0]  R711      -2
    e2_S4_1_1_visit[0]  R712      -2
    e2_S4_1_1_visit[0]  R714      -23
    e2_S4_1_1_visit[0]  R715      -23
    e2_S4_1_1_visit[0]  R716      -2
    e2_S4_1_1_visit[0]  R717      -2
    e2_S4_1_1_visit[0]  R727      -1
    e2_S4_1_1_visit[0]  R729      23
    e2_S4_1_1_visit[0]  R730      2
    e2_S4_1_1_visit[0]  R735      1
    e2_S4_1_1_visit[0]  R760      -6
    e2_S4_1_1_visit[0]  R802      1
    e2_S4_1_1_visit[1]  R684      4
    e2_S4_1_1_visit[1]  R685      2
    e2_S4_1_1_visit[1]  R689      -1
    e2_S4_1_1_visit[1]  R690      -1
    e2_S4_1_1_visit[1]  R691      1
    e2_S4_1_1_visit[1]  R736      -37791
    e2_S4_1_1_visit[1]  R737      71100
    e2_S4_1_1_visit[1]  R763      -6
    e2_S4_1_1_visit[1]  R803      1
    e2_S4_1_1_visit[2]  R682      21
    e2_S4_1_1_visit[2]  R683      2
    e2_S4_1_1_visit[2]  R692      -1
    e2_S4_1_1_visit[2]  R693      -1
    e2_S4_1_1_visit[2]  R694      1
    e2_S4_1_1_visit[2]  R699      -21
    e2_S4_1_1_visit[2]  R700      -21
    e2_S4_1_1_visit[2]  R701      -2
    e2_S4_1_1_visit[2]  R702      -2
    e2_S4_1_1_visit[2]  R704      -21
    e2_S4_1_1_visit[2]  R705      -21
    e2_S4_1_1_visit[2]  R706      -2
    e2_S4_1_1_visit[2]  R707      -2
    e2_S4_1_1_visit[2]  R709      -21
    e2_S4_1_1_visit[2]  R710      -21
    e2_S4_1_1_visit[2]  R711      -2
    e2_S4_1_1_visit[2]  R712      -2
    e2_S4_1_1_visit[2]  R714      -21
    e2_S4_1_1_visit[2]  R715      -21
    e2_S4_1_1_visit[2]  R716      -2
    e2_S4_1_1_visit[2]  R717      -2
    e2_S4_1_1_visit[2]  R731      -1
    e2_S4_1_1_visit[2]  R733      21
    e2_S4_1_1_visit[2]  R734      2
    e2_S4_1_1_visit[2]  R738      1
    e2_S4_1_1_visit[2]  R766      -6
    e2_S4_1_1_visit[2]  R806      1
    e2_S4_1_1_visit[3]  R684      4
    e2_S4_1_1_visit[3]  R685      2
    e2_S4_1_1_visit[3]  R695      -1
    e2_S4_1_1_visit[3]  R696      -1
    e2_S4_1_1_visit[3]  R697      1
    e2_S4_1_1_visit[3]  R739      -26949
    e2_S4_1_1_visit[3]  R740      71100
    e2_S4_1_1_visit[3]  R769      -6
    e2_S4_1_1_visit[3]  R807      1
    e2_S4_1_1_arc[-1,0]  OBJ       3.8275318418009277e+01
    e2_S4_1_1_arc[-1,0]  R680      1
    e2_S4_1_1_arc[-1,0]  R686      1
    e2_S4_1_1_arc[-1,0]  R698      -44319
    e2_S4_1_1_arc[-1,0]  R699      -157
    e2_S4_1_1_arc[-1,0]  R700      180
    e2_S4_1_1_arc[-1,0]  R701      -4
    e2_S4_1_1_arc[-1,0]  R702      6
    e2_S4_1_1_arc[-1,0]  R741      -12
    e2_S4_1_1_arc[-1,0]  R761      1
    e2_S4_1_1_arc[-1,1]  OBJ       3.8275318418009277e+01
    e2_S4_1_1_arc[-1,1]  R680      1
    e2_S4_1_1_arc[-1,1]  R689      1
    e2_S4_1_1_arc[-1,1]  R703      -40749
    e2_S4_1_1_arc[-1,1]  R704      -180
    e2_S4_1_1_arc[-1,1]  R705      176
    e2_S4_1_1_arc[-1,1]  R706      -6
    e2_S4_1_1_arc[-1,1]  R707      4
    e2_S4_1_1_arc[-1,1]  R742      -12
    e2_S4_1_1_arc[-1,1]  R764      1
    e2_S4_1_1_arc[-1,2]  OBJ       8.48528137423857
    e2_S4_1_1_arc[-1,2]  R680      1
    e2_S4_1_1_arc[-1,2]  R692      1
    e2_S4_1_1_arc[-1,2]  R708      -29919
    e2_S4_1_1_arc[-1,2]  R709      -159
    e2_S4_1_1_arc[-1,2]  R710      180
    e2_S4_1_1_arc[-1,2]  R711      -4
    e2_S4_1_1_arc[-1,2]  R712      6
    e2_S4_1_1_arc[-1,2]  R743      -12
    e2_S4_1_1_arc[-1,2]  R767      1
    e2_S4_1_1_arc[-1,3]  OBJ       8.48528137423857
    e2_S4_1_1_arc[-1,3]  R680      1
    e2_S4_1_1_arc[-1,3]  R695      1
    e2_S4_1_1_arc[-1,3]  R713      -28119
    e2_S4_1_1_arc[-1,3]  R714      -180
    e2_S4_1_1_arc[-1,3]  R715      176
    e2_S4_1_1_arc[-1,3]  R716      -6
    e2_S4_1_1_arc[-1,3]  R717      4
    e2_S4_1_1_arc[-1,3]  R744      -12
    e2_S4_1_1_arc[-1,3]  R770      1
    e2_S4_1_1_arc[0,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_1_arc[0,-2]  R681      1
    e2_S4_1_1_arc[0,-2]  R687      1
    e2_S4_1_1_arc[0,-2]  R718      -35709
    e2_S4_1_1_arc[0,-2]  R745      -12
    e2_S4_1_1_arc[0,-2]  R762      1
    e2_S4_1_1_arc[1,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_1_arc[1,-2]  R681      1
    e2_S4_1_1_arc[1,-2]  R690      1
    e2_S4_1_1_arc[1,-2]  R719      -42369
    e2_S4_1_1_arc[1,-2]  R746      -12
    e2_S4_1_1_arc[1,-2]  R765      1
    e2_S4_1_1_arc[2,-2]  OBJ       8.48528137423857
    e2_S4_1_1_arc[2,-2]  R681      1
    e2_S4_1_1_arc[2,-2]  R693      1
    e2_S4_1_1_arc[2,-2]  R720      -48315
    e2_S4_1_1_arc[2,-2]  R747      -12
    e2_S4_1_1_arc[2,-2]  R768      1
    e2_S4_1_1_arc[3,-2]  OBJ       8.48528137423857
    e2_S4_1_1_arc[3,-2]  R681      1
    e2_S4_1_1_arc[3,-2]  R696      1
    e2_S4_1_1_arc[3,-2]  R721      -52275
    e2_S4_1_1_arc[3,-2]  R748      -12
    e2_S4_1_1_arc[3,-2]  R771      1
    MARKER    'MARKER'                 'INTEND'
    C522      R724      1
    C522      R741      -1
    C522      R742      -1
    C522      R743      -1
    C522      R744      -1
    C523      R745      1
    C523      R746      1
    C523      R747      1
    C523      R748      1
    MARKER    'MARKER'                 'INTORG'
    C524      R725      1
    C524      R726      -60
    C524      R727      1
    C524      R728      -39660
    C524      R729      -180
    C524      R730      -6
    C524      R735      -1
    C525      R725      1
    C525      R726      -60
    C525      R731      1
    C525      R732      -54060
    C525      R733      -180
    C525      R734      -6
    C525      R738      -1
    MARKER    'MARKER'                 'INTEND'
    m5_route_0  R750      1
    m5_route_0  R751      -1
    m5_route_0  R752      1
    m5_route_0  R753      -1
    m5_route_0  R760      1
    m5_route_1  R750      -1
    m5_route_1  R751      1
    m5_route_1  R754      1
    m5_route_1  R755      -1
    m5_route_1  R756      1
    m5_route_1  R757      -1
    m5_route_1  R763      1
    m5_route_2  R754      -1
    m5_route_2  R755      1
    m5_route_2  R758      1
    m5_route_2  R759      -1
    m5_route_2  R766      1
    m5_route_3  R752      -1
    m5_route_3  R753      1
    m5_route_3  R756      -1
    m5_route_3  R757      1
    m5_route_3  R758      -1
    m5_route_3  R759      1
    m5_route_3  R769      1
    MARKER    'MARKER'                 'INTORG'
    C530      R830      -4
    C531      OBJ       0
    C532      R830      1
    C532      clean_stock_b1  1
    C533      R834      -4
    C534      OBJ       0
    C535      R834      1
    C535      clean_stock_b1  1
    C536      R838      -4
    C537      OBJ       0
    C538      R838      1
    C538      clean_stock_b1  1
    C539      R842      -4
    C540      OBJ       0
    C541      R842      1
    C541      clean_stock_b1  1
    C542      R846      -4
    C543      OBJ       0
    C544      R846      1
    C544      clean_stock_b1  1
    C545      R850      -4
    C546      OBJ       0
    C547      R850      1
    C547      clean_stock_b1  1
    C548      R854      -4
    C549      OBJ       0
    C550      R854      1
    C550      clean_stock_b1  1
    C551      R858      -4
    C552      OBJ       0
    C553      R858      1
    C553      clean_stock_b1  1
    C554      R862      -4
    C555      OBJ       0
    C556      R862      1
    C556      clean_stock_b1  1
    C557      R867      -4
    C558      OBJ       0
    C559      R867      1
    C559      clean_stock_b2  1
    C560      R871      -4
    C561      OBJ       0
    C562      R871      1
    C562      clean_stock_b2  1
    C563      R875      -4
    C564      OBJ       0
    C565      R875      1
    C565      clean_stock_b2  1
    C566      R879      -4
    C567      OBJ       0
    C568      R879      1
    C568      clean_stock_b2  1
    C569      R883      -4
    C570      OBJ       0
    C571      R883      1
    C571      clean_stock_b2  1
    C572      R887      -4
    C573      OBJ       0
    C574      R887      1
    C574      clean_stock_b2  1
    C575      R891      -4
    C576      OBJ       0
    C577      R891      1
    C577      clean_stock_b2  1
    C578      R895      -4
    C579      OBJ       0
    C580      R895      1
    C580      clean_stock_b2  1
    C581      R899      -4
    C582      OBJ       0
    C583      R899      1
    C583      clean_stock_b2  1
    C584      R904      -4
    C585      OBJ       0
    C586      R904      1
    C586      clean_stock_b3  1
    C587      R908      -4
    C588      OBJ       0
    C589      R908      1
    C589      clean_stock_b3  1
    C590      R912      -4
    C591      OBJ       0
    C592      R912      1
    C592      clean_stock_b3  1
    C593      R916      -4
    C594      OBJ       0
    C595      R916      1
    C595      clean_stock_b3  1
    C596      R920      -4
    C597      OBJ       0
    C598      R920      1
    C598      clean_stock_b3  1
    C599      R924      -4
    C600      OBJ       0
    C601      R924      1
    C601      clean_stock_b3  1
    C602      R928      -4
    C603      OBJ       0
    C604      R928      1
    C604      clean_stock_b3  1
    C605      R932      -4
    C606      OBJ       0
    C607      R932      1
    C607      clean_stock_b3  1
    C608      R936      -4
    C609      OBJ       0
    C610      R936      1
    C610      clean_stock_b3  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      R311      1809
    RHS1      R312      71100
    RHS1      R313      39601
    RHS1      R315      71100
    RHS1      R316      54001
    RHS1      R318      915
    RHS1      R319      71100
    RHS1      R320      54001
    RHS1      R343      -43170
    RHS1      R344      -180
    RHS1      R345      157
    RHS1      R346      -6
    RHS1      R347      4
    RHS1      R348      -39600
    RHS1      R349      -176
    RHS1      R350      180
    RHS1      R351      -4
    RHS1      R352      6
    RHS1      R353      -29664
    RHS1      R354      -180
    RHS1      R355      159
    RHS1      R356      -6
    RHS1      R357      4
    RHS1      R358      -27864
    RHS1      R359      -176
    RHS1      R360      180
    RHS1      R361      -4
    RHS1      R362      6
    RHS1      R363      -33900
    RHS1      R364      -40560
    RHS1      R365      -47400
    RHS1      R366      -51360
    RHS1      R370      -39600
    RHS1      R374      -54000
    RHS1      R378      -37791
    RHS1      R379      71100
    RHS1      R381      -26949
    RHS1      R382      71100
    RHS1      R383      -11
    RHS1      R384      -11
    RHS1      R385      -11
    RHS1      R386      -11
    RHS1      R387      -11
    RHS1      R388      -11
    RHS1      R389      -11
    RHS1      R390      -11
    RHS1      R412      -43170
    RHS1      R413      -180
    RHS1      R414      157
    RHS1      R415      -6
    RHS1      R416      4
    RHS1      R417      -39600
    RHS1      R418      -176
    RHS1      R419      180
    RHS1      R420      -4
    RHS1      R421      6
    RHS1      R422      -29664
    RHS1      R423      -180
    RHS1      R424      159
    RHS1      R425      -6
    RHS1      R426      4
    RHS1      R427      -27864
    RHS1      R428      -176
    RHS1      R429      180
    RHS1      R430      -4
    RHS1      R431      6
    RHS1      R432      -33900
    RHS1      R433      -40560
    RHS1      R434      -47400
    RHS1      R435      -51360
    RHS1      R438      -11
    RHS1      R440      -75540
    RHS1      R442      -39600
    RHS1      R446      -54000
    RHS1      R450      -37791
    RHS1      R451      71100
    RHS1      R453      -26949
    RHS1      R454      71100
    RHS1      R455      -11
    RHS1      R456      -11
    RHS1      R457      -11
    RHS1      R458      -11
    RHS1      R459      -11
    RHS1      R460      -11
    RHS1      R461      -11
    RHS1      R462      -11
    RHS1      R484      -43170
    RHS1      R485      -180
    RHS1      R486      157
    RHS1      R487      -6
    RHS1      R488      4
    RHS1      R489      -39600
    RHS1      R490      -176
    RHS1      R491      180
    RHS1      R492      -4
    RHS1      R493      6
    RHS1      R494      -29664
    RHS1      R495      -180
    RHS1      R496      159
    RHS1      R497      -6
    RHS1      R498      4
    RHS1      R499      -27864
    RHS1      R500      -176
    RHS1      R501      180
    RHS1      R502      -4
    RHS1      R503      6
    RHS1      R504      -33900
    RHS1      R505      -40560
    RHS1      R506      -47400
    RHS1      R507      -51360
    RHS1      R510      -11
    RHS1      R512      -75540
    RHS1      R514      -39600
    RHS1      R518      -54000
    RHS1      R522      -37791
    RHS1      R523      71100
    RHS1      R525      -26949
    RHS1      R526      71100
    RHS1      R527      -11
    RHS1      R528      -11
    RHS1      R529      -11
    RHS1      R530      -11
    RHS1      R531      -11
    RHS1      R532      -11
    RHS1      R533      -11
    RHS1      R534      -11
    RHS1      R556      -43170
    RHS1      R557      -180
    RHS1      R558      157
    RHS1      R559      -6
    RHS1      R560      4
    RHS1      R561      -39600
    RHS1      R562      -176
    RHS1      R563      180
    RHS1      R564      -4
    RHS1      R565      6
    RHS1      R566      -29664
    RHS1      R567      -180
    RHS1      R568      159
    RHS1      R569      -6
    RHS1      R570      4
    RHS1      R571      -27864
    RHS1      R572      -176
    RHS1      R573      180
    RHS1      R574      -4
    RHS1      R575      6
    RHS1      R576      -33900
    RHS1      R577      -40560
    RHS1      R578      -47400
    RHS1      R579      -51360
    RHS1      R582      -11
    RHS1      R584      -75540
    RHS1      R586      -39600
    RHS1      R590      -54000
    RHS1      R594      -37791
    RHS1      R595      71100
    RHS1      R597      -26949
    RHS1      R598      71100
    RHS1      R599      -11
    RHS1      R600      -11
    RHS1      R601      -11
    RHS1      R602      -11
    RHS1      R603      -11
    RHS1      R604      -11
    RHS1      R605      -11
    RHS1      R606      -11
    RHS1      R628      -43170
    RHS1      R629      -180
    RHS1      R630      157
    RHS1      R631      -6
    RHS1      R632      4
    RHS1      R633      -39600
    RHS1      R634      -176
    RHS1      R635      180
    RHS1      R636      -4
    RHS1      R637      6
    RHS1      R638      -29664
    RHS1      R639      -180
    RHS1      R640      159
    RHS1      R641      -6
    RHS1      R642      4
    RHS1      R643      -27864
    RHS1      R644      -176
    RHS1      R645      180
    RHS1      R646      -4
    RHS1      R647      6
    RHS1      R648      -33900
    RHS1      R649      -40560
    RHS1      R650      -47400
    RHS1      R651      -51360
    RHS1      R656      -39600
    RHS1      R660      -54000
    RHS1      R664      -37791
    RHS1      R665      71100
    RHS1      R667      -26949
    RHS1      R668      71100
    RHS1      R669      -11
    RHS1      R670      -11
    RHS1      R671      -11
    RHS1      R672      -11
    RHS1      R673      -11
    RHS1      R674      -11
    RHS1      R675      -11
    RHS1      R676      -11
    RHS1      R698      -43170
    RHS1      R699      -180
    RHS1      R700      157
    RHS1      R701      -6
    RHS1      R702      4
    RHS1      R703      -39600
    RHS1      R704      -176
    RHS1      R705      180
    RHS1      R706      -4
    RHS1      R707      6
    RHS1      R708      -29664
    RHS1      R709      -180
    RHS1      R710      159
    RHS1      R711      -6
    RHS1      R712      4
    RHS1      R713      -27864
    RHS1      R714      -176
    RHS1      R715      180
    RHS1      R716      -4
    RHS1      R717      6
    RHS1      R718      -33900
    RHS1      R719      -40560
    RHS1      R720      -47400
    RHS1      R721      -51360
    RHS1      R724      -11
    RHS1      R726      -75540
    RHS1      R728      -39600
    RHS1      R732      -54000
    RHS1      R736      -37791
    RHS1      R737      71100
    RHS1      R739      -26949
    RHS1      R740      71100
    RHS1      R741      -11
    RHS1      R742      -11
    RHS1      R743      -11
    RHS1      R744      -11
    RHS1      R745      -11
    RHS1      R746      -11
    RHS1      R747      -11
    RHS1      R748      -11
    RHS1      R750      5
    RHS1      R751      5
    RHS1      R752      5
    RHS1      R753      5
    RHS1      R754      5
    RHS1      R755      5
    RHS1      R756      5
    RHS1      R757      5
    RHS1      R758      5
    RHS1      R759      5
    RHS1      R761      1
    RHS1      R762      1
    RHS1      R764      1
    RHS1      R765      1
    RHS1      R767      1
    RHS1      R768      1
    RHS1      R770      1
    RHS1      R771      1
    RHS1      R772      600
    RHS1      R773      -153
    RHS1      R774      180
    RHS1      R775      -2
    RHS1      R776      6
    RHS1      R777      -11
    RHS1      R778      1525
    RHS1      R779      -153
    RHS1      R780      180
    RHS1      R781      -2
    RHS1      R782      6
    RHS1      R783      -11
    RHS1      R784      1525
    RHS1      R785      -180
    RHS1      R786      155
    RHS1      R787      -6
    RHS1      R788      2
    RHS1      R789      -11
    RHS1      R790      1525
    RHS1      R791      -176
    RHS1      R792      176
    RHS1      R793      -4
    RHS1      R794      4
    RHS1      R795      -11
    RHS1      R796      336
    RHS1      R797      -155
    RHS1      R798      180
    RHS1      R799      -2
    RHS1      R800      6
    RHS1      R801      -11
    RHS1      R802      1
    RHS1      R803      1
    RHS1      R804      2400
    RHS1      R805      1
    RHS1      R806      1
    RHS1      R807      1
    RHS1      R808      1800
    RHS1      R809      1
    RHS1      clean_stock_b1  -31
    RHS1      clean_stock_b2  -29
    RHS1      clean_stock_b3  -29
BOUNDS
 FX BND1      delivery_S4_b1  31221
 FX BND1      delivery_S4_b2  47085
 FX BND1      C34_order_d  33900
 FX BND1      C34_order_p  40560
 FX BND1      C95_order_d  47400
 FX BND1      C95_order_p  49200
 UP BND1      C6        157
 LO BND1      C7        4
 UP BND1      C7        180
 UP BND1      C8        159
 LO BND1      C9        4
 UP BND1      C9        180
 UP BND1      C10       4
 LO BND1      C11       2
 UP BND1      C11       6
 UP BND1      C12       4
 LO BND1      C13       2
 UP BND1      C13       6
 UP BND1      C14       11
 UP BND1      C15       11
 UP BND1      C16       11
 UP BND1      C17       11
 UP BND1      e1_b1_0_weight[0]  600
 UP BND1      e1_b1_0_weight[1]  600
 UP BND1      e1_b1_0_weight[2]  600
 UP BND1      e1_b1_0_weight[3]  600
 UP BND1      e1_b1_0_volume[0]  40
 UP BND1      e1_b1_0_volume[1]  40
 UP BND1      e1_b1_0_volume[2]  40
 UP BND1      e1_b1_0_volume[3]  40
 BV BND1      C62     
 UP BND1      e1_b1_1_weight[0]  600
 UP BND1      e1_b1_1_weight[1]  600
 UP BND1      e1_b1_1_weight[2]  600
 UP BND1      e1_b1_1_weight[3]  600
 UP BND1      e1_b1_1_volume[0]  40
 UP BND1      e1_b1_1_volume[1]  40
 UP BND1      e1_b1_1_volume[2]  40
 UP BND1      e1_b1_1_volume[3]  40
 BV BND1      C107    
 UP BND1      e1_b1_2_weight[0]  600
 UP BND1      e1_b1_2_weight[1]  600
 UP BND1      e1_b1_2_weight[2]  600
 UP BND1      e1_b1_2_weight[3]  600
 UP BND1      e1_b1_2_volume[0]  40
 UP BND1      e1_b1_2_volume[1]  40
 UP BND1      e1_b1_2_volume[2]  40
 UP BND1      e1_b1_2_volume[3]  40
 BV BND1      C152    
 UP BND1      e1_b2_0_weight[0]  600
 UP BND1      e1_b2_0_weight[1]  600
 UP BND1      e1_b2_0_weight[2]  600
 UP BND1      e1_b2_0_weight[3]  600
 UP BND1      e1_b2_0_volume[0]  40
 UP BND1      e1_b2_0_volume[1]  40
 UP BND1      e1_b2_0_volume[2]  40
 UP BND1      e1_b2_0_volume[3]  40
 BV BND1      C197    
 BV BND1      C198    
 UP BND1      e1_b2_1_weight[0]  600
 UP BND1      e1_b2_1_weight[1]  600
 UP BND1      e1_b2_1_weight[2]  600
 UP BND1      e1_b2_1_weight[3]  600
 UP BND1      e1_b2_1_volume[0]  40
 UP BND1      e1_b2_1_volume[1]  40
 UP BND1      e1_b2_1_volume[2]  40
 UP BND1      e1_b2_1_volume[3]  40
 BV BND1      C243    
 BV BND1      C244    
 UP BND1      e1_b2_2_weight[0]  600
 UP BND1      e1_b2_2_weight[1]  600
 UP BND1      e1_b2_2_weight[2]  600
 UP BND1      e1_b2_2_weight[3]  600
 UP BND1      e1_b2_2_volume[0]  40
 UP BND1      e1_b2_2_volume[1]  40
 UP BND1      e1_b2_2_volume[2]  40
 UP BND1      e1_b2_2_volume[3]  40
 BV BND1      C289    
 BV BND1      C290    
 UP BND1      e1_b3_0_weight[0]  600
 UP BND1      e1_b3_0_weight[1]  600
 UP BND1      e1_b3_0_weight[2]  600
 UP BND1      e1_b3_0_volume[0]  40
 UP BND1      e1_b3_0_volume[1]  40
 UP BND1      e1_b3_0_volume[2]  40
 BV BND1      C325    
 BV BND1      C326    
 BV BND1      C327    
 UP BND1      e1_b3_1_weight[0]  600
 UP BND1      e1_b3_1_weight[1]  600
 UP BND1      e1_b3_1_weight[2]  600
 UP BND1      e1_b3_1_volume[0]  40
 UP BND1      e1_b3_1_volume[1]  40
 UP BND1      e1_b3_1_volume[2]  40
 BV BND1      C362    
 BV BND1      C363    
 BV BND1      C364    
 UP BND1      e1_b3_2_weight[0]  600
 UP BND1      e1_b3_2_weight[1]  600
 UP BND1      e1_b3_2_weight[2]  600
 UP BND1      e1_b3_2_volume[0]  40
 UP BND1      e1_b3_2_volume[1]  40
 UP BND1      e1_b3_2_volume[2]  40
 BV BND1      C399    
 BV BND1      C400    
 BV BND1      C401    
 FX BND1      pickup_return_C34_order  54000
 BV BND1      eligible_C34_order_b1
 BV BND1      eligible_C34_order_b2
 FX BND1      pickup_return_C95_order  50115
 BV BND1      eligible_C95_order_b2
 FX BND1      e2_S4_0_0_used  1
 BV BND1      e2_S4_0_0_used
 FX BND1      e2_S4_0_0_start  47145
 FX BND1      e2_S4_0_0_end  50115
 FX BND1      e2_S4_0_0_visit[0]  0
 BV BND1      e2_S4_0_0_visit[0]
 FX BND1      e2_S4_0_0_visit[1]  0
 BV BND1      e2_S4_0_0_visit[1]
 FX BND1      e2_S4_0_0_visit[2]  1
 BV BND1      e2_S4_0_0_visit[2]
 FX BND1      e2_S4_0_0_visit[3]  1
 BV BND1      e2_S4_0_0_visit[3]
 FX BND1      e2_S4_0_0_arc[-1,0]  0
 BV BND1      e2_S4_0_0_arc[-1,0]
 FX BND1      e2_S4_0_0_arc[-1,1]  0
 BV BND1      e2_S4_0_0_arc[-1,1]
 FX BND1      e2_S4_0_0_arc[-1,2]  1
 BV BND1      e2_S4_0_0_arc[-1,2]
 FX BND1      e2_S4_0_0_arc[-1,3]  0
 BV BND1      e2_S4_0_0_arc[-1,3]
 FX BND1      e2_S4_0_0_arc[0,-2]  0
 BV BND1      e2_S4_0_0_arc[0,-2]
 FX BND1      e2_S4_0_0_arc[1,-2]  0
 BV BND1      e2_S4_0_0_arc[1,-2]
 FX BND1      e2_S4_0_0_arc[2,-2]  0
 BV BND1      e2_S4_0_0_arc[2,-2]
 FX BND1      e2_S4_0_0_arc[3,-2]  1
 BV BND1      e2_S4_0_0_arc[3,-2]
 FX BND1      m5_link_0  1
 BV BND1      m5_link_0
 FX BND1      m5_link_1  0
 BV BND1      m5_link_1
 FX BND1      m5_link_2  0
 BV BND1      m5_link_2
 FX BND1      m5_link_3  0
 BV BND1      m5_link_3
 FX BND1      m5_link_4  1
 BV BND1      m5_link_4
 UP BND1      C427      11
 UP BND1      C428      11
 BV BND1      C429    
 BV BND1      C430    
 FX BND1      e2_S4_0_1_used  0
 BV BND1      e2_S4_0_1_used
 FX BND1      e2_S4_0_1_start  0
 FX BND1      e2_S4_0_1_end  0
 FX BND1      e2_S4_0_1_visit[0]  0
 BV BND1      e2_S4_0_1_visit[0]
 FX BND1      e2_S4_0_1_visit[1]  0
 BV BND1      e2_S4_0_1_visit[1]
 FX BND1      e2_S4_0_1_visit[2]  0
 BV BND1      e2_S4_0_1_visit[2]
 FX BND1      e2_S4_0_1_visit[3]  0
 BV BND1      e2_S4_0_1_visit[3]
 FX BND1      e2_S4_0_1_arc[-1,0]  0
 BV BND1      e2_S4_0_1_arc[-1,0]
 FX BND1      e2_S4_0_1_arc[-1,1]  0
 BV BND1      e2_S4_0_1_arc[-1,1]
 FX BND1      e2_S4_0_1_arc[-1,2]  0
 BV BND1      e2_S4_0_1_arc[-1,2]
 FX BND1      e2_S4_0_1_arc[-1,3]  0
 BV BND1      e2_S4_0_1_arc[-1,3]
 FX BND1      e2_S4_0_1_arc[0,-2]  0
 BV BND1      e2_S4_0_1_arc[0,-2]
 FX BND1      e2_S4_0_1_arc[1,-2]  0
 BV BND1      e2_S4_0_1_arc[1,-2]
 FX BND1      e2_S4_0_1_arc[2,-2]  0
 BV BND1      e2_S4_0_1_arc[2,-2]
 FX BND1      e2_S4_0_1_arc[3,-2]  0
 BV BND1      e2_S4_0_1_arc[3,-2]
 UP BND1      C446      11
 UP BND1      C447      11
 BV BND1      C448    
 BV BND1      C449    
 FX BND1      e2_S4_0_2_used  0
 BV BND1      e2_S4_0_2_used
 FX BND1      e2_S4_0_2_start  0
 FX BND1      e2_S4_0_2_end  0
 FX BND1      e2_S4_0_2_visit[0]  0
 BV BND1      e2_S4_0_2_visit[0]
 FX BND1      e2_S4_0_2_visit[1]  0
 BV BND1      e2_S4_0_2_visit[1]
 FX BND1      e2_S4_0_2_visit[2]  0
 BV BND1      e2_S4_0_2_visit[2]
 FX BND1      e2_S4_0_2_visit[3]  0
 BV BND1      e2_S4_0_2_visit[3]
 FX BND1      e2_S4_0_2_arc[-1,0]  0
 BV BND1      e2_S4_0_2_arc[-1,0]
 FX BND1      e2_S4_0_2_arc[-1,1]  0
 BV BND1      e2_S4_0_2_arc[-1,1]
 FX BND1      e2_S4_0_2_arc[-1,2]  0
 BV BND1      e2_S4_0_2_arc[-1,2]
 FX BND1      e2_S4_0_2_arc[-1,3]  0
 BV BND1      e2_S4_0_2_arc[-1,3]
 FX BND1      e2_S4_0_2_arc[0,-2]  0
 BV BND1      e2_S4_0_2_arc[0,-2]
 FX BND1      e2_S4_0_2_arc[1,-2]  0
 BV BND1      e2_S4_0_2_arc[1,-2]
 FX BND1      e2_S4_0_2_arc[2,-2]  0
 BV BND1      e2_S4_0_2_arc[2,-2]
 FX BND1      e2_S4_0_2_arc[3,-2]  0
 BV BND1      e2_S4_0_2_arc[3,-2]
 UP BND1      C465      11
 UP BND1      C466      11
 BV BND1      C467    
 BV BND1      C468    
 FX BND1      e2_S4_0_3_used  0
 BV BND1      e2_S4_0_3_used
 FX BND1      e2_S4_0_3_start  0
 FX BND1      e2_S4_0_3_end  0
 FX BND1      e2_S4_0_3_visit[0]  0
 BV BND1      e2_S4_0_3_visit[0]
 FX BND1      e2_S4_0_3_visit[1]  0
 BV BND1      e2_S4_0_3_visit[1]
 FX BND1      e2_S4_0_3_visit[2]  0
 BV BND1      e2_S4_0_3_visit[2]
 FX BND1      e2_S4_0_3_visit[3]  0
 BV BND1      e2_S4_0_3_visit[3]
 FX BND1      e2_S4_0_3_arc[-1,0]  0
 BV BND1      e2_S4_0_3_arc[-1,0]
 FX BND1      e2_S4_0_3_arc[-1,1]  0
 BV BND1      e2_S4_0_3_arc[-1,1]
 FX BND1      e2_S4_0_3_arc[-1,2]  0
 BV BND1      e2_S4_0_3_arc[-1,2]
 FX BND1      e2_S4_0_3_arc[-1,3]  0
 BV BND1      e2_S4_0_3_arc[-1,3]
 FX BND1      e2_S4_0_3_arc[0,-2]  0
 BV BND1      e2_S4_0_3_arc[0,-2]
 FX BND1      e2_S4_0_3_arc[1,-2]  0
 BV BND1      e2_S4_0_3_arc[1,-2]
 FX BND1      e2_S4_0_3_arc[2,-2]  0
 BV BND1      e2_S4_0_3_arc[2,-2]
 FX BND1      e2_S4_0_3_arc[3,-2]  0
 BV BND1      e2_S4_0_3_arc[3,-2]
 UP BND1      C484      11
 UP BND1      C485      11
 BV BND1      C486    
 BV BND1      C487    
 FX BND1      e2_S4_1_0_used  1
 BV BND1      e2_S4_1_0_used
 FX BND1      e2_S4_1_0_start  31281
 FX BND1      e2_S4_1_0_end  54000
 FX BND1      e2_S4_1_0_visit[0]  1
 BV BND1      e2_S4_1_0_visit[0]
 FX BND1      e2_S4_1_0_visit[1]  1
 BV BND1      e2_S4_1_0_visit[1]
 FX BND1      e2_S4_1_0_visit[2]  0
 BV BND1      e2_S4_1_0_visit[2]
 FX BND1      e2_S4_1_0_visit[3]  0
 BV BND1      e2_S4_1_0_visit[3]
 FX BND1      e2_S4_1_0_arc[-1,0]  1
 BV BND1      e2_S4_1_0_arc[-1,0]
 FX BND1      e2_S4_1_0_arc[-1,1]  0
 BV BND1      e2_S4_1_0_arc[-1,1]
 FX BND1      e2_S4_1_0_arc[-1,2]  0
 BV BND1      e2_S4_1_0_arc[-1,2]
 FX BND1      e2_S4_1_0_arc[-1,3]  0
 BV BND1      e2_S4_1_0_arc[-1,3]
 FX BND1      e2_S4_1_0_arc[0,-2]  0
 BV BND1      e2_S4_1_0_arc[0,-2]
 FX BND1      e2_S4_1_0_arc[1,-2]  1
 BV BND1      e2_S4_1_0_arc[1,-2]
 FX BND1      e2_S4_1_0_arc[2,-2]  0
 BV BND1      e2_S4_1_0_arc[2,-2]
 FX BND1      e2_S4_1_0_arc[3,-2]  0
 BV BND1      e2_S4_1_0_arc[3,-2]
 UP BND1      C503      11
 UP BND1      C504      11
 BV BND1      C505    
 BV BND1      C506    
 FX BND1      e2_S4_1_1_used  0
 BV BND1      e2_S4_1_1_used
 FX BND1      e2_S4_1_1_start  0
 FX BND1      e2_S4_1_1_end  0
 FX BND1      e2_S4_1_1_visit[0]  0
 BV BND1      e2_S4_1_1_visit[0]
 FX BND1      e2_S4_1_1_visit[1]  0
 BV BND1      e2_S4_1_1_visit[1]
 FX BND1      e2_S4_1_1_visit[2]  0
 BV BND1      e2_S4_1_1_visit[2]
 FX BND1      e2_S4_1_1_visit[3]  0
 BV BND1      e2_S4_1_1_visit[3]
 FX BND1      e2_S4_1_1_arc[-1,0]  0
 BV BND1      e2_S4_1_1_arc[-1,0]
 FX BND1      e2_S4_1_1_arc[-1,1]  0
 BV BND1      e2_S4_1_1_arc[-1,1]
 FX BND1      e2_S4_1_1_arc[-1,2]  0
 BV BND1      e2_S4_1_1_arc[-1,2]
 FX BND1      e2_S4_1_1_arc[-1,3]  0
 BV BND1      e2_S4_1_1_arc[-1,3]
 FX BND1      e2_S4_1_1_arc[0,-2]  0
 BV BND1      e2_S4_1_1_arc[0,-2]
 FX BND1      e2_S4_1_1_arc[1,-2]  0
 BV BND1      e2_S4_1_1_arc[1,-2]
 FX BND1      e2_S4_1_1_arc[2,-2]  0
 BV BND1      e2_S4_1_1_arc[2,-2]
 FX BND1      e2_S4_1_1_arc[3,-2]  0
 BV BND1      e2_S4_1_1_arc[3,-2]
 UP BND1      C522      11
 UP BND1      C523      11
 BV BND1      C524    
 BV BND1      C525    
 LO BND1      m5_route_0  1
 UP BND1      m5_route_0  6
 LO BND1      m5_route_1  1
 UP BND1      m5_route_1  6
 LO BND1      m5_route_2  1
 UP BND1      m5_route_2  6
 LO BND1      m5_route_3  1
 UP BND1      m5_route_3  6
 BV BND1      C530    
 BV BND1      C531    
 UP BND1      C532      4
 BV BND1      C533    
 BV BND1      C534    
 UP BND1      C535      4
 BV BND1      C536    
 BV BND1      C537    
 UP BND1      C538      4
 BV BND1      C539    
 BV BND1      C540    
 UP BND1      C541      4
 BV BND1      C542    
 BV BND1      C543    
 UP BND1      C544      4
 BV BND1      C545    
 BV BND1      C546    
 UP BND1      C547      4
 BV BND1      C548    
 BV BND1      C549    
 UP BND1      C550      4
 BV BND1      C551    
 BV BND1      C552    
 UP BND1      C553      4
 BV BND1      C554    
 BV BND1      C555    
 UP BND1      C556      4
 BV BND1      C557    
 BV BND1      C558    
 UP BND1      C559      4
 BV BND1      C560    
 BV BND1      C561    
 UP BND1      C562      4
 BV BND1      C563    
 BV BND1      C564    
 UP BND1      C565      4
 BV BND1      C566    
 BV BND1      C567    
 UP BND1      C568      4
 BV BND1      C569    
 BV BND1      C570    
 UP BND1      C571      4
 BV BND1      C572    
 BV BND1      C573    
 UP BND1      C574      4
 BV BND1      C575    
 BV BND1      C576    
 UP BND1      C577      4
 BV BND1      C578    
 BV BND1      C579    
 UP BND1      C580      4
 BV BND1      C581    
 BV BND1      C582    
 UP BND1      C583      4
 BV BND1      C584    
 BV BND1      C585    
 UP BND1      C586      4
 BV BND1      C587    
 BV BND1      C588    
 UP BND1      C589      4
 BV BND1      C590    
 BV BND1      C591    
 UP BND1      C592      4
 BV BND1      C593    
 BV BND1      C594    
 UP BND1      C595      4
 BV BND1      C596    
 BV BND1      C597    
 UP BND1      C598      4
 BV BND1      C599    
 BV BND1      C600    
 UP BND1      C601      4
 BV BND1      C602    
 BV BND1      C603    
 UP BND1      C604      4
 BV BND1      C605    
 BV BND1      C606    
 UP BND1      C607      4
 BV BND1      C608    
 BV BND1      C609    
 UP BND1      C610      4
ENDATA
