* Signature: 0x478fa2c0bdd475fd
NAME multi_batch_cutoff_v1
ROWS
 N  OBJ
 G  R327    
 L  R328    
 G  R329    
 G  R330    
 L  R331    
 G  R332    
 G  R333    
 G  R334    
 L  R335    
 G  R336    
 G  R337    
 L  R338    
 G  R339    
 G  R340    
 G  R341    
 L  R342    
 G  R343    
 G  R344    
 G  R345    
 L  R346    
 G  R347    
 G  R348    
 G  R349    
 L  R350    
 L  R351    
 G  R352    
 E  R353    
 E  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 G  R389    
 G  R390    
 L  R391    
 G  R392    
 L  R393    
 G  R394    
 G  R395    
 L  R396    
 G  R397    
 L  R398    
 G  R399    
 G  R400    
 L  R401    
 G  R402    
 L  R403    
 G  R404    
 G  R405    
 L  R406    
 G  R407    
 L  R408    
 G  R409    
 G  R410    
 L  R411    
 G  R412    
 L  R413    
 G  R414    
 G  R415    
 L  R416    
 G  R417    
 L  R418    
 G  R419    
 G  R420    
 L  R421    
 G  R422    
 L  R423    
 G  R424    
 G  R425    
 L  R426    
 G  R427    
 L  R428    
 G  R429    
 G  R430    
 L  R431    
 G  R432    
 L  R433    
 G  R434    
 G  R435    
 L  R436    
 G  R437    
 L  R438    
 G  R439    
 G  R440    
 G  R441    
 G  R442    
 G  R443    
 G  R444    
 G  R445    
 G  R446    
 G  R447    
 G  R448    
 L  R449    
 L  R450    
 L  R451    
 G  R452    
 L  R453    
 L  R454    
 L  R455    
 G  R456    
 L  R457    
 L  R458    
 L  R459    
 G  R460    
 L  R461    
 L  R462    
 L  R463    
 G  R464    
 L  R465    
 L  R466    
 G  R467    
 L  R468    
 L  R469    
 G  R470    
 L  R471    
 L  R472    
 G  R473    
 L  R474    
 L  R475    
 G  R476    
 L  R477    
 G  R478    
 G  R479    
 G  R480    
 G  R481    
 G  R482    
 G  R483    
 G  R484    
 G  R485    
 G  R486    
 G  R487    
 G  R488    
 G  R489    
 G  R490    
 G  R491    
 G  R492    
 G  R493    
 G  R494    
 G  R495    
 G  R496    
 G  R497    
 L  R498    
 L  R499    
 G  R500    
 E  R501    
 E  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 G  R537    
 G  R538    
 L  R539    
 G  R540    
 L  R541    
 G  R542    
 G  R543    
 L  R544    
 G  R545    
 L  R546    
 G  R547    
 G  R548    
 L  R549    
 G  R550    
 L  R551    
 G  R552    
 G  R553    
 L  R554    
 G  R555    
 L  R556    
 G  R557    
 G  R558    
 L  R559    
 G  R560    
 L  R561    
 G  R562    
 G  R563    
 L  R564    
 G  R565    
 L  R566    
 G  R567    
 G  R568    
 L  R569    
 G  R570    
 L  R571    
 G  R572    
 G  R573    
 L  R574    
 G  R575    
 L  R576    
 G  R577    
 G  R578    
 L  R579    
 G  R580    
 L  R581    
 G  R582    
 G  R583    
 L  R584    
 G  R585    
 L  R586    
 G  R587    
 G  R588    
 G  R589    
 G  R590    
 G  R591    
 G  R592    
 G  R593    
 G  R594    
 G  R595    
 G  R596    
 L  R597    
 L  R598    
 G  R599    
 L  R600    
 G  R601    
 L  R602    
 G  R603    
 L  R604    
 L  R605    
 L  R606    
 G  R607    
 L  R608    
 L  R609    
 L  R610    
 G  R611    
 L  R612    
 L  R613    
 L  R614    
 G  R615    
 L  R616    
 L  R617    
 G  R618    
 L  R619    
 L  R620    
 G  R621    
 L  R622    
 L  R623    
 G  R624    
 L  R625    
 L  R626    
 G  R627    
 L  R628    
 G  R629    
 G  R630    
 G  R631    
 G  R632    
 G  R633    
 G  R634    
 G  R635    
 G  R636    
 G  R637    
 G  R638    
 G  R639    
 G  R640    
 G  R641    
 G  R642    
 G  R643    
 G  R644    
 G  R645    
 G  R646    
 G  R647    
 G  R648    
 L  R649    
 L  R650    
 G  R651    
 E  R652    
 E  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 G  R688    
 G  R689    
 L  R690    
 G  R691    
 L  R692    
 G  R693    
 G  R694    
 L  R695    
 G  R696    
 L  R697    
 G  R698    
 G  R699    
 L  R700    
 G  R701    
 L  R702    
 G  R703    
 G  R704    
 L  R705    
 G  R706    
 L  R707    
 G  R708    
 G  R709    
 L  R710    
 G  R711    
 L  R712    
 G  R713    
 G  R714    
 L  R715    
 G  R716    
 L  R717    
 G  R718    
 G  R719    
 L  R720    
 G  R721    
 L  R722    
 G  R723    
 G  R724    
 L  R725    
 G  R726    
 L  R727    
 G  R728    
 G  R729    
 L  R730    
 G  R731    
 L  R732    
 G  R733    
 G  R734    
 L  R735    
 G  R736    
 L  R737    
 G  R738    
 G  R739    
 G  R740    
 G  R741    
 G  R742    
 G  R743    
 G  R744    
 G  R745    
 G  R746    
 G  R747    
 L  R748    
 L  R749    
 G  R750    
 L  R751    
 G  R752    
 L  R753    
 G  R754    
 L  R755    
 L  R756    
 L  R757    
 G  R758    
 L  R759    
 L  R760    
 L  R761    
 G  R762    
 L  R763    
 L  R764    
 L  R765    
 G  R766    
 L  R767    
 L  R768    
 G  R769    
 L  R770    
 L  R771    
 G  R772    
 L  R773    
 L  R774    
 G  R775    
 L  R776    
 L  R777    
 G  R778    
 L  R779    
 G  R780    
 G  R781    
 G  R782    
 G  R783    
 G  R784    
 G  R785    
 G  R786    
 G  R787    
 G  R788    
 G  R789    
 G  R790    
 G  R791    
 G  R792    
 G  R793    
 G  R794    
 G  R795    
 G  R796    
 G  R797    
 G  R798    
 G  R799    
 L  R800    
 L  R801    
 G  R802    
 E  R803    
 E  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 G  R839    
 G  R840    
 L  R841    
 G  R842    
 L  R843    
 G  R844    
 G  R845    
 L  R846    
 G  R847    
 L  R848    
 G  R849    
 G  R850    
 L  R851    
 G  R852    
 L  R853    
 G  R854    
 G  R855    
 L  R856    
 G  R857    
 L  R858    
 G  R859    
 G  R860    
 L  R861    
 G  R862    
 L  R863    
 G  R864    
 G  R865    
 L  R866    
 G  R867    
 L  R868    
 G  R869    
 G  R870    
 L  R871    
 G  R872    
 L  R873    
 G  R874    
 G  R875    
 L  R876    
 G  R877    
 L  R878    
 G  R879    
 G  R880    
 L  R881    
 G  R882    
 L  R883    
 G  R884    
 G  R885    
 L  R886    
 G  R887    
 L  R888    
 G  R889    
 G  R890    
 G  R891    
 G  R892    
 G  R893    
 G  R894    
 G  R895    
 G  R896    
 G  R897    
 G  R898    
 L  R899    
 L  R900    
 G  R901    
 L  R902    
 G  R903    
 L  R904    
 G  R905    
 L  R906    
 L  R907    
 L  R908    
 G  R909    
 L  R910    
 L  R911    
 L  R912    
 G  R913    
 L  R914    
 L  R915    
 L  R916    
 G  R917    
 L  R918    
 L  R919    
 G  R920    
 L  R921    
 L  R922    
 G  R923    
 L  R924    
 L  R925    
 G  R926    
 L  R927    
 L  R928    
 G  R929    
 L  R930    
 G  R931    
 G  R932    
 G  R933    
 G  R934    
 G  R935    
 G  R936    
 G  R937    
 G  R938    
 G  R939    
 G  R940    
 G  R941    
 G  R942    
 G  R943    
 G  R944    
 G  R945    
 G  R946    
 G  R947    
 G  R948    
 G  R949    
 G  R950    
 L  R951    
 L  R952    
 G  R953    
 E  R954    
 E  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 G  R990    
 G  R991    
 L  R992    
 G  R993    
 L  R994    
 G  R995    
 G  R996    
 L  R997    
 G  R998    
 L  R999    
 G  R1000   
 G  R1001   
 L  R1002   
 G  R1003   
 L  R1004   
 G  R1005   
 G  R1006   
 L  R1007   
 G  R1008   
 L  R1009   
 G  R1010   
 G  R1011   
 L  R1012   
 G  R1013   
 L  R1014   
 G  R1015   
 G  R1016   
 L  R1017   
 G  R1018   
 L  R1019   
 G  R1020   
 G  R1021   
 L  R1022   
 G  R1023   
 L  R1024   
 G  R1025   
 G  R1026   
 L  R1027   
 G  R1028   
 L  R1029   
 G  R1030   
 G  R1031   
 L  R1032   
 G  R1033   
 L  R1034   
 G  R1035   
 G  R1036   
 L  R1037   
 G  R1038   
 L  R1039   
 G  R1040   
 G  R1041   
 G  R1042   
 G  R1043   
 G  R1044   
 G  R1045   
 G  R1046   
 G  R1047   
 G  R1048   
 G  R1049   
 L  R1050   
 L  R1051   
 G  R1052   
 L  R1053   
 G  R1054   
 L  R1055   
 G  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 G  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 G  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 G  R1068   
 L  R1069   
 L  R1070   
 G  R1071   
 L  R1072   
 L  R1073   
 G  R1074   
 L  R1075   
 L  R1076   
 G  R1077   
 L  R1078   
 L  R1079   
 G  R1080   
 L  R1081   
 G  R1082   
 G  R1083   
 G  R1084   
 G  R1085   
 G  R1086   
 G  R1087   
 G  R1088   
 G  R1089   
 G  R1090   
 G  R1091   
 G  R1092   
 G  R1093   
 G  R1094   
 G  R1095   
 G  R1096   
 G  R1097   
 G  R1098   
 G  R1099   
 G  R1100   
 G  R1101   
 L  R1102   
 L  R1103   
 G  R1104   
 E  R1105   
 E  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 G  R1141   
 G  R1142   
 L  R1143   
 G  R1144   
 L  R1145   
 G  R1146   
 G  R1147   
 L  R1148   
 G  R1149   
 L  R1150   
 G  R1151   
 G  R1152   
 L  R1153   
 G  R1154   
 L  R1155   
 G  R1156   
 G  R1157   
 L  R1158   
 G  R1159   
 L  R1160   
 G  R1161   
 G  R1162   
 L  R1163   
 G  R1164   
 L  R1165   
 G  R1166   
 G  R1167   
 L  R1168   
 G  R1169   
 L  R1170   
 G  R1171   
 G  R1172   
 L  R1173   
 G  R1174   
 L  R1175   
 G  R1176   
 G  R1177   
 L  R1178   
 G  R1179   
 L  R1180   
 G  R1181   
 G  R1182   
 L  R1183   
 G  R1184   
 L  R1185   
 G  R1186   
 G  R1187   
 L  R1188   
 G  R1189   
 L  R1190   
 G  R1191   
 G  R1192   
 G  R1193   
 G  R1194   
 G  R1195   
 G  R1196   
 G  R1197   
 G  R1198   
 G  R1199   
 G  R1200   
 L  R1201   
 L  R1202   
 G  R1203   
 L  R1204   
 G  R1205   
 L  R1206   
 G  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 G  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 G  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 G  R1219   
 L  R1220   
 L  R1221   
 G  R1222   
 L  R1223   
 L  R1224   
 G  R1225   
 L  R1226   
 L  R1227   
 G  R1228   
 L  R1229   
 L  R1230   
 G  R1231   
 L  R1232   
 G  R1233   
 G  R1234   
 G  R1235   
 G  R1236   
 G  R1237   
 G  R1238   
 G  R1239   
 G  R1240   
 G  R1241   
 G  R1242   
 G  R1243   
 G  R1244   
 G  R1245   
 G  R1246   
 G  R1247   
 G  R1248   
 G  R1249   
 G  R1250   
 G  R1251   
 G  R1252   
 L  R1253   
 L  R1254   
 G  R1255   
 E  R1256   
 E  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 G  R1292   
 G  R1293   
 L  R1294   
 G  R1295   
 L  R1296   
 G  R1297   
 G  R1298   
 L  R1299   
 G  R1300   
 L  R1301   
 G  R1302   
 G  R1303   
 L  R1304   
 G  R1305   
 L  R1306   
 G  R1307   
 G  R1308   
 L  R1309   
 G  R1310   
 L  R1311   
 G  R1312   
 G  R1313   
 L  R1314   
 G  R1315   
 L  R1316   
 G  R1317   
 G  R1318   
 L  R1319   
 G  R1320   
 L  R1321   
 G  R1322   
 G  R1323   
 L  R1324   
 G  R1325   
 L  R1326   
 G  R1327   
 G  R1328   
 L  R1329   
 G  R1330   
 L  R1331   
 G  R1332   
 G  R1333   
 L  R1334   
 G  R1335   
 L  R1336   
 G  R1337   
 G  R1338   
 L  R1339   
 G  R1340   
 L  R1341   
 G  R1342   
 G  R1343   
 G  R1344   
 G  R1345   
 G  R1346   
 G  R1347   
 G  R1348   
 G  R1349   
 G  R1350   
 G  R1351   
 L  R1352   
 L  R1353   
 G  R1354   
 L  R1355   
 G  R1356   
 L  R1357   
 G  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 G  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 G  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 G  R1370   
 L  R1371   
 L  R1372   
 G  R1373   
 L  R1374   
 L  R1375   
 G  R1376   
 L  R1377   
 L  R1378   
 G  R1379   
 L  R1380   
 L  R1381   
 G  R1382   
 L  R1383   
 G  R1384   
 G  R1385   
 G  R1386   
 G  R1387   
 G  R1388   
 G  R1389   
 G  R1390   
 G  R1391   
 G  R1392   
 G  R1393   
 G  R1394   
 G  R1395   
 G  R1396   
 G  R1397   
 G  R1398   
 G  R1399   
 G  R1400   
 G  R1401   
 G  R1402   
 G  R1403   
 L  R1404   
 L  R1405   
 G  R1406   
 E  R1407   
 E  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 G  R1443   
 G  R1444   
 L  R1445   
 G  R1446   
 L  R1447   
 G  R1448   
 G  R1449   
 L  R1450   
 G  R1451   
 L  R1452   
 G  R1453   
 G  R1454   
 L  R1455   
 G  R1456   
 L  R1457   
 G  R1458   
 G  R1459   
 L  R1460   
 G  R1461   
 L  R1462   
 G  R1463   
 G  R1464   
 L  R1465   
 G  R1466   
 L  R1467   
 G  R1468   
 G  R1469   
 L  R1470   
 G  R1471   
 L  R1472   
 G  R1473   
 G  R1474   
 L  R1475   
 G  R1476   
 L  R1477   
 G  R1478   
 G  R1479   
 L  R1480   
 G  R1481   
 L  R1482   
 G  R1483   
 G  R1484   
 L  R1485   
 G  R1486   
 L  R1487   
 G  R1488   
 G  R1489   
 L  R1490   
 G  R1491   
 L  R1492   
 G  R1493   
 G  R1494   
 G  R1495   
 G  R1496   
 G  R1497   
 G  R1498   
 G  R1499   
 G  R1500   
 G  R1501   
 G  R1502   
 L  R1503   
 L  R1504   
 G  R1505   
 L  R1506   
 G  R1507   
 L  R1508   
 G  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 G  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 G  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 G  R1521   
 L  R1522   
 L  R1523   
 G  R1524   
 L  R1525   
 L  R1526   
 G  R1527   
 L  R1528   
 L  R1529   
 G  R1530   
 L  R1531   
 L  R1532   
 G  R1533   
 L  R1534   
 G  R1535   
 G  R1536   
 G  R1537   
 G  R1538   
 G  R1539   
 G  R1540   
 G  R1541   
 G  R1542   
 G  R1543   
 G  R1544   
 G  R1545   
 G  R1546   
 G  R1547   
 G  R1548   
 G  R1549   
 G  R1550   
 G  R1551   
 G  R1552   
 G  R1553   
 G  R1554   
 L  R1555   
 L  R1556   
 G  R1557   
 E  R1558   
 E  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 G  R1594   
 G  R1595   
 L  R1596   
 G  R1597   
 L  R1598   
 G  R1599   
 G  R1600   
 L  R1601   
 G  R1602   
 L  R1603   
 G  R1604   
 G  R1605   
 L  R1606   
 G  R1607   
 L  R1608   
 G  R1609   
 G  R1610   
 L  R1611   
 G  R1612   
 L  R1613   
 G  R1614   
 G  R1615   
 L  R1616   
 G  R1617   
 L  R1618   
 G  R1619   
 G  R1620   
 L  R1621   
 G  R1622   
 L  R1623   
 G  R1624   
 G  R1625   
 L  R1626   
 G  R1627   
 L  R1628   
 G  R1629   
 G  R1630   
 L  R1631   
 G  R1632   
 L  R1633   
 G  R1634   
 G  R1635   
 L  R1636   
 G  R1637   
 L  R1638   
 G  R1639   
 G  R1640   
 L  R1641   
 G  R1642   
 L  R1643   
 G  R1644   
 G  R1645   
 G  R1646   
 G  R1647   
 G  R1648   
 G  R1649   
 G  R1650   
 G  R1651   
 G  R1652   
 G  R1653   
 L  R1654   
 L  R1655   
 G  R1656   
 L  R1657   
 G  R1658   
 L  R1659   
 G  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 G  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 G  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 G  R1672   
 L  R1673   
 L  R1674   
 G  R1675   
 L  R1676   
 L  R1677   
 G  R1678   
 L  R1679   
 L  R1680   
 G  R1681   
 L  R1682   
 L  R1683   
 G  R1684   
 L  R1685   
 G  R1686   
 G  R1687   
 G  R1688   
 G  R1689   
 G  R1690   
 G  R1691   
 G  R1692   
 G  R1693   
 G  R1694   
 G  R1695   
 G  R1696   
 G  R1697   
 G  R1698   
 G  R1699   
 G  R1700   
 G  R1701   
 G  R1702   
 G  R1703   
 G  R1704   
 G  R1705   
 L  R1706   
 L  R1707   
 G  R1708   
 E  R1709   
 E  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 G  R1745   
 G  R1746   
 L  R1747   
 G  R1748   
 L  R1749   
 G  R1750   
 G  R1751   
 L  R1752   
 G  R1753   
 L  R1754   
 G  R1755   
 G  R1756   
 L  R1757   
 G  R1758   
 L  R1759   
 G  R1760   
 G  R1761   
 L  R1762   
 G  R1763   
 L  R1764   
 G  R1765   
 G  R1766   
 L  R1767   
 G  R1768   
 L  R1769   
 G  R1770   
 G  R1771   
 L  R1772   
 G  R1773   
 L  R1774   
 G  R1775   
 G  R1776   
 L  R1777   
 G  R1778   
 L  R1779   
 G  R1780   
 G  R1781   
 L  R1782   
 G  R1783   
 L  R1784   
 G  R1785   
 G  R1786   
 L  R1787   
 G  R1788   
 L  R1789   
 G  R1790   
 G  R1791   
 L  R1792   
 G  R1793   
 L  R1794   
 G  R1795   
 G  R1796   
 G  R1797   
 G  R1798   
 G  R1799   
 G  R1800   
 G  R1801   
 G  R1802   
 G  R1803   
 G  R1804   
 L  R1805   
 L  R1806   
 G  R1807   
 L  R1808   
 G  R1809   
 L  R1810   
 G  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 G  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 G  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 G  R1823   
 L  R1824   
 L  R1825   
 G  R1826   
 L  R1827   
 L  R1828   
 G  R1829   
 L  R1830   
 L  R1831   
 G  R1832   
 L  R1833   
 L  R1834   
 G  R1835   
 L  R1836   
 G  R1837   
 G  R1838   
 G  R1839   
 G  R1840   
 G  R1841   
 G  R1842   
 G  R1843   
 G  R1844   
 G  R1845   
 G  R1846   
 G  R1847   
 G  R1848   
 G  R1849   
 G  R1850   
 G  R1851   
 G  R1852   
 G  R1853   
 G  R1854   
 G  R1855   
 G  R1856   
 L  R1857   
 L  R1858   
 G  R1859   
 E  R1860   
 E  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 G  R1896   
 G  R1897   
 L  R1898   
 G  R1899   
 L  R1900   
 G  R1901   
 G  R1902   
 L  R1903   
 G  R1904   
 L  R1905   
 G  R1906   
 G  R1907   
 L  R1908   
 G  R1909   
 L  R1910   
 G  R1911   
 G  R1912   
 L  R1913   
 G  R1914   
 L  R1915   
 G  R1916   
 G  R1917   
 L  R1918   
 G  R1919   
 L  R1920   
 G  R1921   
 G  R1922   
 L  R1923   
 G  R1924   
 L  R1925   
 G  R1926   
 G  R1927   
 L  R1928   
 G  R1929   
 L  R1930   
 G  R1931   
 G  R1932   
 L  R1933   
 G  R1934   
 L  R1935   
 G  R1936   
 G  R1937   
 L  R1938   
 G  R1939   
 L  R1940   
 G  R1941   
 G  R1942   
 L  R1943   
 G  R1944   
 L  R1945   
 G  R1946   
 G  R1947   
 G  R1948   
 G  R1949   
 G  R1950   
 G  R1951   
 G  R1952   
 G  R1953   
 G  R1954   
 G  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 G  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 G  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 G  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 G  R1972   
 L  R1973   
 L  R1974   
 G  R1975   
 L  R1976   
 L  R1977   
 G  R1978   
 L  R1979   
 L  R1980   
 G  R1981   
 L  R1982   
 L  R1983   
 G  R1984   
 L  R1985   
 G  R1986   
 G  R1987   
 G  R1988   
 G  R1989   
 G  R1990   
 G  R1991   
 G  R1992   
 G  R1993   
 G  R1994   
 G  R1995   
 G  R1996   
 G  R1997   
 G  R1998   
 G  R1999   
 G  R2000   
 G  R2001   
 G  R2002   
 G  R2003   
 G  R2004   
 G  R2005   
 L  R2006   
 L  R2007   
 G  R2008   
 E  R2009   
 E  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 G  R2045   
 G  R2046   
 L  R2047   
 G  R2048   
 L  R2049   
 G  R2050   
 G  R2051   
 L  R2052   
 G  R2053   
 L  R2054   
 G  R2055   
 G  R2056   
 L  R2057   
 G  R2058   
 L  R2059   
 G  R2060   
 G  R2061   
 L  R2062   
 G  R2063   
 L  R2064   
 G  R2065   
 G  R2066   
 L  R2067   
 G  R2068   
 L  R2069   
 G  R2070   
 G  R2071   
 L  R2072   
 G  R2073   
 L  R2074   
 G  R2075   
 G  R2076   
 L  R2077   
 G  R2078   
 L  R2079   
 G  R2080   
 G  R2081   
 L  R2082   
 G  R2083   
 L  R2084   
 G  R2085   
 G  R2086   
 L  R2087   
 G  R2088   
 L  R2089   
 G  R2090   
 G  R2091   
 L  R2092   
 G  R2093   
 L  R2094   
 G  R2095   
 G  R2096   
 G  R2097   
 G  R2098   
 G  R2099   
 G  R2100   
 G  R2101   
 G  R2102   
 G  R2103   
 G  R2104   
 L  R2105   
 L  R2106   
 G  R2107   
 L  R2108   
 G  R2109   
 L  R2110   
 G  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 G  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 G  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 G  R2123   
 L  R2124   
 L  R2125   
 G  R2126   
 L  R2127   
 L  R2128   
 G  R2129   
 L  R2130   
 L  R2131   
 G  R2132   
 L  R2133   
 L  R2134   
 G  R2135   
 L  R2136   
 G  R2137   
 G  R2138   
 G  R2139   
 G  R2140   
 G  R2141   
 G  R2142   
 G  R2143   
 G  R2144   
 G  R2145   
 G  R2146   
 G  R2147   
 G  R2148   
 G  R2149   
 G  R2150   
 G  R2151   
 G  R2152   
 G  R2153   
 G  R2154   
 G  R2155   
 G  R2156   
 L  R2157   
 L  R2158   
 G  R2159   
 E  R2160   
 E  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 G  R2196   
 G  R2197   
 L  R2198   
 G  R2199   
 L  R2200   
 G  R2201   
 G  R2202   
 L  R2203   
 G  R2204   
 L  R2205   
 G  R2206   
 G  R2207   
 L  R2208   
 G  R2209   
 L  R2210   
 G  R2211   
 G  R2212   
 L  R2213   
 G  R2214   
 L  R2215   
 G  R2216   
 G  R2217   
 L  R2218   
 G  R2219   
 L  R2220   
 G  R2221   
 G  R2222   
 L  R2223   
 G  R2224   
 L  R2225   
 G  R2226   
 G  R2227   
 L  R2228   
 G  R2229   
 L  R2230   
 G  R2231   
 G  R2232   
 L  R2233   
 G  R2234   
 L  R2235   
 G  R2236   
 G  R2237   
 L  R2238   
 G  R2239   
 L  R2240   
 G  R2241   
 G  R2242   
 L  R2243   
 G  R2244   
 L  R2245   
 G  R2246   
 G  R2247   
 G  R2248   
 G  R2249   
 G  R2250   
 G  R2251   
 G  R2252   
 G  R2253   
 G  R2254   
 G  R2255   
 L  R2256   
 L  R2257   
 G  R2258   
 L  R2259   
 G  R2260   
 L  R2261   
 G  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 G  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 G  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 G  R2274   
 L  R2275   
 L  R2276   
 G  R2277   
 L  R2278   
 L  R2279   
 G  R2280   
 L  R2281   
 L  R2282   
 G  R2283   
 L  R2284   
 L  R2285   
 G  R2286   
 L  R2287   
 G  R2288   
 G  R2289   
 G  R2290   
 G  R2291   
 G  R2292   
 G  R2293   
 G  R2294   
 G  R2295   
 G  R2296   
 G  R2297   
 G  R2298   
 G  R2299   
 G  R2300   
 G  R2301   
 G  R2302   
 G  R2303   
 G  R2304   
 G  R2305   
 G  R2306   
 G  R2307   
 L  R2308   
 L  R2309   
 G  R2310   
 E  R2311   
 E  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 G  R2347   
 G  R2348   
 L  R2349   
 G  R2350   
 L  R2351   
 G  R2352   
 G  R2353   
 L  R2354   
 G  R2355   
 L  R2356   
 G  R2357   
 G  R2358   
 L  R2359   
 G  R2360   
 L  R2361   
 G  R2362   
 G  R2363   
 L  R2364   
 G  R2365   
 L  R2366   
 G  R2367   
 G  R2368   
 L  R2369   
 G  R2370   
 L  R2371   
 G  R2372   
 G  R2373   
 L  R2374   
 G  R2375   
 L  R2376   
 G  R2377   
 G  R2378   
 L  R2379   
 G  R2380   
 L  R2381   
 G  R2382   
 G  R2383   
 L  R2384   
 G  R2385   
 L  R2386   
 G  R2387   
 G  R2388   
 L  R2389   
 G  R2390   
 L  R2391   
 G  R2392   
 G  R2393   
 L  R2394   
 G  R2395   
 L  R2396   
 G  R2397   
 G  R2398   
 G  R2399   
 G  R2400   
 G  R2401   
 G  R2402   
 G  R2403   
 G  R2404   
 G  R2405   
 G  R2406   
 L  R2407   
 L  R2408   
 G  R2409   
 L  R2410   
 G  R2411   
 L  R2412   
 G  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 G  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 G  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 G  R2425   
 L  R2426   
 L  R2427   
 G  R2428   
 L  R2429   
 L  R2430   
 G  R2431   
 L  R2432   
 L  R2433   
 G  R2434   
 L  R2435   
 L  R2436   
 G  R2437   
 L  R2438   
 G  R2439   
 G  R2440   
 G  R2441   
 G  R2442   
 G  R2443   
 G  R2444   
 G  R2445   
 G  R2446   
 G  R2447   
 G  R2448   
 G  R2449   
 G  R2450   
 G  R2451   
 G  R2452   
 G  R2453   
 G  R2454   
 G  R2455   
 G  R2456   
 G  R2457   
 G  R2458   
 L  R2459   
 L  R2460   
 G  R2461   
 E  R2462   
 E  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 G  R2498   
 G  R2499   
 L  R2500   
 G  R2501   
 L  R2502   
 G  R2503   
 G  R2504   
 L  R2505   
 G  R2506   
 L  R2507   
 G  R2508   
 G  R2509   
 L  R2510   
 G  R2511   
 L  R2512   
 G  R2513   
 G  R2514   
 L  R2515   
 G  R2516   
 L  R2517   
 G  R2518   
 G  R2519   
 L  R2520   
 G  R2521   
 L  R2522   
 G  R2523   
 G  R2524   
 L  R2525   
 G  R2526   
 L  R2527   
 G  R2528   
 G  R2529   
 L  R2530   
 G  R2531   
 L  R2532   
 G  R2533   
 G  R2534   
 L  R2535   
 G  R2536   
 L  R2537   
 G  R2538   
 G  R2539   
 L  R2540   
 G  R2541   
 L  R2542   
 G  R2543   
 G  R2544   
 L  R2545   
 G  R2546   
 L  R2547   
 G  R2548   
 G  R2549   
 G  R2550   
 G  R2551   
 G  R2552   
 G  R2553   
 G  R2554   
 G  R2555   
 G  R2556   
 G  R2557   
 L  R2558   
 L  R2559   
 G  R2560   
 L  R2561   
 G  R2562   
 L  R2563   
 G  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 G  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 G  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 G  R2576   
 L  R2577   
 L  R2578   
 G  R2579   
 L  R2580   
 L  R2581   
 G  R2582   
 L  R2583   
 L  R2584   
 G  R2585   
 L  R2586   
 L  R2587   
 G  R2588   
 L  R2589   
 G  R2590   
 G  R2591   
 G  R2592   
 G  R2593   
 G  R2594   
 G  R2595   
 G  R2596   
 G  R2597   
 G  R2598   
 G  R2599   
 G  R2600   
 G  R2601   
 G  R2602   
 G  R2603   
 G  R2604   
 G  R2605   
 G  R2606   
 G  R2607   
 G  R2608   
 G  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 G  R2613   
 E  R2614   
 E  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 G  R2650   
 G  R2651   
 L  R2652   
 G  R2653   
 L  R2654   
 G  R2655   
 G  R2656   
 L  R2657   
 G  R2658   
 L  R2659   
 G  R2660   
 G  R2661   
 L  R2662   
 G  R2663   
 L  R2664   
 G  R2665   
 G  R2666   
 L  R2667   
 G  R2668   
 L  R2669   
 G  R2670   
 G  R2671   
 L  R2672   
 G  R2673   
 L  R2674   
 G  R2675   
 G  R2676   
 L  R2677   
 G  R2678   
 L  R2679   
 G  R2680   
 G  R2681   
 L  R2682   
 G  R2683   
 L  R2684   
 G  R2685   
 G  R2686   
 L  R2687   
 G  R2688   
 L  R2689   
 G  R2690   
 G  R2691   
 L  R2692   
 G  R2693   
 L  R2694   
 G  R2695   
 G  R2696   
 L  R2697   
 G  R2698   
 L  R2699   
 G  R2700   
 G  R2701   
 G  R2702   
 G  R2703   
 G  R2704   
 G  R2705   
 G  R2706   
 G  R2707   
 G  R2708   
 G  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 G  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 G  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 G  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 G  R2726   
 L  R2727   
 L  R2728   
 G  R2729   
 L  R2730   
 L  R2731   
 G  R2732   
 L  R2733   
 L  R2734   
 G  R2735   
 L  R2736   
 L  R2737   
 G  R2738   
 L  R2739   
 G  R2740   
 G  R2741   
 G  R2742   
 G  R2743   
 G  R2744   
 G  R2745   
 G  R2746   
 G  R2747   
 G  R2748   
 G  R2749   
 G  R2750   
 G  R2751   
 G  R2752   
 G  R2753   
 G  R2754   
 G  R2755   
 G  R2756   
 G  R2757   
 G  R2758   
 G  R2759   
 L  R2760   
 L  R2761   
 G  R2762   
 E  R2763   
 E  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 G  R2799   
 G  R2800   
 L  R2801   
 G  R2802   
 L  R2803   
 G  R2804   
 G  R2805   
 L  R2806   
 G  R2807   
 L  R2808   
 G  R2809   
 G  R2810   
 L  R2811   
 G  R2812   
 L  R2813   
 G  R2814   
 G  R2815   
 L  R2816   
 G  R2817   
 L  R2818   
 G  R2819   
 G  R2820   
 L  R2821   
 G  R2822   
 L  R2823   
 G  R2824   
 G  R2825   
 L  R2826   
 G  R2827   
 L  R2828   
 G  R2829   
 G  R2830   
 L  R2831   
 G  R2832   
 L  R2833   
 G  R2834   
 G  R2835   
 L  R2836   
 G  R2837   
 L  R2838   
 G  R2839   
 G  R2840   
 L  R2841   
 G  R2842   
 L  R2843   
 G  R2844   
 G  R2845   
 L  R2846   
 G  R2847   
 L  R2848   
 G  R2849   
 G  R2850   
 G  R2851   
 G  R2852   
 G  R2853   
 G  R2854   
 G  R2855   
 G  R2856   
 G  R2857   
 G  R2858   
 L  R2859   
 L  R2860   
 G  R2861   
 L  R2862   
 G  R2863   
 L  R2864   
 G  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 G  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 G  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 G  R2877   
 L  R2878   
 L  R2879   
 G  R2880   
 L  R2881   
 L  R2882   
 G  R2883   
 L  R2884   
 L  R2885   
 G  R2886   
 L  R2887   
 L  R2888   
 G  R2889   
 L  R2890   
 G  R2891   
 G  R2892   
 G  R2893   
 G  R2894   
 G  R2895   
 G  R2896   
 G  R2897   
 G  R2898   
 G  R2899   
 G  R2900   
 G  R2901   
 G  R2902   
 G  R2903   
 G  R2904   
 G  R2905   
 G  R2906   
 G  R2907   
 G  R2908   
 G  R2909   
 G  R2910   
 L  R2911   
 L  R2912   
 G  R2913   
 E  R2914   
 E  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  R2937   
 L  R2938   
 L  R2939   
 L  R2940   
 L  R2941   
 L  R2942   
 L  R2943   
 L  R2944   
 L  R2945   
 L  R2946   
 L  R2947   
 L  R2948   
 L  R2949   
 G  R2950   
 G  R2951   
 L  R2952   
 G  R2953   
 L  R2954   
 G  R2955   
 G  R2956   
 L  R2957   
 G  R2958   
 L  R2959   
 G  R2960   
 G  R2961   
 L  R2962   
 G  R2963   
 L  R2964   
 G  R2965   
 G  R2966   
 L  R2967   
 G  R2968   
 L  R2969   
 G  R2970   
 G  R2971   
 L  R2972   
 G  R2973   
 L  R2974   
 G  R2975   
 G  R2976   
 L  R2977   
 G  R2978   
 L  R2979   
 G  R2980   
 G  R2981   
 L  R2982   
 G  R2983   
 L  R2984   
 G  R2985   
 G  R2986   
 L  R2987   
 G  R2988   
 L  R2989   
 G  R2990   
 G  R2991   
 L  R2992   
 G  R2993   
 L  R2994   
 G  R2995   
 G  R2996   
 L  R2997   
 G  R2998   
 L  R2999   
 G  R3000   
 G  R3001   
 G  R3002   
 G  R3003   
 G  R3004   
 G  R3005   
 G  R3006   
 G  R3007   
 G  R3008   
 G  R3009   
 L  R3010   
 L  R3011   
 G  R3012   
 L  R3013   
 G  R3014   
 L  R3015   
 G  R3016   
 L  R3017   
 L  R3018   
 L  R3019   
 G  R3020   
 L  R3021   
 L  R3022   
 L  R3023   
 G  R3024   
 L  R3025   
 L  R3026   
 L  R3027   
 G  R3028   
 L  R3029   
 L  R3030   
 G  R3031   
 L  R3032   
 L  R3033   
 G  R3034   
 L  R3035   
 L  R3036   
 G  R3037   
 L  R3038   
 L  R3039   
 G  R3040   
 L  R3041   
 G  R3042   
 G  R3043   
 G  R3044   
 G  R3045   
 G  R3046   
 G  R3047   
 G  R3048   
 G  R3049   
 G  R3050   
 G  R3051   
 G  R3052   
 G  R3053   
 G  R3054   
 G  R3055   
 G  R3056   
 G  R3057   
 G  R3058   
 G  R3059   
 G  R3060   
 G  R3061   
 L  R3062   
 L  R3063   
 L  R3064   
 L  R3065   
 L  R3066   
 L  R3067   
 L  R3068   
 L  R3069   
 L  R3070   
 L  R3071   
 L  R3072   
 L  R3073   
 L  R3074   
 L  R3075   
 L  R3076   
 L  R3077   
 L  R3078   
 L  R3079   
 L  R3080   
 L  R3081   
 L  R3082   
 L  R3083   
 L  R3084   
 L  R3085   
 L  R3086   
 L  R3087   
 L  R3088   
 L  R3089   
 L  R3090   
 L  R3091   
 L  R3092   
 L  R3093   
 L  R3094   
 L  R3095   
 L  R3096   
 L  R3097   
 L  R3098   
 L  R3099   
 L  R3100   
 L  R3101   
 L  R3102   
 L  R3103   
 L  R3104   
 L  R3105   
 L  R3106   
 L  R3107   
 L  R3108   
 L  R3109   
 L  R3110   
 L  R3111   
 L  R3112   
 L  R3113   
 L  R3114   
 L  R3115   
 L  R3116   
 L  R3117   
 L  R3118   
 L  R3119   
 L  R3120   
 L  R3121   
 L  R3122   
 L  R3123   
 L  R3124   
 L  R3125   
 L  R3126   
 L  R3127   
 L  R3128   
 L  R3129   
 L  R3130   
 L  R3131   
 L  R3132   
 L  R3133   
 L  R3134   
 L  R3135   
 L  R3136   
 L  R3137   
 L  R3138   
 L  R3139   
 L  R3140   
 L  R3141   
 L  R3142   
 E  R3143   
 E  R3144   
 E  R3145   
 E  R3146   
 E  R3147   
 E  R3148   
 E  R3149   
 E  R3150   
 E  R3151   
 E  R3152   
 E  R3153   
 E  R3154   
 E  R3155   
 E  R3156   
 E  R3157   
 E  R3158   
 E  R3159   
 E  R3160   
 E  R3161   
 E  R3162   
 E  R3163   
 E  R3164   
 E  R3165   
 E  R3166   
 E  R3167   
 E  R3168   
 E  R3169   
 E  R3170   
 E  R3171   
 E  R3172   
 G  R3173   
 G  R3174   
 L  R3175   
 G  R3176   
 L  R3177   
 G  R3178   
 G  R3179   
 G  R3180   
 L  R3181   
 G  R3182   
 L  R3183   
 G  R3184   
 G  R3185   
 G  R3186   
 L  R3187   
 G  R3188   
 L  R3189   
 G  R3190   
 G  R3191   
 G  R3192   
 L  R3193   
 G  R3194   
 L  R3195   
 G  R3196   
 G  R3197   
 G  R3198   
 L  R3199   
 G  R3200   
 L  R3201   
 G  R3202   
 G  R3203   
 G  R3204   
 L  R3205   
 G  R3206   
 L  R3207   
 G  R3208   
 G  R3209   
 G  R3210   
 L  R3211   
 G  R3212   
 L  R3213   
 G  R3214   
 G  R3215   
 G  R3216   
 L  R3217   
 G  R3218   
 L  R3219   
 G  R3220   
 G  R3221   
 G  R3222   
 L  R3223   
 G  R3224   
 L  R3225   
 G  R3226   
 G  R3227   
 G  R3228   
 L  R3229   
 G  R3230   
 L  R3231   
 G  R3232   
 G  R3233   
 G  R3234   
 L  R3235   
 G  R3236   
 L  R3237   
 G  R3238   
 G  R3239   
 G  R3240   
 L  R3241   
 G  R3242   
 L  R3243   
 G  R3244   
 G  R3245   
 G  R3246   
 L  R3247   
 G  R3248   
 L  R3249   
 G  R3250   
 G  R3251   
 G  R3252   
 L  R3253   
 G  R3254   
 L  R3255   
 G  R3256   
 G  R3257   
 G  R3258   
 L  R3259   
 G  R3260   
 L  R3261   
 G  R3262   
 G  R3263   
 G  R3264   
 L  R3265   
 G  R3266   
 L  R3267   
 G  R3268   
 G  R3269   
 G  R3270   
 L  R3271   
 G  R3272   
 L  R3273   
 G  R3274   
 G  R3275   
 G  R3276   
 L  R3277   
 G  R3278   
 L  R3279   
 G  R3280   
 G  R3281   
 G  R3282   
 L  R3283   
 G  R3284   
 L  R3285   
 G  R3286   
 G  R3287   
 G  R3288   
 L  R3289   
 G  R3290   
 L  R3291   
 G  R3292   
 G  R3293   
 G  R3294   
 L  R3295   
 G  R3296   
 L  R3297   
 G  R3298   
 G  R3299   
 G  R3300   
 L  R3301   
 G  R3302   
 L  R3303   
 G  R3304   
 G  R3305   
 G  R3306   
 L  R3307   
 G  R3308   
 L  R3309   
 G  R3310   
 G  R3311   
 G  R3312   
 L  R3313   
 G  R3314   
 L  R3315   
 G  R3316   
 G  R3317   
 G  R3318   
 L  R3319   
 G  R3320   
 L  R3321   
 G  R3322   
 G  R3323   
 G  R3324   
 L  R3325   
 G  R3326   
 L  R3327   
 G  R3328   
 G  R3329   
 G  R3330   
 L  R3331   
 G  R3332   
 L  R3333   
 G  R3334   
 G  R3335   
 G  R3336   
 L  R3337   
 G  R3338   
 L  R3339   
 G  R3340   
 G  R3341   
 G  R3342   
 L  R3343   
 G  R3344   
 L  R3345   
 G  R3346   
 G  R3347   
 G  R3348   
 L  R3349   
 G  R3350   
 L  R3351   
 G  R3352   
 G  R3353   
 G  R3354   
 L  R3355   
 G  R3356   
 L  R3357   
 G  R3358   
 G  R3359   
 G  R3360   
 L  R3361   
 G  R3362   
 L  R3363   
 G  R3364   
 G  R3365   
 G  R3366   
 L  R3367   
 G  R3368   
 L  R3369   
 G  R3370   
 G  R3371   
 G  R3372   
 L  R3373   
 G  R3374   
 L  R3375   
 G  R3376   
 G  R3377   
 G  R3378   
 L  R3379   
 G  R3380   
 L  R3381   
 G  R3382   
 G  R3383   
 G  R3384   
 L  R3385   
 G  R3386   
 L  R3387   
 G  R3388   
 G  R3389   
 G  R3390   
 L  R3391   
 G  R3392   
 L  R3393   
 G  R3394   
 G  R3395   
 G  R3396   
 L  R3397   
 G  R3398   
 L  R3399   
 G  R3400   
 G  R3401   
 G  R3402   
 L  R3403   
 G  R3404   
 L  R3405   
 G  R3406   
 G  R3407   
 G  R3408   
 L  R3409   
 G  R3410   
 L  R3411   
 G  R3412   
 E  R3413   
 E  R3414   
 G  R3415   
 G  R3416   
 E  R3417   
 E  R3418   
 G  R3419   
 G  R3420   
 E  R3421   
 E  R3422   
 G  R3423   
 G  R3424   
 E  R3425   
 E  R3426   
 G  R3427   
 G  R3428   
 E  R3429   
 E  R3430   
 G  R3431   
 G  R3432   
 L  R3453   
 L  R3457   
 L  R3461   
 L  R3465   
 L  R3469   
 L  R3473   
 L  R3477   
 L  R3481   
 L  R3485   
 G  clean_stock_b1
 L  R3490   
 L  R3494   
 L  R3498   
 L  R3502   
 L  R3506   
 L  R3510   
 L  R3514   
 L  R3518   
 L  R3522   
 G  clean_stock_b2
 L  R3527   
 L  R3531   
 L  R3535   
 L  R3539   
 L  R3543   
 L  R3547   
 L  R3551   
 L  R3555   
 L  R3559   
 G  clean_stock_b3
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    delivery_S4_b1  R452      -1
    delivery_S4_b1  R603      -1
    delivery_S4_b1  R754      -1
    delivery_S4_b1  R905      -1
    delivery_S4_b1  R1056     -1
    delivery_S4_b1  R1207     -1
    delivery_S4_b1  R1358     -1
    delivery_S4_b1  R1509     -1
    delivery_S4_b1  R1660     -1
    delivery_S4_b1  R1811     -1
    delivery_S4_b1  R1960     -1
    delivery_S4_b1  R2111     -1
    delivery_S4_b1  R2262     -1
    delivery_S4_b1  R2413     -1
    delivery_S4_b1  R2564     -1
    delivery_S4_b1  R2714     -1
    delivery_S4_b1  R2865     -1
    delivery_S4_b1  R3016     -1
    delivery_S4_b2  R456      -1
    delivery_S4_b2  R607      -1
    delivery_S4_b2  R758      -1
    delivery_S4_b2  R909      -1
    delivery_S4_b2  R1060     -1
    delivery_S4_b2  R1211     -1
    delivery_S4_b2  R1362     -1
    delivery_S4_b2  R1513     -1
    delivery_S4_b2  R1664     -1
    delivery_S4_b2  R1815     -1
    delivery_S4_b2  R1964     -1
    delivery_S4_b2  R2115     -1
    delivery_S4_b2  R2266     -1
    delivery_S4_b2  R2417     -1
    delivery_S4_b2  R2568     -1
    delivery_S4_b2  R2718     -1
    delivery_S4_b2  R2869     -1
    delivery_S4_b2  R3020     -1
    delivery_S4_b3  R460      -1
    delivery_S4_b3  R611      -1
    delivery_S4_b3  R762      -1
    delivery_S4_b3  R913      -1
    delivery_S4_b3  R1064     -1
    delivery_S4_b3  R1215     -1
    delivery_S4_b3  R1366     -1
    delivery_S4_b3  R1517     -1
    delivery_S4_b3  R1668     -1
    delivery_S4_b3  R1819     -1
    delivery_S4_b3  R1968     -1
    delivery_S4_b3  R2119     -1
    delivery_S4_b3  R2270     -1
    delivery_S4_b3  R2421     -1
    delivery_S4_b3  R2572     -1
    delivery_S4_b3  R2722     -1
    delivery_S4_b3  R2873     -1
    delivery_S4_b3  R3024     -1
    C24_order_d  R389      1
    C24_order_d  R439      -1
    C24_order_d  R537      1
    C24_order_d  R587      -1
    C24_order_d  R688      1
    C24_order_d  R738      -1
    C24_order_d  R839      1
    C24_order_d  R889      -1
    C24_order_d  R990      1
    C24_order_d  R1040     -1
    C24_order_d  R1141     1
    C24_order_d  R1191     -1
    C24_order_d  R1292     1
    C24_order_d  R1342     -1
    C24_order_d  R1443     1
    C24_order_d  R1493     -1
    C24_order_d  R1594     1
    C24_order_d  R1644     -1
    C24_order_d  R1745     1
    C24_order_d  R1795     -1
    C24_order_d  R1896     1
    C24_order_d  R1946     -1
    C24_order_d  R2045     1
    C24_order_d  R2095     -1
    C24_order_d  R2196     1
    C24_order_d  R2246     -1
    C24_order_d  R2347     1
    C24_order_d  R2397     -1
    C24_order_d  R2498     1
    C24_order_d  R2548     -1
    C24_order_d  R2650     1
    C24_order_d  R2700     -1
    C24_order_d  R2799     1
    C24_order_d  R2849     -1
    C24_order_d  R2950     1
    C24_order_d  R3000     -1
    C24_order_d  R3173     -1
    C24_order_d  R3179     -1
    C24_order_d  R3185     -1
    C24_order_d  R3191     -1
    C24_order_d  R3197     -1
    C24_order_d  R3203     -1
    C24_order_d  R3415     -1
    C24_order_p  R327      -1
    C24_order_p  R394      1
    C24_order_p  R440      -1
    C24_order_p  R542      1
    C24_order_p  R588      -1
    C24_order_p  R693      1
    C24_order_p  R739      -1
    C24_order_p  R844      1
    C24_order_p  R890      -1
    C24_order_p  R995      1
    C24_order_p  R1041     -1
    C24_order_p  R1146     1
    C24_order_p  R1192     -1
    C24_order_p  R1297     1
    C24_order_p  R1343     -1
    C24_order_p  R1448     1
    C24_order_p  R1494     -1
    C24_order_p  R1599     1
    C24_order_p  R1645     -1
    C24_order_p  R1750     1
    C24_order_p  R1796     -1
    C24_order_p  R1901     1
    C24_order_p  R1947     -1
    C24_order_p  R2050     1
    C24_order_p  R2096     -1
    C24_order_p  R2201     1
    C24_order_p  R2247     -1
    C24_order_p  R2352     1
    C24_order_p  R2398     -1
    C24_order_p  R2503     1
    C24_order_p  R2549     -1
    C24_order_p  R2655     1
    C24_order_p  R2701     -1
    C24_order_p  R2804     1
    C24_order_p  R2850     -1
    C24_order_p  R2955     1
    C24_order_p  R3001     -1
    C24_order_p  R3173     1
    C24_order_p  R3209     -1
    C24_order_p  R3215     -1
    C24_order_p  R3221     -1
    C24_order_p  R3227     -1
    C24_order_p  R3233     -1
    C24_order_p  R3239     -1
    C24_order_p  R3245     -1
    C24_order_p  R3251     1
    C24_order_p  R3281     1
    C24_order_p  R3415     1
    C34_order_d  R399      1
    C34_order_d  R441      -1
    C34_order_d  R547      1
    C34_order_d  R589      -1
    C34_order_d  R698      1
    C34_order_d  R740      -1
    C34_order_d  R849      1
    C34_order_d  R891      -1
    C34_order_d  R1000     1
    C34_order_d  R1042     -1
    C34_order_d  R1151     1
    C34_order_d  R1193     -1
    C34_order_d  R1302     1
    C34_order_d  R1344     -1
    C34_order_d  R1453     1
    C34_order_d  R1495     -1
    C34_order_d  R1604     1
    C34_order_d  R1646     -1
    C34_order_d  R1755     1
    C34_order_d  R1797     -1
    C34_order_d  R1906     1
    C34_order_d  R1948     -1
    C34_order_d  R2055     1
    C34_order_d  R2097     -1
    C34_order_d  R2206     1
    C34_order_d  R2248     -1
    C34_order_d  R2357     1
    C34_order_d  R2399     -1
    C34_order_d  R2508     1
    C34_order_d  R2550     -1
    C34_order_d  R2660     1
    C34_order_d  R2702     -1
    C34_order_d  R2809     1
    C34_order_d  R2851     -1
    C34_order_d  R2960     1
    C34_order_d  R3002     -1
    C34_order_d  R3179     1
    C34_order_d  R3251     -1
    C34_order_d  R3257     -1
    C34_order_d  R3263     -1
    C34_order_d  R3269     -1
    C34_order_d  R3275     -1
    C34_order_d  R3419     -1
    C34_order_p  R334      -1
    C34_order_p  R404      1
    C34_order_p  R442      -1
    C34_order_p  R552      1
    C34_order_p  R590      -1
    C34_order_p  R703      1
    C34_order_p  R741      -1
    C34_order_p  R854      1
    C34_order_p  R892      -1
    C34_order_p  R1005     1
    C34_order_p  R1043     -1
    C34_order_p  R1156     1
    C34_order_p  R1194     -1
    C34_order_p  R1307     1
    C34_order_p  R1345     -1
    C34_order_p  R1458     1
    C34_order_p  R1496     -1
    C34_order_p  R1609     1
    C34_order_p  R1647     -1
    C34_order_p  R1760     1
    C34_order_p  R1798     -1
    C34_order_p  R1911     1
    C34_order_p  R1949     -1
    C34_order_p  R2060     1
    C34_order_p  R2098     -1
    C34_order_p  R2211     1
    C34_order_p  R2249     -1
    C34_order_p  R2362     1
    C34_order_p  R2400     -1
    C34_order_p  R2513     1
    C34_order_p  R2551     -1
    C34_order_p  R2665     1
    C34_order_p  R2703     -1
    C34_order_p  R2814     1
    C34_order_p  R2852     -1
    C34_order_p  R2965     1
    C34_order_p  R3003     -1
    C34_order_p  R3185     1
    C34_order_p  R3209     1
    C34_order_p  R3257     1
    C34_order_p  R3281     -1
    C34_order_p  R3287     -1
    C34_order_p  R3293     -1
    C34_order_p  R3299     -1
    C34_order_p  R3305     -1
    C34_order_p  R3311     -1
    C34_order_p  R3317     -1
    C34_order_p  R3419     1
    C95_order_d  R409      1
    C95_order_d  R443      -1
    C95_order_d  R557      1
    C95_order_d  R591      -1
    C95_order_d  R708      1
    C95_order_d  R742      -1
    C95_order_d  R859      1
    C95_order_d  R893      -1
    C95_order_d  R1010     1
    C95_order_d  R1044     -1
    C95_order_d  R1161     1
    C95_order_d  R1195     -1
    C95_order_d  R1312     1
    C95_order_d  R1346     -1
    C95_order_d  R1463     1
    C95_order_d  R1497     -1
    C95_order_d  R1614     1
    C95_order_d  R1648     -1
    C95_order_d  R1765     1
    C95_order_d  R1799     -1
    C95_order_d  R1916     1
    C95_order_d  R1950     -1
    C95_order_d  R2065     1
    C95_order_d  R2099     -1
    C95_order_d  R2216     1
    C95_order_d  R2250     -1
    C95_order_d  R2367     1
    C95_order_d  R2401     -1
    C95_order_d  R2518     1
    C95_order_d  R2552     -1
    C95_order_d  R2670     1
    C95_order_d  R2704     -1
    C95_order_d  R2819     1
    C95_order_d  R2853     -1
    C95_order_d  R2970     1
    C95_order_d  R3004     -1
    C95_order_d  R3215     1
    C95_order_d  R3287     1
    C95_order_d  R3323     -1
    C95_order_d  R3329     -1
    C95_order_d  R3335     -1
    C95_order_d  R3341     -1
    C95_order_d  R3365     1
    C95_order_d  R3423     -1
    C95_order_p  R341      -1
    C95_order_p  R414      1
    C95_order_p  R444      -1
    C95_order_p  R562      1
    C95_order_p  R592      -1
    C95_order_p  R713      1
    C95_order_p  R743      -1
    C95_order_p  R864      1
    C95_order_p  R894      -1
    C95_order_p  R1015     1
    C95_order_p  R1045     -1
    C95_order_p  R1166     1
    C95_order_p  R1196     -1
    C95_order_p  R1317     1
    C95_order_p  R1347     -1
    C95_order_p  R1468     1
    C95_order_p  R1498     -1
    C95_order_p  R1619     1
    C95_order_p  R1649     -1
    C95_order_p  R1770     1
    C95_order_p  R1800     -1
    C95_order_p  R1921     1
    C95_order_p  R1951     -1
    C95_order_p  R2070     1
    C95_order_p  R2100     -1
    C95_order_p  R2221     1
    C95_order_p  R2251     -1
    C95_order_p  R2372     1
    C95_order_p  R2402     -1
    C95_order_p  R2523     1
    C95_order_p  R2553     -1
    C95_order_p  R2675     1
    C95_order_p  R2705     -1
    C95_order_p  R2824     1
    C95_order_p  R2854     -1
    C95_order_p  R2975     1
    C95_order_p  R3005     -1
    C95_order_p  R3191     1
    C95_order_p  R3221     1
    C95_order_p  R3263     1
    C95_order_p  R3293     1
    C95_order_p  R3323     1
    C95_order_p  R3347     -1
    C95_order_p  R3353     -1
    C95_order_p  R3359     -1
    C95_order_p  R3371     1
    C95_order_p  R3389     1
    C95_order_p  R3423     1
    C73_order_d  R419      1
    C73_order_d  R445      -1
    C73_order_d  R567      1
    C73_order_d  R593      -1
    C73_order_d  R718      1
    C73_order_d  R744      -1
    C73_order_d  R869      1
    C73_order_d  R895      -1
    C73_order_d  R1020     1
    C73_order_d  R1046     -1
    C73_order_d  R1171     1
    C73_order_d  R1197     -1
    C73_order_d  R1322     1
    C73_order_d  R1348     -1
    C73_order_d  R1473     1
    C73_order_d  R1499     -1
    C73_order_d  R1624     1
    C73_order_d  R1650     -1
    C73_order_d  R1775     1
    C73_order_d  R1801     -1
    C73_order_d  R1926     1
    C73_order_d  R1952     -1
    C73_order_d  R2075     1
    C73_order_d  R2101     -1
    C73_order_d  R2226     1
    C73_order_d  R2252     -1
    C73_order_d  R2377     1
    C73_order_d  R2403     -1
    C73_order_d  R2528     1
    C73_order_d  R2554     -1
    C73_order_d  R2680     1
    C73_order_d  R2706     -1
    C73_order_d  R2829     1
    C73_order_d  R2855     -1
    C73_order_d  R2980     1
    C73_order_d  R3006     -1
    C73_order_d  R3227     1
    C73_order_d  R3299     1
    C73_order_d  R3329     1
    C73_order_d  R3365     -1
    C73_order_d  R3371     -1
    C73_order_d  R3377     -1
    C73_order_d  R3383     -1
    C73_order_d  R3427     -1
    C73_order_p  R345      -1
    C73_order_p  R424      1
    C73_order_p  R446      -1
    C73_order_p  R572      1
    C73_order_p  R594      -1
    C73_order_p  R723      1
    C73_order_p  R745      -1
    C73_order_p  R874      1
    C73_order_p  R896      -1
    C73_order_p  R1025     1
    C73_order_p  R1047     -1
    C73_order_p  R1176     1
    C73_order_p  R1198     -1
    C73_order_p  R1327     1
    C73_order_p  R1349     -1
    C73_order_p  R1478     1
    C73_order_p  R1500     -1
    C73_order_p  R1629     1
    C73_order_p  R1651     -1
    C73_order_p  R1780     1
    C73_order_p  R1802     -1
    C73_order_p  R1931     1
    C73_order_p  R1953     -1
    C73_order_p  R2080     1
    C73_order_p  R2102     -1
    C73_order_p  R2231     1
    C73_order_p  R2253     -1
    C73_order_p  R2382     1
    C73_order_p  R2404     -1
    C73_order_p  R2533     1
    C73_order_p  R2555     -1
    C73_order_p  R2685     1
    C73_order_p  R2707     -1
    C73_order_p  R2834     1
    C73_order_p  R2856     -1
    C73_order_p  R2985     1
    C73_order_p  R3007     -1
    C73_order_p  R3197     1
    C73_order_p  R3233     1
    C73_order_p  R3269     1
    C73_order_p  R3305     1
    C73_order_p  R3335     1
    C73_order_p  R3347     1
    C73_order_p  R3377     1
    C73_order_p  R3389     -1
    C73_order_p  R3395     -1
    C73_order_p  R3401     -1
    C73_order_p  R3427     1
    C63_order_d  R429      1
    C63_order_d  R447      -1
    C63_order_d  R577      1
    C63_order_d  R595      -1
    C63_order_d  R728      1
    C63_order_d  R746      -1
    C63_order_d  R879      1
    C63_order_d  R897      -1
    C63_order_d  R1030     1
    C63_order_d  R1048     -1
    C63_order_d  R1181     1
    C63_order_d  R1199     -1
    C63_order_d  R1332     1
    C63_order_d  R1350     -1
    C63_order_d  R1483     1
    C63_order_d  R1501     -1
    C63_order_d  R1634     1
    C63_order_d  R1652     -1
    C63_order_d  R1785     1
    C63_order_d  R1803     -1
    C63_order_d  R1936     1
    C63_order_d  R1954     -1
    C63_order_d  R2085     1
    C63_order_d  R2103     -1
    C63_order_d  R2236     1
    C63_order_d  R2254     -1
    C63_order_d  R2387     1
    C63_order_d  R2405     -1
    C63_order_d  R2538     1
    C63_order_d  R2556     -1
    C63_order_d  R2690     1
    C63_order_d  R2708     -1
    C63_order_d  R2839     1
    C63_order_d  R2857     -1
    C63_order_d  R2990     1
    C63_order_d  R3008     -1
    C63_order_d  R3239     1
    C63_order_d  R3311     1
    C63_order_d  R3353     1
    C63_order_d  R3395     1
    C63_order_d  R3407     -1
    C63_order_d  R3431     -1
    C63_order_p  R349      -1
    C63_order_p  R434      1
    C63_order_p  R448      -1
    C63_order_p  R582      1
    C63_order_p  R596      -1
    C63_order_p  R733      1
    C63_order_p  R747      -1
    C63_order_p  R884      1
    C63_order_p  R898      -1
    C63_order_p  R1035     1
    C63_order_p  R1049     -1
    C63_order_p  R1186     1
    C63_order_p  R1200     -1
    C63_order_p  R1337     1
    C63_order_p  R1351     -1
    C63_order_p  R1488     1
    C63_order_p  R1502     -1
    C63_order_p  R1639     1
    C63_order_p  R1653     -1
    C63_order_p  R1790     1
    C63_order_p  R1804     -1
    C63_order_p  R1941     1
    C63_order_p  R1955     -1
    C63_order_p  R2090     1
    C63_order_p  R2104     -1
    C63_order_p  R2241     1
    C63_order_p  R2255     -1
    C63_order_p  R2392     1
    C63_order_p  R2406     -1
    C63_order_p  R2543     1
    C63_order_p  R2557     -1
    C63_order_p  R2695     1
    C63_order_p  R2709     -1
    C63_order_p  R2844     1
    C63_order_p  R2858     -1
    C63_order_p  R2995     1
    C63_order_p  R3009     -1
    C63_order_p  R3203     1
    C63_order_p  R3245     1
    C63_order_p  R3275     1
    C63_order_p  R3317     1
    C63_order_p  R3341     1
    C63_order_p  R3359     1
    C63_order_p  R3383     1
    C63_order_p  R3401     1
    C63_order_p  R3407     1
    C63_order_p  R3431     1
    MARKER    'MARKER'                 'INTEND'
    C13       R390      1
    C13       R391      1
    C13       R538      1
    C13       R539      1
    C13       R689      1
    C13       R690      1
    C13       R840      1
    C13       R841      1
    C13       R991      1
    C13       R992      1
    C13       R1142     1
    C13       R1143     1
    C13       R1293     1
    C13       R1294     1
    C13       R1444     1
    C13       R1445     1
    C13       R1595     1
    C13       R1596     1
    C13       R1746     1
    C13       R1747     1
    C13       R1897     1
    C13       R1898     1
    C13       R2046     1
    C13       R2047     1
    C13       R2197     1
    C13       R2198     1
    C13       R2348     1
    C13       R2349     1
    C13       R2499     1
    C13       R2500     1
    C13       R2651     1
    C13       R2652     1
    C13       R2800     1
    C13       R2801     1
    C13       R2951     1
    C13       R2952     1
    C13       R3174     -1
    C13       R3175     -1
    C13       R3180     -1
    C13       R3181     -1
    C13       R3186     -1
    C13       R3187     -1
    C13       R3192     -1
    C13       R3193     -1
    C13       R3198     -1
    C13       R3199     -1
    C13       R3204     -1
    C13       R3205     -1
    C14       R395      1
    C14       R396      1
    C14       R543      1
    C14       R544      1
    C14       R694      1
    C14       R695      1
    C14       R845      1
    C14       R846      1
    C14       R996      1
    C14       R997      1
    C14       R1147     1
    C14       R1148     1
    C14       R1298     1
    C14       R1299     1
    C14       R1449     1
    C14       R1450     1
    C14       R1600     1
    C14       R1601     1
    C14       R1751     1
    C14       R1752     1
    C14       R1902     1
    C14       R1903     1
    C14       R2051     1
    C14       R2052     1
    C14       R2202     1
    C14       R2203     1
    C14       R2353     1
    C14       R2354     1
    C14       R2504     1
    C14       R2505     1
    C14       R2656     1
    C14       R2657     1
    C14       R2805     1
    C14       R2806     1
    C14       R2956     1
    C14       R2957     1
    C14       R3174     1
    C14       R3175     1
    C14       R3210     -1
    C14       R3211     -1
    C14       R3216     -1
    C14       R3217     -1
    C14       R3222     -1
    C14       R3223     -1
    C14       R3228     -1
    C14       R3229     -1
    C14       R3234     -1
    C14       R3235     -1
    C14       R3240     -1
    C14       R3241     -1
    C14       R3246     -1
    C14       R3247     -1
    C14       R3252     1
    C14       R3253     1
    C14       R3282     1
    C14       R3283     1
    C15       R400      1
    C15       R401      1
    C15       R548      1
    C15       R549      1
    C15       R699      1
    C15       R700      1
    C15       R850      1
    C15       R851      1
    C15       R1001     1
    C15       R1002     1
    C15       R1152     1
    C15       R1153     1
    C15       R1303     1
    C15       R1304     1
    C15       R1454     1
    C15       R1455     1
    C15       R1605     1
    C15       R1606     1
    C15       R1756     1
    C15       R1757     1
    C15       R1907     1
    C15       R1908     1
    C15       R2056     1
    C15       R2057     1
    C15       R2207     1
    C15       R2208     1
    C15       R2358     1
    C15       R2359     1
    C15       R2509     1
    C15       R2510     1
    C15       R2661     1
    C15       R2662     1
    C15       R2810     1
    C15       R2811     1
    C15       R2961     1
    C15       R2962     1
    C15       R3180     1
    C15       R3181     1
    C15       R3252     -1
    C15       R3253     -1
    C15       R3258     -1
    C15       R3259     -1
    C15       R3264     -1
    C15       R3265     -1
    C15       R3270     -1
    C15       R3271     -1
    C15       R3276     -1
    C15       R3277     -1
    C16       R405      1
    C16       R406      1
    C16       R553      1
    C16       R554      1
    C16       R704      1
    C16       R705      1
    C16       R855      1
    C16       R856      1
    C16       R1006     1
    C16       R1007     1
    C16       R1157     1
    C16       R1158     1
    C16       R1308     1
    C16       R1309     1
    C16       R1459     1
    C16       R1460     1
    C16       R1610     1
    C16       R1611     1
    C16       R1761     1
    C16       R1762     1
    C16       R1912     1
    C16       R1913     1
    C16       R2061     1
    C16       R2062     1
    C16       R2212     1
    C16       R2213     1
    C16       R2363     1
    C16       R2364     1
    C16       R2514     1
    C16       R2515     1
    C16       R2666     1
    C16       R2667     1
    C16       R2815     1
    C16       R2816     1
    C16       R2966     1
    C16       R2967     1
    C16       R3186     1
    C16       R3187     1
    C16       R3210     1
    C16       R3211     1
    C16       R3258     1
    C16       R3259     1
    C16       R3282     -1
    C16       R3283     -1
    C16       R3288     -1
    C16       R3289     -1
    C16       R3294     -1
    C16       R3295     -1
    C16       R3300     -1
    C16       R3301     -1
    C16       R3306     -1
    C16       R3307     -1
    C16       R3312     -1
    C16       R3313     -1
    C16       R3318     -1
    C16       R3319     -1
    C17       R410      1
    C17       R411      1
    C17       R558      1
    C17       R559      1
    C17       R709      1
    C17       R710      1
    C17       R860      1
    C17       R861      1
    C17       R1011     1
    C17       R1012     1
    C17       R1162     1
    C17       R1163     1
    C17       R1313     1
    C17       R1314     1
    C17       R1464     1
    C17       R1465     1
    C17       R1615     1
    C17       R1616     1
    C17       R1766     1
    C17       R1767     1
    C17       R1917     1
    C17       R1918     1
    C17       R2066     1
    C17       R2067     1
    C17       R2217     1
    C17       R2218     1
    C17       R2368     1
    C17       R2369     1
    C17       R2519     1
    C17       R2520     1
    C17       R2671     1
    C17       R2672     1
    C17       R2820     1
    C17       R2821     1
    C17       R2971     1
    C17       R2972     1
    C17       R3216     1
    C17       R3217     1
    C17       R3288     1
    C17       R3289     1
    C17       R3324     -1
    C17       R3325     -1
    C17       R3330     -1
    C17       R3331     -1
    C17       R3336     -1
    C17       R3337     -1
    C17       R3342     -1
    C17       R3343     -1
    C17       R3366     1
    C17       R3367     1
    C18       R415      1
    C18       R416      1
    C18       R563      1
    C18       R564      1
    C18       R714      1
    C18       R715      1
    C18       R865      1
    C18       R866      1
    C18       R1016     1
    C18       R1017     1
    C18       R1167     1
    C18       R1168     1
    C18       R1318     1
    C18       R1319     1
    C18       R1469     1
    C18       R1470     1
    C18       R1620     1
    C18       R1621     1
    C18       R1771     1
    C18       R1772     1
    C18       R1922     1
    C18       R1923     1
    C18       R2071     1
    C18       R2072     1
    C18       R2222     1
    C18       R2223     1
    C18       R2373     1
    C18       R2374     1
    C18       R2524     1
    C18       R2525     1
    C18       R2676     1
    C18       R2677     1
    C18       R2825     1
    C18       R2826     1
    C18       R2976     1
    C18       R2977     1
    C18       R3192     1
    C18       R3193     1
    C18       R3222     1
    C18       R3223     1
    C18       R3264     1
    C18       R3265     1
    C18       R3294     1
    C18       R3295     1
    C18       R3324     1
    C18       R3325     1
    C18       R3348     -1
    C18       R3349     -1
    C18       R3354     -1
    C18       R3355     -1
    C18       R3360     -1
    C18       R3361     -1
    C18       R3372     1
    C18       R3373     1
    C18       R3390     1
    C18       R3391     1
    C19       R420      1
    C19       R421      1
    C19       R568      1
    C19       R569      1
    C19       R719      1
    C19       R720      1
    C19       R870      1
    C19       R871      1
    C19       R1021     1
    C19       R1022     1
    C19       R1172     1
    C19       R1173     1
    C19       R1323     1
    C19       R1324     1
    C19       R1474     1
    C19       R1475     1
    C19       R1625     1
    C19       R1626     1
    C19       R1776     1
    C19       R1777     1
    C19       R1927     1
    C19       R1928     1
    C19       R2076     1
    C19       R2077     1
    C19       R2227     1
    C19       R2228     1
    C19       R2378     1
    C19       R2379     1
    C19       R2529     1
    C19       R2530     1
    C19       R2681     1
    C19       R2682     1
    C19       R2830     1
    C19       R2831     1
    C19       R2981     1
    C19       R2982     1
    C19       R3228     1
    C19       R3229     1
    C19       R3300     1
    C19       R3301     1
    C19       R3330     1
    C19       R3331     1
    C19       R3366     -1
    C19       R3367     -1
    C19       R3372     -1
    C19       R3373     -1
    C19       R3378     -1
    C19       R3379     -1
    C19       R3384     -1
    C19       R3385     -1
    C20       R425      1
    C20       R426      1
    C20       R573      1
    C20       R574      1
    C20       R724      1
    C20       R725      1
    C20       R875      1
    C20       R876      1
    C20       R1026     1
    C20       R1027     1
    C20       R1177     1
    C20       R1178     1
    C20       R1328     1
    C20       R1329     1
    C20       R1479     1
    C20       R1480     1
    C20       R1630     1
    C20       R1631     1
    C20       R1781     1
    C20       R1782     1
    C20       R1932     1
    C20       R1933     1
    C20       R2081     1
    C20       R2082     1
    C20       R2232     1
    C20       R2233     1
    C20       R2383     1
    C20       R2384     1
    C20       R2534     1
    C20       R2535     1
    C20       R2686     1
    C20       R2687     1
    C20       R2835     1
    C20       R2836     1
    C20       R2986     1
    C20       R2987     1
    C20       R3198     1
    C20       R3199     1
    C20       R3234     1
    C20       R3235     1
    C20       R3270     1
    C20       R3271     1
    C20       R3306     1
    C20       R3307     1
    C20       R3336     1
    C20       R3337     1
    C20       R3348     1
    C20       R3349     1
    C20       R3378     1
    C20       R3379     1
    C20       R3390     -1
    C20       R3391     -1
    C20       R3396     -1
    C20       R3397     -1
    C20       R3402     -1
    C20       R3403     -1
    C21       R430      1
    C21       R431      1
    C21       R578      1
    C21       R579      1
    C21       R729      1
    C21       R730      1
    C21       R880      1
    C21       R881      1
    C21       R1031     1
    C21       R1032     1
    C21       R1182     1
    C21       R1183     1
    C21       R1333     1
    C21       R1334     1
    C21       R1484     1
    C21       R1485     1
    C21       R1635     1
    C21       R1636     1
    C21       R1786     1
    C21       R1787     1
    C21       R1937     1
    C21       R1938     1
    C21       R2086     1
    C21       R2087     1
    C21       R2237     1
    C21       R2238     1
    C21       R2388     1
    C21       R2389     1
    C21       R2539     1
    C21       R2540     1
    C21       R2691     1
    C21       R2692     1
    C21       R2840     1
    C21       R2841     1
    C21       R2991     1
    C21       R2992     1
    C21       R3240     1
    C21       R3241     1
    C21       R3312     1
    C21       R3313     1
    C21       R3354     1
    C21       R3355     1
    C21       R3396     1
    C21       R3397     1
    C21       R3408     -1
    C21       R3409     -1
    C22       R435      1
    C22       R436      1
    C22       R583      1
    C22       R584      1
    C22       R734      1
    C22       R735      1
    C22       R885      1
    C22       R886      1
    C22       R1036     1
    C22       R1037     1
    C22       R1187     1
    C22       R1188     1
    C22       R1338     1
    C22       R1339     1
    C22       R1489     1
    C22       R1490     1
    C22       R1640     1
    C22       R1641     1
    C22       R1791     1
    C22       R1792     1
    C22       R1942     1
    C22       R1943     1
    C22       R2091     1
    C22       R2092     1
    C22       R2242     1
    C22       R2243     1
    C22       R2393     1
    C22       R2394     1
    C22       R2544     1
    C22       R2545     1
    C22       R2696     1
    C22       R2697     1
    C22       R2845     1
    C22       R2846     1
    C22       R2996     1
    C22       R2997     1
    C22       R3204     1
    C22       R3205     1
    C22       R3246     1
    C22       R3247     1
    C22       R3276     1
    C22       R3277     1
    C22       R3318     1
    C22       R3319     1
    C22       R3342     1
    C22       R3343     1
    C22       R3360     1
    C22       R3361     1
    C22       R3384     1
    C22       R3385     1
    C22       R3402     1
    C22       R3403     1
    C22       R3408     1
    C22       R3409     1
    C23       R392      1
    C23       R393      1
    C23       R540      1
    C23       R541      1
    C23       R691      1
    C23       R692      1
    C23       R842      1
    C23       R843      1
    C23       R993      1
    C23       R994      1
    C23       R1144     1
    C23       R1145     1
    C23       R1295     1
    C23       R1296     1
    C23       R1446     1
    C23       R1447     1
    C23       R1597     1
    C23       R1598     1
    C23       R1748     1
    C23       R1749     1
    C23       R1899     1
    C23       R1900     1
    C23       R2048     1
    C23       R2049     1
    C23       R2199     1
    C23       R2200     1
    C23       R2350     1
    C23       R2351     1
    C23       R2501     1
    C23       R2502     1
    C23       R2653     1
    C23       R2654     1
    C23       R2802     1
    C23       R2803     1
    C23       R2953     1
    C23       R2954     1
    C23       R3176     -1
    C23       R3177     -1
    C23       R3182     -1
    C23       R3183     -1
    C23       R3188     -1
    C23       R3189     -1
    C23       R3194     -1
    C23       R3195     -1
    C23       R3200     -1
    C23       R3201     -1
    C23       R3206     -1
    C23       R3207     -1
    C24       R397      1
    C24       R398      1
    C24       R545      1
    C24       R546      1
    C24       R696      1
    C24       R697      1
    C24       R847      1
    C24       R848      1
    C24       R998      1
    C24       R999      1
    C24       R1149     1
    C24       R1150     1
    C24       R1300     1
    C24       R1301     1
    C24       R1451     1
    C24       R1452     1
    C24       R1602     1
    C24       R1603     1
    C24       R1753     1
    C24       R1754     1
    C24       R1904     1
    C24       R1905     1
    C24       R2053     1
    C24       R2054     1
    C24       R2204     1
    C24       R2205     1
    C24       R2355     1
    C24       R2356     1
    C24       R2506     1
    C24       R2507     1
    C24       R2658     1
    C24       R2659     1
    C24       R2807     1
    C24       R2808     1
    C24       R2958     1
    C24       R2959     1
    C24       R3176     1
    C24       R3177     1
    C24       R3212     -1
    C24       R3213     -1
    C24       R3218     -1
    C24       R3219     -1
    C24       R3224     -1
    C24       R3225     -1
    C24       R3230     -1
    C24       R3231     -1
    C24       R3236     -1
    C24       R3237     -1
    C24       R3242     -1
    C24       R3243     -1
    C24       R3248     -1
    C24       R3249     -1
    C24       R3254     1
    C24       R3255     1
    C24       R3284     1
    C24       R3285     1
    C25       R402      1
    C25       R403      1
    C25       R550      1
    C25       R551      1
    C25       R701      1
    C25       R702      1
    C25       R852      1
    C25       R853      1
    C25       R1003     1
    C25       R1004     1
    C25       R1154     1
    C25       R1155     1
    C25       R1305     1
    C25       R1306     1
    C25       R1456     1
    C25       R1457     1
    C25       R1607     1
    C25       R1608     1
    C25       R1758     1
    C25       R1759     1
    C25       R1909     1
    C25       R1910     1
    C25       R2058     1
    C25       R2059     1
    C25       R2209     1
    C25       R2210     1
    C25       R2360     1
    C25       R2361     1
    C25       R2511     1
    C25       R2512     1
    C25       R2663     1
    C25       R2664     1
    C25       R2812     1
    C25       R2813     1
    C25       R2963     1
    C25       R2964     1
    C25       R3182     1
    C25       R3183     1
    C25       R3254     -1
    C25       R3255     -1
    C25       R3260     -1
    C25       R3261     -1
    C25       R3266     -1
    C25       R3267     -1
    C25       R3272     -1
    C25       R3273     -1
    C25       R3278     -1
    C25       R3279     -1
    C26       R407      1
    C26       R408      1
    C26       R555      1
    C26       R556      1
    C26       R706      1
    C26       R707      1
    C26       R857      1
    C26       R858      1
    C26       R1008     1
    C26       R1009     1
    C26       R1159     1
    C26       R1160     1
    C26       R1310     1
    C26       R1311     1
    C26       R1461     1
    C26       R1462     1
    C26       R1612     1
    C26       R1613     1
    C26       R1763     1
    C26       R1764     1
    C26       R1914     1
    C26       R1915     1
    C26       R2063     1
    C26       R2064     1
    C26       R2214     1
    C26       R2215     1
    C26       R2365     1
    C26       R2366     1
    C26       R2516     1
    C26       R2517     1
    C26       R2668     1
    C26       R2669     1
    C26       R2817     1
    C26       R2818     1
    C26       R2968     1
    C26       R2969     1
    C26       R3188     1
    C26       R3189     1
    C26       R3212     1
    C26       R3213     1
    C26       R3260     1
    C26       R3261     1
    C26       R3284     -1
    C26       R3285     -1
    C26       R3290     -1
    C26       R3291     -1
    C26       R3296     -1
    C26       R3297     -1
    C26       R3302     -1
    C26       R3303     -1
    C26       R3308     -1
    C26       R3309     -1
    C26       R3314     -1
    C26       R3315     -1
    C26       R3320     -1
    C26       R3321     -1
    C27       R412      1
    C27       R413      1
    C27       R560      1
    C27       R561      1
    C27       R711      1
    C27       R712      1
    C27       R862      1
    C27       R863      1
    C27       R1013     1
    C27       R1014     1
    C27       R1164     1
    C27       R1165     1
    C27       R1315     1
    C27       R1316     1
    C27       R1466     1
    C27       R1467     1
    C27       R1617     1
    C27       R1618     1
    C27       R1768     1
    C27       R1769     1
    C27       R1919     1
    C27       R1920     1
    C27       R2068     1
    C27       R2069     1
    C27       R2219     1
    C27       R2220     1
    C27       R2370     1
    C27       R2371     1
    C27       R2521     1
    C27       R2522     1
    C27       R2673     1
    C27       R2674     1
    C27       R2822     1
    C27       R2823     1
    C27       R2973     1
    C27       R2974     1
    C27       R3218     1
    C27       R3219     1
    C27       R3290     1
    C27       R3291     1
    C27       R3326     -1
    C27       R3327     -1
    C27       R3332     -1
    C27       R3333     -1
    C27       R3338     -1
    C27       R3339     -1
    C27       R3344     -1
    C27       R3345     -1
    C27       R3368     1
    C27       R3369     1
    C28       R417      1
    C28       R418      1
    C28       R565      1
    C28       R566      1
    C28       R716      1
    C28       R717      1
    C28       R867      1
    C28       R868      1
    C28       R1018     1
    C28       R1019     1
    C28       R1169     1
    C28       R1170     1
    C28       R1320     1
    C28       R1321     1
    C28       R1471     1
    C28       R1472     1
    C28       R1622     1
    C28       R1623     1
    C28       R1773     1
    C28       R1774     1
    C28       R1924     1
    C28       R1925     1
    C28       R2073     1
    C28       R2074     1
    C28       R2224     1
    C28       R2225     1
    C28       R2375     1
    C28       R2376     1
    C28       R2526     1
    C28       R2527     1
    C28       R2678     1
    C28       R2679     1
    C28       R2827     1
    C28       R2828     1
    C28       R2978     1
    C28       R2979     1
    C28       R3194     1
    C28       R3195     1
    C28       R3224     1
    C28       R3225     1
    C28       R3266     1
    C28       R3267     1
    C28       R3296     1
    C28       R3297     1
    C28       R3326     1
    C28       R3327     1
    C28       R3350     -1
    C28       R3351     -1
    C28       R3356     -1
    C28       R3357     -1
    C28       R3362     -1
    C28       R3363     -1
    C28       R3374     1
    C28       R3375     1
    C28       R3392     1
    C28       R3393     1
    C29       R422      1
    C29       R423      1
    C29       R570      1
    C29       R571      1
    C29       R721      1
    C29       R722      1
    C29       R872      1
    C29       R873      1
    C29       R1023     1
    C29       R1024     1
    C29       R1174     1
    C29       R1175     1
    C29       R1325     1
    C29       R1326     1
    C29       R1476     1
    C29       R1477     1
    C29       R1627     1
    C29       R1628     1
    C29       R1778     1
    C29       R1779     1
    C29       R1929     1
    C29       R1930     1
    C29       R2078     1
    C29       R2079     1
    C29       R2229     1
    C29       R2230     1
    C29       R2380     1
    C29       R2381     1
    C29       R2531     1
    C29       R2532     1
    C29       R2683     1
    C29       R2684     1
    C29       R2832     1
    C29       R2833     1
    C29       R2983     1
    C29       R2984     1
    C29       R3230     1
    C29       R3231     1
    C29       R3302     1
    C29       R3303     1
    C29       R3332     1
    C29       R3333     1
    C29       R3368     -1
    C29       R3369     -1
    C29       R3374     -1
    C29       R3375     -1
    C29       R3380     -1
    C29       R3381     -1
    C29       R3386     -1
    C29       R3387     -1
    C30       R427      1
    C30       R428      1
    C30       R575      1
    C30       R576      1
    C30       R726      1
    C30       R727      1
    C30       R877      1
    C30       R878      1
    C30       R1028     1
    C30       R1029     1
    C30       R1179     1
    C30       R1180     1
    C30       R1330     1
    C30       R1331     1
    C30       R1481     1
    C30       R1482     1
    C30       R1632     1
    C30       R1633     1
    C30       R1783     1
    C30       R1784     1
    C30       R1934     1
    C30       R1935     1
    C30       R2083     1
    C30       R2084     1
    C30       R2234     1
    C30       R2235     1
    C30       R2385     1
    C30       R2386     1
    C30       R2536     1
    C30       R2537     1
    C30       R2688     1
    C30       R2689     1
    C30       R2837     1
    C30       R2838     1
    C30       R2988     1
    C30       R2989     1
    C30       R3200     1
    C30       R3201     1
    C30       R3236     1
    C30       R3237     1
    C30       R3272     1
    C30       R3273     1
    C30       R3308     1
    C30       R3309     1
    C30       R3338     1
    C30       R3339     1
    C30       R3350     1
    C30       R3351     1
    C30       R3380     1
    C30       R3381     1
    C30       R3392     -1
    C30       R3393     -1
    C30       R3398     -1
    C30       R3399     -1
    C30       R3404     -1
    C30       R3405     -1
    C31       R432      1
    C31       R433      1
    C31       R580      1
    C31       R581      1
    C31       R731      1
    C31       R732      1
    C31       R882      1
    C31       R883      1
    C31       R1033     1
    C31       R1034     1
    C31       R1184     1
    C31       R1185     1
    C31       R1335     1
    C31       R1336     1
    C31       R1486     1
    C31       R1487     1
    C31       R1637     1
    C31       R1638     1
    C31       R1788     1
    C31       R1789     1
    C31       R1939     1
    C31       R1940     1
    C31       R2088     1
    C31       R2089     1
    C31       R2239     1
    C31       R2240     1
    C31       R2390     1
    C31       R2391     1
    C31       R2541     1
    C31       R2542     1
    C31       R2693     1
    C31       R2694     1
    C31       R2842     1
    C31       R2843     1
    C31       R2993     1
    C31       R2994     1
    C31       R3242     1
    C31       R3243     1
    C31       R3314     1
    C31       R3315     1
    C31       R3356     1
    C31       R3357     1
    C31       R3398     1
    C31       R3399     1
    C31       R3410     -1
    C31       R3411     -1
    C32       R437      1
    C32       R438      1
    C32       R585      1
    C32       R586      1
    C32       R736      1
    C32       R737      1
    C32       R887      1
    C32       R888      1
    C32       R1038     1
    C32       R1039     1
    C32       R1189     1
    C32       R1190     1
    C32       R1340     1
    C32       R1341     1
    C32       R1491     1
    C32       R1492     1
    C32       R1642     1
    C32       R1643     1
    C32       R1793     1
    C32       R1794     1
    C32       R1944     1
    C32       R1945     1
    C32       R2093     1
    C32       R2094     1
    C32       R2244     1
    C32       R2245     1
    C32       R2395     1
    C32       R2396     1
    C32       R2546     1
    C32       R2547     1
    C32       R2698     1
    C32       R2699     1
    C32       R2847     1
    C32       R2848     1
    C32       R2998     1
    C32       R2999     1
    C32       R3206     1
    C32       R3207     1
    C32       R3248     1
    C32       R3249     1
    C32       R3278     1
    C32       R3279     1
    C32       R3320     1
    C32       R3321     1
    C32       R3344     1
    C32       R3345     1
    C32       R3362     1
    C32       R3363     1
    C32       R3386     1
    C32       R3387     1
    C32       R3404     1
    C32       R3405     1
    C32       R3410     1
    C32       R3411     1
    C33       R478      1
    C33       R488      -1
    C33       R629      1
    C33       R639      -1
    C33       R780      1
    C33       R790      -1
    C33       R931      1
    C33       R941      -1
    C33       R1082     1
    C33       R1092     -1
    C33       R1233     1
    C33       R1243     -1
    C33       R1384     1
    C33       R1394     -1
    C33       R1535     1
    C33       R1545     -1
    C33       R1686     1
    C33       R1696     -1
    C33       R1837     1
    C33       R1847     -1
    C33       R1986     1
    C33       R1996     -1
    C33       R2137     1
    C33       R2147     -1
    C33       R2288     1
    C33       R2298     -1
    C33       R2439     1
    C33       R2449     -1
    C33       R2590     1
    C33       R2600     -1
    C33       R2740     1
    C33       R2750     -1
    C33       R2891     1
    C33       R2901     -1
    C33       R3042     1
    C33       R3052     -1
    C33       R3178     -1
    C33       R3184     -1
    C33       R3190     -1
    C33       R3196     -1
    C33       R3202     -1
    C33       R3208     -1
    C33       R3416     -1
    C34       R479      1
    C34       R489      -1
    C34       R630      1
    C34       R640      -1
    C34       R781      1
    C34       R791      -1
    C34       R932      1
    C34       R942      -1
    C34       R1083     1
    C34       R1093     -1
    C34       R1234     1
    C34       R1244     -1
    C34       R1385     1
    C34       R1395     -1
    C34       R1536     1
    C34       R1546     -1
    C34       R1687     1
    C34       R1697     -1
    C34       R1838     1
    C34       R1848     -1
    C34       R1987     1
    C34       R1997     -1
    C34       R2138     1
    C34       R2148     -1
    C34       R2289     1
    C34       R2299     -1
    C34       R2440     1
    C34       R2450     -1
    C34       R2591     1
    C34       R2601     -1
    C34       R2741     1
    C34       R2751     -1
    C34       R2892     1
    C34       R2902     -1
    C34       R3043     1
    C34       R3053     -1
    C34       R3178     1
    C34       R3214     -1
    C34       R3220     -1
    C34       R3226     -1
    C34       R3232     -1
    C34       R3238     -1
    C34       R3244     -1
    C34       R3250     -1
    C34       R3256     1
    C34       R3286     1
    C34       R3416     1
    C35       R480      1
    C35       R490      -1
    C35       R631      1
    C35       R641      -1
    C35       R782      1
    C35       R792      -1
    C35       R933      1
    C35       R943      -1
    C35       R1084     1
    C35       R1094     -1
    C35       R1235     1
    C35       R1245     -1
    C35       R1386     1
    C35       R1396     -1
    C35       R1537     1
    C35       R1547     -1
    C35       R1688     1
    C35       R1698     -1
    C35       R1839     1
    C35       R1849     -1
    C35       R1988     1
    C35       R1998     -1
    C35       R2139     1
    C35       R2149     -1
    C35       R2290     1
    C35       R2300     -1
    C35       R2441     1
    C35       R2451     -1
    C35       R2592     1
    C35       R2602     -1
    C35       R2742     1
    C35       R2752     -1
    C35       R2893     1
    C35       R2903     -1
    C35       R3044     1
    C35       R3054     -1
    C35       R3184     1
    C35       R3256     -1
    C35       R3262     -1
    C35       R3268     -1
    C35       R3274     -1
    C35       R3280     -1
    C35       R3420     -1
    C36       R481      1
    C36       R491      -1
    C36       R632      1
    C36       R642      -1
    C36       R783      1
    C36       R793      -1
    C36       R934      1
    C36       R944      -1
    C36       R1085     1
    C36       R1095     -1
    C36       R1236     1
    C36       R1246     -1
    C36       R1387     1
    C36       R1397     -1
    C36       R1538     1
    C36       R1548     -1
    C36       R1689     1
    C36       R1699     -1
    C36       R1840     1
    C36       R1850     -1
    C36       R1989     1
    C36       R1999     -1
    C36       R2140     1
    C36       R2150     -1
    C36       R2291     1
    C36       R2301     -1
    C36       R2442     1
    C36       R2452     -1
    C36       R2593     1
    C36       R2603     -1
    C36       R2743     1
    C36       R2753     -1
    C36       R2894     1
    C36       R2904     -1
    C36       R3045     1
    C36       R3055     -1
    C36       R3190     1
    C36       R3214     1
    C36       R3262     1
    C36       R3286     -1
    C36       R3292     -1
    C36       R3298     -1
    C36       R3304     -1
    C36       R3310     -1
    C36       R3316     -1
    C36       R3322     -1
    C36       R3420     1
    C37       R482      1
    C37       R492      -1
    C37       R633      1
    C37       R643      -1
    C37       R784      1
    C37       R794      -1
    C37       R935      1
    C37       R945      -1
    C37       R1086     1
    C37       R1096     -1
    C37       R1237     1
    C37       R1247     -1
    C37       R1388     1
    C37       R1398     -1
    C37       R1539     1
    C37       R1549     -1
    C37       R1690     1
    C37       R1700     -1
    C37       R1841     1
    C37       R1851     -1
    C37       R1990     1
    C37       R2000     -1
    C37       R2141     1
    C37       R2151     -1
    C37       R2292     1
    C37       R2302     -1
    C37       R2443     1
    C37       R2453     -1
    C37       R2594     1
    C37       R2604     -1
    C37       R2744     1
    C37       R2754     -1
    C37       R2895     1
    C37       R2905     -1
    C37       R3046     1
    C37       R3056     -1
    C37       R3220     1
    C37       R3292     1
    C37       R3328     -1
    C37       R3334     -1
    C37       R3340     -1
    C37       R3346     -1
    C37       R3370     1
    C37       R3424     -1
    C38       R483      1
    C38       R493      -1
    C38       R634      1
    C38       R644      -1
    C38       R785      1
    C38       R795      -1
    C38       R936      1
    C38       R946      -1
    C38       R1087     1
    C38       R1097     -1
    C38       R1238     1
    C38       R1248     -1
    C38       R1389     1
    C38       R1399     -1
    C38       R1540     1
    C38       R1550     -1
    C38       R1691     1
    C38       R1701     -1
    C38       R1842     1
    C38       R1852     -1
    C38       R1991     1
    C38       R2001     -1
    C38       R2142     1
    C38       R2152     -1
    C38       R2293     1
    C38       R2303     -1
    C38       R2444     1
    C38       R2454     -1
    C38       R2595     1
    C38       R2605     -1
    C38       R2745     1
    C38       R2755     -1
    C38       R2896     1
    C38       R2906     -1
    C38       R3047     1
    C38       R3057     -1
    C38       R3196     1
    C38       R3226     1
    C38       R3268     1
    C38       R3298     1
    C38       R3328     1
    C38       R3352     -1
    C38       R3358     -1
    C38       R3364     -1
    C38       R3376     1
    C38       R3394     1
    C38       R3424     1
    C39       R484      1
    C39       R494      -1
    C39       R635      1
    C39       R645      -1
    C39       R786      1
    C39       R796      -1
    C39       R937      1
    C39       R947      -1
    C39       R1088     1
    C39       R1098     -1
    C39       R1239     1
    C39       R1249     -1
    C39       R1390     1
    C39       R1400     -1
    C39       R1541     1
    C39       R1551     -1
    C39       R1692     1
    C39       R1702     -1
    C39       R1843     1
    C39       R1853     -1
    C39       R1992     1
    C39       R2002     -1
    C39       R2143     1
    C39       R2153     -1
    C39       R2294     1
    C39       R2304     -1
    C39       R2445     1
    C39       R2455     -1
    C39       R2596     1
    C39       R2606     -1
    C39       R2746     1
    C39       R2756     -1
    C39       R2897     1
    C39       R2907     -1
    C39       R3048     1
    C39       R3058     -1
    C39       R3232     1
    C39       R3304     1
    C39       R3334     1
    C39       R3370     -1
    C39       R3376     -1
    C39       R3382     -1
    C39       R3388     -1
    C39       R3428     -1
    C40       R485      1
    C40       R495      -1
    C40       R636      1
    C40       R646      -1
    C40       R787      1
    C40       R797      -1
    C40       R938      1
    C40       R948      -1
    C40       R1089     1
    C40       R1099     -1
    C40       R1240     1
    C40       R1250     -1
    C40       R1391     1
    C40       R1401     -1
    C40       R1542     1
    C40       R1552     -1
    C40       R1693     1
    C40       R1703     -1
    C40       R1844     1
    C40       R1854     -1
    C40       R1993     1
    C40       R2003     -1
    C40       R2144     1
    C40       R2154     -1
    C40       R2295     1
    C40       R2305     -1
    C40       R2446     1
    C40       R2456     -1
    C40       R2597     1
    C40       R2607     -1
    C40       R2747     1
    C40       R2757     -1
    C40       R2898     1
    C40       R2908     -1
    C40       R3049     1
    C40       R3059     -1
    C40       R3202     1
    C40       R3238     1
    C40       R3274     1
    C40       R3310     1
    C40       R3340     1
    C40       R3352     1
    C40       R3382     1
    C40       R3394     -1
    C40       R3400     -1
    C40       R3406     -1
    C40       R3428     1
    C41       R486      1
    C41       R496      -1
    C41       R637      1
    C41       R647      -1
    C41       R788      1
    C41       R798      -1
    C41       R939      1
    C41       R949      -1
    C41       R1090     1
    C41       R1100     -1
    C41       R1241     1
    C41       R1251     -1
    C41       R1392     1
    C41       R1402     -1
    C41       R1543     1
    C41       R1553     -1
    C41       R1694     1
    C41       R1704     -1
    C41       R1845     1
    C41       R1855     -1
    C41       R1994     1
    C41       R2004     -1
    C41       R2145     1
    C41       R2155     -1
    C41       R2296     1
    C41       R2306     -1
    C41       R2447     1
    C41       R2457     -1
    C41       R2598     1
    C41       R2608     -1
    C41       R2748     1
    C41       R2758     -1
    C41       R2899     1
    C41       R2909     -1
    C41       R3050     1
    C41       R3060     -1
    C41       R3244     1
    C41       R3316     1
    C41       R3358     1
    C41       R3400     1
    C41       R3412     -1
    C41       R3432     -1
    C42       R487      1
    C42       R497      -1
    C42       R638      1
    C42       R648      -1
    C42       R789      1
    C42       R799      -1
    C42       R940      1
    C42       R950      -1
    C42       R1091     1
    C42       R1101     -1
    C42       R1242     1
    C42       R1252     -1
    C42       R1393     1
    C42       R1403     -1
    C42       R1544     1
    C42       R1554     -1
    C42       R1695     1
    C42       R1705     -1
    C42       R1846     1
    C42       R1856     -1
    C42       R1995     1
    C42       R2005     -1
    C42       R2146     1
    C42       R2156     -1
    C42       R2297     1
    C42       R2307     -1
    C42       R2448     1
    C42       R2458     -1
    C42       R2599     1
    C42       R2609     -1
    C42       R2749     1
    C42       R2759     -1
    C42       R2900     1
    C42       R2910     -1
    C42       R3051     1
    C42       R3061     -1
    C42       R3208     1
    C42       R3250     1
    C42       R3280     1
    C42       R3322     1
    C42       R3346     1
    C42       R3364     1
    C42       R3388     1
    C42       R3406     1
    C42       R3412     1
    C42       R3432     1
    e1_b1_0_weight[0]  OBJ       0
    e1_b1_0_weight[1]  OBJ       0
    e1_b1_0_weight[2]  OBJ       0
    e1_b1_0_weight[3]  OBJ       0
    e1_b1_0_volume[0]  OBJ       0
    e1_b1_0_volume[1]  OBJ       0
    e1_b1_0_volume[2]  OBJ       0
    e1_b1_0_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C87       OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b1_1_weight[0]  OBJ       0
    e1_b1_1_weight[1]  OBJ       0
    e1_b1_1_weight[2]  OBJ       0
    e1_b1_1_weight[3]  OBJ       0
    e1_b1_1_volume[0]  OBJ       0
    e1_b1_1_volume[1]  OBJ       0
    e1_b1_1_volume[2]  OBJ       0
    e1_b1_1_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C132      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b1_2_weight[0]  OBJ       0
    e1_b1_2_weight[1]  OBJ       0
    e1_b1_2_weight[2]  OBJ       0
    e1_b1_2_weight[3]  OBJ       0
    e1_b1_2_volume[0]  OBJ       0
    e1_b1_2_volume[1]  OBJ       0
    e1_b1_2_volume[2]  OBJ       0
    e1_b1_2_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C177      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b2_0_weight[0]  OBJ       0
    e1_b2_0_weight[1]  OBJ       0
    e1_b2_0_weight[2]  OBJ       0
    e1_b2_0_weight[3]  OBJ       0
    e1_b2_0_volume[0]  OBJ       0
    e1_b2_0_volume[1]  OBJ       0
    e1_b2_0_volume[2]  OBJ       0
    e1_b2_0_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C222      OBJ       0
    C223      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b2_1_weight[0]  OBJ       0
    e1_b2_1_weight[1]  OBJ       0
    e1_b2_1_weight[2]  OBJ       0
    e1_b2_1_weight[3]  OBJ       0
    e1_b2_1_volume[0]  OBJ       0
    e1_b2_1_volume[1]  OBJ       0
    e1_b2_1_volume[2]  OBJ       0
    e1_b2_1_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C268      OBJ       0
    C269      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b2_2_weight[0]  OBJ       0
    e1_b2_2_weight[1]  OBJ       0
    e1_b2_2_weight[2]  OBJ       0
    e1_b2_2_weight[3]  OBJ       0
    e1_b2_2_volume[0]  OBJ       0
    e1_b2_2_volume[1]  OBJ       0
    e1_b2_2_volume[2]  OBJ       0
    e1_b2_2_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C314      OBJ       0
    C315      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b3_0_weight[0]  OBJ       0
    e1_b3_0_weight[1]  OBJ       0
    e1_b3_0_weight[2]  OBJ       0
    e1_b3_0_weight[3]  OBJ       0
    e1_b3_0_volume[0]  OBJ       0
    e1_b3_0_volume[1]  OBJ       0
    e1_b3_0_volume[2]  OBJ       0
    e1_b3_0_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C360      OBJ       0
    C361      OBJ       0
    C362      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b3_1_weight[0]  OBJ       0
    e1_b3_1_weight[1]  OBJ       0
    e1_b3_1_weight[2]  OBJ       0
    e1_b3_1_weight[3]  OBJ       0
    e1_b3_1_volume[0]  OBJ       0
    e1_b3_1_volume[1]  OBJ       0
    e1_b3_1_volume[2]  OBJ       0
    e1_b3_1_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C407      OBJ       0
    C408      OBJ       0
    C409      OBJ       0
    MARKER    'MARKER'                 'INTEND'
    e1_b3_2_weight[0]  OBJ       0
    e1_b3_2_weight[1]  OBJ       0
    e1_b3_2_weight[2]  OBJ       0
    e1_b3_2_weight[3]  OBJ       0
    e1_b3_2_volume[0]  OBJ       0
    e1_b3_2_volume[1]  OBJ       0
    e1_b3_2_volume[2]  OBJ       0
    e1_b3_2_volume[3]  OBJ       0
    MARKER    'MARKER'                 'INTORG'
    C454      OBJ       0
    C455      OBJ       0
    C456      OBJ       0
    pickup_return_C24_order  R327      1
    pickup_return_C24_order  R328      1
    pickup_return_C24_order  R329      1
    pickup_return_C24_order  R331      1
    pickup_return_C24_order  R332      1
    pickup_return_C24_order  R464      1
    pickup_return_C24_order  R465      1
    pickup_return_C24_order  R615      1
    pickup_return_C24_order  R616      1
    pickup_return_C24_order  R766      1
    pickup_return_C24_order  R767      1
    pickup_return_C24_order  R917      1
    pickup_return_C24_order  R918      1
    pickup_return_C24_order  R1068     1
    pickup_return_C24_order  R1069     1
    pickup_return_C24_order  R1219     1
    pickup_return_C24_order  R1220     1
    pickup_return_C24_order  R1370     1
    pickup_return_C24_order  R1371     1
    pickup_return_C24_order  R1521     1
    pickup_return_C24_order  R1522     1
    pickup_return_C24_order  R1672     1
    pickup_return_C24_order  R1673     1
    pickup_return_C24_order  R1823     1
    pickup_return_C24_order  R1824     1
    pickup_return_C24_order  R1972     1
    pickup_return_C24_order  R1973     1
    pickup_return_C24_order  R2123     1
    pickup_return_C24_order  R2124     1
    pickup_return_C24_order  R2274     1
    pickup_return_C24_order  R2275     1
    pickup_return_C24_order  R2425     1
    pickup_return_C24_order  R2426     1
    pickup_return_C24_order  R2576     1
    pickup_return_C24_order  R2577     1
    pickup_return_C24_order  R2726     1
    pickup_return_C24_order  R2727     1
    pickup_return_C24_order  R2877     1
    pickup_return_C24_order  R2878     1
    pickup_return_C24_order  R3028     1
    pickup_return_C24_order  R3029     1
    eligible_C24_order_b1  R328      31500
    eligible_C24_order_b1  R329      4938
    eligible_C24_order_b1  R330      1
    eligible_C24_order_b1  R333      -1
    eligible_C24_order_b2  R331      17100
    eligible_C24_order_b2  R332      19338
    eligible_C24_order_b2  R333      1
    pickup_return_C34_order  R334      1
    pickup_return_C34_order  R335      1
    pickup_return_C34_order  R336      1
    pickup_return_C34_order  R338      1
    pickup_return_C34_order  R339      1
    pickup_return_C34_order  R467      1
    pickup_return_C34_order  R468      1
    pickup_return_C34_order  R618      1
    pickup_return_C34_order  R619      1
    pickup_return_C34_order  R769      1
    pickup_return_C34_order  R770      1
    pickup_return_C34_order  R920      1
    pickup_return_C34_order  R921      1
    pickup_return_C34_order  R1071     1
    pickup_return_C34_order  R1072     1
    pickup_return_C34_order  R1222     1
    pickup_return_C34_order  R1223     1
    pickup_return_C34_order  R1373     1
    pickup_return_C34_order  R1374     1
    pickup_return_C34_order  R1524     1
    pickup_return_C34_order  R1525     1
    pickup_return_C34_order  R1675     1
    pickup_return_C34_order  R1676     1
    pickup_return_C34_order  R1826     1
    pickup_return_C34_order  R1827     1
    pickup_return_C34_order  R1975     1
    pickup_return_C34_order  R1976     1
    pickup_return_C34_order  R2126     1
    pickup_return_C34_order  R2127     1
    pickup_return_C34_order  R2277     1
    pickup_return_C34_order  R2278     1
    pickup_return_C34_order  R2428     1
    pickup_return_C34_order  R2429     1
    pickup_return_C34_order  R2579     1
    pickup_return_C34_order  R2580     1
    pickup_return_C34_order  R2729     1
    pickup_return_C34_order  R2730     1
    pickup_return_C34_order  R2880     1
    pickup_return_C34_order  R2881     1
    pickup_return_C34_order  R3031     1
    pickup_return_C34_order  R3032     1
    eligible_C34_order_b1  R335      31500
    eligible_C34_order_b1  R336      2032
    eligible_C34_order_b1  R337      1
    eligible_C34_order_b1  R340      -1
    eligible_C34_order_b2  R338      17100
    eligible_C34_order_b2  R339      16432
    eligible_C34_order_b2  R340      1
    pickup_return_C95_order  R341      1
    pickup_return_C95_order  R342      1
    pickup_return_C95_order  R343      1
    pickup_return_C95_order  R470      1
    pickup_return_C95_order  R471      1
    pickup_return_C95_order  R621      1
    pickup_return_C95_order  R622      1
    pickup_return_C95_order  R772      1
    pickup_return_C95_order  R773      1
    pickup_return_C95_order  R923      1
    pickup_return_C95_order  R924      1
    pickup_return_C95_order  R1074     1
    pickup_return_C95_order  R1075     1
    pickup_return_C95_order  R1225     1
    pickup_return_C95_order  R1226     1
    pickup_return_C95_order  R1376     1
    pickup_return_C95_order  R1377     1
    pickup_return_C95_order  R1527     1
    pickup_return_C95_order  R1528     1
    pickup_return_C95_order  R1678     1
    pickup_return_C95_order  R1679     1
    pickup_return_C95_order  R1829     1
    pickup_return_C95_order  R1830     1
    pickup_return_C95_order  R1978     1
    pickup_return_C95_order  R1979     1
    pickup_return_C95_order  R2129     1
    pickup_return_C95_order  R2130     1
    pickup_return_C95_order  R2280     1
    pickup_return_C95_order  R2281     1
    pickup_return_C95_order  R2431     1
    pickup_return_C95_order  R2432     1
    pickup_return_C95_order  R2582     1
    pickup_return_C95_order  R2583     1
    pickup_return_C95_order  R2732     1
    pickup_return_C95_order  R2733     1
    pickup_return_C95_order  R2883     1
    pickup_return_C95_order  R2884     1
    pickup_return_C95_order  R3034     1
    pickup_return_C95_order  R3035     1
    eligible_C95_order_b2  R342      17100
    eligible_C95_order_b2  R343      4150
    eligible_C95_order_b2  R344      1
    pickup_return_C73_order  R345      1
    pickup_return_C73_order  R346      1
    pickup_return_C73_order  R347      1
    pickup_return_C73_order  R473      1
    pickup_return_C73_order  R474      1
    pickup_return_C73_order  R624      1
    pickup_return_C73_order  R625      1
    pickup_return_C73_order  R775      1
    pickup_return_C73_order  R776      1
    pickup_return_C73_order  R926      1
    pickup_return_C73_order  R927      1
    pickup_return_C73_order  R1077     1
    pickup_return_C73_order  R1078     1
    pickup_return_C73_order  R1228     1
    pickup_return_C73_order  R1229     1
    pickup_return_C73_order  R1379     1
    pickup_return_C73_order  R1380     1
    pickup_return_C73_order  R1530     1
    pickup_return_C73_order  R1531     1
    pickup_return_C73_order  R1681     1
    pickup_return_C73_order  R1682     1
    pickup_return_C73_order  R1832     1
    pickup_return_C73_order  R1833     1
    pickup_return_C73_order  R1981     1
    pickup_return_C73_order  R1982     1
    pickup_return_C73_order  R2132     1
    pickup_return_C73_order  R2133     1
    pickup_return_C73_order  R2283     1
    pickup_return_C73_order  R2284     1
    pickup_return_C73_order  R2434     1
    pickup_return_C73_order  R2435     1
    pickup_return_C73_order  R2585     1
    pickup_return_C73_order  R2586     1
    pickup_return_C73_order  R2735     1
    pickup_return_C73_order  R2736     1
    pickup_return_C73_order  R2886     1
    pickup_return_C73_order  R2887     1
    pickup_return_C73_order  R3037     1
    pickup_return_C73_order  R3038     1
    eligible_C73_order_b2  R346      17100
    eligible_C73_order_b2  R347      2370
    eligible_C73_order_b2  R348      1
    pickup_return_C63_order  R349      1
    pickup_return_C63_order  R476      1
    pickup_return_C63_order  R477      1
    pickup_return_C63_order  R627      1
    pickup_return_C63_order  R628      1
    pickup_return_C63_order  R778      1
    pickup_return_C63_order  R779      1
    pickup_return_C63_order  R929      1
    pickup_return_C63_order  R930      1
    pickup_return_C63_order  R1080     1
    pickup_return_C63_order  R1081     1
    pickup_return_C63_order  R1231     1
    pickup_return_C63_order  R1232     1
    pickup_return_C63_order  R1382     1
    pickup_return_C63_order  R1383     1
    pickup_return_C63_order  R1533     1
    pickup_return_C63_order  R1534     1
    pickup_return_C63_order  R1684     1
    pickup_return_C63_order  R1685     1
    pickup_return_C63_order  R1835     1
    pickup_return_C63_order  R1836     1
    pickup_return_C63_order  R1984     1
    pickup_return_C63_order  R1985     1
    pickup_return_C63_order  R2135     1
    pickup_return_C63_order  R2136     1
    pickup_return_C63_order  R2286     1
    pickup_return_C63_order  R2287     1
    pickup_return_C63_order  R2437     1
    pickup_return_C63_order  R2438     1
    pickup_return_C63_order  R2588     1
    pickup_return_C63_order  R2589     1
    pickup_return_C63_order  R2738     1
    pickup_return_C63_order  R2739     1
    pickup_return_C63_order  R2889     1
    pickup_return_C63_order  R2890     1
    pickup_return_C63_order  R3040     1
    pickup_return_C63_order  R3041     1
    e2_S4_0_0_used  R350      -75600
    e2_S4_0_0_used  R351      -75600
    e2_S4_0_0_used  R352      -28800
    e2_S4_0_0_used  R353      -1
    e2_S4_0_0_used  R354      -1
    e2_S4_0_0_used  R355      -180
    e2_S4_0_0_used  R356      -6
    e2_S4_0_0_used  R357      -180
    e2_S4_0_0_used  R358      -6
    e2_S4_0_0_used  R361      -1
    e2_S4_0_0_used  R364      -1
    e2_S4_0_0_used  R367      -1
    e2_S4_0_0_used  R370      -1
    e2_S4_0_0_used  R373      -1
    e2_S4_0_0_used  R376      -1
    e2_S4_0_0_used  R379      -1
    e2_S4_0_0_used  R382      -1
    e2_S4_0_0_used  R385      -1
    e2_S4_0_0_used  R388      -1
    e2_S4_0_0_used  R449      -75540
    e2_S4_0_0_used  R450      -1
    e2_S4_0_0_used  R598      -1
    e2_S4_0_0_used  R1956     -1
    e2_S4_0_0_used  R2610     -1
    e2_S4_0_0_start  R350      1
    e2_S4_0_0_start  R352      1
    e2_S4_0_0_start  R389      -1
    e2_S4_0_0_start  R394      -1
    e2_S4_0_0_start  R399      -1
    e2_S4_0_0_start  R404      -1
    e2_S4_0_0_start  R409      -1
    e2_S4_0_0_start  R414      -1
    e2_S4_0_0_start  R419      -1
    e2_S4_0_0_start  R424      -1
    e2_S4_0_0_start  R429      -1
    e2_S4_0_0_start  R434      -1
    e2_S4_0_0_start  R452      1
    e2_S4_0_0_start  R456      1
    e2_S4_0_0_start  R460      1
    e2_S4_0_0_end  R351      1
    e2_S4_0_0_end  R439      1
    e2_S4_0_0_end  R440      1
    e2_S4_0_0_end  R441      1
    e2_S4_0_0_end  R442      1
    e2_S4_0_0_end  R443      1
    e2_S4_0_0_end  R444      1
    e2_S4_0_0_end  R445      1
    e2_S4_0_0_end  R446      1
    e2_S4_0_0_end  R447      1
    e2_S4_0_0_end  R448      1
    e2_S4_0_0_end  R449      1
    e2_S4_0_0_end  R464      -1
    e2_S4_0_0_end  R465      -1
    e2_S4_0_0_end  R467      -1
    e2_S4_0_0_end  R468      -1
    e2_S4_0_0_end  R470      -1
    e2_S4_0_0_end  R471      -1
    e2_S4_0_0_end  R473      -1
    e2_S4_0_0_end  R474      -1
    e2_S4_0_0_end  R476      -1
    e2_S4_0_0_end  R477      -1
    e2_S4_0_0_end  R601      -1
    e2_S4_0_0_visit[0]  R355      15
    e2_S4_0_0_visit[0]  R356      1
    e2_S4_0_0_visit[0]  R359      -1
    e2_S4_0_0_visit[0]  R360      -1
    e2_S4_0_0_visit[0]  R361      1
    e2_S4_0_0_visit[0]  R390      -15
    e2_S4_0_0_visit[0]  R391      -15
    e2_S4_0_0_visit[0]  R392      -1
    e2_S4_0_0_visit[0]  R393      -1
    e2_S4_0_0_visit[0]  R395      -15
    e2_S4_0_0_visit[0]  R396      -15
    e2_S4_0_0_visit[0]  R397      -1
    e2_S4_0_0_visit[0]  R398      -1
    e2_S4_0_0_visit[0]  R400      -15
    e2_S4_0_0_visit[0]  R401      -15
    e2_S4_0_0_visit[0]  R402      -1
    e2_S4_0_0_visit[0]  R403      -1
    e2_S4_0_0_visit[0]  R405      -15
    e2_S4_0_0_visit[0]  R406      -15
    e2_S4_0_0_visit[0]  R407      -1
    e2_S4_0_0_visit[0]  R408      -1
    e2_S4_0_0_visit[0]  R410      -15
    e2_S4_0_0_visit[0]  R411      -15
    e2_S4_0_0_visit[0]  R412      -1
    e2_S4_0_0_visit[0]  R413      -1
    e2_S4_0_0_visit[0]  R415      -15
    e2_S4_0_0_visit[0]  R416      -15
    e2_S4_0_0_visit[0]  R417      -1
    e2_S4_0_0_visit[0]  R418      -1
    e2_S4_0_0_visit[0]  R420      -15
    e2_S4_0_0_visit[0]  R421      -15
    e2_S4_0_0_visit[0]  R422      -1
    e2_S4_0_0_visit[0]  R423      -1
    e2_S4_0_0_visit[0]  R425      -15
    e2_S4_0_0_visit[0]  R426      -15
    e2_S4_0_0_visit[0]  R427      -1
    e2_S4_0_0_visit[0]  R428      -1
    e2_S4_0_0_visit[0]  R430      -15
    e2_S4_0_0_visit[0]  R431      -15
    e2_S4_0_0_visit[0]  R432      -1
    e2_S4_0_0_visit[0]  R433      -1
    e2_S4_0_0_visit[0]  R435      -15
    e2_S4_0_0_visit[0]  R436      -15
    e2_S4_0_0_visit[0]  R437      -1
    e2_S4_0_0_visit[0]  R438      -1
    e2_S4_0_0_visit[0]  R451      -1
    e2_S4_0_0_visit[0]  R453      15
    e2_S4_0_0_visit[0]  R454      1
    e2_S4_0_0_visit[0]  R463      1
    e2_S4_0_0_visit[0]  R3143     -1
    e2_S4_0_0_visit[0]  R3413     1
    e2_S4_0_0_visit[1]  R357      2
    e2_S4_0_0_visit[1]  R358      1
    e2_S4_0_0_visit[1]  R362      -1
    e2_S4_0_0_visit[1]  R363      -1
    e2_S4_0_0_visit[1]  R364      1
    e2_S4_0_0_visit[1]  R464      -40937
    e2_S4_0_0_visit[1]  R465      71100
    e2_S4_0_0_visit[1]  R3146     -1
    e2_S4_0_0_visit[1]  R3414     1
    e2_S4_0_0_visit[2]  R355      23
    e2_S4_0_0_visit[2]  R356      2
    e2_S4_0_0_visit[2]  R365      -1
    e2_S4_0_0_visit[2]  R366      -1
    e2_S4_0_0_visit[2]  R367      1
    e2_S4_0_0_visit[2]  R390      -23
    e2_S4_0_0_visit[2]  R391      -23
    e2_S4_0_0_visit[2]  R392      -2
    e2_S4_0_0_visit[2]  R393      -2
    e2_S4_0_0_visit[2]  R395      -23
    e2_S4_0_0_visit[2]  R396      -23
    e2_S4_0_0_visit[2]  R397      -2
    e2_S4_0_0_visit[2]  R398      -2
    e2_S4_0_0_visit[2]  R400      -23
    e2_S4_0_0_visit[2]  R401      -23
    e2_S4_0_0_visit[2]  R402      -2
    e2_S4_0_0_visit[2]  R403      -2
    e2_S4_0_0_visit[2]  R405      -23
    e2_S4_0_0_visit[2]  R406      -23
    e2_S4_0_0_visit[2]  R407      -2
    e2_S4_0_0_visit[2]  R408      -2
    e2_S4_0_0_visit[2]  R410      -23
    e2_S4_0_0_visit[2]  R411      -23
    e2_S4_0_0_visit[2]  R412      -2
    e2_S4_0_0_visit[2]  R413      -2
    e2_S4_0_0_visit[2]  R415      -23
    e2_S4_0_0_visit[2]  R416      -23
    e2_S4_0_0_visit[2]  R417      -2
    e2_S4_0_0_visit[2]  R418      -2
    e2_S4_0_0_visit[2]  R420      -23
    e2_S4_0_0_visit[2]  R421      -23
    e2_S4_0_0_visit[2]  R422      -2
    e2_S4_0_0_visit[2]  R423      -2
    e2_S4_0_0_visit[2]  R425      -23
    e2_S4_0_0_visit[2]  R426      -23
    e2_S4_0_0_visit[2]  R427      -2
    e2_S4_0_0_visit[2]  R428      -2
    e2_S4_0_0_visit[2]  R430      -23
    e2_S4_0_0_visit[2]  R431      -23
    e2_S4_0_0_visit[2]  R432      -2
    e2_S4_0_0_visit[2]  R433      -2
    e2_S4_0_0_visit[2]  R435      -23
    e2_S4_0_0_visit[2]  R436      -23
    e2_S4_0_0_visit[2]  R437      -2
    e2_S4_0_0_visit[2]  R438      -2
    e2_S4_0_0_visit[2]  R451      -1
    e2_S4_0_0_visit[2]  R453      23
    e2_S4_0_0_visit[2]  R454      2
    e2_S4_0_0_visit[2]  R466      1
    e2_S4_0_0_visit[2]  R3149     -1
    e2_S4_0_0_visit[2]  R3417     1
    e2_S4_0_0_visit[3]  R357      4
    e2_S4_0_0_visit[3]  R358      2
    e2_S4_0_0_visit[3]  R368      -1
    e2_S4_0_0_visit[3]  R369      -1
    e2_S4_0_0_visit[3]  R370      1
    e2_S4_0_0_visit[3]  R467      -38031
    e2_S4_0_0_visit[3]  R468      71100
    e2_S4_0_0_visit[3]  R3152     -1
    e2_S4_0_0_visit[3]  R3418     1
    e2_S4_0_0_visit[4]  R355      21
    e2_S4_0_0_visit[4]  R356      2
    e2_S4_0_0_visit[4]  R371      -1
    e2_S4_0_0_visit[4]  R372      -1
    e2_S4_0_0_visit[4]  R373      1
    e2_S4_0_0_visit[4]  R390      -21
    e2_S4_0_0_visit[4]  R391      -21
    e2_S4_0_0_visit[4]  R392      -2
    e2_S4_0_0_visit[4]  R393      -2
    e2_S4_0_0_visit[4]  R395      -21
    e2_S4_0_0_visit[4]  R396      -21
    e2_S4_0_0_visit[4]  R397      -2
    e2_S4_0_0_visit[4]  R398      -2
    e2_S4_0_0_visit[4]  R400      -21
    e2_S4_0_0_visit[4]  R401      -21
    e2_S4_0_0_visit[4]  R402      -2
    e2_S4_0_0_visit[4]  R403      -2
    e2_S4_0_0_visit[4]  R405      -21
    e2_S4_0_0_visit[4]  R406      -21
    e2_S4_0_0_visit[4]  R407      -2
    e2_S4_0_0_visit[4]  R408      -2
    e2_S4_0_0_visit[4]  R410      -21
    e2_S4_0_0_visit[4]  R411      -21
    e2_S4_0_0_visit[4]  R412      -2
    e2_S4_0_0_visit[4]  R413      -2
    e2_S4_0_0_visit[4]  R415      -21
    e2_S4_0_0_visit[4]  R416      -21
    e2_S4_0_0_visit[4]  R417      -2
    e2_S4_0_0_visit[4]  R418      -2
    e2_S4_0_0_visit[4]  R420      -21
    e2_S4_0_0_visit[4]  R421      -21
    e2_S4_0_0_visit[4]  R422      -2
    e2_S4_0_0_visit[4]  R423      -2
    e2_S4_0_0_visit[4]  R425      -21
    e2_S4_0_0_visit[4]  R426      -21
    e2_S4_0_0_visit[4]  R427      -2
    e2_S4_0_0_visit[4]  R428      -2
    e2_S4_0_0_visit[4]  R430      -21
    e2_S4_0_0_visit[4]  R431      -21
    e2_S4_0_0_visit[4]  R432      -2
    e2_S4_0_0_visit[4]  R433      -2
    e2_S4_0_0_visit[4]  R435      -21
    e2_S4_0_0_visit[4]  R436      -21
    e2_S4_0_0_visit[4]  R437      -2
    e2_S4_0_0_visit[4]  R438      -2
    e2_S4_0_0_visit[4]  R455      -1
    e2_S4_0_0_visit[4]  R457      21
    e2_S4_0_0_visit[4]  R458      2
    e2_S4_0_0_visit[4]  R469      1
    e2_S4_0_0_visit[4]  R3155     -1
    e2_S4_0_0_visit[4]  R3421     1
    e2_S4_0_0_visit[5]  R357      4
    e2_S4_0_0_visit[5]  R358      2
    e2_S4_0_0_visit[5]  R374      -1
    e2_S4_0_0_visit[5]  R375      -1
    e2_S4_0_0_visit[5]  R376      1
    e2_S4_0_0_visit[5]  R470      -25749
    e2_S4_0_0_visit[5]  R471      71100
    e2_S4_0_0_visit[5]  R3158     -1
    e2_S4_0_0_visit[5]  R3422     1
    e2_S4_0_0_visit[6]  R355      23
    e2_S4_0_0_visit[6]  R356      2
    e2_S4_0_0_visit[6]  R377      -1
    e2_S4_0_0_visit[6]  R378      -1
    e2_S4_0_0_visit[6]  R379      1
    e2_S4_0_0_visit[6]  R390      -23
    e2_S4_0_0_visit[6]  R391      -23
    e2_S4_0_0_visit[6]  R392      -2
    e2_S4_0_0_visit[6]  R393      -2
    e2_S4_0_0_visit[6]  R395      -23
    e2_S4_0_0_visit[6]  R396      -23
    e2_S4_0_0_visit[6]  R397      -2
    e2_S4_0_0_visit[6]  R398      -2
    e2_S4_0_0_visit[6]  R400      -23
    e2_S4_0_0_visit[6]  R401      -23
    e2_S4_0_0_visit[6]  R402      -2
    e2_S4_0_0_visit[6]  R403      -2
    e2_S4_0_0_visit[6]  R405      -23
    e2_S4_0_0_visit[6]  R406      -23
    e2_S4_0_0_visit[6]  R407      -2
    e2_S4_0_0_visit[6]  R408      -2
    e2_S4_0_0_visit[6]  R410      -23
    e2_S4_0_0_visit[6]  R411      -23
    e2_S4_0_0_visit[6]  R412      -2
    e2_S4_0_0_visit[6]  R413      -2
    e2_S4_0_0_visit[6]  R415      -23
    e2_S4_0_0_visit[6]  R416      -23
    e2_S4_0_0_visit[6]  R417      -2
    e2_S4_0_0_visit[6]  R418      -2
    e2_S4_0_0_visit[6]  R420      -23
    e2_S4_0_0_visit[6]  R421      -23
    e2_S4_0_0_visit[6]  R422      -2
    e2_S4_0_0_visit[6]  R423      -2
    e2_S4_0_0_visit[6]  R425      -23
    e2_S4_0_0_visit[6]  R426      -23
    e2_S4_0_0_visit[6]  R427      -2
    e2_S4_0_0_visit[6]  R428      -2
    e2_S4_0_0_visit[6]  R430      -23
    e2_S4_0_0_visit[6]  R431      -23
    e2_S4_0_0_visit[6]  R432      -2
    e2_S4_0_0_visit[6]  R433      -2
    e2_S4_0_0_visit[6]  R435      -23
    e2_S4_0_0_visit[6]  R436      -23
    e2_S4_0_0_visit[6]  R437      -2
    e2_S4_0_0_visit[6]  R438      -2
    e2_S4_0_0_visit[6]  R455      -1
    e2_S4_0_0_visit[6]  R457      23
    e2_S4_0_0_visit[6]  R458      2
    e2_S4_0_0_visit[6]  R472      1
    e2_S4_0_0_visit[6]  R3161     -1
    e2_S4_0_0_visit[6]  R3425     1
    e2_S4_0_0_visit[7]  R357      4
    e2_S4_0_0_visit[7]  R358      2
    e2_S4_0_0_visit[7]  R380      -1
    e2_S4_0_0_visit[7]  R381      -1
    e2_S4_0_0_visit[7]  R382      1
    e2_S4_0_0_visit[7]  R473      -23969
    e2_S4_0_0_visit[7]  R474      71100
    e2_S4_0_0_visit[7]  R3164     -1
    e2_S4_0_0_visit[7]  R3426     1
    e2_S4_0_0_visit[8]  R355      21
    e2_S4_0_0_visit[8]  R356      2
    e2_S4_0_0_visit[8]  R383      -1
    e2_S4_0_0_visit[8]  R384      -1
    e2_S4_0_0_visit[8]  R385      1
    e2_S4_0_0_visit[8]  R390      -21
    e2_S4_0_0_visit[8]  R391      -21
    e2_S4_0_0_visit[8]  R392      -2
    e2_S4_0_0_visit[8]  R393      -2
    e2_S4_0_0_visit[8]  R395      -21
    e2_S4_0_0_visit[8]  R396      -21
    e2_S4_0_0_visit[8]  R397      -2
    e2_S4_0_0_visit[8]  R398      -2
    e2_S4_0_0_visit[8]  R400      -21
    e2_S4_0_0_visit[8]  R401      -21
    e2_S4_0_0_visit[8]  R402      -2
    e2_S4_0_0_visit[8]  R403      -2
    e2_S4_0_0_visit[8]  R405      -21
    e2_S4_0_0_visit[8]  R406      -21
    e2_S4_0_0_visit[8]  R407      -2
    e2_S4_0_0_visit[8]  R408      -2
    e2_S4_0_0_visit[8]  R410      -21
    e2_S4_0_0_visit[8]  R411      -21
    e2_S4_0_0_visit[8]  R412      -2
    e2_S4_0_0_visit[8]  R413      -2
    e2_S4_0_0_visit[8]  R415      -21
    e2_S4_0_0_visit[8]  R416      -21
    e2_S4_0_0_visit[8]  R417      -2
    e2_S4_0_0_visit[8]  R418      -2
    e2_S4_0_0_visit[8]  R420      -21
    e2_S4_0_0_visit[8]  R421      -21
    e2_S4_0_0_visit[8]  R422      -2
    e2_S4_0_0_visit[8]  R423      -2
    e2_S4_0_0_visit[8]  R425      -21
    e2_S4_0_0_visit[8]  R426      -21
    e2_S4_0_0_visit[8]  R427      -2
    e2_S4_0_0_visit[8]  R428      -2
    e2_S4_0_0_visit[8]  R430      -21
    e2_S4_0_0_visit[8]  R431      -21
    e2_S4_0_0_visit[8]  R432      -2
    e2_S4_0_0_visit[8]  R433      -2
    e2_S4_0_0_visit[8]  R435      -21
    e2_S4_0_0_visit[8]  R436      -21
    e2_S4_0_0_visit[8]  R437      -2
    e2_S4_0_0_visit[8]  R438      -2
    e2_S4_0_0_visit[8]  R459      -1
    e2_S4_0_0_visit[8]  R461      21
    e2_S4_0_0_visit[8]  R462      2
    e2_S4_0_0_visit[8]  R475      1
    e2_S4_0_0_visit[8]  R3167     -1
    e2_S4_0_0_visit[8]  R3429     1
    e2_S4_0_0_visit[9]  R357      4
    e2_S4_0_0_visit[9]  R358      2
    e2_S4_0_0_visit[9]  R386      -1
    e2_S4_0_0_visit[9]  R387      -1
    e2_S4_0_0_visit[9]  R388      1
    e2_S4_0_0_visit[9]  R476      -11425
    e2_S4_0_0_visit[9]  R477      71100
    e2_S4_0_0_visit[9]  R3170     -1
    e2_S4_0_0_visit[9]  R3430     1
    e2_S4_0_0_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_0_arc[-1,0]  R353      1
    e2_S4_0_0_arc[-1,0]  R359      1
    e2_S4_0_0_arc[-1,0]  R389      -44319
    e2_S4_0_0_arc[-1,0]  R390      -165
    e2_S4_0_0_arc[-1,0]  R391      180
    e2_S4_0_0_arc[-1,0]  R392      -5
    e2_S4_0_0_arc[-1,0]  R393      6
    e2_S4_0_0_arc[-1,0]  R478      -30
    e2_S4_0_0_arc[-1,0]  R3144     1
    e2_S4_0_0_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_0_arc[-1,1]  R353      1
    e2_S4_0_0_arc[-1,1]  R362      1
    e2_S4_0_0_arc[-1,1]  R394      -41683
    e2_S4_0_0_arc[-1,1]  R395      -180
    e2_S4_0_0_arc[-1,1]  R396      178
    e2_S4_0_0_arc[-1,1]  R397      -6
    e2_S4_0_0_arc[-1,1]  R398      5
    e2_S4_0_0_arc[-1,1]  R479      -30
    e2_S4_0_0_arc[-1,1]  R3147     1
    e2_S4_0_0_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_0_arc[-1,2]  R353      1
    e2_S4_0_0_arc[-1,2]  R365      1
    e2_S4_0_0_arc[-1,2]  R399      -44289
    e2_S4_0_0_arc[-1,2]  R400      -157
    e2_S4_0_0_arc[-1,2]  R401      180
    e2_S4_0_0_arc[-1,2]  R402      -4
    e2_S4_0_0_arc[-1,2]  R403      6
    e2_S4_0_0_arc[-1,2]  R480      -30
    e2_S4_0_0_arc[-1,2]  R3150     1
    e2_S4_0_0_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_0_arc[-1,3]  R353      1
    e2_S4_0_0_arc[-1,3]  R368      1
    e2_S4_0_0_arc[-1,3]  R404      -40989
    e2_S4_0_0_arc[-1,3]  R405      -180
    e2_S4_0_0_arc[-1,3]  R406      176
    e2_S4_0_0_arc[-1,3]  R407      -6
    e2_S4_0_0_arc[-1,3]  R408      4
    e2_S4_0_0_arc[-1,3]  R481      -30
    e2_S4_0_0_arc[-1,3]  R3153     1
    e2_S4_0_0_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_0_arc[-1,4]  R353      1
    e2_S4_0_0_arc[-1,4]  R371      1
    e2_S4_0_0_arc[-1,4]  R409      -29919
    e2_S4_0_0_arc[-1,4]  R410      -159
    e2_S4_0_0_arc[-1,4]  R411      180
    e2_S4_0_0_arc[-1,4]  R412      -4
    e2_S4_0_0_arc[-1,4]  R413      6
    e2_S4_0_0_arc[-1,4]  R482      -30
    e2_S4_0_0_arc[-1,4]  R3156     1
    e2_S4_0_0_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_0_arc[-1,5]  R353      1
    e2_S4_0_0_arc[-1,5]  R374      1
    e2_S4_0_0_arc[-1,5]  R414      -26919
    e2_S4_0_0_arc[-1,5]  R415      -180
    e2_S4_0_0_arc[-1,5]  R416      176
    e2_S4_0_0_arc[-1,5]  R417      -6
    e2_S4_0_0_arc[-1,5]  R418      4
    e2_S4_0_0_arc[-1,5]  R483      -30
    e2_S4_0_0_arc[-1,5]  R3159     1
    e2_S4_0_0_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_0_arc[-1,6]  R353      1
    e2_S4_0_0_arc[-1,6]  R377      1
    e2_S4_0_0_arc[-1,6]  R419      -29851
    e2_S4_0_0_arc[-1,6]  R420      -157
    e2_S4_0_0_arc[-1,6]  R421      180
    e2_S4_0_0_arc[-1,6]  R422      -4
    e2_S4_0_0_arc[-1,6]  R423      6
    e2_S4_0_0_arc[-1,6]  R484      -30
    e2_S4_0_0_arc[-1,6]  R3162     1
    e2_S4_0_0_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_0_arc[-1,7]  R353      1
    e2_S4_0_0_arc[-1,7]  R380      1
    e2_S4_0_0_arc[-1,7]  R424      -25651
    e2_S4_0_0_arc[-1,7]  R425      -180
    e2_S4_0_0_arc[-1,7]  R426      176
    e2_S4_0_0_arc[-1,7]  R427      -6
    e2_S4_0_0_arc[-1,7]  R428      4
    e2_S4_0_0_arc[-1,7]  R485      -30
    e2_S4_0_0_arc[-1,7]  R3165     1
    e2_S4_0_0_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_0_arc[-1,8]  R353      1
    e2_S4_0_0_arc[-1,8]  R383      1
    e2_S4_0_0_arc[-1,8]  R429      -15519
    e2_S4_0_0_arc[-1,8]  R430      -159
    e2_S4_0_0_arc[-1,8]  R431      180
    e2_S4_0_0_arc[-1,8]  R432      -4
    e2_S4_0_0_arc[-1,8]  R433      6
    e2_S4_0_0_arc[-1,8]  R486      -30
    e2_S4_0_0_arc[-1,8]  R3168     1
    e2_S4_0_0_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_0_arc[-1,9]  R353      1
    e2_S4_0_0_arc[-1,9]  R386      1
    e2_S4_0_0_arc[-1,9]  R434      -13119
    e2_S4_0_0_arc[-1,9]  R435      -180
    e2_S4_0_0_arc[-1,9]  R436      176
    e2_S4_0_0_arc[-1,9]  R437      -6
    e2_S4_0_0_arc[-1,9]  R438      4
    e2_S4_0_0_arc[-1,9]  R487      -30
    e2_S4_0_0_arc[-1,9]  R3171     1
    e2_S4_0_0_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_0_arc[0,-2]  R354      1
    e2_S4_0_0_arc[0,-2]  R360      1
    e2_S4_0_0_arc[0,-2]  R439      -33523
    e2_S4_0_0_arc[0,-2]  R488      -30
    e2_S4_0_0_arc[0,-2]  R3145     1
    e2_S4_0_0_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_0_arc[1,-2]  R354      1
    e2_S4_0_0_arc[1,-2]  R363      1
    e2_S4_0_0_arc[1,-2]  R440      -39223
    e2_S4_0_0_arc[1,-2]  R489      -30
    e2_S4_0_0_arc[1,-2]  R3148     1
    e2_S4_0_0_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_0_arc[2,-2]  R354      1
    e2_S4_0_0_arc[2,-2]  R366      1
    e2_S4_0_0_arc[2,-2]  R441      -36369
    e2_S4_0_0_arc[2,-2]  R490      -30
    e2_S4_0_0_arc[2,-2]  R3151     1
    e2_S4_0_0_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_0_arc[3,-2]  R354      1
    e2_S4_0_0_arc[3,-2]  R369      1
    e2_S4_0_0_arc[3,-2]  R442      -42129
    e2_S4_0_0_arc[3,-2]  R491      -30
    e2_S4_0_0_arc[3,-2]  R3154     1
    e2_S4_0_0_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_0_arc[4,-2]  R354      1
    e2_S4_0_0_arc[4,-2]  R372      1
    e2_S4_0_0_arc[4,-2]  R443      -48315
    e2_S4_0_0_arc[4,-2]  R492      -30
    e2_S4_0_0_arc[4,-2]  R3157     1
    e2_S4_0_0_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_0_arc[5,-2]  R354      1
    e2_S4_0_0_arc[5,-2]  R375      1
    e2_S4_0_0_arc[5,-2]  R444      -53475
    e2_S4_0_0_arc[5,-2]  R493      -30
    e2_S4_0_0_arc[5,-2]  R3160     1
    e2_S4_0_0_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_0_arc[6,-2]  R354      1
    e2_S4_0_0_arc[6,-2]  R378      1
    e2_S4_0_0_arc[6,-2]  R445      -49531
    e2_S4_0_0_arc[6,-2]  R494      -30
    e2_S4_0_0_arc[6,-2]  R3163     1
    e2_S4_0_0_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_0_arc[7,-2]  R354      1
    e2_S4_0_0_arc[7,-2]  R381      1
    e2_S4_0_0_arc[7,-2]  R446      -56191
    e2_S4_0_0_arc[7,-2]  R495      -30
    e2_S4_0_0_arc[7,-2]  R3166     1
    e2_S4_0_0_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_0_arc[8,-2]  R354      1
    e2_S4_0_0_arc[8,-2]  R384      1
    e2_S4_0_0_arc[8,-2]  R447      -63217
    e2_S4_0_0_arc[8,-2]  R496      -30
    e2_S4_0_0_arc[8,-2]  R3169     1
    e2_S4_0_0_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_0_arc[9,-2]  R354      1
    e2_S4_0_0_arc[9,-2]  R387      1
    e2_S4_0_0_arc[9,-2]  R448      -68677
    e2_S4_0_0_arc[9,-2]  R497      -30
    e2_S4_0_0_arc[9,-2]  R3172     1
    m5_link_0  R3063     17
    m5_link_0  R3064     17
    m5_link_0  R3145     1
    m5_link_0  R3147     1
    m5_link_0  R3174     -165
    m5_link_0  R3175     178
    m5_link_0  R3176     -5
    m5_link_0  R3177     5
    m5_link_0  R3178     -30
    m5_link_1  OBJ       3.9560080889704963e+01
    m5_link_1  R3065     17
    m5_link_1  R3066     17
    m5_link_1  R3145     1
    m5_link_1  R3150     1
    m5_link_1  R3179     -2147
    m5_link_1  R3180     -142
    m5_link_1  R3181     180
    m5_link_1  R3182     -3
    m5_link_1  R3183     6
    m5_link_1  R3184     -30
    m5_link_2  OBJ       3.9560080889704963e+01
    m5_link_2  R3067     17
    m5_link_2  R3068     17
    m5_link_2  R3145     1
    m5_link_2  R3153     1
    m5_link_2  R3186     -165
    m5_link_2  R3187     176
    m5_link_2  R3188     -5
    m5_link_2  R3189     4
    m5_link_2  R3190     -30
    m5_link_3  OBJ       9.8994949366116654e+00
    m5_link_3  R3069     17
    m5_link_3  R3070     17
    m5_link_3  R3145     1
    m5_link_3  R3159     1
    m5_link_3  R3192     -165
    m5_link_3  R3193     176
    m5_link_3  R3194     -5
    m5_link_3  R3195     4
    m5_link_3  R3196     -30
    m5_link_4  OBJ       1.8110770276274835e+01
    m5_link_4  R3071     17
    m5_link_4  R3072     17
    m5_link_4  R3145     1
    m5_link_4  R3165     1
    m5_link_4  R3198     -165
    m5_link_4  R3199     176
    m5_link_4  R3200     -5
    m5_link_4  R3201     4
    m5_link_4  R3202     -30
    m5_link_5  OBJ       1.8601075237738275e+01
    m5_link_5  R3073     17
    m5_link_5  R3074     17
    m5_link_5  R3145     1
    m5_link_5  R3171     1
    m5_link_5  R3204     -165
    m5_link_5  R3205     176
    m5_link_5  R3206     -5
    m5_link_5  R3207     4
    m5_link_5  R3208     -30
    m5_link_6  OBJ       3.9560080889704963e+01
    m5_link_6  R3075     17
    m5_link_6  R3076     17
    m5_link_6  R3148     1
    m5_link_6  R3153     1
    m5_link_6  R3209     -4547
    m5_link_6  R3210     -180
    m5_link_6  R3211     174
    m5_link_6  R3212     -6
    m5_link_6  R3213     3
    m5_link_6  R3214     -30
    m5_link_7  OBJ       9.8994949366116654e+00
    m5_link_7  R3077     17
    m5_link_7  R3078     17
    m5_link_7  R3148     1
    m5_link_7  R3156     1
    m5_link_7  R3216     -159
    m5_link_7  R3217     178
    m5_link_7  R3218     -4
    m5_link_7  R3219     5
    m5_link_7  R3220     -30
    m5_link_8  OBJ       9.8994949366116654e+00
    m5_link_8  R3079     17
    m5_link_8  R3080     17
    m5_link_8  R3148     1
    m5_link_8  R3159     1
    m5_link_8  R3222     -180
    m5_link_8  R3223     174
    m5_link_8  R3224     -6
    m5_link_8  R3225     3
    m5_link_8  R3226     -30
    m5_link_9  OBJ       1.8110770276274835e+01
    m5_link_9  R3081     17
    m5_link_9  R3082     17
    m5_link_9  R3148     1
    m5_link_9  R3162     1
    m5_link_9  R3228     -157
    m5_link_9  R3229     178
    m5_link_9  R3230     -4
    m5_link_9  R3231     5
    m5_link_9  R3232     -30
    m5_link_10  OBJ       1.8110770276274835e+01
    m5_link_10  R3083     17
    m5_link_10  R3084     17
    m5_link_10  R3148     1
    m5_link_10  R3165     1
    m5_link_10  R3234     -180
    m5_link_10  R3235     174
    m5_link_10  R3236     -6
    m5_link_10  R3237     3
    m5_link_10  R3238     -30
    m5_link_11  OBJ       1.8601075237738275e+01
    m5_link_11  R3085     17
    m5_link_11  R3086     17
    m5_link_11  R3148     1
    m5_link_11  R3168     1
    m5_link_11  R3240     -159
    m5_link_11  R3241     178
    m5_link_11  R3242     -4
    m5_link_11  R3243     5
    m5_link_11  R3244     -30
    m5_link_12  OBJ       1.8601075237738275e+01
    m5_link_12  R3087     17
    m5_link_12  R3088     17
    m5_link_12  R3148     1
    m5_link_12  R3171     1
    m5_link_12  R3246     -180
    m5_link_12  R3247     174
    m5_link_12  R3248     -6
    m5_link_12  R3249     3
    m5_link_12  R3250     -30
    m5_link_13  OBJ       3.9560080889704963e+01
    m5_link_13  R3089     17
    m5_link_13  R3090     17
    m5_link_13  R3147     1
    m5_link_13  R3151     1
    m5_link_13  R3251     -2387
    m5_link_13  R3252     -157
    m5_link_13  R3253     178
    m5_link_13  R3254     -4
    m5_link_13  R3255     5
    m5_link_13  R3256     -30
    m5_link_14  R3091     17
    m5_link_14  R3092     17
    m5_link_14  R3151     1
    m5_link_14  R3153     1
    m5_link_14  R3258     -157
    m5_link_14  R3259     176
    m5_link_14  R3260     -4
    m5_link_14  R3261     4
    m5_link_14  R3262     -30
    m5_link_15  OBJ       3.0805843601498726e+01
    m5_link_15  R3093     17
    m5_link_15  R3094     17
    m5_link_15  R3151     1
    m5_link_15  R3159     1
    m5_link_15  R3264     -157
    m5_link_15  R3265     176
    m5_link_15  R3266     -4
    m5_link_15  R3267     4
    m5_link_15  R3268     -30
    m5_link_16  OBJ       2.2472205054244231e+01
    m5_link_16  R3095     17
    m5_link_16  R3096     17
    m5_link_16  R3151     1
    m5_link_16  R3165     1
    m5_link_16  R3270     -157
    m5_link_16  R3271     176
    m5_link_16  R3272     -4
    m5_link_16  R3273     4
    m5_link_16  R3274     -30
    m5_link_17  OBJ       2.2203603311174518e+01
    m5_link_17  R3097     17
    m5_link_17  R3098     17
    m5_link_17  R3151     1
    m5_link_17  R3171     1
    m5_link_17  R3276     -157
    m5_link_17  R3277     176
    m5_link_17  R3278     -4
    m5_link_17  R3279     4
    m5_link_17  R3280     -30
    m5_link_18  OBJ       3.9560080889704963e+01
    m5_link_18  R3099     17
    m5_link_18  R3100     17
    m5_link_18  R3147     1
    m5_link_18  R3154     1
    m5_link_18  R3281     -8147
    m5_link_18  R3282     -180
    m5_link_18  R3283     174
    m5_link_18  R3284     -6
    m5_link_18  R3285     3
    m5_link_18  R3286     -30
    m5_link_19  OBJ       3.0805843601498726e+01
    m5_link_19  R3101     17
    m5_link_19  R3102     17
    m5_link_19  R3154     1
    m5_link_19  R3156     1
    m5_link_19  R3288     -159
    m5_link_19  R3289     176
    m5_link_19  R3290     -4
    m5_link_19  R3291     4
    m5_link_19  R3292     -30
    m5_link_20  OBJ       3.0805843601498726e+01
    m5_link_20  R3103     17
    m5_link_20  R3104     17
    m5_link_20  R3154     1
    m5_link_20  R3159     1
    m5_link_20  R3294     -180
    m5_link_20  R3295     172
    m5_link_20  R3296     -6
    m5_link_20  R3297     2
    m5_link_20  R3298     -30
    m5_link_21  OBJ       2.2472205054244231e+01
    m5_link_21  R3105     17
    m5_link_21  R3106     17
    m5_link_21  R3154     1
    m5_link_21  R3162     1
    m5_link_21  R3300     -157
    m5_link_21  R3301     176
    m5_link_21  R3302     -4
    m5_link_21  R3303     4
    m5_link_21  R3304     -30
    m5_link_22  OBJ       2.2472205054244231e+01
    m5_link_22  R3107     17
    m5_link_22  R3108     17
    m5_link_22  R3154     1
    m5_link_22  R3165     1
    m5_link_22  R3306     -180
    m5_link_22  R3307     172
    m5_link_22  R3308     -6
    m5_link_22  R3309     2
    m5_link_22  R3310     -30
    m5_link_23  OBJ       2.2203603311174518e+01
    m5_link_23  R3109     17
    m5_link_23  R3110     17
    m5_link_23  R3154     1
    m5_link_23  R3168     1
    m5_link_23  R3312     -159
    m5_link_23  R3313     176
    m5_link_23  R3314     -4
    m5_link_23  R3315     4
    m5_link_23  R3316     -30
    m5_link_24  OBJ       2.2203603311174518e+01
    m5_link_24  R3111     17
    m5_link_24  R3112     17
    m5_link_24  R3154     1
    m5_link_24  R3171     1
    m5_link_24  R3318     -180
    m5_link_24  R3319     172
    m5_link_24  R3320     -6
    m5_link_24  R3321     2
    m5_link_24  R3322     -30
    m5_link_25  R3113     17
    m5_link_25  R3114     17
    m5_link_25  R3157     1
    m5_link_25  R3159     1
    m5_link_25  R3324     -159
    m5_link_25  R3325     176
    m5_link_25  R3326     -4
    m5_link_25  R3327     4
    m5_link_25  R3328     -30
    m5_link_26  OBJ       1.2083045973594572e+01
    m5_link_26  R3115     17
    m5_link_26  R3116     17
    m5_link_26  R3157     1
    m5_link_26  R3162     1
    m5_link_26  R3329     -2103
    m5_link_26  R3330     -136
    m5_link_26  R3331     180
    m5_link_26  R3332     -2
    m5_link_26  R3333     6
    m5_link_26  R3334     -30
    m5_link_27  OBJ       1.2083045973594572e+01
    m5_link_27  R3117     17
    m5_link_27  R3118     17
    m5_link_27  R3157     1
    m5_link_27  R3165     1
    m5_link_27  R3336     -159
    m5_link_27  R3337     176
    m5_link_27  R3338     -4
    m5_link_27  R3339     4
    m5_link_27  R3340     -30
    m5_link_28  OBJ       8.94427190999916
    m5_link_28  R3119     17
    m5_link_28  R3120     17
    m5_link_28  R3157     1
    m5_link_28  R3171     1
    m5_link_28  R3342     -159
    m5_link_28  R3343     176
    m5_link_28  R3344     -4
    m5_link_28  R3345     4
    m5_link_28  R3346     -30
    m5_link_29  OBJ       1.2083045973594572e+01
    m5_link_29  R3121     17
    m5_link_29  R3122     17
    m5_link_29  R3160     1
    m5_link_29  R3165     1
    m5_link_29  R3347     -3063
    m5_link_29  R3348     -180
    m5_link_29  R3349     172
    m5_link_29  R3350     -6
    m5_link_29  R3351     2
    m5_link_29  R3352     -30
    m5_link_30  OBJ       8.94427190999916
    m5_link_30  R3123     17
    m5_link_30  R3124     17
    m5_link_30  R3160     1
    m5_link_30  R3168     1
    m5_link_30  R3354     -159
    m5_link_30  R3355     176
    m5_link_30  R3356     -4
    m5_link_30  R3357     4
    m5_link_30  R3358     -30
    m5_link_31  OBJ       8.94427190999916
    m5_link_31  R3125     17
    m5_link_31  R3126     17
    m5_link_31  R3160     1
    m5_link_31  R3171     1
    m5_link_31  R3360     -180
    m5_link_31  R3361     172
    m5_link_31  R3362     -6
    m5_link_31  R3363     2
    m5_link_31  R3364     -30
    m5_link_32  OBJ       1.2083045973594572e+01
    m5_link_32  R3127     17
    m5_link_32  R3128     17
    m5_link_32  R3156     1
    m5_link_32  R3163     1
    m5_link_32  R3365     -3387
    m5_link_32  R3366     -136
    m5_link_32  R3367     180
    m5_link_32  R3368     -2
    m5_link_32  R3369     6
    m5_link_32  R3370     -30
    m5_link_33  OBJ       1.2083045973594572e+01
    m5_link_33  R3129     17
    m5_link_33  R3130     17
    m5_link_33  R3159     1
    m5_link_33  R3163     1
    m5_link_33  R3371     -387
    m5_link_33  R3372     -157
    m5_link_33  R3373     176
    m5_link_33  R3374     -4
    m5_link_33  R3375     4
    m5_link_33  R3376     -30
    m5_link_34  R3131     17
    m5_link_34  R3132     17
    m5_link_34  R3163     1
    m5_link_34  R3165     1
    m5_link_34  R3378     -157
    m5_link_34  R3379     176
    m5_link_34  R3380     -4
    m5_link_34  R3381     4
    m5_link_34  R3382     -30
    m5_link_35  OBJ       9.4868329805051381e+00
    m5_link_35  R3133     17
    m5_link_35  R3134     17
    m5_link_35  R3163     1
    m5_link_35  R3171     1
    m5_link_35  R3384     -157
    m5_link_35  R3385     176
    m5_link_35  R3386     -4
    m5_link_35  R3387     4
    m5_link_35  R3388     -30
    m5_link_36  OBJ       1.2083045973594572e+01
    m5_link_36  R3135     17
    m5_link_36  R3136     17
    m5_link_36  R3159     1
    m5_link_36  R3166     1
    m5_link_36  R3389     -7047
    m5_link_36  R3390     -180
    m5_link_36  R3391     172
    m5_link_36  R3392     -6
    m5_link_36  R3393     2
    m5_link_36  R3394     -30
    m5_link_37  OBJ       9.4868329805051381e+00
    m5_link_37  R3137     17
    m5_link_37  R3138     17
    m5_link_37  R3166     1
    m5_link_37  R3168     1
    m5_link_37  R3396     -159
    m5_link_37  R3397     176
    m5_link_37  R3398     -4
    m5_link_37  R3399     4
    m5_link_37  R3400     -30
    m5_link_38  OBJ       9.4868329805051381e+00
    m5_link_38  R3139     17
    m5_link_38  R3140     17
    m5_link_38  R3166     1
    m5_link_38  R3171     1
    m5_link_38  R3402     -180
    m5_link_38  R3403     172
    m5_link_38  R3404     -6
    m5_link_38  R3405     2
    m5_link_38  R3406     -30
    m5_link_39  R3141     17
    m5_link_39  R3142     17
    m5_link_39  R3169     1
    m5_link_39  R3171     1
    m5_link_39  R3408     -159
    m5_link_39  R3409     176
    m5_link_39  R3410     -4
    m5_link_39  R3411     4
    m5_link_39  R3412     -30
    MARKER    'MARKER'                 'INTEND'
    C541      R478      -1
    C541      R479      -1
    C541      R480      -1
    C541      R481      -1
    C541      R482      -1
    C541      R483      -1
    C541      R484      -1
    C541      R485      -1
    C541      R486      -1
    C541      R487      -1
    C542      R488      1
    C542      R489      1
    C542      R490      1
    C542      R491      1
    C542      R492      1
    C542      R493      1
    C542      R494      1
    C542      R495      1
    C542      R496      1
    C542      R497      1
    C542      R599      -1
    MARKER    'MARKER'                 'INTORG'
    C543      R450      1
    C543      R451      1
    C543      R452      -39660
    C543      R453      -180
    C543      R454      -6
    C543      R463      -1
    C543      R466      -1
    C544      R450      1
    C544      R455      1
    C544      R456      -54060
    C544      R457      -180
    C544      R458      -6
    C544      R469      -1
    C544      R472      -1
    C545      R450      1
    C545      R459      1
    C545      R460      -71160
    C545      R461      -180
    C545      R462      -6
    C545      R475      -1
    e2_S4_0_1_used  R498      -75600
    e2_S4_0_1_used  R499      -75600
    e2_S4_0_1_used  R500      -28800
    e2_S4_0_1_used  R501      -1
    e2_S4_0_1_used  R502      -1
    e2_S4_0_1_used  R503      -180
    e2_S4_0_1_used  R504      -6
    e2_S4_0_1_used  R505      -180
    e2_S4_0_1_used  R506      -6
    e2_S4_0_1_used  R509      -1
    e2_S4_0_1_used  R512      -1
    e2_S4_0_1_used  R515      -1
    e2_S4_0_1_used  R518      -1
    e2_S4_0_1_used  R521      -1
    e2_S4_0_1_used  R524      -1
    e2_S4_0_1_used  R527      -1
    e2_S4_0_1_used  R530      -1
    e2_S4_0_1_used  R533      -1
    e2_S4_0_1_used  R536      -1
    e2_S4_0_1_used  R597      -75540
    e2_S4_0_1_used  R598      1
    e2_S4_0_1_used  R599      -30
    e2_S4_0_1_used  R600      -1
    e2_S4_0_1_used  R601      -75600
    e2_S4_0_1_used  R749      -1
    e2_S4_0_1_used  R2610     -1
    e2_S4_0_1_start  R498      1
    e2_S4_0_1_start  R500      1
    e2_S4_0_1_start  R537      -1
    e2_S4_0_1_start  R542      -1
    e2_S4_0_1_start  R547      -1
    e2_S4_0_1_start  R552      -1
    e2_S4_0_1_start  R557      -1
    e2_S4_0_1_start  R562      -1
    e2_S4_0_1_start  R567      -1
    e2_S4_0_1_start  R572      -1
    e2_S4_0_1_start  R577      -1
    e2_S4_0_1_start  R582      -1
    e2_S4_0_1_start  R601      1
    e2_S4_0_1_start  R603      1
    e2_S4_0_1_start  R607      1
    e2_S4_0_1_start  R611      1
    e2_S4_0_1_end  R499      1
    e2_S4_0_1_end  R587      1
    e2_S4_0_1_end  R588      1
    e2_S4_0_1_end  R589      1
    e2_S4_0_1_end  R590      1
    e2_S4_0_1_end  R591      1
    e2_S4_0_1_end  R592      1
    e2_S4_0_1_end  R593      1
    e2_S4_0_1_end  R594      1
    e2_S4_0_1_end  R595      1
    e2_S4_0_1_end  R596      1
    e2_S4_0_1_end  R597      1
    e2_S4_0_1_end  R615      -1
    e2_S4_0_1_end  R616      -1
    e2_S4_0_1_end  R618      -1
    e2_S4_0_1_end  R619      -1
    e2_S4_0_1_end  R621      -1
    e2_S4_0_1_end  R622      -1
    e2_S4_0_1_end  R624      -1
    e2_S4_0_1_end  R625      -1
    e2_S4_0_1_end  R627      -1
    e2_S4_0_1_end  R628      -1
    e2_S4_0_1_end  R752      -1
    e2_S4_0_1_visit[0]  R503      15
    e2_S4_0_1_visit[0]  R504      1
    e2_S4_0_1_visit[0]  R507      -1
    e2_S4_0_1_visit[0]  R508      -1
    e2_S4_0_1_visit[0]  R509      1
    e2_S4_0_1_visit[0]  R538      -15
    e2_S4_0_1_visit[0]  R539      -15
    e2_S4_0_1_visit[0]  R540      -1
    e2_S4_0_1_visit[0]  R541      -1
    e2_S4_0_1_visit[0]  R543      -15
    e2_S4_0_1_visit[0]  R544      -15
    e2_S4_0_1_visit[0]  R545      -1
    e2_S4_0_1_visit[0]  R546      -1
    e2_S4_0_1_visit[0]  R548      -15
    e2_S4_0_1_visit[0]  R549      -15
    e2_S4_0_1_visit[0]  R550      -1
    e2_S4_0_1_visit[0]  R551      -1
    e2_S4_0_1_visit[0]  R553      -15
    e2_S4_0_1_visit[0]  R554      -15
    e2_S4_0_1_visit[0]  R555      -1
    e2_S4_0_1_visit[0]  R556      -1
    e2_S4_0_1_visit[0]  R558      -15
    e2_S4_0_1_visit[0]  R559      -15
    e2_S4_0_1_visit[0]  R560      -1
    e2_S4_0_1_visit[0]  R561      -1
    e2_S4_0_1_visit[0]  R563      -15
    e2_S4_0_1_visit[0]  R564      -15
    e2_S4_0_1_visit[0]  R565      -1
    e2_S4_0_1_visit[0]  R566      -1
    e2_S4_0_1_visit[0]  R568      -15
    e2_S4_0_1_visit[0]  R569      -15
    e2_S4_0_1_visit[0]  R570      -1
    e2_S4_0_1_visit[0]  R571      -1
    e2_S4_0_1_visit[0]  R573      -15
    e2_S4_0_1_visit[0]  R574      -15
    e2_S4_0_1_visit[0]  R575      -1
    e2_S4_0_1_visit[0]  R576      -1
    e2_S4_0_1_visit[0]  R578      -15
    e2_S4_0_1_visit[0]  R579      -15
    e2_S4_0_1_visit[0]  R580      -1
    e2_S4_0_1_visit[0]  R581      -1
    e2_S4_0_1_visit[0]  R583      -15
    e2_S4_0_1_visit[0]  R584      -15
    e2_S4_0_1_visit[0]  R585      -1
    e2_S4_0_1_visit[0]  R586      -1
    e2_S4_0_1_visit[0]  R602      -1
    e2_S4_0_1_visit[0]  R604      15
    e2_S4_0_1_visit[0]  R605      1
    e2_S4_0_1_visit[0]  R614      1
    e2_S4_0_1_visit[0]  R3143     -2
    e2_S4_0_1_visit[0]  R3413     1
    e2_S4_0_1_visit[1]  R505      2
    e2_S4_0_1_visit[1]  R506      1
    e2_S4_0_1_visit[1]  R510      -1
    e2_S4_0_1_visit[1]  R511      -1
    e2_S4_0_1_visit[1]  R512      1
    e2_S4_0_1_visit[1]  R615      -40937
    e2_S4_0_1_visit[1]  R616      71100
    e2_S4_0_1_visit[1]  R3146     -2
    e2_S4_0_1_visit[1]  R3414     1
    e2_S4_0_1_visit[2]  R503      23
    e2_S4_0_1_visit[2]  R504      2
    e2_S4_0_1_visit[2]  R513      -1
    e2_S4_0_1_visit[2]  R514      -1
    e2_S4_0_1_visit[2]  R515      1
    e2_S4_0_1_visit[2]  R538      -23
    e2_S4_0_1_visit[2]  R539      -23
    e2_S4_0_1_visit[2]  R540      -2
    e2_S4_0_1_visit[2]  R541      -2
    e2_S4_0_1_visit[2]  R543      -23
    e2_S4_0_1_visit[2]  R544      -23
    e2_S4_0_1_visit[2]  R545      -2
    e2_S4_0_1_visit[2]  R546      -2
    e2_S4_0_1_visit[2]  R548      -23
    e2_S4_0_1_visit[2]  R549      -23
    e2_S4_0_1_visit[2]  R550      -2
    e2_S4_0_1_visit[2]  R551      -2
    e2_S4_0_1_visit[2]  R553      -23
    e2_S4_0_1_visit[2]  R554      -23
    e2_S4_0_1_visit[2]  R555      -2
    e2_S4_0_1_visit[2]  R556      -2
    e2_S4_0_1_visit[2]  R558      -23
    e2_S4_0_1_visit[2]  R559      -23
    e2_S4_0_1_visit[2]  R560      -2
    e2_S4_0_1_visit[2]  R561      -2
    e2_S4_0_1_visit[2]  R563      -23
    e2_S4_0_1_visit[2]  R564      -23
    e2_S4_0_1_visit[2]  R565      -2
    e2_S4_0_1_visit[2]  R566      -2
    e2_S4_0_1_visit[2]  R568      -23
    e2_S4_0_1_visit[2]  R569      -23
    e2_S4_0_1_visit[2]  R570      -2
    e2_S4_0_1_visit[2]  R571      -2
    e2_S4_0_1_visit[2]  R573      -23
    e2_S4_0_1_visit[2]  R574      -23
    e2_S4_0_1_visit[2]  R575      -2
    e2_S4_0_1_visit[2]  R576      -2
    e2_S4_0_1_visit[2]  R578      -23
    e2_S4_0_1_visit[2]  R579      -23
    e2_S4_0_1_visit[2]  R580      -2
    e2_S4_0_1_visit[2]  R581      -2
    e2_S4_0_1_visit[2]  R583      -23
    e2_S4_0_1_visit[2]  R584      -23
    e2_S4_0_1_visit[2]  R585      -2
    e2_S4_0_1_visit[2]  R586      -2
    e2_S4_0_1_visit[2]  R602      -1
    e2_S4_0_1_visit[2]  R604      23
    e2_S4_0_1_visit[2]  R605      2
    e2_S4_0_1_visit[2]  R617      1
    e2_S4_0_1_visit[2]  R3149     -2
    e2_S4_0_1_visit[2]  R3417     1
    e2_S4_0_1_visit[3]  R505      4
    e2_S4_0_1_visit[3]  R506      2
    e2_S4_0_1_visit[3]  R516      -1
    e2_S4_0_1_visit[3]  R517      -1
    e2_S4_0_1_visit[3]  R518      1
    e2_S4_0_1_visit[3]  R618      -38031
    e2_S4_0_1_visit[3]  R619      71100
    e2_S4_0_1_visit[3]  R3152     -2
    e2_S4_0_1_visit[3]  R3418     1
    e2_S4_0_1_visit[4]  R503      21
    e2_S4_0_1_visit[4]  R504      2
    e2_S4_0_1_visit[4]  R519      -1
    e2_S4_0_1_visit[4]  R520      -1
    e2_S4_0_1_visit[4]  R521      1
    e2_S4_0_1_visit[4]  R538      -21
    e2_S4_0_1_visit[4]  R539      -21
    e2_S4_0_1_visit[4]  R540      -2
    e2_S4_0_1_visit[4]  R541      -2
    e2_S4_0_1_visit[4]  R543      -21
    e2_S4_0_1_visit[4]  R544      -21
    e2_S4_0_1_visit[4]  R545      -2
    e2_S4_0_1_visit[4]  R546      -2
    e2_S4_0_1_visit[4]  R548      -21
    e2_S4_0_1_visit[4]  R549      -21
    e2_S4_0_1_visit[4]  R550      -2
    e2_S4_0_1_visit[4]  R551      -2
    e2_S4_0_1_visit[4]  R553      -21
    e2_S4_0_1_visit[4]  R554      -21
    e2_S4_0_1_visit[4]  R555      -2
    e2_S4_0_1_visit[4]  R556      -2
    e2_S4_0_1_visit[4]  R558      -21
    e2_S4_0_1_visit[4]  R559      -21
    e2_S4_0_1_visit[4]  R560      -2
    e2_S4_0_1_visit[4]  R561      -2
    e2_S4_0_1_visit[4]  R563      -21
    e2_S4_0_1_visit[4]  R564      -21
    e2_S4_0_1_visit[4]  R565      -2
    e2_S4_0_1_visit[4]  R566      -2
    e2_S4_0_1_visit[4]  R568      -21
    e2_S4_0_1_visit[4]  R569      -21
    e2_S4_0_1_visit[4]  R570      -2
    e2_S4_0_1_visit[4]  R571      -2
    e2_S4_0_1_visit[4]  R573      -21
    e2_S4_0_1_visit[4]  R574      -21
    e2_S4_0_1_visit[4]  R575      -2
    e2_S4_0_1_visit[4]  R576      -2
    e2_S4_0_1_visit[4]  R578      -21
    e2_S4_0_1_visit[4]  R579      -21
    e2_S4_0_1_visit[4]  R580      -2
    e2_S4_0_1_visit[4]  R581      -2
    e2_S4_0_1_visit[4]  R583      -21
    e2_S4_0_1_visit[4]  R584      -21
    e2_S4_0_1_visit[4]  R585      -2
    e2_S4_0_1_visit[4]  R586      -2
    e2_S4_0_1_visit[4]  R606      -1
    e2_S4_0_1_visit[4]  R608      21
    e2_S4_0_1_visit[4]  R609      2
    e2_S4_0_1_visit[4]  R620      1
    e2_S4_0_1_visit[4]  R3155     -2
    e2_S4_0_1_visit[4]  R3421     1
    e2_S4_0_1_visit[5]  R505      4
    e2_S4_0_1_visit[5]  R506      2
    e2_S4_0_1_visit[5]  R522      -1
    e2_S4_0_1_visit[5]  R523      -1
    e2_S4_0_1_visit[5]  R524      1
    e2_S4_0_1_visit[5]  R621      -25749
    e2_S4_0_1_visit[5]  R622      71100
    e2_S4_0_1_visit[5]  R3158     -2
    e2_S4_0_1_visit[5]  R3422     1
    e2_S4_0_1_visit[6]  R503      23
    e2_S4_0_1_visit[6]  R504      2
    e2_S4_0_1_visit[6]  R525      -1
    e2_S4_0_1_visit[6]  R526      -1
    e2_S4_0_1_visit[6]  R527      1
    e2_S4_0_1_visit[6]  R538      -23
    e2_S4_0_1_visit[6]  R539      -23
    e2_S4_0_1_visit[6]  R540      -2
    e2_S4_0_1_visit[6]  R541      -2
    e2_S4_0_1_visit[6]  R543      -23
    e2_S4_0_1_visit[6]  R544      -23
    e2_S4_0_1_visit[6]  R545      -2
    e2_S4_0_1_visit[6]  R546      -2
    e2_S4_0_1_visit[6]  R548      -23
    e2_S4_0_1_visit[6]  R549      -23
    e2_S4_0_1_visit[6]  R550      -2
    e2_S4_0_1_visit[6]  R551      -2
    e2_S4_0_1_visit[6]  R553      -23
    e2_S4_0_1_visit[6]  R554      -23
    e2_S4_0_1_visit[6]  R555      -2
    e2_S4_0_1_visit[6]  R556      -2
    e2_S4_0_1_visit[6]  R558      -23
    e2_S4_0_1_visit[6]  R559      -23
    e2_S4_0_1_visit[6]  R560      -2
    e2_S4_0_1_visit[6]  R561      -2
    e2_S4_0_1_visit[6]  R563      -23
    e2_S4_0_1_visit[6]  R564      -23
    e2_S4_0_1_visit[6]  R565      -2
    e2_S4_0_1_visit[6]  R566      -2
    e2_S4_0_1_visit[6]  R568      -23
    e2_S4_0_1_visit[6]  R569      -23
    e2_S4_0_1_visit[6]  R570      -2
    e2_S4_0_1_visit[6]  R571      -2
    e2_S4_0_1_visit[6]  R573      -23
    e2_S4_0_1_visit[6]  R574      -23
    e2_S4_0_1_visit[6]  R575      -2
    e2_S4_0_1_visit[6]  R576      -2
    e2_S4_0_1_visit[6]  R578      -23
    e2_S4_0_1_visit[6]  R579      -23
    e2_S4_0_1_visit[6]  R580      -2
    e2_S4_0_1_visit[6]  R581      -2
    e2_S4_0_1_visit[6]  R583      -23
    e2_S4_0_1_visit[6]  R584      -23
    e2_S4_0_1_visit[6]  R585      -2
    e2_S4_0_1_visit[6]  R586      -2
    e2_S4_0_1_visit[6]  R606      -1
    e2_S4_0_1_visit[6]  R608      23
    e2_S4_0_1_visit[6]  R609      2
    e2_S4_0_1_visit[6]  R623      1
    e2_S4_0_1_visit[6]  R3161     -2
    e2_S4_0_1_visit[6]  R3425     1
    e2_S4_0_1_visit[7]  R505      4
    e2_S4_0_1_visit[7]  R506      2
    e2_S4_0_1_visit[7]  R528      -1
    e2_S4_0_1_visit[7]  R529      -1
    e2_S4_0_1_visit[7]  R530      1
    e2_S4_0_1_visit[7]  R624      -23969
    e2_S4_0_1_visit[7]  R625      71100
    e2_S4_0_1_visit[7]  R3164     -2
    e2_S4_0_1_visit[7]  R3426     1
    e2_S4_0_1_visit[8]  R503      21
    e2_S4_0_1_visit[8]  R504      2
    e2_S4_0_1_visit[8]  R531      -1
    e2_S4_0_1_visit[8]  R532      -1
    e2_S4_0_1_visit[8]  R533      1
    e2_S4_0_1_visit[8]  R538      -21
    e2_S4_0_1_visit[8]  R539      -21
    e2_S4_0_1_visit[8]  R540      -2
    e2_S4_0_1_visit[8]  R541      -2
    e2_S4_0_1_visit[8]  R543      -21
    e2_S4_0_1_visit[8]  R544      -21
    e2_S4_0_1_visit[8]  R545      -2
    e2_S4_0_1_visit[8]  R546      -2
    e2_S4_0_1_visit[8]  R548      -21
    e2_S4_0_1_visit[8]  R549      -21
    e2_S4_0_1_visit[8]  R550      -2
    e2_S4_0_1_visit[8]  R551      -2
    e2_S4_0_1_visit[8]  R553      -21
    e2_S4_0_1_visit[8]  R554      -21
    e2_S4_0_1_visit[8]  R555      -2
    e2_S4_0_1_visit[8]  R556      -2
    e2_S4_0_1_visit[8]  R558      -21
    e2_S4_0_1_visit[8]  R559      -21
    e2_S4_0_1_visit[8]  R560      -2
    e2_S4_0_1_visit[8]  R561      -2
    e2_S4_0_1_visit[8]  R563      -21
    e2_S4_0_1_visit[8]  R564      -21
    e2_S4_0_1_visit[8]  R565      -2
    e2_S4_0_1_visit[8]  R566      -2
    e2_S4_0_1_visit[8]  R568      -21
    e2_S4_0_1_visit[8]  R569      -21
    e2_S4_0_1_visit[8]  R570      -2
    e2_S4_0_1_visit[8]  R571      -2
    e2_S4_0_1_visit[8]  R573      -21
    e2_S4_0_1_visit[8]  R574      -21
    e2_S4_0_1_visit[8]  R575      -2
    e2_S4_0_1_visit[8]  R576      -2
    e2_S4_0_1_visit[8]  R578      -21
    e2_S4_0_1_visit[8]  R579      -21
    e2_S4_0_1_visit[8]  R580      -2
    e2_S4_0_1_visit[8]  R581      -2
    e2_S4_0_1_visit[8]  R583      -21
    e2_S4_0_1_visit[8]  R584      -21
    e2_S4_0_1_visit[8]  R585      -2
    e2_S4_0_1_visit[8]  R586      -2
    e2_S4_0_1_visit[8]  R610      -1
    e2_S4_0_1_visit[8]  R612      21
    e2_S4_0_1_visit[8]  R613      2
    e2_S4_0_1_visit[8]  R626      1
    e2_S4_0_1_visit[8]  R3167     -2
    e2_S4_0_1_visit[8]  R3429     1
    e2_S4_0_1_visit[9]  R505      4
    e2_S4_0_1_visit[9]  R506      2
    e2_S4_0_1_visit[9]  R534      -1
    e2_S4_0_1_visit[9]  R535      -1
    e2_S4_0_1_visit[9]  R536      1
    e2_S4_0_1_visit[9]  R627      -11425
    e2_S4_0_1_visit[9]  R628      71100
    e2_S4_0_1_visit[9]  R3170     -2
    e2_S4_0_1_visit[9]  R3430     1
    e2_S4_0_1_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_1_arc[-1,0]  R501      1
    e2_S4_0_1_arc[-1,0]  R507      1
    e2_S4_0_1_arc[-1,0]  R537      -44319
    e2_S4_0_1_arc[-1,0]  R538      -165
    e2_S4_0_1_arc[-1,0]  R539      180
    e2_S4_0_1_arc[-1,0]  R540      -5
    e2_S4_0_1_arc[-1,0]  R541      6
    e2_S4_0_1_arc[-1,0]  R629      -30
    e2_S4_0_1_arc[-1,0]  R3144     1
    e2_S4_0_1_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_1_arc[-1,1]  R501      1
    e2_S4_0_1_arc[-1,1]  R510      1
    e2_S4_0_1_arc[-1,1]  R542      -41683
    e2_S4_0_1_arc[-1,1]  R543      -180
    e2_S4_0_1_arc[-1,1]  R544      178
    e2_S4_0_1_arc[-1,1]  R545      -6
    e2_S4_0_1_arc[-1,1]  R546      5
    e2_S4_0_1_arc[-1,1]  R630      -30
    e2_S4_0_1_arc[-1,1]  R3147     1
    e2_S4_0_1_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_1_arc[-1,2]  R501      1
    e2_S4_0_1_arc[-1,2]  R513      1
    e2_S4_0_1_arc[-1,2]  R547      -44289
    e2_S4_0_1_arc[-1,2]  R548      -157
    e2_S4_0_1_arc[-1,2]  R549      180
    e2_S4_0_1_arc[-1,2]  R550      -4
    e2_S4_0_1_arc[-1,2]  R551      6
    e2_S4_0_1_arc[-1,2]  R631      -30
    e2_S4_0_1_arc[-1,2]  R3150     1
    e2_S4_0_1_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_1_arc[-1,3]  R501      1
    e2_S4_0_1_arc[-1,3]  R516      1
    e2_S4_0_1_arc[-1,3]  R552      -40989
    e2_S4_0_1_arc[-1,3]  R553      -180
    e2_S4_0_1_arc[-1,3]  R554      176
    e2_S4_0_1_arc[-1,3]  R555      -6
    e2_S4_0_1_arc[-1,3]  R556      4
    e2_S4_0_1_arc[-1,3]  R632      -30
    e2_S4_0_1_arc[-1,3]  R3153     1
    e2_S4_0_1_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_1_arc[-1,4]  R501      1
    e2_S4_0_1_arc[-1,4]  R519      1
    e2_S4_0_1_arc[-1,4]  R557      -29919
    e2_S4_0_1_arc[-1,4]  R558      -159
    e2_S4_0_1_arc[-1,4]  R559      180
    e2_S4_0_1_arc[-1,4]  R560      -4
    e2_S4_0_1_arc[-1,4]  R561      6
    e2_S4_0_1_arc[-1,4]  R633      -30
    e2_S4_0_1_arc[-1,4]  R3156     1
    e2_S4_0_1_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_1_arc[-1,5]  R501      1
    e2_S4_0_1_arc[-1,5]  R522      1
    e2_S4_0_1_arc[-1,5]  R562      -26919
    e2_S4_0_1_arc[-1,5]  R563      -180
    e2_S4_0_1_arc[-1,5]  R564      176
    e2_S4_0_1_arc[-1,5]  R565      -6
    e2_S4_0_1_arc[-1,5]  R566      4
    e2_S4_0_1_arc[-1,5]  R634      -30
    e2_S4_0_1_arc[-1,5]  R3159     1
    e2_S4_0_1_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_1_arc[-1,6]  R501      1
    e2_S4_0_1_arc[-1,6]  R525      1
    e2_S4_0_1_arc[-1,6]  R567      -29851
    e2_S4_0_1_arc[-1,6]  R568      -157
    e2_S4_0_1_arc[-1,6]  R569      180
    e2_S4_0_1_arc[-1,6]  R570      -4
    e2_S4_0_1_arc[-1,6]  R571      6
    e2_S4_0_1_arc[-1,6]  R635      -30
    e2_S4_0_1_arc[-1,6]  R3162     1
    e2_S4_0_1_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_1_arc[-1,7]  R501      1
    e2_S4_0_1_arc[-1,7]  R528      1
    e2_S4_0_1_arc[-1,7]  R572      -25651
    e2_S4_0_1_arc[-1,7]  R573      -180
    e2_S4_0_1_arc[-1,7]  R574      176
    e2_S4_0_1_arc[-1,7]  R575      -6
    e2_S4_0_1_arc[-1,7]  R576      4
    e2_S4_0_1_arc[-1,7]  R636      -30
    e2_S4_0_1_arc[-1,7]  R3165     1
    e2_S4_0_1_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_1_arc[-1,8]  R501      1
    e2_S4_0_1_arc[-1,8]  R531      1
    e2_S4_0_1_arc[-1,8]  R577      -15519
    e2_S4_0_1_arc[-1,8]  R578      -159
    e2_S4_0_1_arc[-1,8]  R579      180
    e2_S4_0_1_arc[-1,8]  R580      -4
    e2_S4_0_1_arc[-1,8]  R581      6
    e2_S4_0_1_arc[-1,8]  R637      -30
    e2_S4_0_1_arc[-1,8]  R3168     1
    e2_S4_0_1_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_1_arc[-1,9]  R501      1
    e2_S4_0_1_arc[-1,9]  R534      1
    e2_S4_0_1_arc[-1,9]  R582      -13119
    e2_S4_0_1_arc[-1,9]  R583      -180
    e2_S4_0_1_arc[-1,9]  R584      176
    e2_S4_0_1_arc[-1,9]  R585      -6
    e2_S4_0_1_arc[-1,9]  R586      4
    e2_S4_0_1_arc[-1,9]  R638      -30
    e2_S4_0_1_arc[-1,9]  R3171     1
    e2_S4_0_1_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_1_arc[0,-2]  R502      1
    e2_S4_0_1_arc[0,-2]  R508      1
    e2_S4_0_1_arc[0,-2]  R587      -33523
    e2_S4_0_1_arc[0,-2]  R639      -30
    e2_S4_0_1_arc[0,-2]  R3145     1
    e2_S4_0_1_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_1_arc[1,-2]  R502      1
    e2_S4_0_1_arc[1,-2]  R511      1
    e2_S4_0_1_arc[1,-2]  R588      -39223
    e2_S4_0_1_arc[1,-2]  R640      -30
    e2_S4_0_1_arc[1,-2]  R3148     1
    e2_S4_0_1_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_1_arc[2,-2]  R502      1
    e2_S4_0_1_arc[2,-2]  R514      1
    e2_S4_0_1_arc[2,-2]  R589      -36369
    e2_S4_0_1_arc[2,-2]  R641      -30
    e2_S4_0_1_arc[2,-2]  R3151     1
    e2_S4_0_1_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_1_arc[3,-2]  R502      1
    e2_S4_0_1_arc[3,-2]  R517      1
    e2_S4_0_1_arc[3,-2]  R590      -42129
    e2_S4_0_1_arc[3,-2]  R642      -30
    e2_S4_0_1_arc[3,-2]  R3154     1
    e2_S4_0_1_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_1_arc[4,-2]  R502      1
    e2_S4_0_1_arc[4,-2]  R520      1
    e2_S4_0_1_arc[4,-2]  R591      -48315
    e2_S4_0_1_arc[4,-2]  R643      -30
    e2_S4_0_1_arc[4,-2]  R3157     1
    e2_S4_0_1_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_1_arc[5,-2]  R502      1
    e2_S4_0_1_arc[5,-2]  R523      1
    e2_S4_0_1_arc[5,-2]  R592      -53475
    e2_S4_0_1_arc[5,-2]  R644      -30
    e2_S4_0_1_arc[5,-2]  R3160     1
    e2_S4_0_1_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_1_arc[6,-2]  R502      1
    e2_S4_0_1_arc[6,-2]  R526      1
    e2_S4_0_1_arc[6,-2]  R593      -49531
    e2_S4_0_1_arc[6,-2]  R645      -30
    e2_S4_0_1_arc[6,-2]  R3163     1
    e2_S4_0_1_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_1_arc[7,-2]  R502      1
    e2_S4_0_1_arc[7,-2]  R529      1
    e2_S4_0_1_arc[7,-2]  R594      -56191
    e2_S4_0_1_arc[7,-2]  R646      -30
    e2_S4_0_1_arc[7,-2]  R3166     1
    e2_S4_0_1_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_1_arc[8,-2]  R502      1
    e2_S4_0_1_arc[8,-2]  R532      1
    e2_S4_0_1_arc[8,-2]  R595      -63217
    e2_S4_0_1_arc[8,-2]  R647      -30
    e2_S4_0_1_arc[8,-2]  R3169     1
    e2_S4_0_1_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_1_arc[9,-2]  R502      1
    e2_S4_0_1_arc[9,-2]  R535      1
    e2_S4_0_1_arc[9,-2]  R596      -68677
    e2_S4_0_1_arc[9,-2]  R648      -30
    e2_S4_0_1_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C579      R599      1
    C579      R629      -1
    C579      R630      -1
    C579      R631      -1
    C579      R632      -1
    C579      R633      -1
    C579      R634      -1
    C579      R635      -1
    C579      R636      -1
    C579      R637      -1
    C579      R638      -1
    C580      R639      1
    C580      R640      1
    C580      R641      1
    C580      R642      1
    C580      R643      1
    C580      R644      1
    C580      R645      1
    C580      R646      1
    C580      R647      1
    C580      R648      1
    C580      R750      -1
    MARKER    'MARKER'                 'INTORG'
    C581      R600      1
    C581      R601      -60
    C581      R602      1
    C581      R603      -39660
    C581      R604      -180
    C581      R605      -6
    C581      R614      -1
    C581      R617      -1
    C582      R600      1
    C582      R601      -60
    C582      R606      1
    C582      R607      -54060
    C582      R608      -180
    C582      R609      -6
    C582      R620      -1
    C582      R623      -1
    C583      R600      1
    C583      R601      -60
    C583      R610      1
    C583      R611      -71160
    C583      R612      -180
    C583      R613      -6
    C583      R626      -1
    e2_S4_0_2_used  R649      -75600
    e2_S4_0_2_used  R650      -75600
    e2_S4_0_2_used  R651      -28800
    e2_S4_0_2_used  R652      -1
    e2_S4_0_2_used  R653      -1
    e2_S4_0_2_used  R654      -180
    e2_S4_0_2_used  R655      -6
    e2_S4_0_2_used  R656      -180
    e2_S4_0_2_used  R657      -6
    e2_S4_0_2_used  R660      -1
    e2_S4_0_2_used  R663      -1
    e2_S4_0_2_used  R666      -1
    e2_S4_0_2_used  R669      -1
    e2_S4_0_2_used  R672      -1
    e2_S4_0_2_used  R675      -1
    e2_S4_0_2_used  R678      -1
    e2_S4_0_2_used  R681      -1
    e2_S4_0_2_used  R684      -1
    e2_S4_0_2_used  R687      -1
    e2_S4_0_2_used  R748      -75540
    e2_S4_0_2_used  R749      1
    e2_S4_0_2_used  R750      -30
    e2_S4_0_2_used  R751      -1
    e2_S4_0_2_used  R752      -75600
    e2_S4_0_2_used  R900      -1
    e2_S4_0_2_used  R2610     -1
    e2_S4_0_2_start  R649      1
    e2_S4_0_2_start  R651      1
    e2_S4_0_2_start  R688      -1
    e2_S4_0_2_start  R693      -1
    e2_S4_0_2_start  R698      -1
    e2_S4_0_2_start  R703      -1
    e2_S4_0_2_start  R708      -1
    e2_S4_0_2_start  R713      -1
    e2_S4_0_2_start  R718      -1
    e2_S4_0_2_start  R723      -1
    e2_S4_0_2_start  R728      -1
    e2_S4_0_2_start  R733      -1
    e2_S4_0_2_start  R752      1
    e2_S4_0_2_start  R754      1
    e2_S4_0_2_start  R758      1
    e2_S4_0_2_start  R762      1
    e2_S4_0_2_end  R650      1
    e2_S4_0_2_end  R738      1
    e2_S4_0_2_end  R739      1
    e2_S4_0_2_end  R740      1
    e2_S4_0_2_end  R741      1
    e2_S4_0_2_end  R742      1
    e2_S4_0_2_end  R743      1
    e2_S4_0_2_end  R744      1
    e2_S4_0_2_end  R745      1
    e2_S4_0_2_end  R746      1
    e2_S4_0_2_end  R747      1
    e2_S4_0_2_end  R748      1
    e2_S4_0_2_end  R766      -1
    e2_S4_0_2_end  R767      -1
    e2_S4_0_2_end  R769      -1
    e2_S4_0_2_end  R770      -1
    e2_S4_0_2_end  R772      -1
    e2_S4_0_2_end  R773      -1
    e2_S4_0_2_end  R775      -1
    e2_S4_0_2_end  R776      -1
    e2_S4_0_2_end  R778      -1
    e2_S4_0_2_end  R779      -1
    e2_S4_0_2_end  R903      -1
    e2_S4_0_2_visit[0]  R654      15
    e2_S4_0_2_visit[0]  R655      1
    e2_S4_0_2_visit[0]  R658      -1
    e2_S4_0_2_visit[0]  R659      -1
    e2_S4_0_2_visit[0]  R660      1
    e2_S4_0_2_visit[0]  R689      -15
    e2_S4_0_2_visit[0]  R690      -15
    e2_S4_0_2_visit[0]  R691      -1
    e2_S4_0_2_visit[0]  R692      -1
    e2_S4_0_2_visit[0]  R694      -15
    e2_S4_0_2_visit[0]  R695      -15
    e2_S4_0_2_visit[0]  R696      -1
    e2_S4_0_2_visit[0]  R697      -1
    e2_S4_0_2_visit[0]  R699      -15
    e2_S4_0_2_visit[0]  R700      -15
    e2_S4_0_2_visit[0]  R701      -1
    e2_S4_0_2_visit[0]  R702      -1
    e2_S4_0_2_visit[0]  R704      -15
    e2_S4_0_2_visit[0]  R705      -15
    e2_S4_0_2_visit[0]  R706      -1
    e2_S4_0_2_visit[0]  R707      -1
    e2_S4_0_2_visit[0]  R709      -15
    e2_S4_0_2_visit[0]  R710      -15
    e2_S4_0_2_visit[0]  R711      -1
    e2_S4_0_2_visit[0]  R712      -1
    e2_S4_0_2_visit[0]  R714      -15
    e2_S4_0_2_visit[0]  R715      -15
    e2_S4_0_2_visit[0]  R716      -1
    e2_S4_0_2_visit[0]  R717      -1
    e2_S4_0_2_visit[0]  R719      -15
    e2_S4_0_2_visit[0]  R720      -15
    e2_S4_0_2_visit[0]  R721      -1
    e2_S4_0_2_visit[0]  R722      -1
    e2_S4_0_2_visit[0]  R724      -15
    e2_S4_0_2_visit[0]  R725      -15
    e2_S4_0_2_visit[0]  R726      -1
    e2_S4_0_2_visit[0]  R727      -1
    e2_S4_0_2_visit[0]  R729      -15
    e2_S4_0_2_visit[0]  R730      -15
    e2_S4_0_2_visit[0]  R731      -1
    e2_S4_0_2_visit[0]  R732      -1
    e2_S4_0_2_visit[0]  R734      -15
    e2_S4_0_2_visit[0]  R735      -15
    e2_S4_0_2_visit[0]  R736      -1
    e2_S4_0_2_visit[0]  R737      -1
    e2_S4_0_2_visit[0]  R753      -1
    e2_S4_0_2_visit[0]  R755      15
    e2_S4_0_2_visit[0]  R756      1
    e2_S4_0_2_visit[0]  R765      1
    e2_S4_0_2_visit[0]  R3143     -3
    e2_S4_0_2_visit[0]  R3413     1
    e2_S4_0_2_visit[1]  R656      2
    e2_S4_0_2_visit[1]  R657      1
    e2_S4_0_2_visit[1]  R661      -1
    e2_S4_0_2_visit[1]  R662      -1
    e2_S4_0_2_visit[1]  R663      1
    e2_S4_0_2_visit[1]  R766      -40937
    e2_S4_0_2_visit[1]  R767      71100
    e2_S4_0_2_visit[1]  R3146     -3
    e2_S4_0_2_visit[1]  R3414     1
    e2_S4_0_2_visit[2]  R654      23
    e2_S4_0_2_visit[2]  R655      2
    e2_S4_0_2_visit[2]  R664      -1
    e2_S4_0_2_visit[2]  R665      -1
    e2_S4_0_2_visit[2]  R666      1
    e2_S4_0_2_visit[2]  R689      -23
    e2_S4_0_2_visit[2]  R690      -23
    e2_S4_0_2_visit[2]  R691      -2
    e2_S4_0_2_visit[2]  R692      -2
    e2_S4_0_2_visit[2]  R694      -23
    e2_S4_0_2_visit[2]  R695      -23
    e2_S4_0_2_visit[2]  R696      -2
    e2_S4_0_2_visit[2]  R697      -2
    e2_S4_0_2_visit[2]  R699      -23
    e2_S4_0_2_visit[2]  R700      -23
    e2_S4_0_2_visit[2]  R701      -2
    e2_S4_0_2_visit[2]  R702      -2
    e2_S4_0_2_visit[2]  R704      -23
    e2_S4_0_2_visit[2]  R705      -23
    e2_S4_0_2_visit[2]  R706      -2
    e2_S4_0_2_visit[2]  R707      -2
    e2_S4_0_2_visit[2]  R709      -23
    e2_S4_0_2_visit[2]  R710      -23
    e2_S4_0_2_visit[2]  R711      -2
    e2_S4_0_2_visit[2]  R712      -2
    e2_S4_0_2_visit[2]  R714      -23
    e2_S4_0_2_visit[2]  R715      -23
    e2_S4_0_2_visit[2]  R716      -2
    e2_S4_0_2_visit[2]  R717      -2
    e2_S4_0_2_visit[2]  R719      -23
    e2_S4_0_2_visit[2]  R720      -23
    e2_S4_0_2_visit[2]  R721      -2
    e2_S4_0_2_visit[2]  R722      -2
    e2_S4_0_2_visit[2]  R724      -23
    e2_S4_0_2_visit[2]  R725      -23
    e2_S4_0_2_visit[2]  R726      -2
    e2_S4_0_2_visit[2]  R727      -2
    e2_S4_0_2_visit[2]  R729      -23
    e2_S4_0_2_visit[2]  R730      -23
    e2_S4_0_2_visit[2]  R731      -2
    e2_S4_0_2_visit[2]  R732      -2
    e2_S4_0_2_visit[2]  R734      -23
    e2_S4_0_2_visit[2]  R735      -23
    e2_S4_0_2_visit[2]  R736      -2
    e2_S4_0_2_visit[2]  R737      -2
    e2_S4_0_2_visit[2]  R753      -1
    e2_S4_0_2_visit[2]  R755      23
    e2_S4_0_2_visit[2]  R756      2
    e2_S4_0_2_visit[2]  R768      1
    e2_S4_0_2_visit[2]  R3149     -3
    e2_S4_0_2_visit[2]  R3417     1
    e2_S4_0_2_visit[3]  R656      4
    e2_S4_0_2_visit[3]  R657      2
    e2_S4_0_2_visit[3]  R667      -1
    e2_S4_0_2_visit[3]  R668      -1
    e2_S4_0_2_visit[3]  R669      1
    e2_S4_0_2_visit[3]  R769      -38031
    e2_S4_0_2_visit[3]  R770      71100
    e2_S4_0_2_visit[3]  R3152     -3
    e2_S4_0_2_visit[3]  R3418     1
    e2_S4_0_2_visit[4]  R654      21
    e2_S4_0_2_visit[4]  R655      2
    e2_S4_0_2_visit[4]  R670      -1
    e2_S4_0_2_visit[4]  R671      -1
    e2_S4_0_2_visit[4]  R672      1
    e2_S4_0_2_visit[4]  R689      -21
    e2_S4_0_2_visit[4]  R690      -21
    e2_S4_0_2_visit[4]  R691      -2
    e2_S4_0_2_visit[4]  R692      -2
    e2_S4_0_2_visit[4]  R694      -21
    e2_S4_0_2_visit[4]  R695      -21
    e2_S4_0_2_visit[4]  R696      -2
    e2_S4_0_2_visit[4]  R697      -2
    e2_S4_0_2_visit[4]  R699      -21
    e2_S4_0_2_visit[4]  R700      -21
    e2_S4_0_2_visit[4]  R701      -2
    e2_S4_0_2_visit[4]  R702      -2
    e2_S4_0_2_visit[4]  R704      -21
    e2_S4_0_2_visit[4]  R705      -21
    e2_S4_0_2_visit[4]  R706      -2
    e2_S4_0_2_visit[4]  R707      -2
    e2_S4_0_2_visit[4]  R709      -21
    e2_S4_0_2_visit[4]  R710      -21
    e2_S4_0_2_visit[4]  R711      -2
    e2_S4_0_2_visit[4]  R712      -2
    e2_S4_0_2_visit[4]  R714      -21
    e2_S4_0_2_visit[4]  R715      -21
    e2_S4_0_2_visit[4]  R716      -2
    e2_S4_0_2_visit[4]  R717      -2
    e2_S4_0_2_visit[4]  R719      -21
    e2_S4_0_2_visit[4]  R720      -21
    e2_S4_0_2_visit[4]  R721      -2
    e2_S4_0_2_visit[4]  R722      -2
    e2_S4_0_2_visit[4]  R724      -21
    e2_S4_0_2_visit[4]  R725      -21
    e2_S4_0_2_visit[4]  R726      -2
    e2_S4_0_2_visit[4]  R727      -2
    e2_S4_0_2_visit[4]  R729      -21
    e2_S4_0_2_visit[4]  R730      -21
    e2_S4_0_2_visit[4]  R731      -2
    e2_S4_0_2_visit[4]  R732      -2
    e2_S4_0_2_visit[4]  R734      -21
    e2_S4_0_2_visit[4]  R735      -21
    e2_S4_0_2_visit[4]  R736      -2
    e2_S4_0_2_visit[4]  R737      -2
    e2_S4_0_2_visit[4]  R757      -1
    e2_S4_0_2_visit[4]  R759      21
    e2_S4_0_2_visit[4]  R760      2
    e2_S4_0_2_visit[4]  R771      1
    e2_S4_0_2_visit[4]  R3155     -3
    e2_S4_0_2_visit[4]  R3421     1
    e2_S4_0_2_visit[5]  R656      4
    e2_S4_0_2_visit[5]  R657      2
    e2_S4_0_2_visit[5]  R673      -1
    e2_S4_0_2_visit[5]  R674      -1
    e2_S4_0_2_visit[5]  R675      1
    e2_S4_0_2_visit[5]  R772      -25749
    e2_S4_0_2_visit[5]  R773      71100
    e2_S4_0_2_visit[5]  R3158     -3
    e2_S4_0_2_visit[5]  R3422     1
    e2_S4_0_2_visit[6]  R654      23
    e2_S4_0_2_visit[6]  R655      2
    e2_S4_0_2_visit[6]  R676      -1
    e2_S4_0_2_visit[6]  R677      -1
    e2_S4_0_2_visit[6]  R678      1
    e2_S4_0_2_visit[6]  R689      -23
    e2_S4_0_2_visit[6]  R690      -23
    e2_S4_0_2_visit[6]  R691      -2
    e2_S4_0_2_visit[6]  R692      -2
    e2_S4_0_2_visit[6]  R694      -23
    e2_S4_0_2_visit[6]  R695      -23
    e2_S4_0_2_visit[6]  R696      -2
    e2_S4_0_2_visit[6]  R697      -2
    e2_S4_0_2_visit[6]  R699      -23
    e2_S4_0_2_visit[6]  R700      -23
    e2_S4_0_2_visit[6]  R701      -2
    e2_S4_0_2_visit[6]  R702      -2
    e2_S4_0_2_visit[6]  R704      -23
    e2_S4_0_2_visit[6]  R705      -23
    e2_S4_0_2_visit[6]  R706      -2
    e2_S4_0_2_visit[6]  R707      -2
    e2_S4_0_2_visit[6]  R709      -23
    e2_S4_0_2_visit[6]  R710      -23
    e2_S4_0_2_visit[6]  R711      -2
    e2_S4_0_2_visit[6]  R712      -2
    e2_S4_0_2_visit[6]  R714      -23
    e2_S4_0_2_visit[6]  R715      -23
    e2_S4_0_2_visit[6]  R716      -2
    e2_S4_0_2_visit[6]  R717      -2
    e2_S4_0_2_visit[6]  R719      -23
    e2_S4_0_2_visit[6]  R720      -23
    e2_S4_0_2_visit[6]  R721      -2
    e2_S4_0_2_visit[6]  R722      -2
    e2_S4_0_2_visit[6]  R724      -23
    e2_S4_0_2_visit[6]  R725      -23
    e2_S4_0_2_visit[6]  R726      -2
    e2_S4_0_2_visit[6]  R727      -2
    e2_S4_0_2_visit[6]  R729      -23
    e2_S4_0_2_visit[6]  R730      -23
    e2_S4_0_2_visit[6]  R731      -2
    e2_S4_0_2_visit[6]  R732      -2
    e2_S4_0_2_visit[6]  R734      -23
    e2_S4_0_2_visit[6]  R735      -23
    e2_S4_0_2_visit[6]  R736      -2
    e2_S4_0_2_visit[6]  R737      -2
    e2_S4_0_2_visit[6]  R757      -1
    e2_S4_0_2_visit[6]  R759      23
    e2_S4_0_2_visit[6]  R760      2
    e2_S4_0_2_visit[6]  R774      1
    e2_S4_0_2_visit[6]  R3161     -3
    e2_S4_0_2_visit[6]  R3425     1
    e2_S4_0_2_visit[7]  R656      4
    e2_S4_0_2_visit[7]  R657      2
    e2_S4_0_2_visit[7]  R679      -1
    e2_S4_0_2_visit[7]  R680      -1
    e2_S4_0_2_visit[7]  R681      1
    e2_S4_0_2_visit[7]  R775      -23969
    e2_S4_0_2_visit[7]  R776      71100
    e2_S4_0_2_visit[7]  R3164     -3
    e2_S4_0_2_visit[7]  R3426     1
    e2_S4_0_2_visit[8]  R654      21
    e2_S4_0_2_visit[8]  R655      2
    e2_S4_0_2_visit[8]  R682      -1
    e2_S4_0_2_visit[8]  R683      -1
    e2_S4_0_2_visit[8]  R684      1
    e2_S4_0_2_visit[8]  R689      -21
    e2_S4_0_2_visit[8]  R690      -21
    e2_S4_0_2_visit[8]  R691      -2
    e2_S4_0_2_visit[8]  R692      -2
    e2_S4_0_2_visit[8]  R694      -21
    e2_S4_0_2_visit[8]  R695      -21
    e2_S4_0_2_visit[8]  R696      -2
    e2_S4_0_2_visit[8]  R697      -2
    e2_S4_0_2_visit[8]  R699      -21
    e2_S4_0_2_visit[8]  R700      -21
    e2_S4_0_2_visit[8]  R701      -2
    e2_S4_0_2_visit[8]  R702      -2
    e2_S4_0_2_visit[8]  R704      -21
    e2_S4_0_2_visit[8]  R705      -21
    e2_S4_0_2_visit[8]  R706      -2
    e2_S4_0_2_visit[8]  R707      -2
    e2_S4_0_2_visit[8]  R709      -21
    e2_S4_0_2_visit[8]  R710      -21
    e2_S4_0_2_visit[8]  R711      -2
    e2_S4_0_2_visit[8]  R712      -2
    e2_S4_0_2_visit[8]  R714      -21
    e2_S4_0_2_visit[8]  R715      -21
    e2_S4_0_2_visit[8]  R716      -2
    e2_S4_0_2_visit[8]  R717      -2
    e2_S4_0_2_visit[8]  R719      -21
    e2_S4_0_2_visit[8]  R720      -21
    e2_S4_0_2_visit[8]  R721      -2
    e2_S4_0_2_visit[8]  R722      -2
    e2_S4_0_2_visit[8]  R724      -21
    e2_S4_0_2_visit[8]  R725      -21
    e2_S4_0_2_visit[8]  R726      -2
    e2_S4_0_2_visit[8]  R727      -2
    e2_S4_0_2_visit[8]  R729      -21
    e2_S4_0_2_visit[8]  R730      -21
    e2_S4_0_2_visit[8]  R731      -2
    e2_S4_0_2_visit[8]  R732      -2
    e2_S4_0_2_visit[8]  R734      -21
    e2_S4_0_2_visit[8]  R735      -21
    e2_S4_0_2_visit[8]  R736      -2
    e2_S4_0_2_visit[8]  R737      -2
    e2_S4_0_2_visit[8]  R761      -1
    e2_S4_0_2_visit[8]  R763      21
    e2_S4_0_2_visit[8]  R764      2
    e2_S4_0_2_visit[8]  R777      1
    e2_S4_0_2_visit[8]  R3167     -3
    e2_S4_0_2_visit[8]  R3429     1
    e2_S4_0_2_visit[9]  R656      4
    e2_S4_0_2_visit[9]  R657      2
    e2_S4_0_2_visit[9]  R685      -1
    e2_S4_0_2_visit[9]  R686      -1
    e2_S4_0_2_visit[9]  R687      1
    e2_S4_0_2_visit[9]  R778      -11425
    e2_S4_0_2_visit[9]  R779      71100
    e2_S4_0_2_visit[9]  R3170     -3
    e2_S4_0_2_visit[9]  R3430     1
    e2_S4_0_2_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_2_arc[-1,0]  R652      1
    e2_S4_0_2_arc[-1,0]  R658      1
    e2_S4_0_2_arc[-1,0]  R688      -44319
    e2_S4_0_2_arc[-1,0]  R689      -165
    e2_S4_0_2_arc[-1,0]  R690      180
    e2_S4_0_2_arc[-1,0]  R691      -5
    e2_S4_0_2_arc[-1,0]  R692      6
    e2_S4_0_2_arc[-1,0]  R780      -30
    e2_S4_0_2_arc[-1,0]  R3144     1
    e2_S4_0_2_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_2_arc[-1,1]  R652      1
    e2_S4_0_2_arc[-1,1]  R661      1
    e2_S4_0_2_arc[-1,1]  R693      -41683
    e2_S4_0_2_arc[-1,1]  R694      -180
    e2_S4_0_2_arc[-1,1]  R695      178
    e2_S4_0_2_arc[-1,1]  R696      -6
    e2_S4_0_2_arc[-1,1]  R697      5
    e2_S4_0_2_arc[-1,1]  R781      -30
    e2_S4_0_2_arc[-1,1]  R3147     1
    e2_S4_0_2_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_2_arc[-1,2]  R652      1
    e2_S4_0_2_arc[-1,2]  R664      1
    e2_S4_0_2_arc[-1,2]  R698      -44289
    e2_S4_0_2_arc[-1,2]  R699      -157
    e2_S4_0_2_arc[-1,2]  R700      180
    e2_S4_0_2_arc[-1,2]  R701      -4
    e2_S4_0_2_arc[-1,2]  R702      6
    e2_S4_0_2_arc[-1,2]  R782      -30
    e2_S4_0_2_arc[-1,2]  R3150     1
    e2_S4_0_2_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_2_arc[-1,3]  R652      1
    e2_S4_0_2_arc[-1,3]  R667      1
    e2_S4_0_2_arc[-1,3]  R703      -40989
    e2_S4_0_2_arc[-1,3]  R704      -180
    e2_S4_0_2_arc[-1,3]  R705      176
    e2_S4_0_2_arc[-1,3]  R706      -6
    e2_S4_0_2_arc[-1,3]  R707      4
    e2_S4_0_2_arc[-1,3]  R783      -30
    e2_S4_0_2_arc[-1,3]  R3153     1
    e2_S4_0_2_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_2_arc[-1,4]  R652      1
    e2_S4_0_2_arc[-1,4]  R670      1
    e2_S4_0_2_arc[-1,4]  R708      -29919
    e2_S4_0_2_arc[-1,4]  R709      -159
    e2_S4_0_2_arc[-1,4]  R710      180
    e2_S4_0_2_arc[-1,4]  R711      -4
    e2_S4_0_2_arc[-1,4]  R712      6
    e2_S4_0_2_arc[-1,4]  R784      -30
    e2_S4_0_2_arc[-1,4]  R3156     1
    e2_S4_0_2_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_2_arc[-1,5]  R652      1
    e2_S4_0_2_arc[-1,5]  R673      1
    e2_S4_0_2_arc[-1,5]  R713      -26919
    e2_S4_0_2_arc[-1,5]  R714      -180
    e2_S4_0_2_arc[-1,5]  R715      176
    e2_S4_0_2_arc[-1,5]  R716      -6
    e2_S4_0_2_arc[-1,5]  R717      4
    e2_S4_0_2_arc[-1,5]  R785      -30
    e2_S4_0_2_arc[-1,5]  R3159     1
    e2_S4_0_2_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_2_arc[-1,6]  R652      1
    e2_S4_0_2_arc[-1,6]  R676      1
    e2_S4_0_2_arc[-1,6]  R718      -29851
    e2_S4_0_2_arc[-1,6]  R719      -157
    e2_S4_0_2_arc[-1,6]  R720      180
    e2_S4_0_2_arc[-1,6]  R721      -4
    e2_S4_0_2_arc[-1,6]  R722      6
    e2_S4_0_2_arc[-1,6]  R786      -30
    e2_S4_0_2_arc[-1,6]  R3162     1
    e2_S4_0_2_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_2_arc[-1,7]  R652      1
    e2_S4_0_2_arc[-1,7]  R679      1
    e2_S4_0_2_arc[-1,7]  R723      -25651
    e2_S4_0_2_arc[-1,7]  R724      -180
    e2_S4_0_2_arc[-1,7]  R725      176
    e2_S4_0_2_arc[-1,7]  R726      -6
    e2_S4_0_2_arc[-1,7]  R727      4
    e2_S4_0_2_arc[-1,7]  R787      -30
    e2_S4_0_2_arc[-1,7]  R3165     1
    e2_S4_0_2_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_2_arc[-1,8]  R652      1
    e2_S4_0_2_arc[-1,8]  R682      1
    e2_S4_0_2_arc[-1,8]  R728      -15519
    e2_S4_0_2_arc[-1,8]  R729      -159
    e2_S4_0_2_arc[-1,8]  R730      180
    e2_S4_0_2_arc[-1,8]  R731      -4
    e2_S4_0_2_arc[-1,8]  R732      6
    e2_S4_0_2_arc[-1,8]  R788      -30
    e2_S4_0_2_arc[-1,8]  R3168     1
    e2_S4_0_2_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_2_arc[-1,9]  R652      1
    e2_S4_0_2_arc[-1,9]  R685      1
    e2_S4_0_2_arc[-1,9]  R733      -13119
    e2_S4_0_2_arc[-1,9]  R734      -180
    e2_S4_0_2_arc[-1,9]  R735      176
    e2_S4_0_2_arc[-1,9]  R736      -6
    e2_S4_0_2_arc[-1,9]  R737      4
    e2_S4_0_2_arc[-1,9]  R789      -30
    e2_S4_0_2_arc[-1,9]  R3171     1
    e2_S4_0_2_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_2_arc[0,-2]  R653      1
    e2_S4_0_2_arc[0,-2]  R659      1
    e2_S4_0_2_arc[0,-2]  R738      -33523
    e2_S4_0_2_arc[0,-2]  R790      -30
    e2_S4_0_2_arc[0,-2]  R3145     1
    e2_S4_0_2_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_2_arc[1,-2]  R653      1
    e2_S4_0_2_arc[1,-2]  R662      1
    e2_S4_0_2_arc[1,-2]  R739      -39223
    e2_S4_0_2_arc[1,-2]  R791      -30
    e2_S4_0_2_arc[1,-2]  R3148     1
    e2_S4_0_2_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_2_arc[2,-2]  R653      1
    e2_S4_0_2_arc[2,-2]  R665      1
    e2_S4_0_2_arc[2,-2]  R740      -36369
    e2_S4_0_2_arc[2,-2]  R792      -30
    e2_S4_0_2_arc[2,-2]  R3151     1
    e2_S4_0_2_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_2_arc[3,-2]  R653      1
    e2_S4_0_2_arc[3,-2]  R668      1
    e2_S4_0_2_arc[3,-2]  R741      -42129
    e2_S4_0_2_arc[3,-2]  R793      -30
    e2_S4_0_2_arc[3,-2]  R3154     1
    e2_S4_0_2_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_2_arc[4,-2]  R653      1
    e2_S4_0_2_arc[4,-2]  R671      1
    e2_S4_0_2_arc[4,-2]  R742      -48315
    e2_S4_0_2_arc[4,-2]  R794      -30
    e2_S4_0_2_arc[4,-2]  R3157     1
    e2_S4_0_2_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_2_arc[5,-2]  R653      1
    e2_S4_0_2_arc[5,-2]  R674      1
    e2_S4_0_2_arc[5,-2]  R743      -53475
    e2_S4_0_2_arc[5,-2]  R795      -30
    e2_S4_0_2_arc[5,-2]  R3160     1
    e2_S4_0_2_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_2_arc[6,-2]  R653      1
    e2_S4_0_2_arc[6,-2]  R677      1
    e2_S4_0_2_arc[6,-2]  R744      -49531
    e2_S4_0_2_arc[6,-2]  R796      -30
    e2_S4_0_2_arc[6,-2]  R3163     1
    e2_S4_0_2_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_2_arc[7,-2]  R653      1
    e2_S4_0_2_arc[7,-2]  R680      1
    e2_S4_0_2_arc[7,-2]  R745      -56191
    e2_S4_0_2_arc[7,-2]  R797      -30
    e2_S4_0_2_arc[7,-2]  R3166     1
    e2_S4_0_2_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_2_arc[8,-2]  R653      1
    e2_S4_0_2_arc[8,-2]  R683      1
    e2_S4_0_2_arc[8,-2]  R746      -63217
    e2_S4_0_2_arc[8,-2]  R798      -30
    e2_S4_0_2_arc[8,-2]  R3169     1
    e2_S4_0_2_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_2_arc[9,-2]  R653      1
    e2_S4_0_2_arc[9,-2]  R686      1
    e2_S4_0_2_arc[9,-2]  R747      -68677
    e2_S4_0_2_arc[9,-2]  R799      -30
    e2_S4_0_2_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C617      R750      1
    C617      R780      -1
    C617      R781      -1
    C617      R782      -1
    C617      R783      -1
    C617      R784      -1
    C617      R785      -1
    C617      R786      -1
    C617      R787      -1
    C617      R788      -1
    C617      R789      -1
    C618      R790      1
    C618      R791      1
    C618      R792      1
    C618      R793      1
    C618      R794      1
    C618      R795      1
    C618      R796      1
    C618      R797      1
    C618      R798      1
    C618      R799      1
    C618      R901      -1
    MARKER    'MARKER'                 'INTORG'
    C619      R751      1
    C619      R752      -60
    C619      R753      1
    C619      R754      -39660
    C619      R755      -180
    C619      R756      -6
    C619      R765      -1
    C619      R768      -1
    C620      R751      1
    C620      R752      -60
    C620      R757      1
    C620      R758      -54060
    C620      R759      -180
    C620      R760      -6
    C620      R771      -1
    C620      R774      -1
    C621      R751      1
    C621      R752      -60
    C621      R761      1
    C621      R762      -71160
    C621      R763      -180
    C621      R764      -6
    C621      R777      -1
    e2_S4_0_3_used  R800      -75600
    e2_S4_0_3_used  R801      -75600
    e2_S4_0_3_used  R802      -28800
    e2_S4_0_3_used  R803      -1
    e2_S4_0_3_used  R804      -1
    e2_S4_0_3_used  R805      -180
    e2_S4_0_3_used  R806      -6
    e2_S4_0_3_used  R807      -180
    e2_S4_0_3_used  R808      -6
    e2_S4_0_3_used  R811      -1
    e2_S4_0_3_used  R814      -1
    e2_S4_0_3_used  R817      -1
    e2_S4_0_3_used  R820      -1
    e2_S4_0_3_used  R823      -1
    e2_S4_0_3_used  R826      -1
    e2_S4_0_3_used  R829      -1
    e2_S4_0_3_used  R832      -1
    e2_S4_0_3_used  R835      -1
    e2_S4_0_3_used  R838      -1
    e2_S4_0_3_used  R899      -75540
    e2_S4_0_3_used  R900      1
    e2_S4_0_3_used  R901      -30
    e2_S4_0_3_used  R902      -1
    e2_S4_0_3_used  R903      -75600
    e2_S4_0_3_used  R1051     -1
    e2_S4_0_3_used  R2610     -1
    e2_S4_0_3_start  R800      1
    e2_S4_0_3_start  R802      1
    e2_S4_0_3_start  R839      -1
    e2_S4_0_3_start  R844      -1
    e2_S4_0_3_start  R849      -1
    e2_S4_0_3_start  R854      -1
    e2_S4_0_3_start  R859      -1
    e2_S4_0_3_start  R864      -1
    e2_S4_0_3_start  R869      -1
    e2_S4_0_3_start  R874      -1
    e2_S4_0_3_start  R879      -1
    e2_S4_0_3_start  R884      -1
    e2_S4_0_3_start  R903      1
    e2_S4_0_3_start  R905      1
    e2_S4_0_3_start  R909      1
    e2_S4_0_3_start  R913      1
    e2_S4_0_3_end  R801      1
    e2_S4_0_3_end  R889      1
    e2_S4_0_3_end  R890      1
    e2_S4_0_3_end  R891      1
    e2_S4_0_3_end  R892      1
    e2_S4_0_3_end  R893      1
    e2_S4_0_3_end  R894      1
    e2_S4_0_3_end  R895      1
    e2_S4_0_3_end  R896      1
    e2_S4_0_3_end  R897      1
    e2_S4_0_3_end  R898      1
    e2_S4_0_3_end  R899      1
    e2_S4_0_3_end  R917      -1
    e2_S4_0_3_end  R918      -1
    e2_S4_0_3_end  R920      -1
    e2_S4_0_3_end  R921      -1
    e2_S4_0_3_end  R923      -1
    e2_S4_0_3_end  R924      -1
    e2_S4_0_3_end  R926      -1
    e2_S4_0_3_end  R927      -1
    e2_S4_0_3_end  R929      -1
    e2_S4_0_3_end  R930      -1
    e2_S4_0_3_end  R1054     -1
    e2_S4_0_3_visit[0]  R805      15
    e2_S4_0_3_visit[0]  R806      1
    e2_S4_0_3_visit[0]  R809      -1
    e2_S4_0_3_visit[0]  R810      -1
    e2_S4_0_3_visit[0]  R811      1
    e2_S4_0_3_visit[0]  R840      -15
    e2_S4_0_3_visit[0]  R841      -15
    e2_S4_0_3_visit[0]  R842      -1
    e2_S4_0_3_visit[0]  R843      -1
    e2_S4_0_3_visit[0]  R845      -15
    e2_S4_0_3_visit[0]  R846      -15
    e2_S4_0_3_visit[0]  R847      -1
    e2_S4_0_3_visit[0]  R848      -1
    e2_S4_0_3_visit[0]  R850      -15
    e2_S4_0_3_visit[0]  R851      -15
    e2_S4_0_3_visit[0]  R852      -1
    e2_S4_0_3_visit[0]  R853      -1
    e2_S4_0_3_visit[0]  R855      -15
    e2_S4_0_3_visit[0]  R856      -15
    e2_S4_0_3_visit[0]  R857      -1
    e2_S4_0_3_visit[0]  R858      -1
    e2_S4_0_3_visit[0]  R860      -15
    e2_S4_0_3_visit[0]  R861      -15
    e2_S4_0_3_visit[0]  R862      -1
    e2_S4_0_3_visit[0]  R863      -1
    e2_S4_0_3_visit[0]  R865      -15
    e2_S4_0_3_visit[0]  R866      -15
    e2_S4_0_3_visit[0]  R867      -1
    e2_S4_0_3_visit[0]  R868      -1
    e2_S4_0_3_visit[0]  R870      -15
    e2_S4_0_3_visit[0]  R871      -15
    e2_S4_0_3_visit[0]  R872      -1
    e2_S4_0_3_visit[0]  R873      -1
    e2_S4_0_3_visit[0]  R875      -15
    e2_S4_0_3_visit[0]  R876      -15
    e2_S4_0_3_visit[0]  R877      -1
    e2_S4_0_3_visit[0]  R878      -1
    e2_S4_0_3_visit[0]  R880      -15
    e2_S4_0_3_visit[0]  R881      -15
    e2_S4_0_3_visit[0]  R882      -1
    e2_S4_0_3_visit[0]  R883      -1
    e2_S4_0_3_visit[0]  R885      -15
    e2_S4_0_3_visit[0]  R886      -15
    e2_S4_0_3_visit[0]  R887      -1
    e2_S4_0_3_visit[0]  R888      -1
    e2_S4_0_3_visit[0]  R904      -1
    e2_S4_0_3_visit[0]  R906      15
    e2_S4_0_3_visit[0]  R907      1
    e2_S4_0_3_visit[0]  R916      1
    e2_S4_0_3_visit[0]  R3143     -4
    e2_S4_0_3_visit[0]  R3413     1
    e2_S4_0_3_visit[1]  R807      2
    e2_S4_0_3_visit[1]  R808      1
    e2_S4_0_3_visit[1]  R812      -1
    e2_S4_0_3_visit[1]  R813      -1
    e2_S4_0_3_visit[1]  R814      1
    e2_S4_0_3_visit[1]  R917      -40937
    e2_S4_0_3_visit[1]  R918      71100
    e2_S4_0_3_visit[1]  R3146     -4
    e2_S4_0_3_visit[1]  R3414     1
    e2_S4_0_3_visit[2]  R805      23
    e2_S4_0_3_visit[2]  R806      2
    e2_S4_0_3_visit[2]  R815      -1
    e2_S4_0_3_visit[2]  R816      -1
    e2_S4_0_3_visit[2]  R817      1
    e2_S4_0_3_visit[2]  R840      -23
    e2_S4_0_3_visit[2]  R841      -23
    e2_S4_0_3_visit[2]  R842      -2
    e2_S4_0_3_visit[2]  R843      -2
    e2_S4_0_3_visit[2]  R845      -23
    e2_S4_0_3_visit[2]  R846      -23
    e2_S4_0_3_visit[2]  R847      -2
    e2_S4_0_3_visit[2]  R848      -2
    e2_S4_0_3_visit[2]  R850      -23
    e2_S4_0_3_visit[2]  R851      -23
    e2_S4_0_3_visit[2]  R852      -2
    e2_S4_0_3_visit[2]  R853      -2
    e2_S4_0_3_visit[2]  R855      -23
    e2_S4_0_3_visit[2]  R856      -23
    e2_S4_0_3_visit[2]  R857      -2
    e2_S4_0_3_visit[2]  R858      -2
    e2_S4_0_3_visit[2]  R860      -23
    e2_S4_0_3_visit[2]  R861      -23
    e2_S4_0_3_visit[2]  R862      -2
    e2_S4_0_3_visit[2]  R863      -2
    e2_S4_0_3_visit[2]  R865      -23
    e2_S4_0_3_visit[2]  R866      -23
    e2_S4_0_3_visit[2]  R867      -2
    e2_S4_0_3_visit[2]  R868      -2
    e2_S4_0_3_visit[2]  R870      -23
    e2_S4_0_3_visit[2]  R871      -23
    e2_S4_0_3_visit[2]  R872      -2
    e2_S4_0_3_visit[2]  R873      -2
    e2_S4_0_3_visit[2]  R875      -23
    e2_S4_0_3_visit[2]  R876      -23
    e2_S4_0_3_visit[2]  R877      -2
    e2_S4_0_3_visit[2]  R878      -2
    e2_S4_0_3_visit[2]  R880      -23
    e2_S4_0_3_visit[2]  R881      -23
    e2_S4_0_3_visit[2]  R882      -2
    e2_S4_0_3_visit[2]  R883      -2
    e2_S4_0_3_visit[2]  R885      -23
    e2_S4_0_3_visit[2]  R886      -23
    e2_S4_0_3_visit[2]  R887      -2
    e2_S4_0_3_visit[2]  R888      -2
    e2_S4_0_3_visit[2]  R904      -1
    e2_S4_0_3_visit[2]  R906      23
    e2_S4_0_3_visit[2]  R907      2
    e2_S4_0_3_visit[2]  R919      1
    e2_S4_0_3_visit[2]  R3149     -4
    e2_S4_0_3_visit[2]  R3417     1
    e2_S4_0_3_visit[3]  R807      4
    e2_S4_0_3_visit[3]  R808      2
    e2_S4_0_3_visit[3]  R818      -1
    e2_S4_0_3_visit[3]  R819      -1
    e2_S4_0_3_visit[3]  R820      1
    e2_S4_0_3_visit[3]  R920      -38031
    e2_S4_0_3_visit[3]  R921      71100
    e2_S4_0_3_visit[3]  R3152     -4
    e2_S4_0_3_visit[3]  R3418     1
    e2_S4_0_3_visit[4]  R805      21
    e2_S4_0_3_visit[4]  R806      2
    e2_S4_0_3_visit[4]  R821      -1
    e2_S4_0_3_visit[4]  R822      -1
    e2_S4_0_3_visit[4]  R823      1
    e2_S4_0_3_visit[4]  R840      -21
    e2_S4_0_3_visit[4]  R841      -21
    e2_S4_0_3_visit[4]  R842      -2
    e2_S4_0_3_visit[4]  R843      -2
    e2_S4_0_3_visit[4]  R845      -21
    e2_S4_0_3_visit[4]  R846      -21
    e2_S4_0_3_visit[4]  R847      -2
    e2_S4_0_3_visit[4]  R848      -2
    e2_S4_0_3_visit[4]  R850      -21
    e2_S4_0_3_visit[4]  R851      -21
    e2_S4_0_3_visit[4]  R852      -2
    e2_S4_0_3_visit[4]  R853      -2
    e2_S4_0_3_visit[4]  R855      -21
    e2_S4_0_3_visit[4]  R856      -21
    e2_S4_0_3_visit[4]  R857      -2
    e2_S4_0_3_visit[4]  R858      -2
    e2_S4_0_3_visit[4]  R860      -21
    e2_S4_0_3_visit[4]  R861      -21
    e2_S4_0_3_visit[4]  R862      -2
    e2_S4_0_3_visit[4]  R863      -2
    e2_S4_0_3_visit[4]  R865      -21
    e2_S4_0_3_visit[4]  R866      -21
    e2_S4_0_3_visit[4]  R867      -2
    e2_S4_0_3_visit[4]  R868      -2
    e2_S4_0_3_visit[4]  R870      -21
    e2_S4_0_3_visit[4]  R871      -21
    e2_S4_0_3_visit[4]  R872      -2
    e2_S4_0_3_visit[4]  R873      -2
    e2_S4_0_3_visit[4]  R875      -21
    e2_S4_0_3_visit[4]  R876      -21
    e2_S4_0_3_visit[4]  R877      -2
    e2_S4_0_3_visit[4]  R878      -2
    e2_S4_0_3_visit[4]  R880      -21
    e2_S4_0_3_visit[4]  R881      -21
    e2_S4_0_3_visit[4]  R882      -2
    e2_S4_0_3_visit[4]  R883      -2
    e2_S4_0_3_visit[4]  R885      -21
    e2_S4_0_3_visit[4]  R886      -21
    e2_S4_0_3_visit[4]  R887      -2
    e2_S4_0_3_visit[4]  R888      -2
    e2_S4_0_3_visit[4]  R908      -1
    e2_S4_0_3_visit[4]  R910      21
    e2_S4_0_3_visit[4]  R911      2
    e2_S4_0_3_visit[4]  R922      1
    e2_S4_0_3_visit[4]  R3155     -4
    e2_S4_0_3_visit[4]  R3421     1
    e2_S4_0_3_visit[5]  R807      4
    e2_S4_0_3_visit[5]  R808      2
    e2_S4_0_3_visit[5]  R824      -1
    e2_S4_0_3_visit[5]  R825      -1
    e2_S4_0_3_visit[5]  R826      1
    e2_S4_0_3_visit[5]  R923      -25749
    e2_S4_0_3_visit[5]  R924      71100
    e2_S4_0_3_visit[5]  R3158     -4
    e2_S4_0_3_visit[5]  R3422     1
    e2_S4_0_3_visit[6]  R805      23
    e2_S4_0_3_visit[6]  R806      2
    e2_S4_0_3_visit[6]  R827      -1
    e2_S4_0_3_visit[6]  R828      -1
    e2_S4_0_3_visit[6]  R829      1
    e2_S4_0_3_visit[6]  R840      -23
    e2_S4_0_3_visit[6]  R841      -23
    e2_S4_0_3_visit[6]  R842      -2
    e2_S4_0_3_visit[6]  R843      -2
    e2_S4_0_3_visit[6]  R845      -23
    e2_S4_0_3_visit[6]  R846      -23
    e2_S4_0_3_visit[6]  R847      -2
    e2_S4_0_3_visit[6]  R848      -2
    e2_S4_0_3_visit[6]  R850      -23
    e2_S4_0_3_visit[6]  R851      -23
    e2_S4_0_3_visit[6]  R852      -2
    e2_S4_0_3_visit[6]  R853      -2
    e2_S4_0_3_visit[6]  R855      -23
    e2_S4_0_3_visit[6]  R856      -23
    e2_S4_0_3_visit[6]  R857      -2
    e2_S4_0_3_visit[6]  R858      -2
    e2_S4_0_3_visit[6]  R860      -23
    e2_S4_0_3_visit[6]  R861      -23
    e2_S4_0_3_visit[6]  R862      -2
    e2_S4_0_3_visit[6]  R863      -2
    e2_S4_0_3_visit[6]  R865      -23
    e2_S4_0_3_visit[6]  R866      -23
    e2_S4_0_3_visit[6]  R867      -2
    e2_S4_0_3_visit[6]  R868      -2
    e2_S4_0_3_visit[6]  R870      -23
    e2_S4_0_3_visit[6]  R871      -23
    e2_S4_0_3_visit[6]  R872      -2
    e2_S4_0_3_visit[6]  R873      -2
    e2_S4_0_3_visit[6]  R875      -23
    e2_S4_0_3_visit[6]  R876      -23
    e2_S4_0_3_visit[6]  R877      -2
    e2_S4_0_3_visit[6]  R878      -2
    e2_S4_0_3_visit[6]  R880      -23
    e2_S4_0_3_visit[6]  R881      -23
    e2_S4_0_3_visit[6]  R882      -2
    e2_S4_0_3_visit[6]  R883      -2
    e2_S4_0_3_visit[6]  R885      -23
    e2_S4_0_3_visit[6]  R886      -23
    e2_S4_0_3_visit[6]  R887      -2
    e2_S4_0_3_visit[6]  R888      -2
    e2_S4_0_3_visit[6]  R908      -1
    e2_S4_0_3_visit[6]  R910      23
    e2_S4_0_3_visit[6]  R911      2
    e2_S4_0_3_visit[6]  R925      1
    e2_S4_0_3_visit[6]  R3161     -4
    e2_S4_0_3_visit[6]  R3425     1
    e2_S4_0_3_visit[7]  R807      4
    e2_S4_0_3_visit[7]  R808      2
    e2_S4_0_3_visit[7]  R830      -1
    e2_S4_0_3_visit[7]  R831      -1
    e2_S4_0_3_visit[7]  R832      1
    e2_S4_0_3_visit[7]  R926      -23969
    e2_S4_0_3_visit[7]  R927      71100
    e2_S4_0_3_visit[7]  R3164     -4
    e2_S4_0_3_visit[7]  R3426     1
    e2_S4_0_3_visit[8]  R805      21
    e2_S4_0_3_visit[8]  R806      2
    e2_S4_0_3_visit[8]  R833      -1
    e2_S4_0_3_visit[8]  R834      -1
    e2_S4_0_3_visit[8]  R835      1
    e2_S4_0_3_visit[8]  R840      -21
    e2_S4_0_3_visit[8]  R841      -21
    e2_S4_0_3_visit[8]  R842      -2
    e2_S4_0_3_visit[8]  R843      -2
    e2_S4_0_3_visit[8]  R845      -21
    e2_S4_0_3_visit[8]  R846      -21
    e2_S4_0_3_visit[8]  R847      -2
    e2_S4_0_3_visit[8]  R848      -2
    e2_S4_0_3_visit[8]  R850      -21
    e2_S4_0_3_visit[8]  R851      -21
    e2_S4_0_3_visit[8]  R852      -2
    e2_S4_0_3_visit[8]  R853      -2
    e2_S4_0_3_visit[8]  R855      -21
    e2_S4_0_3_visit[8]  R856      -21
    e2_S4_0_3_visit[8]  R857      -2
    e2_S4_0_3_visit[8]  R858      -2
    e2_S4_0_3_visit[8]  R860      -21
    e2_S4_0_3_visit[8]  R861      -21
    e2_S4_0_3_visit[8]  R862      -2
    e2_S4_0_3_visit[8]  R863      -2
    e2_S4_0_3_visit[8]  R865      -21
    e2_S4_0_3_visit[8]  R866      -21
    e2_S4_0_3_visit[8]  R867      -2
    e2_S4_0_3_visit[8]  R868      -2
    e2_S4_0_3_visit[8]  R870      -21
    e2_S4_0_3_visit[8]  R871      -21
    e2_S4_0_3_visit[8]  R872      -2
    e2_S4_0_3_visit[8]  R873      -2
    e2_S4_0_3_visit[8]  R875      -21
    e2_S4_0_3_visit[8]  R876      -21
    e2_S4_0_3_visit[8]  R877      -2
    e2_S4_0_3_visit[8]  R878      -2
    e2_S4_0_3_visit[8]  R880      -21
    e2_S4_0_3_visit[8]  R881      -21
    e2_S4_0_3_visit[8]  R882      -2
    e2_S4_0_3_visit[8]  R883      -2
    e2_S4_0_3_visit[8]  R885      -21
    e2_S4_0_3_visit[8]  R886      -21
    e2_S4_0_3_visit[8]  R887      -2
    e2_S4_0_3_visit[8]  R888      -2
    e2_S4_0_3_visit[8]  R912      -1
    e2_S4_0_3_visit[8]  R914      21
    e2_S4_0_3_visit[8]  R915      2
    e2_S4_0_3_visit[8]  R928      1
    e2_S4_0_3_visit[8]  R3167     -4
    e2_S4_0_3_visit[8]  R3429     1
    e2_S4_0_3_visit[9]  R807      4
    e2_S4_0_3_visit[9]  R808      2
    e2_S4_0_3_visit[9]  R836      -1
    e2_S4_0_3_visit[9]  R837      -1
    e2_S4_0_3_visit[9]  R838      1
    e2_S4_0_3_visit[9]  R929      -11425
    e2_S4_0_3_visit[9]  R930      71100
    e2_S4_0_3_visit[9]  R3170     -4
    e2_S4_0_3_visit[9]  R3430     1
    e2_S4_0_3_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_3_arc[-1,0]  R803      1
    e2_S4_0_3_arc[-1,0]  R809      1
    e2_S4_0_3_arc[-1,0]  R839      -44319
    e2_S4_0_3_arc[-1,0]  R840      -165
    e2_S4_0_3_arc[-1,0]  R841      180
    e2_S4_0_3_arc[-1,0]  R842      -5
    e2_S4_0_3_arc[-1,0]  R843      6
    e2_S4_0_3_arc[-1,0]  R931      -30
    e2_S4_0_3_arc[-1,0]  R3144     1
    e2_S4_0_3_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_3_arc[-1,1]  R803      1
    e2_S4_0_3_arc[-1,1]  R812      1
    e2_S4_0_3_arc[-1,1]  R844      -41683
    e2_S4_0_3_arc[-1,1]  R845      -180
    e2_S4_0_3_arc[-1,1]  R846      178
    e2_S4_0_3_arc[-1,1]  R847      -6
    e2_S4_0_3_arc[-1,1]  R848      5
    e2_S4_0_3_arc[-1,1]  R932      -30
    e2_S4_0_3_arc[-1,1]  R3147     1
    e2_S4_0_3_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_3_arc[-1,2]  R803      1
    e2_S4_0_3_arc[-1,2]  R815      1
    e2_S4_0_3_arc[-1,2]  R849      -44289
    e2_S4_0_3_arc[-1,2]  R850      -157
    e2_S4_0_3_arc[-1,2]  R851      180
    e2_S4_0_3_arc[-1,2]  R852      -4
    e2_S4_0_3_arc[-1,2]  R853      6
    e2_S4_0_3_arc[-1,2]  R933      -30
    e2_S4_0_3_arc[-1,2]  R3150     1
    e2_S4_0_3_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_3_arc[-1,3]  R803      1
    e2_S4_0_3_arc[-1,3]  R818      1
    e2_S4_0_3_arc[-1,3]  R854      -40989
    e2_S4_0_3_arc[-1,3]  R855      -180
    e2_S4_0_3_arc[-1,3]  R856      176
    e2_S4_0_3_arc[-1,3]  R857      -6
    e2_S4_0_3_arc[-1,3]  R858      4
    e2_S4_0_3_arc[-1,3]  R934      -30
    e2_S4_0_3_arc[-1,3]  R3153     1
    e2_S4_0_3_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_3_arc[-1,4]  R803      1
    e2_S4_0_3_arc[-1,4]  R821      1
    e2_S4_0_3_arc[-1,4]  R859      -29919
    e2_S4_0_3_arc[-1,4]  R860      -159
    e2_S4_0_3_arc[-1,4]  R861      180
    e2_S4_0_3_arc[-1,4]  R862      -4
    e2_S4_0_3_arc[-1,4]  R863      6
    e2_S4_0_3_arc[-1,4]  R935      -30
    e2_S4_0_3_arc[-1,4]  R3156     1
    e2_S4_0_3_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_3_arc[-1,5]  R803      1
    e2_S4_0_3_arc[-1,5]  R824      1
    e2_S4_0_3_arc[-1,5]  R864      -26919
    e2_S4_0_3_arc[-1,5]  R865      -180
    e2_S4_0_3_arc[-1,5]  R866      176
    e2_S4_0_3_arc[-1,5]  R867      -6
    e2_S4_0_3_arc[-1,5]  R868      4
    e2_S4_0_3_arc[-1,5]  R936      -30
    e2_S4_0_3_arc[-1,5]  R3159     1
    e2_S4_0_3_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_3_arc[-1,6]  R803      1
    e2_S4_0_3_arc[-1,6]  R827      1
    e2_S4_0_3_arc[-1,6]  R869      -29851
    e2_S4_0_3_arc[-1,6]  R870      -157
    e2_S4_0_3_arc[-1,6]  R871      180
    e2_S4_0_3_arc[-1,6]  R872      -4
    e2_S4_0_3_arc[-1,6]  R873      6
    e2_S4_0_3_arc[-1,6]  R937      -30
    e2_S4_0_3_arc[-1,6]  R3162     1
    e2_S4_0_3_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_3_arc[-1,7]  R803      1
    e2_S4_0_3_arc[-1,7]  R830      1
    e2_S4_0_3_arc[-1,7]  R874      -25651
    e2_S4_0_3_arc[-1,7]  R875      -180
    e2_S4_0_3_arc[-1,7]  R876      176
    e2_S4_0_3_arc[-1,7]  R877      -6
    e2_S4_0_3_arc[-1,7]  R878      4
    e2_S4_0_3_arc[-1,7]  R938      -30
    e2_S4_0_3_arc[-1,7]  R3165     1
    e2_S4_0_3_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_3_arc[-1,8]  R803      1
    e2_S4_0_3_arc[-1,8]  R833      1
    e2_S4_0_3_arc[-1,8]  R879      -15519
    e2_S4_0_3_arc[-1,8]  R880      -159
    e2_S4_0_3_arc[-1,8]  R881      180
    e2_S4_0_3_arc[-1,8]  R882      -4
    e2_S4_0_3_arc[-1,8]  R883      6
    e2_S4_0_3_arc[-1,8]  R939      -30
    e2_S4_0_3_arc[-1,8]  R3168     1
    e2_S4_0_3_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_3_arc[-1,9]  R803      1
    e2_S4_0_3_arc[-1,9]  R836      1
    e2_S4_0_3_arc[-1,9]  R884      -13119
    e2_S4_0_3_arc[-1,9]  R885      -180
    e2_S4_0_3_arc[-1,9]  R886      176
    e2_S4_0_3_arc[-1,9]  R887      -6
    e2_S4_0_3_arc[-1,9]  R888      4
    e2_S4_0_3_arc[-1,9]  R940      -30
    e2_S4_0_3_arc[-1,9]  R3171     1
    e2_S4_0_3_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_3_arc[0,-2]  R804      1
    e2_S4_0_3_arc[0,-2]  R810      1
    e2_S4_0_3_arc[0,-2]  R889      -33523
    e2_S4_0_3_arc[0,-2]  R941      -30
    e2_S4_0_3_arc[0,-2]  R3145     1
    e2_S4_0_3_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_3_arc[1,-2]  R804      1
    e2_S4_0_3_arc[1,-2]  R813      1
    e2_S4_0_3_arc[1,-2]  R890      -39223
    e2_S4_0_3_arc[1,-2]  R942      -30
    e2_S4_0_3_arc[1,-2]  R3148     1
    e2_S4_0_3_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_3_arc[2,-2]  R804      1
    e2_S4_0_3_arc[2,-2]  R816      1
    e2_S4_0_3_arc[2,-2]  R891      -36369
    e2_S4_0_3_arc[2,-2]  R943      -30
    e2_S4_0_3_arc[2,-2]  R3151     1
    e2_S4_0_3_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_3_arc[3,-2]  R804      1
    e2_S4_0_3_arc[3,-2]  R819      1
    e2_S4_0_3_arc[3,-2]  R892      -42129
    e2_S4_0_3_arc[3,-2]  R944      -30
    e2_S4_0_3_arc[3,-2]  R3154     1
    e2_S4_0_3_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_3_arc[4,-2]  R804      1
    e2_S4_0_3_arc[4,-2]  R822      1
    e2_S4_0_3_arc[4,-2]  R893      -48315
    e2_S4_0_3_arc[4,-2]  R945      -30
    e2_S4_0_3_arc[4,-2]  R3157     1
    e2_S4_0_3_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_3_arc[5,-2]  R804      1
    e2_S4_0_3_arc[5,-2]  R825      1
    e2_S4_0_3_arc[5,-2]  R894      -53475
    e2_S4_0_3_arc[5,-2]  R946      -30
    e2_S4_0_3_arc[5,-2]  R3160     1
    e2_S4_0_3_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_3_arc[6,-2]  R804      1
    e2_S4_0_3_arc[6,-2]  R828      1
    e2_S4_0_3_arc[6,-2]  R895      -49531
    e2_S4_0_3_arc[6,-2]  R947      -30
    e2_S4_0_3_arc[6,-2]  R3163     1
    e2_S4_0_3_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_3_arc[7,-2]  R804      1
    e2_S4_0_3_arc[7,-2]  R831      1
    e2_S4_0_3_arc[7,-2]  R896      -56191
    e2_S4_0_3_arc[7,-2]  R948      -30
    e2_S4_0_3_arc[7,-2]  R3166     1
    e2_S4_0_3_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_3_arc[8,-2]  R804      1
    e2_S4_0_3_arc[8,-2]  R834      1
    e2_S4_0_3_arc[8,-2]  R897      -63217
    e2_S4_0_3_arc[8,-2]  R949      -30
    e2_S4_0_3_arc[8,-2]  R3169     1
    e2_S4_0_3_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_3_arc[9,-2]  R804      1
    e2_S4_0_3_arc[9,-2]  R837      1
    e2_S4_0_3_arc[9,-2]  R898      -68677
    e2_S4_0_3_arc[9,-2]  R950      -30
    e2_S4_0_3_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C655      R901      1
    C655      R931      -1
    C655      R932      -1
    C655      R933      -1
    C655      R934      -1
    C655      R935      -1
    C655      R936      -1
    C655      R937      -1
    C655      R938      -1
    C655      R939      -1
    C655      R940      -1
    C656      R941      1
    C656      R942      1
    C656      R943      1
    C656      R944      1
    C656      R945      1
    C656      R946      1
    C656      R947      1
    C656      R948      1
    C656      R949      1
    C656      R950      1
    C656      R1052     -1
    MARKER    'MARKER'                 'INTORG'
    C657      R902      1
    C657      R903      -60
    C657      R904      1
    C657      R905      -39660
    C657      R906      -180
    C657      R907      -6
    C657      R916      -1
    C657      R919      -1
    C658      R902      1
    C658      R903      -60
    C658      R908      1
    C658      R909      -54060
    C658      R910      -180
    C658      R911      -6
    C658      R922      -1
    C658      R925      -1
    C659      R902      1
    C659      R903      -60
    C659      R912      1
    C659      R913      -71160
    C659      R914      -180
    C659      R915      -6
    C659      R928      -1
    e2_S4_0_4_used  R951      -75600
    e2_S4_0_4_used  R952      -75600
    e2_S4_0_4_used  R953      -28800
    e2_S4_0_4_used  R954      -1
    e2_S4_0_4_used  R955      -1
    e2_S4_0_4_used  R956      -180
    e2_S4_0_4_used  R957      -6
    e2_S4_0_4_used  R958      -180
    e2_S4_0_4_used  R959      -6
    e2_S4_0_4_used  R962      -1
    e2_S4_0_4_used  R965      -1
    e2_S4_0_4_used  R968      -1
    e2_S4_0_4_used  R971      -1
    e2_S4_0_4_used  R974      -1
    e2_S4_0_4_used  R977      -1
    e2_S4_0_4_used  R980      -1
    e2_S4_0_4_used  R983      -1
    e2_S4_0_4_used  R986      -1
    e2_S4_0_4_used  R989      -1
    e2_S4_0_4_used  R1050     -75540
    e2_S4_0_4_used  R1051     1
    e2_S4_0_4_used  R1052     -30
    e2_S4_0_4_used  R1053     -1
    e2_S4_0_4_used  R1054     -75600
    e2_S4_0_4_used  R1202     -1
    e2_S4_0_4_used  R2610     -1
    e2_S4_0_4_start  R951      1
    e2_S4_0_4_start  R953      1
    e2_S4_0_4_start  R990      -1
    e2_S4_0_4_start  R995      -1
    e2_S4_0_4_start  R1000     -1
    e2_S4_0_4_start  R1005     -1
    e2_S4_0_4_start  R1010     -1
    e2_S4_0_4_start  R1015     -1
    e2_S4_0_4_start  R1020     -1
    e2_S4_0_4_start  R1025     -1
    e2_S4_0_4_start  R1030     -1
    e2_S4_0_4_start  R1035     -1
    e2_S4_0_4_start  R1054     1
    e2_S4_0_4_start  R1056     1
    e2_S4_0_4_start  R1060     1
    e2_S4_0_4_start  R1064     1
    e2_S4_0_4_end  R952      1
    e2_S4_0_4_end  R1040     1
    e2_S4_0_4_end  R1041     1
    e2_S4_0_4_end  R1042     1
    e2_S4_0_4_end  R1043     1
    e2_S4_0_4_end  R1044     1
    e2_S4_0_4_end  R1045     1
    e2_S4_0_4_end  R1046     1
    e2_S4_0_4_end  R1047     1
    e2_S4_0_4_end  R1048     1
    e2_S4_0_4_end  R1049     1
    e2_S4_0_4_end  R1050     1
    e2_S4_0_4_end  R1068     -1
    e2_S4_0_4_end  R1069     -1
    e2_S4_0_4_end  R1071     -1
    e2_S4_0_4_end  R1072     -1
    e2_S4_0_4_end  R1074     -1
    e2_S4_0_4_end  R1075     -1
    e2_S4_0_4_end  R1077     -1
    e2_S4_0_4_end  R1078     -1
    e2_S4_0_4_end  R1080     -1
    e2_S4_0_4_end  R1081     -1
    e2_S4_0_4_end  R1205     -1
    e2_S4_0_4_visit[0]  R956      15
    e2_S4_0_4_visit[0]  R957      1
    e2_S4_0_4_visit[0]  R960      -1
    e2_S4_0_4_visit[0]  R961      -1
    e2_S4_0_4_visit[0]  R962      1
    e2_S4_0_4_visit[0]  R991      -15
    e2_S4_0_4_visit[0]  R992      -15
    e2_S4_0_4_visit[0]  R993      -1
    e2_S4_0_4_visit[0]  R994      -1
    e2_S4_0_4_visit[0]  R996      -15
    e2_S4_0_4_visit[0]  R997      -15
    e2_S4_0_4_visit[0]  R998      -1
    e2_S4_0_4_visit[0]  R999      -1
    e2_S4_0_4_visit[0]  R1001     -15
    e2_S4_0_4_visit[0]  R1002     -15
    e2_S4_0_4_visit[0]  R1003     -1
    e2_S4_0_4_visit[0]  R1004     -1
    e2_S4_0_4_visit[0]  R1006     -15
    e2_S4_0_4_visit[0]  R1007     -15
    e2_S4_0_4_visit[0]  R1008     -1
    e2_S4_0_4_visit[0]  R1009     -1
    e2_S4_0_4_visit[0]  R1011     -15
    e2_S4_0_4_visit[0]  R1012     -15
    e2_S4_0_4_visit[0]  R1013     -1
    e2_S4_0_4_visit[0]  R1014     -1
    e2_S4_0_4_visit[0]  R1016     -15
    e2_S4_0_4_visit[0]  R1017     -15
    e2_S4_0_4_visit[0]  R1018     -1
    e2_S4_0_4_visit[0]  R1019     -1
    e2_S4_0_4_visit[0]  R1021     -15
    e2_S4_0_4_visit[0]  R1022     -15
    e2_S4_0_4_visit[0]  R1023     -1
    e2_S4_0_4_visit[0]  R1024     -1
    e2_S4_0_4_visit[0]  R1026     -15
    e2_S4_0_4_visit[0]  R1027     -15
    e2_S4_0_4_visit[0]  R1028     -1
    e2_S4_0_4_visit[0]  R1029     -1
    e2_S4_0_4_visit[0]  R1031     -15
    e2_S4_0_4_visit[0]  R1032     -15
    e2_S4_0_4_visit[0]  R1033     -1
    e2_S4_0_4_visit[0]  R1034     -1
    e2_S4_0_4_visit[0]  R1036     -15
    e2_S4_0_4_visit[0]  R1037     -15
    e2_S4_0_4_visit[0]  R1038     -1
    e2_S4_0_4_visit[0]  R1039     -1
    e2_S4_0_4_visit[0]  R1055     -1
    e2_S4_0_4_visit[0]  R1057     15
    e2_S4_0_4_visit[0]  R1058     1
    e2_S4_0_4_visit[0]  R1067     1
    e2_S4_0_4_visit[0]  R3143     -5
    e2_S4_0_4_visit[0]  R3413     1
    e2_S4_0_4_visit[1]  R958      2
    e2_S4_0_4_visit[1]  R959      1
    e2_S4_0_4_visit[1]  R963      -1
    e2_S4_0_4_visit[1]  R964      -1
    e2_S4_0_4_visit[1]  R965      1
    e2_S4_0_4_visit[1]  R1068     -40937
    e2_S4_0_4_visit[1]  R1069     71100
    e2_S4_0_4_visit[1]  R3146     -5
    e2_S4_0_4_visit[1]  R3414     1
    e2_S4_0_4_visit[2]  R956      23
    e2_S4_0_4_visit[2]  R957      2
    e2_S4_0_4_visit[2]  R966      -1
    e2_S4_0_4_visit[2]  R967      -1
    e2_S4_0_4_visit[2]  R968      1
    e2_S4_0_4_visit[2]  R991      -23
    e2_S4_0_4_visit[2]  R992      -23
    e2_S4_0_4_visit[2]  R993      -2
    e2_S4_0_4_visit[2]  R994      -2
    e2_S4_0_4_visit[2]  R996      -23
    e2_S4_0_4_visit[2]  R997      -23
    e2_S4_0_4_visit[2]  R998      -2
    e2_S4_0_4_visit[2]  R999      -2
    e2_S4_0_4_visit[2]  R1001     -23
    e2_S4_0_4_visit[2]  R1002     -23
    e2_S4_0_4_visit[2]  R1003     -2
    e2_S4_0_4_visit[2]  R1004     -2
    e2_S4_0_4_visit[2]  R1006     -23
    e2_S4_0_4_visit[2]  R1007     -23
    e2_S4_0_4_visit[2]  R1008     -2
    e2_S4_0_4_visit[2]  R1009     -2
    e2_S4_0_4_visit[2]  R1011     -23
    e2_S4_0_4_visit[2]  R1012     -23
    e2_S4_0_4_visit[2]  R1013     -2
    e2_S4_0_4_visit[2]  R1014     -2
    e2_S4_0_4_visit[2]  R1016     -23
    e2_S4_0_4_visit[2]  R1017     -23
    e2_S4_0_4_visit[2]  R1018     -2
    e2_S4_0_4_visit[2]  R1019     -2
    e2_S4_0_4_visit[2]  R1021     -23
    e2_S4_0_4_visit[2]  R1022     -23
    e2_S4_0_4_visit[2]  R1023     -2
    e2_S4_0_4_visit[2]  R1024     -2
    e2_S4_0_4_visit[2]  R1026     -23
    e2_S4_0_4_visit[2]  R1027     -23
    e2_S4_0_4_visit[2]  R1028     -2
    e2_S4_0_4_visit[2]  R1029     -2
    e2_S4_0_4_visit[2]  R1031     -23
    e2_S4_0_4_visit[2]  R1032     -23
    e2_S4_0_4_visit[2]  R1033     -2
    e2_S4_0_4_visit[2]  R1034     -2
    e2_S4_0_4_visit[2]  R1036     -23
    e2_S4_0_4_visit[2]  R1037     -23
    e2_S4_0_4_visit[2]  R1038     -2
    e2_S4_0_4_visit[2]  R1039     -2
    e2_S4_0_4_visit[2]  R1055     -1
    e2_S4_0_4_visit[2]  R1057     23
    e2_S4_0_4_visit[2]  R1058     2
    e2_S4_0_4_visit[2]  R1070     1
    e2_S4_0_4_visit[2]  R3149     -5
    e2_S4_0_4_visit[2]  R3417     1
    e2_S4_0_4_visit[3]  R958      4
    e2_S4_0_4_visit[3]  R959      2
    e2_S4_0_4_visit[3]  R969      -1
    e2_S4_0_4_visit[3]  R970      -1
    e2_S4_0_4_visit[3]  R971      1
    e2_S4_0_4_visit[3]  R1071     -38031
    e2_S4_0_4_visit[3]  R1072     71100
    e2_S4_0_4_visit[3]  R3152     -5
    e2_S4_0_4_visit[3]  R3418     1
    e2_S4_0_4_visit[4]  R956      21
    e2_S4_0_4_visit[4]  R957      2
    e2_S4_0_4_visit[4]  R972      -1
    e2_S4_0_4_visit[4]  R973      -1
    e2_S4_0_4_visit[4]  R974      1
    e2_S4_0_4_visit[4]  R991      -21
    e2_S4_0_4_visit[4]  R992      -21
    e2_S4_0_4_visit[4]  R993      -2
    e2_S4_0_4_visit[4]  R994      -2
    e2_S4_0_4_visit[4]  R996      -21
    e2_S4_0_4_visit[4]  R997      -21
    e2_S4_0_4_visit[4]  R998      -2
    e2_S4_0_4_visit[4]  R999      -2
    e2_S4_0_4_visit[4]  R1001     -21
    e2_S4_0_4_visit[4]  R1002     -21
    e2_S4_0_4_visit[4]  R1003     -2
    e2_S4_0_4_visit[4]  R1004     -2
    e2_S4_0_4_visit[4]  R1006     -21
    e2_S4_0_4_visit[4]  R1007     -21
    e2_S4_0_4_visit[4]  R1008     -2
    e2_S4_0_4_visit[4]  R1009     -2
    e2_S4_0_4_visit[4]  R1011     -21
    e2_S4_0_4_visit[4]  R1012     -21
    e2_S4_0_4_visit[4]  R1013     -2
    e2_S4_0_4_visit[4]  R1014     -2
    e2_S4_0_4_visit[4]  R1016     -21
    e2_S4_0_4_visit[4]  R1017     -21
    e2_S4_0_4_visit[4]  R1018     -2
    e2_S4_0_4_visit[4]  R1019     -2
    e2_S4_0_4_visit[4]  R1021     -21
    e2_S4_0_4_visit[4]  R1022     -21
    e2_S4_0_4_visit[4]  R1023     -2
    e2_S4_0_4_visit[4]  R1024     -2
    e2_S4_0_4_visit[4]  R1026     -21
    e2_S4_0_4_visit[4]  R1027     -21
    e2_S4_0_4_visit[4]  R1028     -2
    e2_S4_0_4_visit[4]  R1029     -2
    e2_S4_0_4_visit[4]  R1031     -21
    e2_S4_0_4_visit[4]  R1032     -21
    e2_S4_0_4_visit[4]  R1033     -2
    e2_S4_0_4_visit[4]  R1034     -2
    e2_S4_0_4_visit[4]  R1036     -21
    e2_S4_0_4_visit[4]  R1037     -21
    e2_S4_0_4_visit[4]  R1038     -2
    e2_S4_0_4_visit[4]  R1039     -2
    e2_S4_0_4_visit[4]  R1059     -1
    e2_S4_0_4_visit[4]  R1061     21
    e2_S4_0_4_visit[4]  R1062     2
    e2_S4_0_4_visit[4]  R1073     1
    e2_S4_0_4_visit[4]  R3155     -5
    e2_S4_0_4_visit[4]  R3421     1
    e2_S4_0_4_visit[5]  R958      4
    e2_S4_0_4_visit[5]  R959      2
    e2_S4_0_4_visit[5]  R975      -1
    e2_S4_0_4_visit[5]  R976      -1
    e2_S4_0_4_visit[5]  R977      1
    e2_S4_0_4_visit[5]  R1074     -25749
    e2_S4_0_4_visit[5]  R1075     71100
    e2_S4_0_4_visit[5]  R3158     -5
    e2_S4_0_4_visit[5]  R3422     1
    e2_S4_0_4_visit[6]  R956      23
    e2_S4_0_4_visit[6]  R957      2
    e2_S4_0_4_visit[6]  R978      -1
    e2_S4_0_4_visit[6]  R979      -1
    e2_S4_0_4_visit[6]  R980      1
    e2_S4_0_4_visit[6]  R991      -23
    e2_S4_0_4_visit[6]  R992      -23
    e2_S4_0_4_visit[6]  R993      -2
    e2_S4_0_4_visit[6]  R994      -2
    e2_S4_0_4_visit[6]  R996      -23
    e2_S4_0_4_visit[6]  R997      -23
    e2_S4_0_4_visit[6]  R998      -2
    e2_S4_0_4_visit[6]  R999      -2
    e2_S4_0_4_visit[6]  R1001     -23
    e2_S4_0_4_visit[6]  R1002     -23
    e2_S4_0_4_visit[6]  R1003     -2
    e2_S4_0_4_visit[6]  R1004     -2
    e2_S4_0_4_visit[6]  R1006     -23
    e2_S4_0_4_visit[6]  R1007     -23
    e2_S4_0_4_visit[6]  R1008     -2
    e2_S4_0_4_visit[6]  R1009     -2
    e2_S4_0_4_visit[6]  R1011     -23
    e2_S4_0_4_visit[6]  R1012     -23
    e2_S4_0_4_visit[6]  R1013     -2
    e2_S4_0_4_visit[6]  R1014     -2
    e2_S4_0_4_visit[6]  R1016     -23
    e2_S4_0_4_visit[6]  R1017     -23
    e2_S4_0_4_visit[6]  R1018     -2
    e2_S4_0_4_visit[6]  R1019     -2
    e2_S4_0_4_visit[6]  R1021     -23
    e2_S4_0_4_visit[6]  R1022     -23
    e2_S4_0_4_visit[6]  R1023     -2
    e2_S4_0_4_visit[6]  R1024     -2
    e2_S4_0_4_visit[6]  R1026     -23
    e2_S4_0_4_visit[6]  R1027     -23
    e2_S4_0_4_visit[6]  R1028     -2
    e2_S4_0_4_visit[6]  R1029     -2
    e2_S4_0_4_visit[6]  R1031     -23
    e2_S4_0_4_visit[6]  R1032     -23
    e2_S4_0_4_visit[6]  R1033     -2
    e2_S4_0_4_visit[6]  R1034     -2
    e2_S4_0_4_visit[6]  R1036     -23
    e2_S4_0_4_visit[6]  R1037     -23
    e2_S4_0_4_visit[6]  R1038     -2
    e2_S4_0_4_visit[6]  R1039     -2
    e2_S4_0_4_visit[6]  R1059     -1
    e2_S4_0_4_visit[6]  R1061     23
    e2_S4_0_4_visit[6]  R1062     2
    e2_S4_0_4_visit[6]  R1076     1
    e2_S4_0_4_visit[6]  R3161     -5
    e2_S4_0_4_visit[6]  R3425     1
    e2_S4_0_4_visit[7]  R958      4
    e2_S4_0_4_visit[7]  R959      2
    e2_S4_0_4_visit[7]  R981      -1
    e2_S4_0_4_visit[7]  R982      -1
    e2_S4_0_4_visit[7]  R983      1
    e2_S4_0_4_visit[7]  R1077     -23969
    e2_S4_0_4_visit[7]  R1078     71100
    e2_S4_0_4_visit[7]  R3164     -5
    e2_S4_0_4_visit[7]  R3426     1
    e2_S4_0_4_visit[8]  R956      21
    e2_S4_0_4_visit[8]  R957      2
    e2_S4_0_4_visit[8]  R984      -1
    e2_S4_0_4_visit[8]  R985      -1
    e2_S4_0_4_visit[8]  R986      1
    e2_S4_0_4_visit[8]  R991      -21
    e2_S4_0_4_visit[8]  R992      -21
    e2_S4_0_4_visit[8]  R993      -2
    e2_S4_0_4_visit[8]  R994      -2
    e2_S4_0_4_visit[8]  R996      -21
    e2_S4_0_4_visit[8]  R997      -21
    e2_S4_0_4_visit[8]  R998      -2
    e2_S4_0_4_visit[8]  R999      -2
    e2_S4_0_4_visit[8]  R1001     -21
    e2_S4_0_4_visit[8]  R1002     -21
    e2_S4_0_4_visit[8]  R1003     -2
    e2_S4_0_4_visit[8]  R1004     -2
    e2_S4_0_4_visit[8]  R1006     -21
    e2_S4_0_4_visit[8]  R1007     -21
    e2_S4_0_4_visit[8]  R1008     -2
    e2_S4_0_4_visit[8]  R1009     -2
    e2_S4_0_4_visit[8]  R1011     -21
    e2_S4_0_4_visit[8]  R1012     -21
    e2_S4_0_4_visit[8]  R1013     -2
    e2_S4_0_4_visit[8]  R1014     -2
    e2_S4_0_4_visit[8]  R1016     -21
    e2_S4_0_4_visit[8]  R1017     -21
    e2_S4_0_4_visit[8]  R1018     -2
    e2_S4_0_4_visit[8]  R1019     -2
    e2_S4_0_4_visit[8]  R1021     -21
    e2_S4_0_4_visit[8]  R1022     -21
    e2_S4_0_4_visit[8]  R1023     -2
    e2_S4_0_4_visit[8]  R1024     -2
    e2_S4_0_4_visit[8]  R1026     -21
    e2_S4_0_4_visit[8]  R1027     -21
    e2_S4_0_4_visit[8]  R1028     -2
    e2_S4_0_4_visit[8]  R1029     -2
    e2_S4_0_4_visit[8]  R1031     -21
    e2_S4_0_4_visit[8]  R1032     -21
    e2_S4_0_4_visit[8]  R1033     -2
    e2_S4_0_4_visit[8]  R1034     -2
    e2_S4_0_4_visit[8]  R1036     -21
    e2_S4_0_4_visit[8]  R1037     -21
    e2_S4_0_4_visit[8]  R1038     -2
    e2_S4_0_4_visit[8]  R1039     -2
    e2_S4_0_4_visit[8]  R1063     -1
    e2_S4_0_4_visit[8]  R1065     21
    e2_S4_0_4_visit[8]  R1066     2
    e2_S4_0_4_visit[8]  R1079     1
    e2_S4_0_4_visit[8]  R3167     -5
    e2_S4_0_4_visit[8]  R3429     1
    e2_S4_0_4_visit[9]  R958      4
    e2_S4_0_4_visit[9]  R959      2
    e2_S4_0_4_visit[9]  R987      -1
    e2_S4_0_4_visit[9]  R988      -1
    e2_S4_0_4_visit[9]  R989      1
    e2_S4_0_4_visit[9]  R1080     -11425
    e2_S4_0_4_visit[9]  R1081     71100
    e2_S4_0_4_visit[9]  R3170     -5
    e2_S4_0_4_visit[9]  R3430     1
    e2_S4_0_4_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_4_arc[-1,0]  R954      1
    e2_S4_0_4_arc[-1,0]  R960      1
    e2_S4_0_4_arc[-1,0]  R990      -44319
    e2_S4_0_4_arc[-1,0]  R991      -165
    e2_S4_0_4_arc[-1,0]  R992      180
    e2_S4_0_4_arc[-1,0]  R993      -5
    e2_S4_0_4_arc[-1,0]  R994      6
    e2_S4_0_4_arc[-1,0]  R1082     -30
    e2_S4_0_4_arc[-1,0]  R3144     1
    e2_S4_0_4_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_4_arc[-1,1]  R954      1
    e2_S4_0_4_arc[-1,1]  R963      1
    e2_S4_0_4_arc[-1,1]  R995      -41683
    e2_S4_0_4_arc[-1,1]  R996      -180
    e2_S4_0_4_arc[-1,1]  R997      178
    e2_S4_0_4_arc[-1,1]  R998      -6
    e2_S4_0_4_arc[-1,1]  R999      5
    e2_S4_0_4_arc[-1,1]  R1083     -30
    e2_S4_0_4_arc[-1,1]  R3147     1
    e2_S4_0_4_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_4_arc[-1,2]  R954      1
    e2_S4_0_4_arc[-1,2]  R966      1
    e2_S4_0_4_arc[-1,2]  R1000     -44289
    e2_S4_0_4_arc[-1,2]  R1001     -157
    e2_S4_0_4_arc[-1,2]  R1002     180
    e2_S4_0_4_arc[-1,2]  R1003     -4
    e2_S4_0_4_arc[-1,2]  R1004     6
    e2_S4_0_4_arc[-1,2]  R1084     -30
    e2_S4_0_4_arc[-1,2]  R3150     1
    e2_S4_0_4_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_4_arc[-1,3]  R954      1
    e2_S4_0_4_arc[-1,3]  R969      1
    e2_S4_0_4_arc[-1,3]  R1005     -40989
    e2_S4_0_4_arc[-1,3]  R1006     -180
    e2_S4_0_4_arc[-1,3]  R1007     176
    e2_S4_0_4_arc[-1,3]  R1008     -6
    e2_S4_0_4_arc[-1,3]  R1009     4
    e2_S4_0_4_arc[-1,3]  R1085     -30
    e2_S4_0_4_arc[-1,3]  R3153     1
    e2_S4_0_4_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_4_arc[-1,4]  R954      1
    e2_S4_0_4_arc[-1,4]  R972      1
    e2_S4_0_4_arc[-1,4]  R1010     -29919
    e2_S4_0_4_arc[-1,4]  R1011     -159
    e2_S4_0_4_arc[-1,4]  R1012     180
    e2_S4_0_4_arc[-1,4]  R1013     -4
    e2_S4_0_4_arc[-1,4]  R1014     6
    e2_S4_0_4_arc[-1,4]  R1086     -30
    e2_S4_0_4_arc[-1,4]  R3156     1
    e2_S4_0_4_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_4_arc[-1,5]  R954      1
    e2_S4_0_4_arc[-1,5]  R975      1
    e2_S4_0_4_arc[-1,5]  R1015     -26919
    e2_S4_0_4_arc[-1,5]  R1016     -180
    e2_S4_0_4_arc[-1,5]  R1017     176
    e2_S4_0_4_arc[-1,5]  R1018     -6
    e2_S4_0_4_arc[-1,5]  R1019     4
    e2_S4_0_4_arc[-1,5]  R1087     -30
    e2_S4_0_4_arc[-1,5]  R3159     1
    e2_S4_0_4_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_4_arc[-1,6]  R954      1
    e2_S4_0_4_arc[-1,6]  R978      1
    e2_S4_0_4_arc[-1,6]  R1020     -29851
    e2_S4_0_4_arc[-1,6]  R1021     -157
    e2_S4_0_4_arc[-1,6]  R1022     180
    e2_S4_0_4_arc[-1,6]  R1023     -4
    e2_S4_0_4_arc[-1,6]  R1024     6
    e2_S4_0_4_arc[-1,6]  R1088     -30
    e2_S4_0_4_arc[-1,6]  R3162     1
    e2_S4_0_4_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_4_arc[-1,7]  R954      1
    e2_S4_0_4_arc[-1,7]  R981      1
    e2_S4_0_4_arc[-1,7]  R1025     -25651
    e2_S4_0_4_arc[-1,7]  R1026     -180
    e2_S4_0_4_arc[-1,7]  R1027     176
    e2_S4_0_4_arc[-1,7]  R1028     -6
    e2_S4_0_4_arc[-1,7]  R1029     4
    e2_S4_0_4_arc[-1,7]  R1089     -30
    e2_S4_0_4_arc[-1,7]  R3165     1
    e2_S4_0_4_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_4_arc[-1,8]  R954      1
    e2_S4_0_4_arc[-1,8]  R984      1
    e2_S4_0_4_arc[-1,8]  R1030     -15519
    e2_S4_0_4_arc[-1,8]  R1031     -159
    e2_S4_0_4_arc[-1,8]  R1032     180
    e2_S4_0_4_arc[-1,8]  R1033     -4
    e2_S4_0_4_arc[-1,8]  R1034     6
    e2_S4_0_4_arc[-1,8]  R1090     -30
    e2_S4_0_4_arc[-1,8]  R3168     1
    e2_S4_0_4_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_4_arc[-1,9]  R954      1
    e2_S4_0_4_arc[-1,9]  R987      1
    e2_S4_0_4_arc[-1,9]  R1035     -13119
    e2_S4_0_4_arc[-1,9]  R1036     -180
    e2_S4_0_4_arc[-1,9]  R1037     176
    e2_S4_0_4_arc[-1,9]  R1038     -6
    e2_S4_0_4_arc[-1,9]  R1039     4
    e2_S4_0_4_arc[-1,9]  R1091     -30
    e2_S4_0_4_arc[-1,9]  R3171     1
    e2_S4_0_4_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_4_arc[0,-2]  R955      1
    e2_S4_0_4_arc[0,-2]  R961      1
    e2_S4_0_4_arc[0,-2]  R1040     -33523
    e2_S4_0_4_arc[0,-2]  R1092     -30
    e2_S4_0_4_arc[0,-2]  R3145     1
    e2_S4_0_4_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_4_arc[1,-2]  R955      1
    e2_S4_0_4_arc[1,-2]  R964      1
    e2_S4_0_4_arc[1,-2]  R1041     -39223
    e2_S4_0_4_arc[1,-2]  R1093     -30
    e2_S4_0_4_arc[1,-2]  R3148     1
    e2_S4_0_4_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_4_arc[2,-2]  R955      1
    e2_S4_0_4_arc[2,-2]  R967      1
    e2_S4_0_4_arc[2,-2]  R1042     -36369
    e2_S4_0_4_arc[2,-2]  R1094     -30
    e2_S4_0_4_arc[2,-2]  R3151     1
    e2_S4_0_4_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_4_arc[3,-2]  R955      1
    e2_S4_0_4_arc[3,-2]  R970      1
    e2_S4_0_4_arc[3,-2]  R1043     -42129
    e2_S4_0_4_arc[3,-2]  R1095     -30
    e2_S4_0_4_arc[3,-2]  R3154     1
    e2_S4_0_4_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_4_arc[4,-2]  R955      1
    e2_S4_0_4_arc[4,-2]  R973      1
    e2_S4_0_4_arc[4,-2]  R1044     -48315
    e2_S4_0_4_arc[4,-2]  R1096     -30
    e2_S4_0_4_arc[4,-2]  R3157     1
    e2_S4_0_4_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_4_arc[5,-2]  R955      1
    e2_S4_0_4_arc[5,-2]  R976      1
    e2_S4_0_4_arc[5,-2]  R1045     -53475
    e2_S4_0_4_arc[5,-2]  R1097     -30
    e2_S4_0_4_arc[5,-2]  R3160     1
    e2_S4_0_4_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_4_arc[6,-2]  R955      1
    e2_S4_0_4_arc[6,-2]  R979      1
    e2_S4_0_4_arc[6,-2]  R1046     -49531
    e2_S4_0_4_arc[6,-2]  R1098     -30
    e2_S4_0_4_arc[6,-2]  R3163     1
    e2_S4_0_4_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_4_arc[7,-2]  R955      1
    e2_S4_0_4_arc[7,-2]  R982      1
    e2_S4_0_4_arc[7,-2]  R1047     -56191
    e2_S4_0_4_arc[7,-2]  R1099     -30
    e2_S4_0_4_arc[7,-2]  R3166     1
    e2_S4_0_4_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_4_arc[8,-2]  R955      1
    e2_S4_0_4_arc[8,-2]  R985      1
    e2_S4_0_4_arc[8,-2]  R1048     -63217
    e2_S4_0_4_arc[8,-2]  R1100     -30
    e2_S4_0_4_arc[8,-2]  R3169     1
    e2_S4_0_4_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_4_arc[9,-2]  R955      1
    e2_S4_0_4_arc[9,-2]  R988      1
    e2_S4_0_4_arc[9,-2]  R1049     -68677
    e2_S4_0_4_arc[9,-2]  R1101     -30
    e2_S4_0_4_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C693      R1052     1
    C693      R1082     -1
    C693      R1083     -1
    C693      R1084     -1
    C693      R1085     -1
    C693      R1086     -1
    C693      R1087     -1
    C693      R1088     -1
    C693      R1089     -1
    C693      R1090     -1
    C693      R1091     -1
    C694      R1092     1
    C694      R1093     1
    C694      R1094     1
    C694      R1095     1
    C694      R1096     1
    C694      R1097     1
    C694      R1098     1
    C694      R1099     1
    C694      R1100     1
    C694      R1101     1
    C694      R1203     -1
    MARKER    'MARKER'                 'INTORG'
    C695      R1053     1
    C695      R1054     -60
    C695      R1055     1
    C695      R1056     -39660
    C695      R1057     -180
    C695      R1058     -6
    C695      R1067     -1
    C695      R1070     -1
    C696      R1053     1
    C696      R1054     -60
    C696      R1059     1
    C696      R1060     -54060
    C696      R1061     -180
    C696      R1062     -6
    C696      R1073     -1
    C696      R1076     -1
    C697      R1053     1
    C697      R1054     -60
    C697      R1063     1
    C697      R1064     -71160
    C697      R1065     -180
    C697      R1066     -6
    C697      R1079     -1
    e2_S4_0_5_used  R1102     -75600
    e2_S4_0_5_used  R1103     -75600
    e2_S4_0_5_used  R1104     -28800
    e2_S4_0_5_used  R1105     -1
    e2_S4_0_5_used  R1106     -1
    e2_S4_0_5_used  R1107     -180
    e2_S4_0_5_used  R1108     -6
    e2_S4_0_5_used  R1109     -180
    e2_S4_0_5_used  R1110     -6
    e2_S4_0_5_used  R1113     -1
    e2_S4_0_5_used  R1116     -1
    e2_S4_0_5_used  R1119     -1
    e2_S4_0_5_used  R1122     -1
    e2_S4_0_5_used  R1125     -1
    e2_S4_0_5_used  R1128     -1
    e2_S4_0_5_used  R1131     -1
    e2_S4_0_5_used  R1134     -1
    e2_S4_0_5_used  R1137     -1
    e2_S4_0_5_used  R1140     -1
    e2_S4_0_5_used  R1201     -75540
    e2_S4_0_5_used  R1202     1
    e2_S4_0_5_used  R1203     -30
    e2_S4_0_5_used  R1204     -1
    e2_S4_0_5_used  R1205     -75600
    e2_S4_0_5_used  R1353     -1
    e2_S4_0_5_used  R2610     -1
    e2_S4_0_5_start  R1102     1
    e2_S4_0_5_start  R1104     1
    e2_S4_0_5_start  R1141     -1
    e2_S4_0_5_start  R1146     -1
    e2_S4_0_5_start  R1151     -1
    e2_S4_0_5_start  R1156     -1
    e2_S4_0_5_start  R1161     -1
    e2_S4_0_5_start  R1166     -1
    e2_S4_0_5_start  R1171     -1
    e2_S4_0_5_start  R1176     -1
    e2_S4_0_5_start  R1181     -1
    e2_S4_0_5_start  R1186     -1
    e2_S4_0_5_start  R1205     1
    e2_S4_0_5_start  R1207     1
    e2_S4_0_5_start  R1211     1
    e2_S4_0_5_start  R1215     1
    e2_S4_0_5_end  R1103     1
    e2_S4_0_5_end  R1191     1
    e2_S4_0_5_end  R1192     1
    e2_S4_0_5_end  R1193     1
    e2_S4_0_5_end  R1194     1
    e2_S4_0_5_end  R1195     1
    e2_S4_0_5_end  R1196     1
    e2_S4_0_5_end  R1197     1
    e2_S4_0_5_end  R1198     1
    e2_S4_0_5_end  R1199     1
    e2_S4_0_5_end  R1200     1
    e2_S4_0_5_end  R1201     1
    e2_S4_0_5_end  R1219     -1
    e2_S4_0_5_end  R1220     -1
    e2_S4_0_5_end  R1222     -1
    e2_S4_0_5_end  R1223     -1
    e2_S4_0_5_end  R1225     -1
    e2_S4_0_5_end  R1226     -1
    e2_S4_0_5_end  R1228     -1
    e2_S4_0_5_end  R1229     -1
    e2_S4_0_5_end  R1231     -1
    e2_S4_0_5_end  R1232     -1
    e2_S4_0_5_end  R1356     -1
    e2_S4_0_5_visit[0]  R1107     15
    e2_S4_0_5_visit[0]  R1108     1
    e2_S4_0_5_visit[0]  R1111     -1
    e2_S4_0_5_visit[0]  R1112     -1
    e2_S4_0_5_visit[0]  R1113     1
    e2_S4_0_5_visit[0]  R1142     -15
    e2_S4_0_5_visit[0]  R1143     -15
    e2_S4_0_5_visit[0]  R1144     -1
    e2_S4_0_5_visit[0]  R1145     -1
    e2_S4_0_5_visit[0]  R1147     -15
    e2_S4_0_5_visit[0]  R1148     -15
    e2_S4_0_5_visit[0]  R1149     -1
    e2_S4_0_5_visit[0]  R1150     -1
    e2_S4_0_5_visit[0]  R1152     -15
    e2_S4_0_5_visit[0]  R1153     -15
    e2_S4_0_5_visit[0]  R1154     -1
    e2_S4_0_5_visit[0]  R1155     -1
    e2_S4_0_5_visit[0]  R1157     -15
    e2_S4_0_5_visit[0]  R1158     -15
    e2_S4_0_5_visit[0]  R1159     -1
    e2_S4_0_5_visit[0]  R1160     -1
    e2_S4_0_5_visit[0]  R1162     -15
    e2_S4_0_5_visit[0]  R1163     -15
    e2_S4_0_5_visit[0]  R1164     -1
    e2_S4_0_5_visit[0]  R1165     -1
    e2_S4_0_5_visit[0]  R1167     -15
    e2_S4_0_5_visit[0]  R1168     -15
    e2_S4_0_5_visit[0]  R1169     -1
    e2_S4_0_5_visit[0]  R1170     -1
    e2_S4_0_5_visit[0]  R1172     -15
    e2_S4_0_5_visit[0]  R1173     -15
    e2_S4_0_5_visit[0]  R1174     -1
    e2_S4_0_5_visit[0]  R1175     -1
    e2_S4_0_5_visit[0]  R1177     -15
    e2_S4_0_5_visit[0]  R1178     -15
    e2_S4_0_5_visit[0]  R1179     -1
    e2_S4_0_5_visit[0]  R1180     -1
    e2_S4_0_5_visit[0]  R1182     -15
    e2_S4_0_5_visit[0]  R1183     -15
    e2_S4_0_5_visit[0]  R1184     -1
    e2_S4_0_5_visit[0]  R1185     -1
    e2_S4_0_5_visit[0]  R1187     -15
    e2_S4_0_5_visit[0]  R1188     -15
    e2_S4_0_5_visit[0]  R1189     -1
    e2_S4_0_5_visit[0]  R1190     -1
    e2_S4_0_5_visit[0]  R1206     -1
    e2_S4_0_5_visit[0]  R1208     15
    e2_S4_0_5_visit[0]  R1209     1
    e2_S4_0_5_visit[0]  R1218     1
    e2_S4_0_5_visit[0]  R3143     -6
    e2_S4_0_5_visit[0]  R3413     1
    e2_S4_0_5_visit[1]  R1109     2
    e2_S4_0_5_visit[1]  R1110     1
    e2_S4_0_5_visit[1]  R1114     -1
    e2_S4_0_5_visit[1]  R1115     -1
    e2_S4_0_5_visit[1]  R1116     1
    e2_S4_0_5_visit[1]  R1219     -40937
    e2_S4_0_5_visit[1]  R1220     71100
    e2_S4_0_5_visit[1]  R3146     -6
    e2_S4_0_5_visit[1]  R3414     1
    e2_S4_0_5_visit[2]  R1107     23
    e2_S4_0_5_visit[2]  R1108     2
    e2_S4_0_5_visit[2]  R1117     -1
    e2_S4_0_5_visit[2]  R1118     -1
    e2_S4_0_5_visit[2]  R1119     1
    e2_S4_0_5_visit[2]  R1142     -23
    e2_S4_0_5_visit[2]  R1143     -23
    e2_S4_0_5_visit[2]  R1144     -2
    e2_S4_0_5_visit[2]  R1145     -2
    e2_S4_0_5_visit[2]  R1147     -23
    e2_S4_0_5_visit[2]  R1148     -23
    e2_S4_0_5_visit[2]  R1149     -2
    e2_S4_0_5_visit[2]  R1150     -2
    e2_S4_0_5_visit[2]  R1152     -23
    e2_S4_0_5_visit[2]  R1153     -23
    e2_S4_0_5_visit[2]  R1154     -2
    e2_S4_0_5_visit[2]  R1155     -2
    e2_S4_0_5_visit[2]  R1157     -23
    e2_S4_0_5_visit[2]  R1158     -23
    e2_S4_0_5_visit[2]  R1159     -2
    e2_S4_0_5_visit[2]  R1160     -2
    e2_S4_0_5_visit[2]  R1162     -23
    e2_S4_0_5_visit[2]  R1163     -23
    e2_S4_0_5_visit[2]  R1164     -2
    e2_S4_0_5_visit[2]  R1165     -2
    e2_S4_0_5_visit[2]  R1167     -23
    e2_S4_0_5_visit[2]  R1168     -23
    e2_S4_0_5_visit[2]  R1169     -2
    e2_S4_0_5_visit[2]  R1170     -2
    e2_S4_0_5_visit[2]  R1172     -23
    e2_S4_0_5_visit[2]  R1173     -23
    e2_S4_0_5_visit[2]  R1174     -2
    e2_S4_0_5_visit[2]  R1175     -2
    e2_S4_0_5_visit[2]  R1177     -23
    e2_S4_0_5_visit[2]  R1178     -23
    e2_S4_0_5_visit[2]  R1179     -2
    e2_S4_0_5_visit[2]  R1180     -2
    e2_S4_0_5_visit[2]  R1182     -23
    e2_S4_0_5_visit[2]  R1183     -23
    e2_S4_0_5_visit[2]  R1184     -2
    e2_S4_0_5_visit[2]  R1185     -2
    e2_S4_0_5_visit[2]  R1187     -23
    e2_S4_0_5_visit[2]  R1188     -23
    e2_S4_0_5_visit[2]  R1189     -2
    e2_S4_0_5_visit[2]  R1190     -2
    e2_S4_0_5_visit[2]  R1206     -1
    e2_S4_0_5_visit[2]  R1208     23
    e2_S4_0_5_visit[2]  R1209     2
    e2_S4_0_5_visit[2]  R1221     1
    e2_S4_0_5_visit[2]  R3149     -6
    e2_S4_0_5_visit[2]  R3417     1
    e2_S4_0_5_visit[3]  R1109     4
    e2_S4_0_5_visit[3]  R1110     2
    e2_S4_0_5_visit[3]  R1120     -1
    e2_S4_0_5_visit[3]  R1121     -1
    e2_S4_0_5_visit[3]  R1122     1
    e2_S4_0_5_visit[3]  R1222     -38031
    e2_S4_0_5_visit[3]  R1223     71100
    e2_S4_0_5_visit[3]  R3152     -6
    e2_S4_0_5_visit[3]  R3418     1
    e2_S4_0_5_visit[4]  R1107     21
    e2_S4_0_5_visit[4]  R1108     2
    e2_S4_0_5_visit[4]  R1123     -1
    e2_S4_0_5_visit[4]  R1124     -1
    e2_S4_0_5_visit[4]  R1125     1
    e2_S4_0_5_visit[4]  R1142     -21
    e2_S4_0_5_visit[4]  R1143     -21
    e2_S4_0_5_visit[4]  R1144     -2
    e2_S4_0_5_visit[4]  R1145     -2
    e2_S4_0_5_visit[4]  R1147     -21
    e2_S4_0_5_visit[4]  R1148     -21
    e2_S4_0_5_visit[4]  R1149     -2
    e2_S4_0_5_visit[4]  R1150     -2
    e2_S4_0_5_visit[4]  R1152     -21
    e2_S4_0_5_visit[4]  R1153     -21
    e2_S4_0_5_visit[4]  R1154     -2
    e2_S4_0_5_visit[4]  R1155     -2
    e2_S4_0_5_visit[4]  R1157     -21
    e2_S4_0_5_visit[4]  R1158     -21
    e2_S4_0_5_visit[4]  R1159     -2
    e2_S4_0_5_visit[4]  R1160     -2
    e2_S4_0_5_visit[4]  R1162     -21
    e2_S4_0_5_visit[4]  R1163     -21
    e2_S4_0_5_visit[4]  R1164     -2
    e2_S4_0_5_visit[4]  R1165     -2
    e2_S4_0_5_visit[4]  R1167     -21
    e2_S4_0_5_visit[4]  R1168     -21
    e2_S4_0_5_visit[4]  R1169     -2
    e2_S4_0_5_visit[4]  R1170     -2
    e2_S4_0_5_visit[4]  R1172     -21
    e2_S4_0_5_visit[4]  R1173     -21
    e2_S4_0_5_visit[4]  R1174     -2
    e2_S4_0_5_visit[4]  R1175     -2
    e2_S4_0_5_visit[4]  R1177     -21
    e2_S4_0_5_visit[4]  R1178     -21
    e2_S4_0_5_visit[4]  R1179     -2
    e2_S4_0_5_visit[4]  R1180     -2
    e2_S4_0_5_visit[4]  R1182     -21
    e2_S4_0_5_visit[4]  R1183     -21
    e2_S4_0_5_visit[4]  R1184     -2
    e2_S4_0_5_visit[4]  R1185     -2
    e2_S4_0_5_visit[4]  R1187     -21
    e2_S4_0_5_visit[4]  R1188     -21
    e2_S4_0_5_visit[4]  R1189     -2
    e2_S4_0_5_visit[4]  R1190     -2
    e2_S4_0_5_visit[4]  R1210     -1
    e2_S4_0_5_visit[4]  R1212     21
    e2_S4_0_5_visit[4]  R1213     2
    e2_S4_0_5_visit[4]  R1224     1
    e2_S4_0_5_visit[4]  R3155     -6
    e2_S4_0_5_visit[4]  R3421     1
    e2_S4_0_5_visit[5]  R1109     4
    e2_S4_0_5_visit[5]  R1110     2
    e2_S4_0_5_visit[5]  R1126     -1
    e2_S4_0_5_visit[5]  R1127     -1
    e2_S4_0_5_visit[5]  R1128     1
    e2_S4_0_5_visit[5]  R1225     -25749
    e2_S4_0_5_visit[5]  R1226     71100
    e2_S4_0_5_visit[5]  R3158     -6
    e2_S4_0_5_visit[5]  R3422     1
    e2_S4_0_5_visit[6]  R1107     23
    e2_S4_0_5_visit[6]  R1108     2
    e2_S4_0_5_visit[6]  R1129     -1
    e2_S4_0_5_visit[6]  R1130     -1
    e2_S4_0_5_visit[6]  R1131     1
    e2_S4_0_5_visit[6]  R1142     -23
    e2_S4_0_5_visit[6]  R1143     -23
    e2_S4_0_5_visit[6]  R1144     -2
    e2_S4_0_5_visit[6]  R1145     -2
    e2_S4_0_5_visit[6]  R1147     -23
    e2_S4_0_5_visit[6]  R1148     -23
    e2_S4_0_5_visit[6]  R1149     -2
    e2_S4_0_5_visit[6]  R1150     -2
    e2_S4_0_5_visit[6]  R1152     -23
    e2_S4_0_5_visit[6]  R1153     -23
    e2_S4_0_5_visit[6]  R1154     -2
    e2_S4_0_5_visit[6]  R1155     -2
    e2_S4_0_5_visit[6]  R1157     -23
    e2_S4_0_5_visit[6]  R1158     -23
    e2_S4_0_5_visit[6]  R1159     -2
    e2_S4_0_5_visit[6]  R1160     -2
    e2_S4_0_5_visit[6]  R1162     -23
    e2_S4_0_5_visit[6]  R1163     -23
    e2_S4_0_5_visit[6]  R1164     -2
    e2_S4_0_5_visit[6]  R1165     -2
    e2_S4_0_5_visit[6]  R1167     -23
    e2_S4_0_5_visit[6]  R1168     -23
    e2_S4_0_5_visit[6]  R1169     -2
    e2_S4_0_5_visit[6]  R1170     -2
    e2_S4_0_5_visit[6]  R1172     -23
    e2_S4_0_5_visit[6]  R1173     -23
    e2_S4_0_5_visit[6]  R1174     -2
    e2_S4_0_5_visit[6]  R1175     -2
    e2_S4_0_5_visit[6]  R1177     -23
    e2_S4_0_5_visit[6]  R1178     -23
    e2_S4_0_5_visit[6]  R1179     -2
    e2_S4_0_5_visit[6]  R1180     -2
    e2_S4_0_5_visit[6]  R1182     -23
    e2_S4_0_5_visit[6]  R1183     -23
    e2_S4_0_5_visit[6]  R1184     -2
    e2_S4_0_5_visit[6]  R1185     -2
    e2_S4_0_5_visit[6]  R1187     -23
    e2_S4_0_5_visit[6]  R1188     -23
    e2_S4_0_5_visit[6]  R1189     -2
    e2_S4_0_5_visit[6]  R1190     -2
    e2_S4_0_5_visit[6]  R1210     -1
    e2_S4_0_5_visit[6]  R1212     23
    e2_S4_0_5_visit[6]  R1213     2
    e2_S4_0_5_visit[6]  R1227     1
    e2_S4_0_5_visit[6]  R3161     -6
    e2_S4_0_5_visit[6]  R3425     1
    e2_S4_0_5_visit[7]  R1109     4
    e2_S4_0_5_visit[7]  R1110     2
    e2_S4_0_5_visit[7]  R1132     -1
    e2_S4_0_5_visit[7]  R1133     -1
    e2_S4_0_5_visit[7]  R1134     1
    e2_S4_0_5_visit[7]  R1228     -23969
    e2_S4_0_5_visit[7]  R1229     71100
    e2_S4_0_5_visit[7]  R3164     -6
    e2_S4_0_5_visit[7]  R3426     1
    e2_S4_0_5_visit[8]  R1107     21
    e2_S4_0_5_visit[8]  R1108     2
    e2_S4_0_5_visit[8]  R1135     -1
    e2_S4_0_5_visit[8]  R1136     -1
    e2_S4_0_5_visit[8]  R1137     1
    e2_S4_0_5_visit[8]  R1142     -21
    e2_S4_0_5_visit[8]  R1143     -21
    e2_S4_0_5_visit[8]  R1144     -2
    e2_S4_0_5_visit[8]  R1145     -2
    e2_S4_0_5_visit[8]  R1147     -21
    e2_S4_0_5_visit[8]  R1148     -21
    e2_S4_0_5_visit[8]  R1149     -2
    e2_S4_0_5_visit[8]  R1150     -2
    e2_S4_0_5_visit[8]  R1152     -21
    e2_S4_0_5_visit[8]  R1153     -21
    e2_S4_0_5_visit[8]  R1154     -2
    e2_S4_0_5_visit[8]  R1155     -2
    e2_S4_0_5_visit[8]  R1157     -21
    e2_S4_0_5_visit[8]  R1158     -21
    e2_S4_0_5_visit[8]  R1159     -2
    e2_S4_0_5_visit[8]  R1160     -2
    e2_S4_0_5_visit[8]  R1162     -21
    e2_S4_0_5_visit[8]  R1163     -21
    e2_S4_0_5_visit[8]  R1164     -2
    e2_S4_0_5_visit[8]  R1165     -2
    e2_S4_0_5_visit[8]  R1167     -21
    e2_S4_0_5_visit[8]  R1168     -21
    e2_S4_0_5_visit[8]  R1169     -2
    e2_S4_0_5_visit[8]  R1170     -2
    e2_S4_0_5_visit[8]  R1172     -21
    e2_S4_0_5_visit[8]  R1173     -21
    e2_S4_0_5_visit[8]  R1174     -2
    e2_S4_0_5_visit[8]  R1175     -2
    e2_S4_0_5_visit[8]  R1177     -21
    e2_S4_0_5_visit[8]  R1178     -21
    e2_S4_0_5_visit[8]  R1179     -2
    e2_S4_0_5_visit[8]  R1180     -2
    e2_S4_0_5_visit[8]  R1182     -21
    e2_S4_0_5_visit[8]  R1183     -21
    e2_S4_0_5_visit[8]  R1184     -2
    e2_S4_0_5_visit[8]  R1185     -2
    e2_S4_0_5_visit[8]  R1187     -21
    e2_S4_0_5_visit[8]  R1188     -21
    e2_S4_0_5_visit[8]  R1189     -2
    e2_S4_0_5_visit[8]  R1190     -2
    e2_S4_0_5_visit[8]  R1214     -1
    e2_S4_0_5_visit[8]  R1216     21
    e2_S4_0_5_visit[8]  R1217     2
    e2_S4_0_5_visit[8]  R1230     1
    e2_S4_0_5_visit[8]  R3167     -6
    e2_S4_0_5_visit[8]  R3429     1
    e2_S4_0_5_visit[9]  R1109     4
    e2_S4_0_5_visit[9]  R1110     2
    e2_S4_0_5_visit[9]  R1138     -1
    e2_S4_0_5_visit[9]  R1139     -1
    e2_S4_0_5_visit[9]  R1140     1
    e2_S4_0_5_visit[9]  R1231     -11425
    e2_S4_0_5_visit[9]  R1232     71100
    e2_S4_0_5_visit[9]  R3170     -6
    e2_S4_0_5_visit[9]  R3430     1
    e2_S4_0_5_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_5_arc[-1,0]  R1105     1
    e2_S4_0_5_arc[-1,0]  R1111     1
    e2_S4_0_5_arc[-1,0]  R1141     -44319
    e2_S4_0_5_arc[-1,0]  R1142     -165
    e2_S4_0_5_arc[-1,0]  R1143     180
    e2_S4_0_5_arc[-1,0]  R1144     -5
    e2_S4_0_5_arc[-1,0]  R1145     6
    e2_S4_0_5_arc[-1,0]  R1233     -30
    e2_S4_0_5_arc[-1,0]  R3144     1
    e2_S4_0_5_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_5_arc[-1,1]  R1105     1
    e2_S4_0_5_arc[-1,1]  R1114     1
    e2_S4_0_5_arc[-1,1]  R1146     -41683
    e2_S4_0_5_arc[-1,1]  R1147     -180
    e2_S4_0_5_arc[-1,1]  R1148     178
    e2_S4_0_5_arc[-1,1]  R1149     -6
    e2_S4_0_5_arc[-1,1]  R1150     5
    e2_S4_0_5_arc[-1,1]  R1234     -30
    e2_S4_0_5_arc[-1,1]  R3147     1
    e2_S4_0_5_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_5_arc[-1,2]  R1105     1
    e2_S4_0_5_arc[-1,2]  R1117     1
    e2_S4_0_5_arc[-1,2]  R1151     -44289
    e2_S4_0_5_arc[-1,2]  R1152     -157
    e2_S4_0_5_arc[-1,2]  R1153     180
    e2_S4_0_5_arc[-1,2]  R1154     -4
    e2_S4_0_5_arc[-1,2]  R1155     6
    e2_S4_0_5_arc[-1,2]  R1235     -30
    e2_S4_0_5_arc[-1,2]  R3150     1
    e2_S4_0_5_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_5_arc[-1,3]  R1105     1
    e2_S4_0_5_arc[-1,3]  R1120     1
    e2_S4_0_5_arc[-1,3]  R1156     -40989
    e2_S4_0_5_arc[-1,3]  R1157     -180
    e2_S4_0_5_arc[-1,3]  R1158     176
    e2_S4_0_5_arc[-1,3]  R1159     -6
    e2_S4_0_5_arc[-1,3]  R1160     4
    e2_S4_0_5_arc[-1,3]  R1236     -30
    e2_S4_0_5_arc[-1,3]  R3153     1
    e2_S4_0_5_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_5_arc[-1,4]  R1105     1
    e2_S4_0_5_arc[-1,4]  R1123     1
    e2_S4_0_5_arc[-1,4]  R1161     -29919
    e2_S4_0_5_arc[-1,4]  R1162     -159
    e2_S4_0_5_arc[-1,4]  R1163     180
    e2_S4_0_5_arc[-1,4]  R1164     -4
    e2_S4_0_5_arc[-1,4]  R1165     6
    e2_S4_0_5_arc[-1,4]  R1237     -30
    e2_S4_0_5_arc[-1,4]  R3156     1
    e2_S4_0_5_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_5_arc[-1,5]  R1105     1
    e2_S4_0_5_arc[-1,5]  R1126     1
    e2_S4_0_5_arc[-1,5]  R1166     -26919
    e2_S4_0_5_arc[-1,5]  R1167     -180
    e2_S4_0_5_arc[-1,5]  R1168     176
    e2_S4_0_5_arc[-1,5]  R1169     -6
    e2_S4_0_5_arc[-1,5]  R1170     4
    e2_S4_0_5_arc[-1,5]  R1238     -30
    e2_S4_0_5_arc[-1,5]  R3159     1
    e2_S4_0_5_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_5_arc[-1,6]  R1105     1
    e2_S4_0_5_arc[-1,6]  R1129     1
    e2_S4_0_5_arc[-1,6]  R1171     -29851
    e2_S4_0_5_arc[-1,6]  R1172     -157
    e2_S4_0_5_arc[-1,6]  R1173     180
    e2_S4_0_5_arc[-1,6]  R1174     -4
    e2_S4_0_5_arc[-1,6]  R1175     6
    e2_S4_0_5_arc[-1,6]  R1239     -30
    e2_S4_0_5_arc[-1,6]  R3162     1
    e2_S4_0_5_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_5_arc[-1,7]  R1105     1
    e2_S4_0_5_arc[-1,7]  R1132     1
    e2_S4_0_5_arc[-1,7]  R1176     -25651
    e2_S4_0_5_arc[-1,7]  R1177     -180
    e2_S4_0_5_arc[-1,7]  R1178     176
    e2_S4_0_5_arc[-1,7]  R1179     -6
    e2_S4_0_5_arc[-1,7]  R1180     4
    e2_S4_0_5_arc[-1,7]  R1240     -30
    e2_S4_0_5_arc[-1,7]  R3165     1
    e2_S4_0_5_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_5_arc[-1,8]  R1105     1
    e2_S4_0_5_arc[-1,8]  R1135     1
    e2_S4_0_5_arc[-1,8]  R1181     -15519
    e2_S4_0_5_arc[-1,8]  R1182     -159
    e2_S4_0_5_arc[-1,8]  R1183     180
    e2_S4_0_5_arc[-1,8]  R1184     -4
    e2_S4_0_5_arc[-1,8]  R1185     6
    e2_S4_0_5_arc[-1,8]  R1241     -30
    e2_S4_0_5_arc[-1,8]  R3168     1
    e2_S4_0_5_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_5_arc[-1,9]  R1105     1
    e2_S4_0_5_arc[-1,9]  R1138     1
    e2_S4_0_5_arc[-1,9]  R1186     -13119
    e2_S4_0_5_arc[-1,9]  R1187     -180
    e2_S4_0_5_arc[-1,9]  R1188     176
    e2_S4_0_5_arc[-1,9]  R1189     -6
    e2_S4_0_5_arc[-1,9]  R1190     4
    e2_S4_0_5_arc[-1,9]  R1242     -30
    e2_S4_0_5_arc[-1,9]  R3171     1
    e2_S4_0_5_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_5_arc[0,-2]  R1106     1
    e2_S4_0_5_arc[0,-2]  R1112     1
    e2_S4_0_5_arc[0,-2]  R1191     -33523
    e2_S4_0_5_arc[0,-2]  R1243     -30
    e2_S4_0_5_arc[0,-2]  R3145     1
    e2_S4_0_5_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_5_arc[1,-2]  R1106     1
    e2_S4_0_5_arc[1,-2]  R1115     1
    e2_S4_0_5_arc[1,-2]  R1192     -39223
    e2_S4_0_5_arc[1,-2]  R1244     -30
    e2_S4_0_5_arc[1,-2]  R3148     1
    e2_S4_0_5_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_5_arc[2,-2]  R1106     1
    e2_S4_0_5_arc[2,-2]  R1118     1
    e2_S4_0_5_arc[2,-2]  R1193     -36369
    e2_S4_0_5_arc[2,-2]  R1245     -30
    e2_S4_0_5_arc[2,-2]  R3151     1
    e2_S4_0_5_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_5_arc[3,-2]  R1106     1
    e2_S4_0_5_arc[3,-2]  R1121     1
    e2_S4_0_5_arc[3,-2]  R1194     -42129
    e2_S4_0_5_arc[3,-2]  R1246     -30
    e2_S4_0_5_arc[3,-2]  R3154     1
    e2_S4_0_5_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_5_arc[4,-2]  R1106     1
    e2_S4_0_5_arc[4,-2]  R1124     1
    e2_S4_0_5_arc[4,-2]  R1195     -48315
    e2_S4_0_5_arc[4,-2]  R1247     -30
    e2_S4_0_5_arc[4,-2]  R3157     1
    e2_S4_0_5_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_5_arc[5,-2]  R1106     1
    e2_S4_0_5_arc[5,-2]  R1127     1
    e2_S4_0_5_arc[5,-2]  R1196     -53475
    e2_S4_0_5_arc[5,-2]  R1248     -30
    e2_S4_0_5_arc[5,-2]  R3160     1
    e2_S4_0_5_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_5_arc[6,-2]  R1106     1
    e2_S4_0_5_arc[6,-2]  R1130     1
    e2_S4_0_5_arc[6,-2]  R1197     -49531
    e2_S4_0_5_arc[6,-2]  R1249     -30
    e2_S4_0_5_arc[6,-2]  R3163     1
    e2_S4_0_5_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_5_arc[7,-2]  R1106     1
    e2_S4_0_5_arc[7,-2]  R1133     1
    e2_S4_0_5_arc[7,-2]  R1198     -56191
    e2_S4_0_5_arc[7,-2]  R1250     -30
    e2_S4_0_5_arc[7,-2]  R3166     1
    e2_S4_0_5_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_5_arc[8,-2]  R1106     1
    e2_S4_0_5_arc[8,-2]  R1136     1
    e2_S4_0_5_arc[8,-2]  R1199     -63217
    e2_S4_0_5_arc[8,-2]  R1251     -30
    e2_S4_0_5_arc[8,-2]  R3169     1
    e2_S4_0_5_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_5_arc[9,-2]  R1106     1
    e2_S4_0_5_arc[9,-2]  R1139     1
    e2_S4_0_5_arc[9,-2]  R1200     -68677
    e2_S4_0_5_arc[9,-2]  R1252     -30
    e2_S4_0_5_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C731      R1203     1
    C731      R1233     -1
    C731      R1234     -1
    C731      R1235     -1
    C731      R1236     -1
    C731      R1237     -1
    C731      R1238     -1
    C731      R1239     -1
    C731      R1240     -1
    C731      R1241     -1
    C731      R1242     -1
    C732      R1243     1
    C732      R1244     1
    C732      R1245     1
    C732      R1246     1
    C732      R1247     1
    C732      R1248     1
    C732      R1249     1
    C732      R1250     1
    C732      R1251     1
    C732      R1252     1
    C732      R1354     -1
    MARKER    'MARKER'                 'INTORG'
    C733      R1204     1
    C733      R1205     -60
    C733      R1206     1
    C733      R1207     -39660
    C733      R1208     -180
    C733      R1209     -6
    C733      R1218     -1
    C733      R1221     -1
    C734      R1204     1
    C734      R1205     -60
    C734      R1210     1
    C734      R1211     -54060
    C734      R1212     -180
    C734      R1213     -6
    C734      R1224     -1
    C734      R1227     -1
    C735      R1204     1
    C735      R1205     -60
    C735      R1214     1
    C735      R1215     -71160
    C735      R1216     -180
    C735      R1217     -6
    C735      R1230     -1
    e2_S4_0_6_used  R1253     -75600
    e2_S4_0_6_used  R1254     -75600
    e2_S4_0_6_used  R1255     -28800
    e2_S4_0_6_used  R1256     -1
    e2_S4_0_6_used  R1257     -1
    e2_S4_0_6_used  R1258     -180
    e2_S4_0_6_used  R1259     -6
    e2_S4_0_6_used  R1260     -180
    e2_S4_0_6_used  R1261     -6
    e2_S4_0_6_used  R1264     -1
    e2_S4_0_6_used  R1267     -1
    e2_S4_0_6_used  R1270     -1
    e2_S4_0_6_used  R1273     -1
    e2_S4_0_6_used  R1276     -1
    e2_S4_0_6_used  R1279     -1
    e2_S4_0_6_used  R1282     -1
    e2_S4_0_6_used  R1285     -1
    e2_S4_0_6_used  R1288     -1
    e2_S4_0_6_used  R1291     -1
    e2_S4_0_6_used  R1352     -75540
    e2_S4_0_6_used  R1353     1
    e2_S4_0_6_used  R1354     -30
    e2_S4_0_6_used  R1355     -1
    e2_S4_0_6_used  R1356     -75600
    e2_S4_0_6_used  R1504     -1
    e2_S4_0_6_used  R2610     -1
    e2_S4_0_6_start  R1253     1
    e2_S4_0_6_start  R1255     1
    e2_S4_0_6_start  R1292     -1
    e2_S4_0_6_start  R1297     -1
    e2_S4_0_6_start  R1302     -1
    e2_S4_0_6_start  R1307     -1
    e2_S4_0_6_start  R1312     -1
    e2_S4_0_6_start  R1317     -1
    e2_S4_0_6_start  R1322     -1
    e2_S4_0_6_start  R1327     -1
    e2_S4_0_6_start  R1332     -1
    e2_S4_0_6_start  R1337     -1
    e2_S4_0_6_start  R1356     1
    e2_S4_0_6_start  R1358     1
    e2_S4_0_6_start  R1362     1
    e2_S4_0_6_start  R1366     1
    e2_S4_0_6_end  R1254     1
    e2_S4_0_6_end  R1342     1
    e2_S4_0_6_end  R1343     1
    e2_S4_0_6_end  R1344     1
    e2_S4_0_6_end  R1345     1
    e2_S4_0_6_end  R1346     1
    e2_S4_0_6_end  R1347     1
    e2_S4_0_6_end  R1348     1
    e2_S4_0_6_end  R1349     1
    e2_S4_0_6_end  R1350     1
    e2_S4_0_6_end  R1351     1
    e2_S4_0_6_end  R1352     1
    e2_S4_0_6_end  R1370     -1
    e2_S4_0_6_end  R1371     -1
    e2_S4_0_6_end  R1373     -1
    e2_S4_0_6_end  R1374     -1
    e2_S4_0_6_end  R1376     -1
    e2_S4_0_6_end  R1377     -1
    e2_S4_0_6_end  R1379     -1
    e2_S4_0_6_end  R1380     -1
    e2_S4_0_6_end  R1382     -1
    e2_S4_0_6_end  R1383     -1
    e2_S4_0_6_end  R1507     -1
    e2_S4_0_6_visit[0]  R1258     15
    e2_S4_0_6_visit[0]  R1259     1
    e2_S4_0_6_visit[0]  R1262     -1
    e2_S4_0_6_visit[0]  R1263     -1
    e2_S4_0_6_visit[0]  R1264     1
    e2_S4_0_6_visit[0]  R1293     -15
    e2_S4_0_6_visit[0]  R1294     -15
    e2_S4_0_6_visit[0]  R1295     -1
    e2_S4_0_6_visit[0]  R1296     -1
    e2_S4_0_6_visit[0]  R1298     -15
    e2_S4_0_6_visit[0]  R1299     -15
    e2_S4_0_6_visit[0]  R1300     -1
    e2_S4_0_6_visit[0]  R1301     -1
    e2_S4_0_6_visit[0]  R1303     -15
    e2_S4_0_6_visit[0]  R1304     -15
    e2_S4_0_6_visit[0]  R1305     -1
    e2_S4_0_6_visit[0]  R1306     -1
    e2_S4_0_6_visit[0]  R1308     -15
    e2_S4_0_6_visit[0]  R1309     -15
    e2_S4_0_6_visit[0]  R1310     -1
    e2_S4_0_6_visit[0]  R1311     -1
    e2_S4_0_6_visit[0]  R1313     -15
    e2_S4_0_6_visit[0]  R1314     -15
    e2_S4_0_6_visit[0]  R1315     -1
    e2_S4_0_6_visit[0]  R1316     -1
    e2_S4_0_6_visit[0]  R1318     -15
    e2_S4_0_6_visit[0]  R1319     -15
    e2_S4_0_6_visit[0]  R1320     -1
    e2_S4_0_6_visit[0]  R1321     -1
    e2_S4_0_6_visit[0]  R1323     -15
    e2_S4_0_6_visit[0]  R1324     -15
    e2_S4_0_6_visit[0]  R1325     -1
    e2_S4_0_6_visit[0]  R1326     -1
    e2_S4_0_6_visit[0]  R1328     -15
    e2_S4_0_6_visit[0]  R1329     -15
    e2_S4_0_6_visit[0]  R1330     -1
    e2_S4_0_6_visit[0]  R1331     -1
    e2_S4_0_6_visit[0]  R1333     -15
    e2_S4_0_6_visit[0]  R1334     -15
    e2_S4_0_6_visit[0]  R1335     -1
    e2_S4_0_6_visit[0]  R1336     -1
    e2_S4_0_6_visit[0]  R1338     -15
    e2_S4_0_6_visit[0]  R1339     -15
    e2_S4_0_6_visit[0]  R1340     -1
    e2_S4_0_6_visit[0]  R1341     -1
    e2_S4_0_6_visit[0]  R1357     -1
    e2_S4_0_6_visit[0]  R1359     15
    e2_S4_0_6_visit[0]  R1360     1
    e2_S4_0_6_visit[0]  R1369     1
    e2_S4_0_6_visit[0]  R3143     -7
    e2_S4_0_6_visit[0]  R3413     1
    e2_S4_0_6_visit[1]  R1260     2
    e2_S4_0_6_visit[1]  R1261     1
    e2_S4_0_6_visit[1]  R1265     -1
    e2_S4_0_6_visit[1]  R1266     -1
    e2_S4_0_6_visit[1]  R1267     1
    e2_S4_0_6_visit[1]  R1370     -40937
    e2_S4_0_6_visit[1]  R1371     71100
    e2_S4_0_6_visit[1]  R3146     -7
    e2_S4_0_6_visit[1]  R3414     1
    e2_S4_0_6_visit[2]  R1258     23
    e2_S4_0_6_visit[2]  R1259     2
    e2_S4_0_6_visit[2]  R1268     -1
    e2_S4_0_6_visit[2]  R1269     -1
    e2_S4_0_6_visit[2]  R1270     1
    e2_S4_0_6_visit[2]  R1293     -23
    e2_S4_0_6_visit[2]  R1294     -23
    e2_S4_0_6_visit[2]  R1295     -2
    e2_S4_0_6_visit[2]  R1296     -2
    e2_S4_0_6_visit[2]  R1298     -23
    e2_S4_0_6_visit[2]  R1299     -23
    e2_S4_0_6_visit[2]  R1300     -2
    e2_S4_0_6_visit[2]  R1301     -2
    e2_S4_0_6_visit[2]  R1303     -23
    e2_S4_0_6_visit[2]  R1304     -23
    e2_S4_0_6_visit[2]  R1305     -2
    e2_S4_0_6_visit[2]  R1306     -2
    e2_S4_0_6_visit[2]  R1308     -23
    e2_S4_0_6_visit[2]  R1309     -23
    e2_S4_0_6_visit[2]  R1310     -2
    e2_S4_0_6_visit[2]  R1311     -2
    e2_S4_0_6_visit[2]  R1313     -23
    e2_S4_0_6_visit[2]  R1314     -23
    e2_S4_0_6_visit[2]  R1315     -2
    e2_S4_0_6_visit[2]  R1316     -2
    e2_S4_0_6_visit[2]  R1318     -23
    e2_S4_0_6_visit[2]  R1319     -23
    e2_S4_0_6_visit[2]  R1320     -2
    e2_S4_0_6_visit[2]  R1321     -2
    e2_S4_0_6_visit[2]  R1323     -23
    e2_S4_0_6_visit[2]  R1324     -23
    e2_S4_0_6_visit[2]  R1325     -2
    e2_S4_0_6_visit[2]  R1326     -2
    e2_S4_0_6_visit[2]  R1328     -23
    e2_S4_0_6_visit[2]  R1329     -23
    e2_S4_0_6_visit[2]  R1330     -2
    e2_S4_0_6_visit[2]  R1331     -2
    e2_S4_0_6_visit[2]  R1333     -23
    e2_S4_0_6_visit[2]  R1334     -23
    e2_S4_0_6_visit[2]  R1335     -2
    e2_S4_0_6_visit[2]  R1336     -2
    e2_S4_0_6_visit[2]  R1338     -23
    e2_S4_0_6_visit[2]  R1339     -23
    e2_S4_0_6_visit[2]  R1340     -2
    e2_S4_0_6_visit[2]  R1341     -2
    e2_S4_0_6_visit[2]  R1357     -1
    e2_S4_0_6_visit[2]  R1359     23
    e2_S4_0_6_visit[2]  R1360     2
    e2_S4_0_6_visit[2]  R1372     1
    e2_S4_0_6_visit[2]  R3149     -7
    e2_S4_0_6_visit[2]  R3417     1
    e2_S4_0_6_visit[3]  R1260     4
    e2_S4_0_6_visit[3]  R1261     2
    e2_S4_0_6_visit[3]  R1271     -1
    e2_S4_0_6_visit[3]  R1272     -1
    e2_S4_0_6_visit[3]  R1273     1
    e2_S4_0_6_visit[3]  R1373     -38031
    e2_S4_0_6_visit[3]  R1374     71100
    e2_S4_0_6_visit[3]  R3152     -7
    e2_S4_0_6_visit[3]  R3418     1
    e2_S4_0_6_visit[4]  R1258     21
    e2_S4_0_6_visit[4]  R1259     2
    e2_S4_0_6_visit[4]  R1274     -1
    e2_S4_0_6_visit[4]  R1275     -1
    e2_S4_0_6_visit[4]  R1276     1
    e2_S4_0_6_visit[4]  R1293     -21
    e2_S4_0_6_visit[4]  R1294     -21
    e2_S4_0_6_visit[4]  R1295     -2
    e2_S4_0_6_visit[4]  R1296     -2
    e2_S4_0_6_visit[4]  R1298     -21
    e2_S4_0_6_visit[4]  R1299     -21
    e2_S4_0_6_visit[4]  R1300     -2
    e2_S4_0_6_visit[4]  R1301     -2
    e2_S4_0_6_visit[4]  R1303     -21
    e2_S4_0_6_visit[4]  R1304     -21
    e2_S4_0_6_visit[4]  R1305     -2
    e2_S4_0_6_visit[4]  R1306     -2
    e2_S4_0_6_visit[4]  R1308     -21
    e2_S4_0_6_visit[4]  R1309     -21
    e2_S4_0_6_visit[4]  R1310     -2
    e2_S4_0_6_visit[4]  R1311     -2
    e2_S4_0_6_visit[4]  R1313     -21
    e2_S4_0_6_visit[4]  R1314     -21
    e2_S4_0_6_visit[4]  R1315     -2
    e2_S4_0_6_visit[4]  R1316     -2
    e2_S4_0_6_visit[4]  R1318     -21
    e2_S4_0_6_visit[4]  R1319     -21
    e2_S4_0_6_visit[4]  R1320     -2
    e2_S4_0_6_visit[4]  R1321     -2
    e2_S4_0_6_visit[4]  R1323     -21
    e2_S4_0_6_visit[4]  R1324     -21
    e2_S4_0_6_visit[4]  R1325     -2
    e2_S4_0_6_visit[4]  R1326     -2
    e2_S4_0_6_visit[4]  R1328     -21
    e2_S4_0_6_visit[4]  R1329     -21
    e2_S4_0_6_visit[4]  R1330     -2
    e2_S4_0_6_visit[4]  R1331     -2
    e2_S4_0_6_visit[4]  R1333     -21
    e2_S4_0_6_visit[4]  R1334     -21
    e2_S4_0_6_visit[4]  R1335     -2
    e2_S4_0_6_visit[4]  R1336     -2
    e2_S4_0_6_visit[4]  R1338     -21
    e2_S4_0_6_visit[4]  R1339     -21
    e2_S4_0_6_visit[4]  R1340     -2
    e2_S4_0_6_visit[4]  R1341     -2
    e2_S4_0_6_visit[4]  R1361     -1
    e2_S4_0_6_visit[4]  R1363     21
    e2_S4_0_6_visit[4]  R1364     2
    e2_S4_0_6_visit[4]  R1375     1
    e2_S4_0_6_visit[4]  R3155     -7
    e2_S4_0_6_visit[4]  R3421     1
    e2_S4_0_6_visit[5]  R1260     4
    e2_S4_0_6_visit[5]  R1261     2
    e2_S4_0_6_visit[5]  R1277     -1
    e2_S4_0_6_visit[5]  R1278     -1
    e2_S4_0_6_visit[5]  R1279     1
    e2_S4_0_6_visit[5]  R1376     -25749
    e2_S4_0_6_visit[5]  R1377     71100
    e2_S4_0_6_visit[5]  R3158     -7
    e2_S4_0_6_visit[5]  R3422     1
    e2_S4_0_6_visit[6]  R1258     23
    e2_S4_0_6_visit[6]  R1259     2
    e2_S4_0_6_visit[6]  R1280     -1
    e2_S4_0_6_visit[6]  R1281     -1
    e2_S4_0_6_visit[6]  R1282     1
    e2_S4_0_6_visit[6]  R1293     -23
    e2_S4_0_6_visit[6]  R1294     -23
    e2_S4_0_6_visit[6]  R1295     -2
    e2_S4_0_6_visit[6]  R1296     -2
    e2_S4_0_6_visit[6]  R1298     -23
    e2_S4_0_6_visit[6]  R1299     -23
    e2_S4_0_6_visit[6]  R1300     -2
    e2_S4_0_6_visit[6]  R1301     -2
    e2_S4_0_6_visit[6]  R1303     -23
    e2_S4_0_6_visit[6]  R1304     -23
    e2_S4_0_6_visit[6]  R1305     -2
    e2_S4_0_6_visit[6]  R1306     -2
    e2_S4_0_6_visit[6]  R1308     -23
    e2_S4_0_6_visit[6]  R1309     -23
    e2_S4_0_6_visit[6]  R1310     -2
    e2_S4_0_6_visit[6]  R1311     -2
    e2_S4_0_6_visit[6]  R1313     -23
    e2_S4_0_6_visit[6]  R1314     -23
    e2_S4_0_6_visit[6]  R1315     -2
    e2_S4_0_6_visit[6]  R1316     -2
    e2_S4_0_6_visit[6]  R1318     -23
    e2_S4_0_6_visit[6]  R1319     -23
    e2_S4_0_6_visit[6]  R1320     -2
    e2_S4_0_6_visit[6]  R1321     -2
    e2_S4_0_6_visit[6]  R1323     -23
    e2_S4_0_6_visit[6]  R1324     -23
    e2_S4_0_6_visit[6]  R1325     -2
    e2_S4_0_6_visit[6]  R1326     -2
    e2_S4_0_6_visit[6]  R1328     -23
    e2_S4_0_6_visit[6]  R1329     -23
    e2_S4_0_6_visit[6]  R1330     -2
    e2_S4_0_6_visit[6]  R1331     -2
    e2_S4_0_6_visit[6]  R1333     -23
    e2_S4_0_6_visit[6]  R1334     -23
    e2_S4_0_6_visit[6]  R1335     -2
    e2_S4_0_6_visit[6]  R1336     -2
    e2_S4_0_6_visit[6]  R1338     -23
    e2_S4_0_6_visit[6]  R1339     -23
    e2_S4_0_6_visit[6]  R1340     -2
    e2_S4_0_6_visit[6]  R1341     -2
    e2_S4_0_6_visit[6]  R1361     -1
    e2_S4_0_6_visit[6]  R1363     23
    e2_S4_0_6_visit[6]  R1364     2
    e2_S4_0_6_visit[6]  R1378     1
    e2_S4_0_6_visit[6]  R3161     -7
    e2_S4_0_6_visit[6]  R3425     1
    e2_S4_0_6_visit[7]  R1260     4
    e2_S4_0_6_visit[7]  R1261     2
    e2_S4_0_6_visit[7]  R1283     -1
    e2_S4_0_6_visit[7]  R1284     -1
    e2_S4_0_6_visit[7]  R1285     1
    e2_S4_0_6_visit[7]  R1379     -23969
    e2_S4_0_6_visit[7]  R1380     71100
    e2_S4_0_6_visit[7]  R3164     -7
    e2_S4_0_6_visit[7]  R3426     1
    e2_S4_0_6_visit[8]  R1258     21
    e2_S4_0_6_visit[8]  R1259     2
    e2_S4_0_6_visit[8]  R1286     -1
    e2_S4_0_6_visit[8]  R1287     -1
    e2_S4_0_6_visit[8]  R1288     1
    e2_S4_0_6_visit[8]  R1293     -21
    e2_S4_0_6_visit[8]  R1294     -21
    e2_S4_0_6_visit[8]  R1295     -2
    e2_S4_0_6_visit[8]  R1296     -2
    e2_S4_0_6_visit[8]  R1298     -21
    e2_S4_0_6_visit[8]  R1299     -21
    e2_S4_0_6_visit[8]  R1300     -2
    e2_S4_0_6_visit[8]  R1301     -2
    e2_S4_0_6_visit[8]  R1303     -21
    e2_S4_0_6_visit[8]  R1304     -21
    e2_S4_0_6_visit[8]  R1305     -2
    e2_S4_0_6_visit[8]  R1306     -2
    e2_S4_0_6_visit[8]  R1308     -21
    e2_S4_0_6_visit[8]  R1309     -21
    e2_S4_0_6_visit[8]  R1310     -2
    e2_S4_0_6_visit[8]  R1311     -2
    e2_S4_0_6_visit[8]  R1313     -21
    e2_S4_0_6_visit[8]  R1314     -21
    e2_S4_0_6_visit[8]  R1315     -2
    e2_S4_0_6_visit[8]  R1316     -2
    e2_S4_0_6_visit[8]  R1318     -21
    e2_S4_0_6_visit[8]  R1319     -21
    e2_S4_0_6_visit[8]  R1320     -2
    e2_S4_0_6_visit[8]  R1321     -2
    e2_S4_0_6_visit[8]  R1323     -21
    e2_S4_0_6_visit[8]  R1324     -21
    e2_S4_0_6_visit[8]  R1325     -2
    e2_S4_0_6_visit[8]  R1326     -2
    e2_S4_0_6_visit[8]  R1328     -21
    e2_S4_0_6_visit[8]  R1329     -21
    e2_S4_0_6_visit[8]  R1330     -2
    e2_S4_0_6_visit[8]  R1331     -2
    e2_S4_0_6_visit[8]  R1333     -21
    e2_S4_0_6_visit[8]  R1334     -21
    e2_S4_0_6_visit[8]  R1335     -2
    e2_S4_0_6_visit[8]  R1336     -2
    e2_S4_0_6_visit[8]  R1338     -21
    e2_S4_0_6_visit[8]  R1339     -21
    e2_S4_0_6_visit[8]  R1340     -2
    e2_S4_0_6_visit[8]  R1341     -2
    e2_S4_0_6_visit[8]  R1365     -1
    e2_S4_0_6_visit[8]  R1367     21
    e2_S4_0_6_visit[8]  R1368     2
    e2_S4_0_6_visit[8]  R1381     1
    e2_S4_0_6_visit[8]  R3167     -7
    e2_S4_0_6_visit[8]  R3429     1
    e2_S4_0_6_visit[9]  R1260     4
    e2_S4_0_6_visit[9]  R1261     2
    e2_S4_0_6_visit[9]  R1289     -1
    e2_S4_0_6_visit[9]  R1290     -1
    e2_S4_0_6_visit[9]  R1291     1
    e2_S4_0_6_visit[9]  R1382     -11425
    e2_S4_0_6_visit[9]  R1383     71100
    e2_S4_0_6_visit[9]  R3170     -7
    e2_S4_0_6_visit[9]  R3430     1
    e2_S4_0_6_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_6_arc[-1,0]  R1256     1
    e2_S4_0_6_arc[-1,0]  R1262     1
    e2_S4_0_6_arc[-1,0]  R1292     -44319
    e2_S4_0_6_arc[-1,0]  R1293     -165
    e2_S4_0_6_arc[-1,0]  R1294     180
    e2_S4_0_6_arc[-1,0]  R1295     -5
    e2_S4_0_6_arc[-1,0]  R1296     6
    e2_S4_0_6_arc[-1,0]  R1384     -30
    e2_S4_0_6_arc[-1,0]  R3144     1
    e2_S4_0_6_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_6_arc[-1,1]  R1256     1
    e2_S4_0_6_arc[-1,1]  R1265     1
    e2_S4_0_6_arc[-1,1]  R1297     -41683
    e2_S4_0_6_arc[-1,1]  R1298     -180
    e2_S4_0_6_arc[-1,1]  R1299     178
    e2_S4_0_6_arc[-1,1]  R1300     -6
    e2_S4_0_6_arc[-1,1]  R1301     5
    e2_S4_0_6_arc[-1,1]  R1385     -30
    e2_S4_0_6_arc[-1,1]  R3147     1
    e2_S4_0_6_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_6_arc[-1,2]  R1256     1
    e2_S4_0_6_arc[-1,2]  R1268     1
    e2_S4_0_6_arc[-1,2]  R1302     -44289
    e2_S4_0_6_arc[-1,2]  R1303     -157
    e2_S4_0_6_arc[-1,2]  R1304     180
    e2_S4_0_6_arc[-1,2]  R1305     -4
    e2_S4_0_6_arc[-1,2]  R1306     6
    e2_S4_0_6_arc[-1,2]  R1386     -30
    e2_S4_0_6_arc[-1,2]  R3150     1
    e2_S4_0_6_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_6_arc[-1,3]  R1256     1
    e2_S4_0_6_arc[-1,3]  R1271     1
    e2_S4_0_6_arc[-1,3]  R1307     -40989
    e2_S4_0_6_arc[-1,3]  R1308     -180
    e2_S4_0_6_arc[-1,3]  R1309     176
    e2_S4_0_6_arc[-1,3]  R1310     -6
    e2_S4_0_6_arc[-1,3]  R1311     4
    e2_S4_0_6_arc[-1,3]  R1387     -30
    e2_S4_0_6_arc[-1,3]  R3153     1
    e2_S4_0_6_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_6_arc[-1,4]  R1256     1
    e2_S4_0_6_arc[-1,4]  R1274     1
    e2_S4_0_6_arc[-1,4]  R1312     -29919
    e2_S4_0_6_arc[-1,4]  R1313     -159
    e2_S4_0_6_arc[-1,4]  R1314     180
    e2_S4_0_6_arc[-1,4]  R1315     -4
    e2_S4_0_6_arc[-1,4]  R1316     6
    e2_S4_0_6_arc[-1,4]  R1388     -30
    e2_S4_0_6_arc[-1,4]  R3156     1
    e2_S4_0_6_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_6_arc[-1,5]  R1256     1
    e2_S4_0_6_arc[-1,5]  R1277     1
    e2_S4_0_6_arc[-1,5]  R1317     -26919
    e2_S4_0_6_arc[-1,5]  R1318     -180
    e2_S4_0_6_arc[-1,5]  R1319     176
    e2_S4_0_6_arc[-1,5]  R1320     -6
    e2_S4_0_6_arc[-1,5]  R1321     4
    e2_S4_0_6_arc[-1,5]  R1389     -30
    e2_S4_0_6_arc[-1,5]  R3159     1
    e2_S4_0_6_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_6_arc[-1,6]  R1256     1
    e2_S4_0_6_arc[-1,6]  R1280     1
    e2_S4_0_6_arc[-1,6]  R1322     -29851
    e2_S4_0_6_arc[-1,6]  R1323     -157
    e2_S4_0_6_arc[-1,6]  R1324     180
    e2_S4_0_6_arc[-1,6]  R1325     -4
    e2_S4_0_6_arc[-1,6]  R1326     6
    e2_S4_0_6_arc[-1,6]  R1390     -30
    e2_S4_0_6_arc[-1,6]  R3162     1
    e2_S4_0_6_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_6_arc[-1,7]  R1256     1
    e2_S4_0_6_arc[-1,7]  R1283     1
    e2_S4_0_6_arc[-1,7]  R1327     -25651
    e2_S4_0_6_arc[-1,7]  R1328     -180
    e2_S4_0_6_arc[-1,7]  R1329     176
    e2_S4_0_6_arc[-1,7]  R1330     -6
    e2_S4_0_6_arc[-1,7]  R1331     4
    e2_S4_0_6_arc[-1,7]  R1391     -30
    e2_S4_0_6_arc[-1,7]  R3165     1
    e2_S4_0_6_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_6_arc[-1,8]  R1256     1
    e2_S4_0_6_arc[-1,8]  R1286     1
    e2_S4_0_6_arc[-1,8]  R1332     -15519
    e2_S4_0_6_arc[-1,8]  R1333     -159
    e2_S4_0_6_arc[-1,8]  R1334     180
    e2_S4_0_6_arc[-1,8]  R1335     -4
    e2_S4_0_6_arc[-1,8]  R1336     6
    e2_S4_0_6_arc[-1,8]  R1392     -30
    e2_S4_0_6_arc[-1,8]  R3168     1
    e2_S4_0_6_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_6_arc[-1,9]  R1256     1
    e2_S4_0_6_arc[-1,9]  R1289     1
    e2_S4_0_6_arc[-1,9]  R1337     -13119
    e2_S4_0_6_arc[-1,9]  R1338     -180
    e2_S4_0_6_arc[-1,9]  R1339     176
    e2_S4_0_6_arc[-1,9]  R1340     -6
    e2_S4_0_6_arc[-1,9]  R1341     4
    e2_S4_0_6_arc[-1,9]  R1393     -30
    e2_S4_0_6_arc[-1,9]  R3171     1
    e2_S4_0_6_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_6_arc[0,-2]  R1257     1
    e2_S4_0_6_arc[0,-2]  R1263     1
    e2_S4_0_6_arc[0,-2]  R1342     -33523
    e2_S4_0_6_arc[0,-2]  R1394     -30
    e2_S4_0_6_arc[0,-2]  R3145     1
    e2_S4_0_6_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_6_arc[1,-2]  R1257     1
    e2_S4_0_6_arc[1,-2]  R1266     1
    e2_S4_0_6_arc[1,-2]  R1343     -39223
    e2_S4_0_6_arc[1,-2]  R1395     -30
    e2_S4_0_6_arc[1,-2]  R3148     1
    e2_S4_0_6_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_6_arc[2,-2]  R1257     1
    e2_S4_0_6_arc[2,-2]  R1269     1
    e2_S4_0_6_arc[2,-2]  R1344     -36369
    e2_S4_0_6_arc[2,-2]  R1396     -30
    e2_S4_0_6_arc[2,-2]  R3151     1
    e2_S4_0_6_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_6_arc[3,-2]  R1257     1
    e2_S4_0_6_arc[3,-2]  R1272     1
    e2_S4_0_6_arc[3,-2]  R1345     -42129
    e2_S4_0_6_arc[3,-2]  R1397     -30
    e2_S4_0_6_arc[3,-2]  R3154     1
    e2_S4_0_6_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_6_arc[4,-2]  R1257     1
    e2_S4_0_6_arc[4,-2]  R1275     1
    e2_S4_0_6_arc[4,-2]  R1346     -48315
    e2_S4_0_6_arc[4,-2]  R1398     -30
    e2_S4_0_6_arc[4,-2]  R3157     1
    e2_S4_0_6_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_6_arc[5,-2]  R1257     1
    e2_S4_0_6_arc[5,-2]  R1278     1
    e2_S4_0_6_arc[5,-2]  R1347     -53475
    e2_S4_0_6_arc[5,-2]  R1399     -30
    e2_S4_0_6_arc[5,-2]  R3160     1
    e2_S4_0_6_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_6_arc[6,-2]  R1257     1
    e2_S4_0_6_arc[6,-2]  R1281     1
    e2_S4_0_6_arc[6,-2]  R1348     -49531
    e2_S4_0_6_arc[6,-2]  R1400     -30
    e2_S4_0_6_arc[6,-2]  R3163     1
    e2_S4_0_6_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_6_arc[7,-2]  R1257     1
    e2_S4_0_6_arc[7,-2]  R1284     1
    e2_S4_0_6_arc[7,-2]  R1349     -56191
    e2_S4_0_6_arc[7,-2]  R1401     -30
    e2_S4_0_6_arc[7,-2]  R3166     1
    e2_S4_0_6_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_6_arc[8,-2]  R1257     1
    e2_S4_0_6_arc[8,-2]  R1287     1
    e2_S4_0_6_arc[8,-2]  R1350     -63217
    e2_S4_0_6_arc[8,-2]  R1402     -30
    e2_S4_0_6_arc[8,-2]  R3169     1
    e2_S4_0_6_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_6_arc[9,-2]  R1257     1
    e2_S4_0_6_arc[9,-2]  R1290     1
    e2_S4_0_6_arc[9,-2]  R1351     -68677
    e2_S4_0_6_arc[9,-2]  R1403     -30
    e2_S4_0_6_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C769      R1354     1
    C769      R1384     -1
    C769      R1385     -1
    C769      R1386     -1
    C769      R1387     -1
    C769      R1388     -1
    C769      R1389     -1
    C769      R1390     -1
    C769      R1391     -1
    C769      R1392     -1
    C769      R1393     -1
    C770      R1394     1
    C770      R1395     1
    C770      R1396     1
    C770      R1397     1
    C770      R1398     1
    C770      R1399     1
    C770      R1400     1
    C770      R1401     1
    C770      R1402     1
    C770      R1403     1
    C770      R1505     -1
    MARKER    'MARKER'                 'INTORG'
    C771      R1355     1
    C771      R1356     -60
    C771      R1357     1
    C771      R1358     -39660
    C771      R1359     -180
    C771      R1360     -6
    C771      R1369     -1
    C771      R1372     -1
    C772      R1355     1
    C772      R1356     -60
    C772      R1361     1
    C772      R1362     -54060
    C772      R1363     -180
    C772      R1364     -6
    C772      R1375     -1
    C772      R1378     -1
    C773      R1355     1
    C773      R1356     -60
    C773      R1365     1
    C773      R1366     -71160
    C773      R1367     -180
    C773      R1368     -6
    C773      R1381     -1
    e2_S4_0_7_used  R1404     -75600
    e2_S4_0_7_used  R1405     -75600
    e2_S4_0_7_used  R1406     -28800
    e2_S4_0_7_used  R1407     -1
    e2_S4_0_7_used  R1408     -1
    e2_S4_0_7_used  R1409     -180
    e2_S4_0_7_used  R1410     -6
    e2_S4_0_7_used  R1411     -180
    e2_S4_0_7_used  R1412     -6
    e2_S4_0_7_used  R1415     -1
    e2_S4_0_7_used  R1418     -1
    e2_S4_0_7_used  R1421     -1
    e2_S4_0_7_used  R1424     -1
    e2_S4_0_7_used  R1427     -1
    e2_S4_0_7_used  R1430     -1
    e2_S4_0_7_used  R1433     -1
    e2_S4_0_7_used  R1436     -1
    e2_S4_0_7_used  R1439     -1
    e2_S4_0_7_used  R1442     -1
    e2_S4_0_7_used  R1503     -75540
    e2_S4_0_7_used  R1504     1
    e2_S4_0_7_used  R1505     -30
    e2_S4_0_7_used  R1506     -1
    e2_S4_0_7_used  R1507     -75600
    e2_S4_0_7_used  R1655     -1
    e2_S4_0_7_used  R2610     -1
    e2_S4_0_7_start  R1404     1
    e2_S4_0_7_start  R1406     1
    e2_S4_0_7_start  R1443     -1
    e2_S4_0_7_start  R1448     -1
    e2_S4_0_7_start  R1453     -1
    e2_S4_0_7_start  R1458     -1
    e2_S4_0_7_start  R1463     -1
    e2_S4_0_7_start  R1468     -1
    e2_S4_0_7_start  R1473     -1
    e2_S4_0_7_start  R1478     -1
    e2_S4_0_7_start  R1483     -1
    e2_S4_0_7_start  R1488     -1
    e2_S4_0_7_start  R1507     1
    e2_S4_0_7_start  R1509     1
    e2_S4_0_7_start  R1513     1
    e2_S4_0_7_start  R1517     1
    e2_S4_0_7_end  R1405     1
    e2_S4_0_7_end  R1493     1
    e2_S4_0_7_end  R1494     1
    e2_S4_0_7_end  R1495     1
    e2_S4_0_7_end  R1496     1
    e2_S4_0_7_end  R1497     1
    e2_S4_0_7_end  R1498     1
    e2_S4_0_7_end  R1499     1
    e2_S4_0_7_end  R1500     1
    e2_S4_0_7_end  R1501     1
    e2_S4_0_7_end  R1502     1
    e2_S4_0_7_end  R1503     1
    e2_S4_0_7_end  R1521     -1
    e2_S4_0_7_end  R1522     -1
    e2_S4_0_7_end  R1524     -1
    e2_S4_0_7_end  R1525     -1
    e2_S4_0_7_end  R1527     -1
    e2_S4_0_7_end  R1528     -1
    e2_S4_0_7_end  R1530     -1
    e2_S4_0_7_end  R1531     -1
    e2_S4_0_7_end  R1533     -1
    e2_S4_0_7_end  R1534     -1
    e2_S4_0_7_end  R1658     -1
    e2_S4_0_7_visit[0]  R1409     15
    e2_S4_0_7_visit[0]  R1410     1
    e2_S4_0_7_visit[0]  R1413     -1
    e2_S4_0_7_visit[0]  R1414     -1
    e2_S4_0_7_visit[0]  R1415     1
    e2_S4_0_7_visit[0]  R1444     -15
    e2_S4_0_7_visit[0]  R1445     -15
    e2_S4_0_7_visit[0]  R1446     -1
    e2_S4_0_7_visit[0]  R1447     -1
    e2_S4_0_7_visit[0]  R1449     -15
    e2_S4_0_7_visit[0]  R1450     -15
    e2_S4_0_7_visit[0]  R1451     -1
    e2_S4_0_7_visit[0]  R1452     -1
    e2_S4_0_7_visit[0]  R1454     -15
    e2_S4_0_7_visit[0]  R1455     -15
    e2_S4_0_7_visit[0]  R1456     -1
    e2_S4_0_7_visit[0]  R1457     -1
    e2_S4_0_7_visit[0]  R1459     -15
    e2_S4_0_7_visit[0]  R1460     -15
    e2_S4_0_7_visit[0]  R1461     -1
    e2_S4_0_7_visit[0]  R1462     -1
    e2_S4_0_7_visit[0]  R1464     -15
    e2_S4_0_7_visit[0]  R1465     -15
    e2_S4_0_7_visit[0]  R1466     -1
    e2_S4_0_7_visit[0]  R1467     -1
    e2_S4_0_7_visit[0]  R1469     -15
    e2_S4_0_7_visit[0]  R1470     -15
    e2_S4_0_7_visit[0]  R1471     -1
    e2_S4_0_7_visit[0]  R1472     -1
    e2_S4_0_7_visit[0]  R1474     -15
    e2_S4_0_7_visit[0]  R1475     -15
    e2_S4_0_7_visit[0]  R1476     -1
    e2_S4_0_7_visit[0]  R1477     -1
    e2_S4_0_7_visit[0]  R1479     -15
    e2_S4_0_7_visit[0]  R1480     -15
    e2_S4_0_7_visit[0]  R1481     -1
    e2_S4_0_7_visit[0]  R1482     -1
    e2_S4_0_7_visit[0]  R1484     -15
    e2_S4_0_7_visit[0]  R1485     -15
    e2_S4_0_7_visit[0]  R1486     -1
    e2_S4_0_7_visit[0]  R1487     -1
    e2_S4_0_7_visit[0]  R1489     -15
    e2_S4_0_7_visit[0]  R1490     -15
    e2_S4_0_7_visit[0]  R1491     -1
    e2_S4_0_7_visit[0]  R1492     -1
    e2_S4_0_7_visit[0]  R1508     -1
    e2_S4_0_7_visit[0]  R1510     15
    e2_S4_0_7_visit[0]  R1511     1
    e2_S4_0_7_visit[0]  R1520     1
    e2_S4_0_7_visit[0]  R3143     -8
    e2_S4_0_7_visit[0]  R3413     1
    e2_S4_0_7_visit[1]  R1411     2
    e2_S4_0_7_visit[1]  R1412     1
    e2_S4_0_7_visit[1]  R1416     -1
    e2_S4_0_7_visit[1]  R1417     -1
    e2_S4_0_7_visit[1]  R1418     1
    e2_S4_0_7_visit[1]  R1521     -40937
    e2_S4_0_7_visit[1]  R1522     71100
    e2_S4_0_7_visit[1]  R3146     -8
    e2_S4_0_7_visit[1]  R3414     1
    e2_S4_0_7_visit[2]  R1409     23
    e2_S4_0_7_visit[2]  R1410     2
    e2_S4_0_7_visit[2]  R1419     -1
    e2_S4_0_7_visit[2]  R1420     -1
    e2_S4_0_7_visit[2]  R1421     1
    e2_S4_0_7_visit[2]  R1444     -23
    e2_S4_0_7_visit[2]  R1445     -23
    e2_S4_0_7_visit[2]  R1446     -2
    e2_S4_0_7_visit[2]  R1447     -2
    e2_S4_0_7_visit[2]  R1449     -23
    e2_S4_0_7_visit[2]  R1450     -23
    e2_S4_0_7_visit[2]  R1451     -2
    e2_S4_0_7_visit[2]  R1452     -2
    e2_S4_0_7_visit[2]  R1454     -23
    e2_S4_0_7_visit[2]  R1455     -23
    e2_S4_0_7_visit[2]  R1456     -2
    e2_S4_0_7_visit[2]  R1457     -2
    e2_S4_0_7_visit[2]  R1459     -23
    e2_S4_0_7_visit[2]  R1460     -23
    e2_S4_0_7_visit[2]  R1461     -2
    e2_S4_0_7_visit[2]  R1462     -2
    e2_S4_0_7_visit[2]  R1464     -23
    e2_S4_0_7_visit[2]  R1465     -23
    e2_S4_0_7_visit[2]  R1466     -2
    e2_S4_0_7_visit[2]  R1467     -2
    e2_S4_0_7_visit[2]  R1469     -23
    e2_S4_0_7_visit[2]  R1470     -23
    e2_S4_0_7_visit[2]  R1471     -2
    e2_S4_0_7_visit[2]  R1472     -2
    e2_S4_0_7_visit[2]  R1474     -23
    e2_S4_0_7_visit[2]  R1475     -23
    e2_S4_0_7_visit[2]  R1476     -2
    e2_S4_0_7_visit[2]  R1477     -2
    e2_S4_0_7_visit[2]  R1479     -23
    e2_S4_0_7_visit[2]  R1480     -23
    e2_S4_0_7_visit[2]  R1481     -2
    e2_S4_0_7_visit[2]  R1482     -2
    e2_S4_0_7_visit[2]  R1484     -23
    e2_S4_0_7_visit[2]  R1485     -23
    e2_S4_0_7_visit[2]  R1486     -2
    e2_S4_0_7_visit[2]  R1487     -2
    e2_S4_0_7_visit[2]  R1489     -23
    e2_S4_0_7_visit[2]  R1490     -23
    e2_S4_0_7_visit[2]  R1491     -2
    e2_S4_0_7_visit[2]  R1492     -2
    e2_S4_0_7_visit[2]  R1508     -1
    e2_S4_0_7_visit[2]  R1510     23
    e2_S4_0_7_visit[2]  R1511     2
    e2_S4_0_7_visit[2]  R1523     1
    e2_S4_0_7_visit[2]  R3149     -8
    e2_S4_0_7_visit[2]  R3417     1
    e2_S4_0_7_visit[3]  R1411     4
    e2_S4_0_7_visit[3]  R1412     2
    e2_S4_0_7_visit[3]  R1422     -1
    e2_S4_0_7_visit[3]  R1423     -1
    e2_S4_0_7_visit[3]  R1424     1
    e2_S4_0_7_visit[3]  R1524     -38031
    e2_S4_0_7_visit[3]  R1525     71100
    e2_S4_0_7_visit[3]  R3152     -8
    e2_S4_0_7_visit[3]  R3418     1
    e2_S4_0_7_visit[4]  R1409     21
    e2_S4_0_7_visit[4]  R1410     2
    e2_S4_0_7_visit[4]  R1425     -1
    e2_S4_0_7_visit[4]  R1426     -1
    e2_S4_0_7_visit[4]  R1427     1
    e2_S4_0_7_visit[4]  R1444     -21
    e2_S4_0_7_visit[4]  R1445     -21
    e2_S4_0_7_visit[4]  R1446     -2
    e2_S4_0_7_visit[4]  R1447     -2
    e2_S4_0_7_visit[4]  R1449     -21
    e2_S4_0_7_visit[4]  R1450     -21
    e2_S4_0_7_visit[4]  R1451     -2
    e2_S4_0_7_visit[4]  R1452     -2
    e2_S4_0_7_visit[4]  R1454     -21
    e2_S4_0_7_visit[4]  R1455     -21
    e2_S4_0_7_visit[4]  R1456     -2
    e2_S4_0_7_visit[4]  R1457     -2
    e2_S4_0_7_visit[4]  R1459     -21
    e2_S4_0_7_visit[4]  R1460     -21
    e2_S4_0_7_visit[4]  R1461     -2
    e2_S4_0_7_visit[4]  R1462     -2
    e2_S4_0_7_visit[4]  R1464     -21
    e2_S4_0_7_visit[4]  R1465     -21
    e2_S4_0_7_visit[4]  R1466     -2
    e2_S4_0_7_visit[4]  R1467     -2
    e2_S4_0_7_visit[4]  R1469     -21
    e2_S4_0_7_visit[4]  R1470     -21
    e2_S4_0_7_visit[4]  R1471     -2
    e2_S4_0_7_visit[4]  R1472     -2
    e2_S4_0_7_visit[4]  R1474     -21
    e2_S4_0_7_visit[4]  R1475     -21
    e2_S4_0_7_visit[4]  R1476     -2
    e2_S4_0_7_visit[4]  R1477     -2
    e2_S4_0_7_visit[4]  R1479     -21
    e2_S4_0_7_visit[4]  R1480     -21
    e2_S4_0_7_visit[4]  R1481     -2
    e2_S4_0_7_visit[4]  R1482     -2
    e2_S4_0_7_visit[4]  R1484     -21
    e2_S4_0_7_visit[4]  R1485     -21
    e2_S4_0_7_visit[4]  R1486     -2
    e2_S4_0_7_visit[4]  R1487     -2
    e2_S4_0_7_visit[4]  R1489     -21
    e2_S4_0_7_visit[4]  R1490     -21
    e2_S4_0_7_visit[4]  R1491     -2
    e2_S4_0_7_visit[4]  R1492     -2
    e2_S4_0_7_visit[4]  R1512     -1
    e2_S4_0_7_visit[4]  R1514     21
    e2_S4_0_7_visit[4]  R1515     2
    e2_S4_0_7_visit[4]  R1526     1
    e2_S4_0_7_visit[4]  R3155     -8
    e2_S4_0_7_visit[4]  R3421     1
    e2_S4_0_7_visit[5]  R1411     4
    e2_S4_0_7_visit[5]  R1412     2
    e2_S4_0_7_visit[5]  R1428     -1
    e2_S4_0_7_visit[5]  R1429     -1
    e2_S4_0_7_visit[5]  R1430     1
    e2_S4_0_7_visit[5]  R1527     -25749
    e2_S4_0_7_visit[5]  R1528     71100
    e2_S4_0_7_visit[5]  R3158     -8
    e2_S4_0_7_visit[5]  R3422     1
    e2_S4_0_7_visit[6]  R1409     23
    e2_S4_0_7_visit[6]  R1410     2
    e2_S4_0_7_visit[6]  R1431     -1
    e2_S4_0_7_visit[6]  R1432     -1
    e2_S4_0_7_visit[6]  R1433     1
    e2_S4_0_7_visit[6]  R1444     -23
    e2_S4_0_7_visit[6]  R1445     -23
    e2_S4_0_7_visit[6]  R1446     -2
    e2_S4_0_7_visit[6]  R1447     -2
    e2_S4_0_7_visit[6]  R1449     -23
    e2_S4_0_7_visit[6]  R1450     -23
    e2_S4_0_7_visit[6]  R1451     -2
    e2_S4_0_7_visit[6]  R1452     -2
    e2_S4_0_7_visit[6]  R1454     -23
    e2_S4_0_7_visit[6]  R1455     -23
    e2_S4_0_7_visit[6]  R1456     -2
    e2_S4_0_7_visit[6]  R1457     -2
    e2_S4_0_7_visit[6]  R1459     -23
    e2_S4_0_7_visit[6]  R1460     -23
    e2_S4_0_7_visit[6]  R1461     -2
    e2_S4_0_7_visit[6]  R1462     -2
    e2_S4_0_7_visit[6]  R1464     -23
    e2_S4_0_7_visit[6]  R1465     -23
    e2_S4_0_7_visit[6]  R1466     -2
    e2_S4_0_7_visit[6]  R1467     -2
    e2_S4_0_7_visit[6]  R1469     -23
    e2_S4_0_7_visit[6]  R1470     -23
    e2_S4_0_7_visit[6]  R1471     -2
    e2_S4_0_7_visit[6]  R1472     -2
    e2_S4_0_7_visit[6]  R1474     -23
    e2_S4_0_7_visit[6]  R1475     -23
    e2_S4_0_7_visit[6]  R1476     -2
    e2_S4_0_7_visit[6]  R1477     -2
    e2_S4_0_7_visit[6]  R1479     -23
    e2_S4_0_7_visit[6]  R1480     -23
    e2_S4_0_7_visit[6]  R1481     -2
    e2_S4_0_7_visit[6]  R1482     -2
    e2_S4_0_7_visit[6]  R1484     -23
    e2_S4_0_7_visit[6]  R1485     -23
    e2_S4_0_7_visit[6]  R1486     -2
    e2_S4_0_7_visit[6]  R1487     -2
    e2_S4_0_7_visit[6]  R1489     -23
    e2_S4_0_7_visit[6]  R1490     -23
    e2_S4_0_7_visit[6]  R1491     -2
    e2_S4_0_7_visit[6]  R1492     -2
    e2_S4_0_7_visit[6]  R1512     -1
    e2_S4_0_7_visit[6]  R1514     23
    e2_S4_0_7_visit[6]  R1515     2
    e2_S4_0_7_visit[6]  R1529     1
    e2_S4_0_7_visit[6]  R3161     -8
    e2_S4_0_7_visit[6]  R3425     1
    e2_S4_0_7_visit[7]  R1411     4
    e2_S4_0_7_visit[7]  R1412     2
    e2_S4_0_7_visit[7]  R1434     -1
    e2_S4_0_7_visit[7]  R1435     -1
    e2_S4_0_7_visit[7]  R1436     1
    e2_S4_0_7_visit[7]  R1530     -23969
    e2_S4_0_7_visit[7]  R1531     71100
    e2_S4_0_7_visit[7]  R3164     -8
    e2_S4_0_7_visit[7]  R3426     1
    e2_S4_0_7_visit[8]  R1409     21
    e2_S4_0_7_visit[8]  R1410     2
    e2_S4_0_7_visit[8]  R1437     -1
    e2_S4_0_7_visit[8]  R1438     -1
    e2_S4_0_7_visit[8]  R1439     1
    e2_S4_0_7_visit[8]  R1444     -21
    e2_S4_0_7_visit[8]  R1445     -21
    e2_S4_0_7_visit[8]  R1446     -2
    e2_S4_0_7_visit[8]  R1447     -2
    e2_S4_0_7_visit[8]  R1449     -21
    e2_S4_0_7_visit[8]  R1450     -21
    e2_S4_0_7_visit[8]  R1451     -2
    e2_S4_0_7_visit[8]  R1452     -2
    e2_S4_0_7_visit[8]  R1454     -21
    e2_S4_0_7_visit[8]  R1455     -21
    e2_S4_0_7_visit[8]  R1456     -2
    e2_S4_0_7_visit[8]  R1457     -2
    e2_S4_0_7_visit[8]  R1459     -21
    e2_S4_0_7_visit[8]  R1460     -21
    e2_S4_0_7_visit[8]  R1461     -2
    e2_S4_0_7_visit[8]  R1462     -2
    e2_S4_0_7_visit[8]  R1464     -21
    e2_S4_0_7_visit[8]  R1465     -21
    e2_S4_0_7_visit[8]  R1466     -2
    e2_S4_0_7_visit[8]  R1467     -2
    e2_S4_0_7_visit[8]  R1469     -21
    e2_S4_0_7_visit[8]  R1470     -21
    e2_S4_0_7_visit[8]  R1471     -2
    e2_S4_0_7_visit[8]  R1472     -2
    e2_S4_0_7_visit[8]  R1474     -21
    e2_S4_0_7_visit[8]  R1475     -21
    e2_S4_0_7_visit[8]  R1476     -2
    e2_S4_0_7_visit[8]  R1477     -2
    e2_S4_0_7_visit[8]  R1479     -21
    e2_S4_0_7_visit[8]  R1480     -21
    e2_S4_0_7_visit[8]  R1481     -2
    e2_S4_0_7_visit[8]  R1482     -2
    e2_S4_0_7_visit[8]  R1484     -21
    e2_S4_0_7_visit[8]  R1485     -21
    e2_S4_0_7_visit[8]  R1486     -2
    e2_S4_0_7_visit[8]  R1487     -2
    e2_S4_0_7_visit[8]  R1489     -21
    e2_S4_0_7_visit[8]  R1490     -21
    e2_S4_0_7_visit[8]  R1491     -2
    e2_S4_0_7_visit[8]  R1492     -2
    e2_S4_0_7_visit[8]  R1516     -1
    e2_S4_0_7_visit[8]  R1518     21
    e2_S4_0_7_visit[8]  R1519     2
    e2_S4_0_7_visit[8]  R1532     1
    e2_S4_0_7_visit[8]  R3167     -8
    e2_S4_0_7_visit[8]  R3429     1
    e2_S4_0_7_visit[9]  R1411     4
    e2_S4_0_7_visit[9]  R1412     2
    e2_S4_0_7_visit[9]  R1440     -1
    e2_S4_0_7_visit[9]  R1441     -1
    e2_S4_0_7_visit[9]  R1442     1
    e2_S4_0_7_visit[9]  R1533     -11425
    e2_S4_0_7_visit[9]  R1534     71100
    e2_S4_0_7_visit[9]  R3170     -8
    e2_S4_0_7_visit[9]  R3430     1
    e2_S4_0_7_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_7_arc[-1,0]  R1407     1
    e2_S4_0_7_arc[-1,0]  R1413     1
    e2_S4_0_7_arc[-1,0]  R1443     -44319
    e2_S4_0_7_arc[-1,0]  R1444     -165
    e2_S4_0_7_arc[-1,0]  R1445     180
    e2_S4_0_7_arc[-1,0]  R1446     -5
    e2_S4_0_7_arc[-1,0]  R1447     6
    e2_S4_0_7_arc[-1,0]  R1535     -30
    e2_S4_0_7_arc[-1,0]  R3144     1
    e2_S4_0_7_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_7_arc[-1,1]  R1407     1
    e2_S4_0_7_arc[-1,1]  R1416     1
    e2_S4_0_7_arc[-1,1]  R1448     -41683
    e2_S4_0_7_arc[-1,1]  R1449     -180
    e2_S4_0_7_arc[-1,1]  R1450     178
    e2_S4_0_7_arc[-1,1]  R1451     -6
    e2_S4_0_7_arc[-1,1]  R1452     5
    e2_S4_0_7_arc[-1,1]  R1536     -30
    e2_S4_0_7_arc[-1,1]  R3147     1
    e2_S4_0_7_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_7_arc[-1,2]  R1407     1
    e2_S4_0_7_arc[-1,2]  R1419     1
    e2_S4_0_7_arc[-1,2]  R1453     -44289
    e2_S4_0_7_arc[-1,2]  R1454     -157
    e2_S4_0_7_arc[-1,2]  R1455     180
    e2_S4_0_7_arc[-1,2]  R1456     -4
    e2_S4_0_7_arc[-1,2]  R1457     6
    e2_S4_0_7_arc[-1,2]  R1537     -30
    e2_S4_0_7_arc[-1,2]  R3150     1
    e2_S4_0_7_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_7_arc[-1,3]  R1407     1
    e2_S4_0_7_arc[-1,3]  R1422     1
    e2_S4_0_7_arc[-1,3]  R1458     -40989
    e2_S4_0_7_arc[-1,3]  R1459     -180
    e2_S4_0_7_arc[-1,3]  R1460     176
    e2_S4_0_7_arc[-1,3]  R1461     -6
    e2_S4_0_7_arc[-1,3]  R1462     4
    e2_S4_0_7_arc[-1,3]  R1538     -30
    e2_S4_0_7_arc[-1,3]  R3153     1
    e2_S4_0_7_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_7_arc[-1,4]  R1407     1
    e2_S4_0_7_arc[-1,4]  R1425     1
    e2_S4_0_7_arc[-1,4]  R1463     -29919
    e2_S4_0_7_arc[-1,4]  R1464     -159
    e2_S4_0_7_arc[-1,4]  R1465     180
    e2_S4_0_7_arc[-1,4]  R1466     -4
    e2_S4_0_7_arc[-1,4]  R1467     6
    e2_S4_0_7_arc[-1,4]  R1539     -30
    e2_S4_0_7_arc[-1,4]  R3156     1
    e2_S4_0_7_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_7_arc[-1,5]  R1407     1
    e2_S4_0_7_arc[-1,5]  R1428     1
    e2_S4_0_7_arc[-1,5]  R1468     -26919
    e2_S4_0_7_arc[-1,5]  R1469     -180
    e2_S4_0_7_arc[-1,5]  R1470     176
    e2_S4_0_7_arc[-1,5]  R1471     -6
    e2_S4_0_7_arc[-1,5]  R1472     4
    e2_S4_0_7_arc[-1,5]  R1540     -30
    e2_S4_0_7_arc[-1,5]  R3159     1
    e2_S4_0_7_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_7_arc[-1,6]  R1407     1
    e2_S4_0_7_arc[-1,6]  R1431     1
    e2_S4_0_7_arc[-1,6]  R1473     -29851
    e2_S4_0_7_arc[-1,6]  R1474     -157
    e2_S4_0_7_arc[-1,6]  R1475     180
    e2_S4_0_7_arc[-1,6]  R1476     -4
    e2_S4_0_7_arc[-1,6]  R1477     6
    e2_S4_0_7_arc[-1,6]  R1541     -30
    e2_S4_0_7_arc[-1,6]  R3162     1
    e2_S4_0_7_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_7_arc[-1,7]  R1407     1
    e2_S4_0_7_arc[-1,7]  R1434     1
    e2_S4_0_7_arc[-1,7]  R1478     -25651
    e2_S4_0_7_arc[-1,7]  R1479     -180
    e2_S4_0_7_arc[-1,7]  R1480     176
    e2_S4_0_7_arc[-1,7]  R1481     -6
    e2_S4_0_7_arc[-1,7]  R1482     4
    e2_S4_0_7_arc[-1,7]  R1542     -30
    e2_S4_0_7_arc[-1,7]  R3165     1
    e2_S4_0_7_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_7_arc[-1,8]  R1407     1
    e2_S4_0_7_arc[-1,8]  R1437     1
    e2_S4_0_7_arc[-1,8]  R1483     -15519
    e2_S4_0_7_arc[-1,8]  R1484     -159
    e2_S4_0_7_arc[-1,8]  R1485     180
    e2_S4_0_7_arc[-1,8]  R1486     -4
    e2_S4_0_7_arc[-1,8]  R1487     6
    e2_S4_0_7_arc[-1,8]  R1543     -30
    e2_S4_0_7_arc[-1,8]  R3168     1
    e2_S4_0_7_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_7_arc[-1,9]  R1407     1
    e2_S4_0_7_arc[-1,9]  R1440     1
    e2_S4_0_7_arc[-1,9]  R1488     -13119
    e2_S4_0_7_arc[-1,9]  R1489     -180
    e2_S4_0_7_arc[-1,9]  R1490     176
    e2_S4_0_7_arc[-1,9]  R1491     -6
    e2_S4_0_7_arc[-1,9]  R1492     4
    e2_S4_0_7_arc[-1,9]  R1544     -30
    e2_S4_0_7_arc[-1,9]  R3171     1
    e2_S4_0_7_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_7_arc[0,-2]  R1408     1
    e2_S4_0_7_arc[0,-2]  R1414     1
    e2_S4_0_7_arc[0,-2]  R1493     -33523
    e2_S4_0_7_arc[0,-2]  R1545     -30
    e2_S4_0_7_arc[0,-2]  R3145     1
    e2_S4_0_7_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_7_arc[1,-2]  R1408     1
    e2_S4_0_7_arc[1,-2]  R1417     1
    e2_S4_0_7_arc[1,-2]  R1494     -39223
    e2_S4_0_7_arc[1,-2]  R1546     -30
    e2_S4_0_7_arc[1,-2]  R3148     1
    e2_S4_0_7_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_7_arc[2,-2]  R1408     1
    e2_S4_0_7_arc[2,-2]  R1420     1
    e2_S4_0_7_arc[2,-2]  R1495     -36369
    e2_S4_0_7_arc[2,-2]  R1547     -30
    e2_S4_0_7_arc[2,-2]  R3151     1
    e2_S4_0_7_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_7_arc[3,-2]  R1408     1
    e2_S4_0_7_arc[3,-2]  R1423     1
    e2_S4_0_7_arc[3,-2]  R1496     -42129
    e2_S4_0_7_arc[3,-2]  R1548     -30
    e2_S4_0_7_arc[3,-2]  R3154     1
    e2_S4_0_7_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_7_arc[4,-2]  R1408     1
    e2_S4_0_7_arc[4,-2]  R1426     1
    e2_S4_0_7_arc[4,-2]  R1497     -48315
    e2_S4_0_7_arc[4,-2]  R1549     -30
    e2_S4_0_7_arc[4,-2]  R3157     1
    e2_S4_0_7_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_7_arc[5,-2]  R1408     1
    e2_S4_0_7_arc[5,-2]  R1429     1
    e2_S4_0_7_arc[5,-2]  R1498     -53475
    e2_S4_0_7_arc[5,-2]  R1550     -30
    e2_S4_0_7_arc[5,-2]  R3160     1
    e2_S4_0_7_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_7_arc[6,-2]  R1408     1
    e2_S4_0_7_arc[6,-2]  R1432     1
    e2_S4_0_7_arc[6,-2]  R1499     -49531
    e2_S4_0_7_arc[6,-2]  R1551     -30
    e2_S4_0_7_arc[6,-2]  R3163     1
    e2_S4_0_7_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_7_arc[7,-2]  R1408     1
    e2_S4_0_7_arc[7,-2]  R1435     1
    e2_S4_0_7_arc[7,-2]  R1500     -56191
    e2_S4_0_7_arc[7,-2]  R1552     -30
    e2_S4_0_7_arc[7,-2]  R3166     1
    e2_S4_0_7_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_7_arc[8,-2]  R1408     1
    e2_S4_0_7_arc[8,-2]  R1438     1
    e2_S4_0_7_arc[8,-2]  R1501     -63217
    e2_S4_0_7_arc[8,-2]  R1553     -30
    e2_S4_0_7_arc[8,-2]  R3169     1
    e2_S4_0_7_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_7_arc[9,-2]  R1408     1
    e2_S4_0_7_arc[9,-2]  R1441     1
    e2_S4_0_7_arc[9,-2]  R1502     -68677
    e2_S4_0_7_arc[9,-2]  R1554     -30
    e2_S4_0_7_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C807      R1505     1
    C807      R1535     -1
    C807      R1536     -1
    C807      R1537     -1
    C807      R1538     -1
    C807      R1539     -1
    C807      R1540     -1
    C807      R1541     -1
    C807      R1542     -1
    C807      R1543     -1
    C807      R1544     -1
    C808      R1545     1
    C808      R1546     1
    C808      R1547     1
    C808      R1548     1
    C808      R1549     1
    C808      R1550     1
    C808      R1551     1
    C808      R1552     1
    C808      R1553     1
    C808      R1554     1
    C808      R1656     -1
    MARKER    'MARKER'                 'INTORG'
    C809      R1506     1
    C809      R1507     -60
    C809      R1508     1
    C809      R1509     -39660
    C809      R1510     -180
    C809      R1511     -6
    C809      R1520     -1
    C809      R1523     -1
    C810      R1506     1
    C810      R1507     -60
    C810      R1512     1
    C810      R1513     -54060
    C810      R1514     -180
    C810      R1515     -6
    C810      R1526     -1
    C810      R1529     -1
    C811      R1506     1
    C811      R1507     -60
    C811      R1516     1
    C811      R1517     -71160
    C811      R1518     -180
    C811      R1519     -6
    C811      R1532     -1
    e2_S4_0_8_used  R1555     -75600
    e2_S4_0_8_used  R1556     -75600
    e2_S4_0_8_used  R1557     -28800
    e2_S4_0_8_used  R1558     -1
    e2_S4_0_8_used  R1559     -1
    e2_S4_0_8_used  R1560     -180
    e2_S4_0_8_used  R1561     -6
    e2_S4_0_8_used  R1562     -180
    e2_S4_0_8_used  R1563     -6
    e2_S4_0_8_used  R1566     -1
    e2_S4_0_8_used  R1569     -1
    e2_S4_0_8_used  R1572     -1
    e2_S4_0_8_used  R1575     -1
    e2_S4_0_8_used  R1578     -1
    e2_S4_0_8_used  R1581     -1
    e2_S4_0_8_used  R1584     -1
    e2_S4_0_8_used  R1587     -1
    e2_S4_0_8_used  R1590     -1
    e2_S4_0_8_used  R1593     -1
    e2_S4_0_8_used  R1654     -75540
    e2_S4_0_8_used  R1655     1
    e2_S4_0_8_used  R1656     -30
    e2_S4_0_8_used  R1657     -1
    e2_S4_0_8_used  R1658     -75600
    e2_S4_0_8_used  R1806     -1
    e2_S4_0_8_used  R2610     -1
    e2_S4_0_8_start  R1555     1
    e2_S4_0_8_start  R1557     1
    e2_S4_0_8_start  R1594     -1
    e2_S4_0_8_start  R1599     -1
    e2_S4_0_8_start  R1604     -1
    e2_S4_0_8_start  R1609     -1
    e2_S4_0_8_start  R1614     -1
    e2_S4_0_8_start  R1619     -1
    e2_S4_0_8_start  R1624     -1
    e2_S4_0_8_start  R1629     -1
    e2_S4_0_8_start  R1634     -1
    e2_S4_0_8_start  R1639     -1
    e2_S4_0_8_start  R1658     1
    e2_S4_0_8_start  R1660     1
    e2_S4_0_8_start  R1664     1
    e2_S4_0_8_start  R1668     1
    e2_S4_0_8_end  R1556     1
    e2_S4_0_8_end  R1644     1
    e2_S4_0_8_end  R1645     1
    e2_S4_0_8_end  R1646     1
    e2_S4_0_8_end  R1647     1
    e2_S4_0_8_end  R1648     1
    e2_S4_0_8_end  R1649     1
    e2_S4_0_8_end  R1650     1
    e2_S4_0_8_end  R1651     1
    e2_S4_0_8_end  R1652     1
    e2_S4_0_8_end  R1653     1
    e2_S4_0_8_end  R1654     1
    e2_S4_0_8_end  R1672     -1
    e2_S4_0_8_end  R1673     -1
    e2_S4_0_8_end  R1675     -1
    e2_S4_0_8_end  R1676     -1
    e2_S4_0_8_end  R1678     -1
    e2_S4_0_8_end  R1679     -1
    e2_S4_0_8_end  R1681     -1
    e2_S4_0_8_end  R1682     -1
    e2_S4_0_8_end  R1684     -1
    e2_S4_0_8_end  R1685     -1
    e2_S4_0_8_end  R1809     -1
    e2_S4_0_8_visit[0]  R1560     15
    e2_S4_0_8_visit[0]  R1561     1
    e2_S4_0_8_visit[0]  R1564     -1
    e2_S4_0_8_visit[0]  R1565     -1
    e2_S4_0_8_visit[0]  R1566     1
    e2_S4_0_8_visit[0]  R1595     -15
    e2_S4_0_8_visit[0]  R1596     -15
    e2_S4_0_8_visit[0]  R1597     -1
    e2_S4_0_8_visit[0]  R1598     -1
    e2_S4_0_8_visit[0]  R1600     -15
    e2_S4_0_8_visit[0]  R1601     -15
    e2_S4_0_8_visit[0]  R1602     -1
    e2_S4_0_8_visit[0]  R1603     -1
    e2_S4_0_8_visit[0]  R1605     -15
    e2_S4_0_8_visit[0]  R1606     -15
    e2_S4_0_8_visit[0]  R1607     -1
    e2_S4_0_8_visit[0]  R1608     -1
    e2_S4_0_8_visit[0]  R1610     -15
    e2_S4_0_8_visit[0]  R1611     -15
    e2_S4_0_8_visit[0]  R1612     -1
    e2_S4_0_8_visit[0]  R1613     -1
    e2_S4_0_8_visit[0]  R1615     -15
    e2_S4_0_8_visit[0]  R1616     -15
    e2_S4_0_8_visit[0]  R1617     -1
    e2_S4_0_8_visit[0]  R1618     -1
    e2_S4_0_8_visit[0]  R1620     -15
    e2_S4_0_8_visit[0]  R1621     -15
    e2_S4_0_8_visit[0]  R1622     -1
    e2_S4_0_8_visit[0]  R1623     -1
    e2_S4_0_8_visit[0]  R1625     -15
    e2_S4_0_8_visit[0]  R1626     -15
    e2_S4_0_8_visit[0]  R1627     -1
    e2_S4_0_8_visit[0]  R1628     -1
    e2_S4_0_8_visit[0]  R1630     -15
    e2_S4_0_8_visit[0]  R1631     -15
    e2_S4_0_8_visit[0]  R1632     -1
    e2_S4_0_8_visit[0]  R1633     -1
    e2_S4_0_8_visit[0]  R1635     -15
    e2_S4_0_8_visit[0]  R1636     -15
    e2_S4_0_8_visit[0]  R1637     -1
    e2_S4_0_8_visit[0]  R1638     -1
    e2_S4_0_8_visit[0]  R1640     -15
    e2_S4_0_8_visit[0]  R1641     -15
    e2_S4_0_8_visit[0]  R1642     -1
    e2_S4_0_8_visit[0]  R1643     -1
    e2_S4_0_8_visit[0]  R1659     -1
    e2_S4_0_8_visit[0]  R1661     15
    e2_S4_0_8_visit[0]  R1662     1
    e2_S4_0_8_visit[0]  R1671     1
    e2_S4_0_8_visit[0]  R3143     -9
    e2_S4_0_8_visit[0]  R3413     1
    e2_S4_0_8_visit[1]  R1562     2
    e2_S4_0_8_visit[1]  R1563     1
    e2_S4_0_8_visit[1]  R1567     -1
    e2_S4_0_8_visit[1]  R1568     -1
    e2_S4_0_8_visit[1]  R1569     1
    e2_S4_0_8_visit[1]  R1672     -40937
    e2_S4_0_8_visit[1]  R1673     71100
    e2_S4_0_8_visit[1]  R3146     -9
    e2_S4_0_8_visit[1]  R3414     1
    e2_S4_0_8_visit[2]  R1560     23
    e2_S4_0_8_visit[2]  R1561     2
    e2_S4_0_8_visit[2]  R1570     -1
    e2_S4_0_8_visit[2]  R1571     -1
    e2_S4_0_8_visit[2]  R1572     1
    e2_S4_0_8_visit[2]  R1595     -23
    e2_S4_0_8_visit[2]  R1596     -23
    e2_S4_0_8_visit[2]  R1597     -2
    e2_S4_0_8_visit[2]  R1598     -2
    e2_S4_0_8_visit[2]  R1600     -23
    e2_S4_0_8_visit[2]  R1601     -23
    e2_S4_0_8_visit[2]  R1602     -2
    e2_S4_0_8_visit[2]  R1603     -2
    e2_S4_0_8_visit[2]  R1605     -23
    e2_S4_0_8_visit[2]  R1606     -23
    e2_S4_0_8_visit[2]  R1607     -2
    e2_S4_0_8_visit[2]  R1608     -2
    e2_S4_0_8_visit[2]  R1610     -23
    e2_S4_0_8_visit[2]  R1611     -23
    e2_S4_0_8_visit[2]  R1612     -2
    e2_S4_0_8_visit[2]  R1613     -2
    e2_S4_0_8_visit[2]  R1615     -23
    e2_S4_0_8_visit[2]  R1616     -23
    e2_S4_0_8_visit[2]  R1617     -2
    e2_S4_0_8_visit[2]  R1618     -2
    e2_S4_0_8_visit[2]  R1620     -23
    e2_S4_0_8_visit[2]  R1621     -23
    e2_S4_0_8_visit[2]  R1622     -2
    e2_S4_0_8_visit[2]  R1623     -2
    e2_S4_0_8_visit[2]  R1625     -23
    e2_S4_0_8_visit[2]  R1626     -23
    e2_S4_0_8_visit[2]  R1627     -2
    e2_S4_0_8_visit[2]  R1628     -2
    e2_S4_0_8_visit[2]  R1630     -23
    e2_S4_0_8_visit[2]  R1631     -23
    e2_S4_0_8_visit[2]  R1632     -2
    e2_S4_0_8_visit[2]  R1633     -2
    e2_S4_0_8_visit[2]  R1635     -23
    e2_S4_0_8_visit[2]  R1636     -23
    e2_S4_0_8_visit[2]  R1637     -2
    e2_S4_0_8_visit[2]  R1638     -2
    e2_S4_0_8_visit[2]  R1640     -23
    e2_S4_0_8_visit[2]  R1641     -23
    e2_S4_0_8_visit[2]  R1642     -2
    e2_S4_0_8_visit[2]  R1643     -2
    e2_S4_0_8_visit[2]  R1659     -1
    e2_S4_0_8_visit[2]  R1661     23
    e2_S4_0_8_visit[2]  R1662     2
    e2_S4_0_8_visit[2]  R1674     1
    e2_S4_0_8_visit[2]  R3149     -9
    e2_S4_0_8_visit[2]  R3417     1
    e2_S4_0_8_visit[3]  R1562     4
    e2_S4_0_8_visit[3]  R1563     2
    e2_S4_0_8_visit[3]  R1573     -1
    e2_S4_0_8_visit[3]  R1574     -1
    e2_S4_0_8_visit[3]  R1575     1
    e2_S4_0_8_visit[3]  R1675     -38031
    e2_S4_0_8_visit[3]  R1676     71100
    e2_S4_0_8_visit[3]  R3152     -9
    e2_S4_0_8_visit[3]  R3418     1
    e2_S4_0_8_visit[4]  R1560     21
    e2_S4_0_8_visit[4]  R1561     2
    e2_S4_0_8_visit[4]  R1576     -1
    e2_S4_0_8_visit[4]  R1577     -1
    e2_S4_0_8_visit[4]  R1578     1
    e2_S4_0_8_visit[4]  R1595     -21
    e2_S4_0_8_visit[4]  R1596     -21
    e2_S4_0_8_visit[4]  R1597     -2
    e2_S4_0_8_visit[4]  R1598     -2
    e2_S4_0_8_visit[4]  R1600     -21
    e2_S4_0_8_visit[4]  R1601     -21
    e2_S4_0_8_visit[4]  R1602     -2
    e2_S4_0_8_visit[4]  R1603     -2
    e2_S4_0_8_visit[4]  R1605     -21
    e2_S4_0_8_visit[4]  R1606     -21
    e2_S4_0_8_visit[4]  R1607     -2
    e2_S4_0_8_visit[4]  R1608     -2
    e2_S4_0_8_visit[4]  R1610     -21
    e2_S4_0_8_visit[4]  R1611     -21
    e2_S4_0_8_visit[4]  R1612     -2
    e2_S4_0_8_visit[4]  R1613     -2
    e2_S4_0_8_visit[4]  R1615     -21
    e2_S4_0_8_visit[4]  R1616     -21
    e2_S4_0_8_visit[4]  R1617     -2
    e2_S4_0_8_visit[4]  R1618     -2
    e2_S4_0_8_visit[4]  R1620     -21
    e2_S4_0_8_visit[4]  R1621     -21
    e2_S4_0_8_visit[4]  R1622     -2
    e2_S4_0_8_visit[4]  R1623     -2
    e2_S4_0_8_visit[4]  R1625     -21
    e2_S4_0_8_visit[4]  R1626     -21
    e2_S4_0_8_visit[4]  R1627     -2
    e2_S4_0_8_visit[4]  R1628     -2
    e2_S4_0_8_visit[4]  R1630     -21
    e2_S4_0_8_visit[4]  R1631     -21
    e2_S4_0_8_visit[4]  R1632     -2
    e2_S4_0_8_visit[4]  R1633     -2
    e2_S4_0_8_visit[4]  R1635     -21
    e2_S4_0_8_visit[4]  R1636     -21
    e2_S4_0_8_visit[4]  R1637     -2
    e2_S4_0_8_visit[4]  R1638     -2
    e2_S4_0_8_visit[4]  R1640     -21
    e2_S4_0_8_visit[4]  R1641     -21
    e2_S4_0_8_visit[4]  R1642     -2
    e2_S4_0_8_visit[4]  R1643     -2
    e2_S4_0_8_visit[4]  R1663     -1
    e2_S4_0_8_visit[4]  R1665     21
    e2_S4_0_8_visit[4]  R1666     2
    e2_S4_0_8_visit[4]  R1677     1
    e2_S4_0_8_visit[4]  R3155     -9
    e2_S4_0_8_visit[4]  R3421     1
    e2_S4_0_8_visit[5]  R1562     4
    e2_S4_0_8_visit[5]  R1563     2
    e2_S4_0_8_visit[5]  R1579     -1
    e2_S4_0_8_visit[5]  R1580     -1
    e2_S4_0_8_visit[5]  R1581     1
    e2_S4_0_8_visit[5]  R1678     -25749
    e2_S4_0_8_visit[5]  R1679     71100
    e2_S4_0_8_visit[5]  R3158     -9
    e2_S4_0_8_visit[5]  R3422     1
    e2_S4_0_8_visit[6]  R1560     23
    e2_S4_0_8_visit[6]  R1561     2
    e2_S4_0_8_visit[6]  R1582     -1
    e2_S4_0_8_visit[6]  R1583     -1
    e2_S4_0_8_visit[6]  R1584     1
    e2_S4_0_8_visit[6]  R1595     -23
    e2_S4_0_8_visit[6]  R1596     -23
    e2_S4_0_8_visit[6]  R1597     -2
    e2_S4_0_8_visit[6]  R1598     -2
    e2_S4_0_8_visit[6]  R1600     -23
    e2_S4_0_8_visit[6]  R1601     -23
    e2_S4_0_8_visit[6]  R1602     -2
    e2_S4_0_8_visit[6]  R1603     -2
    e2_S4_0_8_visit[6]  R1605     -23
    e2_S4_0_8_visit[6]  R1606     -23
    e2_S4_0_8_visit[6]  R1607     -2
    e2_S4_0_8_visit[6]  R1608     -2
    e2_S4_0_8_visit[6]  R1610     -23
    e2_S4_0_8_visit[6]  R1611     -23
    e2_S4_0_8_visit[6]  R1612     -2
    e2_S4_0_8_visit[6]  R1613     -2
    e2_S4_0_8_visit[6]  R1615     -23
    e2_S4_0_8_visit[6]  R1616     -23
    e2_S4_0_8_visit[6]  R1617     -2
    e2_S4_0_8_visit[6]  R1618     -2
    e2_S4_0_8_visit[6]  R1620     -23
    e2_S4_0_8_visit[6]  R1621     -23
    e2_S4_0_8_visit[6]  R1622     -2
    e2_S4_0_8_visit[6]  R1623     -2
    e2_S4_0_8_visit[6]  R1625     -23
    e2_S4_0_8_visit[6]  R1626     -23
    e2_S4_0_8_visit[6]  R1627     -2
    e2_S4_0_8_visit[6]  R1628     -2
    e2_S4_0_8_visit[6]  R1630     -23
    e2_S4_0_8_visit[6]  R1631     -23
    e2_S4_0_8_visit[6]  R1632     -2
    e2_S4_0_8_visit[6]  R1633     -2
    e2_S4_0_8_visit[6]  R1635     -23
    e2_S4_0_8_visit[6]  R1636     -23
    e2_S4_0_8_visit[6]  R1637     -2
    e2_S4_0_8_visit[6]  R1638     -2
    e2_S4_0_8_visit[6]  R1640     -23
    e2_S4_0_8_visit[6]  R1641     -23
    e2_S4_0_8_visit[6]  R1642     -2
    e2_S4_0_8_visit[6]  R1643     -2
    e2_S4_0_8_visit[6]  R1663     -1
    e2_S4_0_8_visit[6]  R1665     23
    e2_S4_0_8_visit[6]  R1666     2
    e2_S4_0_8_visit[6]  R1680     1
    e2_S4_0_8_visit[6]  R3161     -9
    e2_S4_0_8_visit[6]  R3425     1
    e2_S4_0_8_visit[7]  R1562     4
    e2_S4_0_8_visit[7]  R1563     2
    e2_S4_0_8_visit[7]  R1585     -1
    e2_S4_0_8_visit[7]  R1586     -1
    e2_S4_0_8_visit[7]  R1587     1
    e2_S4_0_8_visit[7]  R1681     -23969
    e2_S4_0_8_visit[7]  R1682     71100
    e2_S4_0_8_visit[7]  R3164     -9
    e2_S4_0_8_visit[7]  R3426     1
    e2_S4_0_8_visit[8]  R1560     21
    e2_S4_0_8_visit[8]  R1561     2
    e2_S4_0_8_visit[8]  R1588     -1
    e2_S4_0_8_visit[8]  R1589     -1
    e2_S4_0_8_visit[8]  R1590     1
    e2_S4_0_8_visit[8]  R1595     -21
    e2_S4_0_8_visit[8]  R1596     -21
    e2_S4_0_8_visit[8]  R1597     -2
    e2_S4_0_8_visit[8]  R1598     -2
    e2_S4_0_8_visit[8]  R1600     -21
    e2_S4_0_8_visit[8]  R1601     -21
    e2_S4_0_8_visit[8]  R1602     -2
    e2_S4_0_8_visit[8]  R1603     -2
    e2_S4_0_8_visit[8]  R1605     -21
    e2_S4_0_8_visit[8]  R1606     -21
    e2_S4_0_8_visit[8]  R1607     -2
    e2_S4_0_8_visit[8]  R1608     -2
    e2_S4_0_8_visit[8]  R1610     -21
    e2_S4_0_8_visit[8]  R1611     -21
    e2_S4_0_8_visit[8]  R1612     -2
    e2_S4_0_8_visit[8]  R1613     -2
    e2_S4_0_8_visit[8]  R1615     -21
    e2_S4_0_8_visit[8]  R1616     -21
    e2_S4_0_8_visit[8]  R1617     -2
    e2_S4_0_8_visit[8]  R1618     -2
    e2_S4_0_8_visit[8]  R1620     -21
    e2_S4_0_8_visit[8]  R1621     -21
    e2_S4_0_8_visit[8]  R1622     -2
    e2_S4_0_8_visit[8]  R1623     -2
    e2_S4_0_8_visit[8]  R1625     -21
    e2_S4_0_8_visit[8]  R1626     -21
    e2_S4_0_8_visit[8]  R1627     -2
    e2_S4_0_8_visit[8]  R1628     -2
    e2_S4_0_8_visit[8]  R1630     -21
    e2_S4_0_8_visit[8]  R1631     -21
    e2_S4_0_8_visit[8]  R1632     -2
    e2_S4_0_8_visit[8]  R1633     -2
    e2_S4_0_8_visit[8]  R1635     -21
    e2_S4_0_8_visit[8]  R1636     -21
    e2_S4_0_8_visit[8]  R1637     -2
    e2_S4_0_8_visit[8]  R1638     -2
    e2_S4_0_8_visit[8]  R1640     -21
    e2_S4_0_8_visit[8]  R1641     -21
    e2_S4_0_8_visit[8]  R1642     -2
    e2_S4_0_8_visit[8]  R1643     -2
    e2_S4_0_8_visit[8]  R1667     -1
    e2_S4_0_8_visit[8]  R1669     21
    e2_S4_0_8_visit[8]  R1670     2
    e2_S4_0_8_visit[8]  R1683     1
    e2_S4_0_8_visit[8]  R3167     -9
    e2_S4_0_8_visit[8]  R3429     1
    e2_S4_0_8_visit[9]  R1562     4
    e2_S4_0_8_visit[9]  R1563     2
    e2_S4_0_8_visit[9]  R1591     -1
    e2_S4_0_8_visit[9]  R1592     -1
    e2_S4_0_8_visit[9]  R1593     1
    e2_S4_0_8_visit[9]  R1684     -11425
    e2_S4_0_8_visit[9]  R1685     71100
    e2_S4_0_8_visit[9]  R3170     -9
    e2_S4_0_8_visit[9]  R3430     1
    e2_S4_0_8_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_8_arc[-1,0]  R1558     1
    e2_S4_0_8_arc[-1,0]  R1564     1
    e2_S4_0_8_arc[-1,0]  R1594     -44319
    e2_S4_0_8_arc[-1,0]  R1595     -165
    e2_S4_0_8_arc[-1,0]  R1596     180
    e2_S4_0_8_arc[-1,0]  R1597     -5
    e2_S4_0_8_arc[-1,0]  R1598     6
    e2_S4_0_8_arc[-1,0]  R1686     -30
    e2_S4_0_8_arc[-1,0]  R3144     1
    e2_S4_0_8_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_8_arc[-1,1]  R1558     1
    e2_S4_0_8_arc[-1,1]  R1567     1
    e2_S4_0_8_arc[-1,1]  R1599     -41683
    e2_S4_0_8_arc[-1,1]  R1600     -180
    e2_S4_0_8_arc[-1,1]  R1601     178
    e2_S4_0_8_arc[-1,1]  R1602     -6
    e2_S4_0_8_arc[-1,1]  R1603     5
    e2_S4_0_8_arc[-1,1]  R1687     -30
    e2_S4_0_8_arc[-1,1]  R3147     1
    e2_S4_0_8_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_8_arc[-1,2]  R1558     1
    e2_S4_0_8_arc[-1,2]  R1570     1
    e2_S4_0_8_arc[-1,2]  R1604     -44289
    e2_S4_0_8_arc[-1,2]  R1605     -157
    e2_S4_0_8_arc[-1,2]  R1606     180
    e2_S4_0_8_arc[-1,2]  R1607     -4
    e2_S4_0_8_arc[-1,2]  R1608     6
    e2_S4_0_8_arc[-1,2]  R1688     -30
    e2_S4_0_8_arc[-1,2]  R3150     1
    e2_S4_0_8_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_8_arc[-1,3]  R1558     1
    e2_S4_0_8_arc[-1,3]  R1573     1
    e2_S4_0_8_arc[-1,3]  R1609     -40989
    e2_S4_0_8_arc[-1,3]  R1610     -180
    e2_S4_0_8_arc[-1,3]  R1611     176
    e2_S4_0_8_arc[-1,3]  R1612     -6
    e2_S4_0_8_arc[-1,3]  R1613     4
    e2_S4_0_8_arc[-1,3]  R1689     -30
    e2_S4_0_8_arc[-1,3]  R3153     1
    e2_S4_0_8_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_8_arc[-1,4]  R1558     1
    e2_S4_0_8_arc[-1,4]  R1576     1
    e2_S4_0_8_arc[-1,4]  R1614     -29919
    e2_S4_0_8_arc[-1,4]  R1615     -159
    e2_S4_0_8_arc[-1,4]  R1616     180
    e2_S4_0_8_arc[-1,4]  R1617     -4
    e2_S4_0_8_arc[-1,4]  R1618     6
    e2_S4_0_8_arc[-1,4]  R1690     -30
    e2_S4_0_8_arc[-1,4]  R3156     1
    e2_S4_0_8_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_8_arc[-1,5]  R1558     1
    e2_S4_0_8_arc[-1,5]  R1579     1
    e2_S4_0_8_arc[-1,5]  R1619     -26919
    e2_S4_0_8_arc[-1,5]  R1620     -180
    e2_S4_0_8_arc[-1,5]  R1621     176
    e2_S4_0_8_arc[-1,5]  R1622     -6
    e2_S4_0_8_arc[-1,5]  R1623     4
    e2_S4_0_8_arc[-1,5]  R1691     -30
    e2_S4_0_8_arc[-1,5]  R3159     1
    e2_S4_0_8_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_8_arc[-1,6]  R1558     1
    e2_S4_0_8_arc[-1,6]  R1582     1
    e2_S4_0_8_arc[-1,6]  R1624     -29851
    e2_S4_0_8_arc[-1,6]  R1625     -157
    e2_S4_0_8_arc[-1,6]  R1626     180
    e2_S4_0_8_arc[-1,6]  R1627     -4
    e2_S4_0_8_arc[-1,6]  R1628     6
    e2_S4_0_8_arc[-1,6]  R1692     -30
    e2_S4_0_8_arc[-1,6]  R3162     1
    e2_S4_0_8_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_8_arc[-1,7]  R1558     1
    e2_S4_0_8_arc[-1,7]  R1585     1
    e2_S4_0_8_arc[-1,7]  R1629     -25651
    e2_S4_0_8_arc[-1,7]  R1630     -180
    e2_S4_0_8_arc[-1,7]  R1631     176
    e2_S4_0_8_arc[-1,7]  R1632     -6
    e2_S4_0_8_arc[-1,7]  R1633     4
    e2_S4_0_8_arc[-1,7]  R1693     -30
    e2_S4_0_8_arc[-1,7]  R3165     1
    e2_S4_0_8_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_8_arc[-1,8]  R1558     1
    e2_S4_0_8_arc[-1,8]  R1588     1
    e2_S4_0_8_arc[-1,8]  R1634     -15519
    e2_S4_0_8_arc[-1,8]  R1635     -159
    e2_S4_0_8_arc[-1,8]  R1636     180
    e2_S4_0_8_arc[-1,8]  R1637     -4
    e2_S4_0_8_arc[-1,8]  R1638     6
    e2_S4_0_8_arc[-1,8]  R1694     -30
    e2_S4_0_8_arc[-1,8]  R3168     1
    e2_S4_0_8_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_8_arc[-1,9]  R1558     1
    e2_S4_0_8_arc[-1,9]  R1591     1
    e2_S4_0_8_arc[-1,9]  R1639     -13119
    e2_S4_0_8_arc[-1,9]  R1640     -180
    e2_S4_0_8_arc[-1,9]  R1641     176
    e2_S4_0_8_arc[-1,9]  R1642     -6
    e2_S4_0_8_arc[-1,9]  R1643     4
    e2_S4_0_8_arc[-1,9]  R1695     -30
    e2_S4_0_8_arc[-1,9]  R3171     1
    e2_S4_0_8_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_8_arc[0,-2]  R1559     1
    e2_S4_0_8_arc[0,-2]  R1565     1
    e2_S4_0_8_arc[0,-2]  R1644     -33523
    e2_S4_0_8_arc[0,-2]  R1696     -30
    e2_S4_0_8_arc[0,-2]  R3145     1
    e2_S4_0_8_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_8_arc[1,-2]  R1559     1
    e2_S4_0_8_arc[1,-2]  R1568     1
    e2_S4_0_8_arc[1,-2]  R1645     -39223
    e2_S4_0_8_arc[1,-2]  R1697     -30
    e2_S4_0_8_arc[1,-2]  R3148     1
    e2_S4_0_8_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_8_arc[2,-2]  R1559     1
    e2_S4_0_8_arc[2,-2]  R1571     1
    e2_S4_0_8_arc[2,-2]  R1646     -36369
    e2_S4_0_8_arc[2,-2]  R1698     -30
    e2_S4_0_8_arc[2,-2]  R3151     1
    e2_S4_0_8_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_8_arc[3,-2]  R1559     1
    e2_S4_0_8_arc[3,-2]  R1574     1
    e2_S4_0_8_arc[3,-2]  R1647     -42129
    e2_S4_0_8_arc[3,-2]  R1699     -30
    e2_S4_0_8_arc[3,-2]  R3154     1
    e2_S4_0_8_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_8_arc[4,-2]  R1559     1
    e2_S4_0_8_arc[4,-2]  R1577     1
    e2_S4_0_8_arc[4,-2]  R1648     -48315
    e2_S4_0_8_arc[4,-2]  R1700     -30
    e2_S4_0_8_arc[4,-2]  R3157     1
    e2_S4_0_8_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_8_arc[5,-2]  R1559     1
    e2_S4_0_8_arc[5,-2]  R1580     1
    e2_S4_0_8_arc[5,-2]  R1649     -53475
    e2_S4_0_8_arc[5,-2]  R1701     -30
    e2_S4_0_8_arc[5,-2]  R3160     1
    e2_S4_0_8_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_8_arc[6,-2]  R1559     1
    e2_S4_0_8_arc[6,-2]  R1583     1
    e2_S4_0_8_arc[6,-2]  R1650     -49531
    e2_S4_0_8_arc[6,-2]  R1702     -30
    e2_S4_0_8_arc[6,-2]  R3163     1
    e2_S4_0_8_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_8_arc[7,-2]  R1559     1
    e2_S4_0_8_arc[7,-2]  R1586     1
    e2_S4_0_8_arc[7,-2]  R1651     -56191
    e2_S4_0_8_arc[7,-2]  R1703     -30
    e2_S4_0_8_arc[7,-2]  R3166     1
    e2_S4_0_8_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_8_arc[8,-2]  R1559     1
    e2_S4_0_8_arc[8,-2]  R1589     1
    e2_S4_0_8_arc[8,-2]  R1652     -63217
    e2_S4_0_8_arc[8,-2]  R1704     -30
    e2_S4_0_8_arc[8,-2]  R3169     1
    e2_S4_0_8_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_8_arc[9,-2]  R1559     1
    e2_S4_0_8_arc[9,-2]  R1592     1
    e2_S4_0_8_arc[9,-2]  R1653     -68677
    e2_S4_0_8_arc[9,-2]  R1705     -30
    e2_S4_0_8_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C845      R1656     1
    C845      R1686     -1
    C845      R1687     -1
    C845      R1688     -1
    C845      R1689     -1
    C845      R1690     -1
    C845      R1691     -1
    C845      R1692     -1
    C845      R1693     -1
    C845      R1694     -1
    C845      R1695     -1
    C846      R1696     1
    C846      R1697     1
    C846      R1698     1
    C846      R1699     1
    C846      R1700     1
    C846      R1701     1
    C846      R1702     1
    C846      R1703     1
    C846      R1704     1
    C846      R1705     1
    C846      R1807     -1
    MARKER    'MARKER'                 'INTORG'
    C847      R1657     1
    C847      R1658     -60
    C847      R1659     1
    C847      R1660     -39660
    C847      R1661     -180
    C847      R1662     -6
    C847      R1671     -1
    C847      R1674     -1
    C848      R1657     1
    C848      R1658     -60
    C848      R1663     1
    C848      R1664     -54060
    C848      R1665     -180
    C848      R1666     -6
    C848      R1677     -1
    C848      R1680     -1
    C849      R1657     1
    C849      R1658     -60
    C849      R1667     1
    C849      R1668     -71160
    C849      R1669     -180
    C849      R1670     -6
    C849      R1683     -1
    e2_S4_0_9_used  R1706     -75600
    e2_S4_0_9_used  R1707     -75600
    e2_S4_0_9_used  R1708     -28800
    e2_S4_0_9_used  R1709     -1
    e2_S4_0_9_used  R1710     -1
    e2_S4_0_9_used  R1711     -180
    e2_S4_0_9_used  R1712     -6
    e2_S4_0_9_used  R1713     -180
    e2_S4_0_9_used  R1714     -6
    e2_S4_0_9_used  R1717     -1
    e2_S4_0_9_used  R1720     -1
    e2_S4_0_9_used  R1723     -1
    e2_S4_0_9_used  R1726     -1
    e2_S4_0_9_used  R1729     -1
    e2_S4_0_9_used  R1732     -1
    e2_S4_0_9_used  R1735     -1
    e2_S4_0_9_used  R1738     -1
    e2_S4_0_9_used  R1741     -1
    e2_S4_0_9_used  R1744     -1
    e2_S4_0_9_used  R1805     -75540
    e2_S4_0_9_used  R1806     1
    e2_S4_0_9_used  R1807     -30
    e2_S4_0_9_used  R1808     -1
    e2_S4_0_9_used  R1809     -75600
    e2_S4_0_9_used  R2610     -1
    e2_S4_0_9_start  R1706     1
    e2_S4_0_9_start  R1708     1
    e2_S4_0_9_start  R1745     -1
    e2_S4_0_9_start  R1750     -1
    e2_S4_0_9_start  R1755     -1
    e2_S4_0_9_start  R1760     -1
    e2_S4_0_9_start  R1765     -1
    e2_S4_0_9_start  R1770     -1
    e2_S4_0_9_start  R1775     -1
    e2_S4_0_9_start  R1780     -1
    e2_S4_0_9_start  R1785     -1
    e2_S4_0_9_start  R1790     -1
    e2_S4_0_9_start  R1809     1
    e2_S4_0_9_start  R1811     1
    e2_S4_0_9_start  R1815     1
    e2_S4_0_9_start  R1819     1
    e2_S4_0_9_end  R1707     1
    e2_S4_0_9_end  R1795     1
    e2_S4_0_9_end  R1796     1
    e2_S4_0_9_end  R1797     1
    e2_S4_0_9_end  R1798     1
    e2_S4_0_9_end  R1799     1
    e2_S4_0_9_end  R1800     1
    e2_S4_0_9_end  R1801     1
    e2_S4_0_9_end  R1802     1
    e2_S4_0_9_end  R1803     1
    e2_S4_0_9_end  R1804     1
    e2_S4_0_9_end  R1805     1
    e2_S4_0_9_end  R1823     -1
    e2_S4_0_9_end  R1824     -1
    e2_S4_0_9_end  R1826     -1
    e2_S4_0_9_end  R1827     -1
    e2_S4_0_9_end  R1829     -1
    e2_S4_0_9_end  R1830     -1
    e2_S4_0_9_end  R1832     -1
    e2_S4_0_9_end  R1833     -1
    e2_S4_0_9_end  R1835     -1
    e2_S4_0_9_end  R1836     -1
    e2_S4_0_9_visit[0]  R1711     15
    e2_S4_0_9_visit[0]  R1712     1
    e2_S4_0_9_visit[0]  R1715     -1
    e2_S4_0_9_visit[0]  R1716     -1
    e2_S4_0_9_visit[0]  R1717     1
    e2_S4_0_9_visit[0]  R1746     -15
    e2_S4_0_9_visit[0]  R1747     -15
    e2_S4_0_9_visit[0]  R1748     -1
    e2_S4_0_9_visit[0]  R1749     -1
    e2_S4_0_9_visit[0]  R1751     -15
    e2_S4_0_9_visit[0]  R1752     -15
    e2_S4_0_9_visit[0]  R1753     -1
    e2_S4_0_9_visit[0]  R1754     -1
    e2_S4_0_9_visit[0]  R1756     -15
    e2_S4_0_9_visit[0]  R1757     -15
    e2_S4_0_9_visit[0]  R1758     -1
    e2_S4_0_9_visit[0]  R1759     -1
    e2_S4_0_9_visit[0]  R1761     -15
    e2_S4_0_9_visit[0]  R1762     -15
    e2_S4_0_9_visit[0]  R1763     -1
    e2_S4_0_9_visit[0]  R1764     -1
    e2_S4_0_9_visit[0]  R1766     -15
    e2_S4_0_9_visit[0]  R1767     -15
    e2_S4_0_9_visit[0]  R1768     -1
    e2_S4_0_9_visit[0]  R1769     -1
    e2_S4_0_9_visit[0]  R1771     -15
    e2_S4_0_9_visit[0]  R1772     -15
    e2_S4_0_9_visit[0]  R1773     -1
    e2_S4_0_9_visit[0]  R1774     -1
    e2_S4_0_9_visit[0]  R1776     -15
    e2_S4_0_9_visit[0]  R1777     -15
    e2_S4_0_9_visit[0]  R1778     -1
    e2_S4_0_9_visit[0]  R1779     -1
    e2_S4_0_9_visit[0]  R1781     -15
    e2_S4_0_9_visit[0]  R1782     -15
    e2_S4_0_9_visit[0]  R1783     -1
    e2_S4_0_9_visit[0]  R1784     -1
    e2_S4_0_9_visit[0]  R1786     -15
    e2_S4_0_9_visit[0]  R1787     -15
    e2_S4_0_9_visit[0]  R1788     -1
    e2_S4_0_9_visit[0]  R1789     -1
    e2_S4_0_9_visit[0]  R1791     -15
    e2_S4_0_9_visit[0]  R1792     -15
    e2_S4_0_9_visit[0]  R1793     -1
    e2_S4_0_9_visit[0]  R1794     -1
    e2_S4_0_9_visit[0]  R1810     -1
    e2_S4_0_9_visit[0]  R1812     15
    e2_S4_0_9_visit[0]  R1813     1
    e2_S4_0_9_visit[0]  R1822     1
    e2_S4_0_9_visit[0]  R3143     -10
    e2_S4_0_9_visit[0]  R3413     1
    e2_S4_0_9_visit[1]  R1713     2
    e2_S4_0_9_visit[1]  R1714     1
    e2_S4_0_9_visit[1]  R1718     -1
    e2_S4_0_9_visit[1]  R1719     -1
    e2_S4_0_9_visit[1]  R1720     1
    e2_S4_0_9_visit[1]  R1823     -40937
    e2_S4_0_9_visit[1]  R1824     71100
    e2_S4_0_9_visit[1]  R3146     -10
    e2_S4_0_9_visit[1]  R3414     1
    e2_S4_0_9_visit[2]  R1711     23
    e2_S4_0_9_visit[2]  R1712     2
    e2_S4_0_9_visit[2]  R1721     -1
    e2_S4_0_9_visit[2]  R1722     -1
    e2_S4_0_9_visit[2]  R1723     1
    e2_S4_0_9_visit[2]  R1746     -23
    e2_S4_0_9_visit[2]  R1747     -23
    e2_S4_0_9_visit[2]  R1748     -2
    e2_S4_0_9_visit[2]  R1749     -2
    e2_S4_0_9_visit[2]  R1751     -23
    e2_S4_0_9_visit[2]  R1752     -23
    e2_S4_0_9_visit[2]  R1753     -2
    e2_S4_0_9_visit[2]  R1754     -2
    e2_S4_0_9_visit[2]  R1756     -23
    e2_S4_0_9_visit[2]  R1757     -23
    e2_S4_0_9_visit[2]  R1758     -2
    e2_S4_0_9_visit[2]  R1759     -2
    e2_S4_0_9_visit[2]  R1761     -23
    e2_S4_0_9_visit[2]  R1762     -23
    e2_S4_0_9_visit[2]  R1763     -2
    e2_S4_0_9_visit[2]  R1764     -2
    e2_S4_0_9_visit[2]  R1766     -23
    e2_S4_0_9_visit[2]  R1767     -23
    e2_S4_0_9_visit[2]  R1768     -2
    e2_S4_0_9_visit[2]  R1769     -2
    e2_S4_0_9_visit[2]  R1771     -23
    e2_S4_0_9_visit[2]  R1772     -23
    e2_S4_0_9_visit[2]  R1773     -2
    e2_S4_0_9_visit[2]  R1774     -2
    e2_S4_0_9_visit[2]  R1776     -23
    e2_S4_0_9_visit[2]  R1777     -23
    e2_S4_0_9_visit[2]  R1778     -2
    e2_S4_0_9_visit[2]  R1779     -2
    e2_S4_0_9_visit[2]  R1781     -23
    e2_S4_0_9_visit[2]  R1782     -23
    e2_S4_0_9_visit[2]  R1783     -2
    e2_S4_0_9_visit[2]  R1784     -2
    e2_S4_0_9_visit[2]  R1786     -23
    e2_S4_0_9_visit[2]  R1787     -23
    e2_S4_0_9_visit[2]  R1788     -2
    e2_S4_0_9_visit[2]  R1789     -2
    e2_S4_0_9_visit[2]  R1791     -23
    e2_S4_0_9_visit[2]  R1792     -23
    e2_S4_0_9_visit[2]  R1793     -2
    e2_S4_0_9_visit[2]  R1794     -2
    e2_S4_0_9_visit[2]  R1810     -1
    e2_S4_0_9_visit[2]  R1812     23
    e2_S4_0_9_visit[2]  R1813     2
    e2_S4_0_9_visit[2]  R1825     1
    e2_S4_0_9_visit[2]  R3149     -10
    e2_S4_0_9_visit[2]  R3417     1
    e2_S4_0_9_visit[3]  R1713     4
    e2_S4_0_9_visit[3]  R1714     2
    e2_S4_0_9_visit[3]  R1724     -1
    e2_S4_0_9_visit[3]  R1725     -1
    e2_S4_0_9_visit[3]  R1726     1
    e2_S4_0_9_visit[3]  R1826     -38031
    e2_S4_0_9_visit[3]  R1827     71100
    e2_S4_0_9_visit[3]  R3152     -10
    e2_S4_0_9_visit[3]  R3418     1
    e2_S4_0_9_visit[4]  R1711     21
    e2_S4_0_9_visit[4]  R1712     2
    e2_S4_0_9_visit[4]  R1727     -1
    e2_S4_0_9_visit[4]  R1728     -1
    e2_S4_0_9_visit[4]  R1729     1
    e2_S4_0_9_visit[4]  R1746     -21
    e2_S4_0_9_visit[4]  R1747     -21
    e2_S4_0_9_visit[4]  R1748     -2
    e2_S4_0_9_visit[4]  R1749     -2
    e2_S4_0_9_visit[4]  R1751     -21
    e2_S4_0_9_visit[4]  R1752     -21
    e2_S4_0_9_visit[4]  R1753     -2
    e2_S4_0_9_visit[4]  R1754     -2
    e2_S4_0_9_visit[4]  R1756     -21
    e2_S4_0_9_visit[4]  R1757     -21
    e2_S4_0_9_visit[4]  R1758     -2
    e2_S4_0_9_visit[4]  R1759     -2
    e2_S4_0_9_visit[4]  R1761     -21
    e2_S4_0_9_visit[4]  R1762     -21
    e2_S4_0_9_visit[4]  R1763     -2
    e2_S4_0_9_visit[4]  R1764     -2
    e2_S4_0_9_visit[4]  R1766     -21
    e2_S4_0_9_visit[4]  R1767     -21
    e2_S4_0_9_visit[4]  R1768     -2
    e2_S4_0_9_visit[4]  R1769     -2
    e2_S4_0_9_visit[4]  R1771     -21
    e2_S4_0_9_visit[4]  R1772     -21
    e2_S4_0_9_visit[4]  R1773     -2
    e2_S4_0_9_visit[4]  R1774     -2
    e2_S4_0_9_visit[4]  R1776     -21
    e2_S4_0_9_visit[4]  R1777     -21
    e2_S4_0_9_visit[4]  R1778     -2
    e2_S4_0_9_visit[4]  R1779     -2
    e2_S4_0_9_visit[4]  R1781     -21
    e2_S4_0_9_visit[4]  R1782     -21
    e2_S4_0_9_visit[4]  R1783     -2
    e2_S4_0_9_visit[4]  R1784     -2
    e2_S4_0_9_visit[4]  R1786     -21
    e2_S4_0_9_visit[4]  R1787     -21
    e2_S4_0_9_visit[4]  R1788     -2
    e2_S4_0_9_visit[4]  R1789     -2
    e2_S4_0_9_visit[4]  R1791     -21
    e2_S4_0_9_visit[4]  R1792     -21
    e2_S4_0_9_visit[4]  R1793     -2
    e2_S4_0_9_visit[4]  R1794     -2
    e2_S4_0_9_visit[4]  R1814     -1
    e2_S4_0_9_visit[4]  R1816     21
    e2_S4_0_9_visit[4]  R1817     2
    e2_S4_0_9_visit[4]  R1828     1
    e2_S4_0_9_visit[4]  R3155     -10
    e2_S4_0_9_visit[4]  R3421     1
    e2_S4_0_9_visit[5]  R1713     4
    e2_S4_0_9_visit[5]  R1714     2
    e2_S4_0_9_visit[5]  R1730     -1
    e2_S4_0_9_visit[5]  R1731     -1
    e2_S4_0_9_visit[5]  R1732     1
    e2_S4_0_9_visit[5]  R1829     -25749
    e2_S4_0_9_visit[5]  R1830     71100
    e2_S4_0_9_visit[5]  R3158     -10
    e2_S4_0_9_visit[5]  R3422     1
    e2_S4_0_9_visit[6]  R1711     23
    e2_S4_0_9_visit[6]  R1712     2
    e2_S4_0_9_visit[6]  R1733     -1
    e2_S4_0_9_visit[6]  R1734     -1
    e2_S4_0_9_visit[6]  R1735     1
    e2_S4_0_9_visit[6]  R1746     -23
    e2_S4_0_9_visit[6]  R1747     -23
    e2_S4_0_9_visit[6]  R1748     -2
    e2_S4_0_9_visit[6]  R1749     -2
    e2_S4_0_9_visit[6]  R1751     -23
    e2_S4_0_9_visit[6]  R1752     -23
    e2_S4_0_9_visit[6]  R1753     -2
    e2_S4_0_9_visit[6]  R1754     -2
    e2_S4_0_9_visit[6]  R1756     -23
    e2_S4_0_9_visit[6]  R1757     -23
    e2_S4_0_9_visit[6]  R1758     -2
    e2_S4_0_9_visit[6]  R1759     -2
    e2_S4_0_9_visit[6]  R1761     -23
    e2_S4_0_9_visit[6]  R1762     -23
    e2_S4_0_9_visit[6]  R1763     -2
    e2_S4_0_9_visit[6]  R1764     -2
    e2_S4_0_9_visit[6]  R1766     -23
    e2_S4_0_9_visit[6]  R1767     -23
    e2_S4_0_9_visit[6]  R1768     -2
    e2_S4_0_9_visit[6]  R1769     -2
    e2_S4_0_9_visit[6]  R1771     -23
    e2_S4_0_9_visit[6]  R1772     -23
    e2_S4_0_9_visit[6]  R1773     -2
    e2_S4_0_9_visit[6]  R1774     -2
    e2_S4_0_9_visit[6]  R1776     -23
    e2_S4_0_9_visit[6]  R1777     -23
    e2_S4_0_9_visit[6]  R1778     -2
    e2_S4_0_9_visit[6]  R1779     -2
    e2_S4_0_9_visit[6]  R1781     -23
    e2_S4_0_9_visit[6]  R1782     -23
    e2_S4_0_9_visit[6]  R1783     -2
    e2_S4_0_9_visit[6]  R1784     -2
    e2_S4_0_9_visit[6]  R1786     -23
    e2_S4_0_9_visit[6]  R1787     -23
    e2_S4_0_9_visit[6]  R1788     -2
    e2_S4_0_9_visit[6]  R1789     -2
    e2_S4_0_9_visit[6]  R1791     -23
    e2_S4_0_9_visit[6]  R1792     -23
    e2_S4_0_9_visit[6]  R1793     -2
    e2_S4_0_9_visit[6]  R1794     -2
    e2_S4_0_9_visit[6]  R1814     -1
    e2_S4_0_9_visit[6]  R1816     23
    e2_S4_0_9_visit[6]  R1817     2
    e2_S4_0_9_visit[6]  R1831     1
    e2_S4_0_9_visit[6]  R3161     -10
    e2_S4_0_9_visit[6]  R3425     1
    e2_S4_0_9_visit[7]  R1713     4
    e2_S4_0_9_visit[7]  R1714     2
    e2_S4_0_9_visit[7]  R1736     -1
    e2_S4_0_9_visit[7]  R1737     -1
    e2_S4_0_9_visit[7]  R1738     1
    e2_S4_0_9_visit[7]  R1832     -23969
    e2_S4_0_9_visit[7]  R1833     71100
    e2_S4_0_9_visit[7]  R3164     -10
    e2_S4_0_9_visit[7]  R3426     1
    e2_S4_0_9_visit[8]  R1711     21
    e2_S4_0_9_visit[8]  R1712     2
    e2_S4_0_9_visit[8]  R1739     -1
    e2_S4_0_9_visit[8]  R1740     -1
    e2_S4_0_9_visit[8]  R1741     1
    e2_S4_0_9_visit[8]  R1746     -21
    e2_S4_0_9_visit[8]  R1747     -21
    e2_S4_0_9_visit[8]  R1748     -2
    e2_S4_0_9_visit[8]  R1749     -2
    e2_S4_0_9_visit[8]  R1751     -21
    e2_S4_0_9_visit[8]  R1752     -21
    e2_S4_0_9_visit[8]  R1753     -2
    e2_S4_0_9_visit[8]  R1754     -2
    e2_S4_0_9_visit[8]  R1756     -21
    e2_S4_0_9_visit[8]  R1757     -21
    e2_S4_0_9_visit[8]  R1758     -2
    e2_S4_0_9_visit[8]  R1759     -2
    e2_S4_0_9_visit[8]  R1761     -21
    e2_S4_0_9_visit[8]  R1762     -21
    e2_S4_0_9_visit[8]  R1763     -2
    e2_S4_0_9_visit[8]  R1764     -2
    e2_S4_0_9_visit[8]  R1766     -21
    e2_S4_0_9_visit[8]  R1767     -21
    e2_S4_0_9_visit[8]  R1768     -2
    e2_S4_0_9_visit[8]  R1769     -2
    e2_S4_0_9_visit[8]  R1771     -21
    e2_S4_0_9_visit[8]  R1772     -21
    e2_S4_0_9_visit[8]  R1773     -2
    e2_S4_0_9_visit[8]  R1774     -2
    e2_S4_0_9_visit[8]  R1776     -21
    e2_S4_0_9_visit[8]  R1777     -21
    e2_S4_0_9_visit[8]  R1778     -2
    e2_S4_0_9_visit[8]  R1779     -2
    e2_S4_0_9_visit[8]  R1781     -21
    e2_S4_0_9_visit[8]  R1782     -21
    e2_S4_0_9_visit[8]  R1783     -2
    e2_S4_0_9_visit[8]  R1784     -2
    e2_S4_0_9_visit[8]  R1786     -21
    e2_S4_0_9_visit[8]  R1787     -21
    e2_S4_0_9_visit[8]  R1788     -2
    e2_S4_0_9_visit[8]  R1789     -2
    e2_S4_0_9_visit[8]  R1791     -21
    e2_S4_0_9_visit[8]  R1792     -21
    e2_S4_0_9_visit[8]  R1793     -2
    e2_S4_0_9_visit[8]  R1794     -2
    e2_S4_0_9_visit[8]  R1818     -1
    e2_S4_0_9_visit[8]  R1820     21
    e2_S4_0_9_visit[8]  R1821     2
    e2_S4_0_9_visit[8]  R1834     1
    e2_S4_0_9_visit[8]  R3167     -10
    e2_S4_0_9_visit[8]  R3429     1
    e2_S4_0_9_visit[9]  R1713     4
    e2_S4_0_9_visit[9]  R1714     2
    e2_S4_0_9_visit[9]  R1742     -1
    e2_S4_0_9_visit[9]  R1743     -1
    e2_S4_0_9_visit[9]  R1744     1
    e2_S4_0_9_visit[9]  R1835     -11425
    e2_S4_0_9_visit[9]  R1836     71100
    e2_S4_0_9_visit[9]  R3170     -10
    e2_S4_0_9_visit[9]  R3430     1
    e2_S4_0_9_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_0_9_arc[-1,0]  R1709     1
    e2_S4_0_9_arc[-1,0]  R1715     1
    e2_S4_0_9_arc[-1,0]  R1745     -44319
    e2_S4_0_9_arc[-1,0]  R1746     -165
    e2_S4_0_9_arc[-1,0]  R1747     180
    e2_S4_0_9_arc[-1,0]  R1748     -5
    e2_S4_0_9_arc[-1,0]  R1749     6
    e2_S4_0_9_arc[-1,0]  R1837     -30
    e2_S4_0_9_arc[-1,0]  R3144     1
    e2_S4_0_9_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_0_9_arc[-1,1]  R1709     1
    e2_S4_0_9_arc[-1,1]  R1718     1
    e2_S4_0_9_arc[-1,1]  R1750     -41683
    e2_S4_0_9_arc[-1,1]  R1751     -180
    e2_S4_0_9_arc[-1,1]  R1752     178
    e2_S4_0_9_arc[-1,1]  R1753     -6
    e2_S4_0_9_arc[-1,1]  R1754     5
    e2_S4_0_9_arc[-1,1]  R1838     -30
    e2_S4_0_9_arc[-1,1]  R3147     1
    e2_S4_0_9_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_0_9_arc[-1,2]  R1709     1
    e2_S4_0_9_arc[-1,2]  R1721     1
    e2_S4_0_9_arc[-1,2]  R1755     -44289
    e2_S4_0_9_arc[-1,2]  R1756     -157
    e2_S4_0_9_arc[-1,2]  R1757     180
    e2_S4_0_9_arc[-1,2]  R1758     -4
    e2_S4_0_9_arc[-1,2]  R1759     6
    e2_S4_0_9_arc[-1,2]  R1839     -30
    e2_S4_0_9_arc[-1,2]  R3150     1
    e2_S4_0_9_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_0_9_arc[-1,3]  R1709     1
    e2_S4_0_9_arc[-1,3]  R1724     1
    e2_S4_0_9_arc[-1,3]  R1760     -40989
    e2_S4_0_9_arc[-1,3]  R1761     -180
    e2_S4_0_9_arc[-1,3]  R1762     176
    e2_S4_0_9_arc[-1,3]  R1763     -6
    e2_S4_0_9_arc[-1,3]  R1764     4
    e2_S4_0_9_arc[-1,3]  R1840     -30
    e2_S4_0_9_arc[-1,3]  R3153     1
    e2_S4_0_9_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_0_9_arc[-1,4]  R1709     1
    e2_S4_0_9_arc[-1,4]  R1727     1
    e2_S4_0_9_arc[-1,4]  R1765     -29919
    e2_S4_0_9_arc[-1,4]  R1766     -159
    e2_S4_0_9_arc[-1,4]  R1767     180
    e2_S4_0_9_arc[-1,4]  R1768     -4
    e2_S4_0_9_arc[-1,4]  R1769     6
    e2_S4_0_9_arc[-1,4]  R1841     -30
    e2_S4_0_9_arc[-1,4]  R3156     1
    e2_S4_0_9_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_0_9_arc[-1,5]  R1709     1
    e2_S4_0_9_arc[-1,5]  R1730     1
    e2_S4_0_9_arc[-1,5]  R1770     -26919
    e2_S4_0_9_arc[-1,5]  R1771     -180
    e2_S4_0_9_arc[-1,5]  R1772     176
    e2_S4_0_9_arc[-1,5]  R1773     -6
    e2_S4_0_9_arc[-1,5]  R1774     4
    e2_S4_0_9_arc[-1,5]  R1842     -30
    e2_S4_0_9_arc[-1,5]  R3159     1
    e2_S4_0_9_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_0_9_arc[-1,6]  R1709     1
    e2_S4_0_9_arc[-1,6]  R1733     1
    e2_S4_0_9_arc[-1,6]  R1775     -29851
    e2_S4_0_9_arc[-1,6]  R1776     -157
    e2_S4_0_9_arc[-1,6]  R1777     180
    e2_S4_0_9_arc[-1,6]  R1778     -4
    e2_S4_0_9_arc[-1,6]  R1779     6
    e2_S4_0_9_arc[-1,6]  R1843     -30
    e2_S4_0_9_arc[-1,6]  R3162     1
    e2_S4_0_9_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_0_9_arc[-1,7]  R1709     1
    e2_S4_0_9_arc[-1,7]  R1736     1
    e2_S4_0_9_arc[-1,7]  R1780     -25651
    e2_S4_0_9_arc[-1,7]  R1781     -180
    e2_S4_0_9_arc[-1,7]  R1782     176
    e2_S4_0_9_arc[-1,7]  R1783     -6
    e2_S4_0_9_arc[-1,7]  R1784     4
    e2_S4_0_9_arc[-1,7]  R1844     -30
    e2_S4_0_9_arc[-1,7]  R3165     1
    e2_S4_0_9_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_0_9_arc[-1,8]  R1709     1
    e2_S4_0_9_arc[-1,8]  R1739     1
    e2_S4_0_9_arc[-1,8]  R1785     -15519
    e2_S4_0_9_arc[-1,8]  R1786     -159
    e2_S4_0_9_arc[-1,8]  R1787     180
    e2_S4_0_9_arc[-1,8]  R1788     -4
    e2_S4_0_9_arc[-1,8]  R1789     6
    e2_S4_0_9_arc[-1,8]  R1845     -30
    e2_S4_0_9_arc[-1,8]  R3168     1
    e2_S4_0_9_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_0_9_arc[-1,9]  R1709     1
    e2_S4_0_9_arc[-1,9]  R1742     1
    e2_S4_0_9_arc[-1,9]  R1790     -13119
    e2_S4_0_9_arc[-1,9]  R1791     -180
    e2_S4_0_9_arc[-1,9]  R1792     176
    e2_S4_0_9_arc[-1,9]  R1793     -6
    e2_S4_0_9_arc[-1,9]  R1794     4
    e2_S4_0_9_arc[-1,9]  R1846     -30
    e2_S4_0_9_arc[-1,9]  R3171     1
    e2_S4_0_9_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_9_arc[0,-2]  R1710     1
    e2_S4_0_9_arc[0,-2]  R1716     1
    e2_S4_0_9_arc[0,-2]  R1795     -33523
    e2_S4_0_9_arc[0,-2]  R1847     -30
    e2_S4_0_9_arc[0,-2]  R3145     1
    e2_S4_0_9_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_0_9_arc[1,-2]  R1710     1
    e2_S4_0_9_arc[1,-2]  R1719     1
    e2_S4_0_9_arc[1,-2]  R1796     -39223
    e2_S4_0_9_arc[1,-2]  R1848     -30
    e2_S4_0_9_arc[1,-2]  R3148     1
    e2_S4_0_9_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_9_arc[2,-2]  R1710     1
    e2_S4_0_9_arc[2,-2]  R1722     1
    e2_S4_0_9_arc[2,-2]  R1797     -36369
    e2_S4_0_9_arc[2,-2]  R1849     -30
    e2_S4_0_9_arc[2,-2]  R3151     1
    e2_S4_0_9_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_0_9_arc[3,-2]  R1710     1
    e2_S4_0_9_arc[3,-2]  R1725     1
    e2_S4_0_9_arc[3,-2]  R1798     -42129
    e2_S4_0_9_arc[3,-2]  R1850     -30
    e2_S4_0_9_arc[3,-2]  R3154     1
    e2_S4_0_9_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_0_9_arc[4,-2]  R1710     1
    e2_S4_0_9_arc[4,-2]  R1728     1
    e2_S4_0_9_arc[4,-2]  R1799     -48315
    e2_S4_0_9_arc[4,-2]  R1851     -30
    e2_S4_0_9_arc[4,-2]  R3157     1
    e2_S4_0_9_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_0_9_arc[5,-2]  R1710     1
    e2_S4_0_9_arc[5,-2]  R1731     1
    e2_S4_0_9_arc[5,-2]  R1800     -53475
    e2_S4_0_9_arc[5,-2]  R1852     -30
    e2_S4_0_9_arc[5,-2]  R3160     1
    e2_S4_0_9_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_9_arc[6,-2]  R1710     1
    e2_S4_0_9_arc[6,-2]  R1734     1
    e2_S4_0_9_arc[6,-2]  R1801     -49531
    e2_S4_0_9_arc[6,-2]  R1853     -30
    e2_S4_0_9_arc[6,-2]  R3163     1
    e2_S4_0_9_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_0_9_arc[7,-2]  R1710     1
    e2_S4_0_9_arc[7,-2]  R1737     1
    e2_S4_0_9_arc[7,-2]  R1802     -56191
    e2_S4_0_9_arc[7,-2]  R1854     -30
    e2_S4_0_9_arc[7,-2]  R3166     1
    e2_S4_0_9_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_9_arc[8,-2]  R1710     1
    e2_S4_0_9_arc[8,-2]  R1740     1
    e2_S4_0_9_arc[8,-2]  R1803     -63217
    e2_S4_0_9_arc[8,-2]  R1855     -30
    e2_S4_0_9_arc[8,-2]  R3169     1
    e2_S4_0_9_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_0_9_arc[9,-2]  R1710     1
    e2_S4_0_9_arc[9,-2]  R1743     1
    e2_S4_0_9_arc[9,-2]  R1804     -68677
    e2_S4_0_9_arc[9,-2]  R1856     -30
    e2_S4_0_9_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C883      R1807     1
    C883      R1837     -1
    C883      R1838     -1
    C883      R1839     -1
    C883      R1840     -1
    C883      R1841     -1
    C883      R1842     -1
    C883      R1843     -1
    C883      R1844     -1
    C883      R1845     -1
    C883      R1846     -1
    C884      R1847     1
    C884      R1848     1
    C884      R1849     1
    C884      R1850     1
    C884      R1851     1
    C884      R1852     1
    C884      R1853     1
    C884      R1854     1
    C884      R1855     1
    C884      R1856     1
    MARKER    'MARKER'                 'INTORG'
    C885      R1808     1
    C885      R1809     -60
    C885      R1810     1
    C885      R1811     -39660
    C885      R1812     -180
    C885      R1813     -6
    C885      R1822     -1
    C885      R1825     -1
    C886      R1808     1
    C886      R1809     -60
    C886      R1814     1
    C886      R1815     -54060
    C886      R1816     -180
    C886      R1817     -6
    C886      R1828     -1
    C886      R1831     -1
    C887      R1808     1
    C887      R1809     -60
    C887      R1818     1
    C887      R1819     -71160
    C887      R1820     -180
    C887      R1821     -6
    C887      R1834     -1
    e2_S4_1_0_used  R1857     -75600
    e2_S4_1_0_used  R1858     -75600
    e2_S4_1_0_used  R1859     -28800
    e2_S4_1_0_used  R1860     -1
    e2_S4_1_0_used  R1861     -1
    e2_S4_1_0_used  R1862     -180
    e2_S4_1_0_used  R1863     -6
    e2_S4_1_0_used  R1864     -180
    e2_S4_1_0_used  R1865     -6
    e2_S4_1_0_used  R1868     -1
    e2_S4_1_0_used  R1871     -1
    e2_S4_1_0_used  R1874     -1
    e2_S4_1_0_used  R1877     -1
    e2_S4_1_0_used  R1880     -1
    e2_S4_1_0_used  R1883     -1
    e2_S4_1_0_used  R1886     -1
    e2_S4_1_0_used  R1889     -1
    e2_S4_1_0_used  R1892     -1
    e2_S4_1_0_used  R1895     -1
    e2_S4_1_0_used  R1956     1
    e2_S4_1_0_used  R1957     -75540
    e2_S4_1_0_used  R1958     -1
    e2_S4_1_0_used  R2106     -1
    e2_S4_1_0_used  R2610     1
    e2_S4_1_0_used  R2710     -1
    e2_S4_1_0_used  R3062     -1
    e2_S4_1_0_start  R1857     1
    e2_S4_1_0_start  R1859     1
    e2_S4_1_0_start  R1896     -1
    e2_S4_1_0_start  R1901     -1
    e2_S4_1_0_start  R1906     -1
    e2_S4_1_0_start  R1911     -1
    e2_S4_1_0_start  R1916     -1
    e2_S4_1_0_start  R1921     -1
    e2_S4_1_0_start  R1926     -1
    e2_S4_1_0_start  R1931     -1
    e2_S4_1_0_start  R1936     -1
    e2_S4_1_0_start  R1941     -1
    e2_S4_1_0_start  R1960     1
    e2_S4_1_0_start  R1964     1
    e2_S4_1_0_start  R1968     1
    e2_S4_1_0_end  R1858     1
    e2_S4_1_0_end  R1946     1
    e2_S4_1_0_end  R1947     1
    e2_S4_1_0_end  R1948     1
    e2_S4_1_0_end  R1949     1
    e2_S4_1_0_end  R1950     1
    e2_S4_1_0_end  R1951     1
    e2_S4_1_0_end  R1952     1
    e2_S4_1_0_end  R1953     1
    e2_S4_1_0_end  R1954     1
    e2_S4_1_0_end  R1955     1
    e2_S4_1_0_end  R1957     1
    e2_S4_1_0_end  R1972     -1
    e2_S4_1_0_end  R1973     -1
    e2_S4_1_0_end  R1975     -1
    e2_S4_1_0_end  R1976     -1
    e2_S4_1_0_end  R1978     -1
    e2_S4_1_0_end  R1979     -1
    e2_S4_1_0_end  R1981     -1
    e2_S4_1_0_end  R1982     -1
    e2_S4_1_0_end  R1984     -1
    e2_S4_1_0_end  R1985     -1
    e2_S4_1_0_end  R2109     -1
    e2_S4_1_0_visit[0]  R1862     15
    e2_S4_1_0_visit[0]  R1863     1
    e2_S4_1_0_visit[0]  R1866     -1
    e2_S4_1_0_visit[0]  R1867     -1
    e2_S4_1_0_visit[0]  R1868     1
    e2_S4_1_0_visit[0]  R1897     -15
    e2_S4_1_0_visit[0]  R1898     -15
    e2_S4_1_0_visit[0]  R1899     -1
    e2_S4_1_0_visit[0]  R1900     -1
    e2_S4_1_0_visit[0]  R1902     -15
    e2_S4_1_0_visit[0]  R1903     -15
    e2_S4_1_0_visit[0]  R1904     -1
    e2_S4_1_0_visit[0]  R1905     -1
    e2_S4_1_0_visit[0]  R1907     -15
    e2_S4_1_0_visit[0]  R1908     -15
    e2_S4_1_0_visit[0]  R1909     -1
    e2_S4_1_0_visit[0]  R1910     -1
    e2_S4_1_0_visit[0]  R1912     -15
    e2_S4_1_0_visit[0]  R1913     -15
    e2_S4_1_0_visit[0]  R1914     -1
    e2_S4_1_0_visit[0]  R1915     -1
    e2_S4_1_0_visit[0]  R1917     -15
    e2_S4_1_0_visit[0]  R1918     -15
    e2_S4_1_0_visit[0]  R1919     -1
    e2_S4_1_0_visit[0]  R1920     -1
    e2_S4_1_0_visit[0]  R1922     -15
    e2_S4_1_0_visit[0]  R1923     -15
    e2_S4_1_0_visit[0]  R1924     -1
    e2_S4_1_0_visit[0]  R1925     -1
    e2_S4_1_0_visit[0]  R1927     -15
    e2_S4_1_0_visit[0]  R1928     -15
    e2_S4_1_0_visit[0]  R1929     -1
    e2_S4_1_0_visit[0]  R1930     -1
    e2_S4_1_0_visit[0]  R1932     -15
    e2_S4_1_0_visit[0]  R1933     -15
    e2_S4_1_0_visit[0]  R1934     -1
    e2_S4_1_0_visit[0]  R1935     -1
    e2_S4_1_0_visit[0]  R1937     -15
    e2_S4_1_0_visit[0]  R1938     -15
    e2_S4_1_0_visit[0]  R1939     -1
    e2_S4_1_0_visit[0]  R1940     -1
    e2_S4_1_0_visit[0]  R1942     -15
    e2_S4_1_0_visit[0]  R1943     -15
    e2_S4_1_0_visit[0]  R1944     -1
    e2_S4_1_0_visit[0]  R1945     -1
    e2_S4_1_0_visit[0]  R1959     -1
    e2_S4_1_0_visit[0]  R1961     15
    e2_S4_1_0_visit[0]  R1962     1
    e2_S4_1_0_visit[0]  R1971     1
    e2_S4_1_0_visit[0]  R3143     -11
    e2_S4_1_0_visit[0]  R3413     1
    e2_S4_1_0_visit[1]  R1864     2
    e2_S4_1_0_visit[1]  R1865     1
    e2_S4_1_0_visit[1]  R1869     -1
    e2_S4_1_0_visit[1]  R1870     -1
    e2_S4_1_0_visit[1]  R1871     1
    e2_S4_1_0_visit[1]  R1972     -40937
    e2_S4_1_0_visit[1]  R1973     71100
    e2_S4_1_0_visit[1]  R3146     -11
    e2_S4_1_0_visit[1]  R3414     1
    e2_S4_1_0_visit[2]  R1862     23
    e2_S4_1_0_visit[2]  R1863     2
    e2_S4_1_0_visit[2]  R1872     -1
    e2_S4_1_0_visit[2]  R1873     -1
    e2_S4_1_0_visit[2]  R1874     1
    e2_S4_1_0_visit[2]  R1897     -23
    e2_S4_1_0_visit[2]  R1898     -23
    e2_S4_1_0_visit[2]  R1899     -2
    e2_S4_1_0_visit[2]  R1900     -2
    e2_S4_1_0_visit[2]  R1902     -23
    e2_S4_1_0_visit[2]  R1903     -23
    e2_S4_1_0_visit[2]  R1904     -2
    e2_S4_1_0_visit[2]  R1905     -2
    e2_S4_1_0_visit[2]  R1907     -23
    e2_S4_1_0_visit[2]  R1908     -23
    e2_S4_1_0_visit[2]  R1909     -2
    e2_S4_1_0_visit[2]  R1910     -2
    e2_S4_1_0_visit[2]  R1912     -23
    e2_S4_1_0_visit[2]  R1913     -23
    e2_S4_1_0_visit[2]  R1914     -2
    e2_S4_1_0_visit[2]  R1915     -2
    e2_S4_1_0_visit[2]  R1917     -23
    e2_S4_1_0_visit[2]  R1918     -23
    e2_S4_1_0_visit[2]  R1919     -2
    e2_S4_1_0_visit[2]  R1920     -2
    e2_S4_1_0_visit[2]  R1922     -23
    e2_S4_1_0_visit[2]  R1923     -23
    e2_S4_1_0_visit[2]  R1924     -2
    e2_S4_1_0_visit[2]  R1925     -2
    e2_S4_1_0_visit[2]  R1927     -23
    e2_S4_1_0_visit[2]  R1928     -23
    e2_S4_1_0_visit[2]  R1929     -2
    e2_S4_1_0_visit[2]  R1930     -2
    e2_S4_1_0_visit[2]  R1932     -23
    e2_S4_1_0_visit[2]  R1933     -23
    e2_S4_1_0_visit[2]  R1934     -2
    e2_S4_1_0_visit[2]  R1935     -2
    e2_S4_1_0_visit[2]  R1937     -23
    e2_S4_1_0_visit[2]  R1938     -23
    e2_S4_1_0_visit[2]  R1939     -2
    e2_S4_1_0_visit[2]  R1940     -2
    e2_S4_1_0_visit[2]  R1942     -23
    e2_S4_1_0_visit[2]  R1943     -23
    e2_S4_1_0_visit[2]  R1944     -2
    e2_S4_1_0_visit[2]  R1945     -2
    e2_S4_1_0_visit[2]  R1959     -1
    e2_S4_1_0_visit[2]  R1961     23
    e2_S4_1_0_visit[2]  R1962     2
    e2_S4_1_0_visit[2]  R1974     1
    e2_S4_1_0_visit[2]  R3149     -11
    e2_S4_1_0_visit[2]  R3417     1
    e2_S4_1_0_visit[3]  R1864     4
    e2_S4_1_0_visit[3]  R1865     2
    e2_S4_1_0_visit[3]  R1875     -1
    e2_S4_1_0_visit[3]  R1876     -1
    e2_S4_1_0_visit[3]  R1877     1
    e2_S4_1_0_visit[3]  R1975     -38031
    e2_S4_1_0_visit[3]  R1976     71100
    e2_S4_1_0_visit[3]  R3152     -11
    e2_S4_1_0_visit[3]  R3418     1
    e2_S4_1_0_visit[4]  R1862     21
    e2_S4_1_0_visit[4]  R1863     2
    e2_S4_1_0_visit[4]  R1878     -1
    e2_S4_1_0_visit[4]  R1879     -1
    e2_S4_1_0_visit[4]  R1880     1
    e2_S4_1_0_visit[4]  R1897     -21
    e2_S4_1_0_visit[4]  R1898     -21
    e2_S4_1_0_visit[4]  R1899     -2
    e2_S4_1_0_visit[4]  R1900     -2
    e2_S4_1_0_visit[4]  R1902     -21
    e2_S4_1_0_visit[4]  R1903     -21
    e2_S4_1_0_visit[4]  R1904     -2
    e2_S4_1_0_visit[4]  R1905     -2
    e2_S4_1_0_visit[4]  R1907     -21
    e2_S4_1_0_visit[4]  R1908     -21
    e2_S4_1_0_visit[4]  R1909     -2
    e2_S4_1_0_visit[4]  R1910     -2
    e2_S4_1_0_visit[4]  R1912     -21
    e2_S4_1_0_visit[4]  R1913     -21
    e2_S4_1_0_visit[4]  R1914     -2
    e2_S4_1_0_visit[4]  R1915     -2
    e2_S4_1_0_visit[4]  R1917     -21
    e2_S4_1_0_visit[4]  R1918     -21
    e2_S4_1_0_visit[4]  R1919     -2
    e2_S4_1_0_visit[4]  R1920     -2
    e2_S4_1_0_visit[4]  R1922     -21
    e2_S4_1_0_visit[4]  R1923     -21
    e2_S4_1_0_visit[4]  R1924     -2
    e2_S4_1_0_visit[4]  R1925     -2
    e2_S4_1_0_visit[4]  R1927     -21
    e2_S4_1_0_visit[4]  R1928     -21
    e2_S4_1_0_visit[4]  R1929     -2
    e2_S4_1_0_visit[4]  R1930     -2
    e2_S4_1_0_visit[4]  R1932     -21
    e2_S4_1_0_visit[4]  R1933     -21
    e2_S4_1_0_visit[4]  R1934     -2
    e2_S4_1_0_visit[4]  R1935     -2
    e2_S4_1_0_visit[4]  R1937     -21
    e2_S4_1_0_visit[4]  R1938     -21
    e2_S4_1_0_visit[4]  R1939     -2
    e2_S4_1_0_visit[4]  R1940     -2
    e2_S4_1_0_visit[4]  R1942     -21
    e2_S4_1_0_visit[4]  R1943     -21
    e2_S4_1_0_visit[4]  R1944     -2
    e2_S4_1_0_visit[4]  R1945     -2
    e2_S4_1_0_visit[4]  R1963     -1
    e2_S4_1_0_visit[4]  R1965     21
    e2_S4_1_0_visit[4]  R1966     2
    e2_S4_1_0_visit[4]  R1977     1
    e2_S4_1_0_visit[4]  R3155     -11
    e2_S4_1_0_visit[4]  R3421     1
    e2_S4_1_0_visit[5]  R1864     4
    e2_S4_1_0_visit[5]  R1865     2
    e2_S4_1_0_visit[5]  R1881     -1
    e2_S4_1_0_visit[5]  R1882     -1
    e2_S4_1_0_visit[5]  R1883     1
    e2_S4_1_0_visit[5]  R1978     -25749
    e2_S4_1_0_visit[5]  R1979     71100
    e2_S4_1_0_visit[5]  R3158     -11
    e2_S4_1_0_visit[5]  R3422     1
    e2_S4_1_0_visit[6]  R1862     23
    e2_S4_1_0_visit[6]  R1863     2
    e2_S4_1_0_visit[6]  R1884     -1
    e2_S4_1_0_visit[6]  R1885     -1
    e2_S4_1_0_visit[6]  R1886     1
    e2_S4_1_0_visit[6]  R1897     -23
    e2_S4_1_0_visit[6]  R1898     -23
    e2_S4_1_0_visit[6]  R1899     -2
    e2_S4_1_0_visit[6]  R1900     -2
    e2_S4_1_0_visit[6]  R1902     -23
    e2_S4_1_0_visit[6]  R1903     -23
    e2_S4_1_0_visit[6]  R1904     -2
    e2_S4_1_0_visit[6]  R1905     -2
    e2_S4_1_0_visit[6]  R1907     -23
    e2_S4_1_0_visit[6]  R1908     -23
    e2_S4_1_0_visit[6]  R1909     -2
    e2_S4_1_0_visit[6]  R1910     -2
    e2_S4_1_0_visit[6]  R1912     -23
    e2_S4_1_0_visit[6]  R1913     -23
    e2_S4_1_0_visit[6]  R1914     -2
    e2_S4_1_0_visit[6]  R1915     -2
    e2_S4_1_0_visit[6]  R1917     -23
    e2_S4_1_0_visit[6]  R1918     -23
    e2_S4_1_0_visit[6]  R1919     -2
    e2_S4_1_0_visit[6]  R1920     -2
    e2_S4_1_0_visit[6]  R1922     -23
    e2_S4_1_0_visit[6]  R1923     -23
    e2_S4_1_0_visit[6]  R1924     -2
    e2_S4_1_0_visit[6]  R1925     -2
    e2_S4_1_0_visit[6]  R1927     -23
    e2_S4_1_0_visit[6]  R1928     -23
    e2_S4_1_0_visit[6]  R1929     -2
    e2_S4_1_0_visit[6]  R1930     -2
    e2_S4_1_0_visit[6]  R1932     -23
    e2_S4_1_0_visit[6]  R1933     -23
    e2_S4_1_0_visit[6]  R1934     -2
    e2_S4_1_0_visit[6]  R1935     -2
    e2_S4_1_0_visit[6]  R1937     -23
    e2_S4_1_0_visit[6]  R1938     -23
    e2_S4_1_0_visit[6]  R1939     -2
    e2_S4_1_0_visit[6]  R1940     -2
    e2_S4_1_0_visit[6]  R1942     -23
    e2_S4_1_0_visit[6]  R1943     -23
    e2_S4_1_0_visit[6]  R1944     -2
    e2_S4_1_0_visit[6]  R1945     -2
    e2_S4_1_0_visit[6]  R1963     -1
    e2_S4_1_0_visit[6]  R1965     23
    e2_S4_1_0_visit[6]  R1966     2
    e2_S4_1_0_visit[6]  R1980     1
    e2_S4_1_0_visit[6]  R3161     -11
    e2_S4_1_0_visit[6]  R3425     1
    e2_S4_1_0_visit[7]  R1864     4
    e2_S4_1_0_visit[7]  R1865     2
    e2_S4_1_0_visit[7]  R1887     -1
    e2_S4_1_0_visit[7]  R1888     -1
    e2_S4_1_0_visit[7]  R1889     1
    e2_S4_1_0_visit[7]  R1981     -23969
    e2_S4_1_0_visit[7]  R1982     71100
    e2_S4_1_0_visit[7]  R3164     -11
    e2_S4_1_0_visit[7]  R3426     1
    e2_S4_1_0_visit[8]  R1862     21
    e2_S4_1_0_visit[8]  R1863     2
    e2_S4_1_0_visit[8]  R1890     -1
    e2_S4_1_0_visit[8]  R1891     -1
    e2_S4_1_0_visit[8]  R1892     1
    e2_S4_1_0_visit[8]  R1897     -21
    e2_S4_1_0_visit[8]  R1898     -21
    e2_S4_1_0_visit[8]  R1899     -2
    e2_S4_1_0_visit[8]  R1900     -2
    e2_S4_1_0_visit[8]  R1902     -21
    e2_S4_1_0_visit[8]  R1903     -21
    e2_S4_1_0_visit[8]  R1904     -2
    e2_S4_1_0_visit[8]  R1905     -2
    e2_S4_1_0_visit[8]  R1907     -21
    e2_S4_1_0_visit[8]  R1908     -21
    e2_S4_1_0_visit[8]  R1909     -2
    e2_S4_1_0_visit[8]  R1910     -2
    e2_S4_1_0_visit[8]  R1912     -21
    e2_S4_1_0_visit[8]  R1913     -21
    e2_S4_1_0_visit[8]  R1914     -2
    e2_S4_1_0_visit[8]  R1915     -2
    e2_S4_1_0_visit[8]  R1917     -21
    e2_S4_1_0_visit[8]  R1918     -21
    e2_S4_1_0_visit[8]  R1919     -2
    e2_S4_1_0_visit[8]  R1920     -2
    e2_S4_1_0_visit[8]  R1922     -21
    e2_S4_1_0_visit[8]  R1923     -21
    e2_S4_1_0_visit[8]  R1924     -2
    e2_S4_1_0_visit[8]  R1925     -2
    e2_S4_1_0_visit[8]  R1927     -21
    e2_S4_1_0_visit[8]  R1928     -21
    e2_S4_1_0_visit[8]  R1929     -2
    e2_S4_1_0_visit[8]  R1930     -2
    e2_S4_1_0_visit[8]  R1932     -21
    e2_S4_1_0_visit[8]  R1933     -21
    e2_S4_1_0_visit[8]  R1934     -2
    e2_S4_1_0_visit[8]  R1935     -2
    e2_S4_1_0_visit[8]  R1937     -21
    e2_S4_1_0_visit[8]  R1938     -21
    e2_S4_1_0_visit[8]  R1939     -2
    e2_S4_1_0_visit[8]  R1940     -2
    e2_S4_1_0_visit[8]  R1942     -21
    e2_S4_1_0_visit[8]  R1943     -21
    e2_S4_1_0_visit[8]  R1944     -2
    e2_S4_1_0_visit[8]  R1945     -2
    e2_S4_1_0_visit[8]  R1967     -1
    e2_S4_1_0_visit[8]  R1969     21
    e2_S4_1_0_visit[8]  R1970     2
    e2_S4_1_0_visit[8]  R1983     1
    e2_S4_1_0_visit[8]  R3167     -11
    e2_S4_1_0_visit[8]  R3429     1
    e2_S4_1_0_visit[9]  R1864     4
    e2_S4_1_0_visit[9]  R1865     2
    e2_S4_1_0_visit[9]  R1893     -1
    e2_S4_1_0_visit[9]  R1894     -1
    e2_S4_1_0_visit[9]  R1895     1
    e2_S4_1_0_visit[9]  R1984     -11425
    e2_S4_1_0_visit[9]  R1985     71100
    e2_S4_1_0_visit[9]  R3170     -11
    e2_S4_1_0_visit[9]  R3430     1
    e2_S4_1_0_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_1_0_arc[-1,0]  R1860     1
    e2_S4_1_0_arc[-1,0]  R1866     1
    e2_S4_1_0_arc[-1,0]  R1896     -44319
    e2_S4_1_0_arc[-1,0]  R1897     -165
    e2_S4_1_0_arc[-1,0]  R1898     180
    e2_S4_1_0_arc[-1,0]  R1899     -5
    e2_S4_1_0_arc[-1,0]  R1900     6
    e2_S4_1_0_arc[-1,0]  R1986     -30
    e2_S4_1_0_arc[-1,0]  R3144     1
    e2_S4_1_0_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_1_0_arc[-1,1]  R1860     1
    e2_S4_1_0_arc[-1,1]  R1869     1
    e2_S4_1_0_arc[-1,1]  R1901     -41683
    e2_S4_1_0_arc[-1,1]  R1902     -180
    e2_S4_1_0_arc[-1,1]  R1903     178
    e2_S4_1_0_arc[-1,1]  R1904     -6
    e2_S4_1_0_arc[-1,1]  R1905     5
    e2_S4_1_0_arc[-1,1]  R1987     -30
    e2_S4_1_0_arc[-1,1]  R3147     1
    e2_S4_1_0_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_1_0_arc[-1,2]  R1860     1
    e2_S4_1_0_arc[-1,2]  R1872     1
    e2_S4_1_0_arc[-1,2]  R1906     -44289
    e2_S4_1_0_arc[-1,2]  R1907     -157
    e2_S4_1_0_arc[-1,2]  R1908     180
    e2_S4_1_0_arc[-1,2]  R1909     -4
    e2_S4_1_0_arc[-1,2]  R1910     6
    e2_S4_1_0_arc[-1,2]  R1988     -30
    e2_S4_1_0_arc[-1,2]  R3150     1
    e2_S4_1_0_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_1_0_arc[-1,3]  R1860     1
    e2_S4_1_0_arc[-1,3]  R1875     1
    e2_S4_1_0_arc[-1,3]  R1911     -40989
    e2_S4_1_0_arc[-1,3]  R1912     -180
    e2_S4_1_0_arc[-1,3]  R1913     176
    e2_S4_1_0_arc[-1,3]  R1914     -6
    e2_S4_1_0_arc[-1,3]  R1915     4
    e2_S4_1_0_arc[-1,3]  R1989     -30
    e2_S4_1_0_arc[-1,3]  R3153     1
    e2_S4_1_0_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_1_0_arc[-1,4]  R1860     1
    e2_S4_1_0_arc[-1,4]  R1878     1
    e2_S4_1_0_arc[-1,4]  R1916     -29919
    e2_S4_1_0_arc[-1,4]  R1917     -159
    e2_S4_1_0_arc[-1,4]  R1918     180
    e2_S4_1_0_arc[-1,4]  R1919     -4
    e2_S4_1_0_arc[-1,4]  R1920     6
    e2_S4_1_0_arc[-1,4]  R1990     -30
    e2_S4_1_0_arc[-1,4]  R3156     1
    e2_S4_1_0_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_1_0_arc[-1,5]  R1860     1
    e2_S4_1_0_arc[-1,5]  R1881     1
    e2_S4_1_0_arc[-1,5]  R1921     -26919
    e2_S4_1_0_arc[-1,5]  R1922     -180
    e2_S4_1_0_arc[-1,5]  R1923     176
    e2_S4_1_0_arc[-1,5]  R1924     -6
    e2_S4_1_0_arc[-1,5]  R1925     4
    e2_S4_1_0_arc[-1,5]  R1991     -30
    e2_S4_1_0_arc[-1,5]  R3159     1
    e2_S4_1_0_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_1_0_arc[-1,6]  R1860     1
    e2_S4_1_0_arc[-1,6]  R1884     1
    e2_S4_1_0_arc[-1,6]  R1926     -29851
    e2_S4_1_0_arc[-1,6]  R1927     -157
    e2_S4_1_0_arc[-1,6]  R1928     180
    e2_S4_1_0_arc[-1,6]  R1929     -4
    e2_S4_1_0_arc[-1,6]  R1930     6
    e2_S4_1_0_arc[-1,6]  R1992     -30
    e2_S4_1_0_arc[-1,6]  R3162     1
    e2_S4_1_0_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_1_0_arc[-1,7]  R1860     1
    e2_S4_1_0_arc[-1,7]  R1887     1
    e2_S4_1_0_arc[-1,7]  R1931     -25651
    e2_S4_1_0_arc[-1,7]  R1932     -180
    e2_S4_1_0_arc[-1,7]  R1933     176
    e2_S4_1_0_arc[-1,7]  R1934     -6
    e2_S4_1_0_arc[-1,7]  R1935     4
    e2_S4_1_0_arc[-1,7]  R1993     -30
    e2_S4_1_0_arc[-1,7]  R3165     1
    e2_S4_1_0_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_1_0_arc[-1,8]  R1860     1
    e2_S4_1_0_arc[-1,8]  R1890     1
    e2_S4_1_0_arc[-1,8]  R1936     -15519
    e2_S4_1_0_arc[-1,8]  R1937     -159
    e2_S4_1_0_arc[-1,8]  R1938     180
    e2_S4_1_0_arc[-1,8]  R1939     -4
    e2_S4_1_0_arc[-1,8]  R1940     6
    e2_S4_1_0_arc[-1,8]  R1994     -30
    e2_S4_1_0_arc[-1,8]  R3168     1
    e2_S4_1_0_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_1_0_arc[-1,9]  R1860     1
    e2_S4_1_0_arc[-1,9]  R1893     1
    e2_S4_1_0_arc[-1,9]  R1941     -13119
    e2_S4_1_0_arc[-1,9]  R1942     -180
    e2_S4_1_0_arc[-1,9]  R1943     176
    e2_S4_1_0_arc[-1,9]  R1944     -6
    e2_S4_1_0_arc[-1,9]  R1945     4
    e2_S4_1_0_arc[-1,9]  R1995     -30
    e2_S4_1_0_arc[-1,9]  R3171     1
    e2_S4_1_0_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_0_arc[0,-2]  R1861     1
    e2_S4_1_0_arc[0,-2]  R1867     1
    e2_S4_1_0_arc[0,-2]  R1946     -33523
    e2_S4_1_0_arc[0,-2]  R1996     -30
    e2_S4_1_0_arc[0,-2]  R3145     1
    e2_S4_1_0_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_0_arc[1,-2]  R1861     1
    e2_S4_1_0_arc[1,-2]  R1870     1
    e2_S4_1_0_arc[1,-2]  R1947     -39223
    e2_S4_1_0_arc[1,-2]  R1997     -30
    e2_S4_1_0_arc[1,-2]  R3148     1
    e2_S4_1_0_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_0_arc[2,-2]  R1861     1
    e2_S4_1_0_arc[2,-2]  R1873     1
    e2_S4_1_0_arc[2,-2]  R1948     -36369
    e2_S4_1_0_arc[2,-2]  R1998     -30
    e2_S4_1_0_arc[2,-2]  R3151     1
    e2_S4_1_0_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_0_arc[3,-2]  R1861     1
    e2_S4_1_0_arc[3,-2]  R1876     1
    e2_S4_1_0_arc[3,-2]  R1949     -42129
    e2_S4_1_0_arc[3,-2]  R1999     -30
    e2_S4_1_0_arc[3,-2]  R3154     1
    e2_S4_1_0_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_1_0_arc[4,-2]  R1861     1
    e2_S4_1_0_arc[4,-2]  R1879     1
    e2_S4_1_0_arc[4,-2]  R1950     -48315
    e2_S4_1_0_arc[4,-2]  R2000     -30
    e2_S4_1_0_arc[4,-2]  R3157     1
    e2_S4_1_0_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_1_0_arc[5,-2]  R1861     1
    e2_S4_1_0_arc[5,-2]  R1882     1
    e2_S4_1_0_arc[5,-2]  R1951     -53475
    e2_S4_1_0_arc[5,-2]  R2001     -30
    e2_S4_1_0_arc[5,-2]  R3160     1
    e2_S4_1_0_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_0_arc[6,-2]  R1861     1
    e2_S4_1_0_arc[6,-2]  R1885     1
    e2_S4_1_0_arc[6,-2]  R1952     -49531
    e2_S4_1_0_arc[6,-2]  R2002     -30
    e2_S4_1_0_arc[6,-2]  R3163     1
    e2_S4_1_0_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_0_arc[7,-2]  R1861     1
    e2_S4_1_0_arc[7,-2]  R1888     1
    e2_S4_1_0_arc[7,-2]  R1953     -56191
    e2_S4_1_0_arc[7,-2]  R2003     -30
    e2_S4_1_0_arc[7,-2]  R3166     1
    e2_S4_1_0_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_0_arc[8,-2]  R1861     1
    e2_S4_1_0_arc[8,-2]  R1891     1
    e2_S4_1_0_arc[8,-2]  R1954     -63217
    e2_S4_1_0_arc[8,-2]  R2004     -30
    e2_S4_1_0_arc[8,-2]  R3169     1
    e2_S4_1_0_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_0_arc[9,-2]  R1861     1
    e2_S4_1_0_arc[9,-2]  R1894     1
    e2_S4_1_0_arc[9,-2]  R1955     -68677
    e2_S4_1_0_arc[9,-2]  R2005     -30
    e2_S4_1_0_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C921      R1986     -1
    C921      R1987     -1
    C921      R1988     -1
    C921      R1989     -1
    C921      R1990     -1
    C921      R1991     -1
    C921      R1992     -1
    C921      R1993     -1
    C921      R1994     -1
    C921      R1995     -1
    C922      R1996     1
    C922      R1997     1
    C922      R1998     1
    C922      R1999     1
    C922      R2000     1
    C922      R2001     1
    C922      R2002     1
    C922      R2003     1
    C922      R2004     1
    C922      R2005     1
    C922      R2107     -1
    MARKER    'MARKER'                 'INTORG'
    C923      R1958     1
    C923      R1959     1
    C923      R1960     -39660
    C923      R1961     -180
    C923      R1962     -6
    C923      R1971     -1
    C923      R1974     -1
    C924      R1958     1
    C924      R1963     1
    C924      R1964     -54060
    C924      R1965     -180
    C924      R1966     -6
    C924      R1977     -1
    C924      R1980     -1
    C925      R1958     1
    C925      R1967     1
    C925      R1968     -71160
    C925      R1969     -180
    C925      R1970     -6
    C925      R1983     -1
    e2_S4_1_1_used  R2006     -75600
    e2_S4_1_1_used  R2007     -75600
    e2_S4_1_1_used  R2008     -28800
    e2_S4_1_1_used  R2009     -1
    e2_S4_1_1_used  R2010     -1
    e2_S4_1_1_used  R2011     -180
    e2_S4_1_1_used  R2012     -6
    e2_S4_1_1_used  R2013     -180
    e2_S4_1_1_used  R2014     -6
    e2_S4_1_1_used  R2017     -1
    e2_S4_1_1_used  R2020     -1
    e2_S4_1_1_used  R2023     -1
    e2_S4_1_1_used  R2026     -1
    e2_S4_1_1_used  R2029     -1
    e2_S4_1_1_used  R2032     -1
    e2_S4_1_1_used  R2035     -1
    e2_S4_1_1_used  R2038     -1
    e2_S4_1_1_used  R2041     -1
    e2_S4_1_1_used  R2044     -1
    e2_S4_1_1_used  R2105     -75540
    e2_S4_1_1_used  R2106     1
    e2_S4_1_1_used  R2107     -30
    e2_S4_1_1_used  R2108     -1
    e2_S4_1_1_used  R2109     -75600
    e2_S4_1_1_used  R2257     -1
    e2_S4_1_1_used  R2610     1
    e2_S4_1_1_used  R3062     -1
    e2_S4_1_1_start  R2006     1
    e2_S4_1_1_start  R2008     1
    e2_S4_1_1_start  R2045     -1
    e2_S4_1_1_start  R2050     -1
    e2_S4_1_1_start  R2055     -1
    e2_S4_1_1_start  R2060     -1
    e2_S4_1_1_start  R2065     -1
    e2_S4_1_1_start  R2070     -1
    e2_S4_1_1_start  R2075     -1
    e2_S4_1_1_start  R2080     -1
    e2_S4_1_1_start  R2085     -1
    e2_S4_1_1_start  R2090     -1
    e2_S4_1_1_start  R2109     1
    e2_S4_1_1_start  R2111     1
    e2_S4_1_1_start  R2115     1
    e2_S4_1_1_start  R2119     1
    e2_S4_1_1_end  R2007     1
    e2_S4_1_1_end  R2095     1
    e2_S4_1_1_end  R2096     1
    e2_S4_1_1_end  R2097     1
    e2_S4_1_1_end  R2098     1
    e2_S4_1_1_end  R2099     1
    e2_S4_1_1_end  R2100     1
    e2_S4_1_1_end  R2101     1
    e2_S4_1_1_end  R2102     1
    e2_S4_1_1_end  R2103     1
    e2_S4_1_1_end  R2104     1
    e2_S4_1_1_end  R2105     1
    e2_S4_1_1_end  R2123     -1
    e2_S4_1_1_end  R2124     -1
    e2_S4_1_1_end  R2126     -1
    e2_S4_1_1_end  R2127     -1
    e2_S4_1_1_end  R2129     -1
    e2_S4_1_1_end  R2130     -1
    e2_S4_1_1_end  R2132     -1
    e2_S4_1_1_end  R2133     -1
    e2_S4_1_1_end  R2135     -1
    e2_S4_1_1_end  R2136     -1
    e2_S4_1_1_end  R2260     -1
    e2_S4_1_1_visit[0]  R2011     15
    e2_S4_1_1_visit[0]  R2012     1
    e2_S4_1_1_visit[0]  R2015     -1
    e2_S4_1_1_visit[0]  R2016     -1
    e2_S4_1_1_visit[0]  R2017     1
    e2_S4_1_1_visit[0]  R2046     -15
    e2_S4_1_1_visit[0]  R2047     -15
    e2_S4_1_1_visit[0]  R2048     -1
    e2_S4_1_1_visit[0]  R2049     -1
    e2_S4_1_1_visit[0]  R2051     -15
    e2_S4_1_1_visit[0]  R2052     -15
    e2_S4_1_1_visit[0]  R2053     -1
    e2_S4_1_1_visit[0]  R2054     -1
    e2_S4_1_1_visit[0]  R2056     -15
    e2_S4_1_1_visit[0]  R2057     -15
    e2_S4_1_1_visit[0]  R2058     -1
    e2_S4_1_1_visit[0]  R2059     -1
    e2_S4_1_1_visit[0]  R2061     -15
    e2_S4_1_1_visit[0]  R2062     -15
    e2_S4_1_1_visit[0]  R2063     -1
    e2_S4_1_1_visit[0]  R2064     -1
    e2_S4_1_1_visit[0]  R2066     -15
    e2_S4_1_1_visit[0]  R2067     -15
    e2_S4_1_1_visit[0]  R2068     -1
    e2_S4_1_1_visit[0]  R2069     -1
    e2_S4_1_1_visit[0]  R2071     -15
    e2_S4_1_1_visit[0]  R2072     -15
    e2_S4_1_1_visit[0]  R2073     -1
    e2_S4_1_1_visit[0]  R2074     -1
    e2_S4_1_1_visit[0]  R2076     -15
    e2_S4_1_1_visit[0]  R2077     -15
    e2_S4_1_1_visit[0]  R2078     -1
    e2_S4_1_1_visit[0]  R2079     -1
    e2_S4_1_1_visit[0]  R2081     -15
    e2_S4_1_1_visit[0]  R2082     -15
    e2_S4_1_1_visit[0]  R2083     -1
    e2_S4_1_1_visit[0]  R2084     -1
    e2_S4_1_1_visit[0]  R2086     -15
    e2_S4_1_1_visit[0]  R2087     -15
    e2_S4_1_1_visit[0]  R2088     -1
    e2_S4_1_1_visit[0]  R2089     -1
    e2_S4_1_1_visit[0]  R2091     -15
    e2_S4_1_1_visit[0]  R2092     -15
    e2_S4_1_1_visit[0]  R2093     -1
    e2_S4_1_1_visit[0]  R2094     -1
    e2_S4_1_1_visit[0]  R2110     -1
    e2_S4_1_1_visit[0]  R2112     15
    e2_S4_1_1_visit[0]  R2113     1
    e2_S4_1_1_visit[0]  R2122     1
    e2_S4_1_1_visit[0]  R3143     -12
    e2_S4_1_1_visit[0]  R3413     1
    e2_S4_1_1_visit[1]  R2013     2
    e2_S4_1_1_visit[1]  R2014     1
    e2_S4_1_1_visit[1]  R2018     -1
    e2_S4_1_1_visit[1]  R2019     -1
    e2_S4_1_1_visit[1]  R2020     1
    e2_S4_1_1_visit[1]  R2123     -40937
    e2_S4_1_1_visit[1]  R2124     71100
    e2_S4_1_1_visit[1]  R3146     -12
    e2_S4_1_1_visit[1]  R3414     1
    e2_S4_1_1_visit[2]  R2011     23
    e2_S4_1_1_visit[2]  R2012     2
    e2_S4_1_1_visit[2]  R2021     -1
    e2_S4_1_1_visit[2]  R2022     -1
    e2_S4_1_1_visit[2]  R2023     1
    e2_S4_1_1_visit[2]  R2046     -23
    e2_S4_1_1_visit[2]  R2047     -23
    e2_S4_1_1_visit[2]  R2048     -2
    e2_S4_1_1_visit[2]  R2049     -2
    e2_S4_1_1_visit[2]  R2051     -23
    e2_S4_1_1_visit[2]  R2052     -23
    e2_S4_1_1_visit[2]  R2053     -2
    e2_S4_1_1_visit[2]  R2054     -2
    e2_S4_1_1_visit[2]  R2056     -23
    e2_S4_1_1_visit[2]  R2057     -23
    e2_S4_1_1_visit[2]  R2058     -2
    e2_S4_1_1_visit[2]  R2059     -2
    e2_S4_1_1_visit[2]  R2061     -23
    e2_S4_1_1_visit[2]  R2062     -23
    e2_S4_1_1_visit[2]  R2063     -2
    e2_S4_1_1_visit[2]  R2064     -2
    e2_S4_1_1_visit[2]  R2066     -23
    e2_S4_1_1_visit[2]  R2067     -23
    e2_S4_1_1_visit[2]  R2068     -2
    e2_S4_1_1_visit[2]  R2069     -2
    e2_S4_1_1_visit[2]  R2071     -23
    e2_S4_1_1_visit[2]  R2072     -23
    e2_S4_1_1_visit[2]  R2073     -2
    e2_S4_1_1_visit[2]  R2074     -2
    e2_S4_1_1_visit[2]  R2076     -23
    e2_S4_1_1_visit[2]  R2077     -23
    e2_S4_1_1_visit[2]  R2078     -2
    e2_S4_1_1_visit[2]  R2079     -2
    e2_S4_1_1_visit[2]  R2081     -23
    e2_S4_1_1_visit[2]  R2082     -23
    e2_S4_1_1_visit[2]  R2083     -2
    e2_S4_1_1_visit[2]  R2084     -2
    e2_S4_1_1_visit[2]  R2086     -23
    e2_S4_1_1_visit[2]  R2087     -23
    e2_S4_1_1_visit[2]  R2088     -2
    e2_S4_1_1_visit[2]  R2089     -2
    e2_S4_1_1_visit[2]  R2091     -23
    e2_S4_1_1_visit[2]  R2092     -23
    e2_S4_1_1_visit[2]  R2093     -2
    e2_S4_1_1_visit[2]  R2094     -2
    e2_S4_1_1_visit[2]  R2110     -1
    e2_S4_1_1_visit[2]  R2112     23
    e2_S4_1_1_visit[2]  R2113     2
    e2_S4_1_1_visit[2]  R2125     1
    e2_S4_1_1_visit[2]  R3149     -12
    e2_S4_1_1_visit[2]  R3417     1
    e2_S4_1_1_visit[3]  R2013     4
    e2_S4_1_1_visit[3]  R2014     2
    e2_S4_1_1_visit[3]  R2024     -1
    e2_S4_1_1_visit[3]  R2025     -1
    e2_S4_1_1_visit[3]  R2026     1
    e2_S4_1_1_visit[3]  R2126     -38031
    e2_S4_1_1_visit[3]  R2127     71100
    e2_S4_1_1_visit[3]  R3152     -12
    e2_S4_1_1_visit[3]  R3418     1
    e2_S4_1_1_visit[4]  R2011     21
    e2_S4_1_1_visit[4]  R2012     2
    e2_S4_1_1_visit[4]  R2027     -1
    e2_S4_1_1_visit[4]  R2028     -1
    e2_S4_1_1_visit[4]  R2029     1
    e2_S4_1_1_visit[4]  R2046     -21
    e2_S4_1_1_visit[4]  R2047     -21
    e2_S4_1_1_visit[4]  R2048     -2
    e2_S4_1_1_visit[4]  R2049     -2
    e2_S4_1_1_visit[4]  R2051     -21
    e2_S4_1_1_visit[4]  R2052     -21
    e2_S4_1_1_visit[4]  R2053     -2
    e2_S4_1_1_visit[4]  R2054     -2
    e2_S4_1_1_visit[4]  R2056     -21
    e2_S4_1_1_visit[4]  R2057     -21
    e2_S4_1_1_visit[4]  R2058     -2
    e2_S4_1_1_visit[4]  R2059     -2
    e2_S4_1_1_visit[4]  R2061     -21
    e2_S4_1_1_visit[4]  R2062     -21
    e2_S4_1_1_visit[4]  R2063     -2
    e2_S4_1_1_visit[4]  R2064     -2
    e2_S4_1_1_visit[4]  R2066     -21
    e2_S4_1_1_visit[4]  R2067     -21
    e2_S4_1_1_visit[4]  R2068     -2
    e2_S4_1_1_visit[4]  R2069     -2
    e2_S4_1_1_visit[4]  R2071     -21
    e2_S4_1_1_visit[4]  R2072     -21
    e2_S4_1_1_visit[4]  R2073     -2
    e2_S4_1_1_visit[4]  R2074     -2
    e2_S4_1_1_visit[4]  R2076     -21
    e2_S4_1_1_visit[4]  R2077     -21
    e2_S4_1_1_visit[4]  R2078     -2
    e2_S4_1_1_visit[4]  R2079     -2
    e2_S4_1_1_visit[4]  R2081     -21
    e2_S4_1_1_visit[4]  R2082     -21
    e2_S4_1_1_visit[4]  R2083     -2
    e2_S4_1_1_visit[4]  R2084     -2
    e2_S4_1_1_visit[4]  R2086     -21
    e2_S4_1_1_visit[4]  R2087     -21
    e2_S4_1_1_visit[4]  R2088     -2
    e2_S4_1_1_visit[4]  R2089     -2
    e2_S4_1_1_visit[4]  R2091     -21
    e2_S4_1_1_visit[4]  R2092     -21
    e2_S4_1_1_visit[4]  R2093     -2
    e2_S4_1_1_visit[4]  R2094     -2
    e2_S4_1_1_visit[4]  R2114     -1
    e2_S4_1_1_visit[4]  R2116     21
    e2_S4_1_1_visit[4]  R2117     2
    e2_S4_1_1_visit[4]  R2128     1
    e2_S4_1_1_visit[4]  R3155     -12
    e2_S4_1_1_visit[4]  R3421     1
    e2_S4_1_1_visit[5]  R2013     4
    e2_S4_1_1_visit[5]  R2014     2
    e2_S4_1_1_visit[5]  R2030     -1
    e2_S4_1_1_visit[5]  R2031     -1
    e2_S4_1_1_visit[5]  R2032     1
    e2_S4_1_1_visit[5]  R2129     -25749
    e2_S4_1_1_visit[5]  R2130     71100
    e2_S4_1_1_visit[5]  R3158     -12
    e2_S4_1_1_visit[5]  R3422     1
    e2_S4_1_1_visit[6]  R2011     23
    e2_S4_1_1_visit[6]  R2012     2
    e2_S4_1_1_visit[6]  R2033     -1
    e2_S4_1_1_visit[6]  R2034     -1
    e2_S4_1_1_visit[6]  R2035     1
    e2_S4_1_1_visit[6]  R2046     -23
    e2_S4_1_1_visit[6]  R2047     -23
    e2_S4_1_1_visit[6]  R2048     -2
    e2_S4_1_1_visit[6]  R2049     -2
    e2_S4_1_1_visit[6]  R2051     -23
    e2_S4_1_1_visit[6]  R2052     -23
    e2_S4_1_1_visit[6]  R2053     -2
    e2_S4_1_1_visit[6]  R2054     -2
    e2_S4_1_1_visit[6]  R2056     -23
    e2_S4_1_1_visit[6]  R2057     -23
    e2_S4_1_1_visit[6]  R2058     -2
    e2_S4_1_1_visit[6]  R2059     -2
    e2_S4_1_1_visit[6]  R2061     -23
    e2_S4_1_1_visit[6]  R2062     -23
    e2_S4_1_1_visit[6]  R2063     -2
    e2_S4_1_1_visit[6]  R2064     -2
    e2_S4_1_1_visit[6]  R2066     -23
    e2_S4_1_1_visit[6]  R2067     -23
    e2_S4_1_1_visit[6]  R2068     -2
    e2_S4_1_1_visit[6]  R2069     -2
    e2_S4_1_1_visit[6]  R2071     -23
    e2_S4_1_1_visit[6]  R2072     -23
    e2_S4_1_1_visit[6]  R2073     -2
    e2_S4_1_1_visit[6]  R2074     -2
    e2_S4_1_1_visit[6]  R2076     -23
    e2_S4_1_1_visit[6]  R2077     -23
    e2_S4_1_1_visit[6]  R2078     -2
    e2_S4_1_1_visit[6]  R2079     -2
    e2_S4_1_1_visit[6]  R2081     -23
    e2_S4_1_1_visit[6]  R2082     -23
    e2_S4_1_1_visit[6]  R2083     -2
    e2_S4_1_1_visit[6]  R2084     -2
    e2_S4_1_1_visit[6]  R2086     -23
    e2_S4_1_1_visit[6]  R2087     -23
    e2_S4_1_1_visit[6]  R2088     -2
    e2_S4_1_1_visit[6]  R2089     -2
    e2_S4_1_1_visit[6]  R2091     -23
    e2_S4_1_1_visit[6]  R2092     -23
    e2_S4_1_1_visit[6]  R2093     -2
    e2_S4_1_1_visit[6]  R2094     -2
    e2_S4_1_1_visit[6]  R2114     -1
    e2_S4_1_1_visit[6]  R2116     23
    e2_S4_1_1_visit[6]  R2117     2
    e2_S4_1_1_visit[6]  R2131     1
    e2_S4_1_1_visit[6]  R3161     -12
    e2_S4_1_1_visit[6]  R3425     1
    e2_S4_1_1_visit[7]  R2013     4
    e2_S4_1_1_visit[7]  R2014     2
    e2_S4_1_1_visit[7]  R2036     -1
    e2_S4_1_1_visit[7]  R2037     -1
    e2_S4_1_1_visit[7]  R2038     1
    e2_S4_1_1_visit[7]  R2132     -23969
    e2_S4_1_1_visit[7]  R2133     71100
    e2_S4_1_1_visit[7]  R3164     -12
    e2_S4_1_1_visit[7]  R3426     1
    e2_S4_1_1_visit[8]  R2011     21
    e2_S4_1_1_visit[8]  R2012     2
    e2_S4_1_1_visit[8]  R2039     -1
    e2_S4_1_1_visit[8]  R2040     -1
    e2_S4_1_1_visit[8]  R2041     1
    e2_S4_1_1_visit[8]  R2046     -21
    e2_S4_1_1_visit[8]  R2047     -21
    e2_S4_1_1_visit[8]  R2048     -2
    e2_S4_1_1_visit[8]  R2049     -2
    e2_S4_1_1_visit[8]  R2051     -21
    e2_S4_1_1_visit[8]  R2052     -21
    e2_S4_1_1_visit[8]  R2053     -2
    e2_S4_1_1_visit[8]  R2054     -2
    e2_S4_1_1_visit[8]  R2056     -21
    e2_S4_1_1_visit[8]  R2057     -21
    e2_S4_1_1_visit[8]  R2058     -2
    e2_S4_1_1_visit[8]  R2059     -2
    e2_S4_1_1_visit[8]  R2061     -21
    e2_S4_1_1_visit[8]  R2062     -21
    e2_S4_1_1_visit[8]  R2063     -2
    e2_S4_1_1_visit[8]  R2064     -2
    e2_S4_1_1_visit[8]  R2066     -21
    e2_S4_1_1_visit[8]  R2067     -21
    e2_S4_1_1_visit[8]  R2068     -2
    e2_S4_1_1_visit[8]  R2069     -2
    e2_S4_1_1_visit[8]  R2071     -21
    e2_S4_1_1_visit[8]  R2072     -21
    e2_S4_1_1_visit[8]  R2073     -2
    e2_S4_1_1_visit[8]  R2074     -2
    e2_S4_1_1_visit[8]  R2076     -21
    e2_S4_1_1_visit[8]  R2077     -21
    e2_S4_1_1_visit[8]  R2078     -2
    e2_S4_1_1_visit[8]  R2079     -2
    e2_S4_1_1_visit[8]  R2081     -21
    e2_S4_1_1_visit[8]  R2082     -21
    e2_S4_1_1_visit[8]  R2083     -2
    e2_S4_1_1_visit[8]  R2084     -2
    e2_S4_1_1_visit[8]  R2086     -21
    e2_S4_1_1_visit[8]  R2087     -21
    e2_S4_1_1_visit[8]  R2088     -2
    e2_S4_1_1_visit[8]  R2089     -2
    e2_S4_1_1_visit[8]  R2091     -21
    e2_S4_1_1_visit[8]  R2092     -21
    e2_S4_1_1_visit[8]  R2093     -2
    e2_S4_1_1_visit[8]  R2094     -2
    e2_S4_1_1_visit[8]  R2118     -1
    e2_S4_1_1_visit[8]  R2120     21
    e2_S4_1_1_visit[8]  R2121     2
    e2_S4_1_1_visit[8]  R2134     1
    e2_S4_1_1_visit[8]  R3167     -12
    e2_S4_1_1_visit[8]  R3429     1
    e2_S4_1_1_visit[9]  R2013     4
    e2_S4_1_1_visit[9]  R2014     2
    e2_S4_1_1_visit[9]  R2042     -1
    e2_S4_1_1_visit[9]  R2043     -1
    e2_S4_1_1_visit[9]  R2044     1
    e2_S4_1_1_visit[9]  R2135     -11425
    e2_S4_1_1_visit[9]  R2136     71100
    e2_S4_1_1_visit[9]  R3170     -12
    e2_S4_1_1_visit[9]  R3430     1
    e2_S4_1_1_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_1_1_arc[-1,0]  R2009     1
    e2_S4_1_1_arc[-1,0]  R2015     1
    e2_S4_1_1_arc[-1,0]  R2045     -44319
    e2_S4_1_1_arc[-1,0]  R2046     -165
    e2_S4_1_1_arc[-1,0]  R2047     180
    e2_S4_1_1_arc[-1,0]  R2048     -5
    e2_S4_1_1_arc[-1,0]  R2049     6
    e2_S4_1_1_arc[-1,0]  R2137     -30
    e2_S4_1_1_arc[-1,0]  R3144     1
    e2_S4_1_1_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_1_1_arc[-1,1]  R2009     1
    e2_S4_1_1_arc[-1,1]  R2018     1
    e2_S4_1_1_arc[-1,1]  R2050     -41683
    e2_S4_1_1_arc[-1,1]  R2051     -180
    e2_S4_1_1_arc[-1,1]  R2052     178
    e2_S4_1_1_arc[-1,1]  R2053     -6
    e2_S4_1_1_arc[-1,1]  R2054     5
    e2_S4_1_1_arc[-1,1]  R2138     -30
    e2_S4_1_1_arc[-1,1]  R3147     1
    e2_S4_1_1_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_1_1_arc[-1,2]  R2009     1
    e2_S4_1_1_arc[-1,2]  R2021     1
    e2_S4_1_1_arc[-1,2]  R2055     -44289
    e2_S4_1_1_arc[-1,2]  R2056     -157
    e2_S4_1_1_arc[-1,2]  R2057     180
    e2_S4_1_1_arc[-1,2]  R2058     -4
    e2_S4_1_1_arc[-1,2]  R2059     6
    e2_S4_1_1_arc[-1,2]  R2139     -30
    e2_S4_1_1_arc[-1,2]  R3150     1
    e2_S4_1_1_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_1_1_arc[-1,3]  R2009     1
    e2_S4_1_1_arc[-1,3]  R2024     1
    e2_S4_1_1_arc[-1,3]  R2060     -40989
    e2_S4_1_1_arc[-1,3]  R2061     -180
    e2_S4_1_1_arc[-1,3]  R2062     176
    e2_S4_1_1_arc[-1,3]  R2063     -6
    e2_S4_1_1_arc[-1,3]  R2064     4
    e2_S4_1_1_arc[-1,3]  R2140     -30
    e2_S4_1_1_arc[-1,3]  R3153     1
    e2_S4_1_1_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_1_1_arc[-1,4]  R2009     1
    e2_S4_1_1_arc[-1,4]  R2027     1
    e2_S4_1_1_arc[-1,4]  R2065     -29919
    e2_S4_1_1_arc[-1,4]  R2066     -159
    e2_S4_1_1_arc[-1,4]  R2067     180
    e2_S4_1_1_arc[-1,4]  R2068     -4
    e2_S4_1_1_arc[-1,4]  R2069     6
    e2_S4_1_1_arc[-1,4]  R2141     -30
    e2_S4_1_1_arc[-1,4]  R3156     1
    e2_S4_1_1_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_1_1_arc[-1,5]  R2009     1
    e2_S4_1_1_arc[-1,5]  R2030     1
    e2_S4_1_1_arc[-1,5]  R2070     -26919
    e2_S4_1_1_arc[-1,5]  R2071     -180
    e2_S4_1_1_arc[-1,5]  R2072     176
    e2_S4_1_1_arc[-1,5]  R2073     -6
    e2_S4_1_1_arc[-1,5]  R2074     4
    e2_S4_1_1_arc[-1,5]  R2142     -30
    e2_S4_1_1_arc[-1,5]  R3159     1
    e2_S4_1_1_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_1_1_arc[-1,6]  R2009     1
    e2_S4_1_1_arc[-1,6]  R2033     1
    e2_S4_1_1_arc[-1,6]  R2075     -29851
    e2_S4_1_1_arc[-1,6]  R2076     -157
    e2_S4_1_1_arc[-1,6]  R2077     180
    e2_S4_1_1_arc[-1,6]  R2078     -4
    e2_S4_1_1_arc[-1,6]  R2079     6
    e2_S4_1_1_arc[-1,6]  R2143     -30
    e2_S4_1_1_arc[-1,6]  R3162     1
    e2_S4_1_1_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_1_1_arc[-1,7]  R2009     1
    e2_S4_1_1_arc[-1,7]  R2036     1
    e2_S4_1_1_arc[-1,7]  R2080     -25651
    e2_S4_1_1_arc[-1,7]  R2081     -180
    e2_S4_1_1_arc[-1,7]  R2082     176
    e2_S4_1_1_arc[-1,7]  R2083     -6
    e2_S4_1_1_arc[-1,7]  R2084     4
    e2_S4_1_1_arc[-1,7]  R2144     -30
    e2_S4_1_1_arc[-1,7]  R3165     1
    e2_S4_1_1_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_1_1_arc[-1,8]  R2009     1
    e2_S4_1_1_arc[-1,8]  R2039     1
    e2_S4_1_1_arc[-1,8]  R2085     -15519
    e2_S4_1_1_arc[-1,8]  R2086     -159
    e2_S4_1_1_arc[-1,8]  R2087     180
    e2_S4_1_1_arc[-1,8]  R2088     -4
    e2_S4_1_1_arc[-1,8]  R2089     6
    e2_S4_1_1_arc[-1,8]  R2145     -30
    e2_S4_1_1_arc[-1,8]  R3168     1
    e2_S4_1_1_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_1_1_arc[-1,9]  R2009     1
    e2_S4_1_1_arc[-1,9]  R2042     1
    e2_S4_1_1_arc[-1,9]  R2090     -13119
    e2_S4_1_1_arc[-1,9]  R2091     -180
    e2_S4_1_1_arc[-1,9]  R2092     176
    e2_S4_1_1_arc[-1,9]  R2093     -6
    e2_S4_1_1_arc[-1,9]  R2094     4
    e2_S4_1_1_arc[-1,9]  R2146     -30
    e2_S4_1_1_arc[-1,9]  R3171     1
    e2_S4_1_1_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_1_arc[0,-2]  R2010     1
    e2_S4_1_1_arc[0,-2]  R2016     1
    e2_S4_1_1_arc[0,-2]  R2095     -33523
    e2_S4_1_1_arc[0,-2]  R2147     -30
    e2_S4_1_1_arc[0,-2]  R3145     1
    e2_S4_1_1_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_1_arc[1,-2]  R2010     1
    e2_S4_1_1_arc[1,-2]  R2019     1
    e2_S4_1_1_arc[1,-2]  R2096     -39223
    e2_S4_1_1_arc[1,-2]  R2148     -30
    e2_S4_1_1_arc[1,-2]  R3148     1
    e2_S4_1_1_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_1_arc[2,-2]  R2010     1
    e2_S4_1_1_arc[2,-2]  R2022     1
    e2_S4_1_1_arc[2,-2]  R2097     -36369
    e2_S4_1_1_arc[2,-2]  R2149     -30
    e2_S4_1_1_arc[2,-2]  R3151     1
    e2_S4_1_1_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_1_arc[3,-2]  R2010     1
    e2_S4_1_1_arc[3,-2]  R2025     1
    e2_S4_1_1_arc[3,-2]  R2098     -42129
    e2_S4_1_1_arc[3,-2]  R2150     -30
    e2_S4_1_1_arc[3,-2]  R3154     1
    e2_S4_1_1_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_1_1_arc[4,-2]  R2010     1
    e2_S4_1_1_arc[4,-2]  R2028     1
    e2_S4_1_1_arc[4,-2]  R2099     -48315
    e2_S4_1_1_arc[4,-2]  R2151     -30
    e2_S4_1_1_arc[4,-2]  R3157     1
    e2_S4_1_1_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_1_1_arc[5,-2]  R2010     1
    e2_S4_1_1_arc[5,-2]  R2031     1
    e2_S4_1_1_arc[5,-2]  R2100     -53475
    e2_S4_1_1_arc[5,-2]  R2152     -30
    e2_S4_1_1_arc[5,-2]  R3160     1
    e2_S4_1_1_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_1_arc[6,-2]  R2010     1
    e2_S4_1_1_arc[6,-2]  R2034     1
    e2_S4_1_1_arc[6,-2]  R2101     -49531
    e2_S4_1_1_arc[6,-2]  R2153     -30
    e2_S4_1_1_arc[6,-2]  R3163     1
    e2_S4_1_1_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_1_arc[7,-2]  R2010     1
    e2_S4_1_1_arc[7,-2]  R2037     1
    e2_S4_1_1_arc[7,-2]  R2102     -56191
    e2_S4_1_1_arc[7,-2]  R2154     -30
    e2_S4_1_1_arc[7,-2]  R3166     1
    e2_S4_1_1_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_1_arc[8,-2]  R2010     1
    e2_S4_1_1_arc[8,-2]  R2040     1
    e2_S4_1_1_arc[8,-2]  R2103     -63217
    e2_S4_1_1_arc[8,-2]  R2155     -30
    e2_S4_1_1_arc[8,-2]  R3169     1
    e2_S4_1_1_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_1_arc[9,-2]  R2010     1
    e2_S4_1_1_arc[9,-2]  R2043     1
    e2_S4_1_1_arc[9,-2]  R2104     -68677
    e2_S4_1_1_arc[9,-2]  R2156     -30
    e2_S4_1_1_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C959      R2107     1
    C959      R2137     -1
    C959      R2138     -1
    C959      R2139     -1
    C959      R2140     -1
    C959      R2141     -1
    C959      R2142     -1
    C959      R2143     -1
    C959      R2144     -1
    C959      R2145     -1
    C959      R2146     -1
    C960      R2147     1
    C960      R2148     1
    C960      R2149     1
    C960      R2150     1
    C960      R2151     1
    C960      R2152     1
    C960      R2153     1
    C960      R2154     1
    C960      R2155     1
    C960      R2156     1
    C960      R2258     -1
    MARKER    'MARKER'                 'INTORG'
    C961      R2108     1
    C961      R2109     -60
    C961      R2110     1
    C961      R2111     -39660
    C961      R2112     -180
    C961      R2113     -6
    C961      R2122     -1
    C961      R2125     -1
    C962      R2108     1
    C962      R2109     -60
    C962      R2114     1
    C962      R2115     -54060
    C962      R2116     -180
    C962      R2117     -6
    C962      R2128     -1
    C962      R2131     -1
    C963      R2108     1
    C963      R2109     -60
    C963      R2118     1
    C963      R2119     -71160
    C963      R2120     -180
    C963      R2121     -6
    C963      R2134     -1
    e2_S4_1_2_used  R2157     -75600
    e2_S4_1_2_used  R2158     -75600
    e2_S4_1_2_used  R2159     -28800
    e2_S4_1_2_used  R2160     -1
    e2_S4_1_2_used  R2161     -1
    e2_S4_1_2_used  R2162     -180
    e2_S4_1_2_used  R2163     -6
    e2_S4_1_2_used  R2164     -180
    e2_S4_1_2_used  R2165     -6
    e2_S4_1_2_used  R2168     -1
    e2_S4_1_2_used  R2171     -1
    e2_S4_1_2_used  R2174     -1
    e2_S4_1_2_used  R2177     -1
    e2_S4_1_2_used  R2180     -1
    e2_S4_1_2_used  R2183     -1
    e2_S4_1_2_used  R2186     -1
    e2_S4_1_2_used  R2189     -1
    e2_S4_1_2_used  R2192     -1
    e2_S4_1_2_used  R2195     -1
    e2_S4_1_2_used  R2256     -75540
    e2_S4_1_2_used  R2257     1
    e2_S4_1_2_used  R2258     -30
    e2_S4_1_2_used  R2259     -1
    e2_S4_1_2_used  R2260     -75600
    e2_S4_1_2_used  R2408     -1
    e2_S4_1_2_used  R2610     1
    e2_S4_1_2_used  R3062     -1
    e2_S4_1_2_start  R2157     1
    e2_S4_1_2_start  R2159     1
    e2_S4_1_2_start  R2196     -1
    e2_S4_1_2_start  R2201     -1
    e2_S4_1_2_start  R2206     -1
    e2_S4_1_2_start  R2211     -1
    e2_S4_1_2_start  R2216     -1
    e2_S4_1_2_start  R2221     -1
    e2_S4_1_2_start  R2226     -1
    e2_S4_1_2_start  R2231     -1
    e2_S4_1_2_start  R2236     -1
    e2_S4_1_2_start  R2241     -1
    e2_S4_1_2_start  R2260     1
    e2_S4_1_2_start  R2262     1
    e2_S4_1_2_start  R2266     1
    e2_S4_1_2_start  R2270     1
    e2_S4_1_2_end  R2158     1
    e2_S4_1_2_end  R2246     1
    e2_S4_1_2_end  R2247     1
    e2_S4_1_2_end  R2248     1
    e2_S4_1_2_end  R2249     1
    e2_S4_1_2_end  R2250     1
    e2_S4_1_2_end  R2251     1
    e2_S4_1_2_end  R2252     1
    e2_S4_1_2_end  R2253     1
    e2_S4_1_2_end  R2254     1
    e2_S4_1_2_end  R2255     1
    e2_S4_1_2_end  R2256     1
    e2_S4_1_2_end  R2274     -1
    e2_S4_1_2_end  R2275     -1
    e2_S4_1_2_end  R2277     -1
    e2_S4_1_2_end  R2278     -1
    e2_S4_1_2_end  R2280     -1
    e2_S4_1_2_end  R2281     -1
    e2_S4_1_2_end  R2283     -1
    e2_S4_1_2_end  R2284     -1
    e2_S4_1_2_end  R2286     -1
    e2_S4_1_2_end  R2287     -1
    e2_S4_1_2_end  R2411     -1
    e2_S4_1_2_visit[0]  R2162     15
    e2_S4_1_2_visit[0]  R2163     1
    e2_S4_1_2_visit[0]  R2166     -1
    e2_S4_1_2_visit[0]  R2167     -1
    e2_S4_1_2_visit[0]  R2168     1
    e2_S4_1_2_visit[0]  R2197     -15
    e2_S4_1_2_visit[0]  R2198     -15
    e2_S4_1_2_visit[0]  R2199     -1
    e2_S4_1_2_visit[0]  R2200     -1
    e2_S4_1_2_visit[0]  R2202     -15
    e2_S4_1_2_visit[0]  R2203     -15
    e2_S4_1_2_visit[0]  R2204     -1
    e2_S4_1_2_visit[0]  R2205     -1
    e2_S4_1_2_visit[0]  R2207     -15
    e2_S4_1_2_visit[0]  R2208     -15
    e2_S4_1_2_visit[0]  R2209     -1
    e2_S4_1_2_visit[0]  R2210     -1
    e2_S4_1_2_visit[0]  R2212     -15
    e2_S4_1_2_visit[0]  R2213     -15
    e2_S4_1_2_visit[0]  R2214     -1
    e2_S4_1_2_visit[0]  R2215     -1
    e2_S4_1_2_visit[0]  R2217     -15
    e2_S4_1_2_visit[0]  R2218     -15
    e2_S4_1_2_visit[0]  R2219     -1
    e2_S4_1_2_visit[0]  R2220     -1
    e2_S4_1_2_visit[0]  R2222     -15
    e2_S4_1_2_visit[0]  R2223     -15
    e2_S4_1_2_visit[0]  R2224     -1
    e2_S4_1_2_visit[0]  R2225     -1
    e2_S4_1_2_visit[0]  R2227     -15
    e2_S4_1_2_visit[0]  R2228     -15
    e2_S4_1_2_visit[0]  R2229     -1
    e2_S4_1_2_visit[0]  R2230     -1
    e2_S4_1_2_visit[0]  R2232     -15
    e2_S4_1_2_visit[0]  R2233     -15
    e2_S4_1_2_visit[0]  R2234     -1
    e2_S4_1_2_visit[0]  R2235     -1
    e2_S4_1_2_visit[0]  R2237     -15
    e2_S4_1_2_visit[0]  R2238     -15
    e2_S4_1_2_visit[0]  R2239     -1
    e2_S4_1_2_visit[0]  R2240     -1
    e2_S4_1_2_visit[0]  R2242     -15
    e2_S4_1_2_visit[0]  R2243     -15
    e2_S4_1_2_visit[0]  R2244     -1
    e2_S4_1_2_visit[0]  R2245     -1
    e2_S4_1_2_visit[0]  R2261     -1
    e2_S4_1_2_visit[0]  R2263     15
    e2_S4_1_2_visit[0]  R2264     1
    e2_S4_1_2_visit[0]  R2273     1
    e2_S4_1_2_visit[0]  R3143     -13
    e2_S4_1_2_visit[0]  R3413     1
    e2_S4_1_2_visit[1]  R2164     2
    e2_S4_1_2_visit[1]  R2165     1
    e2_S4_1_2_visit[1]  R2169     -1
    e2_S4_1_2_visit[1]  R2170     -1
    e2_S4_1_2_visit[1]  R2171     1
    e2_S4_1_2_visit[1]  R2274     -40937
    e2_S4_1_2_visit[1]  R2275     71100
    e2_S4_1_2_visit[1]  R3146     -13
    e2_S4_1_2_visit[1]  R3414     1
    e2_S4_1_2_visit[2]  R2162     23
    e2_S4_1_2_visit[2]  R2163     2
    e2_S4_1_2_visit[2]  R2172     -1
    e2_S4_1_2_visit[2]  R2173     -1
    e2_S4_1_2_visit[2]  R2174     1
    e2_S4_1_2_visit[2]  R2197     -23
    e2_S4_1_2_visit[2]  R2198     -23
    e2_S4_1_2_visit[2]  R2199     -2
    e2_S4_1_2_visit[2]  R2200     -2
    e2_S4_1_2_visit[2]  R2202     -23
    e2_S4_1_2_visit[2]  R2203     -23
    e2_S4_1_2_visit[2]  R2204     -2
    e2_S4_1_2_visit[2]  R2205     -2
    e2_S4_1_2_visit[2]  R2207     -23
    e2_S4_1_2_visit[2]  R2208     -23
    e2_S4_1_2_visit[2]  R2209     -2
    e2_S4_1_2_visit[2]  R2210     -2
    e2_S4_1_2_visit[2]  R2212     -23
    e2_S4_1_2_visit[2]  R2213     -23
    e2_S4_1_2_visit[2]  R2214     -2
    e2_S4_1_2_visit[2]  R2215     -2
    e2_S4_1_2_visit[2]  R2217     -23
    e2_S4_1_2_visit[2]  R2218     -23
    e2_S4_1_2_visit[2]  R2219     -2
    e2_S4_1_2_visit[2]  R2220     -2
    e2_S4_1_2_visit[2]  R2222     -23
    e2_S4_1_2_visit[2]  R2223     -23
    e2_S4_1_2_visit[2]  R2224     -2
    e2_S4_1_2_visit[2]  R2225     -2
    e2_S4_1_2_visit[2]  R2227     -23
    e2_S4_1_2_visit[2]  R2228     -23
    e2_S4_1_2_visit[2]  R2229     -2
    e2_S4_1_2_visit[2]  R2230     -2
    e2_S4_1_2_visit[2]  R2232     -23
    e2_S4_1_2_visit[2]  R2233     -23
    e2_S4_1_2_visit[2]  R2234     -2
    e2_S4_1_2_visit[2]  R2235     -2
    e2_S4_1_2_visit[2]  R2237     -23
    e2_S4_1_2_visit[2]  R2238     -23
    e2_S4_1_2_visit[2]  R2239     -2
    e2_S4_1_2_visit[2]  R2240     -2
    e2_S4_1_2_visit[2]  R2242     -23
    e2_S4_1_2_visit[2]  R2243     -23
    e2_S4_1_2_visit[2]  R2244     -2
    e2_S4_1_2_visit[2]  R2245     -2
    e2_S4_1_2_visit[2]  R2261     -1
    e2_S4_1_2_visit[2]  R2263     23
    e2_S4_1_2_visit[2]  R2264     2
    e2_S4_1_2_visit[2]  R2276     1
    e2_S4_1_2_visit[2]  R3149     -13
    e2_S4_1_2_visit[2]  R3417     1
    e2_S4_1_2_visit[3]  R2164     4
    e2_S4_1_2_visit[3]  R2165     2
    e2_S4_1_2_visit[3]  R2175     -1
    e2_S4_1_2_visit[3]  R2176     -1
    e2_S4_1_2_visit[3]  R2177     1
    e2_S4_1_2_visit[3]  R2277     -38031
    e2_S4_1_2_visit[3]  R2278     71100
    e2_S4_1_2_visit[3]  R3152     -13
    e2_S4_1_2_visit[3]  R3418     1
    e2_S4_1_2_visit[4]  R2162     21
    e2_S4_1_2_visit[4]  R2163     2
    e2_S4_1_2_visit[4]  R2178     -1
    e2_S4_1_2_visit[4]  R2179     -1
    e2_S4_1_2_visit[4]  R2180     1
    e2_S4_1_2_visit[4]  R2197     -21
    e2_S4_1_2_visit[4]  R2198     -21
    e2_S4_1_2_visit[4]  R2199     -2
    e2_S4_1_2_visit[4]  R2200     -2
    e2_S4_1_2_visit[4]  R2202     -21
    e2_S4_1_2_visit[4]  R2203     -21
    e2_S4_1_2_visit[4]  R2204     -2
    e2_S4_1_2_visit[4]  R2205     -2
    e2_S4_1_2_visit[4]  R2207     -21
    e2_S4_1_2_visit[4]  R2208     -21
    e2_S4_1_2_visit[4]  R2209     -2
    e2_S4_1_2_visit[4]  R2210     -2
    e2_S4_1_2_visit[4]  R2212     -21
    e2_S4_1_2_visit[4]  R2213     -21
    e2_S4_1_2_visit[4]  R2214     -2
    e2_S4_1_2_visit[4]  R2215     -2
    e2_S4_1_2_visit[4]  R2217     -21
    e2_S4_1_2_visit[4]  R2218     -21
    e2_S4_1_2_visit[4]  R2219     -2
    e2_S4_1_2_visit[4]  R2220     -2
    e2_S4_1_2_visit[4]  R2222     -21
    e2_S4_1_2_visit[4]  R2223     -21
    e2_S4_1_2_visit[4]  R2224     -2
    e2_S4_1_2_visit[4]  R2225     -2
    e2_S4_1_2_visit[4]  R2227     -21
    e2_S4_1_2_visit[4]  R2228     -21
    e2_S4_1_2_visit[4]  R2229     -2
    e2_S4_1_2_visit[4]  R2230     -2
    e2_S4_1_2_visit[4]  R2232     -21
    e2_S4_1_2_visit[4]  R2233     -21
    e2_S4_1_2_visit[4]  R2234     -2
    e2_S4_1_2_visit[4]  R2235     -2
    e2_S4_1_2_visit[4]  R2237     -21
    e2_S4_1_2_visit[4]  R2238     -21
    e2_S4_1_2_visit[4]  R2239     -2
    e2_S4_1_2_visit[4]  R2240     -2
    e2_S4_1_2_visit[4]  R2242     -21
    e2_S4_1_2_visit[4]  R2243     -21
    e2_S4_1_2_visit[4]  R2244     -2
    e2_S4_1_2_visit[4]  R2245     -2
    e2_S4_1_2_visit[4]  R2265     -1
    e2_S4_1_2_visit[4]  R2267     21
    e2_S4_1_2_visit[4]  R2268     2
    e2_S4_1_2_visit[4]  R2279     1
    e2_S4_1_2_visit[4]  R3155     -13
    e2_S4_1_2_visit[4]  R3421     1
    e2_S4_1_2_visit[5]  R2164     4
    e2_S4_1_2_visit[5]  R2165     2
    e2_S4_1_2_visit[5]  R2181     -1
    e2_S4_1_2_visit[5]  R2182     -1
    e2_S4_1_2_visit[5]  R2183     1
    e2_S4_1_2_visit[5]  R2280     -25749
    e2_S4_1_2_visit[5]  R2281     71100
    e2_S4_1_2_visit[5]  R3158     -13
    e2_S4_1_2_visit[5]  R3422     1
    e2_S4_1_2_visit[6]  R2162     23
    e2_S4_1_2_visit[6]  R2163     2
    e2_S4_1_2_visit[6]  R2184     -1
    e2_S4_1_2_visit[6]  R2185     -1
    e2_S4_1_2_visit[6]  R2186     1
    e2_S4_1_2_visit[6]  R2197     -23
    e2_S4_1_2_visit[6]  R2198     -23
    e2_S4_1_2_visit[6]  R2199     -2
    e2_S4_1_2_visit[6]  R2200     -2
    e2_S4_1_2_visit[6]  R2202     -23
    e2_S4_1_2_visit[6]  R2203     -23
    e2_S4_1_2_visit[6]  R2204     -2
    e2_S4_1_2_visit[6]  R2205     -2
    e2_S4_1_2_visit[6]  R2207     -23
    e2_S4_1_2_visit[6]  R2208     -23
    e2_S4_1_2_visit[6]  R2209     -2
    e2_S4_1_2_visit[6]  R2210     -2
    e2_S4_1_2_visit[6]  R2212     -23
    e2_S4_1_2_visit[6]  R2213     -23
    e2_S4_1_2_visit[6]  R2214     -2
    e2_S4_1_2_visit[6]  R2215     -2
    e2_S4_1_2_visit[6]  R2217     -23
    e2_S4_1_2_visit[6]  R2218     -23
    e2_S4_1_2_visit[6]  R2219     -2
    e2_S4_1_2_visit[6]  R2220     -2
    e2_S4_1_2_visit[6]  R2222     -23
    e2_S4_1_2_visit[6]  R2223     -23
    e2_S4_1_2_visit[6]  R2224     -2
    e2_S4_1_2_visit[6]  R2225     -2
    e2_S4_1_2_visit[6]  R2227     -23
    e2_S4_1_2_visit[6]  R2228     -23
    e2_S4_1_2_visit[6]  R2229     -2
    e2_S4_1_2_visit[6]  R2230     -2
    e2_S4_1_2_visit[6]  R2232     -23
    e2_S4_1_2_visit[6]  R2233     -23
    e2_S4_1_2_visit[6]  R2234     -2
    e2_S4_1_2_visit[6]  R2235     -2
    e2_S4_1_2_visit[6]  R2237     -23
    e2_S4_1_2_visit[6]  R2238     -23
    e2_S4_1_2_visit[6]  R2239     -2
    e2_S4_1_2_visit[6]  R2240     -2
    e2_S4_1_2_visit[6]  R2242     -23
    e2_S4_1_2_visit[6]  R2243     -23
    e2_S4_1_2_visit[6]  R2244     -2
    e2_S4_1_2_visit[6]  R2245     -2
    e2_S4_1_2_visit[6]  R2265     -1
    e2_S4_1_2_visit[6]  R2267     23
    e2_S4_1_2_visit[6]  R2268     2
    e2_S4_1_2_visit[6]  R2282     1
    e2_S4_1_2_visit[6]  R3161     -13
    e2_S4_1_2_visit[6]  R3425     1
    e2_S4_1_2_visit[7]  R2164     4
    e2_S4_1_2_visit[7]  R2165     2
    e2_S4_1_2_visit[7]  R2187     -1
    e2_S4_1_2_visit[7]  R2188     -1
    e2_S4_1_2_visit[7]  R2189     1
    e2_S4_1_2_visit[7]  R2283     -23969
    e2_S4_1_2_visit[7]  R2284     71100
    e2_S4_1_2_visit[7]  R3164     -13
    e2_S4_1_2_visit[7]  R3426     1
    e2_S4_1_2_visit[8]  R2162     21
    e2_S4_1_2_visit[8]  R2163     2
    e2_S4_1_2_visit[8]  R2190     -1
    e2_S4_1_2_visit[8]  R2191     -1
    e2_S4_1_2_visit[8]  R2192     1
    e2_S4_1_2_visit[8]  R2197     -21
    e2_S4_1_2_visit[8]  R2198     -21
    e2_S4_1_2_visit[8]  R2199     -2
    e2_S4_1_2_visit[8]  R2200     -2
    e2_S4_1_2_visit[8]  R2202     -21
    e2_S4_1_2_visit[8]  R2203     -21
    e2_S4_1_2_visit[8]  R2204     -2
    e2_S4_1_2_visit[8]  R2205     -2
    e2_S4_1_2_visit[8]  R2207     -21
    e2_S4_1_2_visit[8]  R2208     -21
    e2_S4_1_2_visit[8]  R2209     -2
    e2_S4_1_2_visit[8]  R2210     -2
    e2_S4_1_2_visit[8]  R2212     -21
    e2_S4_1_2_visit[8]  R2213     -21
    e2_S4_1_2_visit[8]  R2214     -2
    e2_S4_1_2_visit[8]  R2215     -2
    e2_S4_1_2_visit[8]  R2217     -21
    e2_S4_1_2_visit[8]  R2218     -21
    e2_S4_1_2_visit[8]  R2219     -2
    e2_S4_1_2_visit[8]  R2220     -2
    e2_S4_1_2_visit[8]  R2222     -21
    e2_S4_1_2_visit[8]  R2223     -21
    e2_S4_1_2_visit[8]  R2224     -2
    e2_S4_1_2_visit[8]  R2225     -2
    e2_S4_1_2_visit[8]  R2227     -21
    e2_S4_1_2_visit[8]  R2228     -21
    e2_S4_1_2_visit[8]  R2229     -2
    e2_S4_1_2_visit[8]  R2230     -2
    e2_S4_1_2_visit[8]  R2232     -21
    e2_S4_1_2_visit[8]  R2233     -21
    e2_S4_1_2_visit[8]  R2234     -2
    e2_S4_1_2_visit[8]  R2235     -2
    e2_S4_1_2_visit[8]  R2237     -21
    e2_S4_1_2_visit[8]  R2238     -21
    e2_S4_1_2_visit[8]  R2239     -2
    e2_S4_1_2_visit[8]  R2240     -2
    e2_S4_1_2_visit[8]  R2242     -21
    e2_S4_1_2_visit[8]  R2243     -21
    e2_S4_1_2_visit[8]  R2244     -2
    e2_S4_1_2_visit[8]  R2245     -2
    e2_S4_1_2_visit[8]  R2269     -1
    e2_S4_1_2_visit[8]  R2271     21
    e2_S4_1_2_visit[8]  R2272     2
    e2_S4_1_2_visit[8]  R2285     1
    e2_S4_1_2_visit[8]  R3167     -13
    e2_S4_1_2_visit[8]  R3429     1
    e2_S4_1_2_visit[9]  R2164     4
    e2_S4_1_2_visit[9]  R2165     2
    e2_S4_1_2_visit[9]  R2193     -1
    e2_S4_1_2_visit[9]  R2194     -1
    e2_S4_1_2_visit[9]  R2195     1
    e2_S4_1_2_visit[9]  R2286     -11425
    e2_S4_1_2_visit[9]  R2287     71100
    e2_S4_1_2_visit[9]  R3170     -13
    e2_S4_1_2_visit[9]  R3430     1
    e2_S4_1_2_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_1_2_arc[-1,0]  R2160     1
    e2_S4_1_2_arc[-1,0]  R2166     1
    e2_S4_1_2_arc[-1,0]  R2196     -44319
    e2_S4_1_2_arc[-1,0]  R2197     -165
    e2_S4_1_2_arc[-1,0]  R2198     180
    e2_S4_1_2_arc[-1,0]  R2199     -5
    e2_S4_1_2_arc[-1,0]  R2200     6
    e2_S4_1_2_arc[-1,0]  R2288     -30
    e2_S4_1_2_arc[-1,0]  R3144     1
    e2_S4_1_2_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_1_2_arc[-1,1]  R2160     1
    e2_S4_1_2_arc[-1,1]  R2169     1
    e2_S4_1_2_arc[-1,1]  R2201     -41683
    e2_S4_1_2_arc[-1,1]  R2202     -180
    e2_S4_1_2_arc[-1,1]  R2203     178
    e2_S4_1_2_arc[-1,1]  R2204     -6
    e2_S4_1_2_arc[-1,1]  R2205     5
    e2_S4_1_2_arc[-1,1]  R2289     -30
    e2_S4_1_2_arc[-1,1]  R3147     1
    e2_S4_1_2_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_1_2_arc[-1,2]  R2160     1
    e2_S4_1_2_arc[-1,2]  R2172     1
    e2_S4_1_2_arc[-1,2]  R2206     -44289
    e2_S4_1_2_arc[-1,2]  R2207     -157
    e2_S4_1_2_arc[-1,2]  R2208     180
    e2_S4_1_2_arc[-1,2]  R2209     -4
    e2_S4_1_2_arc[-1,2]  R2210     6
    e2_S4_1_2_arc[-1,2]  R2290     -30
    e2_S4_1_2_arc[-1,2]  R3150     1
    e2_S4_1_2_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_1_2_arc[-1,3]  R2160     1
    e2_S4_1_2_arc[-1,3]  R2175     1
    e2_S4_1_2_arc[-1,3]  R2211     -40989
    e2_S4_1_2_arc[-1,3]  R2212     -180
    e2_S4_1_2_arc[-1,3]  R2213     176
    e2_S4_1_2_arc[-1,3]  R2214     -6
    e2_S4_1_2_arc[-1,3]  R2215     4
    e2_S4_1_2_arc[-1,3]  R2291     -30
    e2_S4_1_2_arc[-1,3]  R3153     1
    e2_S4_1_2_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_1_2_arc[-1,4]  R2160     1
    e2_S4_1_2_arc[-1,4]  R2178     1
    e2_S4_1_2_arc[-1,4]  R2216     -29919
    e2_S4_1_2_arc[-1,4]  R2217     -159
    e2_S4_1_2_arc[-1,4]  R2218     180
    e2_S4_1_2_arc[-1,4]  R2219     -4
    e2_S4_1_2_arc[-1,4]  R2220     6
    e2_S4_1_2_arc[-1,4]  R2292     -30
    e2_S4_1_2_arc[-1,4]  R3156     1
    e2_S4_1_2_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_1_2_arc[-1,5]  R2160     1
    e2_S4_1_2_arc[-1,5]  R2181     1
    e2_S4_1_2_arc[-1,5]  R2221     -26919
    e2_S4_1_2_arc[-1,5]  R2222     -180
    e2_S4_1_2_arc[-1,5]  R2223     176
    e2_S4_1_2_arc[-1,5]  R2224     -6
    e2_S4_1_2_arc[-1,5]  R2225     4
    e2_S4_1_2_arc[-1,5]  R2293     -30
    e2_S4_1_2_arc[-1,5]  R3159     1
    e2_S4_1_2_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_1_2_arc[-1,6]  R2160     1
    e2_S4_1_2_arc[-1,6]  R2184     1
    e2_S4_1_2_arc[-1,6]  R2226     -29851
    e2_S4_1_2_arc[-1,6]  R2227     -157
    e2_S4_1_2_arc[-1,6]  R2228     180
    e2_S4_1_2_arc[-1,6]  R2229     -4
    e2_S4_1_2_arc[-1,6]  R2230     6
    e2_S4_1_2_arc[-1,6]  R2294     -30
    e2_S4_1_2_arc[-1,6]  R3162     1
    e2_S4_1_2_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_1_2_arc[-1,7]  R2160     1
    e2_S4_1_2_arc[-1,7]  R2187     1
    e2_S4_1_2_arc[-1,7]  R2231     -25651
    e2_S4_1_2_arc[-1,7]  R2232     -180
    e2_S4_1_2_arc[-1,7]  R2233     176
    e2_S4_1_2_arc[-1,7]  R2234     -6
    e2_S4_1_2_arc[-1,7]  R2235     4
    e2_S4_1_2_arc[-1,7]  R2295     -30
    e2_S4_1_2_arc[-1,7]  R3165     1
    e2_S4_1_2_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_1_2_arc[-1,8]  R2160     1
    e2_S4_1_2_arc[-1,8]  R2190     1
    e2_S4_1_2_arc[-1,8]  R2236     -15519
    e2_S4_1_2_arc[-1,8]  R2237     -159
    e2_S4_1_2_arc[-1,8]  R2238     180
    e2_S4_1_2_arc[-1,8]  R2239     -4
    e2_S4_1_2_arc[-1,8]  R2240     6
    e2_S4_1_2_arc[-1,8]  R2296     -30
    e2_S4_1_2_arc[-1,8]  R3168     1
    e2_S4_1_2_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_1_2_arc[-1,9]  R2160     1
    e2_S4_1_2_arc[-1,9]  R2193     1
    e2_S4_1_2_arc[-1,9]  R2241     -13119
    e2_S4_1_2_arc[-1,9]  R2242     -180
    e2_S4_1_2_arc[-1,9]  R2243     176
    e2_S4_1_2_arc[-1,9]  R2244     -6
    e2_S4_1_2_arc[-1,9]  R2245     4
    e2_S4_1_2_arc[-1,9]  R2297     -30
    e2_S4_1_2_arc[-1,9]  R3171     1
    e2_S4_1_2_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_2_arc[0,-2]  R2161     1
    e2_S4_1_2_arc[0,-2]  R2167     1
    e2_S4_1_2_arc[0,-2]  R2246     -33523
    e2_S4_1_2_arc[0,-2]  R2298     -30
    e2_S4_1_2_arc[0,-2]  R3145     1
    e2_S4_1_2_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_2_arc[1,-2]  R2161     1
    e2_S4_1_2_arc[1,-2]  R2170     1
    e2_S4_1_2_arc[1,-2]  R2247     -39223
    e2_S4_1_2_arc[1,-2]  R2299     -30
    e2_S4_1_2_arc[1,-2]  R3148     1
    e2_S4_1_2_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_2_arc[2,-2]  R2161     1
    e2_S4_1_2_arc[2,-2]  R2173     1
    e2_S4_1_2_arc[2,-2]  R2248     -36369
    e2_S4_1_2_arc[2,-2]  R2300     -30
    e2_S4_1_2_arc[2,-2]  R3151     1
    e2_S4_1_2_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_2_arc[3,-2]  R2161     1
    e2_S4_1_2_arc[3,-2]  R2176     1
    e2_S4_1_2_arc[3,-2]  R2249     -42129
    e2_S4_1_2_arc[3,-2]  R2301     -30
    e2_S4_1_2_arc[3,-2]  R3154     1
    e2_S4_1_2_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_1_2_arc[4,-2]  R2161     1
    e2_S4_1_2_arc[4,-2]  R2179     1
    e2_S4_1_2_arc[4,-2]  R2250     -48315
    e2_S4_1_2_arc[4,-2]  R2302     -30
    e2_S4_1_2_arc[4,-2]  R3157     1
    e2_S4_1_2_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_1_2_arc[5,-2]  R2161     1
    e2_S4_1_2_arc[5,-2]  R2182     1
    e2_S4_1_2_arc[5,-2]  R2251     -53475
    e2_S4_1_2_arc[5,-2]  R2303     -30
    e2_S4_1_2_arc[5,-2]  R3160     1
    e2_S4_1_2_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_2_arc[6,-2]  R2161     1
    e2_S4_1_2_arc[6,-2]  R2185     1
    e2_S4_1_2_arc[6,-2]  R2252     -49531
    e2_S4_1_2_arc[6,-2]  R2304     -30
    e2_S4_1_2_arc[6,-2]  R3163     1
    e2_S4_1_2_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_2_arc[7,-2]  R2161     1
    e2_S4_1_2_arc[7,-2]  R2188     1
    e2_S4_1_2_arc[7,-2]  R2253     -56191
    e2_S4_1_2_arc[7,-2]  R2305     -30
    e2_S4_1_2_arc[7,-2]  R3166     1
    e2_S4_1_2_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_2_arc[8,-2]  R2161     1
    e2_S4_1_2_arc[8,-2]  R2191     1
    e2_S4_1_2_arc[8,-2]  R2254     -63217
    e2_S4_1_2_arc[8,-2]  R2306     -30
    e2_S4_1_2_arc[8,-2]  R3169     1
    e2_S4_1_2_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_2_arc[9,-2]  R2161     1
    e2_S4_1_2_arc[9,-2]  R2194     1
    e2_S4_1_2_arc[9,-2]  R2255     -68677
    e2_S4_1_2_arc[9,-2]  R2307     -30
    e2_S4_1_2_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C997      R2258     1
    C997      R2288     -1
    C997      R2289     -1
    C997      R2290     -1
    C997      R2291     -1
    C997      R2292     -1
    C997      R2293     -1
    C997      R2294     -1
    C997      R2295     -1
    C997      R2296     -1
    C997      R2297     -1
    C998      R2298     1
    C998      R2299     1
    C998      R2300     1
    C998      R2301     1
    C998      R2302     1
    C998      R2303     1
    C998      R2304     1
    C998      R2305     1
    C998      R2306     1
    C998      R2307     1
    C998      R2409     -1
    MARKER    'MARKER'                 'INTORG'
    C999      R2259     1
    C999      R2260     -60
    C999      R2261     1
    C999      R2262     -39660
    C999      R2263     -180
    C999      R2264     -6
    C999      R2273     -1
    C999      R2276     -1
    C1000     R2259     1
    C1000     R2260     -60
    C1000     R2265     1
    C1000     R2266     -54060
    C1000     R2267     -180
    C1000     R2268     -6
    C1000     R2279     -1
    C1000     R2282     -1
    C1001     R2259     1
    C1001     R2260     -60
    C1001     R2269     1
    C1001     R2270     -71160
    C1001     R2271     -180
    C1001     R2272     -6
    C1001     R2285     -1
    e2_S4_1_3_used  R2308     -75600
    e2_S4_1_3_used  R2309     -75600
    e2_S4_1_3_used  R2310     -28800
    e2_S4_1_3_used  R2311     -1
    e2_S4_1_3_used  R2312     -1
    e2_S4_1_3_used  R2313     -180
    e2_S4_1_3_used  R2314     -6
    e2_S4_1_3_used  R2315     -180
    e2_S4_1_3_used  R2316     -6
    e2_S4_1_3_used  R2319     -1
    e2_S4_1_3_used  R2322     -1
    e2_S4_1_3_used  R2325     -1
    e2_S4_1_3_used  R2328     -1
    e2_S4_1_3_used  R2331     -1
    e2_S4_1_3_used  R2334     -1
    e2_S4_1_3_used  R2337     -1
    e2_S4_1_3_used  R2340     -1
    e2_S4_1_3_used  R2343     -1
    e2_S4_1_3_used  R2346     -1
    e2_S4_1_3_used  R2407     -75540
    e2_S4_1_3_used  R2408     1
    e2_S4_1_3_used  R2409     -30
    e2_S4_1_3_used  R2410     -1
    e2_S4_1_3_used  R2411     -75600
    e2_S4_1_3_used  R2559     -1
    e2_S4_1_3_used  R2610     1
    e2_S4_1_3_used  R3062     -1
    e2_S4_1_3_start  R2308     1
    e2_S4_1_3_start  R2310     1
    e2_S4_1_3_start  R2347     -1
    e2_S4_1_3_start  R2352     -1
    e2_S4_1_3_start  R2357     -1
    e2_S4_1_3_start  R2362     -1
    e2_S4_1_3_start  R2367     -1
    e2_S4_1_3_start  R2372     -1
    e2_S4_1_3_start  R2377     -1
    e2_S4_1_3_start  R2382     -1
    e2_S4_1_3_start  R2387     -1
    e2_S4_1_3_start  R2392     -1
    e2_S4_1_3_start  R2411     1
    e2_S4_1_3_start  R2413     1
    e2_S4_1_3_start  R2417     1
    e2_S4_1_3_start  R2421     1
    e2_S4_1_3_end  R2309     1
    e2_S4_1_3_end  R2397     1
    e2_S4_1_3_end  R2398     1
    e2_S4_1_3_end  R2399     1
    e2_S4_1_3_end  R2400     1
    e2_S4_1_3_end  R2401     1
    e2_S4_1_3_end  R2402     1
    e2_S4_1_3_end  R2403     1
    e2_S4_1_3_end  R2404     1
    e2_S4_1_3_end  R2405     1
    e2_S4_1_3_end  R2406     1
    e2_S4_1_3_end  R2407     1
    e2_S4_1_3_end  R2425     -1
    e2_S4_1_3_end  R2426     -1
    e2_S4_1_3_end  R2428     -1
    e2_S4_1_3_end  R2429     -1
    e2_S4_1_3_end  R2431     -1
    e2_S4_1_3_end  R2432     -1
    e2_S4_1_3_end  R2434     -1
    e2_S4_1_3_end  R2435     -1
    e2_S4_1_3_end  R2437     -1
    e2_S4_1_3_end  R2438     -1
    e2_S4_1_3_end  R2562     -1
    e2_S4_1_3_visit[0]  R2313     15
    e2_S4_1_3_visit[0]  R2314     1
    e2_S4_1_3_visit[0]  R2317     -1
    e2_S4_1_3_visit[0]  R2318     -1
    e2_S4_1_3_visit[0]  R2319     1
    e2_S4_1_3_visit[0]  R2348     -15
    e2_S4_1_3_visit[0]  R2349     -15
    e2_S4_1_3_visit[0]  R2350     -1
    e2_S4_1_3_visit[0]  R2351     -1
    e2_S4_1_3_visit[0]  R2353     -15
    e2_S4_1_3_visit[0]  R2354     -15
    e2_S4_1_3_visit[0]  R2355     -1
    e2_S4_1_3_visit[0]  R2356     -1
    e2_S4_1_3_visit[0]  R2358     -15
    e2_S4_1_3_visit[0]  R2359     -15
    e2_S4_1_3_visit[0]  R2360     -1
    e2_S4_1_3_visit[0]  R2361     -1
    e2_S4_1_3_visit[0]  R2363     -15
    e2_S4_1_3_visit[0]  R2364     -15
    e2_S4_1_3_visit[0]  R2365     -1
    e2_S4_1_3_visit[0]  R2366     -1
    e2_S4_1_3_visit[0]  R2368     -15
    e2_S4_1_3_visit[0]  R2369     -15
    e2_S4_1_3_visit[0]  R2370     -1
    e2_S4_1_3_visit[0]  R2371     -1
    e2_S4_1_3_visit[0]  R2373     -15
    e2_S4_1_3_visit[0]  R2374     -15
    e2_S4_1_3_visit[0]  R2375     -1
    e2_S4_1_3_visit[0]  R2376     -1
    e2_S4_1_3_visit[0]  R2378     -15
    e2_S4_1_3_visit[0]  R2379     -15
    e2_S4_1_3_visit[0]  R2380     -1
    e2_S4_1_3_visit[0]  R2381     -1
    e2_S4_1_3_visit[0]  R2383     -15
    e2_S4_1_3_visit[0]  R2384     -15
    e2_S4_1_3_visit[0]  R2385     -1
    e2_S4_1_3_visit[0]  R2386     -1
    e2_S4_1_3_visit[0]  R2388     -15
    e2_S4_1_3_visit[0]  R2389     -15
    e2_S4_1_3_visit[0]  R2390     -1
    e2_S4_1_3_visit[0]  R2391     -1
    e2_S4_1_3_visit[0]  R2393     -15
    e2_S4_1_3_visit[0]  R2394     -15
    e2_S4_1_3_visit[0]  R2395     -1
    e2_S4_1_3_visit[0]  R2396     -1
    e2_S4_1_3_visit[0]  R2412     -1
    e2_S4_1_3_visit[0]  R2414     15
    e2_S4_1_3_visit[0]  R2415     1
    e2_S4_1_3_visit[0]  R2424     1
    e2_S4_1_3_visit[0]  R3143     -14
    e2_S4_1_3_visit[0]  R3413     1
    e2_S4_1_3_visit[1]  R2315     2
    e2_S4_1_3_visit[1]  R2316     1
    e2_S4_1_3_visit[1]  R2320     -1
    e2_S4_1_3_visit[1]  R2321     -1
    e2_S4_1_3_visit[1]  R2322     1
    e2_S4_1_3_visit[1]  R2425     -40937
    e2_S4_1_3_visit[1]  R2426     71100
    e2_S4_1_3_visit[1]  R3146     -14
    e2_S4_1_3_visit[1]  R3414     1
    e2_S4_1_3_visit[2]  R2313     23
    e2_S4_1_3_visit[2]  R2314     2
    e2_S4_1_3_visit[2]  R2323     -1
    e2_S4_1_3_visit[2]  R2324     -1
    e2_S4_1_3_visit[2]  R2325     1
    e2_S4_1_3_visit[2]  R2348     -23
    e2_S4_1_3_visit[2]  R2349     -23
    e2_S4_1_3_visit[2]  R2350     -2
    e2_S4_1_3_visit[2]  R2351     -2
    e2_S4_1_3_visit[2]  R2353     -23
    e2_S4_1_3_visit[2]  R2354     -23
    e2_S4_1_3_visit[2]  R2355     -2
    e2_S4_1_3_visit[2]  R2356     -2
    e2_S4_1_3_visit[2]  R2358     -23
    e2_S4_1_3_visit[2]  R2359     -23
    e2_S4_1_3_visit[2]  R2360     -2
    e2_S4_1_3_visit[2]  R2361     -2
    e2_S4_1_3_visit[2]  R2363     -23
    e2_S4_1_3_visit[2]  R2364     -23
    e2_S4_1_3_visit[2]  R2365     -2
    e2_S4_1_3_visit[2]  R2366     -2
    e2_S4_1_3_visit[2]  R2368     -23
    e2_S4_1_3_visit[2]  R2369     -23
    e2_S4_1_3_visit[2]  R2370     -2
    e2_S4_1_3_visit[2]  R2371     -2
    e2_S4_1_3_visit[2]  R2373     -23
    e2_S4_1_3_visit[2]  R2374     -23
    e2_S4_1_3_visit[2]  R2375     -2
    e2_S4_1_3_visit[2]  R2376     -2
    e2_S4_1_3_visit[2]  R2378     -23
    e2_S4_1_3_visit[2]  R2379     -23
    e2_S4_1_3_visit[2]  R2380     -2
    e2_S4_1_3_visit[2]  R2381     -2
    e2_S4_1_3_visit[2]  R2383     -23
    e2_S4_1_3_visit[2]  R2384     -23
    e2_S4_1_3_visit[2]  R2385     -2
    e2_S4_1_3_visit[2]  R2386     -2
    e2_S4_1_3_visit[2]  R2388     -23
    e2_S4_1_3_visit[2]  R2389     -23
    e2_S4_1_3_visit[2]  R2390     -2
    e2_S4_1_3_visit[2]  R2391     -2
    e2_S4_1_3_visit[2]  R2393     -23
    e2_S4_1_3_visit[2]  R2394     -23
    e2_S4_1_3_visit[2]  R2395     -2
    e2_S4_1_3_visit[2]  R2396     -2
    e2_S4_1_3_visit[2]  R2412     -1
    e2_S4_1_3_visit[2]  R2414     23
    e2_S4_1_3_visit[2]  R2415     2
    e2_S4_1_3_visit[2]  R2427     1
    e2_S4_1_3_visit[2]  R3149     -14
    e2_S4_1_3_visit[2]  R3417     1
    e2_S4_1_3_visit[3]  R2315     4
    e2_S4_1_3_visit[3]  R2316     2
    e2_S4_1_3_visit[3]  R2326     -1
    e2_S4_1_3_visit[3]  R2327     -1
    e2_S4_1_3_visit[3]  R2328     1
    e2_S4_1_3_visit[3]  R2428     -38031
    e2_S4_1_3_visit[3]  R2429     71100
    e2_S4_1_3_visit[3]  R3152     -14
    e2_S4_1_3_visit[3]  R3418     1
    e2_S4_1_3_visit[4]  R2313     21
    e2_S4_1_3_visit[4]  R2314     2
    e2_S4_1_3_visit[4]  R2329     -1
    e2_S4_1_3_visit[4]  R2330     -1
    e2_S4_1_3_visit[4]  R2331     1
    e2_S4_1_3_visit[4]  R2348     -21
    e2_S4_1_3_visit[4]  R2349     -21
    e2_S4_1_3_visit[4]  R2350     -2
    e2_S4_1_3_visit[4]  R2351     -2
    e2_S4_1_3_visit[4]  R2353     -21
    e2_S4_1_3_visit[4]  R2354     -21
    e2_S4_1_3_visit[4]  R2355     -2
    e2_S4_1_3_visit[4]  R2356     -2
    e2_S4_1_3_visit[4]  R2358     -21
    e2_S4_1_3_visit[4]  R2359     -21
    e2_S4_1_3_visit[4]  R2360     -2
    e2_S4_1_3_visit[4]  R2361     -2
    e2_S4_1_3_visit[4]  R2363     -21
    e2_S4_1_3_visit[4]  R2364     -21
    e2_S4_1_3_visit[4]  R2365     -2
    e2_S4_1_3_visit[4]  R2366     -2
    e2_S4_1_3_visit[4]  R2368     -21
    e2_S4_1_3_visit[4]  R2369     -21
    e2_S4_1_3_visit[4]  R2370     -2
    e2_S4_1_3_visit[4]  R2371     -2
    e2_S4_1_3_visit[4]  R2373     -21
    e2_S4_1_3_visit[4]  R2374     -21
    e2_S4_1_3_visit[4]  R2375     -2
    e2_S4_1_3_visit[4]  R2376     -2
    e2_S4_1_3_visit[4]  R2378     -21
    e2_S4_1_3_visit[4]  R2379     -21
    e2_S4_1_3_visit[4]  R2380     -2
    e2_S4_1_3_visit[4]  R2381     -2
    e2_S4_1_3_visit[4]  R2383     -21
    e2_S4_1_3_visit[4]  R2384     -21
    e2_S4_1_3_visit[4]  R2385     -2
    e2_S4_1_3_visit[4]  R2386     -2
    e2_S4_1_3_visit[4]  R2388     -21
    e2_S4_1_3_visit[4]  R2389     -21
    e2_S4_1_3_visit[4]  R2390     -2
    e2_S4_1_3_visit[4]  R2391     -2
    e2_S4_1_3_visit[4]  R2393     -21
    e2_S4_1_3_visit[4]  R2394     -21
    e2_S4_1_3_visit[4]  R2395     -2
    e2_S4_1_3_visit[4]  R2396     -2
    e2_S4_1_3_visit[4]  R2416     -1
    e2_S4_1_3_visit[4]  R2418     21
    e2_S4_1_3_visit[4]  R2419     2
    e2_S4_1_3_visit[4]  R2430     1
    e2_S4_1_3_visit[4]  R3155     -14
    e2_S4_1_3_visit[4]  R3421     1
    e2_S4_1_3_visit[5]  R2315     4
    e2_S4_1_3_visit[5]  R2316     2
    e2_S4_1_3_visit[5]  R2332     -1
    e2_S4_1_3_visit[5]  R2333     -1
    e2_S4_1_3_visit[5]  R2334     1
    e2_S4_1_3_visit[5]  R2431     -25749
    e2_S4_1_3_visit[5]  R2432     71100
    e2_S4_1_3_visit[5]  R3158     -14
    e2_S4_1_3_visit[5]  R3422     1
    e2_S4_1_3_visit[6]  R2313     23
    e2_S4_1_3_visit[6]  R2314     2
    e2_S4_1_3_visit[6]  R2335     -1
    e2_S4_1_3_visit[6]  R2336     -1
    e2_S4_1_3_visit[6]  R2337     1
    e2_S4_1_3_visit[6]  R2348     -23
    e2_S4_1_3_visit[6]  R2349     -23
    e2_S4_1_3_visit[6]  R2350     -2
    e2_S4_1_3_visit[6]  R2351     -2
    e2_S4_1_3_visit[6]  R2353     -23
    e2_S4_1_3_visit[6]  R2354     -23
    e2_S4_1_3_visit[6]  R2355     -2
    e2_S4_1_3_visit[6]  R2356     -2
    e2_S4_1_3_visit[6]  R2358     -23
    e2_S4_1_3_visit[6]  R2359     -23
    e2_S4_1_3_visit[6]  R2360     -2
    e2_S4_1_3_visit[6]  R2361     -2
    e2_S4_1_3_visit[6]  R2363     -23
    e2_S4_1_3_visit[6]  R2364     -23
    e2_S4_1_3_visit[6]  R2365     -2
    e2_S4_1_3_visit[6]  R2366     -2
    e2_S4_1_3_visit[6]  R2368     -23
    e2_S4_1_3_visit[6]  R2369     -23
    e2_S4_1_3_visit[6]  R2370     -2
    e2_S4_1_3_visit[6]  R2371     -2
    e2_S4_1_3_visit[6]  R2373     -23
    e2_S4_1_3_visit[6]  R2374     -23
    e2_S4_1_3_visit[6]  R2375     -2
    e2_S4_1_3_visit[6]  R2376     -2
    e2_S4_1_3_visit[6]  R2378     -23
    e2_S4_1_3_visit[6]  R2379     -23
    e2_S4_1_3_visit[6]  R2380     -2
    e2_S4_1_3_visit[6]  R2381     -2
    e2_S4_1_3_visit[6]  R2383     -23
    e2_S4_1_3_visit[6]  R2384     -23
    e2_S4_1_3_visit[6]  R2385     -2
    e2_S4_1_3_visit[6]  R2386     -2
    e2_S4_1_3_visit[6]  R2388     -23
    e2_S4_1_3_visit[6]  R2389     -23
    e2_S4_1_3_visit[6]  R2390     -2
    e2_S4_1_3_visit[6]  R2391     -2
    e2_S4_1_3_visit[6]  R2393     -23
    e2_S4_1_3_visit[6]  R2394     -23
    e2_S4_1_3_visit[6]  R2395     -2
    e2_S4_1_3_visit[6]  R2396     -2
    e2_S4_1_3_visit[6]  R2416     -1
    e2_S4_1_3_visit[6]  R2418     23
    e2_S4_1_3_visit[6]  R2419     2
    e2_S4_1_3_visit[6]  R2433     1
    e2_S4_1_3_visit[6]  R3161     -14
    e2_S4_1_3_visit[6]  R3425     1
    e2_S4_1_3_visit[7]  R2315     4
    e2_S4_1_3_visit[7]  R2316     2
    e2_S4_1_3_visit[7]  R2338     -1
    e2_S4_1_3_visit[7]  R2339     -1
    e2_S4_1_3_visit[7]  R2340     1
    e2_S4_1_3_visit[7]  R2434     -23969
    e2_S4_1_3_visit[7]  R2435     71100
    e2_S4_1_3_visit[7]  R3164     -14
    e2_S4_1_3_visit[7]  R3426     1
    e2_S4_1_3_visit[8]  R2313     21
    e2_S4_1_3_visit[8]  R2314     2
    e2_S4_1_3_visit[8]  R2341     -1
    e2_S4_1_3_visit[8]  R2342     -1
    e2_S4_1_3_visit[8]  R2343     1
    e2_S4_1_3_visit[8]  R2348     -21
    e2_S4_1_3_visit[8]  R2349     -21
    e2_S4_1_3_visit[8]  R2350     -2
    e2_S4_1_3_visit[8]  R2351     -2
    e2_S4_1_3_visit[8]  R2353     -21
    e2_S4_1_3_visit[8]  R2354     -21
    e2_S4_1_3_visit[8]  R2355     -2
    e2_S4_1_3_visit[8]  R2356     -2
    e2_S4_1_3_visit[8]  R2358     -21
    e2_S4_1_3_visit[8]  R2359     -21
    e2_S4_1_3_visit[8]  R2360     -2
    e2_S4_1_3_visit[8]  R2361     -2
    e2_S4_1_3_visit[8]  R2363     -21
    e2_S4_1_3_visit[8]  R2364     -21
    e2_S4_1_3_visit[8]  R2365     -2
    e2_S4_1_3_visit[8]  R2366     -2
    e2_S4_1_3_visit[8]  R2368     -21
    e2_S4_1_3_visit[8]  R2369     -21
    e2_S4_1_3_visit[8]  R2370     -2
    e2_S4_1_3_visit[8]  R2371     -2
    e2_S4_1_3_visit[8]  R2373     -21
    e2_S4_1_3_visit[8]  R2374     -21
    e2_S4_1_3_visit[8]  R2375     -2
    e2_S4_1_3_visit[8]  R2376     -2
    e2_S4_1_3_visit[8]  R2378     -21
    e2_S4_1_3_visit[8]  R2379     -21
    e2_S4_1_3_visit[8]  R2380     -2
    e2_S4_1_3_visit[8]  R2381     -2
    e2_S4_1_3_visit[8]  R2383     -21
    e2_S4_1_3_visit[8]  R2384     -21
    e2_S4_1_3_visit[8]  R2385     -2
    e2_S4_1_3_visit[8]  R2386     -2
    e2_S4_1_3_visit[8]  R2388     -21
    e2_S4_1_3_visit[8]  R2389     -21
    e2_S4_1_3_visit[8]  R2390     -2
    e2_S4_1_3_visit[8]  R2391     -2
    e2_S4_1_3_visit[8]  R2393     -21
    e2_S4_1_3_visit[8]  R2394     -21
    e2_S4_1_3_visit[8]  R2395     -2
    e2_S4_1_3_visit[8]  R2396     -2
    e2_S4_1_3_visit[8]  R2420     -1
    e2_S4_1_3_visit[8]  R2422     21
    e2_S4_1_3_visit[8]  R2423     2
    e2_S4_1_3_visit[8]  R2436     1
    e2_S4_1_3_visit[8]  R3167     -14
    e2_S4_1_3_visit[8]  R3429     1
    e2_S4_1_3_visit[9]  R2315     4
    e2_S4_1_3_visit[9]  R2316     2
    e2_S4_1_3_visit[9]  R2344     -1
    e2_S4_1_3_visit[9]  R2345     -1
    e2_S4_1_3_visit[9]  R2346     1
    e2_S4_1_3_visit[9]  R2437     -11425
    e2_S4_1_3_visit[9]  R2438     71100
    e2_S4_1_3_visit[9]  R3170     -14
    e2_S4_1_3_visit[9]  R3430     1
    e2_S4_1_3_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_1_3_arc[-1,0]  R2311     1
    e2_S4_1_3_arc[-1,0]  R2317     1
    e2_S4_1_3_arc[-1,0]  R2347     -44319
    e2_S4_1_3_arc[-1,0]  R2348     -165
    e2_S4_1_3_arc[-1,0]  R2349     180
    e2_S4_1_3_arc[-1,0]  R2350     -5
    e2_S4_1_3_arc[-1,0]  R2351     6
    e2_S4_1_3_arc[-1,0]  R2439     -30
    e2_S4_1_3_arc[-1,0]  R3144     1
    e2_S4_1_3_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_1_3_arc[-1,1]  R2311     1
    e2_S4_1_3_arc[-1,1]  R2320     1
    e2_S4_1_3_arc[-1,1]  R2352     -41683
    e2_S4_1_3_arc[-1,1]  R2353     -180
    e2_S4_1_3_arc[-1,1]  R2354     178
    e2_S4_1_3_arc[-1,1]  R2355     -6
    e2_S4_1_3_arc[-1,1]  R2356     5
    e2_S4_1_3_arc[-1,1]  R2440     -30
    e2_S4_1_3_arc[-1,1]  R3147     1
    e2_S4_1_3_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_1_3_arc[-1,2]  R2311     1
    e2_S4_1_3_arc[-1,2]  R2323     1
    e2_S4_1_3_arc[-1,2]  R2357     -44289
    e2_S4_1_3_arc[-1,2]  R2358     -157
    e2_S4_1_3_arc[-1,2]  R2359     180
    e2_S4_1_3_arc[-1,2]  R2360     -4
    e2_S4_1_3_arc[-1,2]  R2361     6
    e2_S4_1_3_arc[-1,2]  R2441     -30
    e2_S4_1_3_arc[-1,2]  R3150     1
    e2_S4_1_3_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_1_3_arc[-1,3]  R2311     1
    e2_S4_1_3_arc[-1,3]  R2326     1
    e2_S4_1_3_arc[-1,3]  R2362     -40989
    e2_S4_1_3_arc[-1,3]  R2363     -180
    e2_S4_1_3_arc[-1,3]  R2364     176
    e2_S4_1_3_arc[-1,3]  R2365     -6
    e2_S4_1_3_arc[-1,3]  R2366     4
    e2_S4_1_3_arc[-1,3]  R2442     -30
    e2_S4_1_3_arc[-1,3]  R3153     1
    e2_S4_1_3_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_1_3_arc[-1,4]  R2311     1
    e2_S4_1_3_arc[-1,4]  R2329     1
    e2_S4_1_3_arc[-1,4]  R2367     -29919
    e2_S4_1_3_arc[-1,4]  R2368     -159
    e2_S4_1_3_arc[-1,4]  R2369     180
    e2_S4_1_3_arc[-1,4]  R2370     -4
    e2_S4_1_3_arc[-1,4]  R2371     6
    e2_S4_1_3_arc[-1,4]  R2443     -30
    e2_S4_1_3_arc[-1,4]  R3156     1
    e2_S4_1_3_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_1_3_arc[-1,5]  R2311     1
    e2_S4_1_3_arc[-1,5]  R2332     1
    e2_S4_1_3_arc[-1,5]  R2372     -26919
    e2_S4_1_3_arc[-1,5]  R2373     -180
    e2_S4_1_3_arc[-1,5]  R2374     176
    e2_S4_1_3_arc[-1,5]  R2375     -6
    e2_S4_1_3_arc[-1,5]  R2376     4
    e2_S4_1_3_arc[-1,5]  R2444     -30
    e2_S4_1_3_arc[-1,5]  R3159     1
    e2_S4_1_3_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_1_3_arc[-1,6]  R2311     1
    e2_S4_1_3_arc[-1,6]  R2335     1
    e2_S4_1_3_arc[-1,6]  R2377     -29851
    e2_S4_1_3_arc[-1,6]  R2378     -157
    e2_S4_1_3_arc[-1,6]  R2379     180
    e2_S4_1_3_arc[-1,6]  R2380     -4
    e2_S4_1_3_arc[-1,6]  R2381     6
    e2_S4_1_3_arc[-1,6]  R2445     -30
    e2_S4_1_3_arc[-1,6]  R3162     1
    e2_S4_1_3_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_1_3_arc[-1,7]  R2311     1
    e2_S4_1_3_arc[-1,7]  R2338     1
    e2_S4_1_3_arc[-1,7]  R2382     -25651
    e2_S4_1_3_arc[-1,7]  R2383     -180
    e2_S4_1_3_arc[-1,7]  R2384     176
    e2_S4_1_3_arc[-1,7]  R2385     -6
    e2_S4_1_3_arc[-1,7]  R2386     4
    e2_S4_1_3_arc[-1,7]  R2446     -30
    e2_S4_1_3_arc[-1,7]  R3165     1
    e2_S4_1_3_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_1_3_arc[-1,8]  R2311     1
    e2_S4_1_3_arc[-1,8]  R2341     1
    e2_S4_1_3_arc[-1,8]  R2387     -15519
    e2_S4_1_3_arc[-1,8]  R2388     -159
    e2_S4_1_3_arc[-1,8]  R2389     180
    e2_S4_1_3_arc[-1,8]  R2390     -4
    e2_S4_1_3_arc[-1,8]  R2391     6
    e2_S4_1_3_arc[-1,8]  R2447     -30
    e2_S4_1_3_arc[-1,8]  R3168     1
    e2_S4_1_3_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_1_3_arc[-1,9]  R2311     1
    e2_S4_1_3_arc[-1,9]  R2344     1
    e2_S4_1_3_arc[-1,9]  R2392     -13119
    e2_S4_1_3_arc[-1,9]  R2393     -180
    e2_S4_1_3_arc[-1,9]  R2394     176
    e2_S4_1_3_arc[-1,9]  R2395     -6
    e2_S4_1_3_arc[-1,9]  R2396     4
    e2_S4_1_3_arc[-1,9]  R2448     -30
    e2_S4_1_3_arc[-1,9]  R3171     1
    e2_S4_1_3_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_3_arc[0,-2]  R2312     1
    e2_S4_1_3_arc[0,-2]  R2318     1
    e2_S4_1_3_arc[0,-2]  R2397     -33523
    e2_S4_1_3_arc[0,-2]  R2449     -30
    e2_S4_1_3_arc[0,-2]  R3145     1
    e2_S4_1_3_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_3_arc[1,-2]  R2312     1
    e2_S4_1_3_arc[1,-2]  R2321     1
    e2_S4_1_3_arc[1,-2]  R2398     -39223
    e2_S4_1_3_arc[1,-2]  R2450     -30
    e2_S4_1_3_arc[1,-2]  R3148     1
    e2_S4_1_3_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_3_arc[2,-2]  R2312     1
    e2_S4_1_3_arc[2,-2]  R2324     1
    e2_S4_1_3_arc[2,-2]  R2399     -36369
    e2_S4_1_3_arc[2,-2]  R2451     -30
    e2_S4_1_3_arc[2,-2]  R3151     1
    e2_S4_1_3_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_3_arc[3,-2]  R2312     1
    e2_S4_1_3_arc[3,-2]  R2327     1
    e2_S4_1_3_arc[3,-2]  R2400     -42129
    e2_S4_1_3_arc[3,-2]  R2452     -30
    e2_S4_1_3_arc[3,-2]  R3154     1
    e2_S4_1_3_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_1_3_arc[4,-2]  R2312     1
    e2_S4_1_3_arc[4,-2]  R2330     1
    e2_S4_1_3_arc[4,-2]  R2401     -48315
    e2_S4_1_3_arc[4,-2]  R2453     -30
    e2_S4_1_3_arc[4,-2]  R3157     1
    e2_S4_1_3_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_1_3_arc[5,-2]  R2312     1
    e2_S4_1_3_arc[5,-2]  R2333     1
    e2_S4_1_3_arc[5,-2]  R2402     -53475
    e2_S4_1_3_arc[5,-2]  R2454     -30
    e2_S4_1_3_arc[5,-2]  R3160     1
    e2_S4_1_3_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_3_arc[6,-2]  R2312     1
    e2_S4_1_3_arc[6,-2]  R2336     1
    e2_S4_1_3_arc[6,-2]  R2403     -49531
    e2_S4_1_3_arc[6,-2]  R2455     -30
    e2_S4_1_3_arc[6,-2]  R3163     1
    e2_S4_1_3_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_3_arc[7,-2]  R2312     1
    e2_S4_1_3_arc[7,-2]  R2339     1
    e2_S4_1_3_arc[7,-2]  R2404     -56191
    e2_S4_1_3_arc[7,-2]  R2456     -30
    e2_S4_1_3_arc[7,-2]  R3166     1
    e2_S4_1_3_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_3_arc[8,-2]  R2312     1
    e2_S4_1_3_arc[8,-2]  R2342     1
    e2_S4_1_3_arc[8,-2]  R2405     -63217
    e2_S4_1_3_arc[8,-2]  R2457     -30
    e2_S4_1_3_arc[8,-2]  R3169     1
    e2_S4_1_3_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_3_arc[9,-2]  R2312     1
    e2_S4_1_3_arc[9,-2]  R2345     1
    e2_S4_1_3_arc[9,-2]  R2406     -68677
    e2_S4_1_3_arc[9,-2]  R2458     -30
    e2_S4_1_3_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C1035     R2409     1
    C1035     R2439     -1
    C1035     R2440     -1
    C1035     R2441     -1
    C1035     R2442     -1
    C1035     R2443     -1
    C1035     R2444     -1
    C1035     R2445     -1
    C1035     R2446     -1
    C1035     R2447     -1
    C1035     R2448     -1
    C1036     R2449     1
    C1036     R2450     1
    C1036     R2451     1
    C1036     R2452     1
    C1036     R2453     1
    C1036     R2454     1
    C1036     R2455     1
    C1036     R2456     1
    C1036     R2457     1
    C1036     R2458     1
    C1036     R2560     -1
    MARKER    'MARKER'                 'INTORG'
    C1037     R2410     1
    C1037     R2411     -60
    C1037     R2412     1
    C1037     R2413     -39660
    C1037     R2414     -180
    C1037     R2415     -6
    C1037     R2424     -1
    C1037     R2427     -1
    C1038     R2410     1
    C1038     R2411     -60
    C1038     R2416     1
    C1038     R2417     -54060
    C1038     R2418     -180
    C1038     R2419     -6
    C1038     R2430     -1
    C1038     R2433     -1
    C1039     R2410     1
    C1039     R2411     -60
    C1039     R2420     1
    C1039     R2421     -71160
    C1039     R2422     -180
    C1039     R2423     -6
    C1039     R2436     -1
    e2_S4_1_4_used  R2459     -75600
    e2_S4_1_4_used  R2460     -75600
    e2_S4_1_4_used  R2461     -28800
    e2_S4_1_4_used  R2462     -1
    e2_S4_1_4_used  R2463     -1
    e2_S4_1_4_used  R2464     -180
    e2_S4_1_4_used  R2465     -6
    e2_S4_1_4_used  R2466     -180
    e2_S4_1_4_used  R2467     -6
    e2_S4_1_4_used  R2470     -1
    e2_S4_1_4_used  R2473     -1
    e2_S4_1_4_used  R2476     -1
    e2_S4_1_4_used  R2479     -1
    e2_S4_1_4_used  R2482     -1
    e2_S4_1_4_used  R2485     -1
    e2_S4_1_4_used  R2488     -1
    e2_S4_1_4_used  R2491     -1
    e2_S4_1_4_used  R2494     -1
    e2_S4_1_4_used  R2497     -1
    e2_S4_1_4_used  R2558     -75540
    e2_S4_1_4_used  R2559     1
    e2_S4_1_4_used  R2560     -30
    e2_S4_1_4_used  R2561     -1
    e2_S4_1_4_used  R2562     -75600
    e2_S4_1_4_used  R2610     1
    e2_S4_1_4_used  R3062     -1
    e2_S4_1_4_start  R2459     1
    e2_S4_1_4_start  R2461     1
    e2_S4_1_4_start  R2498     -1
    e2_S4_1_4_start  R2503     -1
    e2_S4_1_4_start  R2508     -1
    e2_S4_1_4_start  R2513     -1
    e2_S4_1_4_start  R2518     -1
    e2_S4_1_4_start  R2523     -1
    e2_S4_1_4_start  R2528     -1
    e2_S4_1_4_start  R2533     -1
    e2_S4_1_4_start  R2538     -1
    e2_S4_1_4_start  R2543     -1
    e2_S4_1_4_start  R2562     1
    e2_S4_1_4_start  R2564     1
    e2_S4_1_4_start  R2568     1
    e2_S4_1_4_start  R2572     1
    e2_S4_1_4_end  R2460     1
    e2_S4_1_4_end  R2548     1
    e2_S4_1_4_end  R2549     1
    e2_S4_1_4_end  R2550     1
    e2_S4_1_4_end  R2551     1
    e2_S4_1_4_end  R2552     1
    e2_S4_1_4_end  R2553     1
    e2_S4_1_4_end  R2554     1
    e2_S4_1_4_end  R2555     1
    e2_S4_1_4_end  R2556     1
    e2_S4_1_4_end  R2557     1
    e2_S4_1_4_end  R2558     1
    e2_S4_1_4_end  R2576     -1
    e2_S4_1_4_end  R2577     -1
    e2_S4_1_4_end  R2579     -1
    e2_S4_1_4_end  R2580     -1
    e2_S4_1_4_end  R2582     -1
    e2_S4_1_4_end  R2583     -1
    e2_S4_1_4_end  R2585     -1
    e2_S4_1_4_end  R2586     -1
    e2_S4_1_4_end  R2588     -1
    e2_S4_1_4_end  R2589     -1
    e2_S4_1_4_visit[0]  R2464     15
    e2_S4_1_4_visit[0]  R2465     1
    e2_S4_1_4_visit[0]  R2468     -1
    e2_S4_1_4_visit[0]  R2469     -1
    e2_S4_1_4_visit[0]  R2470     1
    e2_S4_1_4_visit[0]  R2499     -15
    e2_S4_1_4_visit[0]  R2500     -15
    e2_S4_1_4_visit[0]  R2501     -1
    e2_S4_1_4_visit[0]  R2502     -1
    e2_S4_1_4_visit[0]  R2504     -15
    e2_S4_1_4_visit[0]  R2505     -15
    e2_S4_1_4_visit[0]  R2506     -1
    e2_S4_1_4_visit[0]  R2507     -1
    e2_S4_1_4_visit[0]  R2509     -15
    e2_S4_1_4_visit[0]  R2510     -15
    e2_S4_1_4_visit[0]  R2511     -1
    e2_S4_1_4_visit[0]  R2512     -1
    e2_S4_1_4_visit[0]  R2514     -15
    e2_S4_1_4_visit[0]  R2515     -15
    e2_S4_1_4_visit[0]  R2516     -1
    e2_S4_1_4_visit[0]  R2517     -1
    e2_S4_1_4_visit[0]  R2519     -15
    e2_S4_1_4_visit[0]  R2520     -15
    e2_S4_1_4_visit[0]  R2521     -1
    e2_S4_1_4_visit[0]  R2522     -1
    e2_S4_1_4_visit[0]  R2524     -15
    e2_S4_1_4_visit[0]  R2525     -15
    e2_S4_1_4_visit[0]  R2526     -1
    e2_S4_1_4_visit[0]  R2527     -1
    e2_S4_1_4_visit[0]  R2529     -15
    e2_S4_1_4_visit[0]  R2530     -15
    e2_S4_1_4_visit[0]  R2531     -1
    e2_S4_1_4_visit[0]  R2532     -1
    e2_S4_1_4_visit[0]  R2534     -15
    e2_S4_1_4_visit[0]  R2535     -15
    e2_S4_1_4_visit[0]  R2536     -1
    e2_S4_1_4_visit[0]  R2537     -1
    e2_S4_1_4_visit[0]  R2539     -15
    e2_S4_1_4_visit[0]  R2540     -15
    e2_S4_1_4_visit[0]  R2541     -1
    e2_S4_1_4_visit[0]  R2542     -1
    e2_S4_1_4_visit[0]  R2544     -15
    e2_S4_1_4_visit[0]  R2545     -15
    e2_S4_1_4_visit[0]  R2546     -1
    e2_S4_1_4_visit[0]  R2547     -1
    e2_S4_1_4_visit[0]  R2563     -1
    e2_S4_1_4_visit[0]  R2565     15
    e2_S4_1_4_visit[0]  R2566     1
    e2_S4_1_4_visit[0]  R2575     1
    e2_S4_1_4_visit[0]  R3143     -15
    e2_S4_1_4_visit[0]  R3413     1
    e2_S4_1_4_visit[1]  R2466     2
    e2_S4_1_4_visit[1]  R2467     1
    e2_S4_1_4_visit[1]  R2471     -1
    e2_S4_1_4_visit[1]  R2472     -1
    e2_S4_1_4_visit[1]  R2473     1
    e2_S4_1_4_visit[1]  R2576     -40937
    e2_S4_1_4_visit[1]  R2577     71100
    e2_S4_1_4_visit[1]  R3146     -15
    e2_S4_1_4_visit[1]  R3414     1
    e2_S4_1_4_visit[2]  R2464     23
    e2_S4_1_4_visit[2]  R2465     2
    e2_S4_1_4_visit[2]  R2474     -1
    e2_S4_1_4_visit[2]  R2475     -1
    e2_S4_1_4_visit[2]  R2476     1
    e2_S4_1_4_visit[2]  R2499     -23
    e2_S4_1_4_visit[2]  R2500     -23
    e2_S4_1_4_visit[2]  R2501     -2
    e2_S4_1_4_visit[2]  R2502     -2
    e2_S4_1_4_visit[2]  R2504     -23
    e2_S4_1_4_visit[2]  R2505     -23
    e2_S4_1_4_visit[2]  R2506     -2
    e2_S4_1_4_visit[2]  R2507     -2
    e2_S4_1_4_visit[2]  R2509     -23
    e2_S4_1_4_visit[2]  R2510     -23
    e2_S4_1_4_visit[2]  R2511     -2
    e2_S4_1_4_visit[2]  R2512     -2
    e2_S4_1_4_visit[2]  R2514     -23
    e2_S4_1_4_visit[2]  R2515     -23
    e2_S4_1_4_visit[2]  R2516     -2
    e2_S4_1_4_visit[2]  R2517     -2
    e2_S4_1_4_visit[2]  R2519     -23
    e2_S4_1_4_visit[2]  R2520     -23
    e2_S4_1_4_visit[2]  R2521     -2
    e2_S4_1_4_visit[2]  R2522     -2
    e2_S4_1_4_visit[2]  R2524     -23
    e2_S4_1_4_visit[2]  R2525     -23
    e2_S4_1_4_visit[2]  R2526     -2
    e2_S4_1_4_visit[2]  R2527     -2
    e2_S4_1_4_visit[2]  R2529     -23
    e2_S4_1_4_visit[2]  R2530     -23
    e2_S4_1_4_visit[2]  R2531     -2
    e2_S4_1_4_visit[2]  R2532     -2
    e2_S4_1_4_visit[2]  R2534     -23
    e2_S4_1_4_visit[2]  R2535     -23
    e2_S4_1_4_visit[2]  R2536     -2
    e2_S4_1_4_visit[2]  R2537     -2
    e2_S4_1_4_visit[2]  R2539     -23
    e2_S4_1_4_visit[2]  R2540     -23
    e2_S4_1_4_visit[2]  R2541     -2
    e2_S4_1_4_visit[2]  R2542     -2
    e2_S4_1_4_visit[2]  R2544     -23
    e2_S4_1_4_visit[2]  R2545     -23
    e2_S4_1_4_visit[2]  R2546     -2
    e2_S4_1_4_visit[2]  R2547     -2
    e2_S4_1_4_visit[2]  R2563     -1
    e2_S4_1_4_visit[2]  R2565     23
    e2_S4_1_4_visit[2]  R2566     2
    e2_S4_1_4_visit[2]  R2578     1
    e2_S4_1_4_visit[2]  R3149     -15
    e2_S4_1_4_visit[2]  R3417     1
    e2_S4_1_4_visit[3]  R2466     4
    e2_S4_1_4_visit[3]  R2467     2
    e2_S4_1_4_visit[3]  R2477     -1
    e2_S4_1_4_visit[3]  R2478     -1
    e2_S4_1_4_visit[3]  R2479     1
    e2_S4_1_4_visit[3]  R2579     -38031
    e2_S4_1_4_visit[3]  R2580     71100
    e2_S4_1_4_visit[3]  R3152     -15
    e2_S4_1_4_visit[3]  R3418     1
    e2_S4_1_4_visit[4]  R2464     21
    e2_S4_1_4_visit[4]  R2465     2
    e2_S4_1_4_visit[4]  R2480     -1
    e2_S4_1_4_visit[4]  R2481     -1
    e2_S4_1_4_visit[4]  R2482     1
    e2_S4_1_4_visit[4]  R2499     -21
    e2_S4_1_4_visit[4]  R2500     -21
    e2_S4_1_4_visit[4]  R2501     -2
    e2_S4_1_4_visit[4]  R2502     -2
    e2_S4_1_4_visit[4]  R2504     -21
    e2_S4_1_4_visit[4]  R2505     -21
    e2_S4_1_4_visit[4]  R2506     -2
    e2_S4_1_4_visit[4]  R2507     -2
    e2_S4_1_4_visit[4]  R2509     -21
    e2_S4_1_4_visit[4]  R2510     -21
    e2_S4_1_4_visit[4]  R2511     -2
    e2_S4_1_4_visit[4]  R2512     -2
    e2_S4_1_4_visit[4]  R2514     -21
    e2_S4_1_4_visit[4]  R2515     -21
    e2_S4_1_4_visit[4]  R2516     -2
    e2_S4_1_4_visit[4]  R2517     -2
    e2_S4_1_4_visit[4]  R2519     -21
    e2_S4_1_4_visit[4]  R2520     -21
    e2_S4_1_4_visit[4]  R2521     -2
    e2_S4_1_4_visit[4]  R2522     -2
    e2_S4_1_4_visit[4]  R2524     -21
    e2_S4_1_4_visit[4]  R2525     -21
    e2_S4_1_4_visit[4]  R2526     -2
    e2_S4_1_4_visit[4]  R2527     -2
    e2_S4_1_4_visit[4]  R2529     -21
    e2_S4_1_4_visit[4]  R2530     -21
    e2_S4_1_4_visit[4]  R2531     -2
    e2_S4_1_4_visit[4]  R2532     -2
    e2_S4_1_4_visit[4]  R2534     -21
    e2_S4_1_4_visit[4]  R2535     -21
    e2_S4_1_4_visit[4]  R2536     -2
    e2_S4_1_4_visit[4]  R2537     -2
    e2_S4_1_4_visit[4]  R2539     -21
    e2_S4_1_4_visit[4]  R2540     -21
    e2_S4_1_4_visit[4]  R2541     -2
    e2_S4_1_4_visit[4]  R2542     -2
    e2_S4_1_4_visit[4]  R2544     -21
    e2_S4_1_4_visit[4]  R2545     -21
    e2_S4_1_4_visit[4]  R2546     -2
    e2_S4_1_4_visit[4]  R2547     -2
    e2_S4_1_4_visit[4]  R2567     -1
    e2_S4_1_4_visit[4]  R2569     21
    e2_S4_1_4_visit[4]  R2570     2
    e2_S4_1_4_visit[4]  R2581     1
    e2_S4_1_4_visit[4]  R3155     -15
    e2_S4_1_4_visit[4]  R3421     1
    e2_S4_1_4_visit[5]  R2466     4
    e2_S4_1_4_visit[5]  R2467     2
    e2_S4_1_4_visit[5]  R2483     -1
    e2_S4_1_4_visit[5]  R2484     -1
    e2_S4_1_4_visit[5]  R2485     1
    e2_S4_1_4_visit[5]  R2582     -25749
    e2_S4_1_4_visit[5]  R2583     71100
    e2_S4_1_4_visit[5]  R3158     -15
    e2_S4_1_4_visit[5]  R3422     1
    e2_S4_1_4_visit[6]  R2464     23
    e2_S4_1_4_visit[6]  R2465     2
    e2_S4_1_4_visit[6]  R2486     -1
    e2_S4_1_4_visit[6]  R2487     -1
    e2_S4_1_4_visit[6]  R2488     1
    e2_S4_1_4_visit[6]  R2499     -23
    e2_S4_1_4_visit[6]  R2500     -23
    e2_S4_1_4_visit[6]  R2501     -2
    e2_S4_1_4_visit[6]  R2502     -2
    e2_S4_1_4_visit[6]  R2504     -23
    e2_S4_1_4_visit[6]  R2505     -23
    e2_S4_1_4_visit[6]  R2506     -2
    e2_S4_1_4_visit[6]  R2507     -2
    e2_S4_1_4_visit[6]  R2509     -23
    e2_S4_1_4_visit[6]  R2510     -23
    e2_S4_1_4_visit[6]  R2511     -2
    e2_S4_1_4_visit[6]  R2512     -2
    e2_S4_1_4_visit[6]  R2514     -23
    e2_S4_1_4_visit[6]  R2515     -23
    e2_S4_1_4_visit[6]  R2516     -2
    e2_S4_1_4_visit[6]  R2517     -2
    e2_S4_1_4_visit[6]  R2519     -23
    e2_S4_1_4_visit[6]  R2520     -23
    e2_S4_1_4_visit[6]  R2521     -2
    e2_S4_1_4_visit[6]  R2522     -2
    e2_S4_1_4_visit[6]  R2524     -23
    e2_S4_1_4_visit[6]  R2525     -23
    e2_S4_1_4_visit[6]  R2526     -2
    e2_S4_1_4_visit[6]  R2527     -2
    e2_S4_1_4_visit[6]  R2529     -23
    e2_S4_1_4_visit[6]  R2530     -23
    e2_S4_1_4_visit[6]  R2531     -2
    e2_S4_1_4_visit[6]  R2532     -2
    e2_S4_1_4_visit[6]  R2534     -23
    e2_S4_1_4_visit[6]  R2535     -23
    e2_S4_1_4_visit[6]  R2536     -2
    e2_S4_1_4_visit[6]  R2537     -2
    e2_S4_1_4_visit[6]  R2539     -23
    e2_S4_1_4_visit[6]  R2540     -23
    e2_S4_1_4_visit[6]  R2541     -2
    e2_S4_1_4_visit[6]  R2542     -2
    e2_S4_1_4_visit[6]  R2544     -23
    e2_S4_1_4_visit[6]  R2545     -23
    e2_S4_1_4_visit[6]  R2546     -2
    e2_S4_1_4_visit[6]  R2547     -2
    e2_S4_1_4_visit[6]  R2567     -1
    e2_S4_1_4_visit[6]  R2569     23
    e2_S4_1_4_visit[6]  R2570     2
    e2_S4_1_4_visit[6]  R2584     1
    e2_S4_1_4_visit[6]  R3161     -15
    e2_S4_1_4_visit[6]  R3425     1
    e2_S4_1_4_visit[7]  R2466     4
    e2_S4_1_4_visit[7]  R2467     2
    e2_S4_1_4_visit[7]  R2489     -1
    e2_S4_1_4_visit[7]  R2490     -1
    e2_S4_1_4_visit[7]  R2491     1
    e2_S4_1_4_visit[7]  R2585     -23969
    e2_S4_1_4_visit[7]  R2586     71100
    e2_S4_1_4_visit[7]  R3164     -15
    e2_S4_1_4_visit[7]  R3426     1
    e2_S4_1_4_visit[8]  R2464     21
    e2_S4_1_4_visit[8]  R2465     2
    e2_S4_1_4_visit[8]  R2492     -1
    e2_S4_1_4_visit[8]  R2493     -1
    e2_S4_1_4_visit[8]  R2494     1
    e2_S4_1_4_visit[8]  R2499     -21
    e2_S4_1_4_visit[8]  R2500     -21
    e2_S4_1_4_visit[8]  R2501     -2
    e2_S4_1_4_visit[8]  R2502     -2
    e2_S4_1_4_visit[8]  R2504     -21
    e2_S4_1_4_visit[8]  R2505     -21
    e2_S4_1_4_visit[8]  R2506     -2
    e2_S4_1_4_visit[8]  R2507     -2
    e2_S4_1_4_visit[8]  R2509     -21
    e2_S4_1_4_visit[8]  R2510     -21
    e2_S4_1_4_visit[8]  R2511     -2
    e2_S4_1_4_visit[8]  R2512     -2
    e2_S4_1_4_visit[8]  R2514     -21
    e2_S4_1_4_visit[8]  R2515     -21
    e2_S4_1_4_visit[8]  R2516     -2
    e2_S4_1_4_visit[8]  R2517     -2
    e2_S4_1_4_visit[8]  R2519     -21
    e2_S4_1_4_visit[8]  R2520     -21
    e2_S4_1_4_visit[8]  R2521     -2
    e2_S4_1_4_visit[8]  R2522     -2
    e2_S4_1_4_visit[8]  R2524     -21
    e2_S4_1_4_visit[8]  R2525     -21
    e2_S4_1_4_visit[8]  R2526     -2
    e2_S4_1_4_visit[8]  R2527     -2
    e2_S4_1_4_visit[8]  R2529     -21
    e2_S4_1_4_visit[8]  R2530     -21
    e2_S4_1_4_visit[8]  R2531     -2
    e2_S4_1_4_visit[8]  R2532     -2
    e2_S4_1_4_visit[8]  R2534     -21
    e2_S4_1_4_visit[8]  R2535     -21
    e2_S4_1_4_visit[8]  R2536     -2
    e2_S4_1_4_visit[8]  R2537     -2
    e2_S4_1_4_visit[8]  R2539     -21
    e2_S4_1_4_visit[8]  R2540     -21
    e2_S4_1_4_visit[8]  R2541     -2
    e2_S4_1_4_visit[8]  R2542     -2
    e2_S4_1_4_visit[8]  R2544     -21
    e2_S4_1_4_visit[8]  R2545     -21
    e2_S4_1_4_visit[8]  R2546     -2
    e2_S4_1_4_visit[8]  R2547     -2
    e2_S4_1_4_visit[8]  R2571     -1
    e2_S4_1_4_visit[8]  R2573     21
    e2_S4_1_4_visit[8]  R2574     2
    e2_S4_1_4_visit[8]  R2587     1
    e2_S4_1_4_visit[8]  R3167     -15
    e2_S4_1_4_visit[8]  R3429     1
    e2_S4_1_4_visit[9]  R2466     4
    e2_S4_1_4_visit[9]  R2467     2
    e2_S4_1_4_visit[9]  R2495     -1
    e2_S4_1_4_visit[9]  R2496     -1
    e2_S4_1_4_visit[9]  R2497     1
    e2_S4_1_4_visit[9]  R2588     -11425
    e2_S4_1_4_visit[9]  R2589     71100
    e2_S4_1_4_visit[9]  R3170     -15
    e2_S4_1_4_visit[9]  R3430     1
    e2_S4_1_4_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_1_4_arc[-1,0]  R2462     1
    e2_S4_1_4_arc[-1,0]  R2468     1
    e2_S4_1_4_arc[-1,0]  R2498     -44319
    e2_S4_1_4_arc[-1,0]  R2499     -165
    e2_S4_1_4_arc[-1,0]  R2500     180
    e2_S4_1_4_arc[-1,0]  R2501     -5
    e2_S4_1_4_arc[-1,0]  R2502     6
    e2_S4_1_4_arc[-1,0]  R2590     -30
    e2_S4_1_4_arc[-1,0]  R3144     1
    e2_S4_1_4_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_1_4_arc[-1,1]  R2462     1
    e2_S4_1_4_arc[-1,1]  R2471     1
    e2_S4_1_4_arc[-1,1]  R2503     -41683
    e2_S4_1_4_arc[-1,1]  R2504     -180
    e2_S4_1_4_arc[-1,1]  R2505     178
    e2_S4_1_4_arc[-1,1]  R2506     -6
    e2_S4_1_4_arc[-1,1]  R2507     5
    e2_S4_1_4_arc[-1,1]  R2591     -30
    e2_S4_1_4_arc[-1,1]  R3147     1
    e2_S4_1_4_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_1_4_arc[-1,2]  R2462     1
    e2_S4_1_4_arc[-1,2]  R2474     1
    e2_S4_1_4_arc[-1,2]  R2508     -44289
    e2_S4_1_4_arc[-1,2]  R2509     -157
    e2_S4_1_4_arc[-1,2]  R2510     180
    e2_S4_1_4_arc[-1,2]  R2511     -4
    e2_S4_1_4_arc[-1,2]  R2512     6
    e2_S4_1_4_arc[-1,2]  R2592     -30
    e2_S4_1_4_arc[-1,2]  R3150     1
    e2_S4_1_4_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_1_4_arc[-1,3]  R2462     1
    e2_S4_1_4_arc[-1,3]  R2477     1
    e2_S4_1_4_arc[-1,3]  R2513     -40989
    e2_S4_1_4_arc[-1,3]  R2514     -180
    e2_S4_1_4_arc[-1,3]  R2515     176
    e2_S4_1_4_arc[-1,3]  R2516     -6
    e2_S4_1_4_arc[-1,3]  R2517     4
    e2_S4_1_4_arc[-1,3]  R2593     -30
    e2_S4_1_4_arc[-1,3]  R3153     1
    e2_S4_1_4_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_1_4_arc[-1,4]  R2462     1
    e2_S4_1_4_arc[-1,4]  R2480     1
    e2_S4_1_4_arc[-1,4]  R2518     -29919
    e2_S4_1_4_arc[-1,4]  R2519     -159
    e2_S4_1_4_arc[-1,4]  R2520     180
    e2_S4_1_4_arc[-1,4]  R2521     -4
    e2_S4_1_4_arc[-1,4]  R2522     6
    e2_S4_1_4_arc[-1,4]  R2594     -30
    e2_S4_1_4_arc[-1,4]  R3156     1
    e2_S4_1_4_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_1_4_arc[-1,5]  R2462     1
    e2_S4_1_4_arc[-1,5]  R2483     1
    e2_S4_1_4_arc[-1,5]  R2523     -26919
    e2_S4_1_4_arc[-1,5]  R2524     -180
    e2_S4_1_4_arc[-1,5]  R2525     176
    e2_S4_1_4_arc[-1,5]  R2526     -6
    e2_S4_1_4_arc[-1,5]  R2527     4
    e2_S4_1_4_arc[-1,5]  R2595     -30
    e2_S4_1_4_arc[-1,5]  R3159     1
    e2_S4_1_4_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_1_4_arc[-1,6]  R2462     1
    e2_S4_1_4_arc[-1,6]  R2486     1
    e2_S4_1_4_arc[-1,6]  R2528     -29851
    e2_S4_1_4_arc[-1,6]  R2529     -157
    e2_S4_1_4_arc[-1,6]  R2530     180
    e2_S4_1_4_arc[-1,6]  R2531     -4
    e2_S4_1_4_arc[-1,6]  R2532     6
    e2_S4_1_4_arc[-1,6]  R2596     -30
    e2_S4_1_4_arc[-1,6]  R3162     1
    e2_S4_1_4_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_1_4_arc[-1,7]  R2462     1
    e2_S4_1_4_arc[-1,7]  R2489     1
    e2_S4_1_4_arc[-1,7]  R2533     -25651
    e2_S4_1_4_arc[-1,7]  R2534     -180
    e2_S4_1_4_arc[-1,7]  R2535     176
    e2_S4_1_4_arc[-1,7]  R2536     -6
    e2_S4_1_4_arc[-1,7]  R2537     4
    e2_S4_1_4_arc[-1,7]  R2597     -30
    e2_S4_1_4_arc[-1,7]  R3165     1
    e2_S4_1_4_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_1_4_arc[-1,8]  R2462     1
    e2_S4_1_4_arc[-1,8]  R2492     1
    e2_S4_1_4_arc[-1,8]  R2538     -15519
    e2_S4_1_4_arc[-1,8]  R2539     -159
    e2_S4_1_4_arc[-1,8]  R2540     180
    e2_S4_1_4_arc[-1,8]  R2541     -4
    e2_S4_1_4_arc[-1,8]  R2542     6
    e2_S4_1_4_arc[-1,8]  R2598     -30
    e2_S4_1_4_arc[-1,8]  R3168     1
    e2_S4_1_4_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_1_4_arc[-1,9]  R2462     1
    e2_S4_1_4_arc[-1,9]  R2495     1
    e2_S4_1_4_arc[-1,9]  R2543     -13119
    e2_S4_1_4_arc[-1,9]  R2544     -180
    e2_S4_1_4_arc[-1,9]  R2545     176
    e2_S4_1_4_arc[-1,9]  R2546     -6
    e2_S4_1_4_arc[-1,9]  R2547     4
    e2_S4_1_4_arc[-1,9]  R2599     -30
    e2_S4_1_4_arc[-1,9]  R3171     1
    e2_S4_1_4_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_4_arc[0,-2]  R2463     1
    e2_S4_1_4_arc[0,-2]  R2469     1
    e2_S4_1_4_arc[0,-2]  R2548     -33523
    e2_S4_1_4_arc[0,-2]  R2600     -30
    e2_S4_1_4_arc[0,-2]  R3145     1
    e2_S4_1_4_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_1_4_arc[1,-2]  R2463     1
    e2_S4_1_4_arc[1,-2]  R2472     1
    e2_S4_1_4_arc[1,-2]  R2549     -39223
    e2_S4_1_4_arc[1,-2]  R2601     -30
    e2_S4_1_4_arc[1,-2]  R3148     1
    e2_S4_1_4_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_4_arc[2,-2]  R2463     1
    e2_S4_1_4_arc[2,-2]  R2475     1
    e2_S4_1_4_arc[2,-2]  R2550     -36369
    e2_S4_1_4_arc[2,-2]  R2602     -30
    e2_S4_1_4_arc[2,-2]  R3151     1
    e2_S4_1_4_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_1_4_arc[3,-2]  R2463     1
    e2_S4_1_4_arc[3,-2]  R2478     1
    e2_S4_1_4_arc[3,-2]  R2551     -42129
    e2_S4_1_4_arc[3,-2]  R2603     -30
    e2_S4_1_4_arc[3,-2]  R3154     1
    e2_S4_1_4_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_1_4_arc[4,-2]  R2463     1
    e2_S4_1_4_arc[4,-2]  R2481     1
    e2_S4_1_4_arc[4,-2]  R2552     -48315
    e2_S4_1_4_arc[4,-2]  R2604     -30
    e2_S4_1_4_arc[4,-2]  R3157     1
    e2_S4_1_4_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_1_4_arc[5,-2]  R2463     1
    e2_S4_1_4_arc[5,-2]  R2484     1
    e2_S4_1_4_arc[5,-2]  R2553     -53475
    e2_S4_1_4_arc[5,-2]  R2605     -30
    e2_S4_1_4_arc[5,-2]  R3160     1
    e2_S4_1_4_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_4_arc[6,-2]  R2463     1
    e2_S4_1_4_arc[6,-2]  R2487     1
    e2_S4_1_4_arc[6,-2]  R2554     -49531
    e2_S4_1_4_arc[6,-2]  R2606     -30
    e2_S4_1_4_arc[6,-2]  R3163     1
    e2_S4_1_4_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_1_4_arc[7,-2]  R2463     1
    e2_S4_1_4_arc[7,-2]  R2490     1
    e2_S4_1_4_arc[7,-2]  R2555     -56191
    e2_S4_1_4_arc[7,-2]  R2607     -30
    e2_S4_1_4_arc[7,-2]  R3166     1
    e2_S4_1_4_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_4_arc[8,-2]  R2463     1
    e2_S4_1_4_arc[8,-2]  R2493     1
    e2_S4_1_4_arc[8,-2]  R2556     -63217
    e2_S4_1_4_arc[8,-2]  R2608     -30
    e2_S4_1_4_arc[8,-2]  R3169     1
    e2_S4_1_4_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_1_4_arc[9,-2]  R2463     1
    e2_S4_1_4_arc[9,-2]  R2496     1
    e2_S4_1_4_arc[9,-2]  R2557     -68677
    e2_S4_1_4_arc[9,-2]  R2609     -30
    e2_S4_1_4_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C1073     R2560     1
    C1073     R2590     -1
    C1073     R2591     -1
    C1073     R2592     -1
    C1073     R2593     -1
    C1073     R2594     -1
    C1073     R2595     -1
    C1073     R2596     -1
    C1073     R2597     -1
    C1073     R2598     -1
    C1073     R2599     -1
    C1074     R2600     1
    C1074     R2601     1
    C1074     R2602     1
    C1074     R2603     1
    C1074     R2604     1
    C1074     R2605     1
    C1074     R2606     1
    C1074     R2607     1
    C1074     R2608     1
    C1074     R2609     1
    MARKER    'MARKER'                 'INTORG'
    C1075     R2561     1
    C1075     R2562     -60
    C1075     R2563     1
    C1075     R2564     -39660
    C1075     R2565     -180
    C1075     R2566     -6
    C1075     R2575     -1
    C1075     R2578     -1
    C1076     R2561     1
    C1076     R2562     -60
    C1076     R2567     1
    C1076     R2568     -54060
    C1076     R2569     -180
    C1076     R2570     -6
    C1076     R2581     -1
    C1076     R2584     -1
    C1077     R2561     1
    C1077     R2562     -60
    C1077     R2571     1
    C1077     R2572     -71160
    C1077     R2573     -180
    C1077     R2574     -6
    C1077     R2587     -1
    e2_S4_2_0_used  R2611     -75600
    e2_S4_2_0_used  R2612     -75600
    e2_S4_2_0_used  R2613     -28800
    e2_S4_2_0_used  R2614     -1
    e2_S4_2_0_used  R2615     -1
    e2_S4_2_0_used  R2616     -180
    e2_S4_2_0_used  R2617     -6
    e2_S4_2_0_used  R2618     -180
    e2_S4_2_0_used  R2619     -6
    e2_S4_2_0_used  R2622     -1
    e2_S4_2_0_used  R2625     -1
    e2_S4_2_0_used  R2628     -1
    e2_S4_2_0_used  R2631     -1
    e2_S4_2_0_used  R2634     -1
    e2_S4_2_0_used  R2637     -1
    e2_S4_2_0_used  R2640     -1
    e2_S4_2_0_used  R2643     -1
    e2_S4_2_0_used  R2646     -1
    e2_S4_2_0_used  R2649     -1
    e2_S4_2_0_used  R2710     1
    e2_S4_2_0_used  R2711     -75540
    e2_S4_2_0_used  R2712     -1
    e2_S4_2_0_used  R2860     -1
    e2_S4_2_0_used  R3062     1
    e2_S4_2_0_start  R2611     1
    e2_S4_2_0_start  R2613     1
    e2_S4_2_0_start  R2650     -1
    e2_S4_2_0_start  R2655     -1
    e2_S4_2_0_start  R2660     -1
    e2_S4_2_0_start  R2665     -1
    e2_S4_2_0_start  R2670     -1
    e2_S4_2_0_start  R2675     -1
    e2_S4_2_0_start  R2680     -1
    e2_S4_2_0_start  R2685     -1
    e2_S4_2_0_start  R2690     -1
    e2_S4_2_0_start  R2695     -1
    e2_S4_2_0_start  R2714     1
    e2_S4_2_0_start  R2718     1
    e2_S4_2_0_start  R2722     1
    e2_S4_2_0_end  R2612     1
    e2_S4_2_0_end  R2700     1
    e2_S4_2_0_end  R2701     1
    e2_S4_2_0_end  R2702     1
    e2_S4_2_0_end  R2703     1
    e2_S4_2_0_end  R2704     1
    e2_S4_2_0_end  R2705     1
    e2_S4_2_0_end  R2706     1
    e2_S4_2_0_end  R2707     1
    e2_S4_2_0_end  R2708     1
    e2_S4_2_0_end  R2709     1
    e2_S4_2_0_end  R2711     1
    e2_S4_2_0_end  R2726     -1
    e2_S4_2_0_end  R2727     -1
    e2_S4_2_0_end  R2729     -1
    e2_S4_2_0_end  R2730     -1
    e2_S4_2_0_end  R2732     -1
    e2_S4_2_0_end  R2733     -1
    e2_S4_2_0_end  R2735     -1
    e2_S4_2_0_end  R2736     -1
    e2_S4_2_0_end  R2738     -1
    e2_S4_2_0_end  R2739     -1
    e2_S4_2_0_end  R2863     -1
    e2_S4_2_0_visit[0]  R2616     15
    e2_S4_2_0_visit[0]  R2617     1
    e2_S4_2_0_visit[0]  R2620     -1
    e2_S4_2_0_visit[0]  R2621     -1
    e2_S4_2_0_visit[0]  R2622     1
    e2_S4_2_0_visit[0]  R2651     -15
    e2_S4_2_0_visit[0]  R2652     -15
    e2_S4_2_0_visit[0]  R2653     -1
    e2_S4_2_0_visit[0]  R2654     -1
    e2_S4_2_0_visit[0]  R2656     -15
    e2_S4_2_0_visit[0]  R2657     -15
    e2_S4_2_0_visit[0]  R2658     -1
    e2_S4_2_0_visit[0]  R2659     -1
    e2_S4_2_0_visit[0]  R2661     -15
    e2_S4_2_0_visit[0]  R2662     -15
    e2_S4_2_0_visit[0]  R2663     -1
    e2_S4_2_0_visit[0]  R2664     -1
    e2_S4_2_0_visit[0]  R2666     -15
    e2_S4_2_0_visit[0]  R2667     -15
    e2_S4_2_0_visit[0]  R2668     -1
    e2_S4_2_0_visit[0]  R2669     -1
    e2_S4_2_0_visit[0]  R2671     -15
    e2_S4_2_0_visit[0]  R2672     -15
    e2_S4_2_0_visit[0]  R2673     -1
    e2_S4_2_0_visit[0]  R2674     -1
    e2_S4_2_0_visit[0]  R2676     -15
    e2_S4_2_0_visit[0]  R2677     -15
    e2_S4_2_0_visit[0]  R2678     -1
    e2_S4_2_0_visit[0]  R2679     -1
    e2_S4_2_0_visit[0]  R2681     -15
    e2_S4_2_0_visit[0]  R2682     -15
    e2_S4_2_0_visit[0]  R2683     -1
    e2_S4_2_0_visit[0]  R2684     -1
    e2_S4_2_0_visit[0]  R2686     -15
    e2_S4_2_0_visit[0]  R2687     -15
    e2_S4_2_0_visit[0]  R2688     -1
    e2_S4_2_0_visit[0]  R2689     -1
    e2_S4_2_0_visit[0]  R2691     -15
    e2_S4_2_0_visit[0]  R2692     -15
    e2_S4_2_0_visit[0]  R2693     -1
    e2_S4_2_0_visit[0]  R2694     -1
    e2_S4_2_0_visit[0]  R2696     -15
    e2_S4_2_0_visit[0]  R2697     -15
    e2_S4_2_0_visit[0]  R2698     -1
    e2_S4_2_0_visit[0]  R2699     -1
    e2_S4_2_0_visit[0]  R2713     -1
    e2_S4_2_0_visit[0]  R2715     15
    e2_S4_2_0_visit[0]  R2716     1
    e2_S4_2_0_visit[0]  R2725     1
    e2_S4_2_0_visit[0]  R3143     -16
    e2_S4_2_0_visit[0]  R3413     1
    e2_S4_2_0_visit[1]  R2618     2
    e2_S4_2_0_visit[1]  R2619     1
    e2_S4_2_0_visit[1]  R2623     -1
    e2_S4_2_0_visit[1]  R2624     -1
    e2_S4_2_0_visit[1]  R2625     1
    e2_S4_2_0_visit[1]  R2726     -40937
    e2_S4_2_0_visit[1]  R2727     71100
    e2_S4_2_0_visit[1]  R3146     -16
    e2_S4_2_0_visit[1]  R3414     1
    e2_S4_2_0_visit[2]  R2616     23
    e2_S4_2_0_visit[2]  R2617     2
    e2_S4_2_0_visit[2]  R2626     -1
    e2_S4_2_0_visit[2]  R2627     -1
    e2_S4_2_0_visit[2]  R2628     1
    e2_S4_2_0_visit[2]  R2651     -23
    e2_S4_2_0_visit[2]  R2652     -23
    e2_S4_2_0_visit[2]  R2653     -2
    e2_S4_2_0_visit[2]  R2654     -2
    e2_S4_2_0_visit[2]  R2656     -23
    e2_S4_2_0_visit[2]  R2657     -23
    e2_S4_2_0_visit[2]  R2658     -2
    e2_S4_2_0_visit[2]  R2659     -2
    e2_S4_2_0_visit[2]  R2661     -23
    e2_S4_2_0_visit[2]  R2662     -23
    e2_S4_2_0_visit[2]  R2663     -2
    e2_S4_2_0_visit[2]  R2664     -2
    e2_S4_2_0_visit[2]  R2666     -23
    e2_S4_2_0_visit[2]  R2667     -23
    e2_S4_2_0_visit[2]  R2668     -2
    e2_S4_2_0_visit[2]  R2669     -2
    e2_S4_2_0_visit[2]  R2671     -23
    e2_S4_2_0_visit[2]  R2672     -23
    e2_S4_2_0_visit[2]  R2673     -2
    e2_S4_2_0_visit[2]  R2674     -2
    e2_S4_2_0_visit[2]  R2676     -23
    e2_S4_2_0_visit[2]  R2677     -23
    e2_S4_2_0_visit[2]  R2678     -2
    e2_S4_2_0_visit[2]  R2679     -2
    e2_S4_2_0_visit[2]  R2681     -23
    e2_S4_2_0_visit[2]  R2682     -23
    e2_S4_2_0_visit[2]  R2683     -2
    e2_S4_2_0_visit[2]  R2684     -2
    e2_S4_2_0_visit[2]  R2686     -23
    e2_S4_2_0_visit[2]  R2687     -23
    e2_S4_2_0_visit[2]  R2688     -2
    e2_S4_2_0_visit[2]  R2689     -2
    e2_S4_2_0_visit[2]  R2691     -23
    e2_S4_2_0_visit[2]  R2692     -23
    e2_S4_2_0_visit[2]  R2693     -2
    e2_S4_2_0_visit[2]  R2694     -2
    e2_S4_2_0_visit[2]  R2696     -23
    e2_S4_2_0_visit[2]  R2697     -23
    e2_S4_2_0_visit[2]  R2698     -2
    e2_S4_2_0_visit[2]  R2699     -2
    e2_S4_2_0_visit[2]  R2713     -1
    e2_S4_2_0_visit[2]  R2715     23
    e2_S4_2_0_visit[2]  R2716     2
    e2_S4_2_0_visit[2]  R2728     1
    e2_S4_2_0_visit[2]  R3149     -16
    e2_S4_2_0_visit[2]  R3417     1
    e2_S4_2_0_visit[3]  R2618     4
    e2_S4_2_0_visit[3]  R2619     2
    e2_S4_2_0_visit[3]  R2629     -1
    e2_S4_2_0_visit[3]  R2630     -1
    e2_S4_2_0_visit[3]  R2631     1
    e2_S4_2_0_visit[3]  R2729     -38031
    e2_S4_2_0_visit[3]  R2730     71100
    e2_S4_2_0_visit[3]  R3152     -16
    e2_S4_2_0_visit[3]  R3418     1
    e2_S4_2_0_visit[4]  R2616     21
    e2_S4_2_0_visit[4]  R2617     2
    e2_S4_2_0_visit[4]  R2632     -1
    e2_S4_2_0_visit[4]  R2633     -1
    e2_S4_2_0_visit[4]  R2634     1
    e2_S4_2_0_visit[4]  R2651     -21
    e2_S4_2_0_visit[4]  R2652     -21
    e2_S4_2_0_visit[4]  R2653     -2
    e2_S4_2_0_visit[4]  R2654     -2
    e2_S4_2_0_visit[4]  R2656     -21
    e2_S4_2_0_visit[4]  R2657     -21
    e2_S4_2_0_visit[4]  R2658     -2
    e2_S4_2_0_visit[4]  R2659     -2
    e2_S4_2_0_visit[4]  R2661     -21
    e2_S4_2_0_visit[4]  R2662     -21
    e2_S4_2_0_visit[4]  R2663     -2
    e2_S4_2_0_visit[4]  R2664     -2
    e2_S4_2_0_visit[4]  R2666     -21
    e2_S4_2_0_visit[4]  R2667     -21
    e2_S4_2_0_visit[4]  R2668     -2
    e2_S4_2_0_visit[4]  R2669     -2
    e2_S4_2_0_visit[4]  R2671     -21
    e2_S4_2_0_visit[4]  R2672     -21
    e2_S4_2_0_visit[4]  R2673     -2
    e2_S4_2_0_visit[4]  R2674     -2
    e2_S4_2_0_visit[4]  R2676     -21
    e2_S4_2_0_visit[4]  R2677     -21
    e2_S4_2_0_visit[4]  R2678     -2
    e2_S4_2_0_visit[4]  R2679     -2
    e2_S4_2_0_visit[4]  R2681     -21
    e2_S4_2_0_visit[4]  R2682     -21
    e2_S4_2_0_visit[4]  R2683     -2
    e2_S4_2_0_visit[4]  R2684     -2
    e2_S4_2_0_visit[4]  R2686     -21
    e2_S4_2_0_visit[4]  R2687     -21
    e2_S4_2_0_visit[4]  R2688     -2
    e2_S4_2_0_visit[4]  R2689     -2
    e2_S4_2_0_visit[4]  R2691     -21
    e2_S4_2_0_visit[4]  R2692     -21
    e2_S4_2_0_visit[4]  R2693     -2
    e2_S4_2_0_visit[4]  R2694     -2
    e2_S4_2_0_visit[4]  R2696     -21
    e2_S4_2_0_visit[4]  R2697     -21
    e2_S4_2_0_visit[4]  R2698     -2
    e2_S4_2_0_visit[4]  R2699     -2
    e2_S4_2_0_visit[4]  R2717     -1
    e2_S4_2_0_visit[4]  R2719     21
    e2_S4_2_0_visit[4]  R2720     2
    e2_S4_2_0_visit[4]  R2731     1
    e2_S4_2_0_visit[4]  R3155     -16
    e2_S4_2_0_visit[4]  R3421     1
    e2_S4_2_0_visit[5]  R2618     4
    e2_S4_2_0_visit[5]  R2619     2
    e2_S4_2_0_visit[5]  R2635     -1
    e2_S4_2_0_visit[5]  R2636     -1
    e2_S4_2_0_visit[5]  R2637     1
    e2_S4_2_0_visit[5]  R2732     -25749
    e2_S4_2_0_visit[5]  R2733     71100
    e2_S4_2_0_visit[5]  R3158     -16
    e2_S4_2_0_visit[5]  R3422     1
    e2_S4_2_0_visit[6]  R2616     23
    e2_S4_2_0_visit[6]  R2617     2
    e2_S4_2_0_visit[6]  R2638     -1
    e2_S4_2_0_visit[6]  R2639     -1
    e2_S4_2_0_visit[6]  R2640     1
    e2_S4_2_0_visit[6]  R2651     -23
    e2_S4_2_0_visit[6]  R2652     -23
    e2_S4_2_0_visit[6]  R2653     -2
    e2_S4_2_0_visit[6]  R2654     -2
    e2_S4_2_0_visit[6]  R2656     -23
    e2_S4_2_0_visit[6]  R2657     -23
    e2_S4_2_0_visit[6]  R2658     -2
    e2_S4_2_0_visit[6]  R2659     -2
    e2_S4_2_0_visit[6]  R2661     -23
    e2_S4_2_0_visit[6]  R2662     -23
    e2_S4_2_0_visit[6]  R2663     -2
    e2_S4_2_0_visit[6]  R2664     -2
    e2_S4_2_0_visit[6]  R2666     -23
    e2_S4_2_0_visit[6]  R2667     -23
    e2_S4_2_0_visit[6]  R2668     -2
    e2_S4_2_0_visit[6]  R2669     -2
    e2_S4_2_0_visit[6]  R2671     -23
    e2_S4_2_0_visit[6]  R2672     -23
    e2_S4_2_0_visit[6]  R2673     -2
    e2_S4_2_0_visit[6]  R2674     -2
    e2_S4_2_0_visit[6]  R2676     -23
    e2_S4_2_0_visit[6]  R2677     -23
    e2_S4_2_0_visit[6]  R2678     -2
    e2_S4_2_0_visit[6]  R2679     -2
    e2_S4_2_0_visit[6]  R2681     -23
    e2_S4_2_0_visit[6]  R2682     -23
    e2_S4_2_0_visit[6]  R2683     -2
    e2_S4_2_0_visit[6]  R2684     -2
    e2_S4_2_0_visit[6]  R2686     -23
    e2_S4_2_0_visit[6]  R2687     -23
    e2_S4_2_0_visit[6]  R2688     -2
    e2_S4_2_0_visit[6]  R2689     -2
    e2_S4_2_0_visit[6]  R2691     -23
    e2_S4_2_0_visit[6]  R2692     -23
    e2_S4_2_0_visit[6]  R2693     -2
    e2_S4_2_0_visit[6]  R2694     -2
    e2_S4_2_0_visit[6]  R2696     -23
    e2_S4_2_0_visit[6]  R2697     -23
    e2_S4_2_0_visit[6]  R2698     -2
    e2_S4_2_0_visit[6]  R2699     -2
    e2_S4_2_0_visit[6]  R2717     -1
    e2_S4_2_0_visit[6]  R2719     23
    e2_S4_2_0_visit[6]  R2720     2
    e2_S4_2_0_visit[6]  R2734     1
    e2_S4_2_0_visit[6]  R3161     -16
    e2_S4_2_0_visit[6]  R3425     1
    e2_S4_2_0_visit[7]  R2618     4
    e2_S4_2_0_visit[7]  R2619     2
    e2_S4_2_0_visit[7]  R2641     -1
    e2_S4_2_0_visit[7]  R2642     -1
    e2_S4_2_0_visit[7]  R2643     1
    e2_S4_2_0_visit[7]  R2735     -23969
    e2_S4_2_0_visit[7]  R2736     71100
    e2_S4_2_0_visit[7]  R3164     -16
    e2_S4_2_0_visit[7]  R3426     1
    e2_S4_2_0_visit[8]  R2616     21
    e2_S4_2_0_visit[8]  R2617     2
    e2_S4_2_0_visit[8]  R2644     -1
    e2_S4_2_0_visit[8]  R2645     -1
    e2_S4_2_0_visit[8]  R2646     1
    e2_S4_2_0_visit[8]  R2651     -21
    e2_S4_2_0_visit[8]  R2652     -21
    e2_S4_2_0_visit[8]  R2653     -2
    e2_S4_2_0_visit[8]  R2654     -2
    e2_S4_2_0_visit[8]  R2656     -21
    e2_S4_2_0_visit[8]  R2657     -21
    e2_S4_2_0_visit[8]  R2658     -2
    e2_S4_2_0_visit[8]  R2659     -2
    e2_S4_2_0_visit[8]  R2661     -21
    e2_S4_2_0_visit[8]  R2662     -21
    e2_S4_2_0_visit[8]  R2663     -2
    e2_S4_2_0_visit[8]  R2664     -2
    e2_S4_2_0_visit[8]  R2666     -21
    e2_S4_2_0_visit[8]  R2667     -21
    e2_S4_2_0_visit[8]  R2668     -2
    e2_S4_2_0_visit[8]  R2669     -2
    e2_S4_2_0_visit[8]  R2671     -21
    e2_S4_2_0_visit[8]  R2672     -21
    e2_S4_2_0_visit[8]  R2673     -2
    e2_S4_2_0_visit[8]  R2674     -2
    e2_S4_2_0_visit[8]  R2676     -21
    e2_S4_2_0_visit[8]  R2677     -21
    e2_S4_2_0_visit[8]  R2678     -2
    e2_S4_2_0_visit[8]  R2679     -2
    e2_S4_2_0_visit[8]  R2681     -21
    e2_S4_2_0_visit[8]  R2682     -21
    e2_S4_2_0_visit[8]  R2683     -2
    e2_S4_2_0_visit[8]  R2684     -2
    e2_S4_2_0_visit[8]  R2686     -21
    e2_S4_2_0_visit[8]  R2687     -21
    e2_S4_2_0_visit[8]  R2688     -2
    e2_S4_2_0_visit[8]  R2689     -2
    e2_S4_2_0_visit[8]  R2691     -21
    e2_S4_2_0_visit[8]  R2692     -21
    e2_S4_2_0_visit[8]  R2693     -2
    e2_S4_2_0_visit[8]  R2694     -2
    e2_S4_2_0_visit[8]  R2696     -21
    e2_S4_2_0_visit[8]  R2697     -21
    e2_S4_2_0_visit[8]  R2698     -2
    e2_S4_2_0_visit[8]  R2699     -2
    e2_S4_2_0_visit[8]  R2721     -1
    e2_S4_2_0_visit[8]  R2723     21
    e2_S4_2_0_visit[8]  R2724     2
    e2_S4_2_0_visit[8]  R2737     1
    e2_S4_2_0_visit[8]  R3167     -16
    e2_S4_2_0_visit[8]  R3429     1
    e2_S4_2_0_visit[9]  R2618     4
    e2_S4_2_0_visit[9]  R2619     2
    e2_S4_2_0_visit[9]  R2647     -1
    e2_S4_2_0_visit[9]  R2648     -1
    e2_S4_2_0_visit[9]  R2649     1
    e2_S4_2_0_visit[9]  R2738     -11425
    e2_S4_2_0_visit[9]  R2739     71100
    e2_S4_2_0_visit[9]  R3170     -16
    e2_S4_2_0_visit[9]  R3430     1
    e2_S4_2_0_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_2_0_arc[-1,0]  R2614     1
    e2_S4_2_0_arc[-1,0]  R2620     1
    e2_S4_2_0_arc[-1,0]  R2650     -44319
    e2_S4_2_0_arc[-1,0]  R2651     -165
    e2_S4_2_0_arc[-1,0]  R2652     180
    e2_S4_2_0_arc[-1,0]  R2653     -5
    e2_S4_2_0_arc[-1,0]  R2654     6
    e2_S4_2_0_arc[-1,0]  R2740     -30
    e2_S4_2_0_arc[-1,0]  R3144     1
    e2_S4_2_0_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_2_0_arc[-1,1]  R2614     1
    e2_S4_2_0_arc[-1,1]  R2623     1
    e2_S4_2_0_arc[-1,1]  R2655     -41683
    e2_S4_2_0_arc[-1,1]  R2656     -180
    e2_S4_2_0_arc[-1,1]  R2657     178
    e2_S4_2_0_arc[-1,1]  R2658     -6
    e2_S4_2_0_arc[-1,1]  R2659     5
    e2_S4_2_0_arc[-1,1]  R2741     -30
    e2_S4_2_0_arc[-1,1]  R3147     1
    e2_S4_2_0_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_2_0_arc[-1,2]  R2614     1
    e2_S4_2_0_arc[-1,2]  R2626     1
    e2_S4_2_0_arc[-1,2]  R2660     -44289
    e2_S4_2_0_arc[-1,2]  R2661     -157
    e2_S4_2_0_arc[-1,2]  R2662     180
    e2_S4_2_0_arc[-1,2]  R2663     -4
    e2_S4_2_0_arc[-1,2]  R2664     6
    e2_S4_2_0_arc[-1,2]  R2742     -30
    e2_S4_2_0_arc[-1,2]  R3150     1
    e2_S4_2_0_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_2_0_arc[-1,3]  R2614     1
    e2_S4_2_0_arc[-1,3]  R2629     1
    e2_S4_2_0_arc[-1,3]  R2665     -40989
    e2_S4_2_0_arc[-1,3]  R2666     -180
    e2_S4_2_0_arc[-1,3]  R2667     176
    e2_S4_2_0_arc[-1,3]  R2668     -6
    e2_S4_2_0_arc[-1,3]  R2669     4
    e2_S4_2_0_arc[-1,3]  R2743     -30
    e2_S4_2_0_arc[-1,3]  R3153     1
    e2_S4_2_0_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_2_0_arc[-1,4]  R2614     1
    e2_S4_2_0_arc[-1,4]  R2632     1
    e2_S4_2_0_arc[-1,4]  R2670     -29919
    e2_S4_2_0_arc[-1,4]  R2671     -159
    e2_S4_2_0_arc[-1,4]  R2672     180
    e2_S4_2_0_arc[-1,4]  R2673     -4
    e2_S4_2_0_arc[-1,4]  R2674     6
    e2_S4_2_0_arc[-1,4]  R2744     -30
    e2_S4_2_0_arc[-1,4]  R3156     1
    e2_S4_2_0_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_2_0_arc[-1,5]  R2614     1
    e2_S4_2_0_arc[-1,5]  R2635     1
    e2_S4_2_0_arc[-1,5]  R2675     -26919
    e2_S4_2_0_arc[-1,5]  R2676     -180
    e2_S4_2_0_arc[-1,5]  R2677     176
    e2_S4_2_0_arc[-1,5]  R2678     -6
    e2_S4_2_0_arc[-1,5]  R2679     4
    e2_S4_2_0_arc[-1,5]  R2745     -30
    e2_S4_2_0_arc[-1,5]  R3159     1
    e2_S4_2_0_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_2_0_arc[-1,6]  R2614     1
    e2_S4_2_0_arc[-1,6]  R2638     1
    e2_S4_2_0_arc[-1,6]  R2680     -29851
    e2_S4_2_0_arc[-1,6]  R2681     -157
    e2_S4_2_0_arc[-1,6]  R2682     180
    e2_S4_2_0_arc[-1,6]  R2683     -4
    e2_S4_2_0_arc[-1,6]  R2684     6
    e2_S4_2_0_arc[-1,6]  R2746     -30
    e2_S4_2_0_arc[-1,6]  R3162     1
    e2_S4_2_0_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_2_0_arc[-1,7]  R2614     1
    e2_S4_2_0_arc[-1,7]  R2641     1
    e2_S4_2_0_arc[-1,7]  R2685     -25651
    e2_S4_2_0_arc[-1,7]  R2686     -180
    e2_S4_2_0_arc[-1,7]  R2687     176
    e2_S4_2_0_arc[-1,7]  R2688     -6
    e2_S4_2_0_arc[-1,7]  R2689     4
    e2_S4_2_0_arc[-1,7]  R2747     -30
    e2_S4_2_0_arc[-1,7]  R3165     1
    e2_S4_2_0_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_2_0_arc[-1,8]  R2614     1
    e2_S4_2_0_arc[-1,8]  R2644     1
    e2_S4_2_0_arc[-1,8]  R2690     -15519
    e2_S4_2_0_arc[-1,8]  R2691     -159
    e2_S4_2_0_arc[-1,8]  R2692     180
    e2_S4_2_0_arc[-1,8]  R2693     -4
    e2_S4_2_0_arc[-1,8]  R2694     6
    e2_S4_2_0_arc[-1,8]  R2748     -30
    e2_S4_2_0_arc[-1,8]  R3168     1
    e2_S4_2_0_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_2_0_arc[-1,9]  R2614     1
    e2_S4_2_0_arc[-1,9]  R2647     1
    e2_S4_2_0_arc[-1,9]  R2695     -13119
    e2_S4_2_0_arc[-1,9]  R2696     -180
    e2_S4_2_0_arc[-1,9]  R2697     176
    e2_S4_2_0_arc[-1,9]  R2698     -6
    e2_S4_2_0_arc[-1,9]  R2699     4
    e2_S4_2_0_arc[-1,9]  R2749     -30
    e2_S4_2_0_arc[-1,9]  R3171     1
    e2_S4_2_0_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_2_0_arc[0,-2]  R2615     1
    e2_S4_2_0_arc[0,-2]  R2621     1
    e2_S4_2_0_arc[0,-2]  R2700     -33523
    e2_S4_2_0_arc[0,-2]  R2750     -30
    e2_S4_2_0_arc[0,-2]  R3145     1
    e2_S4_2_0_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_2_0_arc[1,-2]  R2615     1
    e2_S4_2_0_arc[1,-2]  R2624     1
    e2_S4_2_0_arc[1,-2]  R2701     -39223
    e2_S4_2_0_arc[1,-2]  R2751     -30
    e2_S4_2_0_arc[1,-2]  R3148     1
    e2_S4_2_0_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_2_0_arc[2,-2]  R2615     1
    e2_S4_2_0_arc[2,-2]  R2627     1
    e2_S4_2_0_arc[2,-2]  R2702     -36369
    e2_S4_2_0_arc[2,-2]  R2752     -30
    e2_S4_2_0_arc[2,-2]  R3151     1
    e2_S4_2_0_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_2_0_arc[3,-2]  R2615     1
    e2_S4_2_0_arc[3,-2]  R2630     1
    e2_S4_2_0_arc[3,-2]  R2703     -42129
    e2_S4_2_0_arc[3,-2]  R2753     -30
    e2_S4_2_0_arc[3,-2]  R3154     1
    e2_S4_2_0_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_2_0_arc[4,-2]  R2615     1
    e2_S4_2_0_arc[4,-2]  R2633     1
    e2_S4_2_0_arc[4,-2]  R2704     -48315
    e2_S4_2_0_arc[4,-2]  R2754     -30
    e2_S4_2_0_arc[4,-2]  R3157     1
    e2_S4_2_0_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_2_0_arc[5,-2]  R2615     1
    e2_S4_2_0_arc[5,-2]  R2636     1
    e2_S4_2_0_arc[5,-2]  R2705     -53475
    e2_S4_2_0_arc[5,-2]  R2755     -30
    e2_S4_2_0_arc[5,-2]  R3160     1
    e2_S4_2_0_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_2_0_arc[6,-2]  R2615     1
    e2_S4_2_0_arc[6,-2]  R2639     1
    e2_S4_2_0_arc[6,-2]  R2706     -49531
    e2_S4_2_0_arc[6,-2]  R2756     -30
    e2_S4_2_0_arc[6,-2]  R3163     1
    e2_S4_2_0_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_2_0_arc[7,-2]  R2615     1
    e2_S4_2_0_arc[7,-2]  R2642     1
    e2_S4_2_0_arc[7,-2]  R2707     -56191
    e2_S4_2_0_arc[7,-2]  R2757     -30
    e2_S4_2_0_arc[7,-2]  R3166     1
    e2_S4_2_0_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_2_0_arc[8,-2]  R2615     1
    e2_S4_2_0_arc[8,-2]  R2645     1
    e2_S4_2_0_arc[8,-2]  R2708     -63217
    e2_S4_2_0_arc[8,-2]  R2758     -30
    e2_S4_2_0_arc[8,-2]  R3169     1
    e2_S4_2_0_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_2_0_arc[9,-2]  R2615     1
    e2_S4_2_0_arc[9,-2]  R2648     1
    e2_S4_2_0_arc[9,-2]  R2709     -68677
    e2_S4_2_0_arc[9,-2]  R2759     -30
    e2_S4_2_0_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C1111     R2740     -1
    C1111     R2741     -1
    C1111     R2742     -1
    C1111     R2743     -1
    C1111     R2744     -1
    C1111     R2745     -1
    C1111     R2746     -1
    C1111     R2747     -1
    C1111     R2748     -1
    C1111     R2749     -1
    C1112     R2750     1
    C1112     R2751     1
    C1112     R2752     1
    C1112     R2753     1
    C1112     R2754     1
    C1112     R2755     1
    C1112     R2756     1
    C1112     R2757     1
    C1112     R2758     1
    C1112     R2759     1
    C1112     R2861     -1
    MARKER    'MARKER'                 'INTORG'
    C1113     R2712     1
    C1113     R2713     1
    C1113     R2714     -39660
    C1113     R2715     -180
    C1113     R2716     -6
    C1113     R2725     -1
    C1113     R2728     -1
    C1114     R2712     1
    C1114     R2717     1
    C1114     R2718     -54060
    C1114     R2719     -180
    C1114     R2720     -6
    C1114     R2731     -1
    C1114     R2734     -1
    C1115     R2712     1
    C1115     R2721     1
    C1115     R2722     -71160
    C1115     R2723     -180
    C1115     R2724     -6
    C1115     R2737     -1
    e2_S4_2_1_used  R2760     -75600
    e2_S4_2_1_used  R2761     -75600
    e2_S4_2_1_used  R2762     -28800
    e2_S4_2_1_used  R2763     -1
    e2_S4_2_1_used  R2764     -1
    e2_S4_2_1_used  R2765     -180
    e2_S4_2_1_used  R2766     -6
    e2_S4_2_1_used  R2767     -180
    e2_S4_2_1_used  R2768     -6
    e2_S4_2_1_used  R2771     -1
    e2_S4_2_1_used  R2774     -1
    e2_S4_2_1_used  R2777     -1
    e2_S4_2_1_used  R2780     -1
    e2_S4_2_1_used  R2783     -1
    e2_S4_2_1_used  R2786     -1
    e2_S4_2_1_used  R2789     -1
    e2_S4_2_1_used  R2792     -1
    e2_S4_2_1_used  R2795     -1
    e2_S4_2_1_used  R2798     -1
    e2_S4_2_1_used  R2859     -75540
    e2_S4_2_1_used  R2860     1
    e2_S4_2_1_used  R2861     -30
    e2_S4_2_1_used  R2862     -1
    e2_S4_2_1_used  R2863     -75600
    e2_S4_2_1_used  R3011     -1
    e2_S4_2_1_used  R3062     1
    e2_S4_2_1_start  R2760     1
    e2_S4_2_1_start  R2762     1
    e2_S4_2_1_start  R2799     -1
    e2_S4_2_1_start  R2804     -1
    e2_S4_2_1_start  R2809     -1
    e2_S4_2_1_start  R2814     -1
    e2_S4_2_1_start  R2819     -1
    e2_S4_2_1_start  R2824     -1
    e2_S4_2_1_start  R2829     -1
    e2_S4_2_1_start  R2834     -1
    e2_S4_2_1_start  R2839     -1
    e2_S4_2_1_start  R2844     -1
    e2_S4_2_1_start  R2863     1
    e2_S4_2_1_start  R2865     1
    e2_S4_2_1_start  R2869     1
    e2_S4_2_1_start  R2873     1
    e2_S4_2_1_end  R2761     1
    e2_S4_2_1_end  R2849     1
    e2_S4_2_1_end  R2850     1
    e2_S4_2_1_end  R2851     1
    e2_S4_2_1_end  R2852     1
    e2_S4_2_1_end  R2853     1
    e2_S4_2_1_end  R2854     1
    e2_S4_2_1_end  R2855     1
    e2_S4_2_1_end  R2856     1
    e2_S4_2_1_end  R2857     1
    e2_S4_2_1_end  R2858     1
    e2_S4_2_1_end  R2859     1
    e2_S4_2_1_end  R2877     -1
    e2_S4_2_1_end  R2878     -1
    e2_S4_2_1_end  R2880     -1
    e2_S4_2_1_end  R2881     -1
    e2_S4_2_1_end  R2883     -1
    e2_S4_2_1_end  R2884     -1
    e2_S4_2_1_end  R2886     -1
    e2_S4_2_1_end  R2887     -1
    e2_S4_2_1_end  R2889     -1
    e2_S4_2_1_end  R2890     -1
    e2_S4_2_1_end  R3014     -1
    e2_S4_2_1_visit[0]  R2765     15
    e2_S4_2_1_visit[0]  R2766     1
    e2_S4_2_1_visit[0]  R2769     -1
    e2_S4_2_1_visit[0]  R2770     -1
    e2_S4_2_1_visit[0]  R2771     1
    e2_S4_2_1_visit[0]  R2800     -15
    e2_S4_2_1_visit[0]  R2801     -15
    e2_S4_2_1_visit[0]  R2802     -1
    e2_S4_2_1_visit[0]  R2803     -1
    e2_S4_2_1_visit[0]  R2805     -15
    e2_S4_2_1_visit[0]  R2806     -15
    e2_S4_2_1_visit[0]  R2807     -1
    e2_S4_2_1_visit[0]  R2808     -1
    e2_S4_2_1_visit[0]  R2810     -15
    e2_S4_2_1_visit[0]  R2811     -15
    e2_S4_2_1_visit[0]  R2812     -1
    e2_S4_2_1_visit[0]  R2813     -1
    e2_S4_2_1_visit[0]  R2815     -15
    e2_S4_2_1_visit[0]  R2816     -15
    e2_S4_2_1_visit[0]  R2817     -1
    e2_S4_2_1_visit[0]  R2818     -1
    e2_S4_2_1_visit[0]  R2820     -15
    e2_S4_2_1_visit[0]  R2821     -15
    e2_S4_2_1_visit[0]  R2822     -1
    e2_S4_2_1_visit[0]  R2823     -1
    e2_S4_2_1_visit[0]  R2825     -15
    e2_S4_2_1_visit[0]  R2826     -15
    e2_S4_2_1_visit[0]  R2827     -1
    e2_S4_2_1_visit[0]  R2828     -1
    e2_S4_2_1_visit[0]  R2830     -15
    e2_S4_2_1_visit[0]  R2831     -15
    e2_S4_2_1_visit[0]  R2832     -1
    e2_S4_2_1_visit[0]  R2833     -1
    e2_S4_2_1_visit[0]  R2835     -15
    e2_S4_2_1_visit[0]  R2836     -15
    e2_S4_2_1_visit[0]  R2837     -1
    e2_S4_2_1_visit[0]  R2838     -1
    e2_S4_2_1_visit[0]  R2840     -15
    e2_S4_2_1_visit[0]  R2841     -15
    e2_S4_2_1_visit[0]  R2842     -1
    e2_S4_2_1_visit[0]  R2843     -1
    e2_S4_2_1_visit[0]  R2845     -15
    e2_S4_2_1_visit[0]  R2846     -15
    e2_S4_2_1_visit[0]  R2847     -1
    e2_S4_2_1_visit[0]  R2848     -1
    e2_S4_2_1_visit[0]  R2864     -1
    e2_S4_2_1_visit[0]  R2866     15
    e2_S4_2_1_visit[0]  R2867     1
    e2_S4_2_1_visit[0]  R2876     1
    e2_S4_2_1_visit[0]  R3143     -17
    e2_S4_2_1_visit[0]  R3413     1
    e2_S4_2_1_visit[1]  R2767     2
    e2_S4_2_1_visit[1]  R2768     1
    e2_S4_2_1_visit[1]  R2772     -1
    e2_S4_2_1_visit[1]  R2773     -1
    e2_S4_2_1_visit[1]  R2774     1
    e2_S4_2_1_visit[1]  R2877     -40937
    e2_S4_2_1_visit[1]  R2878     71100
    e2_S4_2_1_visit[1]  R3146     -17
    e2_S4_2_1_visit[1]  R3414     1
    e2_S4_2_1_visit[2]  R2765     23
    e2_S4_2_1_visit[2]  R2766     2
    e2_S4_2_1_visit[2]  R2775     -1
    e2_S4_2_1_visit[2]  R2776     -1
    e2_S4_2_1_visit[2]  R2777     1
    e2_S4_2_1_visit[2]  R2800     -23
    e2_S4_2_1_visit[2]  R2801     -23
    e2_S4_2_1_visit[2]  R2802     -2
    e2_S4_2_1_visit[2]  R2803     -2
    e2_S4_2_1_visit[2]  R2805     -23
    e2_S4_2_1_visit[2]  R2806     -23
    e2_S4_2_1_visit[2]  R2807     -2
    e2_S4_2_1_visit[2]  R2808     -2
    e2_S4_2_1_visit[2]  R2810     -23
    e2_S4_2_1_visit[2]  R2811     -23
    e2_S4_2_1_visit[2]  R2812     -2
    e2_S4_2_1_visit[2]  R2813     -2
    e2_S4_2_1_visit[2]  R2815     -23
    e2_S4_2_1_visit[2]  R2816     -23
    e2_S4_2_1_visit[2]  R2817     -2
    e2_S4_2_1_visit[2]  R2818     -2
    e2_S4_2_1_visit[2]  R2820     -23
    e2_S4_2_1_visit[2]  R2821     -23
    e2_S4_2_1_visit[2]  R2822     -2
    e2_S4_2_1_visit[2]  R2823     -2
    e2_S4_2_1_visit[2]  R2825     -23
    e2_S4_2_1_visit[2]  R2826     -23
    e2_S4_2_1_visit[2]  R2827     -2
    e2_S4_2_1_visit[2]  R2828     -2
    e2_S4_2_1_visit[2]  R2830     -23
    e2_S4_2_1_visit[2]  R2831     -23
    e2_S4_2_1_visit[2]  R2832     -2
    e2_S4_2_1_visit[2]  R2833     -2
    e2_S4_2_1_visit[2]  R2835     -23
    e2_S4_2_1_visit[2]  R2836     -23
    e2_S4_2_1_visit[2]  R2837     -2
    e2_S4_2_1_visit[2]  R2838     -2
    e2_S4_2_1_visit[2]  R2840     -23
    e2_S4_2_1_visit[2]  R2841     -23
    e2_S4_2_1_visit[2]  R2842     -2
    e2_S4_2_1_visit[2]  R2843     -2
    e2_S4_2_1_visit[2]  R2845     -23
    e2_S4_2_1_visit[2]  R2846     -23
    e2_S4_2_1_visit[2]  R2847     -2
    e2_S4_2_1_visit[2]  R2848     -2
    e2_S4_2_1_visit[2]  R2864     -1
    e2_S4_2_1_visit[2]  R2866     23
    e2_S4_2_1_visit[2]  R2867     2
    e2_S4_2_1_visit[2]  R2879     1
    e2_S4_2_1_visit[2]  R3149     -17
    e2_S4_2_1_visit[2]  R3417     1
    e2_S4_2_1_visit[3]  R2767     4
    e2_S4_2_1_visit[3]  R2768     2
    e2_S4_2_1_visit[3]  R2778     -1
    e2_S4_2_1_visit[3]  R2779     -1
    e2_S4_2_1_visit[3]  R2780     1
    e2_S4_2_1_visit[3]  R2880     -38031
    e2_S4_2_1_visit[3]  R2881     71100
    e2_S4_2_1_visit[3]  R3152     -17
    e2_S4_2_1_visit[3]  R3418     1
    e2_S4_2_1_visit[4]  R2765     21
    e2_S4_2_1_visit[4]  R2766     2
    e2_S4_2_1_visit[4]  R2781     -1
    e2_S4_2_1_visit[4]  R2782     -1
    e2_S4_2_1_visit[4]  R2783     1
    e2_S4_2_1_visit[4]  R2800     -21
    e2_S4_2_1_visit[4]  R2801     -21
    e2_S4_2_1_visit[4]  R2802     -2
    e2_S4_2_1_visit[4]  R2803     -2
    e2_S4_2_1_visit[4]  R2805     -21
    e2_S4_2_1_visit[4]  R2806     -21
    e2_S4_2_1_visit[4]  R2807     -2
    e2_S4_2_1_visit[4]  R2808     -2
    e2_S4_2_1_visit[4]  R2810     -21
    e2_S4_2_1_visit[4]  R2811     -21
    e2_S4_2_1_visit[4]  R2812     -2
    e2_S4_2_1_visit[4]  R2813     -2
    e2_S4_2_1_visit[4]  R2815     -21
    e2_S4_2_1_visit[4]  R2816     -21
    e2_S4_2_1_visit[4]  R2817     -2
    e2_S4_2_1_visit[4]  R2818     -2
    e2_S4_2_1_visit[4]  R2820     -21
    e2_S4_2_1_visit[4]  R2821     -21
    e2_S4_2_1_visit[4]  R2822     -2
    e2_S4_2_1_visit[4]  R2823     -2
    e2_S4_2_1_visit[4]  R2825     -21
    e2_S4_2_1_visit[4]  R2826     -21
    e2_S4_2_1_visit[4]  R2827     -2
    e2_S4_2_1_visit[4]  R2828     -2
    e2_S4_2_1_visit[4]  R2830     -21
    e2_S4_2_1_visit[4]  R2831     -21
    e2_S4_2_1_visit[4]  R2832     -2
    e2_S4_2_1_visit[4]  R2833     -2
    e2_S4_2_1_visit[4]  R2835     -21
    e2_S4_2_1_visit[4]  R2836     -21
    e2_S4_2_1_visit[4]  R2837     -2
    e2_S4_2_1_visit[4]  R2838     -2
    e2_S4_2_1_visit[4]  R2840     -21
    e2_S4_2_1_visit[4]  R2841     -21
    e2_S4_2_1_visit[4]  R2842     -2
    e2_S4_2_1_visit[4]  R2843     -2
    e2_S4_2_1_visit[4]  R2845     -21
    e2_S4_2_1_visit[4]  R2846     -21
    e2_S4_2_1_visit[4]  R2847     -2
    e2_S4_2_1_visit[4]  R2848     -2
    e2_S4_2_1_visit[4]  R2868     -1
    e2_S4_2_1_visit[4]  R2870     21
    e2_S4_2_1_visit[4]  R2871     2
    e2_S4_2_1_visit[4]  R2882     1
    e2_S4_2_1_visit[4]  R3155     -17
    e2_S4_2_1_visit[4]  R3421     1
    e2_S4_2_1_visit[5]  R2767     4
    e2_S4_2_1_visit[5]  R2768     2
    e2_S4_2_1_visit[5]  R2784     -1
    e2_S4_2_1_visit[5]  R2785     -1
    e2_S4_2_1_visit[5]  R2786     1
    e2_S4_2_1_visit[5]  R2883     -25749
    e2_S4_2_1_visit[5]  R2884     71100
    e2_S4_2_1_visit[5]  R3158     -17
    e2_S4_2_1_visit[5]  R3422     1
    e2_S4_2_1_visit[6]  R2765     23
    e2_S4_2_1_visit[6]  R2766     2
    e2_S4_2_1_visit[6]  R2787     -1
    e2_S4_2_1_visit[6]  R2788     -1
    e2_S4_2_1_visit[6]  R2789     1
    e2_S4_2_1_visit[6]  R2800     -23
    e2_S4_2_1_visit[6]  R2801     -23
    e2_S4_2_1_visit[6]  R2802     -2
    e2_S4_2_1_visit[6]  R2803     -2
    e2_S4_2_1_visit[6]  R2805     -23
    e2_S4_2_1_visit[6]  R2806     -23
    e2_S4_2_1_visit[6]  R2807     -2
    e2_S4_2_1_visit[6]  R2808     -2
    e2_S4_2_1_visit[6]  R2810     -23
    e2_S4_2_1_visit[6]  R2811     -23
    e2_S4_2_1_visit[6]  R2812     -2
    e2_S4_2_1_visit[6]  R2813     -2
    e2_S4_2_1_visit[6]  R2815     -23
    e2_S4_2_1_visit[6]  R2816     -23
    e2_S4_2_1_visit[6]  R2817     -2
    e2_S4_2_1_visit[6]  R2818     -2
    e2_S4_2_1_visit[6]  R2820     -23
    e2_S4_2_1_visit[6]  R2821     -23
    e2_S4_2_1_visit[6]  R2822     -2
    e2_S4_2_1_visit[6]  R2823     -2
    e2_S4_2_1_visit[6]  R2825     -23
    e2_S4_2_1_visit[6]  R2826     -23
    e2_S4_2_1_visit[6]  R2827     -2
    e2_S4_2_1_visit[6]  R2828     -2
    e2_S4_2_1_visit[6]  R2830     -23
    e2_S4_2_1_visit[6]  R2831     -23
    e2_S4_2_1_visit[6]  R2832     -2
    e2_S4_2_1_visit[6]  R2833     -2
    e2_S4_2_1_visit[6]  R2835     -23
    e2_S4_2_1_visit[6]  R2836     -23
    e2_S4_2_1_visit[6]  R2837     -2
    e2_S4_2_1_visit[6]  R2838     -2
    e2_S4_2_1_visit[6]  R2840     -23
    e2_S4_2_1_visit[6]  R2841     -23
    e2_S4_2_1_visit[6]  R2842     -2
    e2_S4_2_1_visit[6]  R2843     -2
    e2_S4_2_1_visit[6]  R2845     -23
    e2_S4_2_1_visit[6]  R2846     -23
    e2_S4_2_1_visit[6]  R2847     -2
    e2_S4_2_1_visit[6]  R2848     -2
    e2_S4_2_1_visit[6]  R2868     -1
    e2_S4_2_1_visit[6]  R2870     23
    e2_S4_2_1_visit[6]  R2871     2
    e2_S4_2_1_visit[6]  R2885     1
    e2_S4_2_1_visit[6]  R3161     -17
    e2_S4_2_1_visit[6]  R3425     1
    e2_S4_2_1_visit[7]  R2767     4
    e2_S4_2_1_visit[7]  R2768     2
    e2_S4_2_1_visit[7]  R2790     -1
    e2_S4_2_1_visit[7]  R2791     -1
    e2_S4_2_1_visit[7]  R2792     1
    e2_S4_2_1_visit[7]  R2886     -23969
    e2_S4_2_1_visit[7]  R2887     71100
    e2_S4_2_1_visit[7]  R3164     -17
    e2_S4_2_1_visit[7]  R3426     1
    e2_S4_2_1_visit[8]  R2765     21
    e2_S4_2_1_visit[8]  R2766     2
    e2_S4_2_1_visit[8]  R2793     -1
    e2_S4_2_1_visit[8]  R2794     -1
    e2_S4_2_1_visit[8]  R2795     1
    e2_S4_2_1_visit[8]  R2800     -21
    e2_S4_2_1_visit[8]  R2801     -21
    e2_S4_2_1_visit[8]  R2802     -2
    e2_S4_2_1_visit[8]  R2803     -2
    e2_S4_2_1_visit[8]  R2805     -21
    e2_S4_2_1_visit[8]  R2806     -21
    e2_S4_2_1_visit[8]  R2807     -2
    e2_S4_2_1_visit[8]  R2808     -2
    e2_S4_2_1_visit[8]  R2810     -21
    e2_S4_2_1_visit[8]  R2811     -21
    e2_S4_2_1_visit[8]  R2812     -2
    e2_S4_2_1_visit[8]  R2813     -2
    e2_S4_2_1_visit[8]  R2815     -21
    e2_S4_2_1_visit[8]  R2816     -21
    e2_S4_2_1_visit[8]  R2817     -2
    e2_S4_2_1_visit[8]  R2818     -2
    e2_S4_2_1_visit[8]  R2820     -21
    e2_S4_2_1_visit[8]  R2821     -21
    e2_S4_2_1_visit[8]  R2822     -2
    e2_S4_2_1_visit[8]  R2823     -2
    e2_S4_2_1_visit[8]  R2825     -21
    e2_S4_2_1_visit[8]  R2826     -21
    e2_S4_2_1_visit[8]  R2827     -2
    e2_S4_2_1_visit[8]  R2828     -2
    e2_S4_2_1_visit[8]  R2830     -21
    e2_S4_2_1_visit[8]  R2831     -21
    e2_S4_2_1_visit[8]  R2832     -2
    e2_S4_2_1_visit[8]  R2833     -2
    e2_S4_2_1_visit[8]  R2835     -21
    e2_S4_2_1_visit[8]  R2836     -21
    e2_S4_2_1_visit[8]  R2837     -2
    e2_S4_2_1_visit[8]  R2838     -2
    e2_S4_2_1_visit[8]  R2840     -21
    e2_S4_2_1_visit[8]  R2841     -21
    e2_S4_2_1_visit[8]  R2842     -2
    e2_S4_2_1_visit[8]  R2843     -2
    e2_S4_2_1_visit[8]  R2845     -21
    e2_S4_2_1_visit[8]  R2846     -21
    e2_S4_2_1_visit[8]  R2847     -2
    e2_S4_2_1_visit[8]  R2848     -2
    e2_S4_2_1_visit[8]  R2872     -1
    e2_S4_2_1_visit[8]  R2874     21
    e2_S4_2_1_visit[8]  R2875     2
    e2_S4_2_1_visit[8]  R2888     1
    e2_S4_2_1_visit[8]  R3167     -17
    e2_S4_2_1_visit[8]  R3429     1
    e2_S4_2_1_visit[9]  R2767     4
    e2_S4_2_1_visit[9]  R2768     2
    e2_S4_2_1_visit[9]  R2796     -1
    e2_S4_2_1_visit[9]  R2797     -1
    e2_S4_2_1_visit[9]  R2798     1
    e2_S4_2_1_visit[9]  R2889     -11425
    e2_S4_2_1_visit[9]  R2890     71100
    e2_S4_2_1_visit[9]  R3170     -17
    e2_S4_2_1_visit[9]  R3430     1
    e2_S4_2_1_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_2_1_arc[-1,0]  R2763     1
    e2_S4_2_1_arc[-1,0]  R2769     1
    e2_S4_2_1_arc[-1,0]  R2799     -44319
    e2_S4_2_1_arc[-1,0]  R2800     -165
    e2_S4_2_1_arc[-1,0]  R2801     180
    e2_S4_2_1_arc[-1,0]  R2802     -5
    e2_S4_2_1_arc[-1,0]  R2803     6
    e2_S4_2_1_arc[-1,0]  R2891     -30
    e2_S4_2_1_arc[-1,0]  R3144     1
    e2_S4_2_1_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_2_1_arc[-1,1]  R2763     1
    e2_S4_2_1_arc[-1,1]  R2772     1
    e2_S4_2_1_arc[-1,1]  R2804     -41683
    e2_S4_2_1_arc[-1,1]  R2805     -180
    e2_S4_2_1_arc[-1,1]  R2806     178
    e2_S4_2_1_arc[-1,1]  R2807     -6
    e2_S4_2_1_arc[-1,1]  R2808     5
    e2_S4_2_1_arc[-1,1]  R2892     -30
    e2_S4_2_1_arc[-1,1]  R3147     1
    e2_S4_2_1_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_2_1_arc[-1,2]  R2763     1
    e2_S4_2_1_arc[-1,2]  R2775     1
    e2_S4_2_1_arc[-1,2]  R2809     -44289
    e2_S4_2_1_arc[-1,2]  R2810     -157
    e2_S4_2_1_arc[-1,2]  R2811     180
    e2_S4_2_1_arc[-1,2]  R2812     -4
    e2_S4_2_1_arc[-1,2]  R2813     6
    e2_S4_2_1_arc[-1,2]  R2893     -30
    e2_S4_2_1_arc[-1,2]  R3150     1
    e2_S4_2_1_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_2_1_arc[-1,3]  R2763     1
    e2_S4_2_1_arc[-1,3]  R2778     1
    e2_S4_2_1_arc[-1,3]  R2814     -40989
    e2_S4_2_1_arc[-1,3]  R2815     -180
    e2_S4_2_1_arc[-1,3]  R2816     176
    e2_S4_2_1_arc[-1,3]  R2817     -6
    e2_S4_2_1_arc[-1,3]  R2818     4
    e2_S4_2_1_arc[-1,3]  R2894     -30
    e2_S4_2_1_arc[-1,3]  R3153     1
    e2_S4_2_1_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_2_1_arc[-1,4]  R2763     1
    e2_S4_2_1_arc[-1,4]  R2781     1
    e2_S4_2_1_arc[-1,4]  R2819     -29919
    e2_S4_2_1_arc[-1,4]  R2820     -159
    e2_S4_2_1_arc[-1,4]  R2821     180
    e2_S4_2_1_arc[-1,4]  R2822     -4
    e2_S4_2_1_arc[-1,4]  R2823     6
    e2_S4_2_1_arc[-1,4]  R2895     -30
    e2_S4_2_1_arc[-1,4]  R3156     1
    e2_S4_2_1_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_2_1_arc[-1,5]  R2763     1
    e2_S4_2_1_arc[-1,5]  R2784     1
    e2_S4_2_1_arc[-1,5]  R2824     -26919
    e2_S4_2_1_arc[-1,5]  R2825     -180
    e2_S4_2_1_arc[-1,5]  R2826     176
    e2_S4_2_1_arc[-1,5]  R2827     -6
    e2_S4_2_1_arc[-1,5]  R2828     4
    e2_S4_2_1_arc[-1,5]  R2896     -30
    e2_S4_2_1_arc[-1,5]  R3159     1
    e2_S4_2_1_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_2_1_arc[-1,6]  R2763     1
    e2_S4_2_1_arc[-1,6]  R2787     1
    e2_S4_2_1_arc[-1,6]  R2829     -29851
    e2_S4_2_1_arc[-1,6]  R2830     -157
    e2_S4_2_1_arc[-1,6]  R2831     180
    e2_S4_2_1_arc[-1,6]  R2832     -4
    e2_S4_2_1_arc[-1,6]  R2833     6
    e2_S4_2_1_arc[-1,6]  R2897     -30
    e2_S4_2_1_arc[-1,6]  R3162     1
    e2_S4_2_1_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_2_1_arc[-1,7]  R2763     1
    e2_S4_2_1_arc[-1,7]  R2790     1
    e2_S4_2_1_arc[-1,7]  R2834     -25651
    e2_S4_2_1_arc[-1,7]  R2835     -180
    e2_S4_2_1_arc[-1,7]  R2836     176
    e2_S4_2_1_arc[-1,7]  R2837     -6
    e2_S4_2_1_arc[-1,7]  R2838     4
    e2_S4_2_1_arc[-1,7]  R2898     -30
    e2_S4_2_1_arc[-1,7]  R3165     1
    e2_S4_2_1_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_2_1_arc[-1,8]  R2763     1
    e2_S4_2_1_arc[-1,8]  R2793     1
    e2_S4_2_1_arc[-1,8]  R2839     -15519
    e2_S4_2_1_arc[-1,8]  R2840     -159
    e2_S4_2_1_arc[-1,8]  R2841     180
    e2_S4_2_1_arc[-1,8]  R2842     -4
    e2_S4_2_1_arc[-1,8]  R2843     6
    e2_S4_2_1_arc[-1,8]  R2899     -30
    e2_S4_2_1_arc[-1,8]  R3168     1
    e2_S4_2_1_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_2_1_arc[-1,9]  R2763     1
    e2_S4_2_1_arc[-1,9]  R2796     1
    e2_S4_2_1_arc[-1,9]  R2844     -13119
    e2_S4_2_1_arc[-1,9]  R2845     -180
    e2_S4_2_1_arc[-1,9]  R2846     176
    e2_S4_2_1_arc[-1,9]  R2847     -6
    e2_S4_2_1_arc[-1,9]  R2848     4
    e2_S4_2_1_arc[-1,9]  R2900     -30
    e2_S4_2_1_arc[-1,9]  R3171     1
    e2_S4_2_1_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_2_1_arc[0,-2]  R2764     1
    e2_S4_2_1_arc[0,-2]  R2770     1
    e2_S4_2_1_arc[0,-2]  R2849     -33523
    e2_S4_2_1_arc[0,-2]  R2901     -30
    e2_S4_2_1_arc[0,-2]  R3145     1
    e2_S4_2_1_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_2_1_arc[1,-2]  R2764     1
    e2_S4_2_1_arc[1,-2]  R2773     1
    e2_S4_2_1_arc[1,-2]  R2850     -39223
    e2_S4_2_1_arc[1,-2]  R2902     -30
    e2_S4_2_1_arc[1,-2]  R3148     1
    e2_S4_2_1_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_2_1_arc[2,-2]  R2764     1
    e2_S4_2_1_arc[2,-2]  R2776     1
    e2_S4_2_1_arc[2,-2]  R2851     -36369
    e2_S4_2_1_arc[2,-2]  R2903     -30
    e2_S4_2_1_arc[2,-2]  R3151     1
    e2_S4_2_1_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_2_1_arc[3,-2]  R2764     1
    e2_S4_2_1_arc[3,-2]  R2779     1
    e2_S4_2_1_arc[3,-2]  R2852     -42129
    e2_S4_2_1_arc[3,-2]  R2904     -30
    e2_S4_2_1_arc[3,-2]  R3154     1
    e2_S4_2_1_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_2_1_arc[4,-2]  R2764     1
    e2_S4_2_1_arc[4,-2]  R2782     1
    e2_S4_2_1_arc[4,-2]  R2853     -48315
    e2_S4_2_1_arc[4,-2]  R2905     -30
    e2_S4_2_1_arc[4,-2]  R3157     1
    e2_S4_2_1_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_2_1_arc[5,-2]  R2764     1
    e2_S4_2_1_arc[5,-2]  R2785     1
    e2_S4_2_1_arc[5,-2]  R2854     -53475
    e2_S4_2_1_arc[5,-2]  R2906     -30
    e2_S4_2_1_arc[5,-2]  R3160     1
    e2_S4_2_1_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_2_1_arc[6,-2]  R2764     1
    e2_S4_2_1_arc[6,-2]  R2788     1
    e2_S4_2_1_arc[6,-2]  R2855     -49531
    e2_S4_2_1_arc[6,-2]  R2907     -30
    e2_S4_2_1_arc[6,-2]  R3163     1
    e2_S4_2_1_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_2_1_arc[7,-2]  R2764     1
    e2_S4_2_1_arc[7,-2]  R2791     1
    e2_S4_2_1_arc[7,-2]  R2856     -56191
    e2_S4_2_1_arc[7,-2]  R2908     -30
    e2_S4_2_1_arc[7,-2]  R3166     1
    e2_S4_2_1_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_2_1_arc[8,-2]  R2764     1
    e2_S4_2_1_arc[8,-2]  R2794     1
    e2_S4_2_1_arc[8,-2]  R2857     -63217
    e2_S4_2_1_arc[8,-2]  R2909     -30
    e2_S4_2_1_arc[8,-2]  R3169     1
    e2_S4_2_1_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_2_1_arc[9,-2]  R2764     1
    e2_S4_2_1_arc[9,-2]  R2797     1
    e2_S4_2_1_arc[9,-2]  R2858     -68677
    e2_S4_2_1_arc[9,-2]  R2910     -30
    e2_S4_2_1_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C1149     R2861     1
    C1149     R2891     -1
    C1149     R2892     -1
    C1149     R2893     -1
    C1149     R2894     -1
    C1149     R2895     -1
    C1149     R2896     -1
    C1149     R2897     -1
    C1149     R2898     -1
    C1149     R2899     -1
    C1149     R2900     -1
    C1150     R2901     1
    C1150     R2902     1
    C1150     R2903     1
    C1150     R2904     1
    C1150     R2905     1
    C1150     R2906     1
    C1150     R2907     1
    C1150     R2908     1
    C1150     R2909     1
    C1150     R2910     1
    C1150     R3012     -1
    MARKER    'MARKER'                 'INTORG'
    C1151     R2862     1
    C1151     R2863     -60
    C1151     R2864     1
    C1151     R2865     -39660
    C1151     R2866     -180
    C1151     R2867     -6
    C1151     R2876     -1
    C1151     R2879     -1
    C1152     R2862     1
    C1152     R2863     -60
    C1152     R2868     1
    C1152     R2869     -54060
    C1152     R2870     -180
    C1152     R2871     -6
    C1152     R2882     -1
    C1152     R2885     -1
    C1153     R2862     1
    C1153     R2863     -60
    C1153     R2872     1
    C1153     R2873     -71160
    C1153     R2874     -180
    C1153     R2875     -6
    C1153     R2888     -1
    e2_S4_2_2_used  R2911     -75600
    e2_S4_2_2_used  R2912     -75600
    e2_S4_2_2_used  R2913     -28800
    e2_S4_2_2_used  R2914     -1
    e2_S4_2_2_used  R2915     -1
    e2_S4_2_2_used  R2916     -180
    e2_S4_2_2_used  R2917     -6
    e2_S4_2_2_used  R2918     -180
    e2_S4_2_2_used  R2919     -6
    e2_S4_2_2_used  R2922     -1
    e2_S4_2_2_used  R2925     -1
    e2_S4_2_2_used  R2928     -1
    e2_S4_2_2_used  R2931     -1
    e2_S4_2_2_used  R2934     -1
    e2_S4_2_2_used  R2937     -1
    e2_S4_2_2_used  R2940     -1
    e2_S4_2_2_used  R2943     -1
    e2_S4_2_2_used  R2946     -1
    e2_S4_2_2_used  R2949     -1
    e2_S4_2_2_used  R3010     -75540
    e2_S4_2_2_used  R3011     1
    e2_S4_2_2_used  R3012     -30
    e2_S4_2_2_used  R3013     -1
    e2_S4_2_2_used  R3014     -75600
    e2_S4_2_2_used  R3062     1
    e2_S4_2_2_start  R2911     1
    e2_S4_2_2_start  R2913     1
    e2_S4_2_2_start  R2950     -1
    e2_S4_2_2_start  R2955     -1
    e2_S4_2_2_start  R2960     -1
    e2_S4_2_2_start  R2965     -1
    e2_S4_2_2_start  R2970     -1
    e2_S4_2_2_start  R2975     -1
    e2_S4_2_2_start  R2980     -1
    e2_S4_2_2_start  R2985     -1
    e2_S4_2_2_start  R2990     -1
    e2_S4_2_2_start  R2995     -1
    e2_S4_2_2_start  R3014     1
    e2_S4_2_2_start  R3016     1
    e2_S4_2_2_start  R3020     1
    e2_S4_2_2_start  R3024     1
    e2_S4_2_2_end  R2912     1
    e2_S4_2_2_end  R3000     1
    e2_S4_2_2_end  R3001     1
    e2_S4_2_2_end  R3002     1
    e2_S4_2_2_end  R3003     1
    e2_S4_2_2_end  R3004     1
    e2_S4_2_2_end  R3005     1
    e2_S4_2_2_end  R3006     1
    e2_S4_2_2_end  R3007     1
    e2_S4_2_2_end  R3008     1
    e2_S4_2_2_end  R3009     1
    e2_S4_2_2_end  R3010     1
    e2_S4_2_2_end  R3028     -1
    e2_S4_2_2_end  R3029     -1
    e2_S4_2_2_end  R3031     -1
    e2_S4_2_2_end  R3032     -1
    e2_S4_2_2_end  R3034     -1
    e2_S4_2_2_end  R3035     -1
    e2_S4_2_2_end  R3037     -1
    e2_S4_2_2_end  R3038     -1
    e2_S4_2_2_end  R3040     -1
    e2_S4_2_2_end  R3041     -1
    e2_S4_2_2_visit[0]  R2916     15
    e2_S4_2_2_visit[0]  R2917     1
    e2_S4_2_2_visit[0]  R2920     -1
    e2_S4_2_2_visit[0]  R2921     -1
    e2_S4_2_2_visit[0]  R2922     1
    e2_S4_2_2_visit[0]  R2951     -15
    e2_S4_2_2_visit[0]  R2952     -15
    e2_S4_2_2_visit[0]  R2953     -1
    e2_S4_2_2_visit[0]  R2954     -1
    e2_S4_2_2_visit[0]  R2956     -15
    e2_S4_2_2_visit[0]  R2957     -15
    e2_S4_2_2_visit[0]  R2958     -1
    e2_S4_2_2_visit[0]  R2959     -1
    e2_S4_2_2_visit[0]  R2961     -15
    e2_S4_2_2_visit[0]  R2962     -15
    e2_S4_2_2_visit[0]  R2963     -1
    e2_S4_2_2_visit[0]  R2964     -1
    e2_S4_2_2_visit[0]  R2966     -15
    e2_S4_2_2_visit[0]  R2967     -15
    e2_S4_2_2_visit[0]  R2968     -1
    e2_S4_2_2_visit[0]  R2969     -1
    e2_S4_2_2_visit[0]  R2971     -15
    e2_S4_2_2_visit[0]  R2972     -15
    e2_S4_2_2_visit[0]  R2973     -1
    e2_S4_2_2_visit[0]  R2974     -1
    e2_S4_2_2_visit[0]  R2976     -15
    e2_S4_2_2_visit[0]  R2977     -15
    e2_S4_2_2_visit[0]  R2978     -1
    e2_S4_2_2_visit[0]  R2979     -1
    e2_S4_2_2_visit[0]  R2981     -15
    e2_S4_2_2_visit[0]  R2982     -15
    e2_S4_2_2_visit[0]  R2983     -1
    e2_S4_2_2_visit[0]  R2984     -1
    e2_S4_2_2_visit[0]  R2986     -15
    e2_S4_2_2_visit[0]  R2987     -15
    e2_S4_2_2_visit[0]  R2988     -1
    e2_S4_2_2_visit[0]  R2989     -1
    e2_S4_2_2_visit[0]  R2991     -15
    e2_S4_2_2_visit[0]  R2992     -15
    e2_S4_2_2_visit[0]  R2993     -1
    e2_S4_2_2_visit[0]  R2994     -1
    e2_S4_2_2_visit[0]  R2996     -15
    e2_S4_2_2_visit[0]  R2997     -15
    e2_S4_2_2_visit[0]  R2998     -1
    e2_S4_2_2_visit[0]  R2999     -1
    e2_S4_2_2_visit[0]  R3015     -1
    e2_S4_2_2_visit[0]  R3017     15
    e2_S4_2_2_visit[0]  R3018     1
    e2_S4_2_2_visit[0]  R3027     1
    e2_S4_2_2_visit[0]  R3143     -18
    e2_S4_2_2_visit[0]  R3413     1
    e2_S4_2_2_visit[1]  R2918     2
    e2_S4_2_2_visit[1]  R2919     1
    e2_S4_2_2_visit[1]  R2923     -1
    e2_S4_2_2_visit[1]  R2924     -1
    e2_S4_2_2_visit[1]  R2925     1
    e2_S4_2_2_visit[1]  R3028     -40937
    e2_S4_2_2_visit[1]  R3029     71100
    e2_S4_2_2_visit[1]  R3146     -18
    e2_S4_2_2_visit[1]  R3414     1
    e2_S4_2_2_visit[2]  R2916     23
    e2_S4_2_2_visit[2]  R2917     2
    e2_S4_2_2_visit[2]  R2926     -1
    e2_S4_2_2_visit[2]  R2927     -1
    e2_S4_2_2_visit[2]  R2928     1
    e2_S4_2_2_visit[2]  R2951     -23
    e2_S4_2_2_visit[2]  R2952     -23
    e2_S4_2_2_visit[2]  R2953     -2
    e2_S4_2_2_visit[2]  R2954     -2
    e2_S4_2_2_visit[2]  R2956     -23
    e2_S4_2_2_visit[2]  R2957     -23
    e2_S4_2_2_visit[2]  R2958     -2
    e2_S4_2_2_visit[2]  R2959     -2
    e2_S4_2_2_visit[2]  R2961     -23
    e2_S4_2_2_visit[2]  R2962     -23
    e2_S4_2_2_visit[2]  R2963     -2
    e2_S4_2_2_visit[2]  R2964     -2
    e2_S4_2_2_visit[2]  R2966     -23
    e2_S4_2_2_visit[2]  R2967     -23
    e2_S4_2_2_visit[2]  R2968     -2
    e2_S4_2_2_visit[2]  R2969     -2
    e2_S4_2_2_visit[2]  R2971     -23
    e2_S4_2_2_visit[2]  R2972     -23
    e2_S4_2_2_visit[2]  R2973     -2
    e2_S4_2_2_visit[2]  R2974     -2
    e2_S4_2_2_visit[2]  R2976     -23
    e2_S4_2_2_visit[2]  R2977     -23
    e2_S4_2_2_visit[2]  R2978     -2
    e2_S4_2_2_visit[2]  R2979     -2
    e2_S4_2_2_visit[2]  R2981     -23
    e2_S4_2_2_visit[2]  R2982     -23
    e2_S4_2_2_visit[2]  R2983     -2
    e2_S4_2_2_visit[2]  R2984     -2
    e2_S4_2_2_visit[2]  R2986     -23
    e2_S4_2_2_visit[2]  R2987     -23
    e2_S4_2_2_visit[2]  R2988     -2
    e2_S4_2_2_visit[2]  R2989     -2
    e2_S4_2_2_visit[2]  R2991     -23
    e2_S4_2_2_visit[2]  R2992     -23
    e2_S4_2_2_visit[2]  R2993     -2
    e2_S4_2_2_visit[2]  R2994     -2
    e2_S4_2_2_visit[2]  R2996     -23
    e2_S4_2_2_visit[2]  R2997     -23
    e2_S4_2_2_visit[2]  R2998     -2
    e2_S4_2_2_visit[2]  R2999     -2
    e2_S4_2_2_visit[2]  R3015     -1
    e2_S4_2_2_visit[2]  R3017     23
    e2_S4_2_2_visit[2]  R3018     2
    e2_S4_2_2_visit[2]  R3030     1
    e2_S4_2_2_visit[2]  R3149     -18
    e2_S4_2_2_visit[2]  R3417     1
    e2_S4_2_2_visit[3]  R2918     4
    e2_S4_2_2_visit[3]  R2919     2
    e2_S4_2_2_visit[3]  R2929     -1
    e2_S4_2_2_visit[3]  R2930     -1
    e2_S4_2_2_visit[3]  R2931     1
    e2_S4_2_2_visit[3]  R3031     -38031
    e2_S4_2_2_visit[3]  R3032     71100
    e2_S4_2_2_visit[3]  R3152     -18
    e2_S4_2_2_visit[3]  R3418     1
    e2_S4_2_2_visit[4]  R2916     21
    e2_S4_2_2_visit[4]  R2917     2
    e2_S4_2_2_visit[4]  R2932     -1
    e2_S4_2_2_visit[4]  R2933     -1
    e2_S4_2_2_visit[4]  R2934     1
    e2_S4_2_2_visit[4]  R2951     -21
    e2_S4_2_2_visit[4]  R2952     -21
    e2_S4_2_2_visit[4]  R2953     -2
    e2_S4_2_2_visit[4]  R2954     -2
    e2_S4_2_2_visit[4]  R2956     -21
    e2_S4_2_2_visit[4]  R2957     -21
    e2_S4_2_2_visit[4]  R2958     -2
    e2_S4_2_2_visit[4]  R2959     -2
    e2_S4_2_2_visit[4]  R2961     -21
    e2_S4_2_2_visit[4]  R2962     -21
    e2_S4_2_2_visit[4]  R2963     -2
    e2_S4_2_2_visit[4]  R2964     -2
    e2_S4_2_2_visit[4]  R2966     -21
    e2_S4_2_2_visit[4]  R2967     -21
    e2_S4_2_2_visit[4]  R2968     -2
    e2_S4_2_2_visit[4]  R2969     -2
    e2_S4_2_2_visit[4]  R2971     -21
    e2_S4_2_2_visit[4]  R2972     -21
    e2_S4_2_2_visit[4]  R2973     -2
    e2_S4_2_2_visit[4]  R2974     -2
    e2_S4_2_2_visit[4]  R2976     -21
    e2_S4_2_2_visit[4]  R2977     -21
    e2_S4_2_2_visit[4]  R2978     -2
    e2_S4_2_2_visit[4]  R2979     -2
    e2_S4_2_2_visit[4]  R2981     -21
    e2_S4_2_2_visit[4]  R2982     -21
    e2_S4_2_2_visit[4]  R2983     -2
    e2_S4_2_2_visit[4]  R2984     -2
    e2_S4_2_2_visit[4]  R2986     -21
    e2_S4_2_2_visit[4]  R2987     -21
    e2_S4_2_2_visit[4]  R2988     -2
    e2_S4_2_2_visit[4]  R2989     -2
    e2_S4_2_2_visit[4]  R2991     -21
    e2_S4_2_2_visit[4]  R2992     -21
    e2_S4_2_2_visit[4]  R2993     -2
    e2_S4_2_2_visit[4]  R2994     -2
    e2_S4_2_2_visit[4]  R2996     -21
    e2_S4_2_2_visit[4]  R2997     -21
    e2_S4_2_2_visit[4]  R2998     -2
    e2_S4_2_2_visit[4]  R2999     -2
    e2_S4_2_2_visit[4]  R3019     -1
    e2_S4_2_2_visit[4]  R3021     21
    e2_S4_2_2_visit[4]  R3022     2
    e2_S4_2_2_visit[4]  R3033     1
    e2_S4_2_2_visit[4]  R3155     -18
    e2_S4_2_2_visit[4]  R3421     1
    e2_S4_2_2_visit[5]  R2918     4
    e2_S4_2_2_visit[5]  R2919     2
    e2_S4_2_2_visit[5]  R2935     -1
    e2_S4_2_2_visit[5]  R2936     -1
    e2_S4_2_2_visit[5]  R2937     1
    e2_S4_2_2_visit[5]  R3034     -25749
    e2_S4_2_2_visit[5]  R3035     71100
    e2_S4_2_2_visit[5]  R3158     -18
    e2_S4_2_2_visit[5]  R3422     1
    e2_S4_2_2_visit[6]  R2916     23
    e2_S4_2_2_visit[6]  R2917     2
    e2_S4_2_2_visit[6]  R2938     -1
    e2_S4_2_2_visit[6]  R2939     -1
    e2_S4_2_2_visit[6]  R2940     1
    e2_S4_2_2_visit[6]  R2951     -23
    e2_S4_2_2_visit[6]  R2952     -23
    e2_S4_2_2_visit[6]  R2953     -2
    e2_S4_2_2_visit[6]  R2954     -2
    e2_S4_2_2_visit[6]  R2956     -23
    e2_S4_2_2_visit[6]  R2957     -23
    e2_S4_2_2_visit[6]  R2958     -2
    e2_S4_2_2_visit[6]  R2959     -2
    e2_S4_2_2_visit[6]  R2961     -23
    e2_S4_2_2_visit[6]  R2962     -23
    e2_S4_2_2_visit[6]  R2963     -2
    e2_S4_2_2_visit[6]  R2964     -2
    e2_S4_2_2_visit[6]  R2966     -23
    e2_S4_2_2_visit[6]  R2967     -23
    e2_S4_2_2_visit[6]  R2968     -2
    e2_S4_2_2_visit[6]  R2969     -2
    e2_S4_2_2_visit[6]  R2971     -23
    e2_S4_2_2_visit[6]  R2972     -23
    e2_S4_2_2_visit[6]  R2973     -2
    e2_S4_2_2_visit[6]  R2974     -2
    e2_S4_2_2_visit[6]  R2976     -23
    e2_S4_2_2_visit[6]  R2977     -23
    e2_S4_2_2_visit[6]  R2978     -2
    e2_S4_2_2_visit[6]  R2979     -2
    e2_S4_2_2_visit[6]  R2981     -23
    e2_S4_2_2_visit[6]  R2982     -23
    e2_S4_2_2_visit[6]  R2983     -2
    e2_S4_2_2_visit[6]  R2984     -2
    e2_S4_2_2_visit[6]  R2986     -23
    e2_S4_2_2_visit[6]  R2987     -23
    e2_S4_2_2_visit[6]  R2988     -2
    e2_S4_2_2_visit[6]  R2989     -2
    e2_S4_2_2_visit[6]  R2991     -23
    e2_S4_2_2_visit[6]  R2992     -23
    e2_S4_2_2_visit[6]  R2993     -2
    e2_S4_2_2_visit[6]  R2994     -2
    e2_S4_2_2_visit[6]  R2996     -23
    e2_S4_2_2_visit[6]  R2997     -23
    e2_S4_2_2_visit[6]  R2998     -2
    e2_S4_2_2_visit[6]  R2999     -2
    e2_S4_2_2_visit[6]  R3019     -1
    e2_S4_2_2_visit[6]  R3021     23
    e2_S4_2_2_visit[6]  R3022     2
    e2_S4_2_2_visit[6]  R3036     1
    e2_S4_2_2_visit[6]  R3161     -18
    e2_S4_2_2_visit[6]  R3425     1
    e2_S4_2_2_visit[7]  R2918     4
    e2_S4_2_2_visit[7]  R2919     2
    e2_S4_2_2_visit[7]  R2941     -1
    e2_S4_2_2_visit[7]  R2942     -1
    e2_S4_2_2_visit[7]  R2943     1
    e2_S4_2_2_visit[7]  R3037     -23969
    e2_S4_2_2_visit[7]  R3038     71100
    e2_S4_2_2_visit[7]  R3164     -18
    e2_S4_2_2_visit[7]  R3426     1
    e2_S4_2_2_visit[8]  R2916     21
    e2_S4_2_2_visit[8]  R2917     2
    e2_S4_2_2_visit[8]  R2944     -1
    e2_S4_2_2_visit[8]  R2945     -1
    e2_S4_2_2_visit[8]  R2946     1
    e2_S4_2_2_visit[8]  R2951     -21
    e2_S4_2_2_visit[8]  R2952     -21
    e2_S4_2_2_visit[8]  R2953     -2
    e2_S4_2_2_visit[8]  R2954     -2
    e2_S4_2_2_visit[8]  R2956     -21
    e2_S4_2_2_visit[8]  R2957     -21
    e2_S4_2_2_visit[8]  R2958     -2
    e2_S4_2_2_visit[8]  R2959     -2
    e2_S4_2_2_visit[8]  R2961     -21
    e2_S4_2_2_visit[8]  R2962     -21
    e2_S4_2_2_visit[8]  R2963     -2
    e2_S4_2_2_visit[8]  R2964     -2
    e2_S4_2_2_visit[8]  R2966     -21
    e2_S4_2_2_visit[8]  R2967     -21
    e2_S4_2_2_visit[8]  R2968     -2
    e2_S4_2_2_visit[8]  R2969     -2
    e2_S4_2_2_visit[8]  R2971     -21
    e2_S4_2_2_visit[8]  R2972     -21
    e2_S4_2_2_visit[8]  R2973     -2
    e2_S4_2_2_visit[8]  R2974     -2
    e2_S4_2_2_visit[8]  R2976     -21
    e2_S4_2_2_visit[8]  R2977     -21
    e2_S4_2_2_visit[8]  R2978     -2
    e2_S4_2_2_visit[8]  R2979     -2
    e2_S4_2_2_visit[8]  R2981     -21
    e2_S4_2_2_visit[8]  R2982     -21
    e2_S4_2_2_visit[8]  R2983     -2
    e2_S4_2_2_visit[8]  R2984     -2
    e2_S4_2_2_visit[8]  R2986     -21
    e2_S4_2_2_visit[8]  R2987     -21
    e2_S4_2_2_visit[8]  R2988     -2
    e2_S4_2_2_visit[8]  R2989     -2
    e2_S4_2_2_visit[8]  R2991     -21
    e2_S4_2_2_visit[8]  R2992     -21
    e2_S4_2_2_visit[8]  R2993     -2
    e2_S4_2_2_visit[8]  R2994     -2
    e2_S4_2_2_visit[8]  R2996     -21
    e2_S4_2_2_visit[8]  R2997     -21
    e2_S4_2_2_visit[8]  R2998     -2
    e2_S4_2_2_visit[8]  R2999     -2
    e2_S4_2_2_visit[8]  R3023     -1
    e2_S4_2_2_visit[8]  R3025     21
    e2_S4_2_2_visit[8]  R3026     2
    e2_S4_2_2_visit[8]  R3039     1
    e2_S4_2_2_visit[8]  R3167     -18
    e2_S4_2_2_visit[8]  R3429     1
    e2_S4_2_2_visit[9]  R2918     4
    e2_S4_2_2_visit[9]  R2919     2
    e2_S4_2_2_visit[9]  R2947     -1
    e2_S4_2_2_visit[9]  R2948     -1
    e2_S4_2_2_visit[9]  R2949     1
    e2_S4_2_2_visit[9]  R3040     -11425
    e2_S4_2_2_visit[9]  R3041     71100
    e2_S4_2_2_visit[9]  R3170     -18
    e2_S4_2_2_visit[9]  R3430     1
    e2_S4_2_2_arc[-1,0]  OBJ       1.4142135623730951e+00
    e2_S4_2_2_arc[-1,0]  R2914     1
    e2_S4_2_2_arc[-1,0]  R2920     1
    e2_S4_2_2_arc[-1,0]  R2950     -44319
    e2_S4_2_2_arc[-1,0]  R2951     -165
    e2_S4_2_2_arc[-1,0]  R2952     180
    e2_S4_2_2_arc[-1,0]  R2953     -5
    e2_S4_2_2_arc[-1,0]  R2954     6
    e2_S4_2_2_arc[-1,0]  R3042     -30
    e2_S4_2_2_arc[-1,0]  R3144     1
    e2_S4_2_2_arc[-1,1]  OBJ       1.4142135623730951e+00
    e2_S4_2_2_arc[-1,1]  R2914     1
    e2_S4_2_2_arc[-1,1]  R2923     1
    e2_S4_2_2_arc[-1,1]  R2955     -41683
    e2_S4_2_2_arc[-1,1]  R2956     -180
    e2_S4_2_2_arc[-1,1]  R2957     178
    e2_S4_2_2_arc[-1,1]  R2958     -6
    e2_S4_2_2_arc[-1,1]  R2959     5
    e2_S4_2_2_arc[-1,1]  R3043     -30
    e2_S4_2_2_arc[-1,1]  R3147     1
    e2_S4_2_2_arc[-1,2]  OBJ       3.8275318418009277e+01
    e2_S4_2_2_arc[-1,2]  R2914     1
    e2_S4_2_2_arc[-1,2]  R2926     1
    e2_S4_2_2_arc[-1,2]  R2960     -44289
    e2_S4_2_2_arc[-1,2]  R2961     -157
    e2_S4_2_2_arc[-1,2]  R2962     180
    e2_S4_2_2_arc[-1,2]  R2963     -4
    e2_S4_2_2_arc[-1,2]  R2964     6
    e2_S4_2_2_arc[-1,2]  R3044     -30
    e2_S4_2_2_arc[-1,2]  R3150     1
    e2_S4_2_2_arc[-1,3]  OBJ       3.8275318418009277e+01
    e2_S4_2_2_arc[-1,3]  R2914     1
    e2_S4_2_2_arc[-1,3]  R2929     1
    e2_S4_2_2_arc[-1,3]  R2965     -40989
    e2_S4_2_2_arc[-1,3]  R2966     -180
    e2_S4_2_2_arc[-1,3]  R2967     176
    e2_S4_2_2_arc[-1,3]  R2968     -6
    e2_S4_2_2_arc[-1,3]  R2969     4
    e2_S4_2_2_arc[-1,3]  R3045     -30
    e2_S4_2_2_arc[-1,3]  R3153     1
    e2_S4_2_2_arc[-1,4]  OBJ       8.48528137423857
    e2_S4_2_2_arc[-1,4]  R2914     1
    e2_S4_2_2_arc[-1,4]  R2932     1
    e2_S4_2_2_arc[-1,4]  R2970     -29919
    e2_S4_2_2_arc[-1,4]  R2971     -159
    e2_S4_2_2_arc[-1,4]  R2972     180
    e2_S4_2_2_arc[-1,4]  R2973     -4
    e2_S4_2_2_arc[-1,4]  R2974     6
    e2_S4_2_2_arc[-1,4]  R3046     -30
    e2_S4_2_2_arc[-1,4]  R3156     1
    e2_S4_2_2_arc[-1,5]  OBJ       8.48528137423857
    e2_S4_2_2_arc[-1,5]  R2914     1
    e2_S4_2_2_arc[-1,5]  R2935     1
    e2_S4_2_2_arc[-1,5]  R2975     -26919
    e2_S4_2_2_arc[-1,5]  R2976     -180
    e2_S4_2_2_arc[-1,5]  R2977     176
    e2_S4_2_2_arc[-1,5]  R2978     -6
    e2_S4_2_2_arc[-1,5]  R2979     4
    e2_S4_2_2_arc[-1,5]  R3047     -30
    e2_S4_2_2_arc[-1,5]  R3159     1
    e2_S4_2_2_arc[-1,6]  OBJ       1.7029386365926403e+01
    e2_S4_2_2_arc[-1,6]  R2914     1
    e2_S4_2_2_arc[-1,6]  R2938     1
    e2_S4_2_2_arc[-1,6]  R2980     -29851
    e2_S4_2_2_arc[-1,6]  R2981     -157
    e2_S4_2_2_arc[-1,6]  R2982     180
    e2_S4_2_2_arc[-1,6]  R2983     -4
    e2_S4_2_2_arc[-1,6]  R2984     6
    e2_S4_2_2_arc[-1,6]  R3048     -30
    e2_S4_2_2_arc[-1,6]  R3162     1
    e2_S4_2_2_arc[-1,7]  OBJ       1.7029386365926403e+01
    e2_S4_2_2_arc[-1,7]  R2914     1
    e2_S4_2_2_arc[-1,7]  R2941     1
    e2_S4_2_2_arc[-1,7]  R2985     -25651
    e2_S4_2_2_arc[-1,7]  R2986     -180
    e2_S4_2_2_arc[-1,7]  R2987     176
    e2_S4_2_2_arc[-1,7]  R2988     -6
    e2_S4_2_2_arc[-1,7]  R2989     4
    e2_S4_2_2_arc[-1,7]  R3049     -30
    e2_S4_2_2_arc[-1,7]  R3165     1
    e2_S4_2_2_arc[-1,8]  OBJ       1.7204650534085253e+01
    e2_S4_2_2_arc[-1,8]  R2914     1
    e2_S4_2_2_arc[-1,8]  R2944     1
    e2_S4_2_2_arc[-1,8]  R2990     -15519
    e2_S4_2_2_arc[-1,8]  R2991     -159
    e2_S4_2_2_arc[-1,8]  R2992     180
    e2_S4_2_2_arc[-1,8]  R2993     -4
    e2_S4_2_2_arc[-1,8]  R2994     6
    e2_S4_2_2_arc[-1,8]  R3050     -30
    e2_S4_2_2_arc[-1,8]  R3168     1
    e2_S4_2_2_arc[-1,9]  OBJ       1.7204650534085253e+01
    e2_S4_2_2_arc[-1,9]  R2914     1
    e2_S4_2_2_arc[-1,9]  R2947     1
    e2_S4_2_2_arc[-1,9]  R2995     -13119
    e2_S4_2_2_arc[-1,9]  R2996     -180
    e2_S4_2_2_arc[-1,9]  R2997     176
    e2_S4_2_2_arc[-1,9]  R2998     -6
    e2_S4_2_2_arc[-1,9]  R2999     4
    e2_S4_2_2_arc[-1,9]  R3051     -30
    e2_S4_2_2_arc[-1,9]  R3171     1
    e2_S4_2_2_arc[0,-2]  OBJ       1.4142135623730951e+00
    e2_S4_2_2_arc[0,-2]  R2915     1
    e2_S4_2_2_arc[0,-2]  R2921     1
    e2_S4_2_2_arc[0,-2]  R3000     -33523
    e2_S4_2_2_arc[0,-2]  R3052     -30
    e2_S4_2_2_arc[0,-2]  R3145     1
    e2_S4_2_2_arc[1,-2]  OBJ       1.4142135623730951e+00
    e2_S4_2_2_arc[1,-2]  R2915     1
    e2_S4_2_2_arc[1,-2]  R2924     1
    e2_S4_2_2_arc[1,-2]  R3001     -39223
    e2_S4_2_2_arc[1,-2]  R3053     -30
    e2_S4_2_2_arc[1,-2]  R3148     1
    e2_S4_2_2_arc[2,-2]  OBJ       3.8275318418009277e+01
    e2_S4_2_2_arc[2,-2]  R2915     1
    e2_S4_2_2_arc[2,-2]  R2927     1
    e2_S4_2_2_arc[2,-2]  R3002     -36369
    e2_S4_2_2_arc[2,-2]  R3054     -30
    e2_S4_2_2_arc[2,-2]  R3151     1
    e2_S4_2_2_arc[3,-2]  OBJ       3.8275318418009277e+01
    e2_S4_2_2_arc[3,-2]  R2915     1
    e2_S4_2_2_arc[3,-2]  R2930     1
    e2_S4_2_2_arc[3,-2]  R3003     -42129
    e2_S4_2_2_arc[3,-2]  R3055     -30
    e2_S4_2_2_arc[3,-2]  R3154     1
    e2_S4_2_2_arc[4,-2]  OBJ       8.48528137423857
    e2_S4_2_2_arc[4,-2]  R2915     1
    e2_S4_2_2_arc[4,-2]  R2933     1
    e2_S4_2_2_arc[4,-2]  R3004     -48315
    e2_S4_2_2_arc[4,-2]  R3056     -30
    e2_S4_2_2_arc[4,-2]  R3157     1
    e2_S4_2_2_arc[5,-2]  OBJ       8.48528137423857
    e2_S4_2_2_arc[5,-2]  R2915     1
    e2_S4_2_2_arc[5,-2]  R2936     1
    e2_S4_2_2_arc[5,-2]  R3005     -53475
    e2_S4_2_2_arc[5,-2]  R3057     -30
    e2_S4_2_2_arc[5,-2]  R3160     1
    e2_S4_2_2_arc[6,-2]  OBJ       1.7029386365926403e+01
    e2_S4_2_2_arc[6,-2]  R2915     1
    e2_S4_2_2_arc[6,-2]  R2939     1
    e2_S4_2_2_arc[6,-2]  R3006     -49531
    e2_S4_2_2_arc[6,-2]  R3058     -30
    e2_S4_2_2_arc[6,-2]  R3163     1
    e2_S4_2_2_arc[7,-2]  OBJ       1.7029386365926403e+01
    e2_S4_2_2_arc[7,-2]  R2915     1
    e2_S4_2_2_arc[7,-2]  R2942     1
    e2_S4_2_2_arc[7,-2]  R3007     -56191
    e2_S4_2_2_arc[7,-2]  R3059     -30
    e2_S4_2_2_arc[7,-2]  R3166     1
    e2_S4_2_2_arc[8,-2]  OBJ       1.7204650534085253e+01
    e2_S4_2_2_arc[8,-2]  R2915     1
    e2_S4_2_2_arc[8,-2]  R2945     1
    e2_S4_2_2_arc[8,-2]  R3008     -63217
    e2_S4_2_2_arc[8,-2]  R3060     -30
    e2_S4_2_2_arc[8,-2]  R3169     1
    e2_S4_2_2_arc[9,-2]  OBJ       1.7204650534085253e+01
    e2_S4_2_2_arc[9,-2]  R2915     1
    e2_S4_2_2_arc[9,-2]  R2948     1
    e2_S4_2_2_arc[9,-2]  R3009     -68677
    e2_S4_2_2_arc[9,-2]  R3061     -30
    e2_S4_2_2_arc[9,-2]  R3172     1
    MARKER    'MARKER'                 'INTEND'
    C1187     R3012     1
    C1187     R3042     -1
    C1187     R3043     -1
    C1187     R3044     -1
    C1187     R3045     -1
    C1187     R3046     -1
    C1187     R3047     -1
    C1187     R3048     -1
    C1187     R3049     -1
    C1187     R3050     -1
    C1187     R3051     -1
    C1188     R3052     1
    C1188     R3053     1
    C1188     R3054     1
    C1188     R3055     1
    C1188     R3056     1
    C1188     R3057     1
    C1188     R3058     1
    C1188     R3059     1
    C1188     R3060     1
    C1188     R3061     1
    MARKER    'MARKER'                 'INTORG'
    C1189     R3013     1
    C1189     R3014     -60
    C1189     R3015     1
    C1189     R3016     -39660
    C1189     R3017     -180
    C1189     R3018     -6
    C1189     R3027     -1
    C1189     R3030     -1
    C1190     R3013     1
    C1190     R3014     -60
    C1190     R3019     1
    C1190     R3020     -54060
    C1190     R3021     -180
    C1190     R3022     -6
    C1190     R3033     -1
    C1190     R3036     -1
    C1191     R3013     1
    C1191     R3014     -60
    C1191     R3023     1
    C1191     R3024     -71160
    C1191     R3025     -180
    C1191     R3026     -6
    C1191     R3039     -1
    MARKER    'MARKER'                 'INTEND'
    m5_route_0  R3063     1
    m5_route_0  R3064     -1
    m5_route_0  R3065     1
    m5_route_0  R3066     -1
    m5_route_0  R3067     1
    m5_route_0  R3068     -1
    m5_route_0  R3069     1
    m5_route_0  R3070     -1
    m5_route_0  R3071     1
    m5_route_0  R3072     -1
    m5_route_0  R3073     1
    m5_route_0  R3074     -1
    m5_route_0  R3143     1
    m5_route_1  R3063     -1
    m5_route_1  R3064     1
    m5_route_1  R3075     1
    m5_route_1  R3076     -1
    m5_route_1  R3077     1
    m5_route_1  R3078     -1
    m5_route_1  R3079     1
    m5_route_1  R3080     -1
    m5_route_1  R3081     1
    m5_route_1  R3082     -1
    m5_route_1  R3083     1
    m5_route_1  R3084     -1
    m5_route_1  R3085     1
    m5_route_1  R3086     -1
    m5_route_1  R3087     1
    m5_route_1  R3088     -1
    m5_route_1  R3089     -1
    m5_route_1  R3090     1
    m5_route_1  R3099     -1
    m5_route_1  R3100     1
    m5_route_1  R3146     1
    m5_route_2  R3065     -1
    m5_route_2  R3066     1
    m5_route_2  R3089     1
    m5_route_2  R3090     -1
    m5_route_2  R3091     1
    m5_route_2  R3092     -1
    m5_route_2  R3093     1
    m5_route_2  R3094     -1
    m5_route_2  R3095     1
    m5_route_2  R3096     -1
    m5_route_2  R3097     1
    m5_route_2  R3098     -1
    m5_route_2  R3149     1
    m5_route_3  R3067     -1
    m5_route_3  R3068     1
    m5_route_3  R3075     -1
    m5_route_3  R3076     1
    m5_route_3  R3091     -1
    m5_route_3  R3092     1
    m5_route_3  R3099     1
    m5_route_3  R3100     -1
    m5_route_3  R3101     1
    m5_route_3  R3102     -1
    m5_route_3  R3103     1
    m5_route_3  R3104     -1
    m5_route_3  R3105     1
    m5_route_3  R3106     -1
    m5_route_3  R3107     1
    m5_route_3  R3108     -1
    m5_route_3  R3109     1
    m5_route_3  R3110     -1
    m5_route_3  R3111     1
    m5_route_3  R3112     -1
    m5_route_3  R3152     1
    m5_route_4  R3077     -1
    m5_route_4  R3078     1
    m5_route_4  R3101     -1
    m5_route_4  R3102     1
    m5_route_4  R3113     1
    m5_route_4  R3114     -1
    m5_route_4  R3115     1
    m5_route_4  R3116     -1
    m5_route_4  R3117     1
    m5_route_4  R3118     -1
    m5_route_4  R3119     1
    m5_route_4  R3120     -1
    m5_route_4  R3127     -1
    m5_route_4  R3128     1
    m5_route_4  R3155     1
    m5_route_5  R3069     -1
    m5_route_5  R3070     1
    m5_route_5  R3079     -1
    m5_route_5  R3080     1
    m5_route_5  R3093     -1
    m5_route_5  R3094     1
    m5_route_5  R3103     -1
    m5_route_5  R3104     1
    m5_route_5  R3113     -1
    m5_route_5  R3114     1
    m5_route_5  R3121     1
    m5_route_5  R3122     -1
    m5_route_5  R3123     1
    m5_route_5  R3124     -1
    m5_route_5  R3125     1
    m5_route_5  R3126     -1
    m5_route_5  R3129     -1
    m5_route_5  R3130     1
    m5_route_5  R3135     -1
    m5_route_5  R3136     1
    m5_route_5  R3158     1
    m5_route_6  R3081     -1
    m5_route_6  R3082     1
    m5_route_6  R3105     -1
    m5_route_6  R3106     1
    m5_route_6  R3115     -1
    m5_route_6  R3116     1
    m5_route_6  R3127     1
    m5_route_6  R3128     -1
    m5_route_6  R3129     1
    m5_route_6  R3130     -1
    m5_route_6  R3131     1
    m5_route_6  R3132     -1
    m5_route_6  R3133     1
    m5_route_6  R3134     -1
    m5_route_6  R3161     1
    m5_route_7  R3071     -1
    m5_route_7  R3072     1
    m5_route_7  R3083     -1
    m5_route_7  R3084     1
    m5_route_7  R3095     -1
    m5_route_7  R3096     1
    m5_route_7  R3107     -1
    m5_route_7  R3108     1
    m5_route_7  R3117     -1
    m5_route_7  R3118     1
    m5_route_7  R3121     -1
    m5_route_7  R3122     1
    m5_route_7  R3131     -1
    m5_route_7  R3132     1
    m5_route_7  R3135     1
    m5_route_7  R3136     -1
    m5_route_7  R3137     1
    m5_route_7  R3138     -1
    m5_route_7  R3139     1
    m5_route_7  R3140     -1
    m5_route_7  R3164     1
    m5_route_8  R3085     -1
    m5_route_8  R3086     1
    m5_route_8  R3109     -1
    m5_route_8  R3110     1
    m5_route_8  R3123     -1
    m5_route_8  R3124     1
    m5_route_8  R3137     -1
    m5_route_8  R3138     1
    m5_route_8  R3141     1
    m5_route_8  R3142     -1
    m5_route_8  R3167     1
    m5_route_9  R3073     -1
    m5_route_9  R3074     1
    m5_route_9  R3087     -1
    m5_route_9  R3088     1
    m5_route_9  R3097     -1
    m5_route_9  R3098     1
    m5_route_9  R3111     -1
    m5_route_9  R3112     1
    m5_route_9  R3119     -1
    m5_route_9  R3120     1
    m5_route_9  R3125     -1
    m5_route_9  R3126     1
    m5_route_9  R3133     -1
    m5_route_9  R3134     1
    m5_route_9  R3139     -1
    m5_route_9  R3140     1
    m5_route_9  R3141     -1
    m5_route_9  R3142     1
    m5_route_9  R3170     1
    MARKER    'MARKER'                 'INTORG'
    C1202     R3453     -9
    C1203     OBJ       0
    C1204     R3453     1
    C1204     clean_stock_b1  1
    C1205     R3457     -9
    C1206     OBJ       0
    C1207     R3457     1
    C1207     clean_stock_b1  1
    C1208     R3461     -9
    C1209     OBJ       0
    C1210     R3461     1
    C1210     clean_stock_b1  1
    C1211     R3465     -9
    C1212     OBJ       0
    C1213     R3465     1
    C1213     clean_stock_b1  1
    C1214     R3469     -9
    C1215     OBJ       0
    C1216     R3469     1
    C1216     clean_stock_b1  1
    C1217     R3473     -9
    C1218     OBJ       0
    C1219     R3473     1
    C1219     clean_stock_b1  1
    C1220     R3477     -9
    C1221     OBJ       0
    C1222     R3477     1
    C1222     clean_stock_b1  1
    C1223     R3481     -9
    C1224     OBJ       0
    C1225     R3481     1
    C1225     clean_stock_b1  1
    C1226     R3485     -9
    C1227     OBJ       0
    C1228     R3485     1
    C1228     clean_stock_b1  1
    C1229     R3490     -9
    C1230     OBJ       0
    C1231     R3490     1
    C1231     clean_stock_b2  1
    C1232     R3494     -9
    C1233     OBJ       0
    C1234     R3494     1
    C1234     clean_stock_b2  1
    C1235     R3498     -9
    C1236     OBJ       0
    C1237     R3498     1
    C1237     clean_stock_b2  1
    C1238     R3502     -9
    C1239     OBJ       0
    C1240     R3502     1
    C1240     clean_stock_b2  1
    C1241     R3506     -9
    C1242     OBJ       0
    C1243     R3506     1
    C1243     clean_stock_b2  1
    C1244     R3510     -9
    C1245     OBJ       0
    C1246     R3510     1
    C1246     clean_stock_b2  1
    C1247     R3514     -9
    C1248     OBJ       0
    C1249     R3514     1
    C1249     clean_stock_b2  1
    C1250     R3518     -9
    C1251     OBJ       0
    C1252     R3518     1
    C1252     clean_stock_b2  1
    C1253     R3522     -9
    C1254     OBJ       0
    C1255     R3522     1
    C1255     clean_stock_b2  1
    C1256     R3527     -9
    C1257     OBJ       0
    C1258     R3527     1
    C1258     clean_stock_b3  1
    C1259     R3531     -9
    C1260     OBJ       0
    C1261     R3531     1
    C1261     clean_stock_b3  1
    C1262     R3535     -9
    C1263     OBJ       0
    C1264     R3535     1
    C1264     clean_stock_b3  1
    C1265     R3539     -9
    C1266     OBJ       0
    C1267     R3539     1
    C1267     clean_stock_b3  1
    C1268     R3543     -9
    C1269     OBJ       0
    C1270     R3543     1
    C1270     clean_stock_b3  1
    C1271     R3547     -9
    C1272     OBJ       0
    C1273     R3547     1
    C1273     clean_stock_b3  1
    C1274     R3551     -9
    C1275     OBJ       0
    C1276     R3551     1
    C1276     clean_stock_b3  1
    C1277     R3555     -9
    C1278     OBJ       0
    C1279     R3555     1
    C1279     clean_stock_b3  1
    C1280     R3559     -9
    C1281     OBJ       0
    C1282     R3559     1
    C1282     clean_stock_b3  1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      R327      703
    RHS1      R328      71100
    RHS1      R329      39601
    RHS1      R331      71100
    RHS1      R332      54001
    RHS1      R334      1809
    RHS1      R335      71100
    RHS1      R336      39601
    RHS1      R338      71100
    RHS1      R339      54001
    RHS1      R341      915
    RHS1      R342      71100
    RHS1      R343      54001
    RHS1      R345      1171
    RHS1      R346      71100
    RHS1      R347      54001
    RHS1      R349      1177
    RHS1      R389      -44276
    RHS1      R390      -180
    RHS1      R391      165
    RHS1      R392      -6
    RHS1      R393      5
    RHS1      R394      -41640
    RHS1      R395      -178
    RHS1      R396      180
    RHS1      R397      -5
    RHS1      R398      6
    RHS1      R399      -43140
    RHS1      R400      -180
    RHS1      R401      157
    RHS1      R402      -6
    RHS1      R403      4
    RHS1      R404      -39840
    RHS1      R405      -176
    RHS1      R406      180
    RHS1      R407      -4
    RHS1      R408      6
    RHS1      R409      -29664
    RHS1      R410      -180
    RHS1      R411      159
    RHS1      R412      -6
    RHS1      R413      4
    RHS1      R414      -26664
    RHS1      R415      -176
    RHS1      R416      180
    RHS1      R417      -4
    RHS1      R418      6
    RHS1      R419      -29340
    RHS1      R420      -180
    RHS1      R421      157
    RHS1      R422      -6
    RHS1      R423      4
    RHS1      R424      -25140
    RHS1      R425      -176
    RHS1      R426      180
    RHS1      R427      -4
    RHS1      R428      6
    RHS1      R429      -15002
    RHS1      R430      -180
    RHS1      R431      159
    RHS1      R432      -6
    RHS1      R433      4
    RHS1      R434      -12602
    RHS1      R435      -176
    RHS1      R436      180
    RHS1      R437      -4
    RHS1      R438      6
    RHS1      R439      -32820
    RHS1      R440      -38520
    RHS1      R441      -34560
    RHS1      R442      -40320
    RHS1      R443      -47400
    RHS1      R444      -52560
    RHS1      R445      -48360
    RHS1      R446      -55020
    RHS1      R447      -62040
    RHS1      R448      -67500
    RHS1      R452      -39600
    RHS1      R456      -54000
    RHS1      R460      -71100
    RHS1      R464      -40937
    RHS1      R465      71100
    RHS1      R467      -38031
    RHS1      R468      71100
    RHS1      R470      -25749
    RHS1      R471      71100
    RHS1      R473      -23969
    RHS1      R474      71100
    RHS1      R476      -11425
    RHS1      R477      71100
    RHS1      R478      -29
    RHS1      R479      -29
    RHS1      R480      -29
    RHS1      R481      -29
    RHS1      R482      -29
    RHS1      R483      -29
    RHS1      R484      -29
    RHS1      R485      -29
    RHS1      R486      -29
    RHS1      R487      -29
    RHS1      R488      -29
    RHS1      R489      -29
    RHS1      R490      -29
    RHS1      R491      -29
    RHS1      R492      -29
    RHS1      R493      -29
    RHS1      R494      -29
    RHS1      R495      -29
    RHS1      R496      -29
    RHS1      R497      -29
    RHS1      R537      -44276
    RHS1      R538      -180
    RHS1      R539      165
    RHS1      R540      -6
    RHS1      R541      5
    RHS1      R542      -41640
    RHS1      R543      -178
    RHS1      R544      180
    RHS1      R545      -5
    RHS1      R546      6
    RHS1      R547      -43140
    RHS1      R548      -180
    RHS1      R549      157
    RHS1      R550      -6
    RHS1      R551      4
    RHS1      R552      -39840
    RHS1      R553      -176
    RHS1      R554      180
    RHS1      R555      -4
    RHS1      R556      6
    RHS1      R557      -29664
    RHS1      R558      -180
    RHS1      R559      159
    RHS1      R560      -6
    RHS1      R561      4
    RHS1      R562      -26664
    RHS1      R563      -176
    RHS1      R564      180
    RHS1      R565      -4
    RHS1      R566      6
    RHS1      R567      -29340
    RHS1      R568      -180
    RHS1      R569      157
    RHS1      R570      -6
    RHS1      R571      4
    RHS1      R572      -25140
    RHS1      R573      -176
    RHS1      R574      180
    RHS1      R575      -4
    RHS1      R576      6
    RHS1      R577      -15002
    RHS1      R578      -180
    RHS1      R579      159
    RHS1      R580      -6
    RHS1      R581      4
    RHS1      R582      -12602
    RHS1      R583      -176
    RHS1      R584      180
    RHS1      R585      -4
    RHS1      R586      6
    RHS1      R587      -32820
    RHS1      R588      -38520
    RHS1      R589      -34560
    RHS1      R590      -40320
    RHS1      R591      -47400
    RHS1      R592      -52560
    RHS1      R593      -48360
    RHS1      R594      -55020
    RHS1      R595      -62040
    RHS1      R596      -67500
    RHS1      R599      -29
    RHS1      R601      -75540
    RHS1      R603      -39600
    RHS1      R607      -54000
    RHS1      R611      -71100
    RHS1      R615      -40937
    RHS1      R616      71100
    RHS1      R618      -38031
    RHS1      R619      71100
    RHS1      R621      -25749
    RHS1      R622      71100
    RHS1      R624      -23969
    RHS1      R625      71100
    RHS1      R627      -11425
    RHS1      R628      71100
    RHS1      R629      -29
    RHS1      R630      -29
    RHS1      R631      -29
    RHS1      R632      -29
    RHS1      R633      -29
    RHS1      R634      -29
    RHS1      R635      -29
    RHS1      R636      -29
    RHS1      R637      -29
    RHS1      R638      -29
    RHS1      R639      -29
    RHS1      R640      -29
    RHS1      R641      -29
    RHS1      R642      -29
    RHS1      R643      -29
    RHS1      R644      -29
    RHS1      R645      -29
    RHS1      R646      -29
    RHS1      R647      -29
    RHS1      R648      -29
    RHS1      R688      -44276
    RHS1      R689      -180
    RHS1      R690      165
    RHS1      R691      -6
    RHS1      R692      5
    RHS1      R693      -41640
    RHS1      R694      -178
    RHS1      R695      180
    RHS1      R696      -5
    RHS1      R697      6
    RHS1      R698      -43140
    RHS1      R699      -180
    RHS1      R700      157
    RHS1      R701      -6
    RHS1      R702      4
    RHS1      R703      -39840
    RHS1      R704      -176
    RHS1      R705      180
    RHS1      R706      -4
    RHS1      R707      6
    RHS1      R708      -29664
    RHS1      R709      -180
    RHS1      R710      159
    RHS1      R711      -6
    RHS1      R712      4
    RHS1      R713      -26664
    RHS1      R714      -176
    RHS1      R715      180
    RHS1      R716      -4
    RHS1      R717      6
    RHS1      R718      -29340
    RHS1      R719      -180
    RHS1      R720      157
    RHS1      R721      -6
    RHS1      R722      4
    RHS1      R723      -25140
    RHS1      R724      -176
    RHS1      R725      180
    RHS1      R726      -4
    RHS1      R727      6
    RHS1      R728      -15002
    RHS1      R729      -180
    RHS1      R730      159
    RHS1      R731      -6
    RHS1      R732      4
    RHS1      R733      -12602
    RHS1      R734      -176
    RHS1      R735      180
    RHS1      R736      -4
    RHS1      R737      6
    RHS1      R738      -32820
    RHS1      R739      -38520
    RHS1      R740      -34560
    RHS1      R741      -40320
    RHS1      R742      -47400
    RHS1      R743      -52560
    RHS1      R744      -48360
    RHS1      R745      -55020
    RHS1      R746      -62040
    RHS1      R747      -67500
    RHS1      R750      -29
    RHS1      R752      -75540
    RHS1      R754      -39600
    RHS1      R758      -54000
    RHS1      R762      -71100
    RHS1      R766      -40937
    RHS1      R767      71100
    RHS1      R769      -38031
    RHS1      R770      71100
    RHS1      R772      -25749
    RHS1      R773      71100
    RHS1      R775      -23969
    RHS1      R776      71100
    RHS1      R778      -11425
    RHS1      R779      71100
    RHS1      R780      -29
    RHS1      R781      -29
    RHS1      R782      -29
    RHS1      R783      -29
    RHS1      R784      -29
    RHS1      R785      -29
    RHS1      R786      -29
    RHS1      R787      -29
    RHS1      R788      -29
    RHS1      R789      -29
    RHS1      R790      -29
    RHS1      R791      -29
    RHS1      R792      -29
    RHS1      R793      -29
    RHS1      R794      -29
    RHS1      R795      -29
    RHS1      R796      -29
    RHS1      R797      -29
    RHS1      R798      -29
    RHS1      R799      -29
    RHS1      R839      -44276
    RHS1      R840      -180
    RHS1      R841      165
    RHS1      R842      -6
    RHS1      R843      5
    RHS1      R844      -41640
    RHS1      R845      -178
    RHS1      R846      180
    RHS1      R847      -5
    RHS1      R848      6
    RHS1      R849      -43140
    RHS1      R850      -180
    RHS1      R851      157
    RHS1      R852      -6
    RHS1      R853      4
    RHS1      R854      -39840
    RHS1      R855      -176
    RHS1      R856      180
    RHS1      R857      -4
    RHS1      R858      6
    RHS1      R859      -29664
    RHS1      R860      -180
    RHS1      R861      159
    RHS1      R862      -6
    RHS1      R863      4
    RHS1      R864      -26664
    RHS1      R865      -176
    RHS1      R866      180
    RHS1      R867      -4
    RHS1      R868      6
    RHS1      R869      -29340
    RHS1      R870      -180
    RHS1      R871      157
    RHS1      R872      -6
    RHS1      R873      4
    RHS1      R874      -25140
    RHS1      R875      -176
    RHS1      R876      180
    RHS1      R877      -4
    RHS1      R878      6
    RHS1      R879      -15002
    RHS1      R880      -180
    RHS1      R881      159
    RHS1      R882      -6
    RHS1      R883      4
    RHS1      R884      -12602
    RHS1      R885      -176
    RHS1      R886      180
    RHS1      R887      -4
    RHS1      R888      6
    RHS1      R889      -32820
    RHS1      R890      -38520
    RHS1      R891      -34560
    RHS1      R892      -40320
    RHS1      R893      -47400
    RHS1      R894      -52560
    RHS1      R895      -48360
    RHS1      R896      -55020
    RHS1      R897      -62040
    RHS1      R898      -67500
    RHS1      R901      -29
    RHS1      R903      -75540
    RHS1      R905      -39600
    RHS1      R909      -54000
    RHS1      R913      -71100
    RHS1      R917      -40937
    RHS1      R918      71100
    RHS1      R920      -38031
    RHS1      R921      71100
    RHS1      R923      -25749
    RHS1      R924      71100
    RHS1      R926      -23969
    RHS1      R927      71100
    RHS1      R929      -11425
    RHS1      R930      71100
    RHS1      R931      -29
    RHS1      R932      -29
    RHS1      R933      -29
    RHS1      R934      -29
    RHS1      R935      -29
    RHS1      R936      -29
    RHS1      R937      -29
    RHS1      R938      -29
    RHS1      R939      -29
    RHS1      R940      -29
    RHS1      R941      -29
    RHS1      R942      -29
    RHS1      R943      -29
    RHS1      R944      -29
    RHS1      R945      -29
    RHS1      R946      -29
    RHS1      R947      -29
    RHS1      R948      -29
    RHS1      R949      -29
    RHS1      R950      -29
    RHS1      R990      -44276
    RHS1      R991      -180
    RHS1      R992      165
    RHS1      R993      -6
    RHS1      R994      5
    RHS1      R995      -41640
    RHS1      R996      -178
    RHS1      R997      180
    RHS1      R998      -5
    RHS1      R999      6
    RHS1      R1000     -43140
    RHS1      R1001     -180
    RHS1      R1002     157
    RHS1      R1003     -6
    RHS1      R1004     4
    RHS1      R1005     -39840
    RHS1      R1006     -176
    RHS1      R1007     180
    RHS1      R1008     -4
    RHS1      R1009     6
    RHS1      R1010     -29664
    RHS1      R1011     -180
    RHS1      R1012     159
    RHS1      R1013     -6
    RHS1      R1014     4
    RHS1      R1015     -26664
    RHS1      R1016     -176
    RHS1      R1017     180
    RHS1      R1018     -4
    RHS1      R1019     6
    RHS1      R1020     -29340
    RHS1      R1021     -180
    RHS1      R1022     157
    RHS1      R1023     -6
    RHS1      R1024     4
    RHS1      R1025     -25140
    RHS1      R1026     -176
    RHS1      R1027     180
    RHS1      R1028     -4
    RHS1      R1029     6
    RHS1      R1030     -15002
    RHS1      R1031     -180
    RHS1      R1032     159
    RHS1      R1033     -6
    RHS1      R1034     4
    RHS1      R1035     -12602
    RHS1      R1036     -176
    RHS1      R1037     180
    RHS1      R1038     -4
    RHS1      R1039     6
    RHS1      R1040     -32820
    RHS1      R1041     -38520
    RHS1      R1042     -34560
    RHS1      R1043     -40320
    RHS1      R1044     -47400
    RHS1      R1045     -52560
    RHS1      R1046     -48360
    RHS1      R1047     -55020
    RHS1      R1048     -62040
    RHS1      R1049     -67500
    RHS1      R1052     -29
    RHS1      R1054     -75540
    RHS1      R1056     -39600
    RHS1      R1060     -54000
    RHS1      R1064     -71100
    RHS1      R1068     -40937
    RHS1      R1069     71100
    RHS1      R1071     -38031
    RHS1      R1072     71100
    RHS1      R1074     -25749
    RHS1      R1075     71100
    RHS1      R1077     -23969
    RHS1      R1078     71100
    RHS1      R1080     -11425
    RHS1      R1081     71100
    RHS1      R1082     -29
    RHS1      R1083     -29
    RHS1      R1084     -29
    RHS1      R1085     -29
    RHS1      R1086     -29
    RHS1      R1087     -29
    RHS1      R1088     -29
    RHS1      R1089     -29
    RHS1      R1090     -29
    RHS1      R1091     -29
    RHS1      R1092     -29
    RHS1      R1093     -29
    RHS1      R1094     -29
    RHS1      R1095     -29
    RHS1      R1096     -29
    RHS1      R1097     -29
    RHS1      R1098     -29
    RHS1      R1099     -29
    RHS1      R1100     -29
    RHS1      R1101     -29
    RHS1      R1141     -44276
    RHS1      R1142     -180
    RHS1      R1143     165
    RHS1      R1144     -6
    RHS1      R1145     5
    RHS1      R1146     -41640
    RHS1      R1147     -178
    RHS1      R1148     180
    RHS1      R1149     -5
    RHS1      R1150     6
    RHS1      R1151     -43140
    RHS1      R1152     -180
    RHS1      R1153     157
    RHS1      R1154     -6
    RHS1      R1155     4
    RHS1      R1156     -39840
    RHS1      R1157     -176
    RHS1      R1158     180
    RHS1      R1159     -4
    RHS1      R1160     6
    RHS1      R1161     -29664
    RHS1      R1162     -180
    RHS1      R1163     159
    RHS1      R1164     -6
    RHS1      R1165     4
    RHS1      R1166     -26664
    RHS1      R1167     -176
    RHS1      R1168     180
    RHS1      R1169     -4
    RHS1      R1170     6
    RHS1      R1171     -29340
    RHS1      R1172     -180
    RHS1      R1173     157
    RHS1      R1174     -6
    RHS1      R1175     4
    RHS1      R1176     -25140
    RHS1      R1177     -176
    RHS1      R1178     180
    RHS1      R1179     -4
    RHS1      R1180     6
    RHS1      R1181     -15002
    RHS1      R1182     -180
    RHS1      R1183     159
    RHS1      R1184     -6
    RHS1      R1185     4
    RHS1      R1186     -12602
    RHS1      R1187     -176
    RHS1      R1188     180
    RHS1      R1189     -4
    RHS1      R1190     6
    RHS1      R1191     -32820
    RHS1      R1192     -38520
    RHS1      R1193     -34560
    RHS1      R1194     -40320
    RHS1      R1195     -47400
    RHS1      R1196     -52560
    RHS1      R1197     -48360
    RHS1      R1198     -55020
    RHS1      R1199     -62040
    RHS1      R1200     -67500
    RHS1      R1203     -29
    RHS1      R1205     -75540
    RHS1      R1207     -39600
    RHS1      R1211     -54000
    RHS1      R1215     -71100
    RHS1      R1219     -40937
    RHS1      R1220     71100
    RHS1      R1222     -38031
    RHS1      R1223     71100
    RHS1      R1225     -25749
    RHS1      R1226     71100
    RHS1      R1228     -23969
    RHS1      R1229     71100
    RHS1      R1231     -11425
    RHS1      R1232     71100
    RHS1      R1233     -29
    RHS1      R1234     -29
    RHS1      R1235     -29
    RHS1      R1236     -29
    RHS1      R1237     -29
    RHS1      R1238     -29
    RHS1      R1239     -29
    RHS1      R1240     -29
    RHS1      R1241     -29
    RHS1      R1242     -29
    RHS1      R1243     -29
    RHS1      R1244     -29
    RHS1      R1245     -29
    RHS1      R1246     -29
    RHS1      R1247     -29
    RHS1      R1248     -29
    RHS1      R1249     -29
    RHS1      R1250     -29
    RHS1      R1251     -29
    RHS1      R1252     -29
    RHS1      R1292     -44276
    RHS1      R1293     -180
    RHS1      R1294     165
    RHS1      R1295     -6
    RHS1      R1296     5
    RHS1      R1297     -41640
    RHS1      R1298     -178
    RHS1      R1299     180
    RHS1      R1300     -5
    RHS1      R1301     6
    RHS1      R1302     -43140
    RHS1      R1303     -180
    RHS1      R1304     157
    RHS1      R1305     -6
    RHS1      R1306     4
    RHS1      R1307     -39840
    RHS1      R1308     -176
    RHS1      R1309     180
    RHS1      R1310     -4
    RHS1      R1311     6
    RHS1      R1312     -29664
    RHS1      R1313     -180
    RHS1      R1314     159
    RHS1      R1315     -6
    RHS1      R1316     4
    RHS1      R1317     -26664
    RHS1      R1318     -176
    RHS1      R1319     180
    RHS1      R1320     -4
    RHS1      R1321     6
    RHS1      R1322     -29340
    RHS1      R1323     -180
    RHS1      R1324     157
    RHS1      R1325     -6
    RHS1      R1326     4
    RHS1      R1327     -25140
    RHS1      R1328     -176
    RHS1      R1329     180
    RHS1      R1330     -4
    RHS1      R1331     6
    RHS1      R1332     -15002
    RHS1      R1333     -180
    RHS1      R1334     159
    RHS1      R1335     -6
    RHS1      R1336     4
    RHS1      R1337     -12602
    RHS1      R1338     -176
    RHS1      R1339     180
    RHS1      R1340     -4
    RHS1      R1341     6
    RHS1      R1342     -32820
    RHS1      R1343     -38520
    RHS1      R1344     -34560
    RHS1      R1345     -40320
    RHS1      R1346     -47400
    RHS1      R1347     -52560
    RHS1      R1348     -48360
    RHS1      R1349     -55020
    RHS1      R1350     -62040
    RHS1      R1351     -67500
    RHS1      R1354     -29
    RHS1      R1356     -75540
    RHS1      R1358     -39600
    RHS1      R1362     -54000
    RHS1      R1366     -71100
    RHS1      R1370     -40937
    RHS1      R1371     71100
    RHS1      R1373     -38031
    RHS1      R1374     71100
    RHS1      R1376     -25749
    RHS1      R1377     71100
    RHS1      R1379     -23969
    RHS1      R1380     71100
    RHS1      R1382     -11425
    RHS1      R1383     71100
    RHS1      R1384     -29
    RHS1      R1385     -29
    RHS1      R1386     -29
    RHS1      R1387     -29
    RHS1      R1388     -29
    RHS1      R1389     -29
    RHS1      R1390     -29
    RHS1      R1391     -29
    RHS1      R1392     -29
    RHS1      R1393     -29
    RHS1      R1394     -29
    RHS1      R1395     -29
    RHS1      R1396     -29
    RHS1      R1397     -29
    RHS1      R1398     -29
    RHS1      R1399     -29
    RHS1      R1400     -29
    RHS1      R1401     -29
    RHS1      R1402     -29
    RHS1      R1403     -29
    RHS1      R1443     -44276
    RHS1      R1444     -180
    RHS1      R1445     165
    RHS1      R1446     -6
    RHS1      R1447     5
    RHS1      R1448     -41640
    RHS1      R1449     -178
    RHS1      R1450     180
    RHS1      R1451     -5
    RHS1      R1452     6
    RHS1      R1453     -43140
    RHS1      R1454     -180
    RHS1      R1455     157
    RHS1      R1456     -6
    RHS1      R1457     4
    RHS1      R1458     -39840
    RHS1      R1459     -176
    RHS1      R1460     180
    RHS1      R1461     -4
    RHS1      R1462     6
    RHS1      R1463     -29664
    RHS1      R1464     -180
    RHS1      R1465     159
    RHS1      R1466     -6
    RHS1      R1467     4
    RHS1      R1468     -26664
    RHS1      R1469     -176
    RHS1      R1470     180
    RHS1      R1471     -4
    RHS1      R1472     6
    RHS1      R1473     -29340
    RHS1      R1474     -180
    RHS1      R1475     157
    RHS1      R1476     -6
    RHS1      R1477     4
    RHS1      R1478     -25140
    RHS1      R1479     -176
    RHS1      R1480     180
    RHS1      R1481     -4
    RHS1      R1482     6
    RHS1      R1483     -15002
    RHS1      R1484     -180
    RHS1      R1485     159
    RHS1      R1486     -6
    RHS1      R1487     4
    RHS1      R1488     -12602
    RHS1      R1489     -176
    RHS1      R1490     180
    RHS1      R1491     -4
    RHS1      R1492     6
    RHS1      R1493     -32820
    RHS1      R1494     -38520
    RHS1      R1495     -34560
    RHS1      R1496     -40320
    RHS1      R1497     -47400
    RHS1      R1498     -52560
    RHS1      R1499     -48360
    RHS1      R1500     -55020
    RHS1      R1501     -62040
    RHS1      R1502     -67500
    RHS1      R1505     -29
    RHS1      R1507     -75540
    RHS1      R1509     -39600
    RHS1      R1513     -54000
    RHS1      R1517     -71100
    RHS1      R1521     -40937
    RHS1      R1522     71100
    RHS1      R1524     -38031
    RHS1      R1525     71100
    RHS1      R1527     -25749
    RHS1      R1528     71100
    RHS1      R1530     -23969
    RHS1      R1531     71100
    RHS1      R1533     -11425
    RHS1      R1534     71100
    RHS1      R1535     -29
    RHS1      R1536     -29
    RHS1      R1537     -29
    RHS1      R1538     -29
    RHS1      R1539     -29
    RHS1      R1540     -29
    RHS1      R1541     -29
    RHS1      R1542     -29
    RHS1      R1543     -29
    RHS1      R1544     -29
    RHS1      R1545     -29
    RHS1      R1546     -29
    RHS1      R1547     -29
    RHS1      R1548     -29
    RHS1      R1549     -29
    RHS1      R1550     -29
    RHS1      R1551     -29
    RHS1      R1552     -29
    RHS1      R1553     -29
    RHS1      R1554     -29
    RHS1      R1594     -44276
    RHS1      R1595     -180
    RHS1      R1596     165
    RHS1      R1597     -6
    RHS1      R1598     5
    RHS1      R1599     -41640
    RHS1      R1600     -178
    RHS1      R1601     180
    RHS1      R1602     -5
    RHS1      R1603     6
    RHS1      R1604     -43140
    RHS1      R1605     -180
    RHS1      R1606     157
    RHS1      R1607     -6
    RHS1      R1608     4
    RHS1      R1609     -39840
    RHS1      R1610     -176
    RHS1      R1611     180
    RHS1      R1612     -4
    RHS1      R1613     6
    RHS1      R1614     -29664
    RHS1      R1615     -180
    RHS1      R1616     159
    RHS1      R1617     -6
    RHS1      R1618     4
    RHS1      R1619     -26664
    RHS1      R1620     -176
    RHS1      R1621     180
    RHS1      R1622     -4
    RHS1      R1623     6
    RHS1      R1624     -29340
    RHS1      R1625     -180
    RHS1      R1626     157
    RHS1      R1627     -6
    RHS1      R1628     4
    RHS1      R1629     -25140
    RHS1      R1630     -176
    RHS1      R1631     180
    RHS1      R1632     -4
    RHS1      R1633     6
    RHS1      R1634     -15002
    RHS1      R1635     -180
    RHS1      R1636     159
    RHS1      R1637     -6
    RHS1      R1638     4
    RHS1      R1639     -12602
    RHS1      R1640     -176
    RHS1      R1641     180
    RHS1      R1642     -4
    RHS1      R1643     6
    RHS1      R1644     -32820
    RHS1      R1645     -38520
    RHS1      R1646     -34560
    RHS1      R1647     -40320
    RHS1      R1648     -47400
    RHS1      R1649     -52560
    RHS1      R1650     -48360
    RHS1      R1651     -55020
    RHS1      R1652     -62040
    RHS1      R1653     -67500
    RHS1      R1656     -29
    RHS1      R1658     -75540
    RHS1      R1660     -39600
    RHS1      R1664     -54000
    RHS1      R1668     -71100
    RHS1      R1672     -40937
    RHS1      R1673     71100
    RHS1      R1675     -38031
    RHS1      R1676     71100
    RHS1      R1678     -25749
    RHS1      R1679     71100
    RHS1      R1681     -23969
    RHS1      R1682     71100
    RHS1      R1684     -11425
    RHS1      R1685     71100
    RHS1      R1686     -29
    RHS1      R1687     -29
    RHS1      R1688     -29
    RHS1      R1689     -29
    RHS1      R1690     -29
    RHS1      R1691     -29
    RHS1      R1692     -29
    RHS1      R1693     -29
    RHS1      R1694     -29
    RHS1      R1695     -29
    RHS1      R1696     -29
    RHS1      R1697     -29
    RHS1      R1698     -29
    RHS1      R1699     -29
    RHS1      R1700     -29
    RHS1      R1701     -29
    RHS1      R1702     -29
    RHS1      R1703     -29
    RHS1      R1704     -29
    RHS1      R1705     -29
    RHS1      R1745     -44276
    RHS1      R1746     -180
    RHS1      R1747     165
    RHS1      R1748     -6
    RHS1      R1749     5
    RHS1      R1750     -41640
    RHS1      R1751     -178
    RHS1      R1752     180
    RHS1      R1753     -5
    RHS1      R1754     6
    RHS1      R1755     -43140
    RHS1      R1756     -180
    RHS1      R1757     157
    RHS1      R1758     -6
    RHS1      R1759     4
    RHS1      R1760     -39840
    RHS1      R1761     -176
    RHS1      R1762     180
    RHS1      R1763     -4
    RHS1      R1764     6
    RHS1      R1765     -29664
    RHS1      R1766     -180
    RHS1      R1767     159
    RHS1      R1768     -6
    RHS1      R1769     4
    RHS1      R1770     -26664
    RHS1      R1771     -176
    RHS1      R1772     180
    RHS1      R1773     -4
    RHS1      R1774     6
    RHS1      R1775     -29340
    RHS1      R1776     -180
    RHS1      R1777     157
    RHS1      R1778     -6
    RHS1      R1779     4
    RHS1      R1780     -25140
    RHS1      R1781     -176
    RHS1      R1782     180
    RHS1      R1783     -4
    RHS1      R1784     6
    RHS1      R1785     -15002
    RHS1      R1786     -180
    RHS1      R1787     159
    RHS1      R1788     -6
    RHS1      R1789     4
    RHS1      R1790     -12602
    RHS1      R1791     -176
    RHS1      R1792     180
    RHS1      R1793     -4
    RHS1      R1794     6
    RHS1      R1795     -32820
    RHS1      R1796     -38520
    RHS1      R1797     -34560
    RHS1      R1798     -40320
    RHS1      R1799     -47400
    RHS1      R1800     -52560
    RHS1      R1801     -48360
    RHS1      R1802     -55020
    RHS1      R1803     -62040
    RHS1      R1804     -67500
    RHS1      R1807     -29
    RHS1      R1809     -75540
    RHS1      R1811     -39600
    RHS1      R1815     -54000
    RHS1      R1819     -71100
    RHS1      R1823     -40937
    RHS1      R1824     71100
    RHS1      R1826     -38031
    RHS1      R1827     71100
    RHS1      R1829     -25749
    RHS1      R1830     71100
    RHS1      R1832     -23969
    RHS1      R1833     71100
    RHS1      R1835     -11425
    RHS1      R1836     71100
    RHS1      R1837     -29
    RHS1      R1838     -29
    RHS1      R1839     -29
    RHS1      R1840     -29
    RHS1      R1841     -29
    RHS1      R1842     -29
    RHS1      R1843     -29
    RHS1      R1844     -29
    RHS1      R1845     -29
    RHS1      R1846     -29
    RHS1      R1847     -29
    RHS1      R1848     -29
    RHS1      R1849     -29
    RHS1      R1850     -29
    RHS1      R1851     -29
    RHS1      R1852     -29
    RHS1      R1853     -29
    RHS1      R1854     -29
    RHS1      R1855     -29
    RHS1      R1856     -29
    RHS1      R1896     -44276
    RHS1      R1897     -180
    RHS1      R1898     165
    RHS1      R1899     -6
    RHS1      R1900     5
    RHS1      R1901     -41640
    RHS1      R1902     -178
    RHS1      R1903     180
    RHS1      R1904     -5
    RHS1      R1905     6
    RHS1      R1906     -43140
    RHS1      R1907     -180
    RHS1      R1908     157
    RHS1      R1909     -6
    RHS1      R1910     4
    RHS1      R1911     -39840
    RHS1      R1912     -176
    RHS1      R1913     180
    RHS1      R1914     -4
    RHS1      R1915     6
    RHS1      R1916     -29664
    RHS1      R1917     -180
    RHS1      R1918     159
    RHS1      R1919     -6
    RHS1      R1920     4
    RHS1      R1921     -26664
    RHS1      R1922     -176
    RHS1      R1923     180
    RHS1      R1924     -4
    RHS1      R1925     6
    RHS1      R1926     -29340
    RHS1      R1927     -180
    RHS1      R1928     157
    RHS1      R1929     -6
    RHS1      R1930     4
    RHS1      R1931     -25140
    RHS1      R1932     -176
    RHS1      R1933     180
    RHS1      R1934     -4
    RHS1      R1935     6
    RHS1      R1936     -15002
    RHS1      R1937     -180
    RHS1      R1938     159
    RHS1      R1939     -6
    RHS1      R1940     4
    RHS1      R1941     -12602
    RHS1      R1942     -176
    RHS1      R1943     180
    RHS1      R1944     -4
    RHS1      R1945     6
    RHS1      R1946     -32820
    RHS1      R1947     -38520
    RHS1      R1948     -34560
    RHS1      R1949     -40320
    RHS1      R1950     -47400
    RHS1      R1951     -52560
    RHS1      R1952     -48360
    RHS1      R1953     -55020
    RHS1      R1954     -62040
    RHS1      R1955     -67500
    RHS1      R1960     -39600
    RHS1      R1964     -54000
    RHS1      R1968     -71100
    RHS1      R1972     -40937
    RHS1      R1973     71100
    RHS1      R1975     -38031
    RHS1      R1976     71100
    RHS1      R1978     -25749
    RHS1      R1979     71100
    RHS1      R1981     -23969
    RHS1      R1982     71100
    RHS1      R1984     -11425
    RHS1      R1985     71100
    RHS1      R1986     -29
    RHS1      R1987     -29
    RHS1      R1988     -29
    RHS1      R1989     -29
    RHS1      R1990     -29
    RHS1      R1991     -29
    RHS1      R1992     -29
    RHS1      R1993     -29
    RHS1      R1994     -29
    RHS1      R1995     -29
    RHS1      R1996     -29
    RHS1      R1997     -29
    RHS1      R1998     -29
    RHS1      R1999     -29
    RHS1      R2000     -29
    RHS1      R2001     -29
    RHS1      R2002     -29
    RHS1      R2003     -29
    RHS1      R2004     -29
    RHS1      R2005     -29
    RHS1      R2045     -44276
    RHS1      R2046     -180
    RHS1      R2047     165
    RHS1      R2048     -6
    RHS1      R2049     5
    RHS1      R2050     -41640
    RHS1      R2051     -178
    RHS1      R2052     180
    RHS1      R2053     -5
    RHS1      R2054     6
    RHS1      R2055     -43140
    RHS1      R2056     -180
    RHS1      R2057     157
    RHS1      R2058     -6
    RHS1      R2059     4
    RHS1      R2060     -39840
    RHS1      R2061     -176
    RHS1      R2062     180
    RHS1      R2063     -4
    RHS1      R2064     6
    RHS1      R2065     -29664
    RHS1      R2066     -180
    RHS1      R2067     159
    RHS1      R2068     -6
    RHS1      R2069     4
    RHS1      R2070     -26664
    RHS1      R2071     -176
    RHS1      R2072     180
    RHS1      R2073     -4
    RHS1      R2074     6
    RHS1      R2075     -29340
    RHS1      R2076     -180
    RHS1      R2077     157
    RHS1      R2078     -6
    RHS1      R2079     4
    RHS1      R2080     -25140
    RHS1      R2081     -176
    RHS1      R2082     180
    RHS1      R2083     -4
    RHS1      R2084     6
    RHS1      R2085     -15002
    RHS1      R2086     -180
    RHS1      R2087     159
    RHS1      R2088     -6
    RHS1      R2089     4
    RHS1      R2090     -12602
    RHS1      R2091     -176
    RHS1      R2092     180
    RHS1      R2093     -4
    RHS1      R2094     6
    RHS1      R2095     -32820
    RHS1      R2096     -38520
    RHS1      R2097     -34560
    RHS1      R2098     -40320
    RHS1      R2099     -47400
    RHS1      R2100     -52560
    RHS1      R2101     -48360
    RHS1      R2102     -55020
    RHS1      R2103     -62040
    RHS1      R2104     -67500
    RHS1      R2107     -29
    RHS1      R2109     -75540
    RHS1      R2111     -39600
    RHS1      R2115     -54000
    RHS1      R2119     -71100
    RHS1      R2123     -40937
    RHS1      R2124     71100
    RHS1      R2126     -38031
    RHS1      R2127     71100
    RHS1      R2129     -25749
    RHS1      R2130     71100
    RHS1      R2132     -23969
    RHS1      R2133     71100
    RHS1      R2135     -11425
    RHS1      R2136     71100
    RHS1      R2137     -29
    RHS1      R2138     -29
    RHS1      R2139     -29
    RHS1      R2140     -29
    RHS1      R2141     -29
    RHS1      R2142     -29
    RHS1      R2143     -29
    RHS1      R2144     -29
    RHS1      R2145     -29
    RHS1      R2146     -29
    RHS1      R2147     -29
    RHS1      R2148     -29
    RHS1      R2149     -29
    RHS1      R2150     -29
    RHS1      R2151     -29
    RHS1      R2152     -29
    RHS1      R2153     -29
    RHS1      R2154     -29
    RHS1      R2155     -29
    RHS1      R2156     -29
    RHS1      R2196     -44276
    RHS1      R2197     -180
    RHS1      R2198     165
    RHS1      R2199     -6
    RHS1      R2200     5
    RHS1      R2201     -41640
    RHS1      R2202     -178
    RHS1      R2203     180
    RHS1      R2204     -5
    RHS1      R2205     6
    RHS1      R2206     -43140
    RHS1      R2207     -180
    RHS1      R2208     157
    RHS1      R2209     -6
    RHS1      R2210     4
    RHS1      R2211     -39840
    RHS1      R2212     -176
    RHS1      R2213     180
    RHS1      R2214     -4
    RHS1      R2215     6
    RHS1      R2216     -29664
    RHS1      R2217     -180
    RHS1      R2218     159
    RHS1      R2219     -6
    RHS1      R2220     4
    RHS1      R2221     -26664
    RHS1      R2222     -176
    RHS1      R2223     180
    RHS1      R2224     -4
    RHS1      R2225     6
    RHS1      R2226     -29340
    RHS1      R2227     -180
    RHS1      R2228     157
    RHS1      R2229     -6
    RHS1      R2230     4
    RHS1      R2231     -25140
    RHS1      R2232     -176
    RHS1      R2233     180
    RHS1      R2234     -4
    RHS1      R2235     6
    RHS1      R2236     -15002
    RHS1      R2237     -180
    RHS1      R2238     159
    RHS1      R2239     -6
    RHS1      R2240     4
    RHS1      R2241     -12602
    RHS1      R2242     -176
    RHS1      R2243     180
    RHS1      R2244     -4
    RHS1      R2245     6
    RHS1      R2246     -32820
    RHS1      R2247     -38520
    RHS1      R2248     -34560
    RHS1      R2249     -40320
    RHS1      R2250     -47400
    RHS1      R2251     -52560
    RHS1      R2252     -48360
    RHS1      R2253     -55020
    RHS1      R2254     -62040
    RHS1      R2255     -67500
    RHS1      R2258     -29
    RHS1      R2260     -75540
    RHS1      R2262     -39600
    RHS1      R2266     -54000
    RHS1      R2270     -71100
    RHS1      R2274     -40937
    RHS1      R2275     71100
    RHS1      R2277     -38031
    RHS1      R2278     71100
    RHS1      R2280     -25749
    RHS1      R2281     71100
    RHS1      R2283     -23969
    RHS1      R2284     71100
    RHS1      R2286     -11425
    RHS1      R2287     71100
    RHS1      R2288     -29
    RHS1      R2289     -29
    RHS1      R2290     -29
    RHS1      R2291     -29
    RHS1      R2292     -29
    RHS1      R2293     -29
    RHS1      R2294     -29
    RHS1      R2295     -29
    RHS1      R2296     -29
    RHS1      R2297     -29
    RHS1      R2298     -29
    RHS1      R2299     -29
    RHS1      R2300     -29
    RHS1      R2301     -29
    RHS1      R2302     -29
    RHS1      R2303     -29
    RHS1      R2304     -29
    RHS1      R2305     -29
    RHS1      R2306     -29
    RHS1      R2307     -29
    RHS1      R2347     -44276
    RHS1      R2348     -180
    RHS1      R2349     165
    RHS1      R2350     -6
    RHS1      R2351     5
    RHS1      R2352     -41640
    RHS1      R2353     -178
    RHS1      R2354     180
    RHS1      R2355     -5
    RHS1      R2356     6
    RHS1      R2357     -43140
    RHS1      R2358     -180
    RHS1      R2359     157
    RHS1      R2360     -6
    RHS1      R2361     4
    RHS1      R2362     -39840
    RHS1      R2363     -176
    RHS1      R2364     180
    RHS1      R2365     -4
    RHS1      R2366     6
    RHS1      R2367     -29664
    RHS1      R2368     -180
    RHS1      R2369     159
    RHS1      R2370     -6
    RHS1      R2371     4
    RHS1      R2372     -26664
    RHS1      R2373     -176
    RHS1      R2374     180
    RHS1      R2375     -4
    RHS1      R2376     6
    RHS1      R2377     -29340
    RHS1      R2378     -180
    RHS1      R2379     157
    RHS1      R2380     -6
    RHS1      R2381     4
    RHS1      R2382     -25140
    RHS1      R2383     -176
    RHS1      R2384     180
    RHS1      R2385     -4
    RHS1      R2386     6
    RHS1      R2387     -15002
    RHS1      R2388     -180
    RHS1      R2389     159
    RHS1      R2390     -6
    RHS1      R2391     4
    RHS1      R2392     -12602
    RHS1      R2393     -176
    RHS1      R2394     180
    RHS1      R2395     -4
    RHS1      R2396     6
    RHS1      R2397     -32820
    RHS1      R2398     -38520
    RHS1      R2399     -34560
    RHS1      R2400     -40320
    RHS1      R2401     -47400
    RHS1      R2402     -52560
    RHS1      R2403     -48360
    RHS1      R2404     -55020
    RHS1      R2405     -62040
    RHS1      R2406     -67500
    RHS1      R2409     -29
    RHS1      R2411     -75540
    RHS1      R2413     -39600
    RHS1      R2417     -54000
    RHS1      R2421     -71100
    RHS1      R2425     -40937
    RHS1      R2426     71100
    RHS1      R2428     -38031
    RHS1      R2429     71100
    RHS1      R2431     -25749
    RHS1      R2432     71100
    RHS1      R2434     -23969
    RHS1      R2435     71100
    RHS1      R2437     -11425
    RHS1      R2438     71100
    RHS1      R2439     -29
    RHS1      R2440     -29
    RHS1      R2441     -29
    RHS1      R2442     -29
    RHS1      R2443     -29
    RHS1      R2444     -29
    RHS1      R2445     -29
    RHS1      R2446     -29
    RHS1      R2447     -29
    RHS1      R2448     -29
    RHS1      R2449     -29
    RHS1      R2450     -29
    RHS1      R2451     -29
    RHS1      R2452     -29
    RHS1      R2453     -29
    RHS1      R2454     -29
    RHS1      R2455     -29
    RHS1      R2456     -29
    RHS1      R2457     -29
    RHS1      R2458     -29
    RHS1      R2498     -44276
    RHS1      R2499     -180
    RHS1      R2500     165
    RHS1      R2501     -6
    RHS1      R2502     5
    RHS1      R2503     -41640
    RHS1      R2504     -178
    RHS1      R2505     180
    RHS1      R2506     -5
    RHS1      R2507     6
    RHS1      R2508     -43140
    RHS1      R2509     -180
    RHS1      R2510     157
    RHS1      R2511     -6
    RHS1      R2512     4
    RHS1      R2513     -39840
    RHS1      R2514     -176
    RHS1      R2515     180
    RHS1      R2516     -4
    RHS1      R2517     6
    RHS1      R2518     -29664
    RHS1      R2519     -180
    RHS1      R2520     159
    RHS1      R2521     -6
    RHS1      R2522     4
    RHS1      R2523     -26664
    RHS1      R2524     -176
    RHS1      R2525     180
    RHS1      R2526     -4
    RHS1      R2527     6
    RHS1      R2528     -29340
    RHS1      R2529     -180
    RHS1      R2530     157
    RHS1      R2531     -6
    RHS1      R2532     4
    RHS1      R2533     -25140
    RHS1      R2534     -176
    RHS1      R2535     180
    RHS1      R2536     -4
    RHS1      R2537     6
    RHS1      R2538     -15002
    RHS1      R2539     -180
    RHS1      R2540     159
    RHS1      R2541     -6
    RHS1      R2542     4
    RHS1      R2543     -12602
    RHS1      R2544     -176
    RHS1      R2545     180
    RHS1      R2546     -4
    RHS1      R2547     6
    RHS1      R2548     -32820
    RHS1      R2549     -38520
    RHS1      R2550     -34560
    RHS1      R2551     -40320
    RHS1      R2552     -47400
    RHS1      R2553     -52560
    RHS1      R2554     -48360
    RHS1      R2555     -55020
    RHS1      R2556     -62040
    RHS1      R2557     -67500
    RHS1      R2560     -29
    RHS1      R2562     -75540
    RHS1      R2564     -39600
    RHS1      R2568     -54000
    RHS1      R2572     -71100
    RHS1      R2576     -40937
    RHS1      R2577     71100
    RHS1      R2579     -38031
    RHS1      R2580     71100
    RHS1      R2582     -25749
    RHS1      R2583     71100
    RHS1      R2585     -23969
    RHS1      R2586     71100
    RHS1      R2588     -11425
    RHS1      R2589     71100
    RHS1      R2590     -29
    RHS1      R2591     -29
    RHS1      R2592     -29
    RHS1      R2593     -29
    RHS1      R2594     -29
    RHS1      R2595     -29
    RHS1      R2596     -29
    RHS1      R2597     -29
    RHS1      R2598     -29
    RHS1      R2599     -29
    RHS1      R2600     -29
    RHS1      R2601     -29
    RHS1      R2602     -29
    RHS1      R2603     -29
    RHS1      R2604     -29
    RHS1      R2605     -29
    RHS1      R2606     -29
    RHS1      R2607     -29
    RHS1      R2608     -29
    RHS1      R2609     -29
    RHS1      R2650     -44276
    RHS1      R2651     -180
    RHS1      R2652     165
    RHS1      R2653     -6
    RHS1      R2654     5
    RHS1      R2655     -41640
    RHS1      R2656     -178
    RHS1      R2657     180
    RHS1      R2658     -5
    RHS1      R2659     6
    RHS1      R2660     -43140
    RHS1      R2661     -180
    RHS1      R2662     157
    RHS1      R2663     -6
    RHS1      R2664     4
    RHS1      R2665     -39840
    RHS1      R2666     -176
    RHS1      R2667     180
    RHS1      R2668     -4
    RHS1      R2669     6
    RHS1      R2670     -29664
    RHS1      R2671     -180
    RHS1      R2672     159
    RHS1      R2673     -6
    RHS1      R2674     4
    RHS1      R2675     -26664
    RHS1      R2676     -176
    RHS1      R2677     180
    RHS1      R2678     -4
    RHS1      R2679     6
    RHS1      R2680     -29340
    RHS1      R2681     -180
    RHS1      R2682     157
    RHS1      R2683     -6
    RHS1      R2684     4
    RHS1      R2685     -25140
    RHS1      R2686     -176
    RHS1      R2687     180
    RHS1      R2688     -4
    RHS1      R2689     6
    RHS1      R2690     -15002
    RHS1      R2691     -180
    RHS1      R2692     159
    RHS1      R2693     -6
    RHS1      R2694     4
    RHS1      R2695     -12602
    RHS1      R2696     -176
    RHS1      R2697     180
    RHS1      R2698     -4
    RHS1      R2699     6
    RHS1      R2700     -32820
    RHS1      R2701     -38520
    RHS1      R2702     -34560
    RHS1      R2703     -40320
    RHS1      R2704     -47400
    RHS1      R2705     -52560
    RHS1      R2706     -48360
    RHS1      R2707     -55020
    RHS1      R2708     -62040
    RHS1      R2709     -67500
    RHS1      R2714     -39600
    RHS1      R2718     -54000
    RHS1      R2722     -71100
    RHS1      R2726     -40937
    RHS1      R2727     71100
    RHS1      R2729     -38031
    RHS1      R2730     71100
    RHS1      R2732     -25749
    RHS1      R2733     71100
    RHS1      R2735     -23969
    RHS1      R2736     71100
    RHS1      R2738     -11425
    RHS1      R2739     71100
    RHS1      R2740     -29
    RHS1      R2741     -29
    RHS1      R2742     -29
    RHS1      R2743     -29
    RHS1      R2744     -29
    RHS1      R2745     -29
    RHS1      R2746     -29
    RHS1      R2747     -29
    RHS1      R2748     -29
    RHS1      R2749     -29
    RHS1      R2750     -29
    RHS1      R2751     -29
    RHS1      R2752     -29
    RHS1      R2753     -29
    RHS1      R2754     -29
    RHS1      R2755     -29
    RHS1      R2756     -29
    RHS1      R2757     -29
    RHS1      R2758     -29
    RHS1      R2759     -29
    RHS1      R2799     -44276
    RHS1      R2800     -180
    RHS1      R2801     165
    RHS1      R2802     -6
    RHS1      R2803     5
    RHS1      R2804     -41640
    RHS1      R2805     -178
    RHS1      R2806     180
    RHS1      R2807     -5
    RHS1      R2808     6
    RHS1      R2809     -43140
    RHS1      R2810     -180
    RHS1      R2811     157
    RHS1      R2812     -6
    RHS1      R2813     4
    RHS1      R2814     -39840
    RHS1      R2815     -176
    RHS1      R2816     180
    RHS1      R2817     -4
    RHS1      R2818     6
    RHS1      R2819     -29664
    RHS1      R2820     -180
    RHS1      R2821     159
    RHS1      R2822     -6
    RHS1      R2823     4
    RHS1      R2824     -26664
    RHS1      R2825     -176
    RHS1      R2826     180
    RHS1      R2827     -4
    RHS1      R2828     6
    RHS1      R2829     -29340
    RHS1      R2830     -180
    RHS1      R2831     157
    RHS1      R2832     -6
    RHS1      R2833     4
    RHS1      R2834     -25140
    RHS1      R2835     -176
    RHS1      R2836     180
    RHS1      R2837     -4
    RHS1      R2838     6
    RHS1      R2839     -15002
    RHS1      R2840     -180
    RHS1      R2841     159
    RHS1      R2842     -6
    RHS1      R2843     4
    RHS1      R2844     -12602
    RHS1      R2845     -176
    RHS1      R2846     180
    RHS1      R2847     -4
    RHS1      R2848     6
    RHS1      R2849     -32820
    RHS1      R2850     -38520
    RHS1      R2851     -34560
    RHS1      R2852     -40320
    RHS1      R2853     -47400
    RHS1      R2854     -52560
    RHS1      R2855     -48360
    RHS1      R2856     -55020
    RHS1      R2857     -62040
    RHS1      R2858     -67500
    RHS1      R2861     -29
    RHS1      R2863     -75540
    RHS1      R2865     -39600
    RHS1      R2869     -54000
    RHS1      R2873     -71100
    RHS1      R2877     -40937
    RHS1      R2878     71100
    RHS1      R2880     -38031
    RHS1      R2881     71100
    RHS1      R2883     -25749
    RHS1      R2884     71100
    RHS1      R2886     -23969
    RHS1      R2887     71100
    RHS1      R2889     -11425
    RHS1      R2890     71100
    RHS1      R2891     -29
    RHS1      R2892     -29
    RHS1      R2893     -29
    RHS1      R2894     -29
    RHS1      R2895     -29
    RHS1      R2896     -29
    RHS1      R2897     -29
    RHS1      R2898     -29
    RHS1      R2899     -29
    RHS1      R2900     -29
    RHS1      R2901     -29
    RHS1      R2902     -29
    RHS1      R2903     -29
    RHS1      R2904     -29
    RHS1      R2905     -29
    RHS1      R2906     -29
    RHS1      R2907     -29
    RHS1      R2908     -29
    RHS1      R2909     -29
    RHS1      R2910     -29
    RHS1      R2950     -44276
    RHS1      R2951     -180
    RHS1      R2952     165
    RHS1      R2953     -6
    RHS1      R2954     5
    RHS1      R2955     -41640
    RHS1      R2956     -178
    RHS1      R2957     180
    RHS1      R2958     -5
    RHS1      R2959     6
    RHS1      R2960     -43140
    RHS1      R2961     -180
    RHS1      R2962     157
    RHS1      R2963     -6
    RHS1      R2964     4
    RHS1      R2965     -39840
    RHS1      R2966     -176
    RHS1      R2967     180
    RHS1      R2968     -4
    RHS1      R2969     6
    RHS1      R2970     -29664
    RHS1      R2971     -180
    RHS1      R2972     159
    RHS1      R2973     -6
    RHS1      R2974     4
    RHS1      R2975     -26664
    RHS1      R2976     -176
    RHS1      R2977     180
    RHS1      R2978     -4
    RHS1      R2979     6
    RHS1      R2980     -29340
    RHS1      R2981     -180
    RHS1      R2982     157
    RHS1      R2983     -6
    RHS1      R2984     4
    RHS1      R2985     -25140
    RHS1      R2986     -176
    RHS1      R2987     180
    RHS1      R2988     -4
    RHS1      R2989     6
    RHS1      R2990     -15002
    RHS1      R2991     -180
    RHS1      R2992     159
    RHS1      R2993     -6
    RHS1      R2994     4
    RHS1      R2995     -12602
    RHS1      R2996     -176
    RHS1      R2997     180
    RHS1      R2998     -4
    RHS1      R2999     6
    RHS1      R3000     -32820
    RHS1      R3001     -38520
    RHS1      R3002     -34560
    RHS1      R3003     -40320
    RHS1      R3004     -47400
    RHS1      R3005     -52560
    RHS1      R3006     -48360
    RHS1      R3007     -55020
    RHS1      R3008     -62040
    RHS1      R3009     -67500
    RHS1      R3012     -29
    RHS1      R3014     -75540
    RHS1      R3016     -39600
    RHS1      R3020     -54000
    RHS1      R3024     -71100
    RHS1      R3028     -40937
    RHS1      R3029     71100
    RHS1      R3031     -38031
    RHS1      R3032     71100
    RHS1      R3034     -25749
    RHS1      R3035     71100
    RHS1      R3037     -23969
    RHS1      R3038     71100
    RHS1      R3040     -11425
    RHS1      R3041     71100
    RHS1      R3042     -29
    RHS1      R3043     -29
    RHS1      R3044     -29
    RHS1      R3045     -29
    RHS1      R3046     -29
    RHS1      R3047     -29
    RHS1      R3048     -29
    RHS1      R3049     -29
    RHS1      R3050     -29
    RHS1      R3051     -29
    RHS1      R3052     -29
    RHS1      R3053     -29
    RHS1      R3054     -29
    RHS1      R3055     -29
    RHS1      R3056     -29
    RHS1      R3057     -29
    RHS1      R3058     -29
    RHS1      R3059     -29
    RHS1      R3060     -29
    RHS1      R3061     -29
    RHS1      R3063     17
    RHS1      R3064     17
    RHS1      R3065     17
    RHS1      R3066     17
    RHS1      R3067     17
    RHS1      R3068     17
    RHS1      R3069     17
    RHS1      R3070     17
    RHS1      R3071     17
    RHS1      R3072     17
    RHS1      R3073     17
    RHS1      R3074     17
    RHS1      R3075     17
    RHS1      R3076     17
    RHS1      R3077     17
    RHS1      R3078     17
    RHS1      R3079     17
    RHS1      R3080     17
    RHS1      R3081     17
    RHS1      R3082     17
    RHS1      R3083     17
    RHS1      R3084     17
    RHS1      R3085     17
    RHS1      R3086     17
    RHS1      R3087     17
    RHS1      R3088     17
    RHS1      R3089     17
    RHS1      R3090     17
    RHS1      R3091     17
    RHS1      R3092     17
    RHS1      R3093     17
    RHS1      R3094     17
    RHS1      R3095     17
    RHS1      R3096     17
    RHS1      R3097     17
    RHS1      R3098     17
    RHS1      R3099     17
    RHS1      R3100     17
    RHS1      R3101     17
    RHS1      R3102     17
    RHS1      R3103     17
    RHS1      R3104     17
    RHS1      R3105     17
    RHS1      R3106     17
    RHS1      R3107     17
    RHS1      R3108     17
    RHS1      R3109     17
    RHS1      R3110     17
    RHS1      R3111     17
    RHS1      R3112     17
    RHS1      R3113     17
    RHS1      R3114     17
    RHS1      R3115     17
    RHS1      R3116     17
    RHS1      R3117     17
    RHS1      R3118     17
    RHS1      R3119     17
    RHS1      R3120     17
    RHS1      R3121     17
    RHS1      R3122     17
    RHS1      R3123     17
    RHS1      R3124     17
    RHS1      R3125     17
    RHS1      R3126     17
    RHS1      R3127     17
    RHS1      R3128     17
    RHS1      R3129     17
    RHS1      R3130     17
    RHS1      R3131     17
    RHS1      R3132     17
    RHS1      R3133     17
    RHS1      R3134     17
    RHS1      R3135     17
    RHS1      R3136     17
    RHS1      R3137     17
    RHS1      R3138     17
    RHS1      R3139     17
    RHS1      R3140     17
    RHS1      R3141     17
    RHS1      R3142     17
    RHS1      R3144     1
    RHS1      R3145     1
    RHS1      R3147     1
    RHS1      R3148     1
    RHS1      R3150     1
    RHS1      R3151     1
    RHS1      R3153     1
    RHS1      R3154     1
    RHS1      R3156     1
    RHS1      R3157     1
    RHS1      R3159     1
    RHS1      R3160     1
    RHS1      R3162     1
    RHS1      R3163     1
    RHS1      R3165     1
    RHS1      R3166     1
    RHS1      R3168     1
    RHS1      R3169     1
    RHS1      R3171     1
    RHS1      R3172     1
    RHS1      R3173     600
    RHS1      R3174     -163
    RHS1      R3175     180
    RHS1      R3176     -4
    RHS1      R3177     6
    RHS1      R3178     -29
    RHS1      R3179     -360
    RHS1      R3180     -165
    RHS1      R3181     157
    RHS1      R3182     -5
    RHS1      R3183     4
    RHS1      R3184     -29
    RHS1      R3185     1787
    RHS1      R3186     -161
    RHS1      R3187     180
    RHS1      R3188     -3
    RHS1      R3189     6
    RHS1      R3190     -29
    RHS1      R3191     897
    RHS1      R3192     -161
    RHS1      R3193     180
    RHS1      R3194     -3
    RHS1      R3195     6
    RHS1      R3196     -29
    RHS1      R3197     1144
    RHS1      R3198     -161
    RHS1      R3199     180
    RHS1      R3200     -3
    RHS1      R3201     6
    RHS1      R3202     -29
    RHS1      R3203     1159
    RHS1      R3204     -161
    RHS1      R3205     180
    RHS1      R3206     -3
    RHS1      R3207     6
    RHS1      R3208     -29
    RHS1      R3209     -2760
    RHS1      R3210     -176
    RHS1      R3211     178
    RHS1      R3212     -4
    RHS1      R3213     5
    RHS1      R3214     -29
    RHS1      R3215     897
    RHS1      R3216     -180
    RHS1      R3217     157
    RHS1      R3218     -6
    RHS1      R3219     3
    RHS1      R3220     -29
    RHS1      R3221     897
    RHS1      R3222     -176
    RHS1      R3223     178
    RHS1      R3224     -4
    RHS1      R3225     5
    RHS1      R3226     -29
    RHS1      R3227     1144
    RHS1      R3228     -180
    RHS1      R3229     155
    RHS1      R3230     -6
    RHS1      R3231     3
    RHS1      R3232     -29
    RHS1      R3233     1144
    RHS1      R3234     -176
    RHS1      R3235     178
    RHS1      R3236     -4
    RHS1      R3237     5
    RHS1      R3238     -29
    RHS1      R3239     1159
    RHS1      R3240     -180
    RHS1      R3241     157
    RHS1      R3242     -6
    RHS1      R3243     3
    RHS1      R3244     -29
    RHS1      R3245     1159
    RHS1      R3246     -176
    RHS1      R3247     178
    RHS1      R3248     -4
    RHS1      R3249     5
    RHS1      R3250     -29
    RHS1      R3251     -600
    RHS1      R3252     -155
    RHS1      R3253     180
    RHS1      R3254     -3
    RHS1      R3255     6
    RHS1      R3256     -29
    RHS1      R3257     600
    RHS1      R3258     -153
    RHS1      R3259     180
    RHS1      R3260     -2
    RHS1      R3261     6
    RHS1      R3262     -29
    RHS1      R3263     1525
    RHS1      R3264     -153
    RHS1      R3265     180
    RHS1      R3266     -2
    RHS1      R3267     6
    RHS1      R3268     -29
    RHS1      R3269     1275
    RHS1      R3270     -153
    RHS1      R3271     180
    RHS1      R3272     -2
    RHS1      R3273     6
    RHS1      R3274     -29
    RHS1      R3275     1267
    RHS1      R3276     -153
    RHS1      R3277     180
    RHS1      R3278     -2
    RHS1      R3279     6
    RHS1      R3280     -29
    RHS1      R3281     -6360
    RHS1      R3282     -178
    RHS1      R3283     176
    RHS1      R3284     -5
    RHS1      R3285     4
    RHS1      R3286     -29
    RHS1      R3287     1525
    RHS1      R3288     -180
    RHS1      R3289     155
    RHS1      R3290     -6
    RHS1      R3291     2
    RHS1      R3292     -29
    RHS1      R3293     1525
    RHS1      R3294     -176
    RHS1      R3295     176
    RHS1      R3296     -4
    RHS1      R3297     4
    RHS1      R3298     -29
    RHS1      R3299     1275
    RHS1      R3300     -180
    RHS1      R3301     153
    RHS1      R3302     -6
    RHS1      R3303     2
    RHS1      R3304     -29
    RHS1      R3305     1275
    RHS1      R3306     -176
    RHS1      R3307     176
    RHS1      R3308     -4
    RHS1      R3309     4
    RHS1      R3310     -29
    RHS1      R3311     1267
    RHS1      R3312     -180
    RHS1      R3313     155
    RHS1      R3314     -6
    RHS1      R3315     2
    RHS1      R3316     -29
    RHS1      R3317     1267
    RHS1      R3318     -176
    RHS1      R3319     176
    RHS1      R3320     -4
    RHS1      R3321     4
    RHS1      R3322     -29
    RHS1      R3323     600
    RHS1      R3324     -155
    RHS1      R3325     180
    RHS1      R3326     -2
    RHS1      R3327     6
    RHS1      R3328     -29
    RHS1      R3329     -1140
    RHS1      R3330     -159
    RHS1      R3331     157
    RHS1      R3332     -4
    RHS1      R3333     4
    RHS1      R3334     -29
    RHS1      R3335     963
    RHS1      R3336     -155
    RHS1      R3337     180
    RHS1      R3338     -2
    RHS1      R3339     6
    RHS1      R3340     -29
    RHS1      R3341     869
    RHS1      R3342     -155
    RHS1      R3343     180
    RHS1      R3344     -2
    RHS1      R3345     6
    RHS1      R3346     -29
    RHS1      R3347     -2100
    RHS1      R3348     -176
    RHS1      R3349     176
    RHS1      R3350     -4
    RHS1      R3351     4
    RHS1      R3352     -29
    RHS1      R3353     869
    RHS1      R3354     -180
    RHS1      R3355     155
    RHS1      R3356     -6
    RHS1      R3357     2
    RHS1      R3358     -29
    RHS1      R3359     869
    RHS1      R3360     -176
    RHS1      R3361     176
    RHS1      R3362     -4
    RHS1      R3363     4
    RHS1      R3364     -29
    RHS1      R3365     -2424
    RHS1      R3366     -157
    RHS1      R3367     159
    RHS1      R3368     -4
    RHS1      R3369     4
    RHS1      R3370     -29
    RHS1      R3371     576
    RHS1      R3372     -153
    RHS1      R3373     180
    RHS1      R3374     -2
    RHS1      R3375     6
    RHS1      R3376     -29
    RHS1      R3377     600
    RHS1      R3378     -153
    RHS1      R3379     180
    RHS1      R3380     -2
    RHS1      R3381     6
    RHS1      R3382     -29
    RHS1      R3383     885
    RHS1      R3384     -153
    RHS1      R3385     180
    RHS1      R3386     -2
    RHS1      R3387     6
    RHS1      R3388     -29
    RHS1      R3389     -6084
    RHS1      R3390     -176
    RHS1      R3391     176
    RHS1      R3392     -4
    RHS1      R3393     4
    RHS1      R3394     -29
    RHS1      R3395     885
    RHS1      R3396     -180
    RHS1      R3397     155
    RHS1      R3398     -6
    RHS1      R3399     2
    RHS1      R3400     -29
    RHS1      R3401     885
    RHS1      R3402     -176
    RHS1      R3403     176
    RHS1      R3404     -4
    RHS1      R3405     4
    RHS1      R3406     -29
    RHS1      R3407     600
    RHS1      R3408     -155
    RHS1      R3409     180
    RHS1      R3410     -2
    RHS1      R3411     6
    RHS1      R3412     -29
    RHS1      R3413     1
    RHS1      R3414     1
    RHS1      R3415     1800
    RHS1      R3416     1
    RHS1      R3417     1
    RHS1      R3418     1
    RHS1      R3419     2400
    RHS1      R3420     1
    RHS1      R3421     1
    RHS1      R3422     1
    RHS1      R3423     3000
    RHS1      R3424     1
    RHS1      R3425     1
    RHS1      R3426     1
    RHS1      R3427     2400
    RHS1      R3428     1
    RHS1      R3429     1
    RHS1      R3430     1
    RHS1      R3431     2400
    RHS1      R3432     1
    RHS1      clean_stock_b1  -44
    RHS1      clean_stock_b2  -40
    RHS1      clean_stock_b3  -38
BOUNDS
 FX BND1      delivery_S4_b1  31221
 FX BND1      delivery_S4_b2  46466
 FX BND1      delivery_S4_b3  60021
 FX BND1      C24_order_d  31324
 FX BND1      C24_order_p  33960
 FX BND1      C34_order_d  33360
 FX BND1      C34_order_p  35760
 FX BND1      C95_order_d  46781
 FX BND1      C95_order_p  52560
 FX BND1      C73_order_d  47744
 FX BND1      C73_order_p  50460
 FX BND1      C63_order_d  60598
 FX BND1      C63_order_p  62998
 UP BND1      C13       165
 LO BND1      C14       2
 UP BND1      C14       180
 UP BND1      C15       157
 LO BND1      C16       4
 UP BND1      C16       180
 UP BND1      C17       159
 LO BND1      C18       4
 UP BND1      C18       180
 UP BND1      C19       157
 LO BND1      C20       4
 UP BND1      C20       180
 UP BND1      C21       159
 LO BND1      C22       4
 UP BND1      C22       180
 UP BND1      C23       5
 LO BND1      C24       1
 UP BND1      C24       6
 UP BND1      C25       4
 LO BND1      C26       2
 UP BND1      C26       6
 UP BND1      C27       4
 LO BND1      C28       2
 UP BND1      C28       6
 UP BND1      C29       4
 LO BND1      C30       2
 UP BND1      C30       6
 UP BND1      C31       4
 LO BND1      C32       2
 UP BND1      C32       6
 UP BND1      C33       29
 UP BND1      C34       29
 UP BND1      C35       29
 UP BND1      C36       29
 UP BND1      C37       29
 UP BND1      C38       29
 UP BND1      C39       29
 UP BND1      C40       29
 UP BND1      C41       29
 UP BND1      C42       29
 UP BND1      e1_b1_0_weight[0]  900
 UP BND1      e1_b1_0_weight[1]  900
 UP BND1      e1_b1_0_weight[2]  900
 UP BND1      e1_b1_0_weight[3]  900
 UP BND1      e1_b1_0_volume[0]  60
 UP BND1      e1_b1_0_volume[1]  60
 UP BND1      e1_b1_0_volume[2]  60
 UP BND1      e1_b1_0_volume[3]  60
 BV BND1      C87     
 UP BND1      e1_b1_1_weight[0]  900
 UP BND1      e1_b1_1_weight[1]  900
 UP BND1      e1_b1_1_weight[2]  900
 UP BND1      e1_b1_1_weight[3]  900
 UP BND1      e1_b1_1_volume[0]  60
 UP BND1      e1_b1_1_volume[1]  60
 UP BND1      e1_b1_1_volume[2]  60
 UP BND1      e1_b1_1_volume[3]  60
 BV BND1      C132    
 UP BND1      e1_b1_2_weight[0]  900
 UP BND1      e1_b1_2_weight[1]  900
 UP BND1      e1_b1_2_weight[2]  900
 UP BND1      e1_b1_2_weight[3]  900
 UP BND1      e1_b1_2_volume[0]  60
 UP BND1      e1_b1_2_volume[1]  60
 UP BND1      e1_b1_2_volume[2]  60
 UP BND1      e1_b1_2_volume[3]  60
 BV BND1      C177    
 UP BND1      e1_b2_0_weight[0]  900
 UP BND1      e1_b2_0_weight[1]  900
 UP BND1      e1_b2_0_weight[2]  900
 UP BND1      e1_b2_0_weight[3]  900
 UP BND1      e1_b2_0_volume[0]  60
 UP BND1      e1_b2_0_volume[1]  60
 UP BND1      e1_b2_0_volume[2]  60
 UP BND1      e1_b2_0_volume[3]  60
 BV BND1      C222    
 BV BND1      C223    
 UP BND1      e1_b2_1_weight[0]  900
 UP BND1      e1_b2_1_weight[1]  900
 UP BND1      e1_b2_1_weight[2]  900
 UP BND1      e1_b2_1_weight[3]  900
 UP BND1      e1_b2_1_volume[0]  60
 UP BND1      e1_b2_1_volume[1]  60
 UP BND1      e1_b2_1_volume[2]  60
 UP BND1      e1_b2_1_volume[3]  60
 BV BND1      C268    
 BV BND1      C269    
 UP BND1      e1_b2_2_weight[0]  900
 UP BND1      e1_b2_2_weight[1]  900
 UP BND1      e1_b2_2_weight[2]  900
 UP BND1      e1_b2_2_weight[3]  900
 UP BND1      e1_b2_2_volume[0]  60
 UP BND1      e1_b2_2_volume[1]  60
 UP BND1      e1_b2_2_volume[2]  60
 UP BND1      e1_b2_2_volume[3]  60
 BV BND1      C314    
 BV BND1      C315    
 UP BND1      e1_b3_0_weight[0]  900
 UP BND1      e1_b3_0_weight[1]  900
 UP BND1      e1_b3_0_weight[2]  900
 UP BND1      e1_b3_0_weight[3]  900
 UP BND1      e1_b3_0_volume[0]  60
 UP BND1      e1_b3_0_volume[1]  60
 UP BND1      e1_b3_0_volume[2]  60
 UP BND1      e1_b3_0_volume[3]  60
 BV BND1      C360    
 BV BND1      C361    
 BV BND1      C362    
 UP BND1      e1_b3_1_weight[0]  900
 UP BND1      e1_b3_1_weight[1]  900
 UP BND1      e1_b3_1_weight[2]  900
 UP BND1      e1_b3_1_weight[3]  900
 UP BND1      e1_b3_1_volume[0]  60
 UP BND1      e1_b3_1_volume[1]  60
 UP BND1      e1_b3_1_volume[2]  60
 UP BND1      e1_b3_1_volume[3]  60
 BV BND1      C407    
 BV BND1      C408    
 BV BND1      C409    
 UP BND1      e1_b3_2_weight[0]  900
 UP BND1      e1_b3_2_weight[1]  900
 UP BND1      e1_b3_2_weight[2]  900
 UP BND1      e1_b3_2_weight[3]  900
 UP BND1      e1_b3_2_volume[0]  60
 UP BND1      e1_b3_2_volume[1]  60
 UP BND1      e1_b3_2_volume[2]  60
 UP BND1      e1_b3_2_volume[3]  60
 BV BND1      C454    
 BV BND1      C455    
 BV BND1      C456    
 FX BND1      pickup_return_C24_order  39601
 BV BND1      eligible_C24_order_b1
 BV BND1      eligible_C24_order_b2
 FX BND1      pickup_return_C34_order  54000
 BV BND1      eligible_C34_order_b1
 BV BND1      eligible_C34_order_b2
 FX BND1      pickup_return_C95_order  54000
 BV BND1      eligible_C95_order_b2
 FX BND1      pickup_return_C73_order  64175
 BV BND1      eligible_C73_order_b2
 FX BND1      pickup_return_C63_order  64175
 FX BND1      e2_S4_0_0_used  1
 BV BND1      e2_S4_0_0_used
 FX BND1      e2_S4_0_0_start  31281
 FX BND1      e2_S4_0_0_end  39601
 FX BND1      e2_S4_0_0_visit[0]  1
 BV BND1      e2_S4_0_0_visit[0]
 FX BND1      e2_S4_0_0_visit[1]  1
 BV BND1      e2_S4_0_0_visit[1]
 FX BND1      e2_S4_0_0_visit[2]  0
 BV BND1      e2_S4_0_0_visit[2]
 FX BND1      e2_S4_0_0_visit[3]  0
 BV BND1      e2_S4_0_0_visit[3]
 FX BND1      e2_S4_0_0_visit[4]  0
 BV BND1      e2_S4_0_0_visit[4]
 FX BND1      e2_S4_0_0_visit[5]  0
 BV BND1      e2_S4_0_0_visit[5]
 FX BND1      e2_S4_0_0_visit[6]  0
 BV BND1      e2_S4_0_0_visit[6]
 FX BND1      e2_S4_0_0_visit[7]  0
 BV BND1      e2_S4_0_0_visit[7]
 FX BND1      e2_S4_0_0_visit[8]  0
 BV BND1      e2_S4_0_0_visit[8]
 FX BND1      e2_S4_0_0_visit[9]  0
 BV BND1      e2_S4_0_0_visit[9]
 FX BND1      e2_S4_0_0_arc[-1,0]  1
 BV BND1      e2_S4_0_0_arc[-1,0]
 FX BND1      e2_S4_0_0_arc[-1,1]  0
 BV BND1      e2_S4_0_0_arc[-1,1]
 FX BND1      e2_S4_0_0_arc[-1,2]  0
 BV BND1      e2_S4_0_0_arc[-1,2]
 FX BND1      e2_S4_0_0_arc[-1,3]  0
 BV BND1      e2_S4_0_0_arc[-1,3]
 FX BND1      e2_S4_0_0_arc[-1,4]  0
 BV BND1      e2_S4_0_0_arc[-1,4]
 FX BND1      e2_S4_0_0_arc[-1,5]  0
 BV BND1      e2_S4_0_0_arc[-1,5]
 FX BND1      e2_S4_0_0_arc[-1,6]  0
 BV BND1      e2_S4_0_0_arc[-1,6]
 FX BND1      e2_S4_0_0_arc[-1,7]  0
 BV BND1      e2_S4_0_0_arc[-1,7]
 FX BND1      e2_S4_0_0_arc[-1,8]  0
 BV BND1      e2_S4_0_0_arc[-1,8]
 FX BND1      e2_S4_0_0_arc[-1,9]  0
 BV BND1      e2_S4_0_0_arc[-1,9]
 FX BND1      e2_S4_0_0_arc[0,-2]  0
 BV BND1      e2_S4_0_0_arc[0,-2]
 FX BND1      e2_S4_0_0_arc[1,-2]  1
 BV BND1      e2_S4_0_0_arc[1,-2]
 FX BND1      e2_S4_0_0_arc[2,-2]  0
 BV BND1      e2_S4_0_0_arc[2,-2]
 FX BND1      e2_S4_0_0_arc[3,-2]  0
 BV BND1      e2_S4_0_0_arc[3,-2]
 FX BND1      e2_S4_0_0_arc[4,-2]  0
 BV BND1      e2_S4_0_0_arc[4,-2]
 FX BND1      e2_S4_0_0_arc[5,-2]  0
 BV BND1      e2_S4_0_0_arc[5,-2]
 FX BND1      e2_S4_0_0_arc[6,-2]  0
 BV BND1      e2_S4_0_0_arc[6,-2]
 FX BND1      e2_S4_0_0_arc[7,-2]  0
 BV BND1      e2_S4_0_0_arc[7,-2]
 FX BND1      e2_S4_0_0_arc[8,-2]  0
 BV BND1      e2_S4_0_0_arc[8,-2]
 FX BND1      e2_S4_0_0_arc[9,-2]  0
 BV BND1      e2_S4_0_0_arc[9,-2]
 FX BND1      m5_link_0  1
 BV BND1      m5_link_0
 FX BND1      m5_link_1  0
 BV BND1      m5_link_1
 FX BND1      m5_link_2  0
 BV BND1      m5_link_2
 FX BND1      m5_link_3  0
 BV BND1      m5_link_3
 FX BND1      m5_link_4  0
 BV BND1      m5_link_4
 FX BND1      m5_link_5  0
 BV BND1      m5_link_5
 FX BND1      m5_link_6  0
 BV BND1      m5_link_6
 FX BND1      m5_link_7  0
 BV BND1      m5_link_7
 FX BND1      m5_link_8  0
 BV BND1      m5_link_8
 FX BND1      m5_link_9  0
 BV BND1      m5_link_9
 FX BND1      m5_link_10  0
 BV BND1      m5_link_10
 FX BND1      m5_link_11  0
 BV BND1      m5_link_11
 FX BND1      m5_link_12  0
 BV BND1      m5_link_12
 FX BND1      m5_link_13  0
 BV BND1      m5_link_13
 FX BND1      m5_link_14  1
 BV BND1      m5_link_14
 FX BND1      m5_link_15  0
 BV BND1      m5_link_15
 FX BND1      m5_link_16  0
 BV BND1      m5_link_16
 FX BND1      m5_link_17  0
 BV BND1      m5_link_17
 FX BND1      m5_link_18  0
 BV BND1      m5_link_18
 FX BND1      m5_link_19  0
 BV BND1      m5_link_19
 FX BND1      m5_link_20  1
 BV BND1      m5_link_20
 FX BND1      m5_link_21  0
 BV BND1      m5_link_21
 FX BND1      m5_link_22  0
 BV BND1      m5_link_22
 FX BND1      m5_link_23  0
 BV BND1      m5_link_23
 FX BND1      m5_link_24  0
 BV BND1      m5_link_24
 FX BND1      m5_link_25  0
 BV BND1      m5_link_25
 FX BND1      m5_link_26  1
 BV BND1      m5_link_26
 FX BND1      m5_link_27  0
 BV BND1      m5_link_27
 FX BND1      m5_link_28  0
 BV BND1      m5_link_28
 FX BND1      m5_link_29  0
 BV BND1      m5_link_29
 FX BND1      m5_link_30  0
 BV BND1      m5_link_30
 FX BND1      m5_link_31  0
 BV BND1      m5_link_31
 FX BND1      m5_link_32  0
 BV BND1      m5_link_32
 FX BND1      m5_link_33  0
 BV BND1      m5_link_33
 FX BND1      m5_link_34  1
 BV BND1      m5_link_34
 FX BND1      m5_link_35  0
 BV BND1      m5_link_35
 FX BND1      m5_link_36  0
 BV BND1      m5_link_36
 FX BND1      m5_link_37  0
 BV BND1      m5_link_37
 FX BND1      m5_link_38  0
 BV BND1      m5_link_38
 FX BND1      m5_link_39  1
 BV BND1      m5_link_39
 UP BND1      C541      29
 UP BND1      C542      29
 BV BND1      C543    
 BV BND1      C544    
 BV BND1      C545    
 FX BND1      e2_S4_0_1_used  1
 BV BND1      e2_S4_0_1_used
 FX BND1      e2_S4_0_1_start  60081
 FX BND1      e2_S4_0_1_end  64175
 FX BND1      e2_S4_0_1_visit[0]  0
 BV BND1      e2_S4_0_1_visit[0]
 FX BND1      e2_S4_0_1_visit[1]  0
 BV BND1      e2_S4_0_1_visit[1]
 FX BND1      e2_S4_0_1_visit[2]  0
 BV BND1      e2_S4_0_1_visit[2]
 FX BND1      e2_S4_0_1_visit[3]  0
 BV BND1      e2_S4_0_1_visit[3]
 FX BND1      e2_S4_0_1_visit[4]  0
 BV BND1      e2_S4_0_1_visit[4]
 FX BND1      e2_S4_0_1_visit[5]  0
 BV BND1      e2_S4_0_1_visit[5]
 FX BND1      e2_S4_0_1_visit[6]  0
 BV BND1      e2_S4_0_1_visit[6]
 FX BND1      e2_S4_0_1_visit[7]  0
 BV BND1      e2_S4_0_1_visit[7]
 FX BND1      e2_S4_0_1_visit[8]  1
 BV BND1      e2_S4_0_1_visit[8]
 FX BND1      e2_S4_0_1_visit[9]  1
 BV BND1      e2_S4_0_1_visit[9]
 FX BND1      e2_S4_0_1_arc[-1,0]  0
 BV BND1      e2_S4_0_1_arc[-1,0]
 FX BND1      e2_S4_0_1_arc[-1,1]  0
 BV BND1      e2_S4_0_1_arc[-1,1]
 FX BND1      e2_S4_0_1_arc[-1,2]  0
 BV BND1      e2_S4_0_1_arc[-1,2]
 FX BND1      e2_S4_0_1_arc[-1,3]  0
 BV BND1      e2_S4_0_1_arc[-1,3]
 FX BND1      e2_S4_0_1_arc[-1,4]  0
 BV BND1      e2_S4_0_1_arc[-1,4]
 FX BND1      e2_S4_0_1_arc[-1,5]  0
 BV BND1      e2_S4_0_1_arc[-1,5]
 FX BND1      e2_S4_0_1_arc[-1,6]  0
 BV BND1      e2_S4_0_1_arc[-1,6]
 FX BND1      e2_S4_0_1_arc[-1,7]  0
 BV BND1      e2_S4_0_1_arc[-1,7]
 FX BND1      e2_S4_0_1_arc[-1,8]  1
 BV BND1      e2_S4_0_1_arc[-1,8]
 FX BND1      e2_S4_0_1_arc[-1,9]  0
 BV BND1      e2_S4_0_1_arc[-1,9]
 FX BND1      e2_S4_0_1_arc[0,-2]  0
 BV BND1      e2_S4_0_1_arc[0,-2]
 FX BND1      e2_S4_0_1_arc[1,-2]  0
 BV BND1      e2_S4_0_1_arc[1,-2]
 FX BND1      e2_S4_0_1_arc[2,-2]  0
 BV BND1      e2_S4_0_1_arc[2,-2]
 FX BND1      e2_S4_0_1_arc[3,-2]  0
 BV BND1      e2_S4_0_1_arc[3,-2]
 FX BND1      e2_S4_0_1_arc[4,-2]  0
 BV BND1      e2_S4_0_1_arc[4,-2]
 FX BND1      e2_S4_0_1_arc[5,-2]  0
 BV BND1      e2_S4_0_1_arc[5,-2]
 FX BND1      e2_S4_0_1_arc[6,-2]  0
 BV BND1      e2_S4_0_1_arc[6,-2]
 FX BND1      e2_S4_0_1_arc[7,-2]  0
 BV BND1      e2_S4_0_1_arc[7,-2]
 FX BND1      e2_S4_0_1_arc[8,-2]  0
 BV BND1      e2_S4_0_1_arc[8,-2]
 FX BND1      e2_S4_0_1_arc[9,-2]  1
 BV BND1      e2_S4_0_1_arc[9,-2]
 UP BND1      C579      29
 UP BND1      C580      29
 BV BND1      C581    
 BV BND1      C582    
 BV BND1      C583    
 FX BND1      e2_S4_0_2_used  0
 BV BND1      e2_S4_0_2_used
 FX BND1      e2_S4_0_2_start  0
 FX BND1      e2_S4_0_2_end  0
 FX BND1      e2_S4_0_2_visit[0]  0
 BV BND1      e2_S4_0_2_visit[0]
 FX BND1      e2_S4_0_2_visit[1]  0
 BV BND1      e2_S4_0_2_visit[1]
 FX BND1      e2_S4_0_2_visit[2]  0
 BV BND1      e2_S4_0_2_visit[2]
 FX BND1      e2_S4_0_2_visit[3]  0
 BV BND1      e2_S4_0_2_visit[3]
 FX BND1      e2_S4_0_2_visit[4]  0
 BV BND1      e2_S4_0_2_visit[4]
 FX BND1      e2_S4_0_2_visit[5]  0
 BV BND1      e2_S4_0_2_visit[5]
 FX BND1      e2_S4_0_2_visit[6]  0
 BV BND1      e2_S4_0_2_visit[6]
 FX BND1      e2_S4_0_2_visit[7]  0
 BV BND1      e2_S4_0_2_visit[7]
 FX BND1      e2_S4_0_2_visit[8]  0
 BV BND1      e2_S4_0_2_visit[8]
 FX BND1      e2_S4_0_2_visit[9]  0
 BV BND1      e2_S4_0_2_visit[9]
 FX BND1      e2_S4_0_2_arc[-1,0]  0
 BV BND1      e2_S4_0_2_arc[-1,0]
 FX BND1      e2_S4_0_2_arc[-1,1]  0
 BV BND1      e2_S4_0_2_arc[-1,1]
 FX BND1      e2_S4_0_2_arc[-1,2]  0
 BV BND1      e2_S4_0_2_arc[-1,2]
 FX BND1      e2_S4_0_2_arc[-1,3]  0
 BV BND1      e2_S4_0_2_arc[-1,3]
 FX BND1      e2_S4_0_2_arc[-1,4]  0
 BV BND1      e2_S4_0_2_arc[-1,4]
 FX BND1      e2_S4_0_2_arc[-1,5]  0
 BV BND1      e2_S4_0_2_arc[-1,5]
 FX BND1      e2_S4_0_2_arc[-1,6]  0
 BV BND1      e2_S4_0_2_arc[-1,6]
 FX BND1      e2_S4_0_2_arc[-1,7]  0
 BV BND1      e2_S4_0_2_arc[-1,7]
 FX BND1      e2_S4_0_2_arc[-1,8]  0
 BV BND1      e2_S4_0_2_arc[-1,8]
 FX BND1      e2_S4_0_2_arc[-1,9]  0
 BV BND1      e2_S4_0_2_arc[-1,9]
 FX BND1      e2_S4_0_2_arc[0,-2]  0
 BV BND1      e2_S4_0_2_arc[0,-2]
 FX BND1      e2_S4_0_2_arc[1,-2]  0
 BV BND1      e2_S4_0_2_arc[1,-2]
 FX BND1      e2_S4_0_2_arc[2,-2]  0
 BV BND1      e2_S4_0_2_arc[2,-2]
 FX BND1      e2_S4_0_2_arc[3,-2]  0
 BV BND1      e2_S4_0_2_arc[3,-2]
 FX BND1      e2_S4_0_2_arc[4,-2]  0
 BV BND1      e2_S4_0_2_arc[4,-2]
 FX BND1      e2_S4_0_2_arc[5,-2]  0
 BV BND1      e2_S4_0_2_arc[5,-2]
 FX BND1      e2_S4_0_2_arc[6,-2]  0
 BV BND1      e2_S4_0_2_arc[6,-2]
 FX BND1      e2_S4_0_2_arc[7,-2]  0
 BV BND1      e2_S4_0_2_arc[7,-2]
 FX BND1      e2_S4_0_2_arc[8,-2]  0
 BV BND1      e2_S4_0_2_arc[8,-2]
 FX BND1      e2_S4_0_2_arc[9,-2]  0
 BV BND1      e2_S4_0_2_arc[9,-2]
 UP BND1      C617      29
 UP BND1      C618      29
 BV BND1      C619    
 BV BND1      C620    
 BV BND1      C621    
 FX BND1      e2_S4_0_3_used  0
 BV BND1      e2_S4_0_3_used
 FX BND1      e2_S4_0_3_start  0
 FX BND1      e2_S4_0_3_end  0
 FX BND1      e2_S4_0_3_visit[0]  0
 BV BND1      e2_S4_0_3_visit[0]
 FX BND1      e2_S4_0_3_visit[1]  0
 BV BND1      e2_S4_0_3_visit[1]
 FX BND1      e2_S4_0_3_visit[2]  0
 BV BND1      e2_S4_0_3_visit[2]
 FX BND1      e2_S4_0_3_visit[3]  0
 BV BND1      e2_S4_0_3_visit[3]
 FX BND1      e2_S4_0_3_visit[4]  0
 BV BND1      e2_S4_0_3_visit[4]
 FX BND1      e2_S4_0_3_visit[5]  0
 BV BND1      e2_S4_0_3_visit[5]
 FX BND1      e2_S4_0_3_visit[6]  0
 BV BND1      e2_S4_0_3_visit[6]
 FX BND1      e2_S4_0_3_visit[7]  0
 BV BND1      e2_S4_0_3_visit[7]
 FX BND1      e2_S4_0_3_visit[8]  0
 BV BND1      e2_S4_0_3_visit[8]
 FX BND1      e2_S4_0_3_visit[9]  0
 BV BND1      e2_S4_0_3_visit[9]
 FX BND1      e2_S4_0_3_arc[-1,0]  0
 BV BND1      e2_S4_0_3_arc[-1,0]
 FX BND1      e2_S4_0_3_arc[-1,1]  0
 BV BND1      e2_S4_0_3_arc[-1,1]
 FX BND1      e2_S4_0_3_arc[-1,2]  0
 BV BND1      e2_S4_0_3_arc[-1,2]
 FX BND1      e2_S4_0_3_arc[-1,3]  0
 BV BND1      e2_S4_0_3_arc[-1,3]
 FX BND1      e2_S4_0_3_arc[-1,4]  0
 BV BND1      e2_S4_0_3_arc[-1,4]
 FX BND1      e2_S4_0_3_arc[-1,5]  0
 BV BND1      e2_S4_0_3_arc[-1,5]
 FX BND1      e2_S4_0_3_arc[-1,6]  0
 BV BND1      e2_S4_0_3_arc[-1,6]
 FX BND1      e2_S4_0_3_arc[-1,7]  0
 BV BND1      e2_S4_0_3_arc[-1,7]
 FX BND1      e2_S4_0_3_arc[-1,8]  0
 BV BND1      e2_S4_0_3_arc[-1,8]
 FX BND1      e2_S4_0_3_arc[-1,9]  0
 BV BND1      e2_S4_0_3_arc[-1,9]
 FX BND1      e2_S4_0_3_arc[0,-2]  0
 BV BND1      e2_S4_0_3_arc[0,-2]
 FX BND1      e2_S4_0_3_arc[1,-2]  0
 BV BND1      e2_S4_0_3_arc[1,-2]
 FX BND1      e2_S4_0_3_arc[2,-2]  0
 BV BND1      e2_S4_0_3_arc[2,-2]
 FX BND1      e2_S4_0_3_arc[3,-2]  0
 BV BND1      e2_S4_0_3_arc[3,-2]
 FX BND1      e2_S4_0_3_arc[4,-2]  0
 BV BND1      e2_S4_0_3_arc[4,-2]
 FX BND1      e2_S4_0_3_arc[5,-2]  0
 BV BND1      e2_S4_0_3_arc[5,-2]
 FX BND1      e2_S4_0_3_arc[6,-2]  0
 BV BND1      e2_S4_0_3_arc[6,-2]
 FX BND1      e2_S4_0_3_arc[7,-2]  0
 BV BND1      e2_S4_0_3_arc[7,-2]
 FX BND1      e2_S4_0_3_arc[8,-2]  0
 BV BND1      e2_S4_0_3_arc[8,-2]
 FX BND1      e2_S4_0_3_arc[9,-2]  0
 BV BND1      e2_S4_0_3_arc[9,-2]
 UP BND1      C655      29
 UP BND1      C656      29
 BV BND1      C657    
 BV BND1      C658    
 BV BND1      C659    
 FX BND1      e2_S4_0_4_used  0
 BV BND1      e2_S4_0_4_used
 FX BND1      e2_S4_0_4_start  0
 FX BND1      e2_S4_0_4_end  0
 FX BND1      e2_S4_0_4_visit[0]  0
 BV BND1      e2_S4_0_4_visit[0]
 FX BND1      e2_S4_0_4_visit[1]  0
 BV BND1      e2_S4_0_4_visit[1]
 FX BND1      e2_S4_0_4_visit[2]  0
 BV BND1      e2_S4_0_4_visit[2]
 FX BND1      e2_S4_0_4_visit[3]  0
 BV BND1      e2_S4_0_4_visit[3]
 FX BND1      e2_S4_0_4_visit[4]  0
 BV BND1      e2_S4_0_4_visit[4]
 FX BND1      e2_S4_0_4_visit[5]  0
 BV BND1      e2_S4_0_4_visit[5]
 FX BND1      e2_S4_0_4_visit[6]  0
 BV BND1      e2_S4_0_4_visit[6]
 FX BND1      e2_S4_0_4_visit[7]  0
 BV BND1      e2_S4_0_4_visit[7]
 FX BND1      e2_S4_0_4_visit[8]  0
 BV BND1      e2_S4_0_4_visit[8]
 FX BND1      e2_S4_0_4_visit[9]  0
 BV BND1      e2_S4_0_4_visit[9]
 FX BND1      e2_S4_0_4_arc[-1,0]  0
 BV BND1      e2_S4_0_4_arc[-1,0]
 FX BND1      e2_S4_0_4_arc[-1,1]  0
 BV BND1      e2_S4_0_4_arc[-1,1]
 FX BND1      e2_S4_0_4_arc[-1,2]  0
 BV BND1      e2_S4_0_4_arc[-1,2]
 FX BND1      e2_S4_0_4_arc[-1,3]  0
 BV BND1      e2_S4_0_4_arc[-1,3]
 FX BND1      e2_S4_0_4_arc[-1,4]  0
 BV BND1      e2_S4_0_4_arc[-1,4]
 FX BND1      e2_S4_0_4_arc[-1,5]  0
 BV BND1      e2_S4_0_4_arc[-1,5]
 FX BND1      e2_S4_0_4_arc[-1,6]  0
 BV BND1      e2_S4_0_4_arc[-1,6]
 FX BND1      e2_S4_0_4_arc[-1,7]  0
 BV BND1      e2_S4_0_4_arc[-1,7]
 FX BND1      e2_S4_0_4_arc[-1,8]  0
 BV BND1      e2_S4_0_4_arc[-1,8]
 FX BND1      e2_S4_0_4_arc[-1,9]  0
 BV BND1      e2_S4_0_4_arc[-1,9]
 FX BND1      e2_S4_0_4_arc[0,-2]  0
 BV BND1      e2_S4_0_4_arc[0,-2]
 FX BND1      e2_S4_0_4_arc[1,-2]  0
 BV BND1      e2_S4_0_4_arc[1,-2]
 FX BND1      e2_S4_0_4_arc[2,-2]  0
 BV BND1      e2_S4_0_4_arc[2,-2]
 FX BND1      e2_S4_0_4_arc[3,-2]  0
 BV BND1      e2_S4_0_4_arc[3,-2]
 FX BND1      e2_S4_0_4_arc[4,-2]  0
 BV BND1      e2_S4_0_4_arc[4,-2]
 FX BND1      e2_S4_0_4_arc[5,-2]  0
 BV BND1      e2_S4_0_4_arc[5,-2]
 FX BND1      e2_S4_0_4_arc[6,-2]  0
 BV BND1      e2_S4_0_4_arc[6,-2]
 FX BND1      e2_S4_0_4_arc[7,-2]  0
 BV BND1      e2_S4_0_4_arc[7,-2]
 FX BND1      e2_S4_0_4_arc[8,-2]  0
 BV BND1      e2_S4_0_4_arc[8,-2]
 FX BND1      e2_S4_0_4_arc[9,-2]  0
 BV BND1      e2_S4_0_4_arc[9,-2]
 UP BND1      C693      29
 UP BND1      C694      29
 BV BND1      C695    
 BV BND1      C696    
 BV BND1      C697    
 FX BND1      e2_S4_0_5_used  0
 BV BND1      e2_S4_0_5_used
 FX BND1      e2_S4_0_5_start  0
 FX BND1      e2_S4_0_5_end  0
 FX BND1      e2_S4_0_5_visit[0]  0
 BV BND1      e2_S4_0_5_visit[0]
 FX BND1      e2_S4_0_5_visit[1]  0
 BV BND1      e2_S4_0_5_visit[1]
 FX BND1      e2_S4_0_5_visit[2]  0
 BV BND1      e2_S4_0_5_visit[2]
 FX BND1      e2_S4_0_5_visit[3]  0
 BV BND1      e2_S4_0_5_visit[3]
 FX BND1      e2_S4_0_5_visit[4]  0
 BV BND1      e2_S4_0_5_visit[4]
 FX BND1      e2_S4_0_5_visit[5]  0
 BV BND1      e2_S4_0_5_visit[5]
 FX BND1      e2_S4_0_5_visit[6]  0
 BV BND1      e2_S4_0_5_visit[6]
 FX BND1      e2_S4_0_5_visit[7]  0
 BV BND1      e2_S4_0_5_visit[7]
 FX BND1      e2_S4_0_5_visit[8]  0
 BV BND1      e2_S4_0_5_visit[8]
 FX BND1      e2_S4_0_5_visit[9]  0
 BV BND1      e2_S4_0_5_visit[9]
 FX BND1      e2_S4_0_5_arc[-1,0]  0
 BV BND1      e2_S4_0_5_arc[-1,0]
 FX BND1      e2_S4_0_5_arc[-1,1]  0
 BV BND1      e2_S4_0_5_arc[-1,1]
 FX BND1      e2_S4_0_5_arc[-1,2]  0
 BV BND1      e2_S4_0_5_arc[-1,2]
 FX BND1      e2_S4_0_5_arc[-1,3]  0
 BV BND1      e2_S4_0_5_arc[-1,3]
 FX BND1      e2_S4_0_5_arc[-1,4]  0
 BV BND1      e2_S4_0_5_arc[-1,4]
 FX BND1      e2_S4_0_5_arc[-1,5]  0
 BV BND1      e2_S4_0_5_arc[-1,5]
 FX BND1      e2_S4_0_5_arc[-1,6]  0
 BV BND1      e2_S4_0_5_arc[-1,6]
 FX BND1      e2_S4_0_5_arc[-1,7]  0
 BV BND1      e2_S4_0_5_arc[-1,7]
 FX BND1      e2_S4_0_5_arc[-1,8]  0
 BV BND1      e2_S4_0_5_arc[-1,8]
 FX BND1      e2_S4_0_5_arc[-1,9]  0
 BV BND1      e2_S4_0_5_arc[-1,9]
 FX BND1      e2_S4_0_5_arc[0,-2]  0
 BV BND1      e2_S4_0_5_arc[0,-2]
 FX BND1      e2_S4_0_5_arc[1,-2]  0
 BV BND1      e2_S4_0_5_arc[1,-2]
 FX BND1      e2_S4_0_5_arc[2,-2]  0
 BV BND1      e2_S4_0_5_arc[2,-2]
 FX BND1      e2_S4_0_5_arc[3,-2]  0
 BV BND1      e2_S4_0_5_arc[3,-2]
 FX BND1      e2_S4_0_5_arc[4,-2]  0
 BV BND1      e2_S4_0_5_arc[4,-2]
 FX BND1      e2_S4_0_5_arc[5,-2]  0
 BV BND1      e2_S4_0_5_arc[5,-2]
 FX BND1      e2_S4_0_5_arc[6,-2]  0
 BV BND1      e2_S4_0_5_arc[6,-2]
 FX BND1      e2_S4_0_5_arc[7,-2]  0
 BV BND1      e2_S4_0_5_arc[7,-2]
 FX BND1      e2_S4_0_5_arc[8,-2]  0
 BV BND1      e2_S4_0_5_arc[8,-2]
 FX BND1      e2_S4_0_5_arc[9,-2]  0
 BV BND1      e2_S4_0_5_arc[9,-2]
 UP BND1      C731      29
 UP BND1      C732      29
 BV BND1      C733    
 BV BND1      C734    
 BV BND1      C735    
 FX BND1      e2_S4_0_6_used  0
 BV BND1      e2_S4_0_6_used
 FX BND1      e2_S4_0_6_start  0
 FX BND1      e2_S4_0_6_end  0
 FX BND1      e2_S4_0_6_visit[0]  0
 BV BND1      e2_S4_0_6_visit[0]
 FX BND1      e2_S4_0_6_visit[1]  0
 BV BND1      e2_S4_0_6_visit[1]
 FX BND1      e2_S4_0_6_visit[2]  0
 BV BND1      e2_S4_0_6_visit[2]
 FX BND1      e2_S4_0_6_visit[3]  0
 BV BND1      e2_S4_0_6_visit[3]
 FX BND1      e2_S4_0_6_visit[4]  0
 BV BND1      e2_S4_0_6_visit[4]
 FX BND1      e2_S4_0_6_visit[5]  0
 BV BND1      e2_S4_0_6_visit[5]
 FX BND1      e2_S4_0_6_visit[6]  0
 BV BND1      e2_S4_0_6_visit[6]
 FX BND1      e2_S4_0_6_visit[7]  0
 BV BND1      e2_S4_0_6_visit[7]
 FX BND1      e2_S4_0_6_visit[8]  0
 BV BND1      e2_S4_0_6_visit[8]
 FX BND1      e2_S4_0_6_visit[9]  0
 BV BND1      e2_S4_0_6_visit[9]
 FX BND1      e2_S4_0_6_arc[-1,0]  0
 BV BND1      e2_S4_0_6_arc[-1,0]
 FX BND1      e2_S4_0_6_arc[-1,1]  0
 BV BND1      e2_S4_0_6_arc[-1,1]
 FX BND1      e2_S4_0_6_arc[-1,2]  0
 BV BND1      e2_S4_0_6_arc[-1,2]
 FX BND1      e2_S4_0_6_arc[-1,3]  0
 BV BND1      e2_S4_0_6_arc[-1,3]
 FX BND1      e2_S4_0_6_arc[-1,4]  0
 BV BND1      e2_S4_0_6_arc[-1,4]
 FX BND1      e2_S4_0_6_arc[-1,5]  0
 BV BND1      e2_S4_0_6_arc[-1,5]
 FX BND1      e2_S4_0_6_arc[-1,6]  0
 BV BND1      e2_S4_0_6_arc[-1,6]
 FX BND1      e2_S4_0_6_arc[-1,7]  0
 BV BND1      e2_S4_0_6_arc[-1,7]
 FX BND1      e2_S4_0_6_arc[-1,8]  0
 BV BND1      e2_S4_0_6_arc[-1,8]
 FX BND1      e2_S4_0_6_arc[-1,9]  0
 BV BND1      e2_S4_0_6_arc[-1,9]
 FX BND1      e2_S4_0_6_arc[0,-2]  0
 BV BND1      e2_S4_0_6_arc[0,-2]
 FX BND1      e2_S4_0_6_arc[1,-2]  0
 BV BND1      e2_S4_0_6_arc[1,-2]
 FX BND1      e2_S4_0_6_arc[2,-2]  0
 BV BND1      e2_S4_0_6_arc[2,-2]
 FX BND1      e2_S4_0_6_arc[3,-2]  0
 BV BND1      e2_S4_0_6_arc[3,-2]
 FX BND1      e2_S4_0_6_arc[4,-2]  0
 BV BND1      e2_S4_0_6_arc[4,-2]
 FX BND1      e2_S4_0_6_arc[5,-2]  0
 BV BND1      e2_S4_0_6_arc[5,-2]
 FX BND1      e2_S4_0_6_arc[6,-2]  0
 BV BND1      e2_S4_0_6_arc[6,-2]
 FX BND1      e2_S4_0_6_arc[7,-2]  0
 BV BND1      e2_S4_0_6_arc[7,-2]
 FX BND1      e2_S4_0_6_arc[8,-2]  0
 BV BND1      e2_S4_0_6_arc[8,-2]
 FX BND1      e2_S4_0_6_arc[9,-2]  0
 BV BND1      e2_S4_0_6_arc[9,-2]
 UP BND1      C769      29
 UP BND1      C770      29
 BV BND1      C771    
 BV BND1      C772    
 BV BND1      C773    
 FX BND1      e2_S4_0_7_used  0
 BV BND1      e2_S4_0_7_used
 FX BND1      e2_S4_0_7_start  0
 FX BND1      e2_S4_0_7_end  0
 FX BND1      e2_S4_0_7_visit[0]  0
 BV BND1      e2_S4_0_7_visit[0]
 FX BND1      e2_S4_0_7_visit[1]  0
 BV BND1      e2_S4_0_7_visit[1]
 FX BND1      e2_S4_0_7_visit[2]  0
 BV BND1      e2_S4_0_7_visit[2]
 FX BND1      e2_S4_0_7_visit[3]  0
 BV BND1      e2_S4_0_7_visit[3]
 FX BND1      e2_S4_0_7_visit[4]  0
 BV BND1      e2_S4_0_7_visit[4]
 FX BND1      e2_S4_0_7_visit[5]  0
 BV BND1      e2_S4_0_7_visit[5]
 FX BND1      e2_S4_0_7_visit[6]  0
 BV BND1      e2_S4_0_7_visit[6]
 FX BND1      e2_S4_0_7_visit[7]  0
 BV BND1      e2_S4_0_7_visit[7]
 FX BND1      e2_S4_0_7_visit[8]  0
 BV BND1      e2_S4_0_7_visit[8]
 FX BND1      e2_S4_0_7_visit[9]  0
 BV BND1      e2_S4_0_7_visit[9]
 FX BND1      e2_S4_0_7_arc[-1,0]  0
 BV BND1      e2_S4_0_7_arc[-1,0]
 FX BND1      e2_S4_0_7_arc[-1,1]  0
 BV BND1      e2_S4_0_7_arc[-1,1]
 FX BND1      e2_S4_0_7_arc[-1,2]  0
 BV BND1      e2_S4_0_7_arc[-1,2]
 FX BND1      e2_S4_0_7_arc[-1,3]  0
 BV BND1      e2_S4_0_7_arc[-1,3]
 FX BND1      e2_S4_0_7_arc[-1,4]  0
 BV BND1      e2_S4_0_7_arc[-1,4]
 FX BND1      e2_S4_0_7_arc[-1,5]  0
 BV BND1      e2_S4_0_7_arc[-1,5]
 FX BND1      e2_S4_0_7_arc[-1,6]  0
 BV BND1      e2_S4_0_7_arc[-1,6]
 FX BND1      e2_S4_0_7_arc[-1,7]  0
 BV BND1      e2_S4_0_7_arc[-1,7]
 FX BND1      e2_S4_0_7_arc[-1,8]  0
 BV BND1      e2_S4_0_7_arc[-1,8]
 FX BND1      e2_S4_0_7_arc[-1,9]  0
 BV BND1      e2_S4_0_7_arc[-1,9]
 FX BND1      e2_S4_0_7_arc[0,-2]  0
 BV BND1      e2_S4_0_7_arc[0,-2]
 FX BND1      e2_S4_0_7_arc[1,-2]  0
 BV BND1      e2_S4_0_7_arc[1,-2]
 FX BND1      e2_S4_0_7_arc[2,-2]  0
 BV BND1      e2_S4_0_7_arc[2,-2]
 FX BND1      e2_S4_0_7_arc[3,-2]  0
 BV BND1      e2_S4_0_7_arc[3,-2]
 FX BND1      e2_S4_0_7_arc[4,-2]  0
 BV BND1      e2_S4_0_7_arc[4,-2]
 FX BND1      e2_S4_0_7_arc[5,-2]  0
 BV BND1      e2_S4_0_7_arc[5,-2]
 FX BND1      e2_S4_0_7_arc[6,-2]  0
 BV BND1      e2_S4_0_7_arc[6,-2]
 FX BND1      e2_S4_0_7_arc[7,-2]  0
 BV BND1      e2_S4_0_7_arc[7,-2]
 FX BND1      e2_S4_0_7_arc[8,-2]  0
 BV BND1      e2_S4_0_7_arc[8,-2]
 FX BND1      e2_S4_0_7_arc[9,-2]  0
 BV BND1      e2_S4_0_7_arc[9,-2]
 UP BND1      C807      29
 UP BND1      C808      29
 BV BND1      C809    
 BV BND1      C810    
 BV BND1      C811    
 FX BND1      e2_S4_0_8_used  0
 BV BND1      e2_S4_0_8_used
 FX BND1      e2_S4_0_8_start  0
 FX BND1      e2_S4_0_8_end  0
 FX BND1      e2_S4_0_8_visit[0]  0
 BV BND1      e2_S4_0_8_visit[0]
 FX BND1      e2_S4_0_8_visit[1]  0
 BV BND1      e2_S4_0_8_visit[1]
 FX BND1      e2_S4_0_8_visit[2]  0
 BV BND1      e2_S4_0_8_visit[2]
 FX BND1      e2_S4_0_8_visit[3]  0
 BV BND1      e2_S4_0_8_visit[3]
 FX BND1      e2_S4_0_8_visit[4]  0
 BV BND1      e2_S4_0_8_visit[4]
 FX BND1      e2_S4_0_8_visit[5]  0
 BV BND1      e2_S4_0_8_visit[5]
 FX BND1      e2_S4_0_8_visit[6]  0
 BV BND1      e2_S4_0_8_visit[6]
 FX BND1      e2_S4_0_8_visit[7]  0
 BV BND1      e2_S4_0_8_visit[7]
 FX BND1      e2_S4_0_8_visit[8]  0
 BV BND1      e2_S4_0_8_visit[8]
 FX BND1      e2_S4_0_8_visit[9]  0
 BV BND1      e2_S4_0_8_visit[9]
 FX BND1      e2_S4_0_8_arc[-1,0]  0
 BV BND1      e2_S4_0_8_arc[-1,0]
 FX BND1      e2_S4_0_8_arc[-1,1]  0
 BV BND1      e2_S4_0_8_arc[-1,1]
 FX BND1      e2_S4_0_8_arc[-1,2]  0
 BV BND1      e2_S4_0_8_arc[-1,2]
 FX BND1      e2_S4_0_8_arc[-1,3]  0
 BV BND1      e2_S4_0_8_arc[-1,3]
 FX BND1      e2_S4_0_8_arc[-1,4]  0
 BV BND1      e2_S4_0_8_arc[-1,4]
 FX BND1      e2_S4_0_8_arc[-1,5]  0
 BV BND1      e2_S4_0_8_arc[-1,5]
 FX BND1      e2_S4_0_8_arc[-1,6]  0
 BV BND1      e2_S4_0_8_arc[-1,6]
 FX BND1      e2_S4_0_8_arc[-1,7]  0
 BV BND1      e2_S4_0_8_arc[-1,7]
 FX BND1      e2_S4_0_8_arc[-1,8]  0
 BV BND1      e2_S4_0_8_arc[-1,8]
 FX BND1      e2_S4_0_8_arc[-1,9]  0
 BV BND1      e2_S4_0_8_arc[-1,9]
 FX BND1      e2_S4_0_8_arc[0,-2]  0
 BV BND1      e2_S4_0_8_arc[0,-2]
 FX BND1      e2_S4_0_8_arc[1,-2]  0
 BV BND1      e2_S4_0_8_arc[1,-2]
 FX BND1      e2_S4_0_8_arc[2,-2]  0
 BV BND1      e2_S4_0_8_arc[2,-2]
 FX BND1      e2_S4_0_8_arc[3,-2]  0
 BV BND1      e2_S4_0_8_arc[3,-2]
 FX BND1      e2_S4_0_8_arc[4,-2]  0
 BV BND1      e2_S4_0_8_arc[4,-2]
 FX BND1      e2_S4_0_8_arc[5,-2]  0
 BV BND1      e2_S4_0_8_arc[5,-2]
 FX BND1      e2_S4_0_8_arc[6,-2]  0
 BV BND1      e2_S4_0_8_arc[6,-2]
 FX BND1      e2_S4_0_8_arc[7,-2]  0
 BV BND1      e2_S4_0_8_arc[7,-2]
 FX BND1      e2_S4_0_8_arc[8,-2]  0
 BV BND1      e2_S4_0_8_arc[8,-2]
 FX BND1      e2_S4_0_8_arc[9,-2]  0
 BV BND1      e2_S4_0_8_arc[9,-2]
 UP BND1      C845      29
 UP BND1      C846      29
 BV BND1      C847    
 BV BND1      C848    
 BV BND1      C849    
 FX BND1      e2_S4_0_9_used  0
 BV BND1      e2_S4_0_9_used
 FX BND1      e2_S4_0_9_start  0
 FX BND1      e2_S4_0_9_end  0
 FX BND1      e2_S4_0_9_visit[0]  0
 BV BND1      e2_S4_0_9_visit[0]
 FX BND1      e2_S4_0_9_visit[1]  0
 BV BND1      e2_S4_0_9_visit[1]
 FX BND1      e2_S4_0_9_visit[2]  0
 BV BND1      e2_S4_0_9_visit[2]
 FX BND1      e2_S4_0_9_visit[3]  0
 BV BND1      e2_S4_0_9_visit[3]
 FX BND1      e2_S4_0_9_visit[4]  0
 BV BND1      e2_S4_0_9_visit[4]
 FX BND1      e2_S4_0_9_visit[5]  0
 BV BND1      e2_S4_0_9_visit[5]
 FX BND1      e2_S4_0_9_visit[6]  0
 BV BND1      e2_S4_0_9_visit[6]
 FX BND1      e2_S4_0_9_visit[7]  0
 BV BND1      e2_S4_0_9_visit[7]
 FX BND1      e2_S4_0_9_visit[8]  0
 BV BND1      e2_S4_0_9_visit[8]
 FX BND1      e2_S4_0_9_visit[9]  0
 BV BND1      e2_S4_0_9_visit[9]
 FX BND1      e2_S4_0_9_arc[-1,0]  0
 BV BND1      e2_S4_0_9_arc[-1,0]
 FX BND1      e2_S4_0_9_arc[-1,1]  0
 BV BND1      e2_S4_0_9_arc[-1,1]
 FX BND1      e2_S4_0_9_arc[-1,2]  0
 BV BND1      e2_S4_0_9_arc[-1,2]
 FX BND1      e2_S4_0_9_arc[-1,3]  0
 BV BND1      e2_S4_0_9_arc[-1,3]
 FX BND1      e2_S4_0_9_arc[-1,4]  0
 BV BND1      e2_S4_0_9_arc[-1,4]
 FX BND1      e2_S4_0_9_arc[-1,5]  0
 BV BND1      e2_S4_0_9_arc[-1,5]
 FX BND1      e2_S4_0_9_arc[-1,6]  0
 BV BND1      e2_S4_0_9_arc[-1,6]
 FX BND1      e2_S4_0_9_arc[-1,7]  0
 BV BND1      e2_S4_0_9_arc[-1,7]
 FX BND1      e2_S4_0_9_arc[-1,8]  0
 BV BND1      e2_S4_0_9_arc[-1,8]
 FX BND1      e2_S4_0_9_arc[-1,9]  0
 BV BND1      e2_S4_0_9_arc[-1,9]
 FX BND1      e2_S4_0_9_arc[0,-2]  0
 BV BND1      e2_S4_0_9_arc[0,-2]
 FX BND1      e2_S4_0_9_arc[1,-2]  0
 BV BND1      e2_S4_0_9_arc[1,-2]
 FX BND1      e2_S4_0_9_arc[2,-2]  0
 BV BND1      e2_S4_0_9_arc[2,-2]
 FX BND1      e2_S4_0_9_arc[3,-2]  0
 BV BND1      e2_S4_0_9_arc[3,-2]
 FX BND1      e2_S4_0_9_arc[4,-2]  0
 BV BND1      e2_S4_0_9_arc[4,-2]
 FX BND1      e2_S4_0_9_arc[5,-2]  0
 BV BND1      e2_S4_0_9_arc[5,-2]
 FX BND1      e2_S4_0_9_arc[6,-2]  0
 BV BND1      e2_S4_0_9_arc[6,-2]
 FX BND1      e2_S4_0_9_arc[7,-2]  0
 BV BND1      e2_S4_0_9_arc[7,-2]
 FX BND1      e2_S4_0_9_arc[8,-2]  0
 BV BND1      e2_S4_0_9_arc[8,-2]
 FX BND1      e2_S4_0_9_arc[9,-2]  0
 BV BND1      e2_S4_0_9_arc[9,-2]
 UP BND1      C883      29
 UP BND1      C884      29
 BV BND1      C885    
 BV BND1      C886    
 BV BND1      C887    
 FX BND1      e2_S4_1_0_used  1
 BV BND1      e2_S4_1_0_used
 FX BND1      e2_S4_1_0_start  46526
 FX BND1      e2_S4_1_0_end  64175
 FX BND1      e2_S4_1_0_visit[0]  0
 BV BND1      e2_S4_1_0_visit[0]
 FX BND1      e2_S4_1_0_visit[1]  0
 BV BND1      e2_S4_1_0_visit[1]
 FX BND1      e2_S4_1_0_visit[2]  0
 BV BND1      e2_S4_1_0_visit[2]
 FX BND1      e2_S4_1_0_visit[3]  0
 BV BND1      e2_S4_1_0_visit[3]
 FX BND1      e2_S4_1_0_visit[4]  1
 BV BND1      e2_S4_1_0_visit[4]
 FX BND1      e2_S4_1_0_visit[5]  0
 BV BND1      e2_S4_1_0_visit[5]
 FX BND1      e2_S4_1_0_visit[6]  1
 BV BND1      e2_S4_1_0_visit[6]
 FX BND1      e2_S4_1_0_visit[7]  1
 BV BND1      e2_S4_1_0_visit[7]
 FX BND1      e2_S4_1_0_visit[8]  0
 BV BND1      e2_S4_1_0_visit[8]
 FX BND1      e2_S4_1_0_visit[9]  0
 BV BND1      e2_S4_1_0_visit[9]
 FX BND1      e2_S4_1_0_arc[-1,0]  0
 BV BND1      e2_S4_1_0_arc[-1,0]
 FX BND1      e2_S4_1_0_arc[-1,1]  0
 BV BND1      e2_S4_1_0_arc[-1,1]
 FX BND1      e2_S4_1_0_arc[-1,2]  0
 BV BND1      e2_S4_1_0_arc[-1,2]
 FX BND1      e2_S4_1_0_arc[-1,3]  0
 BV BND1      e2_S4_1_0_arc[-1,3]
 FX BND1      e2_S4_1_0_arc[-1,4]  1
 BV BND1      e2_S4_1_0_arc[-1,4]
 FX BND1      e2_S4_1_0_arc[-1,5]  0
 BV BND1      e2_S4_1_0_arc[-1,5]
 FX BND1      e2_S4_1_0_arc[-1,6]  0
 BV BND1      e2_S4_1_0_arc[-1,6]
 FX BND1      e2_S4_1_0_arc[-1,7]  0
 BV BND1      e2_S4_1_0_arc[-1,7]
 FX BND1      e2_S4_1_0_arc[-1,8]  0
 BV BND1      e2_S4_1_0_arc[-1,8]
 FX BND1      e2_S4_1_0_arc[-1,9]  0
 BV BND1      e2_S4_1_0_arc[-1,9]
 FX BND1      e2_S4_1_0_arc[0,-2]  0
 BV BND1      e2_S4_1_0_arc[0,-2]
 FX BND1      e2_S4_1_0_arc[1,-2]  0
 BV BND1      e2_S4_1_0_arc[1,-2]
 FX BND1      e2_S4_1_0_arc[2,-2]  0
 BV BND1      e2_S4_1_0_arc[2,-2]
 FX BND1      e2_S4_1_0_arc[3,-2]  0
 BV BND1      e2_S4_1_0_arc[3,-2]
 FX BND1      e2_S4_1_0_arc[4,-2]  0
 BV BND1      e2_S4_1_0_arc[4,-2]
 FX BND1      e2_S4_1_0_arc[5,-2]  0
 BV BND1      e2_S4_1_0_arc[5,-2]
 FX BND1      e2_S4_1_0_arc[6,-2]  0
 BV BND1      e2_S4_1_0_arc[6,-2]
 FX BND1      e2_S4_1_0_arc[7,-2]  1
 BV BND1      e2_S4_1_0_arc[7,-2]
 FX BND1      e2_S4_1_0_arc[8,-2]  0
 BV BND1      e2_S4_1_0_arc[8,-2]
 FX BND1      e2_S4_1_0_arc[9,-2]  0
 BV BND1      e2_S4_1_0_arc[9,-2]
 UP BND1      C921      29
 UP BND1      C922      29
 BV BND1      C923    
 BV BND1      C924    
 BV BND1      C925    
 FX BND1      e2_S4_1_1_used  0
 BV BND1      e2_S4_1_1_used
 FX BND1      e2_S4_1_1_start  0
 FX BND1      e2_S4_1_1_end  0
 FX BND1      e2_S4_1_1_visit[0]  0
 BV BND1      e2_S4_1_1_visit[0]
 FX BND1      e2_S4_1_1_visit[1]  0
 BV BND1      e2_S4_1_1_visit[1]
 FX BND1      e2_S4_1_1_visit[2]  0
 BV BND1      e2_S4_1_1_visit[2]
 FX BND1      e2_S4_1_1_visit[3]  0
 BV BND1      e2_S4_1_1_visit[3]
 FX BND1      e2_S4_1_1_visit[4]  0
 BV BND1      e2_S4_1_1_visit[4]
 FX BND1      e2_S4_1_1_visit[5]  0
 BV BND1      e2_S4_1_1_visit[5]
 FX BND1      e2_S4_1_1_visit[6]  0
 BV BND1      e2_S4_1_1_visit[6]
 FX BND1      e2_S4_1_1_visit[7]  0
 BV BND1      e2_S4_1_1_visit[7]
 FX BND1      e2_S4_1_1_visit[8]  0
 BV BND1      e2_S4_1_1_visit[8]
 FX BND1      e2_S4_1_1_visit[9]  0
 BV BND1      e2_S4_1_1_visit[9]
 FX BND1      e2_S4_1_1_arc[-1,0]  0
 BV BND1      e2_S4_1_1_arc[-1,0]
 FX BND1      e2_S4_1_1_arc[-1,1]  0
 BV BND1      e2_S4_1_1_arc[-1,1]
 FX BND1      e2_S4_1_1_arc[-1,2]  0
 BV BND1      e2_S4_1_1_arc[-1,2]
 FX BND1      e2_S4_1_1_arc[-1,3]  0
 BV BND1      e2_S4_1_1_arc[-1,3]
 FX BND1      e2_S4_1_1_arc[-1,4]  0
 BV BND1      e2_S4_1_1_arc[-1,4]
 FX BND1      e2_S4_1_1_arc[-1,5]  0
 BV BND1      e2_S4_1_1_arc[-1,5]
 FX BND1      e2_S4_1_1_arc[-1,6]  0
 BV BND1      e2_S4_1_1_arc[-1,6]
 FX BND1      e2_S4_1_1_arc[-1,7]  0
 BV BND1      e2_S4_1_1_arc[-1,7]
 FX BND1      e2_S4_1_1_arc[-1,8]  0
 BV BND1      e2_S4_1_1_arc[-1,8]
 FX BND1      e2_S4_1_1_arc[-1,9]  0
 BV BND1      e2_S4_1_1_arc[-1,9]
 FX BND1      e2_S4_1_1_arc[0,-2]  0
 BV BND1      e2_S4_1_1_arc[0,-2]
 FX BND1      e2_S4_1_1_arc[1,-2]  0
 BV BND1      e2_S4_1_1_arc[1,-2]
 FX BND1      e2_S4_1_1_arc[2,-2]  0
 BV BND1      e2_S4_1_1_arc[2,-2]
 FX BND1      e2_S4_1_1_arc[3,-2]  0
 BV BND1      e2_S4_1_1_arc[3,-2]
 FX BND1      e2_S4_1_1_arc[4,-2]  0
 BV BND1      e2_S4_1_1_arc[4,-2]
 FX BND1      e2_S4_1_1_arc[5,-2]  0
 BV BND1      e2_S4_1_1_arc[5,-2]
 FX BND1      e2_S4_1_1_arc[6,-2]  0
 BV BND1      e2_S4_1_1_arc[6,-2]
 FX BND1      e2_S4_1_1_arc[7,-2]  0
 BV BND1      e2_S4_1_1_arc[7,-2]
 FX BND1      e2_S4_1_1_arc[8,-2]  0
 BV BND1      e2_S4_1_1_arc[8,-2]
 FX BND1      e2_S4_1_1_arc[9,-2]  0
 BV BND1      e2_S4_1_1_arc[9,-2]
 UP BND1      C959      29
 UP BND1      C960      29
 BV BND1      C961    
 BV BND1      C962    
 BV BND1      C963    
 FX BND1      e2_S4_1_2_used  0
 BV BND1      e2_S4_1_2_used
 FX BND1      e2_S4_1_2_start  0
 FX BND1      e2_S4_1_2_end  0
 FX BND1      e2_S4_1_2_visit[0]  0
 BV BND1      e2_S4_1_2_visit[0]
 FX BND1      e2_S4_1_2_visit[1]  0
 BV BND1      e2_S4_1_2_visit[1]
 FX BND1      e2_S4_1_2_visit[2]  0
 BV BND1      e2_S4_1_2_visit[2]
 FX BND1      e2_S4_1_2_visit[3]  0
 BV BND1      e2_S4_1_2_visit[3]
 FX BND1      e2_S4_1_2_visit[4]  0
 BV BND1      e2_S4_1_2_visit[4]
 FX BND1      e2_S4_1_2_visit[5]  0
 BV BND1      e2_S4_1_2_visit[5]
 FX BND1      e2_S4_1_2_visit[6]  0
 BV BND1      e2_S4_1_2_visit[6]
 FX BND1      e2_S4_1_2_visit[7]  0
 BV BND1      e2_S4_1_2_visit[7]
 FX BND1      e2_S4_1_2_visit[8]  0
 BV BND1      e2_S4_1_2_visit[8]
 FX BND1      e2_S4_1_2_visit[9]  0
 BV BND1      e2_S4_1_2_visit[9]
 FX BND1      e2_S4_1_2_arc[-1,0]  0
 BV BND1      e2_S4_1_2_arc[-1,0]
 FX BND1      e2_S4_1_2_arc[-1,1]  0
 BV BND1      e2_S4_1_2_arc[-1,1]
 FX BND1      e2_S4_1_2_arc[-1,2]  0
 BV BND1      e2_S4_1_2_arc[-1,2]
 FX BND1      e2_S4_1_2_arc[-1,3]  0
 BV BND1      e2_S4_1_2_arc[-1,3]
 FX BND1      e2_S4_1_2_arc[-1,4]  0
 BV BND1      e2_S4_1_2_arc[-1,4]
 FX BND1      e2_S4_1_2_arc[-1,5]  0
 BV BND1      e2_S4_1_2_arc[-1,5]
 FX BND1      e2_S4_1_2_arc[-1,6]  0
 BV BND1      e2_S4_1_2_arc[-1,6]
 FX BND1      e2_S4_1_2_arc[-1,7]  0
 BV BND1      e2_S4_1_2_arc[-1,7]
 FX BND1      e2_S4_1_2_arc[-1,8]  0
 BV BND1      e2_S4_1_2_arc[-1,8]
 FX BND1      e2_S4_1_2_arc[-1,9]  0
 BV BND1      e2_S4_1_2_arc[-1,9]
 FX BND1      e2_S4_1_2_arc[0,-2]  0
 BV BND1      e2_S4_1_2_arc[0,-2]
 FX BND1      e2_S4_1_2_arc[1,-2]  0
 BV BND1      e2_S4_1_2_arc[1,-2]
 FX BND1      e2_S4_1_2_arc[2,-2]  0
 BV BND1      e2_S4_1_2_arc[2,-2]
 FX BND1      e2_S4_1_2_arc[3,-2]  0
 BV BND1      e2_S4_1_2_arc[3,-2]
 FX BND1      e2_S4_1_2_arc[4,-2]  0
 BV BND1      e2_S4_1_2_arc[4,-2]
 FX BND1      e2_S4_1_2_arc[5,-2]  0
 BV BND1      e2_S4_1_2_arc[5,-2]
 FX BND1      e2_S4_1_2_arc[6,-2]  0
 BV BND1      e2_S4_1_2_arc[6,-2]
 FX BND1      e2_S4_1_2_arc[7,-2]  0
 BV BND1      e2_S4_1_2_arc[7,-2]
 FX BND1      e2_S4_1_2_arc[8,-2]  0
 BV BND1      e2_S4_1_2_arc[8,-2]
 FX BND1      e2_S4_1_2_arc[9,-2]  0
 BV BND1      e2_S4_1_2_arc[9,-2]
 UP BND1      C997      29
 UP BND1      C998      29
 BV BND1      C999    
 BV BND1      C1000   
 BV BND1      C1001   
 FX BND1      e2_S4_1_3_used  0
 BV BND1      e2_S4_1_3_used
 FX BND1      e2_S4_1_3_start  0
 FX BND1      e2_S4_1_3_end  0
 FX BND1      e2_S4_1_3_visit[0]  0
 BV BND1      e2_S4_1_3_visit[0]
 FX BND1      e2_S4_1_3_visit[1]  0
 BV BND1      e2_S4_1_3_visit[1]
 FX BND1      e2_S4_1_3_visit[2]  0
 BV BND1      e2_S4_1_3_visit[2]
 FX BND1      e2_S4_1_3_visit[3]  0
 BV BND1      e2_S4_1_3_visit[3]
 FX BND1      e2_S4_1_3_visit[4]  0
 BV BND1      e2_S4_1_3_visit[4]
 FX BND1      e2_S4_1_3_visit[5]  0
 BV BND1      e2_S4_1_3_visit[5]
 FX BND1      e2_S4_1_3_visit[6]  0
 BV BND1      e2_S4_1_3_visit[6]
 FX BND1      e2_S4_1_3_visit[7]  0
 BV BND1      e2_S4_1_3_visit[7]
 FX BND1      e2_S4_1_3_visit[8]  0
 BV BND1      e2_S4_1_3_visit[8]
 FX BND1      e2_S4_1_3_visit[9]  0
 BV BND1      e2_S4_1_3_visit[9]
 FX BND1      e2_S4_1_3_arc[-1,0]  0
 BV BND1      e2_S4_1_3_arc[-1,0]
 FX BND1      e2_S4_1_3_arc[-1,1]  0
 BV BND1      e2_S4_1_3_arc[-1,1]
 FX BND1      e2_S4_1_3_arc[-1,2]  0
 BV BND1      e2_S4_1_3_arc[-1,2]
 FX BND1      e2_S4_1_3_arc[-1,3]  0
 BV BND1      e2_S4_1_3_arc[-1,3]
 FX BND1      e2_S4_1_3_arc[-1,4]  0
 BV BND1      e2_S4_1_3_arc[-1,4]
 FX BND1      e2_S4_1_3_arc[-1,5]  0
 BV BND1      e2_S4_1_3_arc[-1,5]
 FX BND1      e2_S4_1_3_arc[-1,6]  0
 BV BND1      e2_S4_1_3_arc[-1,6]
 FX BND1      e2_S4_1_3_arc[-1,7]  0
 BV BND1      e2_S4_1_3_arc[-1,7]
 FX BND1      e2_S4_1_3_arc[-1,8]  0
 BV BND1      e2_S4_1_3_arc[-1,8]
 FX BND1      e2_S4_1_3_arc[-1,9]  0
 BV BND1      e2_S4_1_3_arc[-1,9]
 FX BND1      e2_S4_1_3_arc[0,-2]  0
 BV BND1      e2_S4_1_3_arc[0,-2]
 FX BND1      e2_S4_1_3_arc[1,-2]  0
 BV BND1      e2_S4_1_3_arc[1,-2]
 FX BND1      e2_S4_1_3_arc[2,-2]  0
 BV BND1      e2_S4_1_3_arc[2,-2]
 FX BND1      e2_S4_1_3_arc[3,-2]  0
 BV BND1      e2_S4_1_3_arc[3,-2]
 FX BND1      e2_S4_1_3_arc[4,-2]  0
 BV BND1      e2_S4_1_3_arc[4,-2]
 FX BND1      e2_S4_1_3_arc[5,-2]  0
 BV BND1      e2_S4_1_3_arc[5,-2]
 FX BND1      e2_S4_1_3_arc[6,-2]  0
 BV BND1      e2_S4_1_3_arc[6,-2]
 FX BND1      e2_S4_1_3_arc[7,-2]  0
 BV BND1      e2_S4_1_3_arc[7,-2]
 FX BND1      e2_S4_1_3_arc[8,-2]  0
 BV BND1      e2_S4_1_3_arc[8,-2]
 FX BND1      e2_S4_1_3_arc[9,-2]  0
 BV BND1      e2_S4_1_3_arc[9,-2]
 UP BND1      C1035     29
 UP BND1      C1036     29
 BV BND1      C1037   
 BV BND1      C1038   
 BV BND1      C1039   
 FX BND1      e2_S4_1_4_used  0
 BV BND1      e2_S4_1_4_used
 FX BND1      e2_S4_1_4_start  0
 FX BND1      e2_S4_1_4_end  0
 FX BND1      e2_S4_1_4_visit[0]  0
 BV BND1      e2_S4_1_4_visit[0]
 FX BND1      e2_S4_1_4_visit[1]  0
 BV BND1      e2_S4_1_4_visit[1]
 FX BND1      e2_S4_1_4_visit[2]  0
 BV BND1      e2_S4_1_4_visit[2]
 FX BND1      e2_S4_1_4_visit[3]  0
 BV BND1      e2_S4_1_4_visit[3]
 FX BND1      e2_S4_1_4_visit[4]  0
 BV BND1      e2_S4_1_4_visit[4]
 FX BND1      e2_S4_1_4_visit[5]  0
 BV BND1      e2_S4_1_4_visit[5]
 FX BND1      e2_S4_1_4_visit[6]  0
 BV BND1      e2_S4_1_4_visit[6]
 FX BND1      e2_S4_1_4_visit[7]  0
 BV BND1      e2_S4_1_4_visit[7]
 FX BND1      e2_S4_1_4_visit[8]  0
 BV BND1      e2_S4_1_4_visit[8]
 FX BND1      e2_S4_1_4_visit[9]  0
 BV BND1      e2_S4_1_4_visit[9]
 FX BND1      e2_S4_1_4_arc[-1,0]  0
 BV BND1      e2_S4_1_4_arc[-1,0]
 FX BND1      e2_S4_1_4_arc[-1,1]  0
 BV BND1      e2_S4_1_4_arc[-1,1]
 FX BND1      e2_S4_1_4_arc[-1,2]  0
 BV BND1      e2_S4_1_4_arc[-1,2]
 FX BND1      e2_S4_1_4_arc[-1,3]  0
 BV BND1      e2_S4_1_4_arc[-1,3]
 FX BND1      e2_S4_1_4_arc[-1,4]  0
 BV BND1      e2_S4_1_4_arc[-1,4]
 FX BND1      e2_S4_1_4_arc[-1,5]  0
 BV BND1      e2_S4_1_4_arc[-1,5]
 FX BND1      e2_S4_1_4_arc[-1,6]  0
 BV BND1      e2_S4_1_4_arc[-1,6]
 FX BND1      e2_S4_1_4_arc[-1,7]  0
 BV BND1      e2_S4_1_4_arc[-1,7]
 FX BND1      e2_S4_1_4_arc[-1,8]  0
 BV BND1      e2_S4_1_4_arc[-1,8]
 FX BND1      e2_S4_1_4_arc[-1,9]  0
 BV BND1      e2_S4_1_4_arc[-1,9]
 FX BND1      e2_S4_1_4_arc[0,-2]  0
 BV BND1      e2_S4_1_4_arc[0,-2]
 FX BND1      e2_S4_1_4_arc[1,-2]  0
 BV BND1      e2_S4_1_4_arc[1,-2]
 FX BND1      e2_S4_1_4_arc[2,-2]  0
 BV BND1      e2_S4_1_4_arc[2,-2]
 FX BND1      e2_S4_1_4_arc[3,-2]  0
 BV BND1      e2_S4_1_4_arc[3,-2]
 FX BND1      e2_S4_1_4_arc[4,-2]  0
 BV BND1      e2_S4_1_4_arc[4,-2]
 FX BND1      e2_S4_1_4_arc[5,-2]  0
 BV BND1      e2_S4_1_4_arc[5,-2]
 FX BND1      e2_S4_1_4_arc[6,-2]  0
 BV BND1      e2_S4_1_4_arc[6,-2]
 FX BND1      e2_S4_1_4_arc[7,-2]  0
 BV BND1      e2_S4_1_4_arc[7,-2]
 FX BND1      e2_S4_1_4_arc[8,-2]  0
 BV BND1      e2_S4_1_4_arc[8,-2]
 FX BND1      e2_S4_1_4_arc[9,-2]  0
 BV BND1      e2_S4_1_4_arc[9,-2]
 UP BND1      C1073     29
 UP BND1      C1074     29
 BV BND1      C1075   
 BV BND1      C1076   
 BV BND1      C1077   
 FX BND1      e2_S4_2_0_used  1
 BV BND1      e2_S4_2_0_used
 FX BND1      e2_S4_2_0_start  32211
 FX BND1      e2_S4_2_0_end  54000
 FX BND1      e2_S4_2_0_visit[0]  0
 BV BND1      e2_S4_2_0_visit[0]
 FX BND1      e2_S4_2_0_visit[1]  0
 BV BND1      e2_S4_2_0_visit[1]
 FX BND1      e2_S4_2_0_visit[2]  1
 BV BND1      e2_S4_2_0_visit[2]
 FX BND1      e2_S4_2_0_visit[3]  1
 BV BND1      e2_S4_2_0_visit[3]
 FX BND1      e2_S4_2_0_visit[4]  0
 BV BND1      e2_S4_2_0_visit[4]
 FX BND1      e2_S4_2_0_visit[5]  1
 BV BND1      e2_S4_2_0_visit[5]
 FX BND1      e2_S4_2_0_visit[6]  0
 BV BND1      e2_S4_2_0_visit[6]
 FX BND1      e2_S4_2_0_visit[7]  0
 BV BND1      e2_S4_2_0_visit[7]
 FX BND1      e2_S4_2_0_visit[8]  0
 BV BND1      e2_S4_2_0_visit[8]
 FX BND1      e2_S4_2_0_visit[9]  0
 BV BND1      e2_S4_2_0_visit[9]
 FX BND1      e2_S4_2_0_arc[-1,0]  0
 BV BND1      e2_S4_2_0_arc[-1,0]
 FX BND1      e2_S4_2_0_arc[-1,1]  0
 BV BND1      e2_S4_2_0_arc[-1,1]
 FX BND1      e2_S4_2_0_arc[-1,2]  1
 BV BND1      e2_S4_2_0_arc[-1,2]
 FX BND1      e2_S4_2_0_arc[-1,3]  0
 BV BND1      e2_S4_2_0_arc[-1,3]
 FX BND1      e2_S4_2_0_arc[-1,4]  0
 BV BND1      e2_S4_2_0_arc[-1,4]
 FX BND1      e2_S4_2_0_arc[-1,5]  0
 BV BND1      e2_S4_2_0_arc[-1,5]
 FX BND1      e2_S4_2_0_arc[-1,6]  0
 BV BND1      e2_S4_2_0_arc[-1,6]
 FX BND1      e2_S4_2_0_arc[-1,7]  0
 BV BND1      e2_S4_2_0_arc[-1,7]
 FX BND1      e2_S4_2_0_arc[-1,8]  0
 BV BND1      e2_S4_2_0_arc[-1,8]
 FX BND1      e2_S4_2_0_arc[-1,9]  0
 BV BND1      e2_S4_2_0_arc[-1,9]
 FX BND1      e2_S4_2_0_arc[0,-2]  0
 BV BND1      e2_S4_2_0_arc[0,-2]
 FX BND1      e2_S4_2_0_arc[1,-2]  0
 BV BND1      e2_S4_2_0_arc[1,-2]
 FX BND1      e2_S4_2_0_arc[2,-2]  0
 BV BND1      e2_S4_2_0_arc[2,-2]
 FX BND1      e2_S4_2_0_arc[3,-2]  0
 BV BND1      e2_S4_2_0_arc[3,-2]
 FX BND1      e2_S4_2_0_arc[4,-2]  0
 BV BND1      e2_S4_2_0_arc[4,-2]
 FX BND1      e2_S4_2_0_arc[5,-2]  1
 BV BND1      e2_S4_2_0_arc[5,-2]
 FX BND1      e2_S4_2_0_arc[6,-2]  0
 BV BND1      e2_S4_2_0_arc[6,-2]
 FX BND1      e2_S4_2_0_arc[7,-2]  0
 BV BND1      e2_S4_2_0_arc[7,-2]
 FX BND1      e2_S4_2_0_arc[8,-2]  0
 BV BND1      e2_S4_2_0_arc[8,-2]
 FX BND1      e2_S4_2_0_arc[9,-2]  0
 BV BND1      e2_S4_2_0_arc[9,-2]
 UP BND1      C1111     29
 UP BND1      C1112     29
 BV BND1      C1113   
 BV BND1      C1114   
 BV BND1      C1115   
 FX BND1      e2_S4_2_1_used  0
 BV BND1      e2_S4_2_1_used
 FX BND1      e2_S4_2_1_start  0
 FX BND1      e2_S4_2_1_end  0
 FX BND1      e2_S4_2_1_visit[0]  0
 BV BND1      e2_S4_2_1_visit[0]
 FX BND1      e2_S4_2_1_visit[1]  0
 BV BND1      e2_S4_2_1_visit[1]
 FX BND1      e2_S4_2_1_visit[2]  0
 BV BND1      e2_S4_2_1_visit[2]
 FX BND1      e2_S4_2_1_visit[3]  0
 BV BND1      e2_S4_2_1_visit[3]
 FX BND1      e2_S4_2_1_visit[4]  0
 BV BND1      e2_S4_2_1_visit[4]
 FX BND1      e2_S4_2_1_visit[5]  0
 BV BND1      e2_S4_2_1_visit[5]
 FX BND1      e2_S4_2_1_visit[6]  0
 BV BND1      e2_S4_2_1_visit[6]
 FX BND1      e2_S4_2_1_visit[7]  0
 BV BND1      e2_S4_2_1_visit[7]
 FX BND1      e2_S4_2_1_visit[8]  0
 BV BND1      e2_S4_2_1_visit[8]
 FX BND1      e2_S4_2_1_visit[9]  0
 BV BND1      e2_S4_2_1_visit[9]
 FX BND1      e2_S4_2_1_arc[-1,0]  0
 BV BND1      e2_S4_2_1_arc[-1,0]
 FX BND1      e2_S4_2_1_arc[-1,1]  0
 BV BND1      e2_S4_2_1_arc[-1,1]
 FX BND1      e2_S4_2_1_arc[-1,2]  0
 BV BND1      e2_S4_2_1_arc[-1,2]
 FX BND1      e2_S4_2_1_arc[-1,3]  0
 BV BND1      e2_S4_2_1_arc[-1,3]
 FX BND1      e2_S4_2_1_arc[-1,4]  0
 BV BND1      e2_S4_2_1_arc[-1,4]
 FX BND1      e2_S4_2_1_arc[-1,5]  0
 BV BND1      e2_S4_2_1_arc[-1,5]
 FX BND1      e2_S4_2_1_arc[-1,6]  0
 BV BND1      e2_S4_2_1_arc[-1,6]
 FX BND1      e2_S4_2_1_arc[-1,7]  0
 BV BND1      e2_S4_2_1_arc[-1,7]
 FX BND1      e2_S4_2_1_arc[-1,8]  0
 BV BND1      e2_S4_2_1_arc[-1,8]
 FX BND1      e2_S4_2_1_arc[-1,9]  0
 BV BND1      e2_S4_2_1_arc[-1,9]
 FX BND1      e2_S4_2_1_arc[0,-2]  0
 BV BND1      e2_S4_2_1_arc[0,-2]
 FX BND1      e2_S4_2_1_arc[1,-2]  0
 BV BND1      e2_S4_2_1_arc[1,-2]
 FX BND1      e2_S4_2_1_arc[2,-2]  0
 BV BND1      e2_S4_2_1_arc[2,-2]
 FX BND1      e2_S4_2_1_arc[3,-2]  0
 BV BND1      e2_S4_2_1_arc[3,-2]
 FX BND1      e2_S4_2_1_arc[4,-2]  0
 BV BND1      e2_S4_2_1_arc[4,-2]
 FX BND1      e2_S4_2_1_arc[5,-2]  0
 BV BND1      e2_S4_2_1_arc[5,-2]
 FX BND1      e2_S4_2_1_arc[6,-2]  0
 BV BND1      e2_S4_2_1_arc[6,-2]
 FX BND1      e2_S4_2_1_arc[7,-2]  0
 BV BND1      e2_S4_2_1_arc[7,-2]
 FX BND1      e2_S4_2_1_arc[8,-2]  0
 BV BND1      e2_S4_2_1_arc[8,-2]
 FX BND1      e2_S4_2_1_arc[9,-2]  0
 BV BND1      e2_S4_2_1_arc[9,-2]
 UP BND1      C1149     29
 UP BND1      C1150     29
 BV BND1      C1151   
 BV BND1      C1152   
 BV BND1      C1153   
 FX BND1      e2_S4_2_2_used  0
 BV BND1      e2_S4_2_2_used
 FX BND1      e2_S4_2_2_start  0
 FX BND1      e2_S4_2_2_end  0
 FX BND1      e2_S4_2_2_visit[0]  0
 BV BND1      e2_S4_2_2_visit[0]
 FX BND1      e2_S4_2_2_visit[1]  0
 BV BND1      e2_S4_2_2_visit[1]
 FX BND1      e2_S4_2_2_visit[2]  0
 BV BND1      e2_S4_2_2_visit[2]
 FX BND1      e2_S4_2_2_visit[3]  0
 BV BND1      e2_S4_2_2_visit[3]
 FX BND1      e2_S4_2_2_visit[4]  0
 BV BND1      e2_S4_2_2_visit[4]
 FX BND1      e2_S4_2_2_visit[5]  0
 BV BND1      e2_S4_2_2_visit[5]
 FX BND1      e2_S4_2_2_visit[6]  0
 BV BND1      e2_S4_2_2_visit[6]
 FX BND1      e2_S4_2_2_visit[7]  0
 BV BND1      e2_S4_2_2_visit[7]
 FX BND1      e2_S4_2_2_visit[8]  0
 BV BND1      e2_S4_2_2_visit[8]
 FX BND1      e2_S4_2_2_visit[9]  0
 BV BND1      e2_S4_2_2_visit[9]
 FX BND1      e2_S4_2_2_arc[-1,0]  0
 BV BND1      e2_S4_2_2_arc[-1,0]
 FX BND1      e2_S4_2_2_arc[-1,1]  0
 BV BND1      e2_S4_2_2_arc[-1,1]
 FX BND1      e2_S4_2_2_arc[-1,2]  0
 BV BND1      e2_S4_2_2_arc[-1,2]
 FX BND1      e2_S4_2_2_arc[-1,3]  0
 BV BND1      e2_S4_2_2_arc[-1,3]
 FX BND1      e2_S4_2_2_arc[-1,4]  0
 BV BND1      e2_S4_2_2_arc[-1,4]
 FX BND1      e2_S4_2_2_arc[-1,5]  0
 BV BND1      e2_S4_2_2_arc[-1,5]
 FX BND1      e2_S4_2_2_arc[-1,6]  0
 BV BND1      e2_S4_2_2_arc[-1,6]
 FX BND1      e2_S4_2_2_arc[-1,7]  0
 BV BND1      e2_S4_2_2_arc[-1,7]
 FX BND1      e2_S4_2_2_arc[-1,8]  0
 BV BND1      e2_S4_2_2_arc[-1,8]
 FX BND1      e2_S4_2_2_arc[-1,9]  0
 BV BND1      e2_S4_2_2_arc[-1,9]
 FX BND1      e2_S4_2_2_arc[0,-2]  0
 BV BND1      e2_S4_2_2_arc[0,-2]
 FX BND1      e2_S4_2_2_arc[1,-2]  0
 BV BND1      e2_S4_2_2_arc[1,-2]
 FX BND1      e2_S4_2_2_arc[2,-2]  0
 BV BND1      e2_S4_2_2_arc[2,-2]
 FX BND1      e2_S4_2_2_arc[3,-2]  0
 BV BND1      e2_S4_2_2_arc[3,-2]
 FX BND1      e2_S4_2_2_arc[4,-2]  0
 BV BND1      e2_S4_2_2_arc[4,-2]
 FX BND1      e2_S4_2_2_arc[5,-2]  0
 BV BND1      e2_S4_2_2_arc[5,-2]
 FX BND1      e2_S4_2_2_arc[6,-2]  0
 BV BND1      e2_S4_2_2_arc[6,-2]
 FX BND1      e2_S4_2_2_arc[7,-2]  0
 BV BND1      e2_S4_2_2_arc[7,-2]
 FX BND1      e2_S4_2_2_arc[8,-2]  0
 BV BND1      e2_S4_2_2_arc[8,-2]
 FX BND1      e2_S4_2_2_arc[9,-2]  0
 BV BND1      e2_S4_2_2_arc[9,-2]
 UP BND1      C1187     29
 UP BND1      C1188     29
 BV BND1      C1189   
 BV BND1      C1190   
 BV BND1      C1191   
 LO BND1      m5_route_0  1
 UP BND1      m5_route_0  18
 LO BND1      m5_route_1  1
 UP BND1      m5_route_1  18
 LO BND1      m5_route_2  1
 UP BND1      m5_route_2  18
 LO BND1      m5_route_3  1
 UP BND1      m5_route_3  18
 LO BND1      m5_route_4  1
 UP BND1      m5_route_4  18
 LO BND1      m5_route_5  1
 UP BND1      m5_route_5  18
 LO BND1      m5_route_6  1
 UP BND1      m5_route_6  18
 LO BND1      m5_route_7  1
 UP BND1      m5_route_7  18
 LO BND1      m5_route_8  1
 UP BND1      m5_route_8  18
 LO BND1      m5_route_9  1
 UP BND1      m5_route_9  18
 BV BND1      C1202   
 BV BND1      C1203   
 UP BND1      C1204     9
 BV BND1      C1205   
 BV BND1      C1206   
 UP BND1      C1207     9
 BV BND1      C1208   
 BV BND1      C1209   
 UP BND1      C1210     9
 BV BND1      C1211   
 BV BND1      C1212   
 UP BND1      C1213     9
 BV BND1      C1214   
 BV BND1      C1215   
 UP BND1      C1216     9
 BV BND1      C1217   
 BV BND1      C1218   
 UP BND1      C1219     9
 BV BND1      C1220   
 BV BND1      C1221   
 UP BND1      C1222     9
 BV BND1      C1223   
 BV BND1      C1224   
 UP BND1      C1225     9
 BV BND1      C1226   
 BV BND1      C1227   
 UP BND1      C1228     9
 BV BND1      C1229   
 BV BND1      C1230   
 UP BND1      C1231     9
 BV BND1      C1232   
 BV BND1      C1233   
 UP BND1      C1234     9
 BV BND1      C1235   
 BV BND1      C1236   
 UP BND1      C1237     9
 BV BND1      C1238   
 BV BND1      C1239   
 UP BND1      C1240     9
 BV BND1      C1241   
 BV BND1      C1242   
 UP BND1      C1243     9
 BV BND1      C1244   
 BV BND1      C1245   
 UP BND1      C1246     9
 BV BND1      C1247   
 BV BND1      C1248   
 UP BND1      C1249     9
 BV BND1      C1250   
 BV BND1      C1251   
 UP BND1      C1252     9
 BV BND1      C1253   
 BV BND1      C1254   
 UP BND1      C1255     9
 BV BND1      C1256   
 BV BND1      C1257   
 UP BND1      C1258     9
 BV BND1      C1259   
 BV BND1      C1260   
 UP BND1      C1261     9
 BV BND1      C1262   
 BV BND1      C1263   
 UP BND1      C1264     9
 BV BND1      C1265   
 BV BND1      C1266   
 UP BND1      C1267     9
 BV BND1      C1268   
 BV BND1      C1269   
 UP BND1      C1270     9
 BV BND1      C1271   
 BV BND1      C1272   
 UP BND1      C1273     9
 BV BND1      C1274   
 BV BND1      C1275   
 UP BND1      C1276     9
 BV BND1      C1277   
 BV BND1      C1278   
 UP BND1      C1279     9
 BV BND1      C1280   
 BV BND1      C1281   
 UP BND1      C1282     9
ENDATA
