"""Bounded, deterministic B=1 primal seed, independent of the ALNS solver.

Only independently audited schedules become incumbents. Failure of this
restricted construction says nothing about feasibility of the full MILP.
"""
import time

from models.routing.common.cycle.audit import audit_solution
from models.routing.common.cycle.state import empty_result


def construct_incumbent(problem, deadline):
    p, f = problem.operating_policy, problem.fleet
    if len(p.batches) != 1 or not problem.orders or time.perf_counter() >= deadline:
        return None
    batch = p.batches[0]
    sites = [s for s in problem.satellites if problem.demands[s, batch.id]]
    sites.sort(key=lambda s: (min(o.delivery_window[1] for o in problem.orders if o.satellite == s), s))

    def inbound(rows):
        trips, supply, distance, violations = [], {}, 0.0, 0
        for vehicle, row in enumerate(rows):
            if not row:
                continue
            weight = sum(problem.weights[s, batch.id] for s in row)
            volume = sum(problem.demands[s, batch.id]*f.container_volume for s in row)
            violations += int(weight > f.e1_weight_cap+1e-6 or volume > f.e1_volume_cap+1e-6)
            now, previous, events = batch.start+p.e1_load_time, problem.depot, []
            for kind in problem.task_kinds:
                if kind == 'p':
                    now = max(now, batch.cutoff)
                for site in row:
                    now += problem.travel(previous, site)
                    distance += problem.distance(previous, site)
                    events.append(dict(kind=kind, site_id=site, start=now, quantity=problem.demands[site, batch.id]))
                    now += problem.service(site)
                    if kind == 'd':
                        supply[site] = now
                        violations += int(now > batch.cutoff)
                    previous = site
            end = now+problem.travel(previous, problem.depot)+p.depot_return_unload_time
            distance += problem.distance(previous, problem.depot)
            violations += int(end > batch.end or end+p.e1_turnaround_time > p.cycle_end or
                              (problem.reusable and end+p.cleaning_duration > p.cycle_end))
            trips.append(dict(trip_id=f'seed_e1_{vehicle}', batch_id=batch.id, vehicle_id=vehicle,
                              departure=batch.start+p.e1_load_time, return_complete=end, events=events))
        return trips, supply, distance, violations

    rows = [[] for _ in range(f.e1_count)]
    for site in sites:
        if time.perf_counter() >= deadline:
            return None
        options = []
        for vehicle, row in enumerate(rows):
            trial = [list(r) for r in rows]
            trial[vehicle].append(site)
            _, supply, distance, violations = inbound(trial)
            # Earlier supplies improve the chance of meeting customer windows.
            options.append((violations, sum(supply.values()), distance, vehicle))
        rows[min(options)[-1]].append(site)
    e1, supply, _, violations = inbound(rows)
    if violations:
        return None
    best = None
    for sort_key in (lambda o: (o.pickup_window[0] if problem.reusable else o.delivery_window[0], o.id),
                     lambda o: (o.delivery_window[1], o.id)):
        result = empty_result(problem, 'exact')
        result['e1_trips'] = e1
        failed = False
        for site in sites:
            ready, slots = [p.cycle_start]*f.e2_per_sat_count, [0]*f.e2_per_sat_count
            for order in sorted((o for o in problem.orders if o.satellite == site), key=sort_key):
                if time.perf_counter() >= deadline:
                    return best
                choices = []
                for vehicle in range(f.e2_per_sat_count):
                    if slots[vehicle] >= p.e2_max_trips_per_vehicle:
                        continue
                    depart = max(supply[site], ready[vehicle])+p.e2_dispatch_prep_time
                    delivered = max(depart+problem.travel(site, order.customer), order.delivery_window[0])
                    late = max(0, delivered-order.delivery_window[1], delivered+order.service_time-batch.cutoff)
                    events = [dict(order_id=order.id, kind='d', start=delivered, quantity=order.count)]
                    now = delivered+order.service_time
                    if problem.reusable:
                        picked = max(now+order.min_use_time, order.pickup_window[0])
                        late += max(0, picked-order.pickup_window[1])
                        events.append(dict(order_id=order.id, kind='p', start=picked, quantity=order.count))
                        now = picked+order.service_time
                    end = now+problem.travel(order.customer, site)+p.e2_return_unload_time
                    late += max(0, end+p.e2_turnaround_time-p.cycle_end)
                    if problem.reusable:
                        late += max(0, end-batch.cutoff)
                    choices.append((late, end, vehicle, depart, events))
                if not choices:
                    failed = True
                    break
                late, end, vehicle, depart, events = min(choices)
                if late:
                    failed = True
                    break
                result['e2_trips'].append(dict(trip_id=f'seed_e2_{site}_{vehicle}_{slots[vehicle]}',
                    satellite_id=site, vehicle_id=vehicle, trip_index=slots[vehicle],
                    departure=depart, return_complete=end, events=events))
                ready[vehicle], slots[vehicle] = end+p.e2_turnaround_time, slots[vehicle]+1
            if failed:
                break
        if failed:
            continue
        audit = audit_solution(problem, result)
        if audit['valid']:
            result.update(audit=audit, cutoff_snapshots=audit['cutoff_snapshots'], depot_releases=audit['depot_releases'])
            result['info'].update(objective=audit['objective'], status='FEASIBLE', incumbent_source='deterministic_primal_seed')
            if best is None or result['info']['objective'] < best['info']['objective']:
                best = result
    return best
