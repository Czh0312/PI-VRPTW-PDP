* Signature: 0x57816b609b0000de
NAME M5_complete_enumerated_E2_route_cover
ROWS
 N  OBJ
 E  cover_0 
 E  cover_1 
 E  cover_2 
 E  cover_3 
 L  aggregate_trip_limit
COLUMNS
    route_0   OBJ       8.9423
    route_0   cover_1   1
    route_0   aggregate_trip_limit  1
    route_1   OBJ       9.5645999999999987e+00
    route_1   cover_1   1
    route_1   cover_3   1
    route_1   aggregate_trip_limit  1
    route_2   OBJ       6.2339
    route_2   cover_3   1
    route_2   aggregate_trip_limit  1
    route_3   OBJ       8.9423
    route_3   cover_0   1
    route_3   aggregate_trip_limit  1
    route_4   OBJ       8.9423
    route_4   cover_0   1
    route_4   cover_1   1
    route_4   aggregate_trip_limit  1
    route_5   OBJ       9.5645999999999987e+00
    route_5   cover_0   1
    route_5   cover_1   1
    route_5   cover_3   1
    route_5   aggregate_trip_limit  1
    route_6   OBJ       9.5645999999999987e+00
    route_6   cover_0   1
    route_6   cover_3   1
    route_6   aggregate_trip_limit  1
    route_7   OBJ       6.2339
    route_7   cover_2   1
    route_7   aggregate_trip_limit  1
    route_8   OBJ       6.2339
    route_8   cover_2   1
    route_8   cover_3   1
    route_8   aggregate_trip_limit  1
RHS
    RHS1      cover_0   1
    RHS1      cover_1   1
    RHS1      cover_2   1
    RHS1      cover_3   1
    RHS1      aggregate_trip_limit  4
BOUNDS
ENDATA
