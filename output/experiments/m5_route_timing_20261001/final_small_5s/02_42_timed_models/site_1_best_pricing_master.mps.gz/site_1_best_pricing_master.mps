* Signature: 0xfda223ca74caf8a5
NAME M5_complete_enumerated_E2_route_cover
ROWS
 N  OBJ
 E  cover_0 
 E  cover_1 
 E  cover_2 
 E  cover_3 
 E  cover_4 
 E  cover_5 
 L  aggregate_trip_limit
COLUMNS
    route_0   OBJ       2
    route_0   cover_1   1
    route_0   aggregate_trip_limit  1
    route_1   OBJ       2
    route_1   cover_1   1
    route_1   cover_3   1
    route_1   aggregate_trip_limit  1
    route_2   OBJ       2
    route_2   cover_1   1
    route_2   cover_3   1
    route_2   cover_5   1
    route_2   aggregate_trip_limit  1
    route_3   OBJ       2
    route_3   cover_1   1
    route_3   cover_5   1
    route_3   aggregate_trip_limit  1
    route_4   OBJ       2
    route_4   cover_3   1
    route_4   aggregate_trip_limit  1
    route_5   OBJ       2
    route_5   cover_3   1
    route_5   cover_5   1
    route_5   aggregate_trip_limit  1
    route_6   OBJ       2
    route_6   cover_5   1
    route_6   aggregate_trip_limit  1
    route_7   OBJ       2
    route_7   cover_0   1
    route_7   aggregate_trip_limit  1
    route_8   OBJ       2
    route_8   cover_0   1
    route_8   cover_1   1
    route_8   aggregate_trip_limit  1
    route_9   OBJ       2
    route_9   cover_0   1
    route_9   cover_1   1
    route_9   cover_3   1
    route_9   aggregate_trip_limit  1
    route_10  OBJ       2
    route_10  cover_0   1
    route_10  cover_1   1
    route_10  cover_3   1
    route_10  cover_5   1
    route_10  aggregate_trip_limit  1
    route_11  OBJ       2
    route_11  cover_0   1
    route_11  cover_1   1
    route_11  cover_5   1
    route_11  aggregate_trip_limit  1
    route_12  OBJ       2
    route_12  cover_0   1
    route_12  cover_3   1
    route_12  aggregate_trip_limit  1
    route_13  OBJ       2
    route_13  cover_0   1
    route_13  cover_3   1
    route_13  cover_5   1
    route_13  aggregate_trip_limit  1
    route_14  OBJ       2
    route_14  cover_0   1
    route_14  cover_5   1
    route_14  aggregate_trip_limit  1
    route_15  OBJ       2
    route_15  cover_2   1
    route_15  aggregate_trip_limit  1
    route_16  OBJ       2
    route_16  cover_2   1
    route_16  cover_3   1
    route_16  aggregate_trip_limit  1
    route_17  OBJ       2
    route_17  cover_2   1
    route_17  cover_3   1
    route_17  cover_5   1
    route_17  aggregate_trip_limit  1
    route_18  OBJ       2
    route_18  cover_2   1
    route_18  cover_5   1
    route_18  aggregate_trip_limit  1
    route_19  OBJ       2
    route_19  cover_4   1
    route_19  aggregate_trip_limit  1
    route_20  OBJ       2
    route_20  cover_4   1
    route_20  cover_5   1
    route_20  aggregate_trip_limit  1
RHS
    RHS1      cover_0   1
    RHS1      cover_1   1
    RHS1      cover_2   1
    RHS1      cover_3   1
    RHS1      cover_4   1
    RHS1      cover_5   1
    RHS1      aggregate_trip_limit  6
BOUNDS
ENDATA
