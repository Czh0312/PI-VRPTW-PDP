* Signature: 0xa88db9c22172260f
NAME M5_complete_E1_route_inventory_relaxation
ROWS
 N  OBJ
 G  R0      
 L  R1      
 L  R2      
 L  R3      
 G  R4      
 L  R5      
 L  R6      
 L  R7      
 G  R8      
 L  R9      
 G  R10     
 L  R11     
 L  R12     
 L  R13     
 G  R14     
 L  R15     
 G  R16     
 L  R17     
 L  R18     
 L  R19     
 L  R20     
 L  R21     
 G  R22     
 L  R23     
 L  R24     
 L  R25     
 G  R26     
 L  R27     
 L  R28     
 L  R29     
 G  R30     
 L  R31     
 G  R32     
 L  R33     
 L  R34     
 L  R35     
 G  R36     
 L  R37     
 G  R38     
 L  R39     
 L  R40     
 L  R41     
 L  R42     
 L  R43     
 G  R44     
 L  R45     
 L  R46     
 L  R47     
 G  R48     
 L  R49     
 L  R50     
 L  R51     
 G  R52     
 L  R53     
 G  R54     
 L  R55     
 L  R56     
 L  R57     
 G  R58     
 L  R59     
 G  R60     
 L  R61     
 L  R62     
 L  R63     
 L  R64     
 L  R65     
 G  R66     
 L  R67     
 L  R68     
 L  R69     
 G  R70     
 L  R71     
 L  R72     
 L  R73     
 G  R74     
 L  R75     
 G  R76     
 L  R77     
 L  R78     
 L  R79     
 G  R80     
 L  R81     
 G  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 G  R88     
 L  R89     
 L  R90     
 L  R91     
 G  R92     
 L  R93     
 L  R94     
 L  R95     
 G  R96     
 L  R97     
 G  R98     
 L  R99     
 L  R100    
 L  R101    
 G  R102    
 L  R103    
 G  R104    
 L  R105    
 L  R106    
 L  R107    
 G  R108    
 L  R109    
 L  R110    
 L  R111    
 G  R112    
 L  R113    
 L  R114    
 L  R115    
 G  R116    
 L  R117    
 G  R118    
 L  R119    
 L  R120    
 L  R121    
 G  R122    
 L  R123    
 G  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 G  R130    
 L  R131    
 L  R132    
 L  R133    
 G  R134    
 L  R135    
 L  R136    
 L  R137    
 G  R138    
 L  R139    
 G  R140    
 L  R141    
 L  R142    
 L  R143    
 G  R144    
 L  R145    
 G  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 G  R152    
 L  R153    
 L  R154    
 L  R155    
 G  R156    
 L  R157    
 L  R158    
 L  R159    
 G  R160    
 L  R161    
 G  R162    
 L  R163    
 L  R164    
 L  R165    
 G  R166    
 L  R167    
 G  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 G  R174    
 L  R175    
 L  R176    
 L  R177    
 G  R178    
 L  R179    
 L  R180    
 L  R181    
 G  R182    
 L  R183    
 G  R184    
 L  R185    
 L  R186    
 L  R187    
 G  R188    
 L  R189    
 G  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 G  R196    
 L  R197    
 L  R198    
 L  R199    
 G  R200    
 L  R201    
 L  R202    
 L  R203    
 G  R204    
 L  R205    
 G  R206    
 L  R207    
 L  R208    
 L  R209    
 G  R210    
 L  R211    
 G  R212    
 L  R213    
 L  R214    
 L  R215    
 G  R216    
 L  R217    
 L  R218    
 L  R219    
 G  R220    
 L  R221    
 L  R222    
 L  R223    
 G  R224    
 L  R225    
 G  R226    
 L  R227    
 L  R228    
 L  R229    
 G  R230    
 L  R231    
 G  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 G  R238    
 L  R239    
 L  R240    
 L  R241    
 G  R242    
 L  R243    
 L  R244    
 L  R245    
 G  R246    
 L  R247    
 G  R248    
 L  R249    
 L  R250    
 L  R251    
 G  R252    
 L  R253    
 G  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 G  R260    
 L  R261    
 L  R262    
 L  R263    
 G  R264    
 L  R265    
 L  R266    
 L  R267    
 G  R268    
 L  R269    
 G  R270    
 L  R271    
 L  R272    
 L  R273    
 G  R274    
 L  R275    
 G  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 G  R282    
 L  R283    
 L  R284    
 L  R285    
 G  R286    
 L  R287    
 L  R288    
 L  R289    
 G  R290    
 L  R291    
 G  R292    
 L  R293    
 L  R294    
 L  R295    
 G  R296    
 L  R297    
 G  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 G  R304    
 L  R305    
 L  R306    
 L  R307    
 G  R308    
 L  R309    
 L  R310    
 L  R311    
 G  R312    
 L  R313    
 G  R314    
 L  R315    
 L  R316    
 L  R317    
 G  R318    
 L  R319    
 G  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 E  R325    
 E  R326    
 L  R327    
 E  R328    
 E  R329    
 L  R330    
 L  R331    
 E  R332    
 E  R333    
 L  R334    
 E  R335    
 E  R336    
 L  R337    
 L  R338    
 E  R339    
 E  R340    
 L  R341    
 E  R342    
 E  R343    
 L  R344    
 L  R345    
 G  R346    
 G  R347    
 G  R348    
 E  R349    
 L  R350    
 G  R351    
 G  R352    
 G  R353    
 E  R354    
 L  R355    
 G  R356    
 G  R357    
 G  R358    
 E  R359    
 L  R360    
 G  R361    
 G  R362    
 G  R363    
 E  R364    
 L  R365    
 G  R366    
 G  R367    
 G  R368    
 E  R369    
 L  R370    
 G  R371    
 G  R372    
 G  R373    
 E  R374    
 E  R375    
 E  R376    
 E  R377    
 E  R378    
 E  R379    
 E  R380    
 G  clean_stock_b1
 G  clean_stock_b2
 G  clean_stock_b3
 G  R384    
 G  R385    
 G  R386    
 G  certified_E1_cost
 E  joint_cutoff_A1_b1
 E  joint_cutoff_A1_b2
 E  joint_cutoff_A1_b3
 E  joint_cutoff_B1_b1
 E  joint_cutoff_B1_b2
 E  joint_cutoff_B1_b3
 E  joint_cutoff_A2_b1
 E  joint_cutoff_A2_b2
 E  joint_cutoff_A2_b3
 E  joint_cutoff_B2_b1
 E  joint_cutoff_B2_b2
 E  joint_cutoff_B2_b3
 E  joint_cutoff_A3_b1
 E  joint_cutoff_A3_b2
 E  joint_cutoff_A3_b3
 E  joint_cutoff_B3_b1
 E  joint_cutoff_B3_b2
 E  joint_cutoff_B3_b3
 E  joint_cover_0_0
 E  joint_cover_0_1
 E  joint_cover_0_2
 E  joint_cover_0_3
 E  joint_cover_0_4
 E  joint_cover_0_5
 L  joint_trip_limit_0
 G  certified_E2_cost_0
 L  joint_supply_0_0
 L  joint_supply_0_2
 L  joint_supply_0_4
 E  joint_cover_1_0
 E  joint_cover_1_1
 E  joint_cover_1_2
 E  joint_cover_1_3
 E  joint_cover_1_4
 E  joint_cover_1_5
 L  joint_trip_limit_1
 G  certified_E2_cost_1
 L  joint_supply_1_0
 L  joint_supply_1_2
 L  joint_supply_1_4
 G  GC0     
 L  GC1     
 G  GC2     
 L  GC3     
 G  GC4     
 L  GC5     
 G  GC6     
 L  GC7     
 G  GC8     
 L  GC9     
 G  GC10    
 L  GC11    
 G  GC12    
 L  GC13    
 G  GC14    
 L  GC15    
 G  GC16    
 L  GC17    
 G  GC18    
 L  GC19    
 G  GC20    
 L  GC21    
 G  GC22    
 L  GC23    
 G  GC24    
 L  GC25    
 G  GC26    
 L  GC27    
 G  GC28    
 L  GC29    
 G  GC30    
 L  GC31    
 G  GC32    
 L  GC33    
 G  GC34    
 L  GC35    
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    route[0]  OBJ       8
    route[0]  R0        -1
    route[0]  R1        -3
    route[0]  R2        -20.000001
    route[0]  R3        -8.000001
    route[0]  R324      1
    route[0]  R327      1
    route[0]  R384      8
    route[0]  certified_E1_cost  8
    route[1]  OBJ       8
    route[1]  R4        -1
    route[1]  R5        -3
    route[1]  R6        -20.000001
    route[1]  R7        -8.000001
    route[1]  R324      1
    route[1]  R330      1
    route[1]  R384      8
    route[1]  certified_E1_cost  8
    route[2]  OBJ       1.3656854249492380e+01
    route[2]  R8        -1
    route[2]  R9        -3
    route[2]  R10       -1
    route[2]  R11       -3
    route[2]  R12       -20.000001
    route[2]  R13       -8.000001
    route[2]  R324      1
    route[2]  R327      1
    route[2]  R330      1
    route[2]  R384      1.3656854249492380e+01
    route[2]  certified_E1_cost  1.3656854249492380e+01
    route[3]  OBJ       1.3656854249492380e+01
    route[3]  R14       -1
    route[3]  R15       -3
    route[3]  R16       -1
    route[3]  R17       -3
    route[3]  R18       -20.000001
    route[3]  R19       -8.000001
    route[3]  R324      1
    route[3]  R327      1
    route[3]  R330      1
    route[3]  R384      1.3656854249492380e+01
    route[3]  certified_E1_cost  1.3656854249492380e+01
    route[4]  OBJ       8
    route[4]  R20       -20.000001
    route[4]  R21       -8.000001
    route[4]  R324      1
    route[4]  R325      1
    route[4]  R326      -420
    route[4]  R384      8
    route[4]  certified_E1_cost  8
    route[5]  OBJ       8
    route[5]  R22       -1
    route[5]  R23       -3
    route[5]  R24       -20.000001
    route[5]  R25       -8.000001
    route[5]  R324      1
    route[5]  R325      1
    route[5]  R326      -420
    route[5]  R327      1
    route[5]  R384      8
    route[5]  certified_E1_cost  8
    route[6]  OBJ       1.3656854249492380e+01
    route[6]  R26       -1
    route[6]  R27       -3
    route[6]  R28       -20.000001
    route[6]  R29       -8.000001
    route[6]  R324      1
    route[6]  R325      1
    route[6]  R326      -420
    route[6]  R330      1
    route[6]  R384      1.3656854249492380e+01
    route[6]  certified_E1_cost  1.3656854249492380e+01
    route[7]  OBJ       1.3656854249492380e+01
    route[7]  R30       -1
    route[7]  R31       -3
    route[7]  R32       -1
    route[7]  R33       -3
    route[7]  R34       -20.000001
    route[7]  R35       -8.000001
    route[7]  R324      1
    route[7]  R325      1
    route[7]  R326      -420
    route[7]  R327      1
    route[7]  R330      1
    route[7]  R384      1.3656854249492380e+01
    route[7]  certified_E1_cost  1.3656854249492380e+01
    route[8]  OBJ       1.9313708498984759e+01
    route[8]  R36       -1
    route[8]  R37       -3
    route[8]  R38       -1
    route[8]  R39       -3
    route[8]  R40       -20.000001
    route[8]  R41       -8.000001
    route[8]  R324      1
    route[8]  R325      1
    route[8]  R326      -420
    route[8]  R327      1
    route[8]  R330      1
    route[8]  R384      1.9313708498984759e+01
    route[8]  certified_E1_cost  1.9313708498984759e+01
    route[9]  OBJ       8
    route[9]  R42       -20.000001
    route[9]  R43       -8.000001
    route[9]  R324      1
    route[9]  R328      1
    route[9]  R329      -420
    route[9]  R384      8
    route[9]  certified_E1_cost  8
    route[10]  OBJ       1.3656854249492380e+01
    route[10]  R44       -1
    route[10]  R45       -3
    route[10]  R46       -20.000001
    route[10]  R47       -8.000001
    route[10]  R324      1
    route[10]  R327      1
    route[10]  R328      1
    route[10]  R329      -420
    route[10]  R384      1.3656854249492380e+01
    route[10]  certified_E1_cost  1.3656854249492380e+01
    route[11]  OBJ       8
    route[11]  R48       -1
    route[11]  R49       -3
    route[11]  R50       -20.000001
    route[11]  R51       -8.000001
    route[11]  R324      1
    route[11]  R328      1
    route[11]  R329      -420
    route[11]  R330      1
    route[11]  R384      8
    route[11]  certified_E1_cost  8
    route[12]  OBJ       1.9313708498984759e+01
    route[12]  R52       -1
    route[12]  R53       -3
    route[12]  R54       -1
    route[12]  R55       -3
    route[12]  R56       -20.000001
    route[12]  R57       -8.000001
    route[12]  R324      1
    route[12]  R327      1
    route[12]  R328      1
    route[12]  R329      -420
    route[12]  R330      1
    route[12]  R384      1.9313708498984759e+01
    route[12]  certified_E1_cost  1.9313708498984759e+01
    route[13]  OBJ       1.3656854249492380e+01
    route[13]  R58       -1
    route[13]  R59       -3
    route[13]  R60       -1
    route[13]  R61       -3
    route[13]  R62       -20.000001
    route[13]  R63       -8.000001
    route[13]  R324      1
    route[13]  R327      1
    route[13]  R328      1
    route[13]  R329      -420
    route[13]  R330      1
    route[13]  R384      1.3656854249492380e+01
    route[13]  certified_E1_cost  1.3656854249492380e+01
    route[14]  OBJ       1.3656854249492380e+01
    route[14]  R64       -20.000001
    route[14]  R65       -8.000001
    route[14]  R324      1
    route[14]  R325      1
    route[14]  R326      -420
    route[14]  R328      1
    route[14]  R329      -820
    route[14]  R384      1.3656854249492380e+01
    route[14]  certified_E1_cost  1.3656854249492380e+01
    route[15]  OBJ       1.9313708498984759e+01
    route[15]  R66       -1
    route[15]  R67       -3
    route[15]  R68       -20.000001
    route[15]  R69       -8.000001
    route[15]  R324      1
    route[15]  R325      1
    route[15]  R326      -420
    route[15]  R327      1
    route[15]  R328      1
    route[15]  R329      -820
    route[15]  R384      1.9313708498984759e+01
    route[15]  certified_E1_cost  1.9313708498984759e+01
    route[16]  OBJ       1.3656854249492380e+01
    route[16]  R70       -1
    route[16]  R71       -3
    route[16]  R72       -20.000001
    route[16]  R73       -8.000001
    route[16]  R324      1
    route[16]  R325      1
    route[16]  R326      -420
    route[16]  R328      1
    route[16]  R329      -820
    route[16]  R330      1
    route[16]  R384      1.3656854249492380e+01
    route[16]  certified_E1_cost  1.3656854249492380e+01
    route[17]  OBJ       2.4970562748477139e+01
    route[17]  R74       -1
    route[17]  R75       -3
    route[17]  R76       -1
    route[17]  R77       -3
    route[17]  R78       -20.000001
    route[17]  R79       -8.000001
    route[17]  R324      1
    route[17]  R325      1
    route[17]  R326      -420
    route[17]  R327      1
    route[17]  R328      1
    route[17]  R329      -820
    route[17]  R330      1
    route[17]  R384      2.4970562748477139e+01
    route[17]  certified_E1_cost  2.4970562748477139e+01
    route[18]  OBJ       1.9313708498984759e+01
    route[18]  R80       -1
    route[18]  R81       -3
    route[18]  R82       -1
    route[18]  R83       -3
    route[18]  R84       -20.000001
    route[18]  R85       -8.000001
    route[18]  R324      1
    route[18]  R325      1
    route[18]  R326      -420
    route[18]  R327      1
    route[18]  R328      1
    route[18]  R329      -820
    route[18]  R330      1
    route[18]  R384      1.9313708498984759e+01
    route[18]  certified_E1_cost  1.9313708498984759e+01
    route[19]  OBJ       1.3656854249492380e+01
    route[19]  R86       -20.000001
    route[19]  R87       -8.000001
    route[19]  R324      1
    route[19]  R325      1
    route[19]  R326      -820
    route[19]  R328      1
    route[19]  R329      -420
    route[19]  R384      1.3656854249492380e+01
    route[19]  certified_E1_cost  1.3656854249492380e+01
    route[20]  OBJ       1.3656854249492380e+01
    route[20]  R88       -1
    route[20]  R89       -3
    route[20]  R90       -20.000001
    route[20]  R91       -8.000001
    route[20]  R324      1
    route[20]  R325      1
    route[20]  R326      -820
    route[20]  R327      1
    route[20]  R328      1
    route[20]  R329      -420
    route[20]  R384      1.3656854249492380e+01
    route[20]  certified_E1_cost  1.3656854249492380e+01
    route[21]  OBJ       1.9313708498984759e+01
    route[21]  R92       -1
    route[21]  R93       -3
    route[21]  R94       -20.000001
    route[21]  R95       -8.000001
    route[21]  R324      1
    route[21]  R325      1
    route[21]  R326      -820
    route[21]  R328      1
    route[21]  R329      -420
    route[21]  R330      1
    route[21]  R384      1.9313708498984759e+01
    route[21]  certified_E1_cost  1.9313708498984759e+01
    route[22]  OBJ       1.9313708498984759e+01
    route[22]  R96       -1
    route[22]  R97       -3
    route[22]  R98       -1
    route[22]  R99       -3
    route[22]  R100      -20.000001
    route[22]  R101      -8.000001
    route[22]  R324      1
    route[22]  R325      1
    route[22]  R326      -820
    route[22]  R327      1
    route[22]  R328      1
    route[22]  R329      -420
    route[22]  R330      1
    route[22]  R384      1.9313708498984759e+01
    route[22]  certified_E1_cost  1.9313708498984759e+01
    route[23]  OBJ       2.4970562748477139e+01
    route[23]  R102      -1
    route[23]  R103      -3
    route[23]  R104      -1
    route[23]  R105      -3
    route[23]  R106      -20.000001
    route[23]  R107      -8.000001
    route[23]  R324      1
    route[23]  R325      1
    route[23]  R326      -820
    route[23]  R327      1
    route[23]  R328      1
    route[23]  R329      -420
    route[23]  R330      1
    route[23]  R384      2.4970562748477139e+01
    route[23]  certified_E1_cost  2.4970562748477139e+01
    route[24]  OBJ       8
    route[24]  R108      -1
    route[24]  R109      -3
    route[24]  R110      -20.000001
    route[24]  R111      -8.000001
    route[24]  R331      1
    route[24]  R334      1
    route[24]  R385      8
    route[24]  certified_E1_cost  8
    route[25]  OBJ       8
    route[25]  R112      -1
    route[25]  R113      -3
    route[25]  R114      -20.000001
    route[25]  R115      -8.000001
    route[25]  R331      1
    route[25]  R337      1
    route[25]  R385      8
    route[25]  certified_E1_cost  8
    route[26]  OBJ       1.3656854249492380e+01
    route[26]  R116      -1
    route[26]  R117      -3
    route[26]  R118      -1
    route[26]  R119      -3
    route[26]  R120      -20.000001
    route[26]  R121      -8.000001
    route[26]  R331      1
    route[26]  R334      1
    route[26]  R337      1
    route[26]  R385      1.3656854249492380e+01
    route[26]  certified_E1_cost  1.3656854249492380e+01
    route[27]  OBJ       1.3656854249492380e+01
    route[27]  R122      -1
    route[27]  R123      -3
    route[27]  R124      -1
    route[27]  R125      -3
    route[27]  R126      -20.000001
    route[27]  R127      -8.000001
    route[27]  R331      1
    route[27]  R334      1
    route[27]  R337      1
    route[27]  R385      1.3656854249492380e+01
    route[27]  certified_E1_cost  1.3656854249492380e+01
    route[28]  OBJ       8
    route[28]  R128      -20.000001
    route[28]  R129      -8.000001
    route[28]  R331      1
    route[28]  R332      1
    route[28]  R333      -4020
    route[28]  R385      8
    route[28]  certified_E1_cost  8
    route[29]  OBJ       8
    route[29]  R130      -1
    route[29]  R131      -3
    route[29]  R132      -20.000001
    route[29]  R133      -8.000001
    route[29]  R331      1
    route[29]  R332      1
    route[29]  R333      -4020
    route[29]  R334      1
    route[29]  R385      8
    route[29]  certified_E1_cost  8
    route[30]  OBJ       1.3656854249492380e+01
    route[30]  R134      -1
    route[30]  R135      -3
    route[30]  R136      -20.000001
    route[30]  R137      -8.000001
    route[30]  R331      1
    route[30]  R332      1
    route[30]  R333      -4020
    route[30]  R337      1
    route[30]  R385      1.3656854249492380e+01
    route[30]  certified_E1_cost  1.3656854249492380e+01
    route[31]  OBJ       1.3656854249492380e+01
    route[31]  R138      -1
    route[31]  R139      -3
    route[31]  R140      -1
    route[31]  R141      -3
    route[31]  R142      -20.000001
    route[31]  R143      -8.000001
    route[31]  R331      1
    route[31]  R332      1
    route[31]  R333      -4020
    route[31]  R334      1
    route[31]  R337      1
    route[31]  R385      1.3656854249492380e+01
    route[31]  certified_E1_cost  1.3656854249492380e+01
    route[32]  OBJ       1.9313708498984759e+01
    route[32]  R144      -1
    route[32]  R145      -3
    route[32]  R146      -1
    route[32]  R147      -3
    route[32]  R148      -20.000001
    route[32]  R149      -8.000001
    route[32]  R331      1
    route[32]  R332      1
    route[32]  R333      -4020
    route[32]  R334      1
    route[32]  R337      1
    route[32]  R385      1.9313708498984759e+01
    route[32]  certified_E1_cost  1.9313708498984759e+01
    route[33]  OBJ       8
    route[33]  R150      -20.000001
    route[33]  R151      -8.000001
    route[33]  R331      1
    route[33]  R335      1
    route[33]  R336      -4020
    route[33]  R385      8
    route[33]  certified_E1_cost  8
    route[34]  OBJ       1.3656854249492380e+01
    route[34]  R152      -1
    route[34]  R153      -3
    route[34]  R154      -20.000001
    route[34]  R155      -8.000001
    route[34]  R331      1
    route[34]  R334      1
    route[34]  R335      1
    route[34]  R336      -4020
    route[34]  R385      1.3656854249492380e+01
    route[34]  certified_E1_cost  1.3656854249492380e+01
    route[35]  OBJ       8
    route[35]  R156      -1
    route[35]  R157      -3
    route[35]  R158      -20.000001
    route[35]  R159      -8.000001
    route[35]  R331      1
    route[35]  R335      1
    route[35]  R336      -4020
    route[35]  R337      1
    route[35]  R385      8
    route[35]  certified_E1_cost  8
    route[36]  OBJ       1.9313708498984759e+01
    route[36]  R160      -1
    route[36]  R161      -3
    route[36]  R162      -1
    route[36]  R163      -3
    route[36]  R164      -20.000001
    route[36]  R165      -8.000001
    route[36]  R331      1
    route[36]  R334      1
    route[36]  R335      1
    route[36]  R336      -4020
    route[36]  R337      1
    route[36]  R385      1.9313708498984759e+01
    route[36]  certified_E1_cost  1.9313708498984759e+01
    route[37]  OBJ       1.3656854249492380e+01
    route[37]  R166      -1
    route[37]  R167      -3
    route[37]  R168      -1
    route[37]  R169      -3
    route[37]  R170      -20.000001
    route[37]  R171      -8.000001
    route[37]  R331      1
    route[37]  R334      1
    route[37]  R335      1
    route[37]  R336      -4020
    route[37]  R337      1
    route[37]  R385      1.3656854249492380e+01
    route[37]  certified_E1_cost  1.3656854249492380e+01
    route[38]  OBJ       1.3656854249492380e+01
    route[38]  R172      -20.000001
    route[38]  R173      -8.000001
    route[38]  R331      1
    route[38]  R332      1
    route[38]  R333      -4020
    route[38]  R335      1
    route[38]  R336      -4420
    route[38]  R385      1.3656854249492380e+01
    route[38]  certified_E1_cost  1.3656854249492380e+01
    route[39]  OBJ       1.9313708498984759e+01
    route[39]  R174      -1
    route[39]  R175      -3
    route[39]  R176      -20.000001
    route[39]  R177      -8.000001
    route[39]  R331      1
    route[39]  R332      1
    route[39]  R333      -4020
    route[39]  R334      1
    route[39]  R335      1
    route[39]  R336      -4420
    route[39]  R385      1.9313708498984759e+01
    route[39]  certified_E1_cost  1.9313708498984759e+01
    route[40]  OBJ       1.3656854249492380e+01
    route[40]  R178      -1
    route[40]  R179      -3
    route[40]  R180      -20.000001
    route[40]  R181      -8.000001
    route[40]  R331      1
    route[40]  R332      1
    route[40]  R333      -4020
    route[40]  R335      1
    route[40]  R336      -4420
    route[40]  R337      1
    route[40]  R385      1.3656854249492380e+01
    route[40]  certified_E1_cost  1.3656854249492380e+01
    route[41]  OBJ       2.4970562748477139e+01
    route[41]  R182      -1
    route[41]  R183      -3
    route[41]  R184      -1
    route[41]  R185      -3
    route[41]  R186      -20.000001
    route[41]  R187      -8.000001
    route[41]  R331      1
    route[41]  R332      1
    route[41]  R333      -4020
    route[41]  R334      1
    route[41]  R335      1
    route[41]  R336      -4420
    route[41]  R337      1
    route[41]  R385      2.4970562748477139e+01
    route[41]  certified_E1_cost  2.4970562748477139e+01
    route[42]  OBJ       1.9313708498984759e+01
    route[42]  R188      -1
    route[42]  R189      -3
    route[42]  R190      -1
    route[42]  R191      -3
    route[42]  R192      -20.000001
    route[42]  R193      -8.000001
    route[42]  R331      1
    route[42]  R332      1
    route[42]  R333      -4020
    route[42]  R334      1
    route[42]  R335      1
    route[42]  R336      -4420
    route[42]  R337      1
    route[42]  R385      1.9313708498984759e+01
    route[42]  certified_E1_cost  1.9313708498984759e+01
    route[43]  OBJ       1.3656854249492380e+01
    route[43]  R194      -20.000001
    route[43]  R195      -8.000001
    route[43]  R331      1
    route[43]  R332      1
    route[43]  R333      -4420
    route[43]  R335      1
    route[43]  R336      -4020
    route[43]  R385      1.3656854249492380e+01
    route[43]  certified_E1_cost  1.3656854249492380e+01
    route[44]  OBJ       1.3656854249492380e+01
    route[44]  R196      -1
    route[44]  R197      -3
    route[44]  R198      -20.000001
    route[44]  R199      -8.000001
    route[44]  R331      1
    route[44]  R332      1
    route[44]  R333      -4420
    route[44]  R334      1
    route[44]  R335      1
    route[44]  R336      -4020
    route[44]  R385      1.3656854249492380e+01
    route[44]  certified_E1_cost  1.3656854249492380e+01
    route[45]  OBJ       1.9313708498984759e+01
    route[45]  R200      -1
    route[45]  R201      -3
    route[45]  R202      -20.000001
    route[45]  R203      -8.000001
    route[45]  R331      1
    route[45]  R332      1
    route[45]  R333      -4420
    route[45]  R335      1
    route[45]  R336      -4020
    route[45]  R337      1
    route[45]  R385      1.9313708498984759e+01
    route[45]  certified_E1_cost  1.9313708498984759e+01
    route[46]  OBJ       1.9313708498984759e+01
    route[46]  R204      -1
    route[46]  R205      -3
    route[46]  R206      -1
    route[46]  R207      -3
    route[46]  R208      -20.000001
    route[46]  R209      -8.000001
    route[46]  R331      1
    route[46]  R332      1
    route[46]  R333      -4420
    route[46]  R334      1
    route[46]  R335      1
    route[46]  R336      -4020
    route[46]  R337      1
    route[46]  R385      1.9313708498984759e+01
    route[46]  certified_E1_cost  1.9313708498984759e+01
    route[47]  OBJ       2.4970562748477139e+01
    route[47]  R210      -1
    route[47]  R211      -3
    route[47]  R212      -1
    route[47]  R213      -3
    route[47]  R214      -20.000001
    route[47]  R215      -8.000001
    route[47]  R331      1
    route[47]  R332      1
    route[47]  R333      -4420
    route[47]  R334      1
    route[47]  R335      1
    route[47]  R336      -4020
    route[47]  R337      1
    route[47]  R385      2.4970562748477139e+01
    route[47]  certified_E1_cost  2.4970562748477139e+01
    route[48]  OBJ       8
    route[48]  R216      -1
    route[48]  R217      -3
    route[48]  R218      -20.000001
    route[48]  R219      -8.000001
    route[48]  R338      1
    route[48]  R341      1
    route[48]  R386      8
    route[48]  certified_E1_cost  8
    route[49]  OBJ       8
    route[49]  R220      -1
    route[49]  R221      -3
    route[49]  R222      -20.000001
    route[49]  R223      -8.000001
    route[49]  R338      1
    route[49]  R344      1
    route[49]  R386      8
    route[49]  certified_E1_cost  8
    route[50]  OBJ       1.3656854249492380e+01
    route[50]  R224      -1
    route[50]  R225      -3
    route[50]  R226      -1
    route[50]  R227      -3
    route[50]  R228      -20.000001
    route[50]  R229      -8.000001
    route[50]  R338      1
    route[50]  R341      1
    route[50]  R344      1
    route[50]  R386      1.3656854249492380e+01
    route[50]  certified_E1_cost  1.3656854249492380e+01
    route[51]  OBJ       1.3656854249492380e+01
    route[51]  R230      -1
    route[51]  R231      -3
    route[51]  R232      -1
    route[51]  R233      -3
    route[51]  R234      -20.000001
    route[51]  R235      -8.000001
    route[51]  R338      1
    route[51]  R341      1
    route[51]  R344      1
    route[51]  R386      1.3656854249492380e+01
    route[51]  certified_E1_cost  1.3656854249492380e+01
    route[52]  OBJ       8
    route[52]  R236      -20.000001
    route[52]  R237      -8.000001
    route[52]  R338      1
    route[52]  R339      1
    route[52]  R340      -7620
    route[52]  R386      8
    route[52]  certified_E1_cost  8
    route[53]  OBJ       8
    route[53]  R238      -1
    route[53]  R239      -3
    route[53]  R240      -20.000001
    route[53]  R241      -8.000001
    route[53]  R338      1
    route[53]  R339      1
    route[53]  R340      -7620
    route[53]  R341      1
    route[53]  R386      8
    route[53]  certified_E1_cost  8
    route[54]  OBJ       1.3656854249492380e+01
    route[54]  R242      -1
    route[54]  R243      -3
    route[54]  R244      -20.000001
    route[54]  R245      -8.000001
    route[54]  R338      1
    route[54]  R339      1
    route[54]  R340      -7620
    route[54]  R344      1
    route[54]  R386      1.3656854249492380e+01
    route[54]  certified_E1_cost  1.3656854249492380e+01
    route[55]  OBJ       1.3656854249492380e+01
    route[55]  R246      -1
    route[55]  R247      -3
    route[55]  R248      -1
    route[55]  R249      -3
    route[55]  R250      -20.000001
    route[55]  R251      -8.000001
    route[55]  R338      1
    route[55]  R339      1
    route[55]  R340      -7620
    route[55]  R341      1
    route[55]  R344      1
    route[55]  R386      1.3656854249492380e+01
    route[55]  certified_E1_cost  1.3656854249492380e+01
    route[56]  OBJ       1.9313708498984759e+01
    route[56]  R252      -1
    route[56]  R253      -3
    route[56]  R254      -1
    route[56]  R255      -3
    route[56]  R256      -20.000001
    route[56]  R257      -8.000001
    route[56]  R338      1
    route[56]  R339      1
    route[56]  R340      -7620
    route[56]  R341      1
    route[56]  R344      1
    route[56]  R386      1.9313708498984759e+01
    route[56]  certified_E1_cost  1.9313708498984759e+01
    route[57]  OBJ       8
    route[57]  R258      -20.000001
    route[57]  R259      -8.000001
    route[57]  R338      1
    route[57]  R342      1
    route[57]  R343      -7620
    route[57]  R386      8
    route[57]  certified_E1_cost  8
    route[58]  OBJ       1.3656854249492380e+01
    route[58]  R260      -1
    route[58]  R261      -3
    route[58]  R262      -20.000001
    route[58]  R263      -8.000001
    route[58]  R338      1
    route[58]  R341      1
    route[58]  R342      1
    route[58]  R343      -7620
    route[58]  R386      1.3656854249492380e+01
    route[58]  certified_E1_cost  1.3656854249492380e+01
    route[59]  OBJ       8
    route[59]  R264      -1
    route[59]  R265      -3
    route[59]  R266      -20.000001
    route[59]  R267      -8.000001
    route[59]  R338      1
    route[59]  R342      1
    route[59]  R343      -7620
    route[59]  R344      1
    route[59]  R386      8
    route[59]  certified_E1_cost  8
    route[60]  OBJ       1.9313708498984759e+01
    route[60]  R268      -1
    route[60]  R269      -3
    route[60]  R270      -1
    route[60]  R271      -3
    route[60]  R272      -20.000001
    route[60]  R273      -8.000001
    route[60]  R338      1
    route[60]  R341      1
    route[60]  R342      1
    route[60]  R343      -7620
    route[60]  R344      1
    route[60]  R386      1.9313708498984759e+01
    route[60]  certified_E1_cost  1.9313708498984759e+01
    route[61]  OBJ       1.3656854249492380e+01
    route[61]  R274      -1
    route[61]  R275      -3
    route[61]  R276      -1
    route[61]  R277      -3
    route[61]  R278      -20.000001
    route[61]  R279      -8.000001
    route[61]  R338      1
    route[61]  R341      1
    route[61]  R342      1
    route[61]  R343      -7620
    route[61]  R344      1
    route[61]  R386      1.3656854249492380e+01
    route[61]  certified_E1_cost  1.3656854249492380e+01
    route[62]  OBJ       1.3656854249492380e+01
    route[62]  R280      -20.000001
    route[62]  R281      -8.000001
    route[62]  R338      1
    route[62]  R339      1
    route[62]  R340      -7620
    route[62]  R342      1
    route[62]  R343      -8020
    route[62]  R386      1.3656854249492380e+01
    route[62]  certified_E1_cost  1.3656854249492380e+01
    route[63]  OBJ       1.9313708498984759e+01
    route[63]  R282      -1
    route[63]  R283      -3
    route[63]  R284      -20.000001
    route[63]  R285      -8.000001
    route[63]  R338      1
    route[63]  R339      1
    route[63]  R340      -7620
    route[63]  R341      1
    route[63]  R342      1
    route[63]  R343      -8020
    route[63]  R386      1.9313708498984759e+01
    route[63]  certified_E1_cost  1.9313708498984759e+01
    route[64]  OBJ       1.3656854249492380e+01
    route[64]  R286      -1
    route[64]  R287      -3
    route[64]  R288      -20.000001
    route[64]  R289      -8.000001
    route[64]  R338      1
    route[64]  R339      1
    route[64]  R340      -7620
    route[64]  R342      1
    route[64]  R343      -8020
    route[64]  R344      1
    route[64]  R386      1.3656854249492380e+01
    route[64]  certified_E1_cost  1.3656854249492380e+01
    route[65]  OBJ       2.4970562748477139e+01
    route[65]  R290      -1
    route[65]  R291      -3
    route[65]  R292      -1
    route[65]  R293      -3
    route[65]  R294      -20.000001
    route[65]  R295      -8.000001
    route[65]  R338      1
    route[65]  R339      1
    route[65]  R340      -7620
    route[65]  R341      1
    route[65]  R342      1
    route[65]  R343      -8020
    route[65]  R344      1
    route[65]  R386      2.4970562748477139e+01
    route[65]  certified_E1_cost  2.4970562748477139e+01
    route[66]  OBJ       1.9313708498984759e+01
    route[66]  R296      -1
    route[66]  R297      -3
    route[66]  R298      -1
    route[66]  R299      -3
    route[66]  R300      -20.000001
    route[66]  R301      -8.000001
    route[66]  R338      1
    route[66]  R339      1
    route[66]  R340      -7620
    route[66]  R341      1
    route[66]  R342      1
    route[66]  R343      -8020
    route[66]  R344      1
    route[66]  R386      1.9313708498984759e+01
    route[66]  certified_E1_cost  1.9313708498984759e+01
    route[67]  OBJ       1.3656854249492380e+01
    route[67]  R302      -20.000001
    route[67]  R303      -8.000001
    route[67]  R338      1
    route[67]  R339      1
    route[67]  R340      -8020
    route[67]  R342      1
    route[67]  R343      -7620
    route[67]  R386      1.3656854249492380e+01
    route[67]  certified_E1_cost  1.3656854249492380e+01
    route[68]  OBJ       1.3656854249492380e+01
    route[68]  R304      -1
    route[68]  R305      -3
    route[68]  R306      -20.000001
    route[68]  R307      -8.000001
    route[68]  R338      1
    route[68]  R339      1
    route[68]  R340      -8020
    route[68]  R341      1
    route[68]  R342      1
    route[68]  R343      -7620
    route[68]  R386      1.3656854249492380e+01
    route[68]  certified_E1_cost  1.3656854249492380e+01
    route[69]  OBJ       1.9313708498984759e+01
    route[69]  R308      -1
    route[69]  R309      -3
    route[69]  R310      -20.000001
    route[69]  R311      -8.000001
    route[69]  R338      1
    route[69]  R339      1
    route[69]  R340      -8020
    route[69]  R342      1
    route[69]  R343      -7620
    route[69]  R344      1
    route[69]  R386      1.9313708498984759e+01
    route[69]  certified_E1_cost  1.9313708498984759e+01
    route[70]  OBJ       1.9313708498984759e+01
    route[70]  R312      -1
    route[70]  R313      -3
    route[70]  R314      -1
    route[70]  R315      -3
    route[70]  R316      -20.000001
    route[70]  R317      -8.000001
    route[70]  R338      1
    route[70]  R339      1
    route[70]  R340      -8020
    route[70]  R341      1
    route[70]  R342      1
    route[70]  R343      -7620
    route[70]  R344      1
    route[70]  R386      1.9313708498984759e+01
    route[70]  certified_E1_cost  1.9313708498984759e+01
    route[71]  OBJ       2.4970562748477139e+01
    route[71]  R318      -1
    route[71]  R319      -3
    route[71]  R320      -1
    route[71]  R321      -3
    route[71]  R322      -20.000001
    route[71]  R323      -8.000001
    route[71]  R338      1
    route[71]  R339      1
    route[71]  R340      -8020
    route[71]  R341      1
    route[71]  R342      1
    route[71]  R343      -7620
    route[71]  R344      1
    route[71]  R386      2.4970562748477139e+01
    route[71]  certified_E1_cost  2.4970562748477139e+01
    quantity_0_A  R0        1
    quantity_0_A  R1        1
    quantity_0_A  R2        1
    quantity_0_A  R3        1
    quantity_0_A  R375      1
    quantity_0_A  clean_stock_b2  1
    quantity_0_A  clean_stock_b3  1
    quantity_1_B  R4        1
    quantity_1_B  R5        1
    quantity_1_B  R6        1
    quantity_1_B  R7        1
    quantity_1_B  R376      1
    quantity_1_B  clean_stock_b2  1
    quantity_1_B  clean_stock_b3  1
    quantity_2_A  R8        1
    quantity_2_A  R9        1
    quantity_2_A  R12       1
    quantity_2_A  R13       1
    quantity_2_A  R375      1
    quantity_2_A  clean_stock_b2  1
    quantity_2_A  clean_stock_b3  1
    quantity_2_B  R10       1
    quantity_2_B  R11       1
    quantity_2_B  R12       1
    quantity_2_B  R13       1
    quantity_2_B  R376      1
    quantity_2_B  clean_stock_b2  1
    quantity_2_B  clean_stock_b3  1
    quantity_3_B  R14       1
    quantity_3_B  R15       1
    quantity_3_B  R18       1
    quantity_3_B  R19       1
    quantity_3_B  R376      1
    quantity_3_B  clean_stock_b2  1
    quantity_3_B  clean_stock_b3  1
    quantity_3_A  R16       1
    quantity_3_A  R17       1
    quantity_3_A  R18       1
    quantity_3_A  R19       1
    quantity_3_A  R375      1
    quantity_3_A  clean_stock_b2  1
    quantity_3_A  clean_stock_b3  1
    quantity_5_A  R22       1
    quantity_5_A  R23       1
    quantity_5_A  R24       1
    quantity_5_A  R25       1
    quantity_5_A  R375      1
    quantity_5_A  clean_stock_b2  1
    quantity_5_A  clean_stock_b3  1
    quantity_6_B  R26       1
    quantity_6_B  R27       1
    quantity_6_B  R28       1
    quantity_6_B  R29       1
    quantity_6_B  R376      1
    quantity_6_B  clean_stock_b2  1
    quantity_6_B  clean_stock_b3  1
    quantity_7_A  R30       1
    quantity_7_A  R31       1
    quantity_7_A  R34       1
    quantity_7_A  R35       1
    quantity_7_A  R375      1
    quantity_7_A  clean_stock_b2  1
    quantity_7_A  clean_stock_b3  1
    quantity_7_B  R32       1
    quantity_7_B  R33       1
    quantity_7_B  R34       1
    quantity_7_B  R35       1
    quantity_7_B  R376      1
    quantity_7_B  clean_stock_b2  1
    quantity_7_B  clean_stock_b3  1
    quantity_8_B  R36       1
    quantity_8_B  R37       1
    quantity_8_B  R40       1
    quantity_8_B  R41       1
    quantity_8_B  R376      1
    quantity_8_B  clean_stock_b2  1
    quantity_8_B  clean_stock_b3  1
    quantity_8_A  R38       1
    quantity_8_A  R39       1
    quantity_8_A  R40       1
    quantity_8_A  R41       1
    quantity_8_A  R375      1
    quantity_8_A  clean_stock_b2  1
    quantity_8_A  clean_stock_b3  1
    quantity_10_A  R44       1
    quantity_10_A  R45       1
    quantity_10_A  R46       1
    quantity_10_A  R47       1
    quantity_10_A  R375      1
    quantity_10_A  clean_stock_b2  1
    quantity_10_A  clean_stock_b3  1
    quantity_11_B  R48       1
    quantity_11_B  R49       1
    quantity_11_B  R50       1
    quantity_11_B  R51       1
    quantity_11_B  R376      1
    quantity_11_B  clean_stock_b2  1
    quantity_11_B  clean_stock_b3  1
    quantity_12_A  R52       1
    quantity_12_A  R53       1
    quantity_12_A  R56       1
    quantity_12_A  R57       1
    quantity_12_A  R375      1
    quantity_12_A  clean_stock_b2  1
    quantity_12_A  clean_stock_b3  1
    quantity_12_B  R54       1
    quantity_12_B  R55       1
    quantity_12_B  R56       1
    quantity_12_B  R57       1
    quantity_12_B  R376      1
    quantity_12_B  clean_stock_b2  1
    quantity_12_B  clean_stock_b3  1
    quantity_13_B  R58       1
    quantity_13_B  R59       1
    quantity_13_B  R62       1
    quantity_13_B  R63       1
    quantity_13_B  R376      1
    quantity_13_B  clean_stock_b2  1
    quantity_13_B  clean_stock_b3  1
    quantity_13_A  R60       1
    quantity_13_A  R61       1
    quantity_13_A  R62       1
    quantity_13_A  R63       1
    quantity_13_A  R375      1
    quantity_13_A  clean_stock_b2  1
    quantity_13_A  clean_stock_b3  1
    quantity_15_A  R66       1
    quantity_15_A  R67       1
    quantity_15_A  R68       1
    quantity_15_A  R69       1
    quantity_15_A  R375      1
    quantity_15_A  clean_stock_b2  1
    quantity_15_A  clean_stock_b3  1
    quantity_16_B  R70       1
    quantity_16_B  R71       1
    quantity_16_B  R72       1
    quantity_16_B  R73       1
    quantity_16_B  R376      1
    quantity_16_B  clean_stock_b2  1
    quantity_16_B  clean_stock_b3  1
    quantity_17_A  R74       1
    quantity_17_A  R75       1
    quantity_17_A  R78       1
    quantity_17_A  R79       1
    quantity_17_A  R375      1
    quantity_17_A  clean_stock_b2  1
    quantity_17_A  clean_stock_b3  1
    quantity_17_B  R76       1
    quantity_17_B  R77       1
    quantity_17_B  R78       1
    quantity_17_B  R79       1
    quantity_17_B  R376      1
    quantity_17_B  clean_stock_b2  1
    quantity_17_B  clean_stock_b3  1
    quantity_18_B  R80       1
    quantity_18_B  R81       1
    quantity_18_B  R84       1
    quantity_18_B  R85       1
    quantity_18_B  R376      1
    quantity_18_B  clean_stock_b2  1
    quantity_18_B  clean_stock_b3  1
    quantity_18_A  R82       1
    quantity_18_A  R83       1
    quantity_18_A  R84       1
    quantity_18_A  R85       1
    quantity_18_A  R375      1
    quantity_18_A  clean_stock_b2  1
    quantity_18_A  clean_stock_b3  1
    quantity_20_A  R88       1
    quantity_20_A  R89       1
    quantity_20_A  R90       1
    quantity_20_A  R91       1
    quantity_20_A  R375      1
    quantity_20_A  clean_stock_b2  1
    quantity_20_A  clean_stock_b3  1
    quantity_21_B  R92       1
    quantity_21_B  R93       1
    quantity_21_B  R94       1
    quantity_21_B  R95       1
    quantity_21_B  R376      1
    quantity_21_B  clean_stock_b2  1
    quantity_21_B  clean_stock_b3  1
    quantity_22_A  R96       1
    quantity_22_A  R97       1
    quantity_22_A  R100      1
    quantity_22_A  R101      1
    quantity_22_A  R375      1
    quantity_22_A  clean_stock_b2  1
    quantity_22_A  clean_stock_b3  1
    quantity_22_B  R98       1
    quantity_22_B  R99       1
    quantity_22_B  R100      1
    quantity_22_B  R101      1
    quantity_22_B  R376      1
    quantity_22_B  clean_stock_b2  1
    quantity_22_B  clean_stock_b3  1
    quantity_23_B  R102      1
    quantity_23_B  R103      1
    quantity_23_B  R106      1
    quantity_23_B  R107      1
    quantity_23_B  R376      1
    quantity_23_B  clean_stock_b2  1
    quantity_23_B  clean_stock_b3  1
    quantity_23_A  R104      1
    quantity_23_A  R105      1
    quantity_23_A  R106      1
    quantity_23_A  R107      1
    quantity_23_A  R375      1
    quantity_23_A  clean_stock_b2  1
    quantity_23_A  clean_stock_b3  1
    quantity_24_A  R108      1
    quantity_24_A  R109      1
    quantity_24_A  R110      1
    quantity_24_A  R111      1
    quantity_24_A  R377      1
    quantity_24_A  clean_stock_b3  1
    quantity_25_B  R112      1
    quantity_25_B  R113      1
    quantity_25_B  R114      1
    quantity_25_B  R115      1
    quantity_25_B  R378      1
    quantity_25_B  clean_stock_b3  1
    quantity_26_A  R116      1
    quantity_26_A  R117      1
    quantity_26_A  R120      1
    quantity_26_A  R121      1
    quantity_26_A  R377      1
    quantity_26_A  clean_stock_b3  1
    quantity_26_B  R118      1
    quantity_26_B  R119      1
    quantity_26_B  R120      1
    quantity_26_B  R121      1
    quantity_26_B  R378      1
    quantity_26_B  clean_stock_b3  1
    quantity_27_B  R122      1
    quantity_27_B  R123      1
    quantity_27_B  R126      1
    quantity_27_B  R127      1
    quantity_27_B  R378      1
    quantity_27_B  clean_stock_b3  1
    quantity_27_A  R124      1
    quantity_27_A  R125      1
    quantity_27_A  R126      1
    quantity_27_A  R127      1
    quantity_27_A  R377      1
    quantity_27_A  clean_stock_b3  1
    quantity_29_A  R130      1
    quantity_29_A  R131      1
    quantity_29_A  R132      1
    quantity_29_A  R133      1
    quantity_29_A  R377      1
    quantity_29_A  clean_stock_b3  1
    quantity_30_B  R134      1
    quantity_30_B  R135      1
    quantity_30_B  R136      1
    quantity_30_B  R137      1
    quantity_30_B  R378      1
    quantity_30_B  clean_stock_b3  1
    quantity_31_A  R138      1
    quantity_31_A  R139      1
    quantity_31_A  R142      1
    quantity_31_A  R143      1
    quantity_31_A  R377      1
    quantity_31_A  clean_stock_b3  1
    quantity_31_B  R140      1
    quantity_31_B  R141      1
    quantity_31_B  R142      1
    quantity_31_B  R143      1
    quantity_31_B  R378      1
    quantity_31_B  clean_stock_b3  1
    quantity_32_B  R144      1
    quantity_32_B  R145      1
    quantity_32_B  R148      1
    quantity_32_B  R149      1
    quantity_32_B  R378      1
    quantity_32_B  clean_stock_b3  1
    quantity_32_A  R146      1
    quantity_32_A  R147      1
    quantity_32_A  R148      1
    quantity_32_A  R149      1
    quantity_32_A  R377      1
    quantity_32_A  clean_stock_b3  1
    quantity_34_A  R152      1
    quantity_34_A  R153      1
    quantity_34_A  R154      1
    quantity_34_A  R155      1
    quantity_34_A  R377      1
    quantity_34_A  clean_stock_b3  1
    quantity_35_B  R156      1
    quantity_35_B  R157      1
    quantity_35_B  R158      1
    quantity_35_B  R159      1
    quantity_35_B  R378      1
    quantity_35_B  clean_stock_b3  1
    quantity_36_A  R160      1
    quantity_36_A  R161      1
    quantity_36_A  R164      1
    quantity_36_A  R165      1
    quantity_36_A  R377      1
    quantity_36_A  clean_stock_b3  1
    quantity_36_B  R162      1
    quantity_36_B  R163      1
    quantity_36_B  R164      1
    quantity_36_B  R165      1
    quantity_36_B  R378      1
    quantity_36_B  clean_stock_b3  1
    quantity_37_B  R166      1
    quantity_37_B  R167      1
    quantity_37_B  R170      1
    quantity_37_B  R171      1
    quantity_37_B  R378      1
    quantity_37_B  clean_stock_b3  1
    quantity_37_A  R168      1
    quantity_37_A  R169      1
    quantity_37_A  R170      1
    quantity_37_A  R171      1
    quantity_37_A  R377      1
    quantity_37_A  clean_stock_b3  1
    quantity_39_A  R174      1
    quantity_39_A  R175      1
    quantity_39_A  R176      1
    quantity_39_A  R177      1
    quantity_39_A  R377      1
    quantity_39_A  clean_stock_b3  1
    quantity_40_B  R178      1
    quantity_40_B  R179      1
    quantity_40_B  R180      1
    quantity_40_B  R181      1
    quantity_40_B  R378      1
    quantity_40_B  clean_stock_b3  1
    quantity_41_A  R182      1
    quantity_41_A  R183      1
    quantity_41_A  R186      1
    quantity_41_A  R187      1
    quantity_41_A  R377      1
    quantity_41_A  clean_stock_b3  1
    quantity_41_B  R184      1
    quantity_41_B  R185      1
    quantity_41_B  R186      1
    quantity_41_B  R187      1
    quantity_41_B  R378      1
    quantity_41_B  clean_stock_b3  1
    quantity_42_B  R188      1
    quantity_42_B  R189      1
    quantity_42_B  R192      1
    quantity_42_B  R193      1
    quantity_42_B  R378      1
    quantity_42_B  clean_stock_b3  1
    quantity_42_A  R190      1
    quantity_42_A  R191      1
    quantity_42_A  R192      1
    quantity_42_A  R193      1
    quantity_42_A  R377      1
    quantity_42_A  clean_stock_b3  1
    quantity_44_A  R196      1
    quantity_44_A  R197      1
    quantity_44_A  R198      1
    quantity_44_A  R199      1
    quantity_44_A  R377      1
    quantity_44_A  clean_stock_b3  1
    quantity_45_B  R200      1
    quantity_45_B  R201      1
    quantity_45_B  R202      1
    quantity_45_B  R203      1
    quantity_45_B  R378      1
    quantity_45_B  clean_stock_b3  1
    quantity_46_A  R204      1
    quantity_46_A  R205      1
    quantity_46_A  R208      1
    quantity_46_A  R209      1
    quantity_46_A  R377      1
    quantity_46_A  clean_stock_b3  1
    quantity_46_B  R206      1
    quantity_46_B  R207      1
    quantity_46_B  R208      1
    quantity_46_B  R209      1
    quantity_46_B  R378      1
    quantity_46_B  clean_stock_b3  1
    quantity_47_B  R210      1
    quantity_47_B  R211      1
    quantity_47_B  R214      1
    quantity_47_B  R215      1
    quantity_47_B  R378      1
    quantity_47_B  clean_stock_b3  1
    quantity_47_A  R212      1
    quantity_47_A  R213      1
    quantity_47_A  R214      1
    quantity_47_A  R215      1
    quantity_47_A  R377      1
    quantity_47_A  clean_stock_b3  1
    quantity_48_A  R216      1
    quantity_48_A  R217      1
    quantity_48_A  R218      1
    quantity_48_A  R219      1
    quantity_48_A  R379      1
    quantity_49_B  R220      1
    quantity_49_B  R221      1
    quantity_49_B  R222      1
    quantity_49_B  R223      1
    quantity_49_B  R380      1
    quantity_50_A  R224      1
    quantity_50_A  R225      1
    quantity_50_A  R228      1
    quantity_50_A  R229      1
    quantity_50_A  R379      1
    quantity_50_B  R226      1
    quantity_50_B  R227      1
    quantity_50_B  R228      1
    quantity_50_B  R229      1
    quantity_50_B  R380      1
    quantity_51_B  R230      1
    quantity_51_B  R231      1
    quantity_51_B  R234      1
    quantity_51_B  R235      1
    quantity_51_B  R380      1
    quantity_51_A  R232      1
    quantity_51_A  R233      1
    quantity_51_A  R234      1
    quantity_51_A  R235      1
    quantity_51_A  R379      1
    quantity_53_A  R238      1
    quantity_53_A  R239      1
    quantity_53_A  R240      1
    quantity_53_A  R241      1
    quantity_53_A  R379      1
    quantity_54_B  R242      1
    quantity_54_B  R243      1
    quantity_54_B  R244      1
    quantity_54_B  R245      1
    quantity_54_B  R380      1
    quantity_55_A  R246      1
    quantity_55_A  R247      1
    quantity_55_A  R250      1
    quantity_55_A  R251      1
    quantity_55_A  R379      1
    quantity_55_B  R248      1
    quantity_55_B  R249      1
    quantity_55_B  R250      1
    quantity_55_B  R251      1
    quantity_55_B  R380      1
    quantity_56_B  R252      1
    quantity_56_B  R253      1
    quantity_56_B  R256      1
    quantity_56_B  R257      1
    quantity_56_B  R380      1
    quantity_56_A  R254      1
    quantity_56_A  R255      1
    quantity_56_A  R256      1
    quantity_56_A  R257      1
    quantity_56_A  R379      1
    quantity_58_A  R260      1
    quantity_58_A  R261      1
    quantity_58_A  R262      1
    quantity_58_A  R263      1
    quantity_58_A  R379      1
    quantity_59_B  R264      1
    quantity_59_B  R265      1
    quantity_59_B  R266      1
    quantity_59_B  R267      1
    quantity_59_B  R380      1
    quantity_60_A  R268      1
    quantity_60_A  R269      1
    quantity_60_A  R272      1
    quantity_60_A  R273      1
    quantity_60_A  R379      1
    quantity_60_B  R270      1
    quantity_60_B  R271      1
    quantity_60_B  R272      1
    quantity_60_B  R273      1
    quantity_60_B  R380      1
    quantity_61_B  R274      1
    quantity_61_B  R275      1
    quantity_61_B  R278      1
    quantity_61_B  R279      1
    quantity_61_B  R380      1
    quantity_61_A  R276      1
    quantity_61_A  R277      1
    quantity_61_A  R278      1
    quantity_61_A  R279      1
    quantity_61_A  R379      1
    quantity_63_A  R282      1
    quantity_63_A  R283      1
    quantity_63_A  R284      1
    quantity_63_A  R285      1
    quantity_63_A  R379      1
    quantity_64_B  R286      1
    quantity_64_B  R287      1
    quantity_64_B  R288      1
    quantity_64_B  R289      1
    quantity_64_B  R380      1
    quantity_65_A  R290      1
    quantity_65_A  R291      1
    quantity_65_A  R294      1
    quantity_65_A  R295      1
    quantity_65_A  R379      1
    quantity_65_B  R292      1
    quantity_65_B  R293      1
    quantity_65_B  R294      1
    quantity_65_B  R295      1
    quantity_65_B  R380      1
    quantity_66_B  R296      1
    quantity_66_B  R297      1
    quantity_66_B  R300      1
    quantity_66_B  R301      1
    quantity_66_B  R380      1
    quantity_66_A  R298      1
    quantity_66_A  R299      1
    quantity_66_A  R300      1
    quantity_66_A  R301      1
    quantity_66_A  R379      1
    quantity_68_A  R304      1
    quantity_68_A  R305      1
    quantity_68_A  R306      1
    quantity_68_A  R307      1
    quantity_68_A  R379      1
    quantity_69_B  R308      1
    quantity_69_B  R309      1
    quantity_69_B  R310      1
    quantity_69_B  R311      1
    quantity_69_B  R380      1
    quantity_70_A  R312      1
    quantity_70_A  R313      1
    quantity_70_A  R316      1
    quantity_70_A  R317      1
    quantity_70_A  R379      1
    quantity_70_B  R314      1
    quantity_70_B  R315      1
    quantity_70_B  R316      1
    quantity_70_B  R317      1
    quantity_70_B  R380      1
    quantity_71_B  R318      1
    quantity_71_B  R319      1
    quantity_71_B  R322      1
    quantity_71_B  R323      1
    quantity_71_B  R380      1
    quantity_71_A  R320      1
    quantity_71_A  R321      1
    quantity_71_A  R322      1
    quantity_71_A  R323      1
    quantity_71_A  R379      1
    supply_A_b1  R326      1
    supply_A_b1  R345      1
    supply_A_b1  R346      -1
    supply_A_b1  joint_supply_0_0  1
    supply_B_b1  R329      1
    supply_B_b1  R350      1
    supply_B_b1  R351      -1
    supply_B_b1  joint_supply_1_0  1
    supply_A_b2  R333      1
    supply_A_b2  R355      1
    supply_A_b2  R356      -1
    supply_A_b2  joint_supply_0_2  1
    supply_B_b2  R336      1
    supply_B_b2  R360      1
    supply_B_b2  R361      -1
    supply_B_b2  joint_supply_1_2  1
    supply_A_b3  R340      1
    supply_A_b3  R365      1
    supply_A_b3  R366      -1
    supply_A_b3  joint_supply_0_4  1
    supply_B_b3  R343      1
    supply_B_b3  R370      1
    supply_B_b3  R371      -1
    supply_B_b3  joint_supply_1_4  1
    delivery_A1  R346      1
    delivery_A1  R347      -1
    pickup_time_A1  R347      1
    pickup_time_A1  R348      -1
    e2_return_A1  R348      1
    e2_return_A1  GC0       1
    e2_return_A1  GC1       1
    e2_return_A1  GC2       1
    e2_return_A1  GC3       1
    e2_return_A1  GC4       1
    e2_return_A1  GC5       1
    cutoff_A1_b1  R349      1
    cutoff_A1_b1  R375      -1
    cutoff_A1_b1  joint_cutoff_A1_b1  1
    cutoff_A1_b2  R349      1
    cutoff_A1_b2  R377      -1
    cutoff_A1_b2  joint_cutoff_A1_b2  1
    cutoff_A1_b3  R349      1
    cutoff_A1_b3  R379      -1
    cutoff_A1_b3  joint_cutoff_A1_b3  1
    delivery_B1  R351      1
    delivery_B1  R352      -1
    pickup_time_B1  R352      1
    pickup_time_B1  R353      -1
    e2_return_B1  R353      1
    e2_return_B1  GC6       1
    e2_return_B1  GC7       1
    e2_return_B1  GC8       1
    e2_return_B1  GC9       1
    e2_return_B1  GC10      1
    e2_return_B1  GC11      1
    cutoff_B1_b1  R354      1
    cutoff_B1_b1  R376      -1
    cutoff_B1_b1  joint_cutoff_B1_b1  1
    cutoff_B1_b2  R354      1
    cutoff_B1_b2  R378      -1
    cutoff_B1_b2  joint_cutoff_B1_b2  1
    cutoff_B1_b3  R354      1
    cutoff_B1_b3  R380      -1
    cutoff_B1_b3  joint_cutoff_B1_b3  1
    delivery_A2  R356      1
    delivery_A2  R357      -1
    pickup_time_A2  R357      1
    pickup_time_A2  R358      -1
    e2_return_A2  R358      1
    e2_return_A2  GC12      1
    e2_return_A2  GC13      1
    e2_return_A2  GC14      1
    e2_return_A2  GC15      1
    e2_return_A2  GC16      1
    e2_return_A2  GC17      1
    cutoff_A2_b1  R359      1
    cutoff_A2_b1  R375      -1
    cutoff_A2_b1  joint_cutoff_A2_b1  1
    cutoff_A2_b2  R359      1
    cutoff_A2_b2  R377      -1
    cutoff_A2_b2  joint_cutoff_A2_b2  1
    cutoff_A2_b3  R359      1
    cutoff_A2_b3  R379      -1
    cutoff_A2_b3  joint_cutoff_A2_b3  1
    delivery_B2  R361      1
    delivery_B2  R362      -1
    pickup_time_B2  R362      1
    pickup_time_B2  R363      -1
    e2_return_B2  R363      1
    e2_return_B2  GC18      1
    e2_return_B2  GC19      1
    e2_return_B2  GC20      1
    e2_return_B2  GC21      1
    e2_return_B2  GC22      1
    e2_return_B2  GC23      1
    cutoff_B2_b1  R364      1
    cutoff_B2_b1  R376      -1
    cutoff_B2_b1  joint_cutoff_B2_b1  1
    cutoff_B2_b2  R364      1
    cutoff_B2_b2  R378      -1
    cutoff_B2_b2  joint_cutoff_B2_b2  1
    cutoff_B2_b3  R364      1
    cutoff_B2_b3  R380      -1
    cutoff_B2_b3  joint_cutoff_B2_b3  1
    delivery_A3  R366      1
    delivery_A3  R367      -1
    pickup_time_A3  R367      1
    pickup_time_A3  R368      -1
    e2_return_A3  R368      1
    e2_return_A3  GC24      1
    e2_return_A3  GC25      1
    e2_return_A3  GC26      1
    e2_return_A3  GC27      1
    e2_return_A3  GC28      1
    e2_return_A3  GC29      1
    cutoff_A3_b1  R369      1
    cutoff_A3_b1  R375      -1
    cutoff_A3_b1  joint_cutoff_A3_b1  1
    cutoff_A3_b2  R369      1
    cutoff_A3_b2  R377      -1
    cutoff_A3_b2  joint_cutoff_A3_b2  1
    cutoff_A3_b3  R369      1
    cutoff_A3_b3  R379      -1
    cutoff_A3_b3  joint_cutoff_A3_b3  1
    delivery_B3  R371      1
    delivery_B3  R372      -1
    pickup_time_B3  R372      1
    pickup_time_B3  R373      -1
    e2_return_B3  R373      1
    e2_return_B3  GC30      1
    e2_return_B3  GC31      1
    e2_return_B3  GC32      1
    e2_return_B3  GC33      1
    e2_return_B3  GC34      1
    e2_return_B3  GC35      1
    cutoff_B3_b1  R374      1
    cutoff_B3_b1  R376      -1
    cutoff_B3_b1  joint_cutoff_B3_b1  1
    cutoff_B3_b2  R374      1
    cutoff_B3_b2  R378      -1
    cutoff_B3_b2  joint_cutoff_B3_b2  1
    cutoff_B3_b3  R374      1
    cutoff_B3_b3  R380      -1
    cutoff_B3_b3  joint_cutoff_B3_b3  1
    joint_route_0_0_0  OBJ       2
    joint_route_0_0_0  joint_cover_0_1  1
    joint_route_0_0_0  joint_trip_limit_0  1
    joint_route_0_0_0  certified_E2_cost_0  2
    joint_route_0_0_0  joint_cutoff_A1_b1  -1
    joint_route_0_1_0  OBJ       2
    joint_route_0_1_0  joint_cover_0_1  1
    joint_route_0_1_0  joint_trip_limit_0  1
    joint_route_0_1_0  certified_E2_cost_0  2
    joint_route_0_1_0  joint_cutoff_A1_b2  -1
    joint_route_0_2_0  OBJ       2
    joint_route_0_2_0  joint_cover_0_1  1
    joint_route_0_2_0  joint_trip_limit_0  1
    joint_route_0_2_0  certified_E2_cost_0  2
    joint_route_0_2_0  joint_cutoff_A1_b3  -1
    joint_route_0_3_0  OBJ       2
    joint_route_0_3_0  joint_cover_0_1  1
    joint_route_0_3_0  joint_cover_0_3  1
    joint_route_0_3_0  joint_trip_limit_0  1
    joint_route_0_3_0  certified_E2_cost_0  2
    joint_route_0_3_0  joint_cutoff_A1_b2  -1
    joint_route_0_3_0  joint_cutoff_A2_b2  -1
    joint_route_0_4_0  OBJ       2
    joint_route_0_4_0  joint_cover_0_1  1
    joint_route_0_4_0  joint_cover_0_3  1
    joint_route_0_4_0  joint_trip_limit_0  1
    joint_route_0_4_0  certified_E2_cost_0  2
    joint_route_0_4_0  joint_cutoff_A1_b3  -1
    joint_route_0_4_0  joint_cutoff_A2_b3  -1
    joint_route_0_5_0  OBJ       2
    joint_route_0_5_0  joint_cover_0_1  1
    joint_route_0_5_0  joint_cover_0_3  1
    joint_route_0_5_0  joint_cover_0_5  1
    joint_route_0_5_0  joint_trip_limit_0  1
    joint_route_0_5_0  certified_E2_cost_0  2
    joint_route_0_5_0  joint_cutoff_A1_b3  -1
    joint_route_0_5_0  joint_cutoff_A2_b3  -1
    joint_route_0_5_0  joint_cutoff_A3_b3  -1
    joint_route_0_6_0  OBJ       2
    joint_route_0_6_0  joint_cover_0_1  1
    joint_route_0_6_0  joint_cover_0_5  1
    joint_route_0_6_0  joint_trip_limit_0  1
    joint_route_0_6_0  certified_E2_cost_0  2
    joint_route_0_6_0  joint_cutoff_A1_b3  -1
    joint_route_0_6_0  joint_cutoff_A3_b3  -1
    joint_route_0_7_0  OBJ       2
    joint_route_0_7_0  joint_cover_0_3  1
    joint_route_0_7_0  joint_trip_limit_0  1
    joint_route_0_7_0  certified_E2_cost_0  2
    joint_route_0_7_0  joint_cutoff_A2_b2  -1
    joint_route_0_8_0  OBJ       2
    joint_route_0_8_0  joint_cover_0_3  1
    joint_route_0_8_0  joint_trip_limit_0  1
    joint_route_0_8_0  certified_E2_cost_0  2
    joint_route_0_8_0  joint_cutoff_A2_b3  -1
    joint_route_0_9_0  OBJ       2
    joint_route_0_9_0  joint_cover_0_3  1
    joint_route_0_9_0  joint_cover_0_5  1
    joint_route_0_9_0  joint_trip_limit_0  1
    joint_route_0_9_0  certified_E2_cost_0  2
    joint_route_0_9_0  joint_cutoff_A2_b3  -1
    joint_route_0_9_0  joint_cutoff_A3_b3  -1
    joint_route_0_10_0  OBJ       2
    joint_route_0_10_0  joint_cover_0_5  1
    joint_route_0_10_0  joint_trip_limit_0  1
    joint_route_0_10_0  certified_E2_cost_0  2
    joint_route_0_10_0  joint_cutoff_A3_b3  -1
    joint_route_0_11_0  OBJ       2
    joint_route_0_11_0  joint_cover_0_0  1
    joint_route_0_11_0  joint_trip_limit_0  1
    joint_route_0_11_0  certified_E2_cost_0  2
    joint_route_0_11_0  joint_supply_0_0  -1440
    joint_route_0_12_0  OBJ       2
    joint_route_0_12_0  joint_cover_0_0  1
    joint_route_0_12_0  joint_cover_0_1  1
    joint_route_0_12_0  joint_trip_limit_0  1
    joint_route_0_12_0  certified_E2_cost_0  2
    joint_route_0_12_0  joint_cutoff_A1_b1  -1
    joint_route_0_12_0  joint_supply_0_0  -1380
    joint_route_0_13_0  OBJ       2
    joint_route_0_13_0  joint_cover_0_0  1
    joint_route_0_13_0  joint_cover_0_1  1
    joint_route_0_13_0  joint_trip_limit_0  1
    joint_route_0_13_0  certified_E2_cost_0  2
    joint_route_0_13_0  joint_cutoff_A1_b2  -1
    joint_route_0_13_0  joint_supply_0_0  -1440
    joint_route_0_14_0  OBJ       2
    joint_route_0_14_0  joint_cover_0_0  1
    joint_route_0_14_0  joint_cover_0_1  1
    joint_route_0_14_0  joint_trip_limit_0  1
    joint_route_0_14_0  certified_E2_cost_0  2
    joint_route_0_14_0  joint_cutoff_A1_b3  -1
    joint_route_0_14_0  joint_supply_0_0  -1440
    joint_route_0_15_0  OBJ       2
    joint_route_0_15_0  joint_cover_0_0  1
    joint_route_0_15_0  joint_cover_0_1  1
    joint_route_0_15_0  joint_cover_0_3  1
    joint_route_0_15_0  joint_trip_limit_0  1
    joint_route_0_15_0  certified_E2_cost_0  2
    joint_route_0_15_0  joint_cutoff_A1_b2  -1
    joint_route_0_15_0  joint_cutoff_A2_b2  -1
    joint_route_0_15_0  joint_supply_0_0  -1440
    joint_route_0_16_0  OBJ       2
    joint_route_0_16_0  joint_cover_0_0  1
    joint_route_0_16_0  joint_cover_0_1  1
    joint_route_0_16_0  joint_cover_0_3  1
    joint_route_0_16_0  joint_trip_limit_0  1
    joint_route_0_16_0  certified_E2_cost_0  2
    joint_route_0_16_0  joint_cutoff_A1_b3  -1
    joint_route_0_16_0  joint_cutoff_A2_b3  -1
    joint_route_0_16_0  joint_supply_0_0  -1440
    joint_route_0_17_0  OBJ       2
    joint_route_0_17_0  joint_cover_0_0  1
    joint_route_0_17_0  joint_cover_0_1  1
    joint_route_0_17_0  joint_cover_0_3  1
    joint_route_0_17_0  joint_cover_0_5  1
    joint_route_0_17_0  joint_trip_limit_0  1
    joint_route_0_17_0  certified_E2_cost_0  2
    joint_route_0_17_0  joint_cutoff_A1_b3  -1
    joint_route_0_17_0  joint_cutoff_A2_b3  -1
    joint_route_0_17_0  joint_cutoff_A3_b3  -1
    joint_route_0_17_0  joint_supply_0_0  -1440
    joint_route_0_18_0  OBJ       2
    joint_route_0_18_0  joint_cover_0_0  1
    joint_route_0_18_0  joint_cover_0_1  1
    joint_route_0_18_0  joint_cover_0_5  1
    joint_route_0_18_0  joint_trip_limit_0  1
    joint_route_0_18_0  certified_E2_cost_0  2
    joint_route_0_18_0  joint_cutoff_A1_b3  -1
    joint_route_0_18_0  joint_cutoff_A3_b3  -1
    joint_route_0_18_0  joint_supply_0_0  -1440
    joint_route_0_19_0  OBJ       2
    joint_route_0_19_0  joint_cover_0_0  1
    joint_route_0_19_0  joint_cover_0_3  1
    joint_route_0_19_0  joint_trip_limit_0  1
    joint_route_0_19_0  certified_E2_cost_0  2
    joint_route_0_19_0  joint_cutoff_A2_b2  -1
    joint_route_0_19_0  joint_supply_0_0  -1440
    joint_route_0_20_0  OBJ       2
    joint_route_0_20_0  joint_cover_0_0  1
    joint_route_0_20_0  joint_cover_0_3  1
    joint_route_0_20_0  joint_trip_limit_0  1
    joint_route_0_20_0  certified_E2_cost_0  2
    joint_route_0_20_0  joint_cutoff_A2_b3  -1
    joint_route_0_20_0  joint_supply_0_0  -1440
    joint_route_0_21_0  OBJ       2
    joint_route_0_21_0  joint_cover_0_0  1
    joint_route_0_21_0  joint_cover_0_3  1
    joint_route_0_21_0  joint_cover_0_5  1
    joint_route_0_21_0  joint_trip_limit_0  1
    joint_route_0_21_0  certified_E2_cost_0  2
    joint_route_0_21_0  joint_cutoff_A2_b3  -1
    joint_route_0_21_0  joint_cutoff_A3_b3  -1
    joint_route_0_21_0  joint_supply_0_0  -1440
    joint_route_0_22_0  OBJ       2
    joint_route_0_22_0  joint_cover_0_0  1
    joint_route_0_22_0  joint_cover_0_5  1
    joint_route_0_22_0  joint_trip_limit_0  1
    joint_route_0_22_0  certified_E2_cost_0  2
    joint_route_0_22_0  joint_cutoff_A3_b3  -1
    joint_route_0_22_0  joint_supply_0_0  -1440
    joint_route_0_23_0  OBJ       2
    joint_route_0_23_0  joint_cover_0_2  1
    joint_route_0_23_0  joint_trip_limit_0  1
    joint_route_0_23_0  certified_E2_cost_0  2
    joint_route_0_23_0  joint_supply_0_2  -5040
    joint_route_0_24_0  OBJ       2
    joint_route_0_24_0  joint_cover_0_2  1
    joint_route_0_24_0  joint_cover_0_3  1
    joint_route_0_24_0  joint_trip_limit_0  1
    joint_route_0_24_0  certified_E2_cost_0  2
    joint_route_0_24_0  joint_cutoff_A2_b2  -1
    joint_route_0_24_0  joint_supply_0_2  -4560
    joint_route_0_25_0  OBJ       2
    joint_route_0_25_0  joint_cover_0_2  1
    joint_route_0_25_0  joint_cover_0_3  1
    joint_route_0_25_0  joint_trip_limit_0  1
    joint_route_0_25_0  certified_E2_cost_0  2
    joint_route_0_25_0  joint_cutoff_A2_b3  -1
    joint_route_0_25_0  joint_supply_0_2  -4560
    joint_route_0_26_0  OBJ       2
    joint_route_0_26_0  joint_cover_0_2  1
    joint_route_0_26_0  joint_cover_0_3  1
    joint_route_0_26_0  joint_cover_0_5  1
    joint_route_0_26_0  joint_trip_limit_0  1
    joint_route_0_26_0  certified_E2_cost_0  2
    joint_route_0_26_0  joint_cutoff_A2_b3  -1
    joint_route_0_26_0  joint_cutoff_A3_b3  -1
    joint_route_0_26_0  joint_supply_0_2  -4560
    joint_route_0_27_0  OBJ       2
    joint_route_0_27_0  joint_cover_0_2  1
    joint_route_0_27_0  joint_cover_0_5  1
    joint_route_0_27_0  joint_trip_limit_0  1
    joint_route_0_27_0  certified_E2_cost_0  2
    joint_route_0_27_0  joint_cutoff_A3_b3  -1
    joint_route_0_27_0  joint_supply_0_2  -5040
    joint_route_0_28_0  OBJ       2
    joint_route_0_28_0  joint_cover_0_4  1
    joint_route_0_28_0  joint_trip_limit_0  1
    joint_route_0_28_0  certified_E2_cost_0  2
    joint_route_0_28_0  joint_supply_0_4  -8640
    joint_route_0_29_0  OBJ       2
    joint_route_0_29_0  joint_cover_0_4  1
    joint_route_0_29_0  joint_cover_0_5  1
    joint_route_0_29_0  joint_trip_limit_0  1
    joint_route_0_29_0  certified_E2_cost_0  2
    joint_route_0_29_0  joint_cutoff_A3_b3  -1
    joint_route_0_29_0  joint_supply_0_4  -8160
    joint_route_1_0_0  OBJ       2
    joint_route_1_0_0  joint_cover_1_1  1
    joint_route_1_0_0  joint_trip_limit_1  1
    joint_route_1_0_0  certified_E2_cost_1  2
    joint_route_1_0_0  joint_cutoff_B1_b1  -1
    joint_route_1_1_0  OBJ       2
    joint_route_1_1_0  joint_cover_1_1  1
    joint_route_1_1_0  joint_trip_limit_1  1
    joint_route_1_1_0  certified_E2_cost_1  2
    joint_route_1_1_0  joint_cutoff_B1_b2  -1
    joint_route_1_2_0  OBJ       2
    joint_route_1_2_0  joint_cover_1_1  1
    joint_route_1_2_0  joint_trip_limit_1  1
    joint_route_1_2_0  certified_E2_cost_1  2
    joint_route_1_2_0  joint_cutoff_B1_b3  -1
    joint_route_1_3_0  OBJ       2
    joint_route_1_3_0  joint_cover_1_1  1
    joint_route_1_3_0  joint_cover_1_3  1
    joint_route_1_3_0  joint_trip_limit_1  1
    joint_route_1_3_0  certified_E2_cost_1  2
    joint_route_1_3_0  joint_cutoff_B1_b2  -1
    joint_route_1_3_0  joint_cutoff_B2_b2  -1
    joint_route_1_4_0  OBJ       2
    joint_route_1_4_0  joint_cover_1_1  1
    joint_route_1_4_0  joint_cover_1_3  1
    joint_route_1_4_0  joint_trip_limit_1  1
    joint_route_1_4_0  certified_E2_cost_1  2
    joint_route_1_4_0  joint_cutoff_B1_b3  -1
    joint_route_1_4_0  joint_cutoff_B2_b3  -1
    joint_route_1_5_0  OBJ       2
    joint_route_1_5_0  joint_cover_1_1  1
    joint_route_1_5_0  joint_cover_1_3  1
    joint_route_1_5_0  joint_cover_1_5  1
    joint_route_1_5_0  joint_trip_limit_1  1
    joint_route_1_5_0  certified_E2_cost_1  2
    joint_route_1_5_0  joint_cutoff_B1_b3  -1
    joint_route_1_5_0  joint_cutoff_B2_b3  -1
    joint_route_1_5_0  joint_cutoff_B3_b3  -1
    joint_route_1_6_0  OBJ       2
    joint_route_1_6_0  joint_cover_1_1  1
    joint_route_1_6_0  joint_cover_1_5  1
    joint_route_1_6_0  joint_trip_limit_1  1
    joint_route_1_6_0  certified_E2_cost_1  2
    joint_route_1_6_0  joint_cutoff_B1_b3  -1
    joint_route_1_6_0  joint_cutoff_B3_b3  -1
    joint_route_1_7_0  OBJ       2
    joint_route_1_7_0  joint_cover_1_3  1
    joint_route_1_7_0  joint_trip_limit_1  1
    joint_route_1_7_0  certified_E2_cost_1  2
    joint_route_1_7_0  joint_cutoff_B2_b2  -1
    joint_route_1_8_0  OBJ       2
    joint_route_1_8_0  joint_cover_1_3  1
    joint_route_1_8_0  joint_trip_limit_1  1
    joint_route_1_8_0  certified_E2_cost_1  2
    joint_route_1_8_0  joint_cutoff_B2_b3  -1
    joint_route_1_9_0  OBJ       2
    joint_route_1_9_0  joint_cover_1_3  1
    joint_route_1_9_0  joint_cover_1_5  1
    joint_route_1_9_0  joint_trip_limit_1  1
    joint_route_1_9_0  certified_E2_cost_1  2
    joint_route_1_9_0  joint_cutoff_B2_b3  -1
    joint_route_1_9_0  joint_cutoff_B3_b3  -1
    joint_route_1_10_0  OBJ       2
    joint_route_1_10_0  joint_cover_1_5  1
    joint_route_1_10_0  joint_trip_limit_1  1
    joint_route_1_10_0  certified_E2_cost_1  2
    joint_route_1_10_0  joint_cutoff_B3_b3  -1
    joint_route_1_11_0  OBJ       2
    joint_route_1_11_0  joint_cover_1_0  1
    joint_route_1_11_0  joint_trip_limit_1  1
    joint_route_1_11_0  certified_E2_cost_1  2
    joint_route_1_11_0  joint_supply_1_0  -1440
    joint_route_1_12_0  OBJ       2
    joint_route_1_12_0  joint_cover_1_0  1
    joint_route_1_12_0  joint_cover_1_1  1
    joint_route_1_12_0  joint_trip_limit_1  1
    joint_route_1_12_0  certified_E2_cost_1  2
    joint_route_1_12_0  joint_cutoff_B1_b1  -1
    joint_route_1_12_0  joint_supply_1_0  -960
    joint_route_1_13_0  OBJ       2
    joint_route_1_13_0  joint_cover_1_0  1
    joint_route_1_13_0  joint_cover_1_1  1
    joint_route_1_13_0  joint_trip_limit_1  1
    joint_route_1_13_0  certified_E2_cost_1  2
    joint_route_1_13_0  joint_cutoff_B1_b2  -1
    joint_route_1_13_0  joint_supply_1_0  -960
    joint_route_1_14_0  OBJ       2
    joint_route_1_14_0  joint_cover_1_0  1
    joint_route_1_14_0  joint_cover_1_1  1
    joint_route_1_14_0  joint_trip_limit_1  1
    joint_route_1_14_0  certified_E2_cost_1  2
    joint_route_1_14_0  joint_cutoff_B1_b3  -1
    joint_route_1_14_0  joint_supply_1_0  -960
    joint_route_1_15_0  OBJ       2
    joint_route_1_15_0  joint_cover_1_0  1
    joint_route_1_15_0  joint_cover_1_1  1
    joint_route_1_15_0  joint_cover_1_3  1
    joint_route_1_15_0  joint_trip_limit_1  1
    joint_route_1_15_0  certified_E2_cost_1  2
    joint_route_1_15_0  joint_cutoff_B1_b2  -1
    joint_route_1_15_0  joint_cutoff_B2_b2  -1
    joint_route_1_15_0  joint_supply_1_0  -960
    joint_route_1_16_0  OBJ       2
    joint_route_1_16_0  joint_cover_1_0  1
    joint_route_1_16_0  joint_cover_1_1  1
    joint_route_1_16_0  joint_cover_1_3  1
    joint_route_1_16_0  joint_trip_limit_1  1
    joint_route_1_16_0  certified_E2_cost_1  2
    joint_route_1_16_0  joint_cutoff_B1_b3  -1
    joint_route_1_16_0  joint_cutoff_B2_b3  -1
    joint_route_1_16_0  joint_supply_1_0  -960
    joint_route_1_17_0  OBJ       2
    joint_route_1_17_0  joint_cover_1_0  1
    joint_route_1_17_0  joint_cover_1_1  1
    joint_route_1_17_0  joint_cover_1_3  1
    joint_route_1_17_0  joint_cover_1_5  1
    joint_route_1_17_0  joint_trip_limit_1  1
    joint_route_1_17_0  certified_E2_cost_1  2
    joint_route_1_17_0  joint_cutoff_B1_b3  -1
    joint_route_1_17_0  joint_cutoff_B2_b3  -1
    joint_route_1_17_0  joint_cutoff_B3_b3  -1
    joint_route_1_17_0  joint_supply_1_0  -960
    joint_route_1_18_0  OBJ       2
    joint_route_1_18_0  joint_cover_1_0  1
    joint_route_1_18_0  joint_cover_1_1  1
    joint_route_1_18_0  joint_cover_1_5  1
    joint_route_1_18_0  joint_trip_limit_1  1
    joint_route_1_18_0  certified_E2_cost_1  2
    joint_route_1_18_0  joint_cutoff_B1_b3  -1
    joint_route_1_18_0  joint_cutoff_B3_b3  -1
    joint_route_1_18_0  joint_supply_1_0  -960
    joint_route_1_19_0  OBJ       2
    joint_route_1_19_0  joint_cover_1_0  1
    joint_route_1_19_0  joint_cover_1_3  1
    joint_route_1_19_0  joint_trip_limit_1  1
    joint_route_1_19_0  certified_E2_cost_1  2
    joint_route_1_19_0  joint_cutoff_B2_b2  -1
    joint_route_1_19_0  joint_supply_1_0  -1440
    joint_route_1_20_0  OBJ       2
    joint_route_1_20_0  joint_cover_1_0  1
    joint_route_1_20_0  joint_cover_1_3  1
    joint_route_1_20_0  joint_trip_limit_1  1
    joint_route_1_20_0  certified_E2_cost_1  2
    joint_route_1_20_0  joint_cutoff_B2_b3  -1
    joint_route_1_20_0  joint_supply_1_0  -1440
    joint_route_1_21_0  OBJ       2
    joint_route_1_21_0  joint_cover_1_0  1
    joint_route_1_21_0  joint_cover_1_3  1
    joint_route_1_21_0  joint_cover_1_5  1
    joint_route_1_21_0  joint_trip_limit_1  1
    joint_route_1_21_0  certified_E2_cost_1  2
    joint_route_1_21_0  joint_cutoff_B2_b3  -1
    joint_route_1_21_0  joint_cutoff_B3_b3  -1
    joint_route_1_21_0  joint_supply_1_0  -1440
    joint_route_1_22_0  OBJ       2
    joint_route_1_22_0  joint_cover_1_0  1
    joint_route_1_22_0  joint_cover_1_5  1
    joint_route_1_22_0  joint_trip_limit_1  1
    joint_route_1_22_0  certified_E2_cost_1  2
    joint_route_1_22_0  joint_cutoff_B3_b3  -1
    joint_route_1_22_0  joint_supply_1_0  -1440
    joint_route_1_23_0  OBJ       2
    joint_route_1_23_0  joint_cover_1_2  1
    joint_route_1_23_0  joint_trip_limit_1  1
    joint_route_1_23_0  certified_E2_cost_1  2
    joint_route_1_23_0  joint_supply_1_2  -5040
    joint_route_1_24_0  OBJ       2
    joint_route_1_24_0  joint_cover_1_2  1
    joint_route_1_24_0  joint_cover_1_3  1
    joint_route_1_24_0  joint_trip_limit_1  1
    joint_route_1_24_0  certified_E2_cost_1  2
    joint_route_1_24_0  joint_cutoff_B2_b2  -1
    joint_route_1_24_0  joint_supply_1_2  -4560
    joint_route_1_25_0  OBJ       2
    joint_route_1_25_0  joint_cover_1_2  1
    joint_route_1_25_0  joint_cover_1_3  1
    joint_route_1_25_0  joint_trip_limit_1  1
    joint_route_1_25_0  certified_E2_cost_1  2
    joint_route_1_25_0  joint_cutoff_B2_b3  -1
    joint_route_1_25_0  joint_supply_1_2  -4560
    joint_route_1_26_0  OBJ       2
    joint_route_1_26_0  joint_cover_1_2  1
    joint_route_1_26_0  joint_cover_1_3  1
    joint_route_1_26_0  joint_cover_1_5  1
    joint_route_1_26_0  joint_trip_limit_1  1
    joint_route_1_26_0  certified_E2_cost_1  2
    joint_route_1_26_0  joint_cutoff_B2_b3  -1
    joint_route_1_26_0  joint_cutoff_B3_b3  -1
    joint_route_1_26_0  joint_supply_1_2  -4560
    joint_route_1_27_0  OBJ       2
    joint_route_1_27_0  joint_cover_1_2  1
    joint_route_1_27_0  joint_cover_1_5  1
    joint_route_1_27_0  joint_trip_limit_1  1
    joint_route_1_27_0  certified_E2_cost_1  2
    joint_route_1_27_0  joint_cutoff_B3_b3  -1
    joint_route_1_27_0  joint_supply_1_2  -5040
    joint_route_1_28_0  OBJ       2
    joint_route_1_28_0  joint_cover_1_4  1
    joint_route_1_28_0  joint_trip_limit_1  1
    joint_route_1_28_0  certified_E2_cost_1  2
    joint_route_1_28_0  joint_supply_1_4  -8640
    joint_route_1_29_0  OBJ       2
    joint_route_1_29_0  joint_cover_1_4  1
    joint_route_1_29_0  joint_cover_1_5  1
    joint_route_1_29_0  joint_trip_limit_1  1
    joint_route_1_29_0  certified_E2_cost_1  2
    joint_route_1_29_0  joint_cutoff_B3_b3  -1
    joint_route_1_29_0  joint_supply_1_4  -8160
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      R324      2
    RHS1      R325      1
    RHS1      R327      1
    RHS1      R328      1
    RHS1      R330      1
    RHS1      R331      2
    RHS1      R332      1
    RHS1      R334      1
    RHS1      R335      1
    RHS1      R337      1
    RHS1      R338      2
    RHS1      R339      1
    RHS1      R341      1
    RHS1      R342      1
    RHS1      R344      1
    RHS1      R345      1380
    RHS1      R346      120
    RHS1      R347      180
    RHS1      R348      180
    RHS1      R349      1
    RHS1      R350      1380
    RHS1      R351      120
    RHS1      R352      180
    RHS1      R353      180
    RHS1      R354      1
    RHS1      R355      4980
    RHS1      R356      120
    RHS1      R357      180
    RHS1      R358      180
    RHS1      R359      1
    RHS1      R360      4980
    RHS1      R361      120
    RHS1      R362      180
    RHS1      R363      180
    RHS1      R364      1
    RHS1      R365      8580
    RHS1      R366      120
    RHS1      R367      180
    RHS1      R368      180
    RHS1      R369      1
    RHS1      R370      8580
    RHS1      R371      120
    RHS1      R372      180
    RHS1      R373      180
    RHS1      R374      1
    RHS1      clean_stock_b1  -4
    RHS1      clean_stock_b2  -2
    RHS1      R384      1.3656852883806955e+01
    RHS1      R385      1.3656852883806955e+01
    RHS1      R386      1.3656852883806955e+01
    RHS1      certified_E1_cost  4.3313704167613906e+01
    RHS1      joint_cover_0_0  1
    RHS1      joint_cover_0_1  1
    RHS1      joint_cover_0_2  1
    RHS1      joint_cover_0_3  1
    RHS1      joint_cover_0_4  1
    RHS1      joint_cover_0_5  1
    RHS1      joint_trip_limit_0  6
    RHS1      certified_E2_cost_0  5.9999994
    RHS1      joint_supply_0_0  -60
    RHS1      joint_supply_0_2  -60
    RHS1      joint_supply_0_4  -60
    RHS1      joint_cover_1_0  1
    RHS1      joint_cover_1_1  1
    RHS1      joint_cover_1_2  1
    RHS1      joint_cover_1_3  1
    RHS1      joint_cover_1_4  1
    RHS1      joint_cover_1_5  1
    RHS1      joint_trip_limit_1  6
    RHS1      certified_E2_cost_1  5.9999994
    RHS1      joint_supply_1_0  -60
    RHS1      joint_supply_1_2  -60
    RHS1      joint_supply_1_4  -60
    RHS1      GC0       0
    RHS1      GC1       1800
    RHS1      GC2       1801
    RHS1      GC3       5400
    RHS1      GC4       5401
    RHS1      GC5       9000
    RHS1      GC6       0
    RHS1      GC7       1800
    RHS1      GC8       1801
    RHS1      GC9       5400
    RHS1      GC10      5401
    RHS1      GC11      9000
    RHS1      GC12      0
    RHS1      GC13      1800
    RHS1      GC14      1801
    RHS1      GC15      5400
    RHS1      GC16      5401
    RHS1      GC17      9000
    RHS1      GC18      0
    RHS1      GC19      1800
    RHS1      GC20      1801
    RHS1      GC21      5400
    RHS1      GC22      5401
    RHS1      GC23      9000
    RHS1      GC24      0
    RHS1      GC25      1800
    RHS1      GC26      1801
    RHS1      GC27      5400
    RHS1      GC28      5401
    RHS1      GC29      9000
    RHS1      GC30      0
    RHS1      GC31      1800
    RHS1      GC32      1801
    RHS1      GC33      5400
    RHS1      GC34      5401
    RHS1      GC35      9000
BOUNDS
 BV BND1      route[0]
 BV BND1      route[1]
 BV BND1      route[2]
 BV BND1      route[3]
 BV BND1      route[4]
 BV BND1      route[5]
 BV BND1      route[6]
 BV BND1      route[7]
 BV BND1      route[8]
 BV BND1      route[9]
 BV BND1      route[10]
 BV BND1      route[11]
 BV BND1      route[12]
 BV BND1      route[13]
 BV BND1      route[14]
 BV BND1      route[15]
 BV BND1      route[16]
 BV BND1      route[17]
 BV BND1      route[18]
 BV BND1      route[19]
 BV BND1      route[20]
 BV BND1      route[21]
 BV BND1      route[22]
 BV BND1      route[23]
 BV BND1      route[24]
 BV BND1      route[25]
 BV BND1      route[26]
 BV BND1      route[27]
 BV BND1      route[28]
 BV BND1      route[29]
 BV BND1      route[30]
 BV BND1      route[31]
 BV BND1      route[32]
 BV BND1      route[33]
 BV BND1      route[34]
 BV BND1      route[35]
 BV BND1      route[36]
 BV BND1      route[37]
 BV BND1      route[38]
 BV BND1      route[39]
 BV BND1      route[40]
 BV BND1      route[41]
 BV BND1      route[42]
 BV BND1      route[43]
 BV BND1      route[44]
 BV BND1      route[45]
 BV BND1      route[46]
 BV BND1      route[47]
 BV BND1      route[48]
 BV BND1      route[49]
 BV BND1      route[50]
 BV BND1      route[51]
 BV BND1      route[52]
 BV BND1      route[53]
 BV BND1      route[54]
 BV BND1      route[55]
 BV BND1      route[56]
 BV BND1      route[57]
 BV BND1      route[58]
 BV BND1      route[59]
 BV BND1      route[60]
 BV BND1      route[61]
 BV BND1      route[62]
 BV BND1      route[63]
 BV BND1      route[64]
 BV BND1      route[65]
 BV BND1      route[66]
 BV BND1      route[67]
 BV BND1      route[68]
 BV BND1      route[69]
 BV BND1      route[70]
 BV BND1      route[71]
 UP BND1      quantity_0_A  3
 UP BND1      quantity_1_B  3
 UP BND1      quantity_2_A  3
 UP BND1      quantity_2_B  3
 UP BND1      quantity_3_B  3
 UP BND1      quantity_3_A  3
 UP BND1      quantity_5_A  3
 UP BND1      quantity_6_B  3
 UP BND1      quantity_7_A  3
 UP BND1      quantity_7_B  3
 UP BND1      quantity_8_B  3
 UP BND1      quantity_8_A  3
 UP BND1      quantity_10_A  3
 UP BND1      quantity_11_B  3
 UP BND1      quantity_12_A  3
 UP BND1      quantity_12_B  3
 UP BND1      quantity_13_B  3
 UP BND1      quantity_13_A  3
 UP BND1      quantity_15_A  3
 UP BND1      quantity_16_B  3
 UP BND1      quantity_17_A  3
 UP BND1      quantity_17_B  3
 UP BND1      quantity_18_B  3
 UP BND1      quantity_18_A  3
 UP BND1      quantity_20_A  3
 UP BND1      quantity_21_B  3
 UP BND1      quantity_22_A  3
 UP BND1      quantity_22_B  3
 UP BND1      quantity_23_B  3
 UP BND1      quantity_23_A  3
 UP BND1      quantity_24_A  3
 UP BND1      quantity_25_B  3
 UP BND1      quantity_26_A  3
 UP BND1      quantity_26_B  3
 UP BND1      quantity_27_B  3
 UP BND1      quantity_27_A  3
 UP BND1      quantity_29_A  3
 UP BND1      quantity_30_B  3
 UP BND1      quantity_31_A  3
 UP BND1      quantity_31_B  3
 UP BND1      quantity_32_B  3
 UP BND1      quantity_32_A  3
 UP BND1      quantity_34_A  3
 UP BND1      quantity_35_B  3
 UP BND1      quantity_36_A  3
 UP BND1      quantity_36_B  3
 UP BND1      quantity_37_B  3
 UP BND1      quantity_37_A  3
 UP BND1      quantity_39_A  3
 UP BND1      quantity_40_B  3
 UP BND1      quantity_41_A  3
 UP BND1      quantity_41_B  3
 UP BND1      quantity_42_B  3
 UP BND1      quantity_42_A  3
 UP BND1      quantity_44_A  3
 UP BND1      quantity_45_B  3
 UP BND1      quantity_46_A  3
 UP BND1      quantity_46_B  3
 UP BND1      quantity_47_B  3
 UP BND1      quantity_47_A  3
 UP BND1      quantity_48_A  3
 UP BND1      quantity_49_B  3
 UP BND1      quantity_50_A  3
 UP BND1      quantity_50_B  3
 UP BND1      quantity_51_B  3
 UP BND1      quantity_51_A  3
 UP BND1      quantity_53_A  3
 UP BND1      quantity_54_B  3
 UP BND1      quantity_55_A  3
 UP BND1      quantity_55_B  3
 UP BND1      quantity_56_B  3
 UP BND1      quantity_56_A  3
 UP BND1      quantity_58_A  3
 UP BND1      quantity_59_B  3
 UP BND1      quantity_60_A  3
 UP BND1      quantity_60_B  3
 UP BND1      quantity_61_B  3
 UP BND1      quantity_61_A  3
 UP BND1      quantity_63_A  3
 UP BND1      quantity_64_B  3
 UP BND1      quantity_65_A  3
 UP BND1      quantity_65_B  3
 UP BND1      quantity_66_B  3
 UP BND1      quantity_66_A  3
 UP BND1      quantity_68_A  3
 UP BND1      quantity_69_B  3
 UP BND1      quantity_70_A  3
 UP BND1      quantity_70_B  3
 UP BND1      quantity_71_B  3
 UP BND1      quantity_71_A  3
 UP BND1      supply_A_b1  11400
 UP BND1      supply_B_b1  11400
 UP BND1      supply_A_b2  11400
 UP BND1      supply_B_b2  11400
 UP BND1      supply_A_b3  11400
 UP BND1      supply_B_b3  11400
 UP BND1      delivery_A1  1500
 LO BND1      pickup_time_A1  1320
 UP BND1      pickup_time_A1  2100
 UP BND1      e2_return_A1  9000
 BV BND1      cutoff_A1_b1
 BV BND1      cutoff_A1_b2
 BV BND1      cutoff_A1_b3
 UP BND1      delivery_B1  1500
 LO BND1      pickup_time_B1  900
 UP BND1      pickup_time_B1  1200
 UP BND1      e2_return_B1  9000
 BV BND1      cutoff_B1_b1
 BV BND1      cutoff_B1_b2
 BV BND1      cutoff_B1_b3
 LO BND1      delivery_A2  3600
 UP BND1      delivery_A2  5100
 LO BND1      pickup_time_A2  4500
 UP BND1      pickup_time_A2  4800
 UP BND1      e2_return_A2  9000
 BV BND1      cutoff_A2_b1
 BV BND1      cutoff_A2_b2
 BV BND1      cutoff_A2_b3
 LO BND1      delivery_B2  3600
 UP BND1      delivery_B2  5100
 LO BND1      pickup_time_B2  4500
 UP BND1      pickup_time_B2  4800
 UP BND1      e2_return_B2  9000
 BV BND1      cutoff_B2_b1
 BV BND1      cutoff_B2_b2
 BV BND1      cutoff_B2_b3
 LO BND1      delivery_A3  7200
 UP BND1      delivery_A3  8700
 LO BND1      pickup_time_A3  8100
 UP BND1      pickup_time_A3  8400
 UP BND1      e2_return_A3  9000
 BV BND1      cutoff_A3_b1
 BV BND1      cutoff_A3_b2
 BV BND1      cutoff_A3_b3
 LO BND1      delivery_B3  7200
 UP BND1      delivery_B3  8700
 LO BND1      pickup_time_B3  8100
 UP BND1      pickup_time_B3  8400
 UP BND1      e2_return_B3  9000
 BV BND1      cutoff_B3_b1
 BV BND1      cutoff_B3_b2
 BV BND1      cutoff_B3_b3
 BV BND1      joint_route_0_0_0
 BV BND1      joint_route_0_1_0
 BV BND1      joint_route_0_2_0
 BV BND1      joint_route_0_3_0
 BV BND1      joint_route_0_4_0
 BV BND1      joint_route_0_5_0
 BV BND1      joint_route_0_6_0
 BV BND1      joint_route_0_7_0
 BV BND1      joint_route_0_8_0
 BV BND1      joint_route_0_9_0
 BV BND1      joint_route_0_10_0
 BV BND1      joint_route_0_11_0
 BV BND1      joint_route_0_12_0
 BV BND1      joint_route_0_13_0
 BV BND1      joint_route_0_14_0
 BV BND1      joint_route_0_15_0
 BV BND1      joint_route_0_16_0
 BV BND1      joint_route_0_17_0
 BV BND1      joint_route_0_18_0
 BV BND1      joint_route_0_19_0
 BV BND1      joint_route_0_20_0
 BV BND1      joint_route_0_21_0
 BV BND1      joint_route_0_22_0
 BV BND1      joint_route_0_23_0
 BV BND1      joint_route_0_24_0
 BV BND1      joint_route_0_25_0
 BV BND1      joint_route_0_26_0
 BV BND1      joint_route_0_27_0
 BV BND1      joint_route_0_28_0
 BV BND1      joint_route_0_29_0
 BV BND1      joint_route_1_0_0
 BV BND1      joint_route_1_1_0
 BV BND1      joint_route_1_2_0
 BV BND1      joint_route_1_3_0
 BV BND1      joint_route_1_4_0
 BV BND1      joint_route_1_5_0
 BV BND1      joint_route_1_6_0
 BV BND1      joint_route_1_7_0
 BV BND1      joint_route_1_8_0
 BV BND1      joint_route_1_9_0
 BV BND1      joint_route_1_10_0
 BV BND1      joint_route_1_11_0
 BV BND1      joint_route_1_12_0
 BV BND1      joint_route_1_13_0
 BV BND1      joint_route_1_14_0
 BV BND1      joint_route_1_15_0
 BV BND1      joint_route_1_16_0
 BV BND1      joint_route_1_17_0
 BV BND1      joint_route_1_18_0
 BV BND1      joint_route_1_19_0
 BV BND1      joint_route_1_20_0
 BV BND1      joint_route_1_21_0
 BV BND1      joint_route_1_22_0
 BV BND1      joint_route_1_23_0
 BV BND1      joint_route_1_24_0
 BV BND1      joint_route_1_25_0
 BV BND1      joint_route_1_26_0
 BV BND1      joint_route_1_27_0
 BV BND1      joint_route_1_28_0
 BV BND1      joint_route_1_29_0
INDICATORS
 IF GC0       cutoff_A1_b1  1
 IF GC1       cutoff_A1_b1  1
 IF GC2       cutoff_A1_b2  1
 IF GC3       cutoff_A1_b2  1
 IF GC4       cutoff_A1_b3  1
 IF GC5       cutoff_A1_b3  1
 IF GC6       cutoff_B1_b1  1
 IF GC7       cutoff_B1_b1  1
 IF GC8       cutoff_B1_b2  1
 IF GC9       cutoff_B1_b2  1
 IF GC10      cutoff_B1_b3  1
 IF GC11      cutoff_B1_b3  1
 IF GC12      cutoff_A2_b1  1
 IF GC13      cutoff_A2_b1  1
 IF GC14      cutoff_A2_b2  1
 IF GC15      cutoff_A2_b2  1
 IF GC16      cutoff_A2_b3  1
 IF GC17      cutoff_A2_b3  1
 IF GC18      cutoff_B2_b1  1
 IF GC19      cutoff_B2_b1  1
 IF GC20      cutoff_B2_b2  1
 IF GC21      cutoff_B2_b2  1
 IF GC22      cutoff_B2_b3  1
 IF GC23      cutoff_B2_b3  1
 IF GC24      cutoff_A3_b1  1
 IF GC25      cutoff_A3_b1  1
 IF GC26      cutoff_A3_b2  1
 IF GC27      cutoff_A3_b2  1
 IF GC28      cutoff_A3_b3  1
 IF GC29      cutoff_A3_b3  1
 IF GC30      cutoff_B3_b1  1
 IF GC31      cutoff_B3_b1  1
 IF GC32      cutoff_B3_b2  1
 IF GC33      cutoff_B3_b2  1
 IF GC34      cutoff_B3_b3  1
 IF GC35      cutoff_B3_b3  1
ENDATA
