* Signature: 0x530e27e34630dd5
NAME M5_complete_E1_route_inventory_relaxation
ROWS
 N  OBJ
 G  R0      
 L  R1      
 L  R2      
 L  R3      
 L  R4      
 L  R5      
 G  R6      
 L  R7      
 L  R8      
 L  R9      
 G  R10     
 L  R11     
 L  R12     
 L  R13     
 G  R14     
 L  R15     
 G  R16     
 L  R17     
 L  R18     
 L  R19     
 G  R20     
 L  R21     
 G  R22     
 L  R23     
 L  R24     
 L  R25     
 L  R26     
 L  R27     
 G  R28     
 L  R29     
 L  R30     
 L  R31     
 G  R32     
 L  R33     
 L  R34     
 L  R35     
 G  R36     
 L  R37     
 G  R38     
 L  R39     
 L  R40     
 L  R41     
 L  R42     
 L  R43     
 G  R44     
 L  R45     
 L  R46     
 L  R47     
 G  R48     
 L  R49     
 L  R50     
 L  R51     
 G  R52     
 L  R53     
 G  R54     
 L  R55     
 L  R56     
 L  R57     
 L  R58     
 L  R59     
 G  R60     
 L  R61     
 L  R62     
 L  R63     
 G  R64     
 L  R65     
 L  R66     
 L  R67     
 G  R68     
 L  R69     
 G  R70     
 L  R71     
 L  R72     
 L  R73     
 G  R74     
 L  R75     
 G  R76     
 L  R77     
 L  R78     
 L  R79     
 G  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 G  R86     
 L  R87     
 L  R88     
 L  R89     
 G  R90     
 L  R91     
 L  R92     
 L  R93     
 G  R94     
 L  R95     
 G  R96     
 L  R97     
 L  R98     
 L  R99     
 G  R100    
 L  R101    
 G  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 G  R108    
 L  R109    
 L  R110    
 L  R111    
 G  R112    
 L  R113    
 L  R114    
 L  R115    
 G  R116    
 L  R117    
 G  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 G  R124    
 L  R125    
 L  R126    
 L  R127    
 G  R128    
 L  R129    
 L  R130    
 L  R131    
 G  R132    
 L  R133    
 G  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 G  R140    
 L  R141    
 L  R142    
 L  R143    
 G  R144    
 L  R145    
 L  R146    
 L  R147    
 G  R148    
 L  R149    
 G  R150    
 L  R151    
 L  R152    
 L  R153    
 G  R154    
 L  R155    
 G  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 E  R161    
 E  R162    
 L  R163    
 E  R164    
 E  R165    
 L  R166    
 L  R167    
 E  R168    
 E  R169    
 L  R170    
 E  R171    
 E  R172    
 L  R173    
 L  R174    
 G  R175    
 G  R176    
 G  R177    
 E  R178    
 L  R179    
 G  R180    
 G  R181    
 G  R182    
 E  R183    
 L  R184    
 G  R185    
 G  R186    
 G  R187    
 E  R188    
 L  R189    
 G  R190    
 G  R191    
 G  R192    
 E  R193    
 L  R194    
 G  R195    
 G  R196    
 G  R197    
 E  R198    
 L  R199    
 G  R200    
 G  R201    
 G  R202    
 E  R203    
 L  R204    
 G  R205    
 G  R206    
 G  R207    
 E  R208    
 E  R209    
 E  R210    
 E  R211    
 E  R212    
 G  clean_stock_b1
 G  clean_stock_b2
 G  R215    
 G  R216    
 G  certified_E1_cost
 E  joint_cutoff_C4_order_b1
 E  joint_cutoff_C4_order_b2
 E  joint_cutoff_C1_order_b1
 E  joint_cutoff_C1_order_b2
 E  joint_cutoff_C2_order_b1
 E  joint_cutoff_C2_order_b2
 E  joint_cutoff_C3_order_b1
 E  joint_cutoff_C3_order_b2
 E  joint_cutoff_C5_order_b1
 E  joint_cutoff_C5_order_b2
 E  joint_cutoff_C0_order_b1
 E  joint_cutoff_C0_order_b2
 E  joint_cutoff_C6_order_b1
 E  joint_cutoff_C6_order_b2
 E  joint_cover_0_0
 E  joint_cover_0_1
 E  joint_cover_0_2
 E  joint_cover_0_3
 E  joint_cover_0_4
 E  joint_cover_0_5
 L  joint_trip_limit_0
 G  certified_E2_cost_0
 E  joint_cover_1_0
 E  joint_cover_1_1
 E  joint_cover_1_2
 E  joint_cover_1_3
 E  joint_cover_1_4
 E  joint_cover_1_5
 E  joint_cover_1_6
 E  joint_cover_1_7
 L  joint_trip_limit_1
 G  certified_E2_cost_1
 G  GC0     
 L  GC1     
 G  GC2     
 L  GC3     
 G  GC4     
 L  GC5     
 G  GC6     
 L  GC7     
 G  GC8     
 L  GC9     
 G  GC10    
 L  GC11    
 G  GC12    
 L  GC13    
 G  GC14    
 L  GC15    
 G  GC16    
 L  GC17    
 G  GC18    
 L  GC19    
 G  GC20    
 L  GC21    
 G  GC22    
 L  GC23    
 G  GC24    
 L  GC25    
 G  GC26    
 L  GC27    
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    route[0]  OBJ       4.3863424398922618e+01
    route[0]  R0        -1
    route[0]  R1        -5
    route[0]  R2        -210.000001
    route[0]  R3        -14.000001
    route[0]  R160      1
    route[0]  R163      1
    route[0]  R215      4.3863424398922618e+01
    route[0]  certified_E1_cost  4.3863424398922618e+01
    route[1]  OBJ       4.3863424398922618e+01
    route[1]  R4        -210.000001
    route[1]  R5        -14.000001
    route[1]  R160      1
    route[1]  R161      1
    route[1]  R162      -29758
    route[1]  R215      4.3863424398922618e+01
    route[1]  certified_E1_cost  4.3863424398922618e+01
    route[2]  OBJ       4.3863424398922618e+01
    route[2]  R6        -1
    route[2]  R7        -5
    route[2]  R8        -210.000001
    route[2]  R9        -14.000001
    route[2]  R160      1
    route[2]  R161      1
    route[2]  R162      -29758
    route[2]  R163      1
    route[2]  R215      4.3863424398922618e+01
    route[2]  certified_E1_cost  4.3863424398922618e+01
    route[3]  OBJ       1.1474846913616832e+02
    route[3]  R10       -1
    route[3]  R11       -7
    route[3]  R12       -210.000001
    route[3]  R13       -14.000001
    route[3]  R160      1
    route[3]  R161      1
    route[3]  R162      -29758
    route[3]  R166      1
    route[3]  R215      1.1474846913616832e+02
    route[3]  certified_E1_cost  1.1474846913616832e+02
    route[4]  OBJ       1.1474846913616832e+02
    route[4]  R14       -1
    route[4]  R15       -5
    route[4]  R16       -1
    route[4]  R17       -7
    route[4]  R18       -210.000001
    route[4]  R19       -14.000001
    route[4]  R160      1
    route[4]  R161      1
    route[4]  R162      -29758
    route[4]  R163      1
    route[4]  R166      1
    route[4]  R215      1.1474846913616832e+02
    route[4]  certified_E1_cost  1.1474846913616832e+02
    route[5]  OBJ       1.1488454801718143e+02
    route[5]  R20       -1
    route[5]  R21       -7
    route[5]  R22       -1
    route[5]  R23       -5
    route[5]  R24       -210.000001
    route[5]  R25       -14.000001
    route[5]  R160      1
    route[5]  R161      1
    route[5]  R162      -29758
    route[5]  R163      1
    route[5]  R166      1
    route[5]  R215      1.1488454801718143e+02
    route[5]  certified_E1_cost  1.1488454801718143e+02
    route[6]  OBJ       1.1461239025515522e+02
    route[6]  R26       -210.000001
    route[6]  R27       -14.000001
    route[6]  R160      1
    route[6]  R164      1
    route[6]  R165      -30820
    route[6]  R215      1.1461239025515522e+02
    route[6]  certified_E1_cost  1.1461239025515522e+02
    route[7]  OBJ       1.1474846913616832e+02
    route[7]  R28       -1
    route[7]  R29       -5
    route[7]  R30       -210.000001
    route[7]  R31       -14.000001
    route[7]  R160      1
    route[7]  R163      1
    route[7]  R164      1
    route[7]  R165      -30820
    route[7]  R215      1.1474846913616832e+02
    route[7]  certified_E1_cost  1.1474846913616832e+02
    route[8]  OBJ       1.1461239025515522e+02
    route[8]  R32       -1
    route[8]  R33       -7
    route[8]  R34       -210.000001
    route[8]  R35       -14.000001
    route[8]  R160      1
    route[8]  R164      1
    route[8]  R165      -30820
    route[8]  R166      1
    route[8]  R215      1.1461239025515522e+02
    route[8]  certified_E1_cost  1.1461239025515522e+02
    route[9]  OBJ       1.1474846913616832e+02
    route[9]  R36       -1
    route[9]  R37       -7
    route[9]  R38       -1
    route[9]  R39       -5
    route[9]  R40       -210.000001
    route[9]  R41       -14.000001
    route[9]  R160      1
    route[9]  R163      1
    route[9]  R164      1
    route[9]  R165      -30820
    route[9]  R166      1
    route[9]  R215      1.1474846913616832e+02
    route[9]  certified_E1_cost  1.1474846913616832e+02
    route[10]  OBJ       1.1474846913616832e+02
    route[10]  R42       -210.000001
    route[10]  R43       -14.000001
    route[10]  R160      1
    route[10]  R161      1
    route[10]  R162      -29758
    route[10]  R164      1
    route[10]  R165      -31004
    route[10]  R215      1.1474846913616832e+02
    route[10]  certified_E1_cost  1.1474846913616832e+02
    route[11]  OBJ       1.1488454801718143e+02
    route[11]  R44       -1
    route[11]  R45       -5
    route[11]  R46       -210.000001
    route[11]  R47       -14.000001
    route[11]  R160      1
    route[11]  R161      1
    route[11]  R162      -29758
    route[11]  R163      1
    route[11]  R164      1
    route[11]  R165      -31004
    route[11]  R215      1.1488454801718143e+02
    route[11]  certified_E1_cost  1.1488454801718143e+02
    route[12]  OBJ       1.1474846913616832e+02
    route[12]  R48       -1
    route[12]  R49       -7
    route[12]  R50       -210.000001
    route[12]  R51       -14.000001
    route[12]  R160      1
    route[12]  R161      1
    route[12]  R162      -29758
    route[12]  R164      1
    route[12]  R165      -31004
    route[12]  R166      1
    route[12]  R215      1.1474846913616832e+02
    route[12]  certified_E1_cost  1.1474846913616832e+02
    route[13]  OBJ       1.1488454801718143e+02
    route[13]  R52       -1
    route[13]  R53       -7
    route[13]  R54       -1
    route[13]  R55       -5
    route[13]  R56       -210.000001
    route[13]  R57       -14.000001
    route[13]  R160      1
    route[13]  R161      1
    route[13]  R162      -29758
    route[13]  R163      1
    route[13]  R164      1
    route[13]  R165      -31004
    route[13]  R166      1
    route[13]  R215      1.1488454801718143e+02
    route[13]  certified_E1_cost  1.1488454801718143e+02
    route[14]  OBJ       1.1474846913616832e+02
    route[14]  R58       -210.000001
    route[14]  R59       -14.000001
    route[14]  R160      1
    route[14]  R161      1
    route[14]  R162      -32066
    route[14]  R164      1
    route[14]  R165      -30820
    route[14]  R215      1.1474846913616832e+02
    route[14]  certified_E1_cost  1.1474846913616832e+02
    route[15]  OBJ       1.1474846913616832e+02
    route[15]  R60       -1
    route[15]  R61       -5
    route[15]  R62       -210.000001
    route[15]  R63       -14.000001
    route[15]  R160      1
    route[15]  R161      1
    route[15]  R162      -32066
    route[15]  R163      1
    route[15]  R164      1
    route[15]  R165      -30820
    route[15]  R215      1.1474846913616832e+02
    route[15]  certified_E1_cost  1.1474846913616832e+02
    route[16]  OBJ       1.8563351387341402e+02
    route[16]  R64       -1
    route[16]  R65       -7
    route[16]  R66       -210.000001
    route[16]  R67       -14.000001
    route[16]  R160      1
    route[16]  R161      1
    route[16]  R162      -32066
    route[16]  R164      1
    route[16]  R165      -30820
    route[16]  R166      1
    route[16]  R215      1.8563351387341402e+02
    route[16]  certified_E1_cost  1.8563351387341402e+02
    route[17]  OBJ       1.8563351387341402e+02
    route[17]  R68       -1
    route[17]  R69       -5
    route[17]  R70       -1
    route[17]  R71       -7
    route[17]  R72       -210.000001
    route[17]  R73       -14.000001
    route[17]  R160      1
    route[17]  R161      1
    route[17]  R162      -32066
    route[17]  R163      1
    route[17]  R164      1
    route[17]  R165      -30820
    route[17]  R166      1
    route[17]  R215      1.8563351387341402e+02
    route[17]  certified_E1_cost  1.8563351387341402e+02
    route[18]  OBJ       1.8576959275442712e+02
    route[18]  R74       -1
    route[18]  R75       -7
    route[18]  R76       -1
    route[18]  R77       -5
    route[18]  R78       -210.000001
    route[18]  R79       -14.000001
    route[18]  R160      1
    route[18]  R161      1
    route[18]  R162      -32066
    route[18]  R163      1
    route[18]  R164      1
    route[18]  R165      -30820
    route[18]  R166      1
    route[18]  R215      1.8576959275442712e+02
    route[18]  certified_E1_cost  1.8576959275442712e+02
    route[19]  OBJ       4.3863424398922618e+01
    route[19]  R80       -1
    route[19]  R81       -5
    route[19]  R82       -210.000001
    route[19]  R83       -14.000001
    route[19]  R167      1
    route[19]  R170      1
    route[19]  R216      4.3863424398922618e+01
    route[19]  certified_E1_cost  4.3863424398922618e+01
    route[20]  OBJ       4.3863424398922618e+01
    route[20]  R84       -210.000001
    route[20]  R85       -14.000001
    route[20]  R167      1
    route[20]  R168      1
    route[20]  R169      -58558
    route[20]  R216      4.3863424398922618e+01
    route[20]  certified_E1_cost  4.3863424398922618e+01
    route[21]  OBJ       4.3863424398922618e+01
    route[21]  R86       -1
    route[21]  R87       -5
    route[21]  R88       -210.000001
    route[21]  R89       -14.000001
    route[21]  R167      1
    route[21]  R168      1
    route[21]  R169      -58558
    route[21]  R170      1
    route[21]  R216      4.3863424398922618e+01
    route[21]  certified_E1_cost  4.3863424398922618e+01
    route[22]  OBJ       1.1474846913616832e+02
    route[22]  R90       -1
    route[22]  R91       -7
    route[22]  R92       -210.000001
    route[22]  R93       -14.000001
    route[22]  R167      1
    route[22]  R168      1
    route[22]  R169      -58558
    route[22]  R173      1
    route[22]  R216      1.1474846913616832e+02
    route[22]  certified_E1_cost  1.1474846913616832e+02
    route[23]  OBJ       1.1474846913616832e+02
    route[23]  R94       -1
    route[23]  R95       -5
    route[23]  R96       -1
    route[23]  R97       -7
    route[23]  R98       -210.000001
    route[23]  R99       -14.000001
    route[23]  R167      1
    route[23]  R168      1
    route[23]  R169      -58558
    route[23]  R170      1
    route[23]  R173      1
    route[23]  R216      1.1474846913616832e+02
    route[23]  certified_E1_cost  1.1474846913616832e+02
    route[24]  OBJ       1.1488454801718143e+02
    route[24]  R100      -1
    route[24]  R101      -7
    route[24]  R102      -1
    route[24]  R103      -5
    route[24]  R104      -210.000001
    route[24]  R105      -14.000001
    route[24]  R167      1
    route[24]  R168      1
    route[24]  R169      -58558
    route[24]  R170      1
    route[24]  R173      1
    route[24]  R216      1.1488454801718143e+02
    route[24]  certified_E1_cost  1.1488454801718143e+02
    route[25]  OBJ       1.1461239025515522e+02
    route[25]  R106      -210.000001
    route[25]  R107      -14.000001
    route[25]  R167      1
    route[25]  R171      1
    route[25]  R172      -59620
    route[25]  R216      1.1461239025515522e+02
    route[25]  certified_E1_cost  1.1461239025515522e+02
    route[26]  OBJ       1.1474846913616832e+02
    route[26]  R108      -1
    route[26]  R109      -5
    route[26]  R110      -210.000001
    route[26]  R111      -14.000001
    route[26]  R167      1
    route[26]  R170      1
    route[26]  R171      1
    route[26]  R172      -59620
    route[26]  R216      1.1474846913616832e+02
    route[26]  certified_E1_cost  1.1474846913616832e+02
    route[27]  OBJ       1.1461239025515522e+02
    route[27]  R112      -1
    route[27]  R113      -7
    route[27]  R114      -210.000001
    route[27]  R115      -14.000001
    route[27]  R167      1
    route[27]  R171      1
    route[27]  R172      -59620
    route[27]  R173      1
    route[27]  R216      1.1461239025515522e+02
    route[27]  certified_E1_cost  1.1461239025515522e+02
    route[28]  OBJ       1.1474846913616832e+02
    route[28]  R116      -1
    route[28]  R117      -7
    route[28]  R118      -1
    route[28]  R119      -5
    route[28]  R120      -210.000001
    route[28]  R121      -14.000001
    route[28]  R167      1
    route[28]  R170      1
    route[28]  R171      1
    route[28]  R172      -59620
    route[28]  R173      1
    route[28]  R216      1.1474846913616832e+02
    route[28]  certified_E1_cost  1.1474846913616832e+02
    route[29]  OBJ       1.1474846913616832e+02
    route[29]  R122      -210.000001
    route[29]  R123      -14.000001
    route[29]  R167      1
    route[29]  R168      1
    route[29]  R169      -58558
    route[29]  R171      1
    route[29]  R172      -59804
    route[29]  R216      1.1474846913616832e+02
    route[29]  certified_E1_cost  1.1474846913616832e+02
    route[30]  OBJ       1.1488454801718143e+02
    route[30]  R124      -1
    route[30]  R125      -5
    route[30]  R126      -210.000001
    route[30]  R127      -14.000001
    route[30]  R167      1
    route[30]  R168      1
    route[30]  R169      -58558
    route[30]  R170      1
    route[30]  R171      1
    route[30]  R172      -59804
    route[30]  R216      1.1488454801718143e+02
    route[30]  certified_E1_cost  1.1488454801718143e+02
    route[31]  OBJ       1.1474846913616832e+02
    route[31]  R128      -1
    route[31]  R129      -7
    route[31]  R130      -210.000001
    route[31]  R131      -14.000001
    route[31]  R167      1
    route[31]  R168      1
    route[31]  R169      -58558
    route[31]  R171      1
    route[31]  R172      -59804
    route[31]  R173      1
    route[31]  R216      1.1474846913616832e+02
    route[31]  certified_E1_cost  1.1474846913616832e+02
    route[32]  OBJ       1.1488454801718143e+02
    route[32]  R132      -1
    route[32]  R133      -7
    route[32]  R134      -1
    route[32]  R135      -5
    route[32]  R136      -210.000001
    route[32]  R137      -14.000001
    route[32]  R167      1
    route[32]  R168      1
    route[32]  R169      -58558
    route[32]  R170      1
    route[32]  R171      1
    route[32]  R172      -59804
    route[32]  R173      1
    route[32]  R216      1.1488454801718143e+02
    route[32]  certified_E1_cost  1.1488454801718143e+02
    route[33]  OBJ       1.1474846913616832e+02
    route[33]  R138      -210.000001
    route[33]  R139      -14.000001
    route[33]  R167      1
    route[33]  R168      1
    route[33]  R169      -60866
    route[33]  R171      1
    route[33]  R172      -59620
    route[33]  R216      1.1474846913616832e+02
    route[33]  certified_E1_cost  1.1474846913616832e+02
    route[34]  OBJ       1.1474846913616832e+02
    route[34]  R140      -1
    route[34]  R141      -5
    route[34]  R142      -210.000001
    route[34]  R143      -14.000001
    route[34]  R167      1
    route[34]  R168      1
    route[34]  R169      -60866
    route[34]  R170      1
    route[34]  R171      1
    route[34]  R172      -59620
    route[34]  R216      1.1474846913616832e+02
    route[34]  certified_E1_cost  1.1474846913616832e+02
    route[35]  OBJ       1.8563351387341402e+02
    route[35]  R144      -1
    route[35]  R145      -7
    route[35]  R146      -210.000001
    route[35]  R147      -14.000001
    route[35]  R167      1
    route[35]  R168      1
    route[35]  R169      -60866
    route[35]  R171      1
    route[35]  R172      -59620
    route[35]  R173      1
    route[35]  R216      1.8563351387341402e+02
    route[35]  certified_E1_cost  1.8563351387341402e+02
    route[36]  OBJ       1.8563351387341402e+02
    route[36]  R148      -1
    route[36]  R149      -5
    route[36]  R150      -1
    route[36]  R151      -7
    route[36]  R152      -210.000001
    route[36]  R153      -14.000001
    route[36]  R167      1
    route[36]  R168      1
    route[36]  R169      -60866
    route[36]  R170      1
    route[36]  R171      1
    route[36]  R172      -59620
    route[36]  R173      1
    route[36]  R216      1.8563351387341402e+02
    route[36]  certified_E1_cost  1.8563351387341402e+02
    route[37]  OBJ       1.8576959275442712e+02
    route[37]  R154      -1
    route[37]  R155      -7
    route[37]  R156      -1
    route[37]  R157      -5
    route[37]  R158      -210.000001
    route[37]  R159      -14.000001
    route[37]  R167      1
    route[37]  R168      1
    route[37]  R169      -60866
    route[37]  R170      1
    route[37]  R171      1
    route[37]  R172      -59620
    route[37]  R173      1
    route[37]  R216      1.8576959275442712e+02
    route[37]  certified_E1_cost  1.8576959275442712e+02
    quantity_0_S0  R0        1
    quantity_0_S0  R1        1
    quantity_0_S0  R2        2
    quantity_0_S0  R3        1
    quantity_0_S0  R209      1
    quantity_0_S0  clean_stock_b2  1
    quantity_2_S0  R6        1
    quantity_2_S0  R7        1
    quantity_2_S0  R8        2
    quantity_2_S0  R9        1
    quantity_2_S0  R209      1
    quantity_2_S0  clean_stock_b2  1
    quantity_3_S1  R10       1
    quantity_3_S1  R11       1
    quantity_3_S1  R12       2
    quantity_3_S1  R13       1
    quantity_3_S1  R210      1
    quantity_4_S0  R14       1
    quantity_4_S0  R15       1
    quantity_4_S0  R18       2
    quantity_4_S0  R19       1
    quantity_4_S0  R209      1
    quantity_4_S1  R16       1
    quantity_4_S1  R17       1
    quantity_4_S1  R18       2
    quantity_4_S1  R19       1
    quantity_4_S1  R210      1
    quantity_5_S1  R20       1
    quantity_5_S1  R21       1
    quantity_5_S1  R24       2
    quantity_5_S1  R25       1
    quantity_5_S1  R210      1
    quantity_5_S0  R22       1
    quantity_5_S0  R23       1
    quantity_5_S0  R24       2
    quantity_5_S0  R25       1
    quantity_5_S0  R209      1
    quantity_7_S0  R28       1
    quantity_7_S0  R29       1
    quantity_7_S0  R30       2
    quantity_7_S0  R31       1
    quantity_7_S0  R209      1
    quantity_7_S0  clean_stock_b2  1
    quantity_8_S1  R32       1
    quantity_8_S1  R33       1
    quantity_8_S1  R34       2
    quantity_8_S1  R35       1
    quantity_8_S1  R210      1
    quantity_8_S1  clean_stock_b2  1
    quantity_9_S1  R36       1
    quantity_9_S1  R37       1
    quantity_9_S1  R40       2
    quantity_9_S1  R41       1
    quantity_9_S1  R210      1
    quantity_9_S1  clean_stock_b2  1
    quantity_9_S0  R38       1
    quantity_9_S0  R39       1
    quantity_9_S0  R40       2
    quantity_9_S0  R41       1
    quantity_9_S0  R209      1
    quantity_9_S0  clean_stock_b2  1
    quantity_11_S0  R44       1
    quantity_11_S0  R45       1
    quantity_11_S0  R46       2
    quantity_11_S0  R47       1
    quantity_11_S0  R209      1
    quantity_11_S0  clean_stock_b2  1
    quantity_12_S1  R48       1
    quantity_12_S1  R49       1
    quantity_12_S1  R50       2
    quantity_12_S1  R51       1
    quantity_12_S1  R210      1
    quantity_12_S1  clean_stock_b2  1
    quantity_13_S1  R52       1
    quantity_13_S1  R53       1
    quantity_13_S1  R56       2
    quantity_13_S1  R57       1
    quantity_13_S1  R210      1
    quantity_13_S1  clean_stock_b2  1
    quantity_13_S0  R54       1
    quantity_13_S0  R55       1
    quantity_13_S0  R56       2
    quantity_13_S0  R57       1
    quantity_13_S0  R209      1
    quantity_13_S0  clean_stock_b2  1
    quantity_15_S0  R60       1
    quantity_15_S0  R61       1
    quantity_15_S0  R62       2
    quantity_15_S0  R63       1
    quantity_15_S0  R209      1
    quantity_15_S0  clean_stock_b2  1
    quantity_16_S1  R64       1
    quantity_16_S1  R65       1
    quantity_16_S1  R66       2
    quantity_16_S1  R67       1
    quantity_16_S1  R210      1
    quantity_17_S0  R68       1
    quantity_17_S0  R69       1
    quantity_17_S0  R72       2
    quantity_17_S0  R73       1
    quantity_17_S0  R209      1
    quantity_17_S1  R70       1
    quantity_17_S1  R71       1
    quantity_17_S1  R72       2
    quantity_17_S1  R73       1
    quantity_17_S1  R210      1
    quantity_18_S1  R74       1
    quantity_18_S1  R75       1
    quantity_18_S1  R78       2
    quantity_18_S1  R79       1
    quantity_18_S1  R210      1
    quantity_18_S0  R76       1
    quantity_18_S0  R77       1
    quantity_18_S0  R78       2
    quantity_18_S0  R79       1
    quantity_18_S0  R209      1
    quantity_19_S0  R80       1
    quantity_19_S0  R81       1
    quantity_19_S0  R82       2
    quantity_19_S0  R83       1
    quantity_19_S0  R211      1
    quantity_21_S0  R86       1
    quantity_21_S0  R87       1
    quantity_21_S0  R88       2
    quantity_21_S0  R89       1
    quantity_21_S0  R211      1
    quantity_22_S1  R90       1
    quantity_22_S1  R91       1
    quantity_22_S1  R92       2
    quantity_22_S1  R93       1
    quantity_22_S1  R212      1
    quantity_23_S0  R94       1
    quantity_23_S0  R95       1
    quantity_23_S0  R98       2
    quantity_23_S0  R99       1
    quantity_23_S0  R211      1
    quantity_23_S1  R96       1
    quantity_23_S1  R97       1
    quantity_23_S1  R98       2
    quantity_23_S1  R99       1
    quantity_23_S1  R212      1
    quantity_24_S1  R100      1
    quantity_24_S1  R101      1
    quantity_24_S1  R104      2
    quantity_24_S1  R105      1
    quantity_24_S1  R212      1
    quantity_24_S0  R102      1
    quantity_24_S0  R103      1
    quantity_24_S0  R104      2
    quantity_24_S0  R105      1
    quantity_24_S0  R211      1
    quantity_26_S0  R108      1
    quantity_26_S0  R109      1
    quantity_26_S0  R110      2
    quantity_26_S0  R111      1
    quantity_26_S0  R211      1
    quantity_27_S1  R112      1
    quantity_27_S1  R113      1
    quantity_27_S1  R114      2
    quantity_27_S1  R115      1
    quantity_27_S1  R212      1
    quantity_28_S1  R116      1
    quantity_28_S1  R117      1
    quantity_28_S1  R120      2
    quantity_28_S1  R121      1
    quantity_28_S1  R212      1
    quantity_28_S0  R118      1
    quantity_28_S0  R119      1
    quantity_28_S0  R120      2
    quantity_28_S0  R121      1
    quantity_28_S0  R211      1
    quantity_30_S0  R124      1
    quantity_30_S0  R125      1
    quantity_30_S0  R126      2
    quantity_30_S0  R127      1
    quantity_30_S0  R211      1
    quantity_31_S1  R128      1
    quantity_31_S1  R129      1
    quantity_31_S1  R130      2
    quantity_31_S1  R131      1
    quantity_31_S1  R212      1
    quantity_32_S1  R132      1
    quantity_32_S1  R133      1
    quantity_32_S1  R136      2
    quantity_32_S1  R137      1
    quantity_32_S1  R212      1
    quantity_32_S0  R134      1
    quantity_32_S0  R135      1
    quantity_32_S0  R136      2
    quantity_32_S0  R137      1
    quantity_32_S0  R211      1
    quantity_34_S0  R140      1
    quantity_34_S0  R141      1
    quantity_34_S0  R142      2
    quantity_34_S0  R143      1
    quantity_34_S0  R211      1
    quantity_35_S1  R144      1
    quantity_35_S1  R145      1
    quantity_35_S1  R146      2
    quantity_35_S1  R147      1
    quantity_35_S1  R212      1
    quantity_36_S0  R148      1
    quantity_36_S0  R149      1
    quantity_36_S0  R152      2
    quantity_36_S0  R153      1
    quantity_36_S0  R211      1
    quantity_36_S1  R150      1
    quantity_36_S1  R151      1
    quantity_36_S1  R152      2
    quantity_36_S1  R153      1
    quantity_36_S1  R212      1
    quantity_37_S1  R154      1
    quantity_37_S1  R155      1
    quantity_37_S1  R158      2
    quantity_37_S1  R159      1
    quantity_37_S1  R212      1
    quantity_37_S0  R156      1
    quantity_37_S0  R157      1
    quantity_37_S0  R158      2
    quantity_37_S0  R159      1
    quantity_37_S0  R211      1
    supply_S0_b1  R162      1
    supply_S0_b1  R174      1
    supply_S0_b1  R175      -1
    supply_S0_b1  R179      1
    supply_S0_b1  R180      -1
    supply_S1_b1  R165      1
    supply_S1_b1  R189      1
    supply_S1_b1  R190      -1
    supply_S1_b1  R194      1
    supply_S1_b1  R195      -1
    supply_S1_b1  R199      1
    supply_S1_b1  R200      -1
    supply_S0_b2  R169      1
    supply_S0_b2  R184      1
    supply_S0_b2  R185      -1
    supply_S1_b2  R172      1
    supply_S1_b2  R204      1
    supply_S1_b2  R205      -1
    delivery_C4_order  R175      1
    delivery_C4_order  R176      -1
    pickup_time_C4_order  R176      1
    pickup_time_C4_order  R177      -1
    e2_return_C4_order  R177      1
    e2_return_C4_order  GC0       1
    e2_return_C4_order  GC1       1
    e2_return_C4_order  GC2       1
    e2_return_C4_order  GC3       1
    cutoff_C4_order_b1  R178      1
    cutoff_C4_order_b1  R209      -1
    cutoff_C4_order_b1  joint_cutoff_C4_order_b1  1
    cutoff_C4_order_b2  R178      1
    cutoff_C4_order_b2  R211      -1
    cutoff_C4_order_b2  joint_cutoff_C4_order_b2  1
    delivery_C1_order  R180      1
    delivery_C1_order  R181      -1
    pickup_time_C1_order  R181      1
    pickup_time_C1_order  R182      -1
    e2_return_C1_order  R182      1
    e2_return_C1_order  GC4       1
    e2_return_C1_order  GC5       1
    e2_return_C1_order  GC6       1
    e2_return_C1_order  GC7       1
    cutoff_C1_order_b1  R183      1
    cutoff_C1_order_b1  R209      -2
    cutoff_C1_order_b1  joint_cutoff_C1_order_b1  1
    cutoff_C1_order_b2  R183      1
    cutoff_C1_order_b2  R211      -2
    cutoff_C1_order_b2  joint_cutoff_C1_order_b2  1
    delivery_C2_order  R185      1
    delivery_C2_order  R186      -1
    pickup_time_C2_order  R186      1
    pickup_time_C2_order  R187      -1
    e2_return_C2_order  R187      1
    e2_return_C2_order  GC8       1
    e2_return_C2_order  GC9       1
    e2_return_C2_order  GC10      1
    e2_return_C2_order  GC11      1
    cutoff_C2_order_b1  R188      1
    cutoff_C2_order_b1  R209      -2
    cutoff_C2_order_b1  joint_cutoff_C2_order_b1  1
    cutoff_C2_order_b2  R188      1
    cutoff_C2_order_b2  R211      -2
    cutoff_C2_order_b2  joint_cutoff_C2_order_b2  1
    delivery_C3_order  R190      1
    delivery_C3_order  R191      -1
    pickup_time_C3_order  R191      1
    pickup_time_C3_order  R192      -1
    e2_return_C3_order  R192      1
    e2_return_C3_order  GC12      1
    e2_return_C3_order  GC13      1
    e2_return_C3_order  GC14      1
    e2_return_C3_order  GC15      1
    cutoff_C3_order_b1  R193      1
    cutoff_C3_order_b1  R210      -2
    cutoff_C3_order_b1  joint_cutoff_C3_order_b1  1
    cutoff_C3_order_b2  R193      1
    cutoff_C3_order_b2  R212      -2
    cutoff_C3_order_b2  joint_cutoff_C3_order_b2  1
    delivery_C5_order  R195      1
    delivery_C5_order  R196      -1
    pickup_time_C5_order  R196      1
    pickup_time_C5_order  R197      -1
    e2_return_C5_order  R197      1
    e2_return_C5_order  GC16      1
    e2_return_C5_order  GC17      1
    e2_return_C5_order  GC18      1
    e2_return_C5_order  GC19      1
    cutoff_C5_order_b1  R198      1
    cutoff_C5_order_b1  R210      -2
    cutoff_C5_order_b1  joint_cutoff_C5_order_b1  1
    cutoff_C5_order_b2  R198      1
    cutoff_C5_order_b2  R212      -2
    cutoff_C5_order_b2  joint_cutoff_C5_order_b2  1
    delivery_C0_order  R200      1
    delivery_C0_order  R201      -1
    pickup_time_C0_order  R201      1
    pickup_time_C0_order  R202      -1
    e2_return_C0_order  R202      1
    e2_return_C0_order  GC20      1
    e2_return_C0_order  GC21      1
    e2_return_C0_order  GC22      1
    e2_return_C0_order  GC23      1
    cutoff_C0_order_b1  R203      1
    cutoff_C0_order_b1  R210      -2
    cutoff_C0_order_b1  joint_cutoff_C0_order_b1  1
    cutoff_C0_order_b2  R203      1
    cutoff_C0_order_b2  R212      -2
    cutoff_C0_order_b2  joint_cutoff_C0_order_b2  1
    delivery_C6_order  R205      1
    delivery_C6_order  R206      -1
    pickup_time_C6_order  R206      1
    pickup_time_C6_order  R207      -1
    e2_return_C6_order  R207      1
    e2_return_C6_order  GC24      1
    e2_return_C6_order  GC25      1
    e2_return_C6_order  GC26      1
    e2_return_C6_order  GC27      1
    cutoff_C6_order_b1  R208      1
    cutoff_C6_order_b1  R210      -1
    cutoff_C6_order_b1  joint_cutoff_C6_order_b1  1
    cutoff_C6_order_b2  R208      1
    cutoff_C6_order_b2  R212      -1
    cutoff_C6_order_b2  joint_cutoff_C6_order_b2  1
    joint_route_0_0_0  OBJ       18
    joint_route_0_0_0  joint_cover_0_1  1
    joint_route_0_0_0  joint_trip_limit_0  1
    joint_route_0_0_0  certified_E2_cost_0  18
    joint_route_0_0_0  joint_cutoff_C4_order_b1  -1
    joint_route_0_0_1  OBJ       18
    joint_route_0_0_1  joint_cover_0_1  1
    joint_route_0_0_1  joint_trip_limit_0  1
    joint_route_0_0_1  certified_E2_cost_0  18
    joint_route_0_0_1  joint_cutoff_C4_order_b2  -1
    joint_route_0_1_0  OBJ       6.2495983409555066e+01
    joint_route_0_1_0  joint_cover_0_1  1
    joint_route_0_1_0  joint_cover_0_3  1
    joint_route_0_1_0  joint_trip_limit_0  1
    joint_route_0_1_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_1_0  joint_cutoff_C4_order_b1  -1
    joint_route_0_1_0  joint_cutoff_C1_order_b1  -1
    joint_route_0_1_1  OBJ       6.2495983409555066e+01
    joint_route_0_1_1  joint_cover_0_1  1
    joint_route_0_1_1  joint_cover_0_3  1
    joint_route_0_1_1  joint_trip_limit_0  1
    joint_route_0_1_1  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_1_1  joint_cutoff_C4_order_b2  -1
    joint_route_0_1_1  joint_cutoff_C1_order_b2  -1
    joint_route_0_2_0  OBJ       88.4104385228727
    joint_route_0_2_0  joint_cover_0_1  1
    joint_route_0_2_0  joint_cover_0_3  1
    joint_route_0_2_0  joint_cover_0_5  1
    joint_route_0_2_0  joint_trip_limit_0  1
    joint_route_0_2_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_2_0  joint_cutoff_C4_order_b2  -1
    joint_route_0_2_0  joint_cutoff_C1_order_b2  -1
    joint_route_0_2_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_3_0  OBJ       6.5481242412475325e+01
    joint_route_0_3_0  joint_cover_0_1  1
    joint_route_0_3_0  joint_cover_0_5  1
    joint_route_0_3_0  joint_trip_limit_0  1
    joint_route_0_3_0  certified_E2_cost_0  6.5481242412475325e+01
    joint_route_0_3_0  joint_cutoff_C4_order_b2  -1
    joint_route_0_3_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_4_0  OBJ       5.0635955604688654e+01
    joint_route_0_4_0  joint_cover_0_3  1
    joint_route_0_4_0  joint_trip_limit_0  1
    joint_route_0_4_0  certified_E2_cost_0  5.0635955604688654e+01
    joint_route_0_4_0  joint_cutoff_C1_order_b1  -1
    joint_route_0_4_1  OBJ       5.0635955604688654e+01
    joint_route_0_4_1  joint_cover_0_3  1
    joint_route_0_4_1  joint_trip_limit_0  1
    joint_route_0_4_1  certified_E2_cost_0  5.0635955604688654e+01
    joint_route_0_4_1  joint_cutoff_C1_order_b2  -1
    joint_route_0_5_0  OBJ       7.6550410718006276e+01
    joint_route_0_5_0  joint_cover_0_3  1
    joint_route_0_5_0  joint_cover_0_5  1
    joint_route_0_5_0  joint_trip_limit_0  1
    joint_route_0_5_0  certified_E2_cost_0  7.6550410718006276e+01
    joint_route_0_5_0  joint_cutoff_C1_order_b2  -1
    joint_route_0_5_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_6_0  OBJ       60.4648658313239
    joint_route_0_6_0  joint_cover_0_5  1
    joint_route_0_6_0  joint_trip_limit_0  1
    joint_route_0_6_0  certified_E2_cost_0  60.4648658313239
    joint_route_0_6_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_7_0  OBJ       18
    joint_route_0_7_0  joint_cover_0_0  1
    joint_route_0_7_0  joint_trip_limit_0  1
    joint_route_0_7_0  certified_E2_cost_0  18
    joint_route_0_8_0  OBJ       18
    joint_route_0_8_0  joint_cover_0_0  1
    joint_route_0_8_0  joint_cover_0_1  1
    joint_route_0_8_0  joint_trip_limit_0  1
    joint_route_0_8_0  certified_E2_cost_0  18
    joint_route_0_8_0  joint_cutoff_C4_order_b1  -1
    joint_route_0_8_1  OBJ       18
    joint_route_0_8_1  joint_cover_0_0  1
    joint_route_0_8_1  joint_cover_0_1  1
    joint_route_0_8_1  joint_trip_limit_0  1
    joint_route_0_8_1  certified_E2_cost_0  18
    joint_route_0_8_1  joint_cutoff_C4_order_b2  -1
    joint_route_0_9_0  OBJ       6.2495983409555066e+01
    joint_route_0_9_0  joint_cover_0_0  1
    joint_route_0_9_0  joint_cover_0_1  1
    joint_route_0_9_0  joint_cover_0_2  1
    joint_route_0_9_0  joint_trip_limit_0  1
    joint_route_0_9_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_9_0  joint_cutoff_C4_order_b1  -1
    joint_route_0_9_1  OBJ       6.2495983409555066e+01
    joint_route_0_9_1  joint_cover_0_0  1
    joint_route_0_9_1  joint_cover_0_1  1
    joint_route_0_9_1  joint_cover_0_2  1
    joint_route_0_9_1  joint_trip_limit_0  1
    joint_route_0_9_1  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_9_1  joint_cutoff_C4_order_b2  -1
    joint_route_0_10_0  OBJ       6.2495983409555066e+01
    joint_route_0_10_0  joint_cover_0_0  1
    joint_route_0_10_0  joint_cover_0_1  1
    joint_route_0_10_0  joint_cover_0_2  1
    joint_route_0_10_0  joint_cover_0_3  1
    joint_route_0_10_0  joint_trip_limit_0  1
    joint_route_0_10_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_10_0  joint_cutoff_C4_order_b1  -1
    joint_route_0_10_0  joint_cutoff_C1_order_b1  -1
    joint_route_0_10_1  OBJ       6.2495983409555066e+01
    joint_route_0_10_1  joint_cover_0_0  1
    joint_route_0_10_1  joint_cover_0_1  1
    joint_route_0_10_1  joint_cover_0_2  1
    joint_route_0_10_1  joint_cover_0_3  1
    joint_route_0_10_1  joint_trip_limit_0  1
    joint_route_0_10_1  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_10_1  joint_cutoff_C4_order_b2  -1
    joint_route_0_10_1  joint_cutoff_C1_order_b2  -1
    joint_route_0_11_0  OBJ       88.4104385228727
    joint_route_0_11_0  joint_cover_0_0  1
    joint_route_0_11_0  joint_cover_0_1  1
    joint_route_0_11_0  joint_cover_0_2  1
    joint_route_0_11_0  joint_cover_0_3  1
    joint_route_0_11_0  joint_cover_0_5  1
    joint_route_0_11_0  joint_trip_limit_0  1
    joint_route_0_11_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_11_0  joint_cutoff_C4_order_b2  -1
    joint_route_0_11_0  joint_cutoff_C1_order_b2  -1
    joint_route_0_11_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_12_0  OBJ       88.4104385228727
    joint_route_0_12_0  joint_cover_0_0  1
    joint_route_0_12_0  joint_cover_0_1  1
    joint_route_0_12_0  joint_cover_0_2  1
    joint_route_0_12_0  joint_cover_0_5  1
    joint_route_0_12_0  joint_trip_limit_0  1
    joint_route_0_12_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_12_0  joint_cutoff_C4_order_b2  -1
    joint_route_0_12_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_13_0  OBJ       6.2495983409555066e+01
    joint_route_0_13_0  joint_cover_0_0  1
    joint_route_0_13_0  joint_cover_0_1  1
    joint_route_0_13_0  joint_cover_0_3  1
    joint_route_0_13_0  joint_trip_limit_0  1
    joint_route_0_13_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_13_0  joint_cutoff_C4_order_b1  -1
    joint_route_0_13_0  joint_cutoff_C1_order_b1  -1
    joint_route_0_13_1  OBJ       6.2495983409555066e+01
    joint_route_0_13_1  joint_cover_0_0  1
    joint_route_0_13_1  joint_cover_0_1  1
    joint_route_0_13_1  joint_cover_0_3  1
    joint_route_0_13_1  joint_trip_limit_0  1
    joint_route_0_13_1  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_13_1  joint_cutoff_C4_order_b2  -1
    joint_route_0_13_1  joint_cutoff_C1_order_b2  -1
    joint_route_0_14_0  OBJ       88.4104385228727
    joint_route_0_14_0  joint_cover_0_0  1
    joint_route_0_14_0  joint_cover_0_1  1
    joint_route_0_14_0  joint_cover_0_3  1
    joint_route_0_14_0  joint_cover_0_5  1
    joint_route_0_14_0  joint_trip_limit_0  1
    joint_route_0_14_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_14_0  joint_cutoff_C4_order_b2  -1
    joint_route_0_14_0  joint_cutoff_C1_order_b2  -1
    joint_route_0_14_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_15_0  OBJ       6.5481242412475325e+01
    joint_route_0_15_0  joint_cover_0_0  1
    joint_route_0_15_0  joint_cover_0_1  1
    joint_route_0_15_0  joint_cover_0_5  1
    joint_route_0_15_0  joint_trip_limit_0  1
    joint_route_0_15_0  certified_E2_cost_0  6.5481242412475325e+01
    joint_route_0_15_0  joint_cutoff_C4_order_b2  -1
    joint_route_0_15_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_16_0  OBJ       6.2495983409555066e+01
    joint_route_0_16_0  joint_cover_0_0  1
    joint_route_0_16_0  joint_cover_0_2  1
    joint_route_0_16_0  joint_trip_limit_0  1
    joint_route_0_16_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_17_0  OBJ       6.2495983409555066e+01
    joint_route_0_17_0  joint_cover_0_0  1
    joint_route_0_17_0  joint_cover_0_2  1
    joint_route_0_17_0  joint_cover_0_3  1
    joint_route_0_17_0  joint_trip_limit_0  1
    joint_route_0_17_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_17_0  joint_cutoff_C1_order_b1  -1
    joint_route_0_17_1  OBJ       6.2495983409555066e+01
    joint_route_0_17_1  joint_cover_0_0  1
    joint_route_0_17_1  joint_cover_0_2  1
    joint_route_0_17_1  joint_cover_0_3  1
    joint_route_0_17_1  joint_trip_limit_0  1
    joint_route_0_17_1  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_17_1  joint_cutoff_C1_order_b2  -1
    joint_route_0_18_0  OBJ       88.4104385228727
    joint_route_0_18_0  joint_cover_0_0  1
    joint_route_0_18_0  joint_cover_0_2  1
    joint_route_0_18_0  joint_cover_0_3  1
    joint_route_0_18_0  joint_cover_0_5  1
    joint_route_0_18_0  joint_trip_limit_0  1
    joint_route_0_18_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_18_0  joint_cutoff_C1_order_b2  -1
    joint_route_0_18_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_19_0  OBJ       88.4104385228727
    joint_route_0_19_0  joint_cover_0_0  1
    joint_route_0_19_0  joint_cover_0_2  1
    joint_route_0_19_0  joint_cover_0_5  1
    joint_route_0_19_0  joint_trip_limit_0  1
    joint_route_0_19_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_19_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_20_0  OBJ       6.2495983409555066e+01
    joint_route_0_20_0  joint_cover_0_0  1
    joint_route_0_20_0  joint_cover_0_3  1
    joint_route_0_20_0  joint_trip_limit_0  1
    joint_route_0_20_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_20_0  joint_cutoff_C1_order_b1  -1
    joint_route_0_20_1  OBJ       6.2495983409555066e+01
    joint_route_0_20_1  joint_cover_0_0  1
    joint_route_0_20_1  joint_cover_0_3  1
    joint_route_0_20_1  joint_trip_limit_0  1
    joint_route_0_20_1  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_20_1  joint_cutoff_C1_order_b2  -1
    joint_route_0_21_0  OBJ       88.4104385228727
    joint_route_0_21_0  joint_cover_0_0  1
    joint_route_0_21_0  joint_cover_0_3  1
    joint_route_0_21_0  joint_cover_0_5  1
    joint_route_0_21_0  joint_trip_limit_0  1
    joint_route_0_21_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_21_0  joint_cutoff_C1_order_b2  -1
    joint_route_0_21_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_22_0  OBJ       6.5481242412475325e+01
    joint_route_0_22_0  joint_cover_0_0  1
    joint_route_0_22_0  joint_cover_0_5  1
    joint_route_0_22_0  joint_trip_limit_0  1
    joint_route_0_22_0  certified_E2_cost_0  6.5481242412475325e+01
    joint_route_0_22_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_23_0  OBJ       6.2495983409555066e+01
    joint_route_0_23_0  joint_cover_0_1  1
    joint_route_0_23_0  joint_cover_0_2  1
    joint_route_0_23_0  joint_trip_limit_0  1
    joint_route_0_23_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_23_0  joint_cutoff_C4_order_b1  -1
    joint_route_0_23_1  OBJ       6.2495983409555066e+01
    joint_route_0_23_1  joint_cover_0_1  1
    joint_route_0_23_1  joint_cover_0_2  1
    joint_route_0_23_1  joint_trip_limit_0  1
    joint_route_0_23_1  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_23_1  joint_cutoff_C4_order_b2  -1
    joint_route_0_24_0  OBJ       6.2495983409555066e+01
    joint_route_0_24_0  joint_cover_0_1  1
    joint_route_0_24_0  joint_cover_0_2  1
    joint_route_0_24_0  joint_cover_0_3  1
    joint_route_0_24_0  joint_trip_limit_0  1
    joint_route_0_24_0  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_24_0  joint_cutoff_C4_order_b1  -1
    joint_route_0_24_0  joint_cutoff_C1_order_b1  -1
    joint_route_0_24_1  OBJ       6.2495983409555066e+01
    joint_route_0_24_1  joint_cover_0_1  1
    joint_route_0_24_1  joint_cover_0_2  1
    joint_route_0_24_1  joint_cover_0_3  1
    joint_route_0_24_1  joint_trip_limit_0  1
    joint_route_0_24_1  certified_E2_cost_0  6.2495983409555066e+01
    joint_route_0_24_1  joint_cutoff_C4_order_b2  -1
    joint_route_0_24_1  joint_cutoff_C1_order_b2  -1
    joint_route_0_25_0  OBJ       88.4104385228727
    joint_route_0_25_0  joint_cover_0_1  1
    joint_route_0_25_0  joint_cover_0_2  1
    joint_route_0_25_0  joint_cover_0_3  1
    joint_route_0_25_0  joint_cover_0_5  1
    joint_route_0_25_0  joint_trip_limit_0  1
    joint_route_0_25_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_25_0  joint_cutoff_C4_order_b2  -1
    joint_route_0_25_0  joint_cutoff_C1_order_b2  -1
    joint_route_0_25_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_26_0  OBJ       88.4104385228727
    joint_route_0_26_0  joint_cover_0_1  1
    joint_route_0_26_0  joint_cover_0_2  1
    joint_route_0_26_0  joint_cover_0_5  1
    joint_route_0_26_0  joint_trip_limit_0  1
    joint_route_0_26_0  certified_E2_cost_0  88.4104385228727
    joint_route_0_26_0  joint_cutoff_C4_order_b2  -1
    joint_route_0_26_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_27_0  OBJ       5.0635955604688654e+01
    joint_route_0_27_0  joint_cover_0_2  1
    joint_route_0_27_0  joint_trip_limit_0  1
    joint_route_0_27_0  certified_E2_cost_0  5.0635955604688654e+01
    joint_route_0_28_0  OBJ       5.0635955604688654e+01
    joint_route_0_28_0  joint_cover_0_2  1
    joint_route_0_28_0  joint_cover_0_3  1
    joint_route_0_28_0  joint_trip_limit_0  1
    joint_route_0_28_0  certified_E2_cost_0  5.0635955604688654e+01
    joint_route_0_28_0  joint_cutoff_C1_order_b1  -1
    joint_route_0_28_1  OBJ       5.0635955604688654e+01
    joint_route_0_28_1  joint_cover_0_2  1
    joint_route_0_28_1  joint_cover_0_3  1
    joint_route_0_28_1  joint_trip_limit_0  1
    joint_route_0_28_1  certified_E2_cost_0  5.0635955604688654e+01
    joint_route_0_28_1  joint_cutoff_C1_order_b2  -1
    joint_route_0_29_0  OBJ       7.6550410718006276e+01
    joint_route_0_29_0  joint_cover_0_2  1
    joint_route_0_29_0  joint_cover_0_3  1
    joint_route_0_29_0  joint_cover_0_5  1
    joint_route_0_29_0  joint_trip_limit_0  1
    joint_route_0_29_0  certified_E2_cost_0  7.6550410718006276e+01
    joint_route_0_29_0  joint_cutoff_C1_order_b2  -1
    joint_route_0_29_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_30_0  OBJ       7.6550410718006276e+01
    joint_route_0_30_0  joint_cover_0_2  1
    joint_route_0_30_0  joint_cover_0_5  1
    joint_route_0_30_0  joint_trip_limit_0  1
    joint_route_0_30_0  certified_E2_cost_0  7.6550410718006276e+01
    joint_route_0_30_0  joint_cutoff_C2_order_b2  -1
    joint_route_0_31_0  OBJ       60.4648658313239
    joint_route_0_31_0  joint_cover_0_4  1
    joint_route_0_31_0  joint_trip_limit_0  1
    joint_route_0_31_0  certified_E2_cost_0  60.4648658313239
    joint_route_0_32_0  OBJ       60.4648658313239
    joint_route_0_32_0  joint_cover_0_4  1
    joint_route_0_32_0  joint_cover_0_5  1
    joint_route_0_32_0  joint_trip_limit_0  1
    joint_route_0_32_0  certified_E2_cost_0  60.4648658313239
    joint_route_0_32_0  joint_cutoff_C2_order_b2  -1
    joint_route_1_0_0  OBJ       5.8412327466040935e+01
    joint_route_1_0_0  joint_cover_1_1  1
    joint_route_1_0_0  joint_trip_limit_1  1
    joint_route_1_0_0  certified_E2_cost_1  5.8412327466040935e+01
    joint_route_1_0_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_0_1  OBJ       5.8412327466040935e+01
    joint_route_1_0_1  joint_cover_1_1  1
    joint_route_1_0_1  joint_trip_limit_1  1
    joint_route_1_0_1  certified_E2_cost_1  5.8412327466040935e+01
    joint_route_1_0_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_1_0  OBJ       7.5345137758310017e+01
    joint_route_1_1_0  joint_cover_1_1  1
    joint_route_1_1_0  joint_cover_1_3  1
    joint_route_1_1_0  joint_trip_limit_1  1
    joint_route_1_1_0  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_1_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_1_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_1_1  OBJ       7.5345137758310017e+01
    joint_route_1_1_1  joint_cover_1_1  1
    joint_route_1_1_1  joint_cover_1_3  1
    joint_route_1_1_1  joint_trip_limit_1  1
    joint_route_1_1_1  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_1_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_1_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_2_0  OBJ       79.3046301459725
    joint_route_1_2_0  joint_cover_1_1  1
    joint_route_1_2_0  joint_cover_1_3  1
    joint_route_1_2_0  joint_cover_1_5  1
    joint_route_1_2_0  joint_trip_limit_1  1
    joint_route_1_2_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_2_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_2_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_2_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_2_1  OBJ       79.3046301459725
    joint_route_1_2_1  joint_cover_1_1  1
    joint_route_1_2_1  joint_cover_1_3  1
    joint_route_1_2_1  joint_cover_1_5  1
    joint_route_1_2_1  joint_trip_limit_1  1
    joint_route_1_2_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_2_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_2_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_2_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_3_0  OBJ       8.3564344354906453e+01
    joint_route_1_3_0  joint_cover_1_1  1
    joint_route_1_3_0  joint_cover_1_3  1
    joint_route_1_3_0  joint_cover_1_7  1
    joint_route_1_3_0  joint_trip_limit_1  1
    joint_route_1_3_0  certified_E2_cost_1  8.3564344354906453e+01
    joint_route_1_3_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_3_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_3_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_4_0  OBJ       6.4854988239481685e+01
    joint_route_1_4_0  joint_cover_1_1  1
    joint_route_1_4_0  joint_cover_1_5  1
    joint_route_1_4_0  joint_trip_limit_1  1
    joint_route_1_4_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_4_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_4_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_4_1  OBJ       6.4854988239481685e+01
    joint_route_1_4_1  joint_cover_1_1  1
    joint_route_1_4_1  joint_cover_1_5  1
    joint_route_1_4_1  joint_trip_limit_1  1
    joint_route_1_4_1  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_4_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_4_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_5_0  OBJ       7.1043129143869621e+01
    joint_route_1_5_0  joint_cover_1_1  1
    joint_route_1_5_0  joint_cover_1_5  1
    joint_route_1_5_0  joint_cover_1_7  1
    joint_route_1_5_0  joint_trip_limit_1  1
    joint_route_1_5_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_5_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_5_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_5_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_6_0  OBJ       70.2062809929632
    joint_route_1_6_0  joint_cover_1_1  1
    joint_route_1_6_0  joint_cover_1_7  1
    joint_route_1_6_0  joint_trip_limit_1  1
    joint_route_1_6_0  certified_E2_cost_1  70.2062809929632
    joint_route_1_6_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_6_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_7_0  OBJ       7.5073297516493838e+01
    joint_route_1_7_0  joint_cover_1_3  1
    joint_route_1_7_0  joint_trip_limit_1  1
    joint_route_1_7_0  certified_E2_cost_1  7.5073297516493838e+01
    joint_route_1_7_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_7_1  OBJ       7.5073297516493838e+01
    joint_route_1_7_1  joint_cover_1_3  1
    joint_route_1_7_1  joint_trip_limit_1  1
    joint_route_1_7_1  certified_E2_cost_1  7.5073297516493838e+01
    joint_route_1_7_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_8_0  OBJ       7.9032789904156317e+01
    joint_route_1_8_0  joint_cover_1_3  1
    joint_route_1_8_0  joint_cover_1_5  1
    joint_route_1_8_0  joint_trip_limit_1  1
    joint_route_1_8_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_8_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_8_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_8_1  OBJ       7.9032789904156317e+01
    joint_route_1_8_1  joint_cover_1_3  1
    joint_route_1_8_1  joint_cover_1_5  1
    joint_route_1_8_1  joint_trip_limit_1  1
    joint_route_1_8_1  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_8_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_8_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_9_0  OBJ       8.5220930808544253e+01
    joint_route_1_9_0  joint_cover_1_3  1
    joint_route_1_9_0  joint_cover_1_5  1
    joint_route_1_9_0  joint_cover_1_7  1
    joint_route_1_9_0  joint_trip_limit_1  1
    joint_route_1_9_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_9_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_9_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_9_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_10_0  OBJ       8.3292504113090274e+01
    joint_route_1_10_0  joint_cover_1_3  1
    joint_route_1_10_0  joint_cover_1_7  1
    joint_route_1_10_0  joint_trip_limit_1  1
    joint_route_1_10_0  certified_E2_cost_1  8.3292504113090274e+01
    joint_route_1_10_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_10_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_11_0  OBJ       4.1231056256176608e+01
    joint_route_1_11_0  joint_cover_1_5  1
    joint_route_1_11_0  joint_trip_limit_1  1
    joint_route_1_11_0  certified_E2_cost_1  4.1231056256176608e+01
    joint_route_1_11_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_11_1  OBJ       4.1231056256176608e+01
    joint_route_1_11_1  joint_cover_1_5  1
    joint_route_1_11_1  joint_trip_limit_1  1
    joint_route_1_11_1  certified_E2_cost_1  4.1231056256176608e+01
    joint_route_1_11_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_12_0  OBJ       4.7419197160564543e+01
    joint_route_1_12_0  joint_cover_1_5  1
    joint_route_1_12_0  joint_cover_1_7  1
    joint_route_1_12_0  joint_trip_limit_1  1
    joint_route_1_12_0  certified_E2_cost_1  4.7419197160564543e+01
    joint_route_1_12_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_12_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_13_0  OBJ       4.5122056690713912e+01
    joint_route_1_13_0  joint_cover_1_7  1
    joint_route_1_13_0  joint_trip_limit_1  1
    joint_route_1_13_0  certified_E2_cost_1  4.5122056690713912e+01
    joint_route_1_13_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_14_0  OBJ       5.8412327466040935e+01
    joint_route_1_14_0  joint_cover_1_0  1
    joint_route_1_14_0  joint_trip_limit_1  1
    joint_route_1_14_0  certified_E2_cost_1  5.8412327466040935e+01
    joint_route_1_15_0  OBJ       5.8412327466040935e+01
    joint_route_1_15_0  joint_cover_1_0  1
    joint_route_1_15_0  joint_cover_1_1  1
    joint_route_1_15_0  joint_trip_limit_1  1
    joint_route_1_15_0  certified_E2_cost_1  5.8412327466040935e+01
    joint_route_1_15_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_15_1  OBJ       5.8412327466040935e+01
    joint_route_1_15_1  joint_cover_1_0  1
    joint_route_1_15_1  joint_cover_1_1  1
    joint_route_1_15_1  joint_trip_limit_1  1
    joint_route_1_15_1  certified_E2_cost_1  5.8412327466040935e+01
    joint_route_1_15_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_16_0  OBJ       7.5345137758310017e+01
    joint_route_1_16_0  joint_cover_1_0  1
    joint_route_1_16_0  joint_cover_1_1  1
    joint_route_1_16_0  joint_cover_1_3  1
    joint_route_1_16_0  joint_trip_limit_1  1
    joint_route_1_16_0  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_16_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_16_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_16_1  OBJ       7.5345137758310017e+01
    joint_route_1_16_1  joint_cover_1_0  1
    joint_route_1_16_1  joint_cover_1_1  1
    joint_route_1_16_1  joint_cover_1_3  1
    joint_route_1_16_1  joint_trip_limit_1  1
    joint_route_1_16_1  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_16_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_16_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_17_0  OBJ       79.3046301459725
    joint_route_1_17_0  joint_cover_1_0  1
    joint_route_1_17_0  joint_cover_1_1  1
    joint_route_1_17_0  joint_cover_1_3  1
    joint_route_1_17_0  joint_cover_1_4  1
    joint_route_1_17_0  joint_trip_limit_1  1
    joint_route_1_17_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_17_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_17_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_17_1  OBJ       79.3046301459725
    joint_route_1_17_1  joint_cover_1_0  1
    joint_route_1_17_1  joint_cover_1_1  1
    joint_route_1_17_1  joint_cover_1_3  1
    joint_route_1_17_1  joint_cover_1_4  1
    joint_route_1_17_1  joint_trip_limit_1  1
    joint_route_1_17_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_17_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_17_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_18_0  OBJ       79.3046301459725
    joint_route_1_18_0  joint_cover_1_0  1
    joint_route_1_18_0  joint_cover_1_1  1
    joint_route_1_18_0  joint_cover_1_3  1
    joint_route_1_18_0  joint_cover_1_4  1
    joint_route_1_18_0  joint_cover_1_5  1
    joint_route_1_18_0  joint_trip_limit_1  1
    joint_route_1_18_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_18_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_18_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_18_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_18_1  OBJ       79.3046301459725
    joint_route_1_18_1  joint_cover_1_0  1
    joint_route_1_18_1  joint_cover_1_1  1
    joint_route_1_18_1  joint_cover_1_3  1
    joint_route_1_18_1  joint_cover_1_4  1
    joint_route_1_18_1  joint_cover_1_5  1
    joint_route_1_18_1  joint_trip_limit_1  1
    joint_route_1_18_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_18_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_18_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_18_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_19_0  OBJ       8.5492771050360432e+01
    joint_route_1_19_0  joint_cover_1_0  1
    joint_route_1_19_0  joint_cover_1_1  1
    joint_route_1_19_0  joint_cover_1_3  1
    joint_route_1_19_0  joint_cover_1_4  1
    joint_route_1_19_0  joint_cover_1_7  1
    joint_route_1_19_0  joint_trip_limit_1  1
    joint_route_1_19_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_19_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_19_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_19_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_20_0  OBJ       79.3046301459725
    joint_route_1_20_0  joint_cover_1_0  1
    joint_route_1_20_0  joint_cover_1_1  1
    joint_route_1_20_0  joint_cover_1_3  1
    joint_route_1_20_0  joint_cover_1_5  1
    joint_route_1_20_0  joint_trip_limit_1  1
    joint_route_1_20_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_20_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_20_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_20_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_20_1  OBJ       79.3046301459725
    joint_route_1_20_1  joint_cover_1_0  1
    joint_route_1_20_1  joint_cover_1_1  1
    joint_route_1_20_1  joint_cover_1_3  1
    joint_route_1_20_1  joint_cover_1_5  1
    joint_route_1_20_1  joint_trip_limit_1  1
    joint_route_1_20_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_20_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_20_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_20_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_21_0  OBJ       8.3564344354906453e+01
    joint_route_1_21_0  joint_cover_1_0  1
    joint_route_1_21_0  joint_cover_1_1  1
    joint_route_1_21_0  joint_cover_1_3  1
    joint_route_1_21_0  joint_cover_1_7  1
    joint_route_1_21_0  joint_trip_limit_1  1
    joint_route_1_21_0  certified_E2_cost_1  8.3564344354906453e+01
    joint_route_1_21_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_21_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_21_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_22_0  OBJ       6.4854988239481685e+01
    joint_route_1_22_0  joint_cover_1_0  1
    joint_route_1_22_0  joint_cover_1_1  1
    joint_route_1_22_0  joint_cover_1_4  1
    joint_route_1_22_0  joint_trip_limit_1  1
    joint_route_1_22_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_22_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_22_1  OBJ       6.4854988239481685e+01
    joint_route_1_22_1  joint_cover_1_0  1
    joint_route_1_22_1  joint_cover_1_1  1
    joint_route_1_22_1  joint_cover_1_4  1
    joint_route_1_22_1  joint_trip_limit_1  1
    joint_route_1_22_1  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_22_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_23_0  OBJ       6.4854988239481685e+01
    joint_route_1_23_0  joint_cover_1_0  1
    joint_route_1_23_0  joint_cover_1_1  1
    joint_route_1_23_0  joint_cover_1_4  1
    joint_route_1_23_0  joint_cover_1_5  1
    joint_route_1_23_0  joint_trip_limit_1  1
    joint_route_1_23_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_23_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_23_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_23_1  OBJ       6.4854988239481685e+01
    joint_route_1_23_1  joint_cover_1_0  1
    joint_route_1_23_1  joint_cover_1_1  1
    joint_route_1_23_1  joint_cover_1_4  1
    joint_route_1_23_1  joint_cover_1_5  1
    joint_route_1_23_1  joint_trip_limit_1  1
    joint_route_1_23_1  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_23_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_23_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_24_0  OBJ       7.1043129143869621e+01
    joint_route_1_24_0  joint_cover_1_0  1
    joint_route_1_24_0  joint_cover_1_1  1
    joint_route_1_24_0  joint_cover_1_4  1
    joint_route_1_24_0  joint_cover_1_5  1
    joint_route_1_24_0  joint_cover_1_7  1
    joint_route_1_24_0  joint_trip_limit_1  1
    joint_route_1_24_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_24_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_24_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_24_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_25_0  OBJ       7.1043129143869621e+01
    joint_route_1_25_0  joint_cover_1_0  1
    joint_route_1_25_0  joint_cover_1_1  1
    joint_route_1_25_0  joint_cover_1_4  1
    joint_route_1_25_0  joint_cover_1_7  1
    joint_route_1_25_0  joint_trip_limit_1  1
    joint_route_1_25_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_25_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_25_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_26_0  OBJ       6.4854988239481685e+01
    joint_route_1_26_0  joint_cover_1_0  1
    joint_route_1_26_0  joint_cover_1_1  1
    joint_route_1_26_0  joint_cover_1_5  1
    joint_route_1_26_0  joint_trip_limit_1  1
    joint_route_1_26_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_26_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_26_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_26_1  OBJ       6.4854988239481685e+01
    joint_route_1_26_1  joint_cover_1_0  1
    joint_route_1_26_1  joint_cover_1_1  1
    joint_route_1_26_1  joint_cover_1_5  1
    joint_route_1_26_1  joint_trip_limit_1  1
    joint_route_1_26_1  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_26_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_26_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_27_0  OBJ       7.1043129143869621e+01
    joint_route_1_27_0  joint_cover_1_0  1
    joint_route_1_27_0  joint_cover_1_1  1
    joint_route_1_27_0  joint_cover_1_5  1
    joint_route_1_27_0  joint_cover_1_7  1
    joint_route_1_27_0  joint_trip_limit_1  1
    joint_route_1_27_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_27_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_27_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_27_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_28_0  OBJ       70.2062809929632
    joint_route_1_28_0  joint_cover_1_0  1
    joint_route_1_28_0  joint_cover_1_1  1
    joint_route_1_28_0  joint_cover_1_7  1
    joint_route_1_28_0  joint_trip_limit_1  1
    joint_route_1_28_0  certified_E2_cost_1  70.2062809929632
    joint_route_1_28_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_28_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_29_0  OBJ       7.5345137758310017e+01
    joint_route_1_29_0  joint_cover_1_0  1
    joint_route_1_29_0  joint_cover_1_2  1
    joint_route_1_29_0  joint_trip_limit_1  1
    joint_route_1_29_0  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_30_0  OBJ       7.5345137758310017e+01
    joint_route_1_30_0  joint_cover_1_2  1
    joint_route_1_30_0  joint_cover_1_0  1
    joint_route_1_30_0  joint_cover_1_1  1
    joint_route_1_30_0  joint_trip_limit_1  1
    joint_route_1_30_0  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_30_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_30_1  OBJ       7.5345137758310017e+01
    joint_route_1_30_1  joint_cover_1_2  1
    joint_route_1_30_1  joint_cover_1_0  1
    joint_route_1_30_1  joint_cover_1_1  1
    joint_route_1_30_1  joint_trip_limit_1  1
    joint_route_1_30_1  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_30_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_31_0  OBJ       7.5616978000126181e+01
    joint_route_1_31_0  joint_cover_1_0  1
    joint_route_1_31_0  joint_cover_1_2  1
    joint_route_1_31_0  joint_cover_1_3  1
    joint_route_1_31_0  joint_cover_1_1  1
    joint_route_1_31_0  joint_trip_limit_1  1
    joint_route_1_31_0  certified_E2_cost_1  7.5616978000126181e+01
    joint_route_1_31_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_31_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_31_1  OBJ       7.5616978000126181e+01
    joint_route_1_31_1  joint_cover_1_0  1
    joint_route_1_31_1  joint_cover_1_2  1
    joint_route_1_31_1  joint_cover_1_3  1
    joint_route_1_31_1  joint_cover_1_1  1
    joint_route_1_31_1  joint_trip_limit_1  1
    joint_route_1_31_1  certified_E2_cost_1  7.5616978000126181e+01
    joint_route_1_31_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_31_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_32_0  OBJ       8.2059638773566931e+01
    joint_route_1_32_0  joint_cover_1_0  1
    joint_route_1_32_0  joint_cover_1_2  1
    joint_route_1_32_0  joint_cover_1_3  1
    joint_route_1_32_0  joint_cover_1_1  1
    joint_route_1_32_0  joint_cover_1_4  1
    joint_route_1_32_0  joint_trip_limit_1  1
    joint_route_1_32_0  certified_E2_cost_1  8.2059638773566931e+01
    joint_route_1_32_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_32_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_32_1  OBJ       8.2059638773566931e+01
    joint_route_1_32_1  joint_cover_1_0  1
    joint_route_1_32_1  joint_cover_1_2  1
    joint_route_1_32_1  joint_cover_1_3  1
    joint_route_1_32_1  joint_cover_1_1  1
    joint_route_1_32_1  joint_cover_1_4  1
    joint_route_1_32_1  joint_trip_limit_1  1
    joint_route_1_32_1  certified_E2_cost_1  8.2059638773566931e+01
    joint_route_1_32_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_32_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_33_0  OBJ       8.2059638773566931e+01
    joint_route_1_33_0  joint_cover_1_0  1
    joint_route_1_33_0  joint_cover_1_2  1
    joint_route_1_33_0  joint_cover_1_3  1
    joint_route_1_33_0  joint_cover_1_1  1
    joint_route_1_33_0  joint_cover_1_4  1
    joint_route_1_33_0  joint_cover_1_5  1
    joint_route_1_33_0  joint_trip_limit_1  1
    joint_route_1_33_0  certified_E2_cost_1  8.2059638773566931e+01
    joint_route_1_33_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_33_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_33_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_33_1  OBJ       8.2059638773566931e+01
    joint_route_1_33_1  joint_cover_1_0  1
    joint_route_1_33_1  joint_cover_1_2  1
    joint_route_1_33_1  joint_cover_1_3  1
    joint_route_1_33_1  joint_cover_1_1  1
    joint_route_1_33_1  joint_cover_1_4  1
    joint_route_1_33_1  joint_cover_1_5  1
    joint_route_1_33_1  joint_trip_limit_1  1
    joint_route_1_33_1  certified_E2_cost_1  8.2059638773566931e+01
    joint_route_1_33_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_33_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_33_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_34_0  OBJ       8.8247779677954881e+01
    joint_route_1_34_0  joint_cover_1_0  1
    joint_route_1_34_0  joint_cover_1_2  1
    joint_route_1_34_0  joint_cover_1_3  1
    joint_route_1_34_0  joint_cover_1_1  1
    joint_route_1_34_0  joint_cover_1_4  1
    joint_route_1_34_0  joint_cover_1_7  1
    joint_route_1_34_0  joint_trip_limit_1  1
    joint_route_1_34_0  certified_E2_cost_1  8.8247779677954881e+01
    joint_route_1_34_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_34_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_34_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_35_0  OBJ       8.2059638773566931e+01
    joint_route_1_35_0  joint_cover_1_0  1
    joint_route_1_35_0  joint_cover_1_2  1
    joint_route_1_35_0  joint_cover_1_3  1
    joint_route_1_35_0  joint_cover_1_1  1
    joint_route_1_35_0  joint_cover_1_5  1
    joint_route_1_35_0  joint_trip_limit_1  1
    joint_route_1_35_0  certified_E2_cost_1  8.2059638773566931e+01
    joint_route_1_35_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_35_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_35_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_35_1  OBJ       8.2059638773566931e+01
    joint_route_1_35_1  joint_cover_1_0  1
    joint_route_1_35_1  joint_cover_1_2  1
    joint_route_1_35_1  joint_cover_1_3  1
    joint_route_1_35_1  joint_cover_1_1  1
    joint_route_1_35_1  joint_cover_1_5  1
    joint_route_1_35_1  joint_trip_limit_1  1
    joint_route_1_35_1  certified_E2_cost_1  8.2059638773566931e+01
    joint_route_1_35_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_35_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_35_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_36_0  OBJ       8.7410931527048461e+01
    joint_route_1_36_0  joint_cover_1_0  1
    joint_route_1_36_0  joint_cover_1_2  1
    joint_route_1_36_0  joint_cover_1_3  1
    joint_route_1_36_0  joint_cover_1_1  1
    joint_route_1_36_0  joint_cover_1_7  1
    joint_route_1_36_0  joint_trip_limit_1  1
    joint_route_1_36_0  certified_E2_cost_1  8.7410931527048461e+01
    joint_route_1_36_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_36_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_36_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_37_0  OBJ       8.1787798531750752e+01
    joint_route_1_37_0  joint_cover_1_2  1
    joint_route_1_37_0  joint_cover_1_0  1
    joint_route_1_37_0  joint_cover_1_1  1
    joint_route_1_37_0  joint_cover_1_4  1
    joint_route_1_37_0  joint_trip_limit_1  1
    joint_route_1_37_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_37_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_37_1  OBJ       8.1787798531750752e+01
    joint_route_1_37_1  joint_cover_1_2  1
    joint_route_1_37_1  joint_cover_1_0  1
    joint_route_1_37_1  joint_cover_1_1  1
    joint_route_1_37_1  joint_cover_1_4  1
    joint_route_1_37_1  joint_trip_limit_1  1
    joint_route_1_37_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_37_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_38_0  OBJ       8.1787798531750752e+01
    joint_route_1_38_0  joint_cover_1_2  1
    joint_route_1_38_0  joint_cover_1_0  1
    joint_route_1_38_0  joint_cover_1_1  1
    joint_route_1_38_0  joint_cover_1_4  1
    joint_route_1_38_0  joint_cover_1_5  1
    joint_route_1_38_0  joint_trip_limit_1  1
    joint_route_1_38_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_38_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_38_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_38_1  OBJ       8.1787798531750752e+01
    joint_route_1_38_1  joint_cover_1_2  1
    joint_route_1_38_1  joint_cover_1_0  1
    joint_route_1_38_1  joint_cover_1_1  1
    joint_route_1_38_1  joint_cover_1_4  1
    joint_route_1_38_1  joint_cover_1_5  1
    joint_route_1_38_1  joint_trip_limit_1  1
    joint_route_1_38_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_38_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_38_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_39_0  OBJ       87.9759394361387
    joint_route_1_39_0  joint_cover_1_2  1
    joint_route_1_39_0  joint_cover_1_0  1
    joint_route_1_39_0  joint_cover_1_1  1
    joint_route_1_39_0  joint_cover_1_4  1
    joint_route_1_39_0  joint_cover_1_5  1
    joint_route_1_39_0  joint_cover_1_7  1
    joint_route_1_39_0  joint_trip_limit_1  1
    joint_route_1_39_0  certified_E2_cost_1  87.9759394361387
    joint_route_1_39_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_39_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_39_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_40_0  OBJ       87.9759394361387
    joint_route_1_40_0  joint_cover_1_2  1
    joint_route_1_40_0  joint_cover_1_0  1
    joint_route_1_40_0  joint_cover_1_1  1
    joint_route_1_40_0  joint_cover_1_4  1
    joint_route_1_40_0  joint_cover_1_7  1
    joint_route_1_40_0  joint_trip_limit_1  1
    joint_route_1_40_0  certified_E2_cost_1  87.9759394361387
    joint_route_1_40_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_40_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_41_0  OBJ       8.1787798531750752e+01
    joint_route_1_41_0  joint_cover_1_2  1
    joint_route_1_41_0  joint_cover_1_0  1
    joint_route_1_41_0  joint_cover_1_1  1
    joint_route_1_41_0  joint_cover_1_5  1
    joint_route_1_41_0  joint_trip_limit_1  1
    joint_route_1_41_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_41_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_41_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_41_1  OBJ       8.1787798531750752e+01
    joint_route_1_41_1  joint_cover_1_2  1
    joint_route_1_41_1  joint_cover_1_0  1
    joint_route_1_41_1  joint_cover_1_1  1
    joint_route_1_41_1  joint_cover_1_5  1
    joint_route_1_41_1  joint_trip_limit_1  1
    joint_route_1_41_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_41_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_41_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_42_0  OBJ       87.9759394361387
    joint_route_1_42_0  joint_cover_1_2  1
    joint_route_1_42_0  joint_cover_1_0  1
    joint_route_1_42_0  joint_cover_1_1  1
    joint_route_1_42_0  joint_cover_1_5  1
    joint_route_1_42_0  joint_cover_1_7  1
    joint_route_1_42_0  joint_trip_limit_1  1
    joint_route_1_42_0  certified_E2_cost_1  87.9759394361387
    joint_route_1_42_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_42_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_42_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_43_0  OBJ       8.7139091285232269e+01
    joint_route_1_43_0  joint_cover_1_2  1
    joint_route_1_43_0  joint_cover_1_0  1
    joint_route_1_43_0  joint_cover_1_1  1
    joint_route_1_43_0  joint_cover_1_7  1
    joint_route_1_43_0  joint_trip_limit_1  1
    joint_route_1_43_0  certified_E2_cost_1  8.7139091285232269e+01
    joint_route_1_43_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_43_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_44_0  OBJ       7.5345137758310017e+01
    joint_route_1_44_0  joint_cover_1_0  1
    joint_route_1_44_0  joint_cover_1_2  1
    joint_route_1_44_0  joint_cover_1_3  1
    joint_route_1_44_0  joint_trip_limit_1  1
    joint_route_1_44_0  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_44_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_44_1  OBJ       7.5345137758310017e+01
    joint_route_1_44_1  joint_cover_1_0  1
    joint_route_1_44_1  joint_cover_1_2  1
    joint_route_1_44_1  joint_cover_1_3  1
    joint_route_1_44_1  joint_trip_limit_1  1
    joint_route_1_44_1  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_44_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_45_0  OBJ       79.3046301459725
    joint_route_1_45_0  joint_cover_1_0  1
    joint_route_1_45_0  joint_cover_1_2  1
    joint_route_1_45_0  joint_cover_1_3  1
    joint_route_1_45_0  joint_cover_1_4  1
    joint_route_1_45_0  joint_trip_limit_1  1
    joint_route_1_45_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_45_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_45_1  OBJ       79.3046301459725
    joint_route_1_45_1  joint_cover_1_0  1
    joint_route_1_45_1  joint_cover_1_2  1
    joint_route_1_45_1  joint_cover_1_3  1
    joint_route_1_45_1  joint_cover_1_4  1
    joint_route_1_45_1  joint_trip_limit_1  1
    joint_route_1_45_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_45_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_46_0  OBJ       79.3046301459725
    joint_route_1_46_0  joint_cover_1_0  1
    joint_route_1_46_0  joint_cover_1_2  1
    joint_route_1_46_0  joint_cover_1_3  1
    joint_route_1_46_0  joint_cover_1_4  1
    joint_route_1_46_0  joint_cover_1_5  1
    joint_route_1_46_0  joint_trip_limit_1  1
    joint_route_1_46_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_46_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_46_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_46_1  OBJ       79.3046301459725
    joint_route_1_46_1  joint_cover_1_0  1
    joint_route_1_46_1  joint_cover_1_2  1
    joint_route_1_46_1  joint_cover_1_3  1
    joint_route_1_46_1  joint_cover_1_4  1
    joint_route_1_46_1  joint_cover_1_5  1
    joint_route_1_46_1  joint_trip_limit_1  1
    joint_route_1_46_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_46_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_46_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_47_0  OBJ       8.5492771050360432e+01
    joint_route_1_47_0  joint_cover_1_0  1
    joint_route_1_47_0  joint_cover_1_2  1
    joint_route_1_47_0  joint_cover_1_3  1
    joint_route_1_47_0  joint_cover_1_4  1
    joint_route_1_47_0  joint_cover_1_5  1
    joint_route_1_47_0  joint_cover_1_7  1
    joint_route_1_47_0  joint_trip_limit_1  1
    joint_route_1_47_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_47_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_47_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_47_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_48_0  OBJ       8.5492771050360432e+01
    joint_route_1_48_0  joint_cover_1_0  1
    joint_route_1_48_0  joint_cover_1_2  1
    joint_route_1_48_0  joint_cover_1_3  1
    joint_route_1_48_0  joint_cover_1_4  1
    joint_route_1_48_0  joint_cover_1_7  1
    joint_route_1_48_0  joint_trip_limit_1  1
    joint_route_1_48_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_48_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_48_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_49_0  OBJ       79.3046301459725
    joint_route_1_49_0  joint_cover_1_0  1
    joint_route_1_49_0  joint_cover_1_2  1
    joint_route_1_49_0  joint_cover_1_3  1
    joint_route_1_49_0  joint_cover_1_5  1
    joint_route_1_49_0  joint_trip_limit_1  1
    joint_route_1_49_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_49_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_49_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_49_1  OBJ       79.3046301459725
    joint_route_1_49_1  joint_cover_1_0  1
    joint_route_1_49_1  joint_cover_1_2  1
    joint_route_1_49_1  joint_cover_1_3  1
    joint_route_1_49_1  joint_cover_1_5  1
    joint_route_1_49_1  joint_trip_limit_1  1
    joint_route_1_49_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_49_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_49_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_50_0  OBJ       8.5492771050360432e+01
    joint_route_1_50_0  joint_cover_1_0  1
    joint_route_1_50_0  joint_cover_1_2  1
    joint_route_1_50_0  joint_cover_1_3  1
    joint_route_1_50_0  joint_cover_1_5  1
    joint_route_1_50_0  joint_cover_1_7  1
    joint_route_1_50_0  joint_trip_limit_1  1
    joint_route_1_50_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_50_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_50_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_50_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_51_0  OBJ       8.3564344354906453e+01
    joint_route_1_51_0  joint_cover_1_0  1
    joint_route_1_51_0  joint_cover_1_2  1
    joint_route_1_51_0  joint_cover_1_3  1
    joint_route_1_51_0  joint_cover_1_7  1
    joint_route_1_51_0  joint_trip_limit_1  1
    joint_route_1_51_0  certified_E2_cost_1  8.3564344354906453e+01
    joint_route_1_51_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_51_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_52_0  OBJ       79.3046301459725
    joint_route_1_52_0  joint_cover_1_0  1
    joint_route_1_52_0  joint_cover_1_2  1
    joint_route_1_52_0  joint_cover_1_4  1
    joint_route_1_52_0  joint_trip_limit_1  1
    joint_route_1_52_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_53_0  OBJ       79.3046301459725
    joint_route_1_53_0  joint_cover_1_0  1
    joint_route_1_53_0  joint_cover_1_2  1
    joint_route_1_53_0  joint_cover_1_4  1
    joint_route_1_53_0  joint_cover_1_5  1
    joint_route_1_53_0  joint_trip_limit_1  1
    joint_route_1_53_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_53_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_53_1  OBJ       79.3046301459725
    joint_route_1_53_1  joint_cover_1_0  1
    joint_route_1_53_1  joint_cover_1_2  1
    joint_route_1_53_1  joint_cover_1_4  1
    joint_route_1_53_1  joint_cover_1_5  1
    joint_route_1_53_1  joint_trip_limit_1  1
    joint_route_1_53_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_53_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_54_0  OBJ       8.5492771050360432e+01
    joint_route_1_54_0  joint_cover_1_0  1
    joint_route_1_54_0  joint_cover_1_2  1
    joint_route_1_54_0  joint_cover_1_4  1
    joint_route_1_54_0  joint_cover_1_5  1
    joint_route_1_54_0  joint_cover_1_7  1
    joint_route_1_54_0  joint_trip_limit_1  1
    joint_route_1_54_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_54_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_54_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_55_0  OBJ       8.5492771050360432e+01
    joint_route_1_55_0  joint_cover_1_0  1
    joint_route_1_55_0  joint_cover_1_2  1
    joint_route_1_55_0  joint_cover_1_4  1
    joint_route_1_55_0  joint_cover_1_7  1
    joint_route_1_55_0  joint_trip_limit_1  1
    joint_route_1_55_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_55_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_56_0  OBJ       79.3046301459725
    joint_route_1_56_0  joint_cover_1_0  1
    joint_route_1_56_0  joint_cover_1_2  1
    joint_route_1_56_0  joint_cover_1_5  1
    joint_route_1_56_0  joint_trip_limit_1  1
    joint_route_1_56_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_56_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_56_1  OBJ       79.3046301459725
    joint_route_1_56_1  joint_cover_1_0  1
    joint_route_1_56_1  joint_cover_1_2  1
    joint_route_1_56_1  joint_cover_1_5  1
    joint_route_1_56_1  joint_trip_limit_1  1
    joint_route_1_56_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_56_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_57_0  OBJ       8.5492771050360432e+01
    joint_route_1_57_0  joint_cover_1_0  1
    joint_route_1_57_0  joint_cover_1_2  1
    joint_route_1_57_0  joint_cover_1_5  1
    joint_route_1_57_0  joint_cover_1_7  1
    joint_route_1_57_0  joint_trip_limit_1  1
    joint_route_1_57_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_57_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_57_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_58_0  OBJ       8.3564344354906453e+01
    joint_route_1_58_0  joint_cover_1_0  1
    joint_route_1_58_0  joint_cover_1_2  1
    joint_route_1_58_0  joint_cover_1_7  1
    joint_route_1_58_0  joint_trip_limit_1  1
    joint_route_1_58_0  certified_E2_cost_1  8.3564344354906453e+01
    joint_route_1_58_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_59_0  OBJ       7.5345137758310017e+01
    joint_route_1_59_0  joint_cover_1_0  1
    joint_route_1_59_0  joint_cover_1_3  1
    joint_route_1_59_0  joint_trip_limit_1  1
    joint_route_1_59_0  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_59_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_59_1  OBJ       7.5345137758310017e+01
    joint_route_1_59_1  joint_cover_1_0  1
    joint_route_1_59_1  joint_cover_1_3  1
    joint_route_1_59_1  joint_trip_limit_1  1
    joint_route_1_59_1  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_59_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_60_0  OBJ       79.3046301459725
    joint_route_1_60_0  joint_cover_1_0  1
    joint_route_1_60_0  joint_cover_1_3  1
    joint_route_1_60_0  joint_cover_1_4  1
    joint_route_1_60_0  joint_trip_limit_1  1
    joint_route_1_60_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_60_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_60_1  OBJ       79.3046301459725
    joint_route_1_60_1  joint_cover_1_0  1
    joint_route_1_60_1  joint_cover_1_3  1
    joint_route_1_60_1  joint_cover_1_4  1
    joint_route_1_60_1  joint_trip_limit_1  1
    joint_route_1_60_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_60_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_61_0  OBJ       79.3046301459725
    joint_route_1_61_0  joint_cover_1_0  1
    joint_route_1_61_0  joint_cover_1_3  1
    joint_route_1_61_0  joint_cover_1_4  1
    joint_route_1_61_0  joint_cover_1_5  1
    joint_route_1_61_0  joint_trip_limit_1  1
    joint_route_1_61_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_61_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_61_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_61_1  OBJ       79.3046301459725
    joint_route_1_61_1  joint_cover_1_0  1
    joint_route_1_61_1  joint_cover_1_3  1
    joint_route_1_61_1  joint_cover_1_4  1
    joint_route_1_61_1  joint_cover_1_5  1
    joint_route_1_61_1  joint_trip_limit_1  1
    joint_route_1_61_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_61_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_61_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_62_0  OBJ       8.5492771050360432e+01
    joint_route_1_62_0  joint_cover_1_0  1
    joint_route_1_62_0  joint_cover_1_3  1
    joint_route_1_62_0  joint_cover_1_4  1
    joint_route_1_62_0  joint_cover_1_5  1
    joint_route_1_62_0  joint_cover_1_7  1
    joint_route_1_62_0  joint_trip_limit_1  1
    joint_route_1_62_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_62_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_62_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_62_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_63_0  OBJ       8.5492771050360432e+01
    joint_route_1_63_0  joint_cover_1_0  1
    joint_route_1_63_0  joint_cover_1_3  1
    joint_route_1_63_0  joint_cover_1_4  1
    joint_route_1_63_0  joint_cover_1_7  1
    joint_route_1_63_0  joint_trip_limit_1  1
    joint_route_1_63_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_63_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_63_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_64_0  OBJ       79.3046301459725
    joint_route_1_64_0  joint_cover_1_0  1
    joint_route_1_64_0  joint_cover_1_3  1
    joint_route_1_64_0  joint_cover_1_5  1
    joint_route_1_64_0  joint_trip_limit_1  1
    joint_route_1_64_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_64_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_64_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_64_1  OBJ       79.3046301459725
    joint_route_1_64_1  joint_cover_1_0  1
    joint_route_1_64_1  joint_cover_1_3  1
    joint_route_1_64_1  joint_cover_1_5  1
    joint_route_1_64_1  joint_trip_limit_1  1
    joint_route_1_64_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_64_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_64_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_65_0  OBJ       8.5492771050360432e+01
    joint_route_1_65_0  joint_cover_1_0  1
    joint_route_1_65_0  joint_cover_1_3  1
    joint_route_1_65_0  joint_cover_1_5  1
    joint_route_1_65_0  joint_cover_1_7  1
    joint_route_1_65_0  joint_trip_limit_1  1
    joint_route_1_65_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_65_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_65_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_65_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_66_0  OBJ       8.3564344354906453e+01
    joint_route_1_66_0  joint_cover_1_0  1
    joint_route_1_66_0  joint_cover_1_3  1
    joint_route_1_66_0  joint_cover_1_7  1
    joint_route_1_66_0  joint_trip_limit_1  1
    joint_route_1_66_0  certified_E2_cost_1  8.3564344354906453e+01
    joint_route_1_66_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_66_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_67_0  OBJ       6.4854988239481685e+01
    joint_route_1_67_0  joint_cover_1_0  1
    joint_route_1_67_0  joint_cover_1_4  1
    joint_route_1_67_0  joint_trip_limit_1  1
    joint_route_1_67_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_68_0  OBJ       6.4854988239481685e+01
    joint_route_1_68_0  joint_cover_1_0  1
    joint_route_1_68_0  joint_cover_1_4  1
    joint_route_1_68_0  joint_cover_1_5  1
    joint_route_1_68_0  joint_trip_limit_1  1
    joint_route_1_68_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_68_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_68_1  OBJ       6.4854988239481685e+01
    joint_route_1_68_1  joint_cover_1_0  1
    joint_route_1_68_1  joint_cover_1_4  1
    joint_route_1_68_1  joint_cover_1_5  1
    joint_route_1_68_1  joint_trip_limit_1  1
    joint_route_1_68_1  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_68_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_69_0  OBJ       7.1043129143869621e+01
    joint_route_1_69_0  joint_cover_1_0  1
    joint_route_1_69_0  joint_cover_1_4  1
    joint_route_1_69_0  joint_cover_1_5  1
    joint_route_1_69_0  joint_cover_1_7  1
    joint_route_1_69_0  joint_trip_limit_1  1
    joint_route_1_69_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_69_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_69_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_70_0  OBJ       7.1043129143869621e+01
    joint_route_1_70_0  joint_cover_1_0  1
    joint_route_1_70_0  joint_cover_1_4  1
    joint_route_1_70_0  joint_cover_1_7  1
    joint_route_1_70_0  joint_trip_limit_1  1
    joint_route_1_70_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_70_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_71_0  OBJ       6.4854988239481685e+01
    joint_route_1_71_0  joint_cover_1_0  1
    joint_route_1_71_0  joint_cover_1_5  1
    joint_route_1_71_0  joint_trip_limit_1  1
    joint_route_1_71_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_71_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_71_1  OBJ       6.4854988239481685e+01
    joint_route_1_71_1  joint_cover_1_0  1
    joint_route_1_71_1  joint_cover_1_5  1
    joint_route_1_71_1  joint_trip_limit_1  1
    joint_route_1_71_1  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_71_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_72_0  OBJ       7.1043129143869621e+01
    joint_route_1_72_0  joint_cover_1_0  1
    joint_route_1_72_0  joint_cover_1_5  1
    joint_route_1_72_0  joint_cover_1_7  1
    joint_route_1_72_0  joint_trip_limit_1  1
    joint_route_1_72_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_72_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_72_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_73_0  OBJ       70.2062809929632
    joint_route_1_73_0  joint_cover_1_0  1
    joint_route_1_73_0  joint_cover_1_7  1
    joint_route_1_73_0  joint_trip_limit_1  1
    joint_route_1_73_0  certified_E2_cost_1  70.2062809929632
    joint_route_1_73_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_74_0  OBJ       79.3046301459725
    joint_route_1_74_0  joint_cover_1_1  1
    joint_route_1_74_0  joint_cover_1_3  1
    joint_route_1_74_0  joint_cover_1_4  1
    joint_route_1_74_0  joint_trip_limit_1  1
    joint_route_1_74_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_74_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_74_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_74_1  OBJ       79.3046301459725
    joint_route_1_74_1  joint_cover_1_1  1
    joint_route_1_74_1  joint_cover_1_3  1
    joint_route_1_74_1  joint_cover_1_4  1
    joint_route_1_74_1  joint_trip_limit_1  1
    joint_route_1_74_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_74_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_74_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_75_0  OBJ       79.3046301459725
    joint_route_1_75_0  joint_cover_1_1  1
    joint_route_1_75_0  joint_cover_1_3  1
    joint_route_1_75_0  joint_cover_1_4  1
    joint_route_1_75_0  joint_cover_1_5  1
    joint_route_1_75_0  joint_trip_limit_1  1
    joint_route_1_75_0  certified_E2_cost_1  79.3046301459725
    joint_route_1_75_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_75_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_75_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_75_1  OBJ       79.3046301459725
    joint_route_1_75_1  joint_cover_1_1  1
    joint_route_1_75_1  joint_cover_1_3  1
    joint_route_1_75_1  joint_cover_1_4  1
    joint_route_1_75_1  joint_cover_1_5  1
    joint_route_1_75_1  joint_trip_limit_1  1
    joint_route_1_75_1  certified_E2_cost_1  79.3046301459725
    joint_route_1_75_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_75_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_75_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_76_0  OBJ       8.5492771050360432e+01
    joint_route_1_76_0  joint_cover_1_1  1
    joint_route_1_76_0  joint_cover_1_3  1
    joint_route_1_76_0  joint_cover_1_4  1
    joint_route_1_76_0  joint_cover_1_7  1
    joint_route_1_76_0  joint_trip_limit_1  1
    joint_route_1_76_0  certified_E2_cost_1  8.5492771050360432e+01
    joint_route_1_76_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_76_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_76_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_77_0  OBJ       6.4854988239481685e+01
    joint_route_1_77_0  joint_cover_1_1  1
    joint_route_1_77_0  joint_cover_1_4  1
    joint_route_1_77_0  joint_trip_limit_1  1
    joint_route_1_77_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_77_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_77_1  OBJ       6.4854988239481685e+01
    joint_route_1_77_1  joint_cover_1_1  1
    joint_route_1_77_1  joint_cover_1_4  1
    joint_route_1_77_1  joint_trip_limit_1  1
    joint_route_1_77_1  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_77_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_78_0  OBJ       6.4854988239481685e+01
    joint_route_1_78_0  joint_cover_1_1  1
    joint_route_1_78_0  joint_cover_1_4  1
    joint_route_1_78_0  joint_cover_1_5  1
    joint_route_1_78_0  joint_trip_limit_1  1
    joint_route_1_78_0  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_78_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_78_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_78_1  OBJ       6.4854988239481685e+01
    joint_route_1_78_1  joint_cover_1_1  1
    joint_route_1_78_1  joint_cover_1_4  1
    joint_route_1_78_1  joint_cover_1_5  1
    joint_route_1_78_1  joint_trip_limit_1  1
    joint_route_1_78_1  certified_E2_cost_1  6.4854988239481685e+01
    joint_route_1_78_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_78_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_79_0  OBJ       7.1043129143869621e+01
    joint_route_1_79_0  joint_cover_1_1  1
    joint_route_1_79_0  joint_cover_1_4  1
    joint_route_1_79_0  joint_cover_1_5  1
    joint_route_1_79_0  joint_cover_1_7  1
    joint_route_1_79_0  joint_trip_limit_1  1
    joint_route_1_79_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_79_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_79_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_79_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_80_0  OBJ       7.1043129143869621e+01
    joint_route_1_80_0  joint_cover_1_1  1
    joint_route_1_80_0  joint_cover_1_4  1
    joint_route_1_80_0  joint_cover_1_7  1
    joint_route_1_80_0  joint_trip_limit_1  1
    joint_route_1_80_0  certified_E2_cost_1  7.1043129143869621e+01
    joint_route_1_80_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_80_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_81_0  OBJ       7.5073297516493838e+01
    joint_route_1_81_0  joint_cover_1_2  1
    joint_route_1_81_0  joint_trip_limit_1  1
    joint_route_1_81_0  certified_E2_cost_1  7.5073297516493838e+01
    joint_route_1_82_0  OBJ       7.5345137758310017e+01
    joint_route_1_82_0  joint_cover_1_2  1
    joint_route_1_82_0  joint_cover_1_1  1
    joint_route_1_82_0  joint_trip_limit_1  1
    joint_route_1_82_0  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_82_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_82_1  OBJ       7.5345137758310017e+01
    joint_route_1_82_1  joint_cover_1_2  1
    joint_route_1_82_1  joint_cover_1_1  1
    joint_route_1_82_1  joint_trip_limit_1  1
    joint_route_1_82_1  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_82_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_83_0  OBJ       7.5345137758310017e+01
    joint_route_1_83_0  joint_cover_1_2  1
    joint_route_1_83_0  joint_cover_1_3  1
    joint_route_1_83_0  joint_cover_1_1  1
    joint_route_1_83_0  joint_trip_limit_1  1
    joint_route_1_83_0  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_83_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_83_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_83_1  OBJ       7.5345137758310017e+01
    joint_route_1_83_1  joint_cover_1_2  1
    joint_route_1_83_1  joint_cover_1_3  1
    joint_route_1_83_1  joint_cover_1_1  1
    joint_route_1_83_1  joint_trip_limit_1  1
    joint_route_1_83_1  certified_E2_cost_1  7.5345137758310017e+01
    joint_route_1_83_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_83_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_84_0  OBJ       8.1787798531750752e+01
    joint_route_1_84_0  joint_cover_1_2  1
    joint_route_1_84_0  joint_cover_1_3  1
    joint_route_1_84_0  joint_cover_1_1  1
    joint_route_1_84_0  joint_cover_1_4  1
    joint_route_1_84_0  joint_trip_limit_1  1
    joint_route_1_84_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_84_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_84_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_84_1  OBJ       8.1787798531750752e+01
    joint_route_1_84_1  joint_cover_1_2  1
    joint_route_1_84_1  joint_cover_1_3  1
    joint_route_1_84_1  joint_cover_1_1  1
    joint_route_1_84_1  joint_cover_1_4  1
    joint_route_1_84_1  joint_trip_limit_1  1
    joint_route_1_84_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_84_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_84_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_85_0  OBJ       8.1787798531750752e+01
    joint_route_1_85_0  joint_cover_1_2  1
    joint_route_1_85_0  joint_cover_1_3  1
    joint_route_1_85_0  joint_cover_1_1  1
    joint_route_1_85_0  joint_cover_1_4  1
    joint_route_1_85_0  joint_cover_1_5  1
    joint_route_1_85_0  joint_trip_limit_1  1
    joint_route_1_85_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_85_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_85_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_85_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_85_1  OBJ       8.1787798531750752e+01
    joint_route_1_85_1  joint_cover_1_2  1
    joint_route_1_85_1  joint_cover_1_3  1
    joint_route_1_85_1  joint_cover_1_1  1
    joint_route_1_85_1  joint_cover_1_4  1
    joint_route_1_85_1  joint_cover_1_5  1
    joint_route_1_85_1  joint_trip_limit_1  1
    joint_route_1_85_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_85_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_85_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_85_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_86_0  OBJ       87.9759394361387
    joint_route_1_86_0  joint_cover_1_2  1
    joint_route_1_86_0  joint_cover_1_3  1
    joint_route_1_86_0  joint_cover_1_1  1
    joint_route_1_86_0  joint_cover_1_4  1
    joint_route_1_86_0  joint_cover_1_7  1
    joint_route_1_86_0  joint_trip_limit_1  1
    joint_route_1_86_0  certified_E2_cost_1  87.9759394361387
    joint_route_1_86_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_86_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_86_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_87_0  OBJ       8.1787798531750752e+01
    joint_route_1_87_0  joint_cover_1_2  1
    joint_route_1_87_0  joint_cover_1_3  1
    joint_route_1_87_0  joint_cover_1_1  1
    joint_route_1_87_0  joint_cover_1_5  1
    joint_route_1_87_0  joint_trip_limit_1  1
    joint_route_1_87_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_87_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_87_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_87_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_87_1  OBJ       8.1787798531750752e+01
    joint_route_1_87_1  joint_cover_1_2  1
    joint_route_1_87_1  joint_cover_1_3  1
    joint_route_1_87_1  joint_cover_1_1  1
    joint_route_1_87_1  joint_cover_1_5  1
    joint_route_1_87_1  joint_trip_limit_1  1
    joint_route_1_87_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_87_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_87_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_87_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_88_0  OBJ       8.7139091285232269e+01
    joint_route_1_88_0  joint_cover_1_2  1
    joint_route_1_88_0  joint_cover_1_3  1
    joint_route_1_88_0  joint_cover_1_1  1
    joint_route_1_88_0  joint_cover_1_7  1
    joint_route_1_88_0  joint_trip_limit_1  1
    joint_route_1_88_0  certified_E2_cost_1  8.7139091285232269e+01
    joint_route_1_88_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_88_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_88_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_89_0  OBJ       8.1787798531750752e+01
    joint_route_1_89_0  joint_cover_1_2  1
    joint_route_1_89_0  joint_cover_1_1  1
    joint_route_1_89_0  joint_cover_1_4  1
    joint_route_1_89_0  joint_trip_limit_1  1
    joint_route_1_89_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_89_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_89_1  OBJ       8.1787798531750752e+01
    joint_route_1_89_1  joint_cover_1_2  1
    joint_route_1_89_1  joint_cover_1_1  1
    joint_route_1_89_1  joint_cover_1_4  1
    joint_route_1_89_1  joint_trip_limit_1  1
    joint_route_1_89_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_89_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_90_0  OBJ       8.1787798531750752e+01
    joint_route_1_90_0  joint_cover_1_2  1
    joint_route_1_90_0  joint_cover_1_1  1
    joint_route_1_90_0  joint_cover_1_4  1
    joint_route_1_90_0  joint_cover_1_5  1
    joint_route_1_90_0  joint_trip_limit_1  1
    joint_route_1_90_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_90_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_90_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_90_1  OBJ       8.1787798531750752e+01
    joint_route_1_90_1  joint_cover_1_2  1
    joint_route_1_90_1  joint_cover_1_1  1
    joint_route_1_90_1  joint_cover_1_4  1
    joint_route_1_90_1  joint_cover_1_5  1
    joint_route_1_90_1  joint_trip_limit_1  1
    joint_route_1_90_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_90_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_90_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_91_0  OBJ       87.9759394361387
    joint_route_1_91_0  joint_cover_1_2  1
    joint_route_1_91_0  joint_cover_1_1  1
    joint_route_1_91_0  joint_cover_1_4  1
    joint_route_1_91_0  joint_cover_1_5  1
    joint_route_1_91_0  joint_cover_1_7  1
    joint_route_1_91_0  joint_trip_limit_1  1
    joint_route_1_91_0  certified_E2_cost_1  87.9759394361387
    joint_route_1_91_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_91_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_91_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_92_0  OBJ       87.9759394361387
    joint_route_1_92_0  joint_cover_1_2  1
    joint_route_1_92_0  joint_cover_1_1  1
    joint_route_1_92_0  joint_cover_1_4  1
    joint_route_1_92_0  joint_cover_1_7  1
    joint_route_1_92_0  joint_trip_limit_1  1
    joint_route_1_92_0  certified_E2_cost_1  87.9759394361387
    joint_route_1_92_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_92_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_93_0  OBJ       8.1787798531750752e+01
    joint_route_1_93_0  joint_cover_1_2  1
    joint_route_1_93_0  joint_cover_1_1  1
    joint_route_1_93_0  joint_cover_1_5  1
    joint_route_1_93_0  joint_trip_limit_1  1
    joint_route_1_93_0  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_93_0  joint_cutoff_C3_order_b1  -1
    joint_route_1_93_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_93_1  OBJ       8.1787798531750752e+01
    joint_route_1_93_1  joint_cover_1_2  1
    joint_route_1_93_1  joint_cover_1_1  1
    joint_route_1_93_1  joint_cover_1_5  1
    joint_route_1_93_1  joint_trip_limit_1  1
    joint_route_1_93_1  certified_E2_cost_1  8.1787798531750752e+01
    joint_route_1_93_1  joint_cutoff_C3_order_b2  -1
    joint_route_1_93_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_94_0  OBJ       87.9759394361387
    joint_route_1_94_0  joint_cover_1_2  1
    joint_route_1_94_0  joint_cover_1_1  1
    joint_route_1_94_0  joint_cover_1_5  1
    joint_route_1_94_0  joint_cover_1_7  1
    joint_route_1_94_0  joint_trip_limit_1  1
    joint_route_1_94_0  certified_E2_cost_1  87.9759394361387
    joint_route_1_94_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_94_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_94_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_95_0  OBJ       8.7139091285232269e+01
    joint_route_1_95_0  joint_cover_1_2  1
    joint_route_1_95_0  joint_cover_1_1  1
    joint_route_1_95_0  joint_cover_1_7  1
    joint_route_1_95_0  joint_trip_limit_1  1
    joint_route_1_95_0  certified_E2_cost_1  8.7139091285232269e+01
    joint_route_1_95_0  joint_cutoff_C3_order_b2  -1
    joint_route_1_95_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_96_0  OBJ       7.5073297516493838e+01
    joint_route_1_96_0  joint_cover_1_2  1
    joint_route_1_96_0  joint_cover_1_3  1
    joint_route_1_96_0  joint_trip_limit_1  1
    joint_route_1_96_0  certified_E2_cost_1  7.5073297516493838e+01
    joint_route_1_96_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_96_1  OBJ       7.5073297516493838e+01
    joint_route_1_96_1  joint_cover_1_2  1
    joint_route_1_96_1  joint_cover_1_3  1
    joint_route_1_96_1  joint_trip_limit_1  1
    joint_route_1_96_1  certified_E2_cost_1  7.5073297516493838e+01
    joint_route_1_96_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_97_0  OBJ       7.9032789904156317e+01
    joint_route_1_97_0  joint_cover_1_2  1
    joint_route_1_97_0  joint_cover_1_3  1
    joint_route_1_97_0  joint_cover_1_4  1
    joint_route_1_97_0  joint_trip_limit_1  1
    joint_route_1_97_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_97_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_97_1  OBJ       7.9032789904156317e+01
    joint_route_1_97_1  joint_cover_1_2  1
    joint_route_1_97_1  joint_cover_1_3  1
    joint_route_1_97_1  joint_cover_1_4  1
    joint_route_1_97_1  joint_trip_limit_1  1
    joint_route_1_97_1  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_97_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_98_0  OBJ       7.9032789904156317e+01
    joint_route_1_98_0  joint_cover_1_2  1
    joint_route_1_98_0  joint_cover_1_3  1
    joint_route_1_98_0  joint_cover_1_4  1
    joint_route_1_98_0  joint_cover_1_5  1
    joint_route_1_98_0  joint_trip_limit_1  1
    joint_route_1_98_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_98_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_98_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_98_1  OBJ       7.9032789904156317e+01
    joint_route_1_98_1  joint_cover_1_2  1
    joint_route_1_98_1  joint_cover_1_3  1
    joint_route_1_98_1  joint_cover_1_4  1
    joint_route_1_98_1  joint_cover_1_5  1
    joint_route_1_98_1  joint_trip_limit_1  1
    joint_route_1_98_1  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_98_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_98_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_99_0  OBJ       8.5220930808544253e+01
    joint_route_1_99_0  joint_cover_1_2  1
    joint_route_1_99_0  joint_cover_1_3  1
    joint_route_1_99_0  joint_cover_1_4  1
    joint_route_1_99_0  joint_cover_1_5  1
    joint_route_1_99_0  joint_cover_1_7  1
    joint_route_1_99_0  joint_trip_limit_1  1
    joint_route_1_99_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_99_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_99_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_99_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_100_0  OBJ       8.5220930808544253e+01
    joint_route_1_100_0  joint_cover_1_2  1
    joint_route_1_100_0  joint_cover_1_3  1
    joint_route_1_100_0  joint_cover_1_4  1
    joint_route_1_100_0  joint_cover_1_7  1
    joint_route_1_100_0  joint_trip_limit_1  1
    joint_route_1_100_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_100_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_100_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_101_0  OBJ       7.9032789904156317e+01
    joint_route_1_101_0  joint_cover_1_2  1
    joint_route_1_101_0  joint_cover_1_3  1
    joint_route_1_101_0  joint_cover_1_5  1
    joint_route_1_101_0  joint_trip_limit_1  1
    joint_route_1_101_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_101_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_101_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_101_1  OBJ       7.9032789904156317e+01
    joint_route_1_101_1  joint_cover_1_2  1
    joint_route_1_101_1  joint_cover_1_3  1
    joint_route_1_101_1  joint_cover_1_5  1
    joint_route_1_101_1  joint_trip_limit_1  1
    joint_route_1_101_1  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_101_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_101_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_102_0  OBJ       8.5220930808544253e+01
    joint_route_1_102_0  joint_cover_1_2  1
    joint_route_1_102_0  joint_cover_1_3  1
    joint_route_1_102_0  joint_cover_1_5  1
    joint_route_1_102_0  joint_cover_1_7  1
    joint_route_1_102_0  joint_trip_limit_1  1
    joint_route_1_102_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_102_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_102_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_102_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_103_0  OBJ       8.3292504113090274e+01
    joint_route_1_103_0  joint_cover_1_2  1
    joint_route_1_103_0  joint_cover_1_3  1
    joint_route_1_103_0  joint_cover_1_7  1
    joint_route_1_103_0  joint_trip_limit_1  1
    joint_route_1_103_0  certified_E2_cost_1  8.3292504113090274e+01
    joint_route_1_103_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_103_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_104_0  OBJ       7.9032789904156317e+01
    joint_route_1_104_0  joint_cover_1_2  1
    joint_route_1_104_0  joint_cover_1_4  1
    joint_route_1_104_0  joint_trip_limit_1  1
    joint_route_1_104_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_105_0  OBJ       7.9032789904156317e+01
    joint_route_1_105_0  joint_cover_1_2  1
    joint_route_1_105_0  joint_cover_1_4  1
    joint_route_1_105_0  joint_cover_1_5  1
    joint_route_1_105_0  joint_trip_limit_1  1
    joint_route_1_105_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_105_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_105_1  OBJ       7.9032789904156317e+01
    joint_route_1_105_1  joint_cover_1_2  1
    joint_route_1_105_1  joint_cover_1_4  1
    joint_route_1_105_1  joint_cover_1_5  1
    joint_route_1_105_1  joint_trip_limit_1  1
    joint_route_1_105_1  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_105_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_106_0  OBJ       8.5220930808544253e+01
    joint_route_1_106_0  joint_cover_1_2  1
    joint_route_1_106_0  joint_cover_1_4  1
    joint_route_1_106_0  joint_cover_1_5  1
    joint_route_1_106_0  joint_cover_1_7  1
    joint_route_1_106_0  joint_trip_limit_1  1
    joint_route_1_106_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_106_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_106_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_107_0  OBJ       8.5220930808544253e+01
    joint_route_1_107_0  joint_cover_1_2  1
    joint_route_1_107_0  joint_cover_1_4  1
    joint_route_1_107_0  joint_cover_1_7  1
    joint_route_1_107_0  joint_trip_limit_1  1
    joint_route_1_107_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_107_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_108_0  OBJ       7.9032789904156317e+01
    joint_route_1_108_0  joint_cover_1_2  1
    joint_route_1_108_0  joint_cover_1_5  1
    joint_route_1_108_0  joint_trip_limit_1  1
    joint_route_1_108_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_108_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_108_1  OBJ       7.9032789904156317e+01
    joint_route_1_108_1  joint_cover_1_2  1
    joint_route_1_108_1  joint_cover_1_5  1
    joint_route_1_108_1  joint_trip_limit_1  1
    joint_route_1_108_1  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_108_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_109_0  OBJ       8.5220930808544253e+01
    joint_route_1_109_0  joint_cover_1_2  1
    joint_route_1_109_0  joint_cover_1_5  1
    joint_route_1_109_0  joint_cover_1_7  1
    joint_route_1_109_0  joint_trip_limit_1  1
    joint_route_1_109_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_109_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_109_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_110_0  OBJ       8.3292504113090274e+01
    joint_route_1_110_0  joint_cover_1_2  1
    joint_route_1_110_0  joint_cover_1_7  1
    joint_route_1_110_0  joint_trip_limit_1  1
    joint_route_1_110_0  certified_E2_cost_1  8.3292504113090274e+01
    joint_route_1_110_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_111_0  OBJ       7.9032789904156317e+01
    joint_route_1_111_0  joint_cover_1_3  1
    joint_route_1_111_0  joint_cover_1_4  1
    joint_route_1_111_0  joint_trip_limit_1  1
    joint_route_1_111_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_111_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_111_1  OBJ       7.9032789904156317e+01
    joint_route_1_111_1  joint_cover_1_3  1
    joint_route_1_111_1  joint_cover_1_4  1
    joint_route_1_111_1  joint_trip_limit_1  1
    joint_route_1_111_1  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_111_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_112_0  OBJ       7.9032789904156317e+01
    joint_route_1_112_0  joint_cover_1_3  1
    joint_route_1_112_0  joint_cover_1_4  1
    joint_route_1_112_0  joint_cover_1_5  1
    joint_route_1_112_0  joint_trip_limit_1  1
    joint_route_1_112_0  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_112_0  joint_cutoff_C5_order_b1  -1
    joint_route_1_112_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_112_1  OBJ       7.9032789904156317e+01
    joint_route_1_112_1  joint_cover_1_3  1
    joint_route_1_112_1  joint_cover_1_4  1
    joint_route_1_112_1  joint_cover_1_5  1
    joint_route_1_112_1  joint_trip_limit_1  1
    joint_route_1_112_1  certified_E2_cost_1  7.9032789904156317e+01
    joint_route_1_112_1  joint_cutoff_C5_order_b2  -1
    joint_route_1_112_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_113_0  OBJ       8.5220930808544253e+01
    joint_route_1_113_0  joint_cover_1_3  1
    joint_route_1_113_0  joint_cover_1_4  1
    joint_route_1_113_0  joint_cover_1_5  1
    joint_route_1_113_0  joint_cover_1_7  1
    joint_route_1_113_0  joint_trip_limit_1  1
    joint_route_1_113_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_113_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_113_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_113_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_114_0  OBJ       8.5220930808544253e+01
    joint_route_1_114_0  joint_cover_1_3  1
    joint_route_1_114_0  joint_cover_1_4  1
    joint_route_1_114_0  joint_cover_1_7  1
    joint_route_1_114_0  joint_trip_limit_1  1
    joint_route_1_114_0  certified_E2_cost_1  8.5220930808544253e+01
    joint_route_1_114_0  joint_cutoff_C5_order_b2  -1
    joint_route_1_114_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_115_0  OBJ       4.1231056256176608e+01
    joint_route_1_115_0  joint_cover_1_4  1
    joint_route_1_115_0  joint_trip_limit_1  1
    joint_route_1_115_0  certified_E2_cost_1  4.1231056256176608e+01
    joint_route_1_116_0  OBJ       4.1231056256176608e+01
    joint_route_1_116_0  joint_cover_1_4  1
    joint_route_1_116_0  joint_cover_1_5  1
    joint_route_1_116_0  joint_trip_limit_1  1
    joint_route_1_116_0  certified_E2_cost_1  4.1231056256176608e+01
    joint_route_1_116_0  joint_cutoff_C0_order_b1  -1
    joint_route_1_116_1  OBJ       4.1231056256176608e+01
    joint_route_1_116_1  joint_cover_1_4  1
    joint_route_1_116_1  joint_cover_1_5  1
    joint_route_1_116_1  joint_trip_limit_1  1
    joint_route_1_116_1  certified_E2_cost_1  4.1231056256176608e+01
    joint_route_1_116_1  joint_cutoff_C0_order_b2  -1
    joint_route_1_117_0  OBJ       4.7419197160564543e+01
    joint_route_1_117_0  joint_cover_1_4  1
    joint_route_1_117_0  joint_cover_1_5  1
    joint_route_1_117_0  joint_cover_1_7  1
    joint_route_1_117_0  joint_trip_limit_1  1
    joint_route_1_117_0  certified_E2_cost_1  4.7419197160564543e+01
    joint_route_1_117_0  joint_cutoff_C0_order_b2  -1
    joint_route_1_117_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_118_0  OBJ       4.7419197160564543e+01
    joint_route_1_118_0  joint_cover_1_4  1
    joint_route_1_118_0  joint_cover_1_7  1
    joint_route_1_118_0  joint_trip_limit_1  1
    joint_route_1_118_0  certified_E2_cost_1  4.7419197160564543e+01
    joint_route_1_118_0  joint_cutoff_C6_order_b2  -1
    joint_route_1_119_0  OBJ       4.5122056690713912e+01
    joint_route_1_119_0  joint_cover_1_6  1
    joint_route_1_119_0  joint_trip_limit_1  1
    joint_route_1_119_0  certified_E2_cost_1  4.5122056690713912e+01
    joint_route_1_120_0  OBJ       4.5122056690713912e+01
    joint_route_1_120_0  joint_cover_1_6  1
    joint_route_1_120_0  joint_cover_1_7  1
    joint_route_1_120_0  joint_trip_limit_1  1
    joint_route_1_120_0  certified_E2_cost_1  4.5122056690713912e+01
    joint_route_1_120_0  joint_cutoff_C6_order_b2  -1
    MARKER    'MARKER'                 'INTEND'
RHS
    RHS1      R160      2
    RHS1      R161      1
    RHS1      R163      1
    RHS1      R164      1
    RHS1      R166      1
    RHS1      R167      2
    RHS1      R168      1
    RHS1      R170      1
    RHS1      R171      1
    RHS1      R173      1
    RHS1      R174      31230
    RHS1      R175      330
    RHS1      R176      1800
    RHS1      R177      930
    RHS1      R178      1
    RHS1      R179      45620
    RHS1      R180      820
    RHS1      R181      3000
    RHS1      R182      1420
    RHS1      R183      1
    RHS1      R184      60053
    RHS1      R185      967
    RHS1      R186      2400
    RHS1      R187      1567
    RHS1      R188      1
    RHS1      R189      32303
    RHS1      R190      937
    RHS1      R191      1800
    RHS1      R192      1537
    RHS1      R193      1
    RHS1      R194      32893
    RHS1      R195      1187
    RHS1      R196      3000
    RHS1      R197      1787
    RHS1      R198      1
    RHS1      R199      46661
    RHS1      R200      679
    RHS1      R201      3000
    RHS1      R202      1279
    RHS1      R203      1
    RHS1      R204      61063
    RHS1      R205      737
    RHS1      R206      1800
    RHS1      R207      1337
    RHS1      R208      1
    RHS1      clean_stock_b1  -3
    RHS1      R215      1.1474845766132141e+02
    RHS1      R216      1.1474845766132141e+02
    RHS1      certified_E1_cost  2.2963299419004804e+02
    RHS1      joint_cover_0_0  1
    RHS1      joint_cover_0_1  1
    RHS1      joint_cover_0_2  1
    RHS1      joint_cover_0_3  1
    RHS1      joint_cover_0_4  1
    RHS1      joint_cover_0_5  1
    RHS1      joint_trip_limit_0  6
    RHS1      certified_E2_cost_0  1.2296083694479404e+02
    RHS1      joint_cover_1_0  1
    RHS1      joint_cover_1_1  1
    RHS1      joint_cover_1_2  1
    RHS1      joint_cover_1_3  1
    RHS1      joint_cover_1_4  1
    RHS1      joint_cover_1_5  1
    RHS1      joint_cover_1_6  1
    RHS1      joint_cover_1_7  1
    RHS1      joint_trip_limit_1  8
    RHS1      certified_E2_cost_1  1.2718168274611129e+02
    RHS1      GC0       28800
    RHS1      GC1       54000
    RHS1      GC2       54001
    RHS1      GC3       71100
    RHS1      GC4       28800
    RHS1      GC5       54000
    RHS1      GC6       54001
    RHS1      GC7       71100
    RHS1      GC8       28800
    RHS1      GC9       54000
    RHS1      GC10      54001
    RHS1      GC11      71100
    RHS1      GC12      28800
    RHS1      GC13      54000
    RHS1      GC14      54001
    RHS1      GC15      71100
    RHS1      GC16      28800
    RHS1      GC17      54000
    RHS1      GC18      54001
    RHS1      GC19      71100
    RHS1      GC20      28800
    RHS1      GC21      54000
    RHS1      GC22      54001
    RHS1      GC23      71100
    RHS1      GC24      28800
    RHS1      GC25      54000
    RHS1      GC26      54001
    RHS1      GC27      71100
BOUNDS
 BV BND1      route[0]
 BV BND1      route[1]
 BV BND1      route[2]
 BV BND1      route[3]
 BV BND1      route[4]
 BV BND1      route[5]
 BV BND1      route[6]
 BV BND1      route[7]
 BV BND1      route[8]
 BV BND1      route[9]
 BV BND1      route[10]
 BV BND1      route[11]
 BV BND1      route[12]
 BV BND1      route[13]
 BV BND1      route[14]
 BV BND1      route[15]
 BV BND1      route[16]
 BV BND1      route[17]
 BV BND1      route[18]
 BV BND1      route[19]
 BV BND1      route[20]
 BV BND1      route[21]
 BV BND1      route[22]
 BV BND1      route[23]
 BV BND1      route[24]
 BV BND1      route[25]
 BV BND1      route[26]
 BV BND1      route[27]
 BV BND1      route[28]
 BV BND1      route[29]
 BV BND1      route[30]
 BV BND1      route[31]
 BV BND1      route[32]
 BV BND1      route[33]
 BV BND1      route[34]
 BV BND1      route[35]
 BV BND1      route[36]
 BV BND1      route[37]
 UP BND1      quantity_0_S0  5
 UP BND1      quantity_2_S0  5
 UP BND1      quantity_3_S1  7
 UP BND1      quantity_4_S0  5
 UP BND1      quantity_4_S1  7
 UP BND1      quantity_5_S1  7
 UP BND1      quantity_5_S0  5
 UP BND1      quantity_7_S0  5
 UP BND1      quantity_8_S1  7
 UP BND1      quantity_9_S1  7
 UP BND1      quantity_9_S0  5
 UP BND1      quantity_11_S0  5
 UP BND1      quantity_12_S1  7
 UP BND1      quantity_13_S1  7
 UP BND1      quantity_13_S0  5
 UP BND1      quantity_15_S0  5
 UP BND1      quantity_16_S1  7
 UP BND1      quantity_17_S0  5
 UP BND1      quantity_17_S1  7
 UP BND1      quantity_18_S1  7
 UP BND1      quantity_18_S0  5
 UP BND1      quantity_19_S0  5
 UP BND1      quantity_21_S0  5
 UP BND1      quantity_22_S1  7
 UP BND1      quantity_23_S0  5
 UP BND1      quantity_23_S1  7
 UP BND1      quantity_24_S1  7
 UP BND1      quantity_24_S0  5
 UP BND1      quantity_26_S0  5
 UP BND1      quantity_27_S1  7
 UP BND1      quantity_28_S1  7
 UP BND1      quantity_28_S0  5
 UP BND1      quantity_30_S0  5
 UP BND1      quantity_31_S1  7
 UP BND1      quantity_32_S1  7
 UP BND1      quantity_32_S0  5
 UP BND1      quantity_34_S0  5
 UP BND1      quantity_35_S1  7
 UP BND1      quantity_36_S0  5
 UP BND1      quantity_36_S1  7
 UP BND1      quantity_37_S1  7
 UP BND1      quantity_37_S0  5
 UP BND1      supply_S0_b1  75600
 UP BND1      supply_S1_b1  75600
 UP BND1      supply_S0_b2  75600
 UP BND1      supply_S1_b2  75600
 LO BND1      delivery_C4_order  29460
 UP BND1      delivery_C4_order  31560
 LO BND1      pickup_time_C4_order  31860
 UP BND1      pickup_time_C4_order  36420
 LO BND1      e2_return_C4_order  28800
 UP BND1      e2_return_C4_order  71100
 BV BND1      cutoff_C4_order_b1
 BV BND1      cutoff_C4_order_b2
 LO BND1      delivery_C1_order  44340
 UP BND1      delivery_C1_order  46440
 LO BND1      pickup_time_C1_order  47040
 UP BND1      pickup_time_C1_order  51600
 LO BND1      e2_return_C1_order  28800
 UP BND1      e2_return_C1_order  71100
 BV BND1      cutoff_C1_order_b1
 BV BND1      cutoff_C1_order_b2
 LO BND1      delivery_C2_order  58920
 UP BND1      delivery_C2_order  61020
 LO BND1      pickup_time_C2_order  61020
 UP BND1      pickup_time_C2_order  65580
 LO BND1      e2_return_C2_order  28800
 UP BND1      e2_return_C2_order  71100
 BV BND1      cutoff_C2_order_b1
 BV BND1      cutoff_C2_order_b2
 LO BND1      delivery_C3_order  31140
 UP BND1      delivery_C3_order  33240
 LO BND1      pickup_time_C3_order  32640
 UP BND1      pickup_time_C3_order  37200
 LO BND1      e2_return_C3_order  28800
 UP BND1      e2_return_C3_order  71100
 BV BND1      cutoff_C3_order_b1
 BV BND1      cutoff_C3_order_b2
 LO BND1      delivery_C5_order  31980
 UP BND1      delivery_C5_order  34080
 LO BND1      pickup_time_C5_order  34680
 UP BND1      pickup_time_C5_order  39240
 LO BND1      e2_return_C5_order  28800
 UP BND1      e2_return_C5_order  71100
 BV BND1      cutoff_C5_order_b1
 BV BND1      cutoff_C5_order_b2
 LO BND1      delivery_C0_order  45240
 UP BND1      delivery_C0_order  47340
 LO BND1      pickup_time_C0_order  48840
 UP BND1      pickup_time_C0_order  53400
 LO BND1      e2_return_C0_order  28800
 UP BND1      e2_return_C0_order  71100
 BV BND1      cutoff_C0_order_b1
 BV BND1      cutoff_C0_order_b2
 LO BND1      delivery_C6_order  59700
 UP BND1      delivery_C6_order  61800
 LO BND1      pickup_time_C6_order  62100
 UP BND1      pickup_time_C6_order  66660
 LO BND1      e2_return_C6_order  28800
 UP BND1      e2_return_C6_order  71100
 BV BND1      cutoff_C6_order_b1
 BV BND1      cutoff_C6_order_b2
 BV BND1      joint_route_0_0_0
 BV BND1      joint_route_0_0_1
 BV BND1      joint_route_0_1_0
 BV BND1      joint_route_0_1_1
 BV BND1      joint_route_0_2_0
 BV BND1      joint_route_0_3_0
 BV BND1      joint_route_0_4_0
 BV BND1      joint_route_0_4_1
 BV BND1      joint_route_0_5_0
 BV BND1      joint_route_0_6_0
 BV BND1      joint_route_0_7_0
 BV BND1      joint_route_0_8_0
 BV BND1      joint_route_0_8_1
 BV BND1      joint_route_0_9_0
 BV BND1      joint_route_0_9_1
 BV BND1      joint_route_0_10_0
 BV BND1      joint_route_0_10_1
 BV BND1      joint_route_0_11_0
 BV BND1      joint_route_0_12_0
 BV BND1      joint_route_0_13_0
 BV BND1      joint_route_0_13_1
 BV BND1      joint_route_0_14_0
 BV BND1      joint_route_0_15_0
 BV BND1      joint_route_0_16_0
 BV BND1      joint_route_0_17_0
 BV BND1      joint_route_0_17_1
 BV BND1      joint_route_0_18_0
 BV BND1      joint_route_0_19_0
 BV BND1      joint_route_0_20_0
 BV BND1      joint_route_0_20_1
 BV BND1      joint_route_0_21_0
 BV BND1      joint_route_0_22_0
 BV BND1      joint_route_0_23_0
 BV BND1      joint_route_0_23_1
 BV BND1      joint_route_0_24_0
 BV BND1      joint_route_0_24_1
 BV BND1      joint_route_0_25_0
 BV BND1      joint_route_0_26_0
 BV BND1      joint_route_0_27_0
 BV BND1      joint_route_0_28_0
 BV BND1      joint_route_0_28_1
 BV BND1      joint_route_0_29_0
 BV BND1      joint_route_0_30_0
 BV BND1      joint_route_0_31_0
 BV BND1      joint_route_0_32_0
 BV BND1      joint_route_1_0_0
 BV BND1      joint_route_1_0_1
 BV BND1      joint_route_1_1_0
 BV BND1      joint_route_1_1_1
 BV BND1      joint_route_1_2_0
 BV BND1      joint_route_1_2_1
 BV BND1      joint_route_1_3_0
 BV BND1      joint_route_1_4_0
 BV BND1      joint_route_1_4_1
 BV BND1      joint_route_1_5_0
 BV BND1      joint_route_1_6_0
 BV BND1      joint_route_1_7_0
 BV BND1      joint_route_1_7_1
 BV BND1      joint_route_1_8_0
 BV BND1      joint_route_1_8_1
 BV BND1      joint_route_1_9_0
 BV BND1      joint_route_1_10_0
 BV BND1      joint_route_1_11_0
 BV BND1      joint_route_1_11_1
 BV BND1      joint_route_1_12_0
 BV BND1      joint_route_1_13_0
 BV BND1      joint_route_1_14_0
 BV BND1      joint_route_1_15_0
 BV BND1      joint_route_1_15_1
 BV BND1      joint_route_1_16_0
 BV BND1      joint_route_1_16_1
 BV BND1      joint_route_1_17_0
 BV BND1      joint_route_1_17_1
 BV BND1      joint_route_1_18_0
 BV BND1      joint_route_1_18_1
 BV BND1      joint_route_1_19_0
 BV BND1      joint_route_1_20_0
 BV BND1      joint_route_1_20_1
 BV BND1      joint_route_1_21_0
 BV BND1      joint_route_1_22_0
 BV BND1      joint_route_1_22_1
 BV BND1      joint_route_1_23_0
 BV BND1      joint_route_1_23_1
 BV BND1      joint_route_1_24_0
 BV BND1      joint_route_1_25_0
 BV BND1      joint_route_1_26_0
 BV BND1      joint_route_1_26_1
 BV BND1      joint_route_1_27_0
 BV BND1      joint_route_1_28_0
 BV BND1      joint_route_1_29_0
 BV BND1      joint_route_1_30_0
 BV BND1      joint_route_1_30_1
 BV BND1      joint_route_1_31_0
 BV BND1      joint_route_1_31_1
 BV BND1      joint_route_1_32_0
 BV BND1      joint_route_1_32_1
 BV BND1      joint_route_1_33_0
 BV BND1      joint_route_1_33_1
 BV BND1      joint_route_1_34_0
 BV BND1      joint_route_1_35_0
 BV BND1      joint_route_1_35_1
 BV BND1      joint_route_1_36_0
 BV BND1      joint_route_1_37_0
 BV BND1      joint_route_1_37_1
 BV BND1      joint_route_1_38_0
 BV BND1      joint_route_1_38_1
 BV BND1      joint_route_1_39_0
 BV BND1      joint_route_1_40_0
 BV BND1      joint_route_1_41_0
 BV BND1      joint_route_1_41_1
 BV BND1      joint_route_1_42_0
 BV BND1      joint_route_1_43_0
 BV BND1      joint_route_1_44_0
 BV BND1      joint_route_1_44_1
 BV BND1      joint_route_1_45_0
 BV BND1      joint_route_1_45_1
 BV BND1      joint_route_1_46_0
 BV BND1      joint_route_1_46_1
 BV BND1      joint_route_1_47_0
 BV BND1      joint_route_1_48_0
 BV BND1      joint_route_1_49_0
 BV BND1      joint_route_1_49_1
 BV BND1      joint_route_1_50_0
 BV BND1      joint_route_1_51_0
 BV BND1      joint_route_1_52_0
 BV BND1      joint_route_1_53_0
 BV BND1      joint_route_1_53_1
 BV BND1      joint_route_1_54_0
 BV BND1      joint_route_1_55_0
 BV BND1      joint_route_1_56_0
 BV BND1      joint_route_1_56_1
 BV BND1      joint_route_1_57_0
 BV BND1      joint_route_1_58_0
 BV BND1      joint_route_1_59_0
 BV BND1      joint_route_1_59_1
 BV BND1      joint_route_1_60_0
 BV BND1      joint_route_1_60_1
 BV BND1      joint_route_1_61_0
 BV BND1      joint_route_1_61_1
 BV BND1      joint_route_1_62_0
 BV BND1      joint_route_1_63_0
 BV BND1      joint_route_1_64_0
 BV BND1      joint_route_1_64_1
 BV BND1      joint_route_1_65_0
 BV BND1      joint_route_1_66_0
 BV BND1      joint_route_1_67_0
 BV BND1      joint_route_1_68_0
 BV BND1      joint_route_1_68_1
 BV BND1      joint_route_1_69_0
 BV BND1      joint_route_1_70_0
 BV BND1      joint_route_1_71_0
 BV BND1      joint_route_1_71_1
 BV BND1      joint_route_1_72_0
 BV BND1      joint_route_1_73_0
 BV BND1      joint_route_1_74_0
 BV BND1      joint_route_1_74_1
 BV BND1      joint_route_1_75_0
 BV BND1      joint_route_1_75_1
 BV BND1      joint_route_1_76_0
 BV BND1      joint_route_1_77_0
 BV BND1      joint_route_1_77_1
 BV BND1      joint_route_1_78_0
 BV BND1      joint_route_1_78_1
 BV BND1      joint_route_1_79_0
 BV BND1      joint_route_1_80_0
 BV BND1      joint_route_1_81_0
 BV BND1      joint_route_1_82_0
 BV BND1      joint_route_1_82_1
 BV BND1      joint_route_1_83_0
 BV BND1      joint_route_1_83_1
 BV BND1      joint_route_1_84_0
 BV BND1      joint_route_1_84_1
 BV BND1      joint_route_1_85_0
 BV BND1      joint_route_1_85_1
 BV BND1      joint_route_1_86_0
 BV BND1      joint_route_1_87_0
 BV BND1      joint_route_1_87_1
 BV BND1      joint_route_1_88_0
 BV BND1      joint_route_1_89_0
 BV BND1      joint_route_1_89_1
 BV BND1      joint_route_1_90_0
 BV BND1      joint_route_1_90_1
 BV BND1      joint_route_1_91_0
 BV BND1      joint_route_1_92_0
 BV BND1      joint_route_1_93_0
 BV BND1      joint_route_1_93_1
 BV BND1      joint_route_1_94_0
 BV BND1      joint_route_1_95_0
 BV BND1      joint_route_1_96_0
 BV BND1      joint_route_1_96_1
 BV BND1      joint_route_1_97_0
 BV BND1      joint_route_1_97_1
 BV BND1      joint_route_1_98_0
 BV BND1      joint_route_1_98_1
 BV BND1      joint_route_1_99_0
 BV BND1      joint_route_1_100_0
 BV BND1      joint_route_1_101_0
 BV BND1      joint_route_1_101_1
 BV BND1      joint_route_1_102_0
 BV BND1      joint_route_1_103_0
 BV BND1      joint_route_1_104_0
 BV BND1      joint_route_1_105_0
 BV BND1      joint_route_1_105_1
 BV BND1      joint_route_1_106_0
 BV BND1      joint_route_1_107_0
 BV BND1      joint_route_1_108_0
 BV BND1      joint_route_1_108_1
 BV BND1      joint_route_1_109_0
 BV BND1      joint_route_1_110_0
 BV BND1      joint_route_1_111_0
 BV BND1      joint_route_1_111_1
 BV BND1      joint_route_1_112_0
 BV BND1      joint_route_1_112_1
 BV BND1      joint_route_1_113_0
 BV BND1      joint_route_1_114_0
 BV BND1      joint_route_1_115_0
 BV BND1      joint_route_1_116_0
 BV BND1      joint_route_1_116_1
 BV BND1      joint_route_1_117_0
 BV BND1      joint_route_1_118_0
 BV BND1      joint_route_1_119_0
 BV BND1      joint_route_1_120_0
INDICATORS
 IF GC0       cutoff_C4_order_b1  1
 IF GC1       cutoff_C4_order_b1  1
 IF GC2       cutoff_C4_order_b2  1
 IF GC3       cutoff_C4_order_b2  1
 IF GC4       cutoff_C1_order_b1  1
 IF GC5       cutoff_C1_order_b1  1
 IF GC6       cutoff_C1_order_b2  1
 IF GC7       cutoff_C1_order_b2  1
 IF GC8       cutoff_C2_order_b1  1
 IF GC9       cutoff_C2_order_b1  1
 IF GC10      cutoff_C2_order_b2  1
 IF GC11      cutoff_C2_order_b2  1
 IF GC12      cutoff_C3_order_b1  1
 IF GC13      cutoff_C3_order_b1  1
 IF GC14      cutoff_C3_order_b2  1
 IF GC15      cutoff_C3_order_b2  1
 IF GC16      cutoff_C5_order_b1  1
 IF GC17      cutoff_C5_order_b1  1
 IF GC18      cutoff_C5_order_b2  1
 IF GC19      cutoff_C5_order_b2  1
 IF GC20      cutoff_C0_order_b1  1
 IF GC21      cutoff_C0_order_b1  1
 IF GC22      cutoff_C0_order_b2  1
 IF GC23      cutoff_C0_order_b2  1
 IF GC24      cutoff_C6_order_b1  1
 IF GC25      cutoff_C6_order_b1  1
 IF GC26      cutoff_C6_order_b2  1
 IF GC27      cutoff_C6_order_b2  1
ENDATA
