# 数据与审计工具

`data/build_static_batch_suite.py` 生成固定批次配对，`data/static_batch_dataset.py` 选择并验证输入。
`audit/audit_static_batch_suite.py` 验证构造时间表和连续周期。
`data/build_lade_real_case.py`、`data/generate_zhou_later_pickup_dataset.py` 与 `audit/audit_r3pack_dataset.py` 保留数据来源重建和参数审计能力。
旧模型专属绘图和过时场景生成工具已归档。
