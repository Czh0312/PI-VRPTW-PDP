"""Publication artefact generators."""
