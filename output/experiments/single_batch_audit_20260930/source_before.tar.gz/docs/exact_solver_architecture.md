# 精确求解范围

正式入口将 `multi_batch_cutoff_v1` 分发到各编号目录的 `exact/solver.py`。
M1/M3 为单批固定分仓；M2/M4 为单批自由分仓；M5 为多批固定分仓。
各模型的 MILP 建模入口位于 `exact/model.py`，共同固定分仓实现位于 `models/routing/solvers/exact/`。
M2/M4 在此基础上枚举分仓；只有覆盖全部组合并取得足够证明，才报告自由分仓的全局最优。
求解器遵守输入的整数时间刻度及二级趟次上限；ALNS 位于独立 `alns/` 目录。

只有完整 MILP 返回最优并且独立审计通过，才能报告 `proven_optimal=true`。限时可行解、未找到解与已证明不可行必须区分。

历史 M1–M4 的 indexed 和 commodity_flow 后端保存在 `models/routing/baselines/`，需要 `--baseline` 或 `allow_baseline=True`。这些证明只针对历史业务规则，不能作为新版四模型的证明。
