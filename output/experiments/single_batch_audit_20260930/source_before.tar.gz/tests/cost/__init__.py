"""Economic-model tests."""
