"""All B=1 cases must reach each exact model, including real-derived cases."""
import pytest

from experiments.runs.run_single_batch_exact import main, outcome


def test_full_single_batch_exact_plan_covers_four_models(capsys):
    plan = main(['--dry-run', '--exact-time', '300'])
    assert plan['case_count'] == 69
    assert plan['job_count'] == 276
    assert plan['total_budget_seconds'] == 82800
    jobs = plan['jobs']
    assert len({job['run'] for job in jobs}) == 276
    assert all(job['batch_count'] == 1 and job['solver'] == 'exact' for job in jobs)
    for model in range(1, 5):
        subset = [job for job in jobs if job['model'] == model]
        assert len(subset) == 69
        assert {job['size'] for job in subset} == {'small', 'medium', 'large'}
    assert any(job['source_kind'] == 'lade_derived_scenario' for job in jobs)
    capsys.readouterr()


@pytest.mark.parametrize('valid,optimal,infeasible,status,expected', [
    (True, True, False, 'OPTIMAL', 'OPTIMAL'),
    (True, False, False, 'TIME_LIMIT', 'FEASIBLE_NOT_PROVEN'),
    (False, False, False, 'TIME_LIMIT', 'NO_SOLUTION_WITHIN_BUDGET'),
    (False, False, False, 'TIME_LIMIT_BUILD', 'NO_SOLUTION_WITHIN_BUDGET'),
    (False, False, True, 'INFEASIBLE', 'INFEASIBLE'),
    (False, False, False, 'AUDIT_FAILED', 'ERROR_OR_AUDIT_FAILURE'),
])
def test_summary_distinguishes_proofs_from_time_limits(valid, optimal, infeasible, status, expected):
    assert outcome(dict(valid=valid, proven_optimal=optimal,
                        proven_infeasible=infeasible, status=status)) == expected
