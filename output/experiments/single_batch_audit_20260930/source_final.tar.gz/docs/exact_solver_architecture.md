# 精确求解范围

正式入口将 `multi_batch_cutoff_v1` 分发到各编号目录的 `exact/solver.py`。
M1/M3 为单批固定分仓；M2/M4 为单批自由分仓；M5 为多批固定分仓。
各模型的 MILP 建模入口位于 `exact/model.py`，共同固定分仓实现位于 `models/routing/solvers/exact/`。
M2/M4 在此基础上枚举分仓；只有覆盖全部组合并取得足够证明，才报告自由分仓的全局最优。
求解器遵守输入的整数时间刻度及二级趟次上限；ALNS 位于独立 `alns/` 目录。

固定分仓只有完整 MILP 返回最优并且独立审计通过，才能报告 `proven_optimal=true`。
自由分仓还要求全部组合被最优、不可行证明或有效成本下界闭合。`BOUND_PRUNED` 仅表示不能改善
现有已审计可行解，不表示该组合不可行。限时可行解、未找到解与已证明不可行必须区分。

B=1 专门化将回收量固定为各仓全部订单箱数，直接约束带箱二级趟次在唯一截止前卸回，保留清洗末态。
另有基于安全时间界的弧删除、同质车辆对称性、分仓距离界剪枝、未闭合分区重访和经过独立审计的
MIP 初始解。详见 [2026-09-30 检查与对照](single_batch_solver_audit_20260930.md)。

历史 M1–M4 的 indexed 和 commodity_flow 后端保存在 `models/routing/baselines/`，需要 `--baseline` 或 `allow_baseline=True`。这些证明只针对历史业务规则，不能作为新版四模型的证明。
