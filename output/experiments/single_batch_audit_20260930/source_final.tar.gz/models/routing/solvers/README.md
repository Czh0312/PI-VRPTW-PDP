# 当前模型的求解实现

M1–M5 的公开入口仍位于 `../variants/model_n/`，由 `../service.py` 按编号与方法分流。
这里按求解方法存放底层实现，两种方法互不导入。

| 目录 | 文件 | 职责 |
| --- | --- | --- |
| `exact/` | `formulation.py` | 固定分仓的车辆索引 MILP |
| `exact/` | `solver.py` | 调用 Gurobi、提取时间表和最优性证明信息 |
| `exact/` | `assignment.py` | M2/M4 的完整分仓枚举、子问题界与全局证明汇总 |
| `exact/` | `bounds.py` | 非度量距离也适用的保守必访弧下界 |
| `alns/` | `solver.py` | 路线与跨批修复搜索 |
| `alns/` | `construction.py` | 构造初始解 |
| `alns/` | `evaluator.py` | 候选解的日程解码和全周期评价 |
| `alns/` | `assignment.py` | M2/M4 的启发式分仓搜索 |
| `alns/` | `neighborhoods.py` | 多请求破坏/插入修复、有界评价缓存及可行解热启动转换 |

`../common/cycle/` 只提供输入、业务规则、结果格式、分仓转换和独立审计。
ALNS 不导入精确求解或 Gurobi；精确求解不导入 ALNS；共同审计不调用任一求解器的评价结论。
各模型的公共 API 按需导入选定的方法，结果通过 `solver` 和 `solver_module` 记录求解方法与实现位置。

M2/M4 只有全部分仓组合获得足够证明后才能报告全局最优。
ALNS 的可行方案不带最优性证明；精确求解遇到时间上限也不能直接视为已证明最优。

独立加载和实际求解的回归测试：`tests/routing/test_solver_isolation.py`。
2026-09-29 的目录分离本身未改变数学约束或搜索函数逻辑。详见 [模型布局](../../../docs/model_layout.md)。

2026-09-30 增加了 B=1 等价简化、时间窗稀疏弧、车辆对称性、分仓界剪枝与未闭合分区再求解。
ALNS 新增破坏/修复、反转、缓存、双预算降温和分仓热启动，并修复非度量矩阵下临时回程的误判。
`BOUND_PRUNED` 表示该分仓不能改善已审计 incumbent，不表示不可行。
诊断实验的改进与退步均见 [详细检查报告](../../../docs/single_batch_solver_audit_20260930.md)。
