# 模型 6 数据集

小、中、大各9例，共27例。每例的 `case.json` 可直接运行，`parameters.json` 列出固定参数、优化决策及不适用的机制。

模型设置：`{"packaging": "reusable", "assignment": "fixed_reference", "batch_count": "optimized_common_admissible_domain", "order_batches": "optimized", "calendar": "equal_length_common_cutoff_optimized", "pool": "optimized_1_to_Q", "objective": "cost"}`

最终运行范围以各例 case.json 为准；M6–M8 使用完整正整数批次数域，共同物理输入位于本数据集 shared 目录。
